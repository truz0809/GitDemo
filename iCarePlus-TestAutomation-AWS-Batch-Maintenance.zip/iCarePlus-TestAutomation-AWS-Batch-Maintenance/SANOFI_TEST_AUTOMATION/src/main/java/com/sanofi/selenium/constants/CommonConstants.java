package com.sanofi.selenium.constants;

public interface CommonConstants {

	
	public static final String constStatus="Status";
	public static final String constFailedStatus= "FAILED";
	public static final String constPassedStatus= "PASSED";

}
