package com.sanofi.selenium.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class PrescriptionInformation extends Utility_Function {

	public PrescriptionInformation(WebDriver driver) {
		super(driver);
	}

	/************* Static Elements ******************************************/

	public static By RefillQuantity5A = By.xpath("(*//span[contains(text(),'Refill/Qty Captured')])[1]");
	public static By RefillFieldInput = By.xpath(
			"(//*[contains(text(),'Refill/Qty Captured')]//parent::label//parent::div//following-sibling::div//child::input)[1]");

	// wrong xpath
	public static By PrescriptionDoseListXpath = By.xpath(
			"//*[contains(@class,\"slds-grid\")]//*[text()=\"Prescription Dose\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]");

	public static By Prescription5BDoseListXpath = By.xpath(
			"//*[@data-omni-key=\"iccPrescriptionDoseCaptured\"]//*[contains(@class,\"slds-grid\")]//*[text()=\"Prescription Dose\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]");

	public static By PrescriptionDoseFieldInput = By.xpath(
			"(//*[contains(@class,\"slds-grid\")]//*[text()=\"Prescription Dose\"]//parent::label//parent::div//following-sibling::div[contains(@class,\"slds-combobox\")])[1]");

	public static By eleQuickStartList = By.xpath(
			"//*[contains(@class,\"slds-grid\")]//*[text()=\"QuickStart Rx (Y/N)\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]");

	public static By RefillQuantity5B = By.xpath("(*//span[contains(text(),'Refill/Qty Captured')])[2]");
	public static By RefillQuantity5BFieldInput = By.xpath(
			"(//*[contains(text(),'Refill/Qty Captured')]//parent::label//parent::div//following-sibling::div//child::input)[2]");

	public static By PrescriptionDose5BListXpath = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Prescription Dose\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]");
	public static By PrescriptionDose5BFieldInput = By.xpath(
			"(//*[contains(@class,\"slds-grid\")]//*[text()=\"Prescription Dose\"]//parent::label//parent::div//following-sibling::div[contains(@class,\"slds-combobox\")])[2]");

	public static By PrescriptionDateListXpath = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Prescribed Date\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]");
	public static By PrescriptionDateFieldInput = By.xpath(
			"*//label[contains(text(),'Prescribed Date') or aria-label='Prescribed Date']//parent::label//parent::div//following-sibling::div//child::input");

	public static By elePrescriptionSignedListXpath = By.xpath(
			"//*[contains(@class,\"slds-grid\")]//*[text()=\"Prescription Signed\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]");

//	public static By Submit = By.xpath(
//			"//div[@class='slds-grid slds-wrap slds-grid_align-end omniscript-button-position']//span[@role='tooltip'][normalize-space()='Submit']");
//	public static By Confirm = By.xpath(
//			"//div[@class='slds-grid slds-wrap slds-grid_align-end omniscript-button-position']//span[@role='tooltip'][normalize-space()='Ok']");

	public static By elePageTitle = By.xpath(
			"*//div[contains(@class,\"omniscript-body\")]//*[text()='Prescription Information']");

	/************* Dynamic Elements ******************************************/

	public static String strDropdown = "//*[contains(@class,'active lafPageHost')]//*[contains(@class,'slds-combobox')]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div";
	public static String strInputField = "//*[contains(@class,'active lafPageHost')]//*[text()=\"{0}\"]//parent::label//parent::div//parent::div//following-sibling::div//child::input";
	public static String prevNextButtons = "//*[contains(@class,\"omniscript-button-position\")]//*[text()=\"{0}\"]";
	public static String strdropDownXpath = "//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//child::input";
	public static String strInputBoxesXpath = "//div[contains(@class,\"slds-form-container\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String searchButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";
	public static String collabMDName = "(//*[contains(@class,\"active lafPageHost\")]//*[(text()=\"{0}\")]//ancestor::tbody//span[contains(@class,\"slds-grid slds-grid_align-spread\")])[1]";
	public static String collabMDName2 = "(//*[contains(@class,\"active lafPageHost\")]//*[(text()=\"{0}\")]//ancestor::tbody//span[contains(@class,\"slds-grid slds-grid_align-spread\")])[7]";
	public static String colmnData = "(//*[text()='Source System']//ancestor::thead//following-sibling::tbody//td[5])[\"{0}\"]";
	public static String collabNPI = "//*[contains(@class,\"active lafPageHost\")]//*[(text()=\"{0}\")]//ancestor::td//preceding-sibling::th//span";

	public void verifyPrescriptionInfoPageTitle() {
		try {

			setTimeOut(2000);
			waitForPageLoaded();
			Log.info("Verify Prescription Information Page Present");
			waitAndVerifyElement(elePageTitle);
			LoggingInfo("Prescription Information Page is loaded");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Page load has Failed" + ". Error - " + e.getMessage());

		}
	}

	public void PrescriptionValidation(String RefillCapturedExcelData, String Prescription5ADoseExcelData,
			String Prescription5BQuickStartExcleData, String PrescriptionBRefillCapturedExcelData,
			String Prescription5BDoseExcelData, String PrescriberSignedExcelData, String PrescriberDateExcelData,
			String CollaboratingMDFirstNameExcelData, String CollaboratingMDLastNameExcelData,
			String nursePractitionerNPIExcelData) throws InterruptedException {

		try {

			Log.info("Verify Prescription Information");

			waitAndVerifyElement(RefillFieldInput);
			verifyAndEnterDataInputField(RefillFieldInput, RefillCapturedExcelData, prescriptionARefillCaptured);

			waitAndVerifyElement(PrescriptionDoseFieldInput);
			if (!Prescription5ADoseExcelData.isEmpty()) {
				click(PrescriptionDoseFieldInput);
				selectItemFromList(PrescriptionDoseFieldInput, PrescriptionDoseListXpath, Prescription5ADoseExcelData,
						prescription5ADose);
			}

			By eleQuickStartFieldInput = getDynamicElement(strdropDownXpath, "QuickStart Rx (Y/N)");
			waitAndVerifyElement(eleQuickStartFieldInput);
			if (!Prescription5BQuickStartExcleData.isEmpty()) {
				scrollToElement(eleQuickStartFieldInput);
				click(eleQuickStartFieldInput);
				selectItemFromList(eleQuickStartFieldInput, eleQuickStartList, Prescription5BQuickStartExcleData,
						"QuickStart Rx");
			}

			waitAndVerifyElement(RefillQuantity5BFieldInput);
			scrollToElement(RefillQuantity5BFieldInput);
			verifyAndEnterDataInputField(RefillQuantity5BFieldInput, PrescriptionBRefillCapturedExcelData,
					prescriptionBRefillCaptured);

			waitAndVerifyElement(PrescriptionDose5BFieldInput);
			if (!Prescription5BDoseExcelData.isEmpty()) {
				click(PrescriptionDose5BFieldInput);
				selectItemFromList(PrescriptionDose5BFieldInput, Prescription5BDoseListXpath,
						Prescription5BDoseExcelData, prescription5BDose);
			}

			By elePrescriptionSignedInput = getDynamicElement(strdropDownXpath, "Prescription Signed");
			scrollToElement(elePrescriptionSignedInput);
			waitAndVerifyElement(elePrescriptionSignedInput);
			if (!PrescriberSignedExcelData.isEmpty()) {
				click(elePrescriptionSignedInput);
				selectItemFromList(elePrescriptionSignedInput, elePrescriptionSignedListXpath,
						PrescriberSignedExcelData, "Prescription Signed");
			}

			waitAndVerifyElement(PrescriptionDateFieldInput);
			verifyAndEnterDataInputField(PrescriptionDateFieldInput, PrescriberDateExcelData, prescriberState);

			By eleFirstNameCollaborationMDInput = getDynamicElement(strInputBoxesXpath, "First Name");
			scrollToElement(eleFirstNameCollaborationMDInput);
			waitAndVerifyElement(eleFirstNameCollaborationMDInput);
			verifyHardAssertInputFieldBox(eleFirstNameCollaborationMDInput, CollaboratingMDFirstNameExcelData,
					"Collaborating MD FirstName");

			By eleLastCollaborationMDInput = getDynamicElement(strInputBoxesXpath, "Last Name");
			waitAndVerifyElement(eleLastCollaborationMDInput);
			verifyHardAssertInputFieldBox(eleLastCollaborationMDInput, CollaboratingMDLastNameExcelData,
					"Collaborating MD LastName");

			By eleNPIFieldInput = getDynamicElement(strInputBoxesXpath, "NPI #");
			waitAndVerifyElement(eleNPIFieldInput);
			verifyHardAssertInputFieldBox(eleNPIFieldInput, nursePractitionerNPIExcelData, NursePractitionerNPI);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Page verification has failed" + ". Error - " + e.getMessage());
		}
	}

	public void clickOnNextButton() {
		try {
			By nextButton = getDynamicElement(prevNextButtons, "Submit");
			waitAndVerifyElement(nextButton);
			scrollToElement(nextButton);
			click(nextButton);
			Log.info("Clicked on Submit Button");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on Submit Button-" + "Error - " + e.getMessage());
		}
	}

	// Anand P
	public void verifySearchButton() {
		try {

			// *[contains(@class,"active lafPageHost")]//*[text()='Search']//parent::button
			By searchBtn = getDynamicElement(searchButton, "Search");
			scrollToElement(searchBtn);
			waitAndVerifyElement(searchBtn);
			Log.info("Verified search button is visible");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify search Button-" + "Error - " + e.getMessage());
		}
	}

	// Anand P
	public void clickSearchButton() {
		try {

			// *[contains(@class,"active lafPageHost")]//*[text()='Search']//parent::button
			By searchBtn = getDynamicElement(searchButton, "Search");
			scrollToElement(searchBtn);
			click(searchBtn);
			waitFor(2000);
			Log.info("Clicked search button");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify search Button-" + "Error - " + e.getMessage());
		}
	}

	public void enterPrescriptionInformation(String RefillCapturedExcelData, String Prescription5ADoseExcelData,
			String Prescription5BQuickStartExcleData, String PrescriptionBRefillCapturedExcelData,
			String Prescription5BDoseExcelData, String PrescriberSignedExcelData, String PrescriberDateExcelData,
			String CollaboratingMDFirstNameExcelData, String CollaboratingMDLastNameExcelData,
			String nursePractitionerNPIExcelData) throws InterruptedException {

		try {

			Log.info("Verify Prescription Information");

			waitAndVerifyElement(RefillFieldInput);
			verifyAndEnterDataInputField(RefillFieldInput, RefillCapturedExcelData, prescriptionARefillCaptured);

			waitAndVerifyElement(PrescriptionDoseFieldInput);
			if (!Prescription5ADoseExcelData.isEmpty()) {
				click(PrescriptionDoseFieldInput);
				selectItemFromList(PrescriptionDoseFieldInput, PrescriptionDoseListXpath, Prescription5ADoseExcelData,
						prescription5ADose);
			}

			By eleQuickStartFieldInput = getDynamicElement(strdropDownXpath, "QuickStart Rx (Y/N)");
			waitAndVerifyElement(eleQuickStartFieldInput);
			scrollToElement(eleQuickStartFieldInput);
			if (!Prescription5BQuickStartExcleData.isEmpty()) {
				click(eleQuickStartFieldInput);
				selectItemFromList(eleQuickStartFieldInput, eleQuickStartList, Prescription5BQuickStartExcleData,
						"QuickStart Rx");
			}

			waitAndVerifyElement(RefillQuantity5BFieldInput);
			verifyAndEnterDataInputField(RefillQuantity5BFieldInput, PrescriptionBRefillCapturedExcelData,
					prescriptionBRefillCaptured);

			waitAndVerifyElement(PrescriptionDose5BFieldInput);
			scrollToElement(PrescriptionDose5BFieldInput);
			if (!Prescription5BDoseExcelData.isEmpty()) {
				click(PrescriptionDose5BFieldInput);
				selectItemFromList(PrescriptionDose5BFieldInput, Prescription5BDoseListXpath,
						Prescription5BDoseExcelData, prescription5BDose);
			}

			By elePrescriptionSignedInput = getDynamicElement(strdropDownXpath, "Prescription Signed");
			waitAndVerifyElement(elePrescriptionSignedInput);
			scrollToElement(elePrescriptionSignedInput);
			if (!PrescriberSignedExcelData.isEmpty()) {
				click(elePrescriptionSignedInput);
				selectItemFromList(elePrescriptionSignedInput, elePrescriptionSignedListXpath,
						PrescriberSignedExcelData, "Prescription Signed");
			}

			waitAndVerifyElement(PrescriptionDateFieldInput);
			verifyAndEnterDataInputField(PrescriptionDateFieldInput, PrescriberDateExcelData, prescriberState);

			By eleFirstNameCollaborationMDInput = getDynamicElement(strInputBoxesXpath, "First Name");
			waitAndVerifyElement(eleFirstNameCollaborationMDInput);
			scrollToElement(eleFirstNameCollaborationMDInput);
			verifyAndEnterInfoInputField(eleFirstNameCollaborationMDInput, CollaboratingMDFirstNameExcelData,
					"Collaborating MD FirstName");

			By eleLastCollaborationMDInput = getDynamicElement(strInputBoxesXpath, "Last Name");
			waitAndVerifyElement(eleLastCollaborationMDInput);
			verifyAndEnterInfoInputField(eleLastCollaborationMDInput, CollaboratingMDLastNameExcelData,
					"Collaborating MD LastName");

			By eleNPIFieldInput = getDynamicElement(strInputBoxesXpath, "NPI #");
			waitAndVerifyElement(eleNPIFieldInput);
			verifyAndEnterInfoInputField(eleNPIFieldInput, nursePractitionerNPIExcelData, NursePractitionerNPI);

			LoggingInfo("Prescription Information has been entered/verified successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to enter Prescription Information" + ". Error - " + e.getMessage());
		}
	}

	public void enterPrescriptionInfoQN_No(String RefillCapturedExcelData, String Prescription5ADoseExcelData,
			String Prescription5BQuickStartExcleData, String PrescriptionBRefillCapturedExcelData,
			String Prescription5BDoseExcelData, String PrescriberSignedExcelData, String PrescriberDateExcelData,
			String CollaboratingMDFirstNameExcelData, String CollaboratingMDLastNameExcelData,
			String nursePractitionerNPIExcelData) throws InterruptedException {

		try {

			Log.info("Verify Prescription Information");

			waitAndVerifyElement(RefillFieldInput);
			verifyAndEnterDataInputField(RefillFieldInput, RefillCapturedExcelData, prescriptionARefillCaptured);

			waitAndVerifyElement(PrescriptionDoseFieldInput);
			if (!Prescription5ADoseExcelData.isEmpty()) {
				click(PrescriptionDoseFieldInput);
				selectItemFromList(PrescriptionDoseFieldInput, PrescriptionDoseListXpath, Prescription5ADoseExcelData,
						prescription5ADose);
			}

			By eleQuickStartFieldInput = getDynamicElement(strdropDownXpath, "QuickStart Rx (Y/N)");
			waitAndVerifyElement(eleQuickStartFieldInput);
			scrollToElement(eleQuickStartFieldInput);
			if (!Prescription5BQuickStartExcleData.isEmpty()) {
				click(eleQuickStartFieldInput);
				selectItemFromList(eleQuickStartFieldInput, eleQuickStartList, Prescription5BQuickStartExcleData,
						"QuickStart Rx");
			}

			By elePrescriptionSignedInput = getDynamicElement(strdropDownXpath, "Prescription Signed");
			waitAndVerifyElement(elePrescriptionSignedInput);
			scrollToElement(elePrescriptionSignedInput);
			if (!PrescriberSignedExcelData.isEmpty()) {
				click(elePrescriptionSignedInput);
				selectItemFromList(elePrescriptionSignedInput, elePrescriptionSignedListXpath,
						PrescriberSignedExcelData, "Prescription Signed");
			}

			waitAndVerifyElement(PrescriptionDateFieldInput);
			verifyAndEnterDataInputField(PrescriptionDateFieldInput, PrescriberDateExcelData, prescriberState);

			By eleFirstNameCollaborationMDInput = getDynamicElement(strInputBoxesXpath, "First Name");
			waitAndVerifyElement(eleFirstNameCollaborationMDInput);
			scrollToElement(eleFirstNameCollaborationMDInput);
			verifyAndEnterInfoInputField(eleFirstNameCollaborationMDInput, CollaboratingMDFirstNameExcelData,
					"Collaborating MD FirstName");

			By eleLastCollaborationMDInput = getDynamicElement(strInputBoxesXpath, "Last Name");
			waitAndVerifyElement(eleLastCollaborationMDInput);
			verifyAndEnterInfoInputField(eleLastCollaborationMDInput, CollaboratingMDLastNameExcelData,
					"Collaborating MD LastName");

			By eleNPIFieldInput = getDynamicElement(strInputBoxesXpath, "NPI #");
			waitAndVerifyElement(eleNPIFieldInput);
			verifyAndEnterInfoInputField(eleNPIFieldInput, nursePractitionerNPIExcelData, NursePractitionerNPI);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to enter Prescription Information" + ". Error - " + e.getMessage());
		}
	}

	// Anand P
	public void enterCollaboratingMDNameInfo(String CollaboratingMDFirstNameExcelData,
			String CollaboratingMDLastNameExcelData) {
		try {
			By eleFirstNameCollaborationMDInput = getDynamicElement(strInputBoxesXpath, "First Name");
			waitAndVerifyElement(eleFirstNameCollaborationMDInput);

			scrollToElement(eleFirstNameCollaborationMDInput);
			verifyAndEnterInfoInputField(eleFirstNameCollaborationMDInput, CollaboratingMDFirstNameExcelData,
					"Collaborating MD FirstName");

			By eleLastCollaborationMDInput = getDynamicElement(strInputBoxesXpath, "Last Name");
			waitAndVerifyElement(eleLastCollaborationMDInput);
			verifyAndEnterInfoInputField(eleLastCollaborationMDInput, CollaboratingMDLastNameExcelData,
					"Collaborating MD LastName");

			By eleNPIFieldInput = getDynamicElement(strInputBoxesXpath, "NPI #");
			waitAndVerifyElement(eleNPIFieldInput);
			clearText(eleNPIFieldInput);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to enter MD details" + ". Error - " + e.getMessage());

		}

	}

//Anand P
	public void verifyMultipleMatchedMD(String mdName) {
		try {
			By selectfirstRecord = getDynamicElement(collabMDName, mdName);
			scrollToElement(selectfirstRecord);
			click(selectfirstRecord);
			Log.info("Selected first record of mutiple record visible");

			By selectSecondRecord = getDynamicElement(collabMDName2, mdName);
			scrollToElement(selectSecondRecord);
			click(selectSecondRecord);
			Log.info("Selected second record of mutiple record visible");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select matched records-" + "Error - " + e.getMessage());
		}
	}

	// Anand P
	public void selectFirstMatchedRecord(String NPI) {
		try {

			By selectfirstRecord = getDynamicElement(collabNPI, NPI);
			scrollToElement(selectfirstRecord);
			click(selectfirstRecord);
			Log.info("Selected first record of mutiple record visible");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select matched records-" + "Error - " + e.getMessage());
		}
	}

	// Anand P
	public void clearCollaboratingMDNameInfo(String NPI) {
		try {
			By eleFirstNameCollaborationMDInput = getDynamicElement(strInputBoxesXpath, "First Name");
			waitAndVerifyElement(eleFirstNameCollaborationMDInput);

			scrollToElement(eleFirstNameCollaborationMDInput);
			clearText(eleFirstNameCollaborationMDInput);

			By eleLastCollaborationMDInput = getDynamicElement(strInputBoxesXpath, "Last Name");
			waitAndVerifyElement(eleLastCollaborationMDInput);
			clearText(eleLastCollaborationMDInput);

			By eleNPIFieldInput = getDynamicElement(strInputBoxesXpath, "NPI #");
			waitAndVerifyElement(eleNPIFieldInput);
			verifyAndEnterInfoInputField(eleNPIFieldInput, NPI, NursePractitionerNPI);
			waitFor(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to clear MD details" + ". Error - " + e.getMessage());

		}

	}

	// Anand P
	public void validateErrorMsg() {
		try {
			String expectedError = "HCP Consent cannot be captured unless an existing HCP is selected or a new HCP created with all details populated in previous step";
			By errorMsg = By.xpath(
					"//*[text()='HCP Consent cannot be captured unless an existing HCP is selected or a new HCP created with all details populated in previous step']");
			waitAndVerifyElement(errorMsg);
			scrollToElement(errorMsg);
			highLightElement(errorMsg);
			String actualError = getText(errorMsg);
			Assert.assertEquals(expectedError, actualError, "Error message validated successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate error message" + ". Error - " + e.getMessage());

		}

	}

	// Anand P
	public void verifySourceColumn() {
		try {

			boolean nameFound = false;

			By colmnSource = By.xpath("//th//*[text()='Source System']");
			scrollToElement(colmnSource);
			highLightElement(colmnSource);
			Log.info("Verified source column is visible");

			By eleRows = By.xpath("//th//*[text()='Source System']//ancestor::thead//following-sibling::tbody//tr");
			List<WebElement> rows = getWebDriver().findElements(eleRows);
			scrollToElement(eleRows);
			for (WebElement row : rows) {
				WebElement sourceName = row.findElement(By.xpath(".//td[5]"));
				String ele = sourceName.getText();
				if (ele.contains("ICARE+") || ele.contains("RCM")) {
					nameFound = true;
					break;
				}
			}

			Log.info("Veried source column having data as 'ICARE+' and 'RCM");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify source column-" + "Error - " + e.getMessage());
		}
	}

	// Anand P
	public void clearPrescriberName() {

		try {

			JavascriptExecutor js = (JavascriptExecutor) getWebDriver();

			By prescriberFNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Prescriber First Name");
			WebElement ele1 = getWebDriver().findElement(prescriberFNameElementTextBox);
			waitAndVerifyElement(prescriberFNameElementTextBox);
			scrollToElement(prescriberFNameElementTextBox);
			clearText(prescriberFNameElementTextBox);
			js.executeScript("arguments[0].setAttribute('autocomplete','off');", ele1);

			By prescriberLNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Prescriber Last Name");
			WebElement ele2 = getWebDriver().findElement(prescriberLNameElementTextBox);
			waitAndVerifyElement(prescriberLNameElementTextBox);
			scrollToElement(prescriberLNameElementTextBox);
			clearText(prescriberLNameElementTextBox);
			js.executeScript("arguments[0].setAttribute('autocomplete','off');", ele2);
			waitFor(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Prescriber clear failed" + "Error - " + e.getMessage());
		}
	}

	// Anand P
	public void enterIncorrectNPI() {

		try {
			Log.info("Enter Incorrect NPI message");
			By eleNPIFieldInput = getDynamicElement(strInputBoxesXpath, "NPI #");
			waitAndVerifyElement(eleNPIFieldInput);
			scrollToElement(eleNPIFieldInput);
			inputText(eleNPIFieldInput, "12345678901");
			Log.info("Entered 11 digit NPI");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select matched records-" + "Error - " + e.getMessage());
		}

	}

	// Anand P
	public void validateNPIError() {

		try {
			LoggingInfo("Checking error message");
			By error = By.xpath("//div[text()='NPI # should contain only 10 digits']");
			waitAndVerifyElement(error);
			highLightElement(error);
			Log.info("Successfully verified error message");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate error message-" + "Error - " + e.getMessage());
		}

	}
}
