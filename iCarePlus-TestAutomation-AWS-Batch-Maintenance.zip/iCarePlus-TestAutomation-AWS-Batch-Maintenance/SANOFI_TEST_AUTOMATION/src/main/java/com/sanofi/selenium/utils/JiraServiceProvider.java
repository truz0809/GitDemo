package com.sanofi.selenium.utils;

import static io.restassured.RestAssured.given;

import com.sanofi.selenium.apiutils.Payload;
import com.sanofi.selenium.constants.APIConstants;

import net.rcarz.jiraclient.BasicCredentials;
import net.rcarz.jiraclient.Field;
import net.rcarz.jiraclient.Issue;
import net.rcarz.jiraclient.Issue.FluentCreate;
import net.rcarz.jiraclient.JiraClient;
import net.rcarz.jiraclient.JiraException;

public class JiraServiceProvider {

	private JiraClient jira;
	private String project;
	private String JiraUrl;

	public JiraServiceProvider(String JiraUrl, String username, String password, String project) {

		this.JiraUrl = JiraUrl;
		BasicCredentials creds = new BasicCredentials(username, password);
		jira = new JiraClient(JiraUrl, creds);
		this.project = project;
	}

	public void updateJiraIssue(String labelVal, String keyVal) {

		given().header("Content-Type", "application/json")
				.header("Authorization", "Basic dW5uaXRoYW4ua3J1dGlAc2Fub2ZpLmNvbTppZlJNdTRKQmpHYUFEMFFFQkZVdjlGNkQ=")
				.body("{\r\n" + "\"fields\":{\r\n" + "\"labels\":[" + "\"" + labelVal + "\"]\r\n}\r\n}").when()
				.put("https://sanofi.atlassian.net/rest/api/3/issue/" + keyVal + "").then().assertThat()
				.statusCode(204);
	}

	public void createJiraIssue(String issueType, String summary, String description, String reporterName) {
		/* Create a new issue. */
		try {
			FluentCreate newIssueFluentCreate = jira.createIssue(project, issueType);
			// Add the summary
			newIssueFluentCreate.field(Field.SUMMARY, summary);
			// Add the description
			newIssueFluentCreate.field(Field.DESCRIPTION, description);
			// Add the reporter
			newIssueFluentCreate.field(Field.REPORTER, reporterName);
			// create the issue in the jira server
			Issue newIssue = newIssueFluentCreate.execute();

			System.out.println("New issue created. Jira ID : " + newIssue);

		} catch (JiraException e) {
			e.printStackTrace();
		}
	}
}
