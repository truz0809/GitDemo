package com.sanofi.selenium.core;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URL;
import java.time.Duration;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.io.File;
import java.io.FileInputStream;
import org.apache.commons.io.FileUtils;
import org.apache.poi.util.IOUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.sanofi.selenium.apiutils.JiraXrayIntegrationAPI;
import com.sanofi.selenium.apiutils.ZipDirectory;
import com.sanofi.selenium.constants.APIConstants;
import com.sanofi.selenium.constants.CareProgramEnrolleeConstant;
import com.sanofi.selenium.constants.CommonConstants;
import com.sanofi.selenium.constants.DocumentManagementConstant;
import com.sanofi.selenium.constants.ExcelTestDataConstants;
import com.sanofi.selenium.constants.EnrollmentConstants;
import com.sanofi.selenium.constants.TestData;
import com.sanofi.selenium.constants.TriageConstant;
import com.sanofi.selenium.constants.UpdateExcelDataConstants;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.FreeGoodsPage;
import com.sanofi.selenium.pages.HealthcareAccountSearch;
import com.sanofi.selenium.pages.ConsentExpiryDate;
import com.sanofi.selenium.pages.CopayFlow;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.HomePortal;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.LoginPage;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.Listeners;
import com.sanofi.selenium.utils.Log;
import com.sanofi.selenium.utils.ReadExcel;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AuthorizationFormConsentPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.CareTeamAssignment;
import com.sanofi.selenium.pages.ConsentCaptureDate;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PAPPage;
import com.sanofi.selenium.pages.PSQAPage;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;

public abstract class BaseTest extends User
		implements CommonConstants, APIConstants, ExcelTestDataConstants, EnrollmentConstants, UpdateExcelDataConstants,
		TestData, CareProgramEnrolleeConstant, DocumentManagementConstant {

	protected static String applicationUrl, headless, executionOn;
	public static ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();
	protected String screeningNum = "Automation_" + generateRandomString(6);
	protected String randomizationNum = "AutoRandomNum_" + generateRandomString(4);
	public static Object CurrentPage;
	public String Filepath;
	public String sheetName;
	ReadExcel excelObject = new ReadExcel(sheetName);
	protected static ThreadLocal<String> filePath = new ThreadLocal<>();
	// page object initialization
	protected LoginPage loginPage;
	protected HomePortal homeportalPage;
	protected static ExtentHtmlReporter htmlReporter;
	protected static ExtentReports report;
	protected static ExtentTest test;
	protected static ExtentReports extent;
	protected static ThreadLocal<ExtentTest> extentTest;
	protected Utility_Function utilityPage;
	protected static String payerName;
	protected static String hcoName;
	protected static String phyisicanName;
	protected static String consentedContact1, consentedContact2;
	protected static String zipCode;
	protected static String zipCodeSCA1;
	protected static String zipCodeSCA2;
	protected static String zipCodeSCA3;
	protected static String zipCodeSCA4;
	protected static String zipCodeSCA5;
	protected static String zipCodeSCA6;
	protected static String hcoZipCode;
	protected static String psbsid, psbsid3;
	protected static String psbsid1;
	protected static String erpAccountNumber;
	protected static String zipcodeAT07Region1;
	protected static String zipcodeAT07Region2;
	protected static String zipcodeAT07Region3;
	static String jiraResultUpload;
	protected static String commentForJira, accessToken;
	protected static String EnvName;
	// protected static UploadDocument uploadDocs;

	// ******Page object initialization for ICare+
	protected static ReadExcel readExcel;
	protected static UpdatePDF updatepdf;
	protected static DocumentPage documentsPage;
	protected static ConsentExpiryDate consentExpiryDate;
	protected static InsuranceInformation insuranceinfo;
	protected static DiagnosisInfo diagnosisinformation;
	protected static PrescriptionInformation prescriptioninformation;
	public static ExcelTestDataConstants exceltestdataconstants;
	protected static PatientSearchPage patientSearch;
	protected static PatientInformationAndAuthorizationPage patientInfo;
	public static PrescriberInformationPage prescriberInformationPage;
	protected static GenerateTestData generateTestData;
	protected static FormConfirmation formConfirmation;
	protected static AccountObject accountObject;
	protected static ExcelDataUpdate excelDataUpdate;
	protected static ConsentCaptureDate consentCaptureDate;
	protected static AuthorizationFormConsentPage authorizationConsentPage;
	protected static CareProgramEnrolleePage careProgram;
	protected static MissingInformatioPage missingInformatioPage;
	protected static CopayFlow copayFlow;
	protected static QuickStartPage quickStartPage;
	protected static IAPPage iapPage;
	protected static TriagePage triagePage;
	protected static BenefitVerificationPage bvPage;
	protected static PAAndAppealsPage paAppealsPage;
	protected static AssessmentTasksPage assessmentTasksPage;
	protected static PAPPage papPage;
	protected static DocumentManagementPage docMgmt;
	protected static DUPIXENTMyWayPortal dupixentPortal;
	protected static UploadDocument uploadDocs;
	protected static CareTeamAssignment careTeamAsgn;
	protected static FreeGoodsPage freeGoods;
	protected static HealthcareAccountSearch hcAccountSearch;
	protected static GenerateEnrollmentTestData generateEFTestData;
	protected static PSQAPage psqaPage;

	// ************************* Please dont touch and duplicate below JIRA
	// Variables*****************************************************//
	public static String executionJIRAKey, jiraAccessTokenForAuth;
	// **********************************************************************************************************************************//

	public static ThreadLocal<String> currentThreadMethod = new ThreadLocal<String>();
	String FilepathForJiraKey = System.getProperty("user.dir") + "/TestData/" + "JIRAKey.xlsx";
	public HashMap<String, String> testTestNGResultHashMapata = new HashMap<>();
	public JiraXrayIntegrationAPI jiraAPI = new JiraXrayIntegrationAPI();
	public ZipDirectory zipDir = new ZipDirectory();
	ChromeOptions options = new ChromeOptions();
	EdgeOptions option = new EdgeOptions();

	@BeforeSuite(alwaysRun = true)
	public void before() throws Exception {
		headless = Configuration.readApplicationFile("headless");
		applicationUrl = Configuration.readApplicationFile("url");
		executionOn = Configuration.readApplicationFile("executionMode");
		jiraResultUpload = Configuration.readApplicationFile("jiraResultUpload");
		executionJIRAKey = Configuration.readApplicationFile("executionKey");
		configureUser();
		extent = getReportInstance();
		extentTest = new ThreadLocal<ExtentTest>();
		payerName = Configuration.readApplicationFile("PayerName");
		hcoName = Configuration.readApplicationFile("HcoName");
		phyisicanName = Configuration.readApplicationFile("PhyisicanName");
		consentedContact1 = Configuration.readApplicationFile("ConsentedContact1");
		consentedContact2 = Configuration.readApplicationFile("ConsentedContact2");
		zipCode = Configuration.readApplicationFile("Zipcode");
		zipCodeSCA1 = Configuration.readApplicationFile("ATZipcode1");
		zipCodeSCA2 = Configuration.readApplicationFile("ATZipcode2");
		zipCodeSCA3 = Configuration.readApplicationFile("ATZipcode3");
		zipCodeSCA4 = Configuration.readApplicationFile("ATZipcode4");
		zipCodeSCA5 = Configuration.readApplicationFile("ATZipcode5");
		zipCodeSCA6 = Configuration.readApplicationFile("ATZipcode6");
		zipcodeAT07Region1 = Configuration.readApplicationFile("AT07zipcodeRegion1");
		zipcodeAT07Region2 = Configuration.readApplicationFile("AT07zipcodeRegion2");
		zipcodeAT07Region3 = Configuration.readApplicationFile("AT07zipcodeRegion3");
		hcoZipCode = Configuration.readApplicationFile("HCOZipCode");
		psbsid = Configuration.readApplicationFile("psbsValue");
		psbsid1 = Configuration.readApplicationFile("psbsValue1");
		psbsid3 = Configuration.readApplicationFile("psbsValue3");
		erpAccountNumber = Configuration.readApplicationFile("ERPNumber");
		if (executionOn.equals("Remote")) {
			System.setProperty("java.net.useSystemProxies", "true");
			mCK_Endpoint_URL = mCK_Endpoint_URL.replace(Configuration.readApplicationFile("Local_APIPort"),
					Configuration.readApplicationFile("AWS_APIPort"));
			assistRx_Endpoint = assistRx_Endpoint.replace(Configuration.readApplicationFile("Local_APIPort"),
					Configuration.readApplicationFile("AWS_APIPort"));
			annexusURI = annexusURI.replace(Configuration.readApplicationFile("Local_APIPort"),
					Configuration.readApplicationFile("AWS_APIPort"));
			marketing_Endpoint = marketing_Endpoint.replace(Configuration.readApplicationFile("Local_APIPort"),
					Configuration.readApplicationFile("AWS_APIPort"));
			trialCardURI = trialCardURI.replace(Configuration.readApplicationFile("Local_APIPort"),
					Configuration.readApplicationFile("AWS_APIPort"));
			mCK_Token_URL = mCK_Token_URL.replace(Configuration.readApplicationFile("Local_APIPort"),
					Configuration.readApplicationFile("AWS_APIPort"));

			commentForJira = "Executed Through AWS with Automation Evidences";
			System.out.println("Test reached to remote");

		}
		if (jiraResultUpload.equals("True")) {
			jiraAccessTokenForAuth = jiraAPI.getXrayAutheticationToken();
			System.out.println("Reached to jira token and token is " + jiraAccessTokenForAuth);
		}
	}

	/*
	 *//**
		 * Function: get initialize Chrome Driver
		 *
		 * @author Dipali Yadav
		 * @return
		 */

	@SuppressWarnings("static-access")
	@BeforeMethod(alwaysRun = true)
	public void initializeDriver(Method method) throws Exception {
	    String nodeURL = "http://10.25.186.107:4447/wd/hub";
	    int maxRetries = 3;
	    int retryCount = 0;
	    
	    test = extent.createTest(method.getName(), this.getClass().getName());
	    extentTest.set(test);
	    currentThreadMethod.set(method.getName());
	    test.assignCategory(this.getClass().getSimpleName());
	    
	    // Retry logic wrapper around existing configuration
	    while (retryCount < maxRetries) {
	        try {
	            if (executionOn.equals("Local")) {
	                System.setProperty("webdriver.edge.driver", "./msedgedriver.exe");
	            }

	            if (headless.equals("True")) {
	                options.addArguments("--disable-extensions");
	                options.addArguments("--proxy-server='direct://'");
	                options.addArguments("--proxy-bypass-list=*");
	                options.addArguments("--start-maximized");
	                options.addArguments("--disable-notifications");
	                options.addArguments("--headless");
	                options.addArguments("--disable-gpu");
	                options.addArguments("--disable-dev-shm-usage");
	                options.addArguments("--no-sandbox");
	                options.addArguments("--ignore-certificate-errors");
	                options.addArguments("--disable-notifications");
	                options.addArguments("--remote-allow-origins=*");
	                // Additional stability arguments for headless mode
	                options.addArguments("--disable-crash-reporter");
	                options.addArguments("--disable-oopr-debug-crash-dump");
	                options.addArguments("--no-crash-upload");
	                options.addArguments("--memory-pressure-off");
	            } else {
	                options.addArguments("--no-sandbox");
	                options.addArguments("--ignore-certificate-errors");
	                options.addArguments("--disable-notifications");
	                options.addArguments("--remote-allow-origins=*");
	                // Additional stability arguments for non-headless mode
	                options.addArguments("--disable-crash-reporter");
	                options.addArguments("--disable-oopr-debug-crash-dump");
	                options.addArguments("--no-crash-upload");
	                /*********
	                * Uncomment Below code for running docker in local Machine
	                *************************/
	                // options.addArguments("--disable-dev-shm-usage");
	            }
	            
	            Map<String, Object> prefs = new HashMap<String, Object>();
	            // Use File.separator as it will work on any OS
	            if (executionOn.equals("Remote")) {
	                prefs.put("download.default_directory", "/home/seluser/Downloads/Documents");
	            } else {
	                prefs.put("download.default_directory",
	                    System.getProperty("user.dir") + File.separator + "Documents" + File.separator);
	            }
	            prefs.put("download.prompt_for_download", Boolean.valueOf(false));
	            prefs.put("plugins.always_open_pdf_externally", Boolean.valueOf(true));
	            prefs.put("safebrowsing_for_trusted_sources_enabled", Boolean.valueOf(false));
	            options.setExperimentalOption("prefs", prefs);
	            
	            if (executionOn.equals("Remote")) {
	                DesiredCapabilities capability = new DesiredCapabilities();
	                capability.setCapability("name", "Downloading File");
	                capability.setBrowserName("chrome");
	                capability.setPlatform(Platform.LINUX);
	                // Enhanced capabilities for stability
	                capability.setCapability("se:sessionTimeout", Duration.ofMinutes(15));
	                capability.setCapability("se:idleTimeout", Duration.ofMinutes(8));
	                capability.setCapability("se:recordVideo", false);
	                capability.setCapability("se:recordLogs", false);
	                options.merge(capability);
	                
	                RemoteWebDriver remoteDriver = new RemoteWebDriver((new URI(nodeURL)).toURL(), options);
	                remoteDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	                ((RemoteWebDriver) remoteDriver).setFileDetector(new LocalFileDetector());
	                driver.set(remoteDriver);
	                
	                // Verify driver is responsive
	                try {
	                    WebDriverWait verificationWait = new WebDriverWait(remoteDriver, Duration.ofSeconds(15));
	                    verificationWait.until(ExpectedConditions.jsReturnsValue("return document.readyState"));
	                    System.out.println("Driver verification successful. Session ID: " + remoteDriver.getSessionId());
	                } catch (Exception e) {
	                    throw new RuntimeException("Driver responsiveness check failed", e);
	                }
	            }
	            
	            if (executionOn.equals("Local")) {
	                setDriver(new EdgeDriver(option));
	                commentForJira = "Executed Through Local Machine with Automation Evidences";

	                /*********
	                * Uncomment Below code for running docker in local Machine
	                *************************/
	                /*
	                * String urlNode = "http://localhost:4444/wd/hub"; commentForJira =
	                * "Executed Through Local Machine with Automation Evidences";
	                * DesiredCapabilities capability = new DesiredCapabilities();
	                * capability.setCapability("name", "Downloading File");
	                * capability.setBrowserName("chrome"); capability.setPlatform(Platform.LINUX);
	                * options.merge(capability); driver.set(new RemoteWebDriver(new URL(urlNode),
	                * options)); ((RemoteWebDriver) getWebDriver()).setFileDetector(new
	                * LocalFileDetector());
	                */
	            }
	            
	            getWebDriver().manage().deleteAllCookies();
	            // Enhanced timeout for better performance
	            getWebDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(25));
	            getWebDriver().manage().timeouts().pageLoadTimeout(Duration.ofSeconds(90));
	            getWebDriver().manage().timeouts().scriptTimeout(Duration.ofSeconds(45));
	            
	            getWebDriver().navigate().to(applicationUrl);
	            
	            // Wait for page to load completely with enhanced checks
	            try {
	            	WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(45));
	            	wait.until(ExpectedConditions.jsReturnsValue("return document.readyState === 'complete'"));
	            	// Additional stability check
	            	Thread.sleep(2000);
	            } catch (Exception e) {
	                System.out.println("Page load verification failed, continuing anyway: " + e.getMessage());
	            }
	            
	            getWebDriver().manage().window().maximize();
	            loginPage = GetInstance(LoginPage.class);
	            
	      
	            System.out.println("Driver initialization successful on attempt " + (retryCount + 1));
	            break;
	            
	        } catch (Exception e) {
	            retryCount++;
	            System.err.println("Driver initialization attempt " + retryCount + " failed: " + e.getMessage());
	            
	            // Clean up any existing driver instance
	            try {
	                if (driver.get() != null) {
	                    try {
	                        driver.get().quit();
	                    } catch (Exception quitEx) {
	                        System.err.println("Error during driver quit: " + quitEx.getMessage());
	                    }
	                    driver.remove();
	                }
	            } catch (Exception cleanupEx) {
	                System.err.println("Error during cleanup: " + cleanupEx.getMessage());
	            }
	            
	            if (retryCount >= maxRetries) {
	                System.err.println("Failed to initialize driver after " + maxRetries + " attempts");
	                throw new RuntimeException("Driver initialization failed after " + maxRetries + " attempts", e);
	            }
	            
	            try {
	                long delay = (3000 * retryCount) + (long)(Math.random() * 1000);
	                Thread.sleep(delay);
	            } catch (InterruptedException ie) {
	                Thread.currentThread().interrupt();
	            }
	            System.out.println("Retrying driver initialization... Attempt " + (retryCount + 1) + "/" + maxRetries);
	        }
	    }
	}

	/**
	 * Function: Get page class instances.
	 *
	 * @param Page class.
	 * @return
	 */
	public static <TPage> TPage GetInstance(Class<TPage> page) {
		return PageFactory.initElements(getWebDriver(), page);
	}

	/**
	 * Function: Get driver object
	 *
	 *
	 * @return driver object
	 */
	public static WebDriver getWebDriver() {
		return driver.get();
	}

	public static void setDriver(WebDriver driverRef) {
		driver.set(driverRef);
	}

	/**
	 * Function: Get Currently executed method
	 * 
	 * @author pratiksha dixit
	 * @return method name
	 */
	public static String getCurrentMethodName() {
		return currentThreadMethod.get();
	}

	/**
	 * Generate Random Numeric String of length
	 */
	public static String GenerateRandomNumber(int charLength) {
		return String.valueOf(charLength < 1 ? 0
				: new Random().nextInt((9 * (int) Math.pow(10, charLength - 1)) - 1)
						+ (int) Math.pow(10, charLength - 1));
	}

	/**
	 * Function: Get random string
	 *
	 * @param lettersNum
	 * @return
	 */
	public static String generateRandomString(int lettersNum) {
		StringBuilder finalString = new StringBuilder();
		int numberOfLetters = 25;
		long randomNumber;
		for (int i = 0; i < lettersNum; i++) {
			char letter = 97;
			randomNumber = Math.round(Math.random() * numberOfLetters);
			letter += randomNumber;
			finalString.append(String.valueOf(letter));
		}
		return finalString.toString();
	}

	/**
	 * Function: Get random integer
	 *
	 * @param aStart
	 * @param aEnd
	 * @return
	 */
	public int getRandomInteger(final long aStart, final long aEnd) {
		final Random aRandom = new Random();
		if (aStart > aEnd) {
			throw new IllegalArgumentException("Start cannot exceed End.");
		}
		// get the range, casting to long to avoid overflow problems
		final long range = aEnd - aStart + 1;
		// compute a fraction of the range, 0 <= frac < range
		final long fraction = (long) (range * aRandom.nextDouble());
		final int randomNumber = (int) (fraction + aStart);
		return randomNumber;
	}

	/**
	 * Function: for capturing screenshot
	 *
	 * @author Dipali Yadav
	 * @param testCaseName
	 * @return errflpath
	 */
	public static String captureScreenShot(String failureScreenshot) throws IOException {
		String errflpath = "";
		try {

			String screenShotmethodName = getCurrentMethodName();
			File scrFile = ((TakesScreenshot) getWebDriver()).getScreenshotAs(OutputType.FILE);
			if (failureScreenshot.equalsIgnoreCase("Failure")) {
				File Dest = new File("../Screenshots/" + screenShotmethodName + "/FailureScreenShots/"
						+ System.currentTimeMillis() + ".png");
				File Dest1 = new File("Screenshots/" + screenShotmethodName + "/FailureScreenShots/"
						+ System.currentTimeMillis() + ".png");
				errflpath = Dest.toString();
				FileUtils.copyFile(scrFile, Dest1.getAbsoluteFile());
			} else if (failureScreenshot.equalsIgnoreCase("Passed")) {
				File Dest = new File("../Screenshots/" + screenShotmethodName + "/PassedScreenShots/"
						+ System.currentTimeMillis() + ".png");
				File Dest1 = new File("Screenshots/" + screenShotmethodName + "/PassedScreenShots/"
						+ System.currentTimeMillis() + ".png");
				errflpath = Dest.toString();
				FileUtils.copyFile(scrFile, Dest1.getAbsoluteFile());
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Screenshot taking activity failed. Error - " + e.getMessage());
		}

		return errflpath;
	}

	/**
	 * Function: for capturing screenshot in BASE64
	 *
	 * @author Pratiksha Dixit
	 * @param testCaseName
	 * @return errflpath
	 */
	public static String captureScreenShotWithBase64() throws IOException {
		byte[] imageBytes = null;
		try {
			String screenShotmethodName = getCurrentMethodName();
			File scrFile = ((TakesScreenshot) getWebDriver()).getScreenshotAs(OutputType.FILE);
			String destScreenshots = System.getProperty("user.dir") + "/Screenshots/" + screenShotmethodName + "/"
					+ System.currentTimeMillis() + ".png";
			FileUtils.copyFile(scrFile, new File(destScreenshots));
			imageBytes = IOUtils.toByteArray(new FileInputStream(destScreenshots));
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Screenshot taking activity failed. Error - " + e.getMessage());
		}
		return Base64.getEncoder().encodeToString(imageBytes);
	}

	@AfterMethod(alwaysRun = true)
	public void quit(ITestResult result) throws Exception {
		if (result.getStatus() == ITestResult.FAILURE) {
			extentTest.get().fail(result.getThrowable());
			testTestNGResultHashMapata.put(result.getName(), "Failed");

			// *******************************************************************************************************//
			// * Please dont touch and modify below Code for uploading result in JIRA XRAY
			// Execution if test case failed
			// *******************************************************************************************************//
			if (jiraResultUpload.equals("True")) {
				String jiraKeyFailed = ReadExcel.readJiraKeysBasedOnMethodName(FilepathForJiraKey, result.getName());
				extent.flush();
				if (getWebDriver() != null) {
					getWebDriver().quit();
					driver.remove();
				}
				try {
					zipDir.ZipDirs("./Evidences", "./" + result.getName() + ".zip", true, f -> true, result.getName(),
							"./reports", "./Screenshots/" + result.getName() + "/FailureScreenShots");

					jiraAPI.updateAutomatedResultInXrayExecutionCycleViaAPI(jiraAccessTokenForAuth, executionJIRAKey,
							"", jiraKeyFailed, constFailedStatus, "./Evidences/" + result.getName() + ".zip",
							commentForJira);

					Log.info("Execution Result Uploaded For Failed Scenario Sucessfully");
					System.out.println("Execution Result Uploaded For Failed Scenario Sucessfully");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		} else if (result.getStatus() == ITestResult.SKIP) {
			testTestNGResultHashMapata.put(result.getName(), "Skipped");
			extentTest.get().skip(result.getThrowable());
		} else {
			testTestNGResultHashMapata.put(result.getName(), "Passed");
			extentTest.get().pass("Execution Completed");
			// *******************************************************************************************************//
			// * Please dont touch and modify below Code for uploading result in JIRA XRAY
			// Execution if test case Passed
			// *******************************************************************************************************//
			if (jiraResultUpload.equals("True")) {
				String jiraKeyPassed = ReadExcel.readJiraKeysBasedOnMethodName(FilepathForJiraKey, result.getName());
				extent.flush();
				   if (getWebDriver() != null) {
				        getWebDriver().quit();
				        driver.remove();
				    }
				try {
					jiraAPI.updateAutomatedResultInXrayExecutionCycleViaAPI(jiraAccessTokenForAuth, executionJIRAKey,
							"", jiraKeyPassed, constPassedStatus, "reports/PassedSanofiAutomation.html",
							commentForJira);
					Log.info("Execution Result Uploaded For Passed Scenario Sucessfully");
					System.out.println("Execution Result Uploaded For Pass Case Scenario Sucessfully");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}

		if (jiraResultUpload.equals("False")) {
			extent.flush();
			// Close all the browser instances
			   if (getWebDriver() != null) {
			        getWebDriver().quit();
			        driver.remove();
			    }
			System.out.println("Reached to End");
		}
		//Excel cleanup
		ReadExcel.cleanUpExcelCopy();
		//pdf cleanup
		 updatepdf.cleanupThreadLocals();
	}

	@AfterSuite(alwaysRun = true)
	public void postSuite() throws Exception {
		excelObject.updateExecutionResultInTestNgExcelData(testTestNGResultHashMapata);
	}

	/**
	 * Function: get Extent Report instance
	 *
	 * @author Dipali Yadav
	 * @param sheet index no
	 * @return
	 */
	public static ExtentReports getReportInstance() {
		if (report == null) {
			if (EnvName == null) {
				EnvName = Configuration.readApplicationFile("EnvName");
			}
			String Reportname = EnvName + "-" + "PassedSanofiAutomation.html";
			ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(
					System.getProperty("user.dir") + "/reports/" + Reportname);
			report = new ExtentReports();
			report.attachReporter(htmlReporter);
			report.setSystemInfo("OS", "Windows 10");
			report.setSystemInfo("Browser", "Chrome");
			report.setSystemInfo("Tester", "Sanofi Automation");
			htmlReporter.config().setDocumentTitle("Automation Result");
			htmlReporter.config().setReportName("UI Test Execution Report");
			htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
			htmlReporter.config().setTimeStampFormat("MM/dd/yyyy HH:mm:ss");
		}
		return report;
	}

	public static void Info(String LogMessage) {
		ThreadLocal<ExtentTest> extentTest = new ThreadLocal<ExtentTest>();
		extentTest.set(test);
		if (report == null) {
			report = getReportInstance();
		}
		extentTest.get().log(Status.INFO, "Testcase Execution started..."); // report.get().log(Status.INFO,"Testcase
		// Execution started..."
	}

	public static ExtentTest StartCreateTest(String methodName) {
		test = report.createTest(methodName);
		return test;
	}

	public static void FlushReport() {
		report.flush();
	}

	public void Logger(String message) {
		Listeners.infostep(message);
		Log.info(message);
	}

	public void refresh() {
		getWebDriver().navigate().refresh();
	//	getWebDriver().findElement(null).sendKeys(Keys.);
//	    Actions actions = new Actions(getWebDriver());
//        actions.keyDown(Keys.CONTROL)
//               .sendKeys(Keys.F5)
//               .keyUp(Keys.CONTROL)
//               .perform();

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void navigation_PreviousePage() {
		getWebDriver().navigate().back();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * Delete Files present in directory
	 * 
	 * @author Pratiksha Dixit
	 */
	void purgeDirectoryFiles(File dir) {

		for (File file : dir.listFiles()) {
			if (file.isDirectory())
				purgeDirectoryFiles(file);
			if (!(file.getName().equalsIgnoreCase("test.txt"))) {
				file.delete();
			}
		}
	}

	public String getCurrentPageURL() {
		String url = getWebDriver().getCurrentUrl();
		try {
			Thread.sleep(3000);
		} catch (Exception e) {

			e.printStackTrace();
		}
		return url;
	}

	public void navigateToUrl(String url) {
		getWebDriver().navigate().to(url);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public void navigateToURL(String url) {
		getWebDriver().navigate().to(url);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	  // Getter method
    protected String getFilePath() {
        return filePath.get();
    }
    
    protected void setFilePath(String path) {
        filePath.set(path);
    }
    
    public void cleanUpFilePath() {
        filePath.remove();
    }

}