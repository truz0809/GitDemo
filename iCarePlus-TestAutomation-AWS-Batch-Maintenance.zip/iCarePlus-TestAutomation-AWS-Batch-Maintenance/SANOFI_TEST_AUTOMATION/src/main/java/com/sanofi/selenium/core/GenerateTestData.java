package com.sanofi.selenium.core;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import java.io.FileInputStream;
import java.io.File;

import com.sanofi.selenium.constants.TestData;

public class GenerateTestData extends Utility_Function implements TestData {
	public GenerateTestData(WebDriver driver) {
		super(driver);
	}

	private static final Object excelWriteLock = new Object();

	String testDataFilePath = System.getProperty("user.dir") + "/TestData/";
	String testDataFileName = "EnrollmentFormTestData.xlsx";

	public void generateEnrollmentTestData(String functionality) {
		synchronized (excelWriteLock) {
			String[] firstNames = TestData.firstNames;
			String[] lastNames = TestData.lastNames;
			String[] domains = TestData.domains;
			String[] genders = TestData.genders;
			String[] languages = TestData.languages;
			String[] address = TestData.address;
			String[] cityNames = TestData.cityNames;
			String[] States = TestData.statesAndTerritories;
			String[] checkboxes = TestData.checkboxes;
			String[] legalRepfirstNames = TestData.legalRepfirstNames;
			String[] legalReplastNames = TestData.legalReplastNames;
			String[] relationship = TestData.relationship;
			String[] relationshipToPatient = TestData.relationshipToPatient;
			String[] specialties = TestData.preSpecialties;
			String[] facilityNames = TestData.facilityNames;
			String[] officeFirstNames = TestData.officeFirstNames;
			String[] officeLastNames = TestData.officeLastNames;
			String[] dupixentOptions = TestData.dupixentOptions;
			String[] drugAllergies = TestData.drugAllergies;
			String[] collaboratingMDFirstNames = TestData.collaboratingMDFirstNames;

			String testDataFilePath = System.getProperty("user.dir") + "/TestData/";
			String testDataFileName = "EnrollmentFormTestData.xlsx";

			Map<String, String> sheetNameMap = Map.ofEntries(Map.entry("Enrollment", "PDF_Data"),
					Map.entry("Consent Management", "Consent_Management"),
					Map.entry("MissingInformation", "MI_Management"), Map.entry("Free Goods", "Free_Goods"),
					Map.entry("DocumentManagement", "Doc_MGMNT"), Map.entry("Fax", "Fax"),
					Map.entry("AdminSetup", "AdminSetup"), Map.entry("BenefitVerification", "BenefitVerification"),
					Map.entry("CareProgram", "CareProgram"), Map.entry("CopayWorkflow", "CopayWorkflow"),
					Map.entry("DocDropPortal", "DocDropPortal"), Map.entry("PARenewAppeal", "PARenewAppeal"),
					Map.entry("PatientEducation", "PatientEducation"),
					Map.entry("PatientEnrollment", "PatientEnrollment"),
					Map.entry("ProgramAndCareTeamMGMNT", "ProgramAndCareTeamMGMNT"),
					Map.entry("ReportsDashboard", "ReportsDashboard"), Map.entry("RGNAlerts", "RGNAlerts"),
					Map.entry("RGNAM", "RGNAM"), Map.entry("RGNPhone", "RGNPhone"), Map.entry("RGNTTP", "RGNTTP"),
					Map.entry("SecurityAccessMgmnt", "SecurityAccessMgmnt"),
					Map.entry("SpecialtyPharmacyDataDispenses", "SpecialtyPharmacyDataDispenses"),
					Map.entry("TriageToPharmacy", "TriageToPharmacy"),
					Map.entry("BenefitsVerificationWorkflow", "BenefitsVerificationWorkflow"),
					Map.entry("IAPWorkflow", "IAPWorkflow"),
					Map.entry("MissingInformationManagement", "MissingInformationManagement"),
					Map.entry("PAPWorkflow", "PAPWorkflow"),
					Map.entry("PriorAuthorizationWorkflow", "PriorAuthorizationWorkflow"),
					Map.entry("QuickStartWorkFlow", "QuickStartWorkFlow"));

			String sheetToCreate = sheetNameMap.get(functionality);
			if (sheetToCreate == null) {
				System.out.println("Unsupported functionality: " + functionality);
				return;
			}

			try (FileInputStream fileInputStream = new FileInputStream(new File(testDataFilePath + testDataFileName));
					Workbook workbook = new XSSFWorkbook(fileInputStream)) {

				// Remove existing sheet if present
				Sheet sheet = workbook.getSheet(sheetToCreate);
				if (sheet != null) {
					workbook.removeSheetAt(workbook.getSheetIndex(sheet));
				}
				sheet = workbook.createSheet(sheetToCreate);

				Row headerRow = sheet.createRow(0);
				for (int i = 0; i < TestData.headers.length; i++) {
					headerRow.createCell(i).setCellValue(TestData.headers[i]);
				}
				// Generate test data
				Random random = new Random();
				int numRows = 40; // Number of rows you want to generate
				for (int rowNum = 1; rowNum <= numRows; rowNum++) {
					Row row = sheet.createRow(rowNum);
					row.createCell(0).setCellValue("TC" + rowNum); // TestCaseID
					int randomNum = random.nextInt(999);
					String firstName = firstNames[random.nextInt(firstNames.length)];
					String midName = firstNames[random.nextInt(firstNames.length)];
					String lastName = lastNames[random.nextInt(lastNames.length)];

					String fullName = "Automation" + firstName + " " + midName + " " + lastName;

					row.createCell(1).setCellValue(fullName); // PatientName

					// Generating a random DOB (date of birth)
					int year = 1950 + random.nextInt(50); // Random year between 1950 and 2000
					int month = 1 + random.nextInt(12);
					int day = 1 + random.nextInt(28);
					String dob = String.format("%02d-%02d-%02d", month, day, year);
					row.createCell(2).setCellValue(dob); // PatientDOB

					// Generating a random phone number
					String phoneNumber = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
							+ (1000 + random.nextInt(9000));
					row.createCell(3).setCellValue(phoneNumber); // PatientPrimaryPhone

					// Generating a random email id
					String email = firstName.toLowerCase() + lastName.toLowerCase() + "@"
							+ domains[random.nextInt(domains.length)];
					row.createCell(4).setCellValue(email);

					// Generating a random gender
					String gender = genders[random.nextInt(genders.length)];
					row.createCell(5).setCellValue(gender);

					// Generating language
					String language = languages[random.nextInt(languages.length)];
					row.createCell(6).setCellValue(language);

					// Generating patient Address
					String patientAdd = (100 + random.nextInt(900)) + " " + address[random.nextInt(address.length)];
					row.createCell(7).setCellValue(patientAdd);

					// Generating City
					String city = cityNames[random.nextInt(cityNames.length)];
					row.createCell(8).setCellValue(city);

					// Generating State
					String state = States[random.nextInt(States.length)];
					row.createCell(9).setCellValue(state);

					// Generating zip
					int zip = 10000 + random.nextInt(9999);
					row.createCell(10).setCellValue(zip);

					// Generating a random phone number
					String secphoneNumber = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
							+ (1000 + random.nextInt(9000));
					row.createCell(11).setCellValue(secphoneNumber); // PatientSechone

					// generating Patient Authorization Date
					String authDate = getNthDayFromToday(0);
					row.createCell(12).setCellValue(authDate); // PatientAuthDate

					// generating Patient Certifications Date
					String certDate = getNthDayFromToday(0);
					row.createCell(13).setCellValue(certDate); // PatientCertDate

					String checkbox = checkboxes[random.nextInt(checkboxes.length)];
					for (int i = 14; i <= 19; i++) {
						row.createCell(i).setCellValue(checkbox);
					}

					// Legal Representative Names
					int randomNumLegalRep = random.nextInt(999);
					String legalRepfirstName = legalRepfirstNames[random.nextInt(legalRepfirstNames.length)];
					String legalReplastName = legalReplastNames[random.nextInt(legalReplastNames.length)];

					String legalRepName = legalRepfirstName + " " + legalReplastName;
					row.createCell(20).setCellValue(legalRepName); // LegalRepLastName

					// Legal Representative Relationship
					String rel = relationship[random.nextInt(relationship.length)];
					row.createCell(21).setCellValue(rel);

					// patient has no insurance
					row.createCell(22).setCellValue(checkbox);

					// RX payer name

					row.createCell(23).setCellValue("TestAutomation Payer Pharmacy");

					// Rx Phone
					String rxphoneNumber = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
							+ (1000 + random.nextInt(9000));
					row.createCell(24).setCellValue(rxphoneNumber); // RX phone num

					// RX policy ID
					int rxPolicyID = 10000 + random.nextInt(99999);
					row.createCell(25).setCellValue(rxPolicyID);

					// RX group ID
					int rxGrpID = 10000 + random.nextInt(999999);
					row.createCell(26).setCellValue(rxGrpID);

					// RX BIN
					int rxBIN = 200000 + random.nextInt(99999);
					row.createCell(27).setCellValue(rxBIN);

					// RX PCN
					int rxPCN = 1000000000 + random.nextInt(999999999);
					row.createCell(28).setCellValue(rxPCN);

					// Medical Payer Name
					row.createCell(29).setCellValue("TestAutomation Payer Medical");

					// Medical Phone
					String medicalPhoneNumber = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900))
							+ "-" + (1000 + random.nextInt(9000));
					row.createCell(30).setCellValue(medicalPhoneNumber); // Medical phone num

					// Medical policy ID
					int medPolicyID = 50000 + random.nextInt(99999);
					row.createCell(31).setCellValue(medPolicyID);

					// Medical group
					int medgrp = 60000 + random.nextInt(999999);
					row.createCell(32).setCellValue(medgrp);

					// Policy Holder Name

					int randomNumPolicyHolder = random.nextInt(900);
					String policyHolderName = legalRepfirstNames[random.nextInt(legalRepfirstNames.length)]
							+ randomNumPolicyHolder + " " + firstNames[random.nextInt(firstNames.length)] + " "
							+ legalReplastNames[random.nextInt(legalReplastNames.length)];
					row.createCell(33).setCellValue(policyHolderName);

					// relationship To Patient
					String reltoPatient = relationshipToPatient[random.nextInt(relationshipToPatient.length)];
					row.createCell(34).setCellValue(reltoPatient);

					// Preferred Specialty Pharmacy
					row.createCell(35).setCellValue(checkbox);

					// Specialty Pharmacy Name
					row.createCell(36).setCellValue("Automation Specialty Pharmacy");

					// BV Phone
					String BVPhoneNumber = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
							+ (1000 + random.nextInt(9000));
					row.createCell(37).setCellValue(BVPhoneNumber); // BV phone number

					// BV FAX

					String BVFax = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
							+ (1000 + random.nextInt(9000));
					row.createCell(38).setCellValue(BVFax); // BV Fax

					// DUPIXENT MyWay
					row.createCell(39).setCellValue(checkbox);

					// Prescriber name
					int randomNumpre = random.nextInt(999);
					String presfirstName = firstNames[random.nextInt(firstNames.length)];
					String preslastName = lastNames[random.nextInt(lastNames.length)];
					String presName = presfirstName + " " + preslastName;

					row.createCell(40).setCellValue(presName); // PrescriberLastName

					// specialties
					String prspecialties = specialties[random.nextInt(specialties.length)];
					row.createCell(41).setCellValue(prspecialties); // PrescriberLastName

					// Generating Prescriber Address
					String preAdd = (100 + random.nextInt(900)) + " " + address[random.nextInt(address.length)];
					row.createCell(42).setCellValue(preAdd);

					// Generating Prescriber City
					String precity = cityNames[random.nextInt(cityNames.length)];
					row.createCell(43).setCellValue(precity);

					// Generating Prescriber State
					String prstate = States[random.nextInt(States.length)];
					row.createCell(44).setCellValue(prstate);

					// Generating Prescriber zip
					int preszip = 10000 + random.nextInt(9999);
					row.createCell(45).setCellValue(preszip);

					// Prescriber NPI
					String presNPI = generateRandom10DigitNumber();
					row.createCell(46).setCellValue(presNPI);

					// facilityNames
					String facilityName = facilityNames[random.nextInt(facilityNames.length)];
					row.createCell(47).setCellValue(facilityName);

					// Office name
					int randomNumOfc = random.nextInt(999);
					String ofcFName = officeFirstNames[random.nextInt(officeFirstNames.length)];
					String ofcLName = officeFirstNames[random.nextInt(officeLastNames.length)];
					String ofcName = ofcFName + " " + ofcLName;
					row.createCell(48).setCellValue(ofcName);

					// office contcat email
					String offemail = ofcFName.toLowerCase() + ofcLName.toLowerCase() + "@"
							+ domains[random.nextInt(domains.length)];
					row.createCell(49).setCellValue(offemail);

					// Office Phone
					String offPhoneNumber = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
							+ (1000 + random.nextInt(9000));
					row.createCell(50).setCellValue(offPhoneNumber); // office phone number

					// office fax

					String offFax = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
							+ (1000 + random.nextInt(9000));
					row.createCell(51).setCellValue(offFax); // BV Fax

					// tax id
					int tax = 100000000 + random.nextInt(99999999);
					row.createCell(52).setCellValue(tax);

					// Date Of Diagnosis
					year = 2000 + random.nextInt(23); // Random year between 2000 and 2023
					month = 1 + random.nextInt(12);
					day = 1 + random.nextInt(28);
					String datOfDiagnosis = String.format("%02d-%02d-%02d", month, day, year);
					row.createCell(53).setCellValue(datOfDiagnosis);

					// Diagnosis Code
					row.createCell(54).setCellValue("");

					// Prescriber State License
					if (prstate.equalsIgnoreCase("Puerto Rico")) {
						int license = 10000 + random.nextInt(999999);
						row.createCell(55).setCellValue(license);
					}

					// A Sample Provided
					row.createCell(56).setCellValue(checkbox);

					// A Sample Provided Date

					year = 2022 + random.nextInt(1); // Random year between 2022 and 2023
					month = 1 + random.nextInt(12);
					day = 1 + random.nextInt(28);
					String sampleProvidedDate = String.format("%02d-%02d-%02d", month, day, year);
					row.createCell(57).setCellValue(sampleProvidedDate);

					// A Prefilled Syringe
					row.createCell(58).setCellValue(checkbox);

					// A Prefilled Pen
					row.createCell(59).setCellValue(checkbox);

					// Prescription-A RefillCaptured
					int arefill = 1 + random.nextInt(10);
					row.createCell(60).setCellValue(arefill);

					// Prescription-5A Dose
					String dupixentOption = dupixentOptions[random.nextInt(dupixentOptions.length)];
					row.createCell(61).setCellValue(dupixentOption);

					// A-Known Drug Allergies
					String drugAllergie = drugAllergies[random.nextInt(drugAllergies.length)];
					row.createCell(62).setCellValue(drugAllergie);

					// A-weight

					int aweight = 20 + random.nextInt(100);
					row.createCell(63).setCellValue(aweight);

					// A -Initial And Maintenance Doses
					row.createCell(64).setCellValue(checkbox);

					// Prescription 5B Quick Start
					row.createCell(65).setCellValue(checkbox);

					// B Sample Provided
					row.createCell(66).setCellValue(checkbox);

					// b Sample Provided Date

					year = 2022 + random.nextInt(1); // Random year between 2022 and 2023
					month = 1 + random.nextInt(12);
					day = 1 + random.nextInt(28);
					String bsampleProvidedDate = String.format("%02d-%02d-%02d", month, day, year);
					row.createCell(67).setCellValue(bsampleProvidedDate);

					// B Prefilled Syringe
					row.createCell(68).setCellValue(checkbox);

					// B Prefilled Pen
					row.createCell(69).setCellValue(checkbox);

					// Prescription-B RefillCaptured
					int brefill = 1 + random.nextInt(10);
					row.createCell(70).setCellValue(brefill);

					// Prescription-5B Dose
					String bdupixentOption = dupixentOptions[random.nextInt(dupixentOptions.length)];
					row.createCell(71).setCellValue(bdupixentOption);

					// B-Known Drug Allergies
					String bdrugAllergie = drugAllergies[random.nextInt(drugAllergies.length)];
					row.createCell(72).setCellValue(bdrugAllergie);

					// b-weight

					int bweight = 20 + random.nextInt(100);
					row.createCell(73).setCellValue(bweight);

					// A -Initial And Maintenance Doses
					row.createCell(74).setCellValue(checkbox);

					// Prescriber Signature Date
					String prescribersignDate = getNthDayFromToday(0);
					row.createCell(75).setCellValue(prescribersignDate);

					// Substitutions Date
					year = 2022 + random.nextInt(1); // Random year between 2022 and 2023
					month = 1 + random.nextInt(12);
					day = 1 + random.nextInt(28);
					String substitutionsDate = String.format("%02d-%02d-%02d", month, day, year);
					row.createCell(76).setCellValue(substitutionsDate);

					// collaborating MD Names
					int randomNumMD = random.nextInt(999);
					String mdFirstName = collaboratingMDFirstNames[random.nextInt(collaboratingMDFirstNames.length)];

					String mdlastName = lastNames[random.nextInt(lastNames.length)];

					String mdName = mdFirstName + " " + mdlastName;
					row.createCell(77).setCellValue(mdName);

					// Nurse Practitioner NPI
					String nurseNPI = generateRandom10DigitNumber();
					row.createCell(78).setCellValue(nurseNPI);

					// Eosinophil count
					int count = 1 + random.nextInt(50);
					row.createCell(79).setCellValue(count);
				}

				// Write data to Excel file
				try (FileOutputStream fileOut = new FileOutputStream(testDataFilePath + testDataFileName)) {
					workbook.write(fileOut);
					System.out.println("Test data generated successfully and written");
				}

			} catch (

			IOException e) {
				e.printStackTrace();
			}
		}

	}
}