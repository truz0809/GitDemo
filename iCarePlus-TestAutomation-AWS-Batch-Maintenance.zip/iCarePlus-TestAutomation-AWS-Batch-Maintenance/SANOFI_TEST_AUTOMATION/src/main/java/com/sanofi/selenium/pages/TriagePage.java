package com.sanofi.selenium.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class TriagePage extends Utility_Function {

	public TriagePage(WebDriver driver) {
		super(driver);
	}

	/************************
	 * Elements
	 **************************************************/

	public static By elePrescription = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//span[text()=\"Prescription\"]//parent::label//parent::div//following-sibling::div//li//span[contains(@class,\"option-text\")])[2]");
	public static By eleMainTaskStatus = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//span[contains(@class,\"status-text\")]");
	public static By eleCPETable = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Care Program Enrollee Products\"]//tbody//tr");

	public static By eleCPEWorkOrderTable = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-grid\")]//*[text()=\"Care Program Enrollee Work Order\"]");
	public static By eleOrderTable = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Orders\"]//tbody//tr");
	public static By createdDateColumn = By

			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Created Date\"]//parent::a");
	public static By createdDateSortState = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Created Date\"]//parent::a//parent::div//span[contains(@class,\"text\")])[2]");

	public static By orderList = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//th[contains(@class,\"cellContainer\")]//a");

	public static By eleEditStatus = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//button[@title='Edit Status']");

	public static By eleActiveStatus = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),'Active') and @slot='output']//parent::slot//parent::span");
	public static By eleStatusType = By
			.xpath("//*[contains(@class,\"slds-combobox\")]//button[@aria-label='Status']//parent::div");

	// public static By eleStatusoptions = By.xpath(
	// "(//label[contains(text(),'Status')]//following-sibling::div)[1]//div[@role='listbox']//*[@role='option']");

	public static By eleStatusoptions = By.xpath("//*[@ aria-label='Status']//span[@ class='slds-media__body']/span");

	public static By eleSaveEdit = By.xpath("//button[@name='SaveEdit']");

	public static By eleStartNewServiceButton = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//button[@name=\"CareProgramEnrollee.CPE_StartNewService_ICC\"]");
	public static By eleNewServiceTitle = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//h2[text()=\"Start New Service\"]");
	public static By eleSelectDropDown = By.xpath("//*[contains(@class,\"active lafPageHost\")]//select//option");
	public static By eleSelectDropDown1 = By.xpath("//*[contains(@class,\"active lafPageHost\")]//select");
	public static By elePrescriptionElement = By
			.xpath("(//*[@data-label='Prescription'])[1]//div[@class='slds-grid']/a[contains(@href,'')]");
	/************************
	 * Dynamic Elements
	 **************************************************/

	public static String eleButton = "//*[contains(@class,\"active lafPageHost\")]//button[@title=\"{0}\"]";
	public static String strTaskName = "//*[contains(@class,\"active lafPageHost\")]//*[@class=\"slds-section__title\"]//*[text()=\"{0}\"]";
	public static String strSubtaskName = "//*[@class=\"card\"]//*[text()=\"{0}\"]";
	public static String taskButton = "(//*[contains(@class,\"active lafPageHost\")]//*[@class=\"slds-section__title\"]//*[text()=\"{0}\"]//parent::div//span)[1]";
	public static String strSubTaskStatus = "(//*[@class=\"card\"]//*[text()=\"{0}\"]//parent::div//li)[2]";
	public static String subTaskButton = "//*[contains(@class,\"active lafPageHost\")]//div[@class=\"card\"]//*[text()=\"{0}\"]//parent::div";
	public static String strTaskTitle = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strDropDownInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]";
	public static String strInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strInputDateBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//input";
	public static String searchDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//span[contains(@class,\"option-text\")]";
	public static String button = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";
	public static String strAccountObjectDetails = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//parent::dt//following-sibling::dd//lightning-formatted-text";
	 public static String strAccountObjectDetailsLink = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//parent::div//a//span)[3]";
	//public static String strAccountObjectDetailsLink = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//parent::div//span//a//slot//child::span//span";

	public static String strInputBpx = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String orderTableColumn = "//*[contains(@class,\"active lafPageHost\")]//td[@data-label=\"{0}\"]//lightning-base-formatted-text";
	public static String fileName = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]";
	public static String orderTableFirstColumn = "//*[contains(@class,\"active lafPageHost\")]//th[@data-label=\"{0}\"]//lightning-base-formatted-text";
	public static String strCPEUpdateDropdown = "//*[contains(@class,\"active lafPageHost\")]//select[@name=\"{0}\"]";
	public static String strUnenrollConfirmBtn = "//*[contains(@class,\"active lafPageHost\")]//span[@class=\"slds-radio\"]//input[@value=\"{0}\"]//parent::span//child::span[@class=\"slds-radio_faux\"]";
	public static By eleSaveBtn = By.xpath("//*[contains(@class,\"active lafPageHost\")]//button[text()='Save & New']");
	public static String strCPEProduct = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::span//preceding-sibling::span[@class=\"slds-radio--faux topdown-radio--faux\"]";
	public static String cpeDetailsTextField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-text";
	public static String cpeDetailsNonLinkField = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div";
	// public static String cpeDetailsLinkField = "//*[contains(@class,\"active
	// lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//a//span[not(*)]";
	public static String cpeDetailsLinkField = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//slot/span/slot/span";

	public static String selectedSpecialtyPharm = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//child::span//child::slot//child::force-lookup//child::div//child::records-hoverable-link//child::div//child::span//child::slot//child::span//child::slot//child::span";
	/**
	 * Function:Check Triage is initiated
	 * 
	 * @author Trupti
	 **/

	public void checkTraigeIntiation() {
		try {
			setTimeOut(10000);
			By triageStartButton = getDynamicElement(eleButton, "Triage");
			waitAndVerifyElement(triageStartButton);
			scrollToElement(triageStartButton);
			click(triageStartButton);
			String buttonState = getAttributeValue(triageStartButton, "aria-pressed");
			// Assert the state of the button
			Assert.assertEquals(buttonState, "true", "Triage flow is initialized");
			LoggingInfo("Triage flow is initialized");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to check the status of Triage intiation " + e.getMessage());
			Assert.fail("Failed to check the status of Triage intiation " + e.getMessage());
		}
	}

	public void verifytheTriageTaskNotInitiated() 
	{
		try 
		{
			By triageButton = getDynamicElement(eleButton, "Triage");
			setTimeOut(4000);
			String buttonState = getAttributeValue(triageButton, "aria-pressed");
			// Assert the state of the button
			Assert.assertEquals(buttonState, "false", "Triage flow is not initialized");
			LoggingInfo("Triage flow is not initialized, Hence Verified.");
			// setTimeOut(2000);
		} 
		catch (Exception e) 
		{
			Log.error("Failed to check the status of Triage flow intiation " + e.getMessage());
			Assert.fail("Failed to check the status of Triage flow intiation " + e.getMessage());
		}
	}


	/**
	 * Function:Check Triage task is initiated
	 * 
	 * @author Trupti
	 **/

	public void checkTriageTaskInitiation() {
		try {
			By taskName = getDynamicElement(strTaskName, "Triage");
			waitAndVerifyElement(taskName);
			scrollToElement(taskName);
			Log.info("Triage task has been initialized");
			setTimeOut(2000);

			By eleTaskButton = getDynamicElement(taskButton, "Triage");
			click(eleTaskButton);
			Log.info("Clicked on Triage task");
			setTimeOut(1000);

			By subTaskName = getDynamicElement(strSubtaskName, "Submit Order");
			waitAndVerifyElement(subTaskName);
			Log.info("Traige sub task-Submit Order has been initialized");
			setTimeOut(2000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, "Submit Order");
			waitAndVerifyElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Not Started", "Submit Order task status verified");
			LoggingInfo("Traige task and sub tasks have been initialized");

		} catch (Exception e) {
			Log.error("Failed to Check Traige Task Initiation " + e.getMessage());
			Assert.fail("Failed to Check Traige Task Initiation " + e.getMessage());
		}
	}

	/**
	 * Function:Click on triage
	 * 
	 * @author Trupti
	 **/
	public void clickOnTraige() {
		try {
			setTimeOut(10000);
			By triageButton = getDynamicElement(eleButton, "Triage");
			waitAndVerifyElement(triageButton);
			scrollToElement(triageButton);
			click(triageButton);
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to Click on Triage button " + e.getMessage());
			Assert.fail("Failed to Click on Triage button " + e.getMessage());
		}
	}

	/**
	 * Function:Click on task
	 * 
	 * @author Trupti
	 **/
	public void clickOnTask() {
		try {
			By eleSubTaskButton = getDynamicElement(subTaskButton, "Submit Order");
			waitAndVerifyElement(eleSubTaskButton);
			clickByJavascript(eleSubTaskButton);
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click on task " + e.getMessage());
			Assert.fail("Failed to click on task " + e.getMessage());
		}
	}

	public void verifyReviewTask(String selectedSp, String spType) {
		// Define the labels and the corresponding expected values
		String[] inputLabels = { "CPE:  Selected Speciality Pharmacy", "CPE: SP Type", "Expedited" };
		ArrayList<String> expectedValues = new ArrayList<>(Arrays.asList(selectedSp.split(" -")[0], spType, "No"));

		try {

			for (int i = 0; i < inputLabels.length; i++) {
				String inputLabel = inputLabels[i];
				By inputBox = getDynamicElement(strInputBox, inputLabel);

				waitAndVerifyElement(inputBox);

				String value = getAttributeValue(inputBox, "value");

				Assert.assertEquals(value, expectedValues.get(i),
						"Failed to verify review task for label: " + inputLabel);
				Log.info(inputLabel + " - value is as expected");
			}

			LoggingInfo("Triage values are as expected");

		} catch (Exception e) {

			Log.error("Failed to verify review task: " + e.getMessage());
			Assert.fail("Failed to verify review task: " + e.getMessage());
		}
	}

	/**
	 * Function:Verify review task
	 * 
	 * @author Trupti
	 **/
	public void verifyReview() {

		String[] inputLabels = { "CPE:  Selected Speciality Pharmacy", "CPE: SP Type", "Expedited" };
		try {
			for (String inputLabel : inputLabels) {
				By inputBox = getDynamicElement(strInputBox, inputLabel);
				waitAndVerifyElement(inputBox);
				String value = getAttributeValue(inputBox, "value");
				boolean verifyValue = !value.isEmpty();
				Assert.assertTrue(verifyValue, inputLabels + "-is not empty");
			}
			LoggingInfo("Triage values are not empty");

		} catch (Exception e) {
			Log.error("Failed to verify review " + e.getMessage());
			Assert.fail("Failed to verify review " + e.getMessage());
		}
	}

	/**
	 * Function:Check traige task complition
	 * 
	 * @author Trupti
	 **/

	public void checkTraigeTaskComplition() {
		try {
			waitAndVerifyElement(eleMainTaskStatus);
			String mainTaskStatus = getText(eleMainTaskStatus);
			Assert.assertEquals(mainTaskStatus, "Done", "Triage task completed successfully");
			Log.info("QS Summary task completed successfully");

			By eleTaskButton = getDynamicElement(taskButton, "Triage");
			click(eleTaskButton);
			Log.info("Clicked on Triage task");
			setTimeOut(1000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, "Submit Order");
			waitAndVerifyElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Completed", "Submit Order sub task completed successfully");
			LoggingInfo("Submit Order sub task completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to check Triage Task Complition " + e.getMessage());
			Assert.fail("Failed to check Triage Task Complition " + e.getMessage());
		}
	}

	/**
	 * Function:Verify review task
	 * 
	 * @author Trupti
	 **/
	public void verifyReviewTask(String selectedSp, String spType, String expedited) {
		// Define the labels and the corresponding expected values
		String[] inputLabels = { "CPE:  Selected Speciality Pharmacy", "CPE: SP Type", "Expedited" };
		ArrayList<String> expectedValues = new ArrayList<>(Arrays.asList(selectedSp.split(" -")[0], spType, expedited));

		try {

			for (int i = 0; i < inputLabels.length; i++) {
				String inputLabel = inputLabels[i];
				By inputBox = getDynamicElement(strInputBox, inputLabel);

				waitAndVerifyElement(inputBox);

				String value = getAttributeValue(inputBox, "value");

				Assert.assertEquals(value, expectedValues.get(i),
						"Failed to verify review task for label: " + inputLabel);
				Log.info(inputLabel + " - value is as expected");
			}
			LoggingInfo("Triage values are as expected");

		} catch (Exception e) {

			Log.error("Failed to verify review task: " + e.getMessage());
			Assert.fail("Failed to verify review task: " + e.getMessage());
		}
	}

	/**
	 * Function:Verify SP type
	 * 
	 * @author Trupti
	 **/

	public void verifySPType(String spType) {
		try {
			By eleSPType = getDynamicElement(cpeDetailsNonLinkField, "SP Type");
			waitAndVerifyElement(eleSPType);
			scrollToElement(eleSPType);
			verifyDetails(eleSPType, spType, "SP Type");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify SP type " + e.getMessage());
			Assert.fail("Failed to verify SP type " + e.getMessage());
		}
	}

	/**
	 * Function:Verify selected SP type is not empty
	 * 
	 * @author Trupti
	 **/

	public String verifySelectedSP() {
		String value = null;

		try {
			By eleSelectedSPType = getDynamicElement(strAccountObjectDetailsLink, "Selected Specialty Pharmacy");
			waitAndVerifyElement(eleSelectedSPType);
			scrollToElement(eleSelectedSPType);
			value = getText(eleSelectedSPType);
			boolean verifyValue = !value.isEmpty();
			Assert.assertTrue(verifyValue, "-is not empty");
			System.out.println(value);
			LoggingInfo("Selected Specialty Pharmacy is not empty");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify SP type " + e.getMessage());
			Assert.fail("Failed to verify SP type " + e.getMessage());
		}
		return value;
	}

	/**
	 * Function:Verify order details in in order table
	 * 
	 * @author Trupti
	 **/

	public void verifyOrderDetails(String patientName) {
		try {
			LoggingInfo(
					"After Triage is completed, navigate to the Order object and validate that Order details are generated on Patient's name. ");
			boolean nameFound = false;
			if (verifytable("Orders")) {
				List<WebElement> rows = getWebDriver().findElements(eleOrderTable);
				scrollToElement(eleOrderTable);
				for (WebElement row : rows) {
					WebElement woElement = row.findElement(By.xpath("//*[@data-label=\"CPE Work Order\"]//a"));

					((JavascriptExecutor) getWebDriver()).executeScript(
							"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
							woElement);
					String workOrderName = woElement.getAttribute("Title");
					if (workOrderName.equals("Triage")) {
						WebElement nameElement = row.findElement(By.xpath("//*[@data-label=\"Account Name\"]//a"));

						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								nameElement);
						String name = nameElement.getAttribute("Title");
						Assert.assertEquals(patientName, name, "Work order generated");
						nameFound = true;
						break;
					}

				}
				Assert.assertTrue(nameFound, "Name not found in the Order table.");
				LoggingInfo("Verification completed: ");
			}
		} catch (Exception e) {
			Log.error("Failed to navigate to orders table  " + e.getMessage());
			Assert.fail("Failed to navigate to orders table  " + e.getMessage());
		}
	}

	/**
	 * Function:Verify selected Pharmacy record
	 * 
	 * @author Trupti
	 **/

	public String verifySelectedPharmacy(String pharmacy1, String pharmacy2, String pharmacy3) {
		String selectedPharmacy = null;

		try {
			By selectedSPTypeElement = getDynamicElement(strAccountObjectDetailsLink, "Selected Specialty Pharmacy");
			waitAndVerifyElement(selectedSPTypeElement);
			scrollToElement(selectedSPTypeElement);

			selectedPharmacy = getText(selectedSPTypeElement).split(" -")[0];
			boolean isValidPharmacy = false;
			if (pharmacy3 != null) {
				isValidPharmacy = selectedPharmacy.equalsIgnoreCase(pharmacy1)
						|| selectedPharmacy.equalsIgnoreCase(pharmacy2) || selectedPharmacy.equalsIgnoreCase(pharmacy3);
			} else {
				isValidPharmacy = selectedPharmacy.equalsIgnoreCase(pharmacy1)
						|| selectedPharmacy.equalsIgnoreCase(pharmacy2);
			}

			if (isValidPharmacy) {
				LoggingInfo("Selected Specialty Pharmacy is correctly assigned.");
			} else {
				Assert.fail("Selected Specialty Pharmacy is not assigned as expected. Expected one of: " + pharmacy1
						+ ", " + pharmacy2 + (pharmacy3 != null ? ", " + pharmacy3 : "") + ". Actual: "
						+ selectedPharmacy);
			}
		} catch (Exception e) {
			Log.error("Failed to verify Specialty Pharmacy: " + e.getMessage());
			Assert.fail("Failed to verify Specialty Pharmacy: " + e.getMessage());
		}

		return selectedPharmacy;
	}

	/**
	 * Function: Verify selected pharmacy with name
	 * 
	 * @author Trupti
	 **/

	public String verifySelectedPharmacy(String pharmacy1) {
		String value = null;

		try {
			By selectedSPTypeElement = getDynamicElement(selectedSpecialtyPharm, "Selected Specialty Pharmacy");
			waitAndVerifyElement(selectedSPTypeElement);
			scrollToElement(selectedSPTypeElement);

			value = getText(selectedSPTypeElement).split(" -")[0];

			if (value.equalsIgnoreCase(pharmacy1)) {
				LoggingInfo("Selected Specialty Pharmacy is correctly assigned.");
			} else {
				Assert.fail("Selected Specialty Pharmacy is not assigned as expected." + "expected pharmcy " + pharmacy1
						+ "Actual " + value);
			}
		} catch (Exception e) {
			Log.error("Failed to verify Specialty Pharmacy: " + e.getMessage());
			Assert.fail("Failed to verify Specialty Pharmacy: " + e.getMessage());
		}

		return value;
	}

	public void verifyAndclickOnTask() {
		try {
			By eleSubTaskButton = getDynamicElement(subTaskButton, "Submit Order");
			waitAndVerifyElement(eleSubTaskButton);
			click(eleSubTaskButton);
			setTimeOut(2000);
			// closeTaskLoadingWindowIfVisible();
		} catch (Exception e) {
			Log.error("Failed to click on task " + e.getMessage());
			Assert.fail("Failed to click on task " + e.getMessage());
		}
	}

	public void verifyTraigeTaskComplition() {
		try {
			waitAndVerifyElement(eleMainTaskStatus);
			String mainTaskStatus = getText(eleMainTaskStatus);
			Assert.assertEquals(mainTaskStatus, "Done", "Triage task completed successfully");
			Log.info("QS Summary task completed successfully");

			By eleTaskButton = getDynamicElement(taskButton, "Triage");
			click(eleTaskButton);
			Log.info("Clicked on Triage task");
			setTimeOut(1000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, "Submit Order");
			waitAndVerifyElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Completed", "Submit Order sub task completed successfully");
			LoggingInfo("Submit Order sub task completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to check Triage Task Complition " + e.getMessage());
			Assert.fail("Failed to check Triage Task Complition " + e.getMessage());
		}
	}

	public String verifyPharmacyType(String pharmacy1) {
		String value = null;

		try {
			By selectedSPTypeElement = getDynamicElement(cpeDetailsLinkField, "Selected Specialty Pharmacy");
			waitAndVerifyElement(selectedSPTypeElement);
			scrollToElement(selectedSPTypeElement);
			setTimeOut(2000);

			value = getText(selectedSPTypeElement).split(" -")[0];
			if (value.equalsIgnoreCase(pharmacy1)) {
				LoggingInfo("Selected Specialty Pharmacy is correctly assigned.");
			} else {
				Assert.fail("Selected Specialty Pharmacy is not assigned as expected.");
			}
		} catch (Exception e) {
			Log.error("Failed to verify Specialty Pharmacy: " + e.getMessage());
			Assert.fail("Failed to verify Specialty Pharmacy: " + e.getMessage());
		}

		return value;
	}

	/**
	 * Function: Verify review task fields are read only
	 *
	 * @author Trupti
	 */
	public void verifyReviewTaskFieldsReadOnly() {
		try {

			String[] inputLabels = { "CPE:  Selected Speciality Pharmacy", "CPE: SP Type", "Expedited" };
			for (int i = 0; i < inputLabels.length; i++) {
				String inputLabel = inputLabels[i];
				By inputBox = getDynamicElement(strInputBox, inputLabel);
				waitAndVerifyElement(inputBox);
				verifyHardAssertReadOnlyField(inputBox, inputLabel);

				LoggingInfo(inputLabel + " - is read only field");
			}

		} catch (Exception e) {
			Log.error("Failed to validate if fields are read only " + e.getMessage());
			Assert.fail("Failed to validate if fields are read only " + e.getMessage());
		}
	}

	/**
	 * Function: Verify order table - Order name, Quick start
	 *
	 * @author Trupti
	 */
	public void verifyOrderTable(String quickStart) { // Check this again
		try {

			// Order name
			By orderName = getDynamicElement(orderTableFirstColumn, "Name");
			waitAndVerifyElement(orderName);
			String orderNameText = getText(orderName);
			if (orderNameText.contains("MR")) {
				Assert.assertTrue(true, "Order name is generated with the expected prefix.");
				LoggingInfo("Order name is generated with the expected prefix.");

			} else {
				Assert.fail("Order name does not contain the expected prefix 'MR'. Found: " + orderNameText);
				LoggingInfo("Order name does not contain the expected prefix 'MR'");

			}

			// QuickStart
			By quickStartEle = getDynamicElement(orderTableColumn, "Quick Start");
			waitAndVerifyElement(quickStartEle);
			String actualQS = getText(quickStartEle);
			if (actualQS.equals(quickStart)) {
				Assert.assertTrue(true, "Quick start is generated as per patient enrollment.");
				LoggingInfo("Quick start is generated as per patient enrollment");
			} else {
				Assert.fail("Quick start is not generated as per patient enrollment. Found: " + actualQS);
				LoggingInfo("Quick start is not generated as per patient enrollment");
			}
		} catch (Exception e) {

			String errorMessage = "Failed to validate the order details: " + e.getMessage();
			Log.error(errorMessage);
			Assert.fail(errorMessage);
		}
	}

	/**
	 * Function: Verify file name in order details page
	 *
	 * @author Trupti
	 */

	public void verifyFileName(String expectedFileName) {
		try {
			By fileNameText = getDynamicElement(fileName, expectedFileName);
			waitAndVerifyElement(fileNameText);
			String actualFileName = getText(fileNameText);
			if (actualFileName.equals(expectedFileName)) {
				Assert.assertTrue(true, "File name is populated correctly.");
				LoggingInfo("File name is populated correctly.");
			} else {
				Assert.fail("File name does not match the expected value. Found: " + actualFileName + ", Expected: "
						+ expectedFileName);
				LoggingInfo("File name does not match the expected value. Found: " + actualFileName + ", Expected: "
						+ expectedFileName);
			}

		} catch (Exception e) {
			String errorMessage = "Failed to validate the file name: " + e.getMessage();
			Log.error(errorMessage);
			Assert.fail(errorMessage);
		}
	}

	/**
	 * Function:Get order details in in order table
	 * 
	 * @author Trupti
	 **/

	public String getOrderDetails() {
		String ordernum = null;
		try {
			LoggingInfo("Get order number");

			if (verifytable("Orders")) {
				List<WebElement> rows = getWebDriver().findElements(eleOrderTable);
				scrollToElement(eleOrderTable);
				for (WebElement row : rows) {
					WebElement woElement = row.findElement(By.xpath("//*[@data-label=\"CPE Work Order\"]//a"));

					((JavascriptExecutor) getWebDriver()).executeScript(
							"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
							woElement);
					String workOrderName = woElement.getAttribute("Title");
					if (workOrderName.equals("Triage")) {
						WebElement orderElement = row
								.findElement(By.xpath("//*[@data-label=\"Order Number\"]//a//slot//span//slot/span"));

						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								orderElement);
						ordernum = orderElement.getText();
						LoggingInfo("Order number: " + ordernum);

					} else {
						Assert.fail("Triage work order not found");
						LoggingInfo("Order number not found");
					}

				}

			}
		} catch (Exception e) {
			Log.error("Failed to navigate to orders table  " + e.getMessage());
			Assert.fail("Failed to navigate to orders table  " + e.getMessage());
		}
		return ordernum;
	}

	/**
	 * Function: Verify triage order id is present is Order list view
	 *
	 * @author Trupti
	 */
	public void verifyOrderRecordIsPresent(String orderId) {
		try {
			String sortingState;

			do {
				sortingState = getText(createdDateSortState);

				if (sortingState != null && !sortingState.contains("Sorted Descending")) {
					clickByJavascript(createdDateColumn);
					setTimeOut(1000); // Give the UI some time to react
				}
				sortingState = getText(createdDateSortState);
			} while (sortingState != null && !sortingState.contains("Sorted Descending"));

			boolean orderFound = false;
			for (int attempt = 0; attempt < 3; attempt++) {
				if (methodToAvoidStaleElementReferenceErrorElement(orderList)) {
					waitAndVerifyElement(orderList);
					setTimeOut(1000);

					List<WebElement> listOptions = getWebDriver().findElements(orderList);

					for (WebElement element : listOptions) {
						String orderNumber = element.getAttribute("title");
						setTimeOut(1000);
						System.out.println(orderNumber);
						if (orderNumber.equals(orderId)) {
							orderFound = true;
							Assert.assertTrue(orderFound, "Order ID " + orderId + " found.");
							LoggingInfo("Order ID " + orderId + " found.");
							break;
						}
					}
				}

				click(createdDateColumn);
				setTimeOut(2000);
			}

			if (!orderFound) {
				Assert.fail("Order ID " + orderId + " not found in the list after 3 attempts.");
			}

		} catch (Exception e) {
			Log.error("Failed to verify order record: " + e.getMessage());
			e.printStackTrace();
			Assert.fail("Failed to verify order record: " + e.getMessage());
		}
	}

	public void clickonPrescription() {
		try {
			waitAndVerifyElement(elePrescriptionElement);
			clickByJavascript(elePrescriptionElement);
			setTimeOut(2000);
			LoggingInfo("click on Prescription successful ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Prescription" + e.getMessage());
			Assert.fail("Failed to click on Prescription" + e.getMessage());
		}
	}

	public void verifyMRStatus() {
		try {
			waitAndVerifyElement(eleActiveStatus);
			setTimeOut(2000);
			LoggingInfo("MR Active Status verified successfully ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify MR Active Status " + e.getMessage());
			Assert.fail("Failed to verify MR Active Status " + e.getMessage());
		}
	}

	public void changeMRStatus(String statusType) {
		try {
			setTimeOut(2000);
			clickByJavascript(eleEditStatus);
			Log.info("Change MR status");
			setTimeOut(2000);
			waitAndVerifyElement(eleStatusType);
			click(eleStatusType);
			setTimeOut(2000);
			waitAndVerifyElement(eleStatusoptions);
			selectItemFromDropDown(eleStatusType, eleStatusoptions, statusType);
			setTimeOut(2000);
			click(eleSaveEdit);
			setTimeOut(2000);
			LoggingInfo("MR Status is changed to-" + statusType);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to change MR Status" + e.getMessage());
			Assert.fail("Failed to change MR Status" + e.getMessage());
		}
	}

	public void clickOnStartNewService() {
		try {

			waitAndVerifyElement(eleStartNewServiceButton);
			waitForvisiblityOfElementLocated(eleStartNewServiceButton);
			scrollToElement(eleStartNewServiceButton);
			click(eleStartNewServiceButton);
			LoggingInfo("Clicked on 'Start New Service Button'");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click On Start New Service " + e.getMessage());
			Assert.fail("Failed to click On Start New Service " + e.getMessage());
		}
	}

	public void verifyServiceTitle() {
		try {
			waitForPageLoaded();
			waitAndVerifyElement(eleNewServiceTitle);
			LoggingInfo("Start New Service pop up id loaded");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to verify Service Title " + e.getMessage());
			Assert.fail("Failed to verify Service Title " + e.getMessage());
		}
	}

	public void selectService() {
		try {
			waitAndVerifyElement(eleSelectDropDown1);
			selectItemFromList(eleSelectDropDown, "Triage");
			LoggingInfo("Selected Service as Triage");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Service " + e.getMessage());
			Assert.fail("Failed to select Service " + e.getMessage());
		}
	}

	public void selectReason() {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			String reason = "Migrated Patient";
			selectItemFromList(eleSelectDropDown, reason);
			LoggingInfo("Selected Reason as-" + reason);
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Reason " + e.getMessage());
			Assert.fail("Failed to select Reason " + e.getMessage());
		}
	}

	/**
	 * Function: Open Order Record from Orders Table
	 *
	 * @author Shanavaz Nishani
	 */
	public void openOrderRec() {
		try {
			By eleOrderRec = By
					.xpath("//*[contains(@class,'active lafPageHost')]//tbody//th[@data-label='Order Number']//a");
			waitAndVerifyElement(eleOrderRec);
			clickByJavascript(eleOrderRec);
			LoggingInfo("Opened Order Record");
		} catch (Exception e) {
			Log.error("Failed to Open record from Orders Table " + e.getMessage());
			Assert.fail("Failed to Open record from Orders Table " + e.getMessage());
		}

	}

	/**
	 * Function: Validate Field values for Order Details
	 *
	 * @author Shanavaz Nishani
	 */
	public void validateOrderDetailsValues(String field, String value) {

		try {
			scrollToHalfPage();
			String strOrderDetailsField = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//ancestor::div[contains(@class,\"slds-form-element\")]//lightning-formatted-text";
			By eleOrderDetailsField = getDynamicElement(strOrderDetailsField, field);
			waitAndVerifyElement(eleOrderDetailsField);
			highLightElement(eleOrderDetailsField);
			verifyDetails(eleOrderDetailsField, value, field);
			LoggingInfo("Verified Order field: " + field + " with value: " + value);
		} catch (Exception e) {
			Log.error("Failed to Validate Field values " + e.getMessage());
			Assert.fail("Failed to sValidate Field values " + e.getMessage());
		}

	}

	/**
	 * Function: Click on CPE Status Update button
	 *
	 * @author Shanavaz Nishani
	 */
	public void clickOnCPEStatusUpdateBtn() {
		try {
			By eleBtn = By.xpath(
					"//*[contains(@class, 'active lafPageHost')]//*[@apiname='CareProgramEnrollee.CPE_StatusUpdate_ICC']//a");
			waitAndVerifyElement(eleBtn);
			scrollToElement(eleBtn);
			click(eleBtn);
			Log.info("Clicked on button: CPE Status Update");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click on CPE Status Update button " + e.getMessage());
			Assert.fail("Failed to click on CPE Status Update button " + e.getMessage());
		}

	}

	/**
	 * Function: Selct CPE Status from dropdown
	 *
	 * @author Shanavaz Nishani
	 */
	public void selectCPEStatus(String cpeStatus) {
		try {

			By eleCPEUpdateDropdown = getDynamicElement(strCPEUpdateDropdown, "Status");
			selectItemFromList(eleCPEUpdateDropdown, cpeStatus);
			Log.info("Selected CPE status: " + cpeStatus);
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select status " + e.getMessage());
			Assert.fail("Failed to select status " + e.getMessage());
		}
	}

	/**
	 * Function: Selct Inactive Reason from dropdown
	 *
	 * @author Shanavaz Nishani
	 */
	public void selectInactivationReason(String InactivationReason) {
		try {
			By eleCPEInactiveReason = getDynamicElement(strCPEUpdateDropdown, "Inactivation_Reason");
			waitAndVerifyElement(eleCPEInactiveReason);
			selectItemFromList(eleCPEInactiveReason, InactivationReason);
			Log.info("Selected Inactivation Reason: " + InactivationReason);
		} catch (Exception e) {
			Log.error("Failed to select Inactive reason " + e.getMessage());
			Assert.fail("Failed to select Inactive reason " + e.getMessage());
		}

	}

	/**
	 * Function: Select Unenroll Patient confirmation radio button
	 *
	 * @author Shanavaz Nishani
	 */
	public void selectUnenrollPatBox(String consent) {

		try {
			By eleUnenrollConfirmBtn = getDynamicElement(strUnenrollConfirmBtn, consent);
			waitAndVerifyElement(eleUnenrollConfirmBtn);
			clickByJavascript(eleUnenrollConfirmBtn);
			Log.info("Clicked on Unenroll Patient confirmation button: " + consent);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select radio button " + e.getMessage());
			Assert.fail("Failed to select radio button  " + ". Error - " + e.getMessage());
		}

	}

	/**
	 * Function: Click on save and New button
	 * 
	 * @author SHanavaz Nishani
	 **/
	public void clickOnSaveandNewBtn() {

		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleSaveBtn);
			scrollToElement(eleSaveBtn);
			click(eleSaveBtn);
			setTimeOut(2000);
			Log.info("Clicked on Save&New button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Save&New button " + e.getMessage());
			Assert.fail("Failed to click on Save&New button " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Seelect CPE Product from dropdown
	 * 
	 * @author SHanavaz Nishani
	 **/
	public void selectNewCPEProduct(String CPEproduct) throws Exception {
		try {
			By eleCPEProduct = getDynamicElement(strCPEProduct, CPEproduct);
			waitAndVerifyElement(eleCPEProduct);
			scrollToElement(eleCPEProduct);
			click(eleCPEProduct);
			Log.info("Clicked on CPE Product: " + CPEproduct);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Select CPE product " + CPEproduct + e.getMessage());
			Assert.fail("Failed to Select CPE product " + CPEproduct + ". Error - " + e.getMessage());
		}

	}

	/**
	 * Function: Create a CPEP product record
	 * 
	 * @author SHanavaz Nishani
	 **/
	public void createCPEPMobileProduct(String name, String CPE, String CPP, String status) {
		By eleName = By.xpath("//*[@name=\"Name\"]");
		inputText(eleName, name);
		Log.info("Entered Name as MobileApp");

		String strPlaceHolder = "//*[@placeholder=\"{0}\"]";

		By eleCPE = getDynamicElement(strPlaceHolder, "Search Care Program Enrollees...");
		inputText(eleCPE, CPE);
		By eleSelect = By.xpath("(//*[@role=\"listbox\"]//ul//li//span[@class=\"slds-media__body\"])[1]");
		click(eleSelect);

		By eleCPP = getDynamicElement(strPlaceHolder, "Search Care Program Products...");
		inputText(eleCPP, CPP);
		click(eleSelect);

		By eleStatus = By.xpath("//*[contains(@class,\"active lafPageHost\")]//button[@aria-label=\"Status\"]");
		click(eleStatus);
		String strStatusOption = "//*[contains(@class,\"active lafPageHost\")]//div[@aria-label=\"Status\"]//lightning-base-combobox-item//span[@title=\"{0}\"]";
		By eleStatusOption = getDynamicElement(strStatusOption, status);
		waitAndVerifyElement(eleStatusOption);
		click(eleStatusOption);

		missingInformatioPage.clickOnSaveButton();

		LoggingInfo("MobileAPP CPE Product created successfully with name: " + name);

	}

	/**
	 * Function: Validate CPEP product status
	 * 
	 * @author SHanavaz Nishani
	 **/
	public void validateCPEPstatus(String productName, String status) {
		String strName = "//*//tbody//th//a//span[@class=\"slds-truncate\"]//span";
		List<WebElement> eleName = getWebDriver().findElements(By.xpath(strName));
		for (WebElement ele : eleName) {
			String name = ele.getText();
			if (name.contains(productName)) {
				WebElement eleStatus = ele
						.findElement(By.xpath("//*//following::td[@data-label='Status']//lst-formatted-text//span"));
				String actualstatus = eleStatus.getText();
				if (actualstatus.equalsIgnoreCase(status)) {
					Log.info("CPE Product status is as expected " + status);
					LoggingInfo("CPE Product status is as expected " + status);
				}
				break;
			}
		}
	}

	/**
	 * Function: Validate Correspondence picklist has only HCP and Fax records
	 * 
	 * @author SHanavaz Nishani
	 **/
	public void validteCorrespondenceRecordsPicklist() throws Exception {

		By clickXp = By.xpath(
				"(//*[contains(@class,\"active lafPageHost\")]//div[@aria-label=\"Select Items to Send\"]//input[@class=\"slds-input slds-combobox__input\"])[2]");
		click(clickXp);
		String strCorrespondencePicklist = "//*[contains(@class,\"active lafPageHost\")]//div[@aria-label=\"Select Items to Send\"]//ul//li//span/span";
		List<WebElement> eleCorrespondenceRecords = getWebDriver().findElements(By.xpath(strCorrespondencePicklist));

		for (WebElement ele : eleCorrespondenceRecords) {
			String name = ele.getText().trim();
			System.out.println("Correspondence record name: " + name);
			if (name.endsWith("HCP Fax") || name.endsWith("MD Fax") || name.contains("--")) {
				By xp = By.xpath(ele.toString());
				Log.info("Correspondence record is present in the picklist");
				LoggingInfo("Correspondence record is present in the picklist");
			} else {
				Assert.fail("Correspondence record other than HCP and Fax is present in picklist");
				Log.info("Correspondence record is not present in the picklist");
				LoggingInfo("Correspondence record is not present in the picklist");
			}

		}
	}

	/**
	 * Function: Validate that the status field is updated to 'Sent to SP' on order.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateSentToSP() throws Exception {
		boolean statusFound = false;
		int maxAttempts = 15 / 2;
		for (int i = 0; i < maxAttempts; i++) {
			String strOrderDetailsField = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//ancestor::div[contains(@class,\"slds-form-element\")]//lightning-formatted-text";
			By eleOrderDetailsField = getDynamicElement(strOrderDetailsField, "Status");
			scrollToElement(eleOrderDetailsField);
			String status = getText(eleOrderDetailsField).trim();

			System.out.println("Attempt " + (i + 1) + ": Status = " + status);

			if ("Sent to SP".equalsIgnoreCase(status)) {
				System.out.println("Status 'Sent to SP' found!");
				statusFound = true;
				LoggingInfo("Status field is updated to 'Sent to SP'");
				break;
			}

			if (i < maxAttempts) {
				Thread.sleep(2 * 60 * 1000); // Wait for 2 minutes
				refresh();
			}
		}

		if (!statusFound) {
			throw new RuntimeException("Status field not updated to 'Sent to SP' even after 15 minutes.");
		}

	}
	
	/**
	 * Function: Click on CPE Status Update button
	 *
	 * @author Navita
	 */
	public void clickOnCPEStatusUpdate() {
		try {
			By eleBtn = By.xpath(
					"//*[contains(@class, 'active lafPageHost')]//*[@apiname='CareProgramEnrollee.CPE_StatusUpdate_ICC']//button");
			waitAndVerifyElement(eleBtn);
			scrollToElement(eleBtn);
			click(eleBtn);
			Log.info("Clicked on button: CPE Status Update");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click on CPE Status Update button " + e.getMessage());
			Assert.fail("Failed to click on CPE Status Update button " + e.getMessage());
		}

	}
}
