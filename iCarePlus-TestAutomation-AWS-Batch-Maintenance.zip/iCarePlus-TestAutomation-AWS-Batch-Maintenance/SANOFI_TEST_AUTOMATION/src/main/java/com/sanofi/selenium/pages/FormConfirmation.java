package com.sanofi.selenium.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;
import com.sanofi.selenium.pages.PSQAPage;


public class FormConfirmation extends Utility_Function {

	public FormConfirmation(WebDriver driver) {
		super(driver);
	}

	PSQAPage psqaPage = new PSQAPage(getWebDriver());
	
	/************* Dynamic Elements ******************************************/

	public static String prevNextButtons = "//*[contains(@class,\"omniscript-button-position\")]//*[text()=\"{0}\"]";

	public static By elePatientSearch = By.xpath("//*[text()='Search']//parent::button");

	public static By eleSelectBtn = By.xpath("//button[@name='select_button']");
	
	public void clicOnFormConfirmation() {
		try {
//			boolean result = getWebDriver().findElement(eleSelectBtn).isDisplayed();
//			if(result) {
//				click(eleSelectBtn);
//				setTimeOut(3000);
//			}
			By eleConfirmButton = getDynamicElement(prevNextButtons, "Ok");
			waitAndVerifyElement(eleConfirmButton);
			scrollToElement(eleConfirmButton);
			clickByJavascript(eleConfirmButton);
			setTimeOut(5000);

			Log.info("Clicked on Confirm Button");
			setTimeOut(3000);
			LoggingInfo("Click on Confirm Button.");
			setTimeOut(15000);
			if(isElementPresent(PSQAPage.elePageTitle)) {
				psqaPage.verifyPSQAPageTitle();
		   		psqaPage.selectReviewOutcome();
		   		psqaPage.selectUpdatedCaseManager();
		   		psqaPage.clickSubmit();
		   		setTimeOut(10000);
			}
		     setTimeOut(10000);
    	//	documentsPage.verifyRecentlyViewDocumentList();
			By btnGlobalSearch = By.xpath("//*[@aria-label='Search' and @type='button']");
			waitAndVerifyElement(btnGlobalSearch);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on Previous Button-" + "Error - " + e.getMessage());
		}
	}

	public void clicOnFormCancellation() {
		try {
			By eleConfirmButton = getDynamicElement(prevNextButtons, "Cancel");
			waitAndVerifyElement(eleConfirmButton);
			click(eleConfirmButton);
			Log.info("Clicked on Next Button");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on Previous Button-" + "Error - " + e.getMessage());
		}
	}

	

	/**
	 * Function: Search Patient on Confirmation page
	 *
	 * @author Anand Pawar
	 
	public void searchPatientConfirmPage() {
		try {

			waitForPageLoaded();
			By searchBtn = By.xpath("//*[text()='Search']//parent::button");
			waitAndVerifyElement(searchBtn);
			scrollToElement(searchBtn);
			click(searchBtn);
			setTimeOut(3000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on next button" + e.getMessage());
			Assert.fail("Failed to click on next button" + e.getMessage());
		}
	}
	*/
	
public void clicOnOKConfirmation() 
	{
		try {
			
			By eleConfirmButton = getDynamicElement(prevNextButtons, "Ok");
			waitAndVerifyElement(eleConfirmButton);
			click(eleConfirmButton);
			setTimeOut(10000);

			Log.info("Clicked on Confirm Button");
			setTimeOut(10000);
			LoggingInfo("Click on Confirm Button.");
			setTimeOut(10000);
			//documentsPage.verifyRecentlyViewDocumentList();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail("Failed to click on Previous Button-" + "Error - " + e.getMessage());
		}
	}



	/**
	 * Function: Search Patient on Confirmation page
	 *
	 * @author Anand Pawar
	 */
	public void searchPatientConfirmPage() {
		try {

			waitForPageLoaded();
			By searchBtn=By.xpath("//*[text()='Search']//parent::button");
			waitAndVerifyElement(searchBtn);
			scrollToElement(searchBtn);
			click(searchBtn);
			setTimeOut(3000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on next button" + e.getMessage());
			Assert.fail("Failed to click on next button" + e.getMessage());
		}
	}


	public void clickOnConfirm() {
		By eleConfirmButton = getDynamicElement(prevNextButtons, "Ok");
		waitAndVerifyElement(eleConfirmButton);
		click(eleConfirmButton);
		setTimeOut(5000);

		Log.info("Clicked on Confirm Button");
		setTimeOut(3000);
		LoggingInfo("Click on Confirm Button.");
		setTimeOut(15000);
	}

}
