package com.sanofi.selenium.constants;

import java.util.ArrayList;
import java.util.Arrays;


public interface APIConstants {

	public static final String constCaseManager = "Frances Egan";
	//URI
	public static final String constIccEnrollmentURIqa2r2 = "https://icareconnect--iccqa2r2.my.salesforce.com/services/apexrest/iCC_EnrollmentCreateAndUpdate";
	//public static final String constIceURIqa2r2 = "https://apidev-eu.sanofi.com:8441/mq/rabbitmq/1.0/icare/publishiccevent?routingKey=icare-external";
	public static final String constIccEnrollmentURI_UAT = "https://icareconnect--iccqa2r2.my.salesforce.com/services/apexrest/iCC_EnrollmentCreateAndUpdate";
	//public static final String constIccEnrollmentURIqa2r2 = "https://icareconnect--iccqa2r2.my.salesforce.com/services/apexrest/iCC_EnrollmentCreateAndUpdate";
	//public static final String constIceURIqa2r2 = "https://apidev-eu.sanofi.com:8441/mq/rabbitmq/1.0/icare/publishiccevent?routingKey=icare-external";

	//public static final String constIceURIUATAssistRX = "https://apiuat-eu.sanofi.com:8442/icare/AssistRx"; // used for UAT
	
//	public static final String constIceURIUATMarketing = "https://apiuat-eu.sanofi.com:8442/icare/marketingLead";

	
	//public static final String constIceURIMarketingQAR3 = "https://apidev-eu.sanofi.com:8441/icare/marketingLead";
	//public static final String constIceURIMarketingUAT = "https://apiuat-eu.sanofi.com:8442/icare/marketingLead";
	public static final String constXrayJIRAEndURI =  "https://xray.cloud.getxray.app/api/v2";
	public static final String constXrayClientID="CF81BC5D8C6C41F797DDDA4ABB39969C";
	public static final String constXrayClientSecret="34a8ff083df3f3ea5c661677e522aa05e3e7790e157f583520728d75ca80160d";
	


	//Key:Value
	public static final String constContentTypeKey = "Content-Type";
	public static final String constContentTypeValue = "application/json";
//	public static final String constUATApiKeyValue = "l7xxa9df46b3e7dd466385f07b2889d0fe95";
	public static final String constApiKey = "apiKey";

	//public static final String constApiKeyValue = "l7xxa9df46b3e7dd466385f07b2889d0fe95"; // used fotr UAT
	//public static final String constApiKeyValue = "l7xx17a2c8ffe8fc4ef6a7985e52ab29b2dc";

	//public static final String constApiKeyValueQAR3 = "l7xx17a2c8ffe8fc4ef6a7985e52ab29b2dc";
//	public static final String constApiKeyValueUAT = "l7xxa9df46b3e7dd466385f07b2889d0fe95";
	

	public static final String constSourceSystemKey = "source-system";
	public static final String constSourceSystemValueToUnsubscribe = "MarketingUnsubscribe";
	public static final String constSourceSystemValueToCreateLead = "MarketingLeads";
	public static final String constBasicAuthKey = "Authorization";


	//public static final String constBasicAuthValue = "Basic SWNhcmU0cm1xOiVxdW03U3JnRG5KPWhLI3k=";
//	public static final String constBasicAuthValueAssistRX = "Basic YXNzaXN0MmlpY3M6V0wqXkpzdU1LbiFGLTlySg==";// used for UAT
	//public static final String constBasicAuthValueAssistRX = "Basic YXNzaXN0MmlpY3M6Lic2W0YqdH5wQHtIJFhaVg==";
//	public static final String constBasicAuthValueMarketing = "Basic aWNhcmU0bWFya2V0bGVhZHM6TWJZIUtETDJNZCNOSjJ4VA==";

	//public static final String constBasicAuthValueAssistRX = "Basic YXNzaXN0MmlpY3M6V0wqXkpzdU1LbiFGLTlySg==";
	//public static final String constBasicAuthValueMarketingQAR3 = "Basic aWNhcmU0bWFya2V0bGVhZHM6JktCZjUjeFBKI1diIWo/IQ==";
	//public static final String constBasicAuthValueMarketingUAT = "Basic aWNhcmU0bWFya2V0bGVhZHM6TWJZIUtETDJNZCNOSjJ4VA==";
	

	//public static final String constBasicAuthValueAssistRX = "Basic YXNzaXN0MmlpY3M6V0wqXkpzdU1LbiFGLTlySg==";
	public static final String constBasicAuthValueMarketingQAR3 = "Basic aWNhcmU0bWFya2V0bGVhZHM6JktCZjUjeFBKI1diIWo/IQ==";
	public static final String constBasicAuthValueMarketingUAT = "Basic aWNhcmU0bWFya2V0bGVhZHM6TWJZIUtETDJNZCNOSjJ4VA==";
	public static final String constAssistRXPatientIdOriginalValue="9BE17E-04-48A8-BC35-769881YY";
	public static final String constAssistRXPatientIdNewValue="8BE17E-04-48A8-BC35-769881YY";
	
	public static final String constOrderShipmentPathParms = "/services/data/v58.0/sobjects/iCC_Shipment__c";
	public static final String constOrderInvoicePathParms = "/services/data/v58.0/sobjects/iCC_Invoice__c";

	public static final String constAnnexusFileName="iCC-Annexus-PREPRD.p12";
	public static final String constTrialCardFileName="iCC-Copay2IICS-PREPRD.p12";
	
	//Disease 
	public static final String constDiseaseValueHB = "Hemophilia B";
	public static final String constDiseaseValueHA = "Hemophilia A";
	public static final String constDiseaseValueCAD = "CAD";
	public static final String constDiseaseValueCABLIVI = "aTTP";
	public static final String constDiseaseValueMPSI = "MPS I";

	//Identifier to not capture screenshot 
	public static final String constNoScreenshot = "Do not capture screenshot.";
	
	//Email
	public static final String constApiEmail = "apitest@gmail.com.invalid";	
	public static final String constantEmail = "apitest@gmail.com";	
	public static final String constEmail = "Email";	
	
	//ONC annuxus API fields constant 
		public static final String constCaseOrigin = "AnnexusHealth";
		public static final String constOriginSource = "Website";
		public static final String constProductValue = "Sarclisa®";
		public static final String constDiseaseValue = "Multiple Myeloma";
		public static final ArrayList<String> constServicesSupportRequestedValue = new ArrayList<>(
			        Arrays.asList("Reimbursement Services","Patient Assistance Program","Copay Assistance Program","General Program Enrollment","QuickStart"));
		public static final ArrayList<String> CommonMarketingFieldItemList = new ArrayList<>(
				Arrays.asList("Therapy Regimen","Interested in learning more?"));
		ArrayList<String> MarketingValuesItemList = new ArrayList<>(
				Arrays.asList("On-Demand","Yes"));
		ArrayList<String> consents = new ArrayList<>(Arrays.asList("ONC HCP Authorization","Commercial Copay"));
		
		public static final ArrayList<String> AnnexusconsentsList = new ArrayList<>(Arrays.asList("ONC HCP Authorization","Commercial Copay","ONC Program Authorization","ONC HIPAA Authorization","ONC Text Messaging Consent"));
}
