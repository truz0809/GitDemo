package com.sanofi.selenium.pages;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.checkerframework.checker.units.qual.A;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class AccountObject extends Utility_Function {

	public AccountObject(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	Actions act = new Actions(getWebDriver());

	String highlightStyle = "background-color: yellow; border: 3px solid red;";
	public static String accountName;
	// public static String accountName1 ;

	/************* Static Elements ******************************************/

	public static String strAccObject = "//*[text()=\"{0}\"]";
	public static String strAccObjectNoRec = "//*[text()=\"{0}\"]//following-sibling::span";
	public static By RelatedTab = By.xpath("//*[@id=\"flexipage_tab__item\"]");
	public static By NavigationMenu = By.xpath("//*[@aria-label='Show Navigation Menu']");
	public static By AccountMenu = By.xpath("//*[text()='Accounts']");
	public static By RecvdDocMenu = By.xpath("(//*[text()='Received Documents'])[2]");
	public static By SearchList = By.xpath("//*[@placeholder='Search this list...']");
	public static By DetailsTab = By.xpath("//*[@id=\"flexipage_tab2__item\"]");
	public static By accRec = By.xpath("(*//a[@class='slds-truncate'])[1]");
	// public static By elePatientHasIns =
	// By.xpath("//lightning-formatted-text[text()='No']");
	public static By eleAuthorizationConsentTitle = By
			.xpath("*//span//child::*[contains(text(), 'Authorization Form Consents (0)')]");
	public static By AuthorizationFormTextMessaging = By.xpath("//*[contains(text(), 'Text Messaging Consent')]");
	public static By AuthorizationFormHIPAA = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[@data-field-name=\"Name\"]//*[contains(text(), 'HIPAA Authorization')]");
	public static By AuthorizationFormPPA = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[@data-field-name=\"Name\"]//*[contains(text(), 'Patient Program Authorization')]");
	public static By HealthConditionRec = By.xpath("//*[starts-with(text(), 'CON-')]//parent::span");
	public static By CareProgEnrolleesRec = By.xpath("(//*[contains(text(), 'DMW EoE : ')])[3]");

	public static By editTypeDSRRecord = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Edit\"]//ancestor::td//preceding-sibling::th[@data-label=\"Name\"]//*[contains(text(),\"DCR\")]//ancestor::a");

	public static By PrefSpecialtyPharmacyChkbox = By
			.xpath("//*[@name='PreferredSpecialtyPharmacy_ICC__c']//parent::span//following-sibling::label");
	public static By DUPIXENTCheckbox = By
			.xpath("//*[@name='DUPIXENTMyWay_ICC__c']//parent::span//following-sibling::label");
	public static By MedicationRequest1 = By.xpath("(//*[starts-with(text(), 'MR-')]//parent::span)[1]");
	public static By MedicationRequest2 = By.xpath("(//*[starts-with(text(), 'MR-')]//parent::span)[2]");
	public static By ConsentExpirationDate = By.xpath(
			"//*[text()='Consent Expiration Date Time']//parent::div//parent::dt//following-sibling::dd//child::div//child::span//child::slot//child::lightning-formatted-text");
	public static By MemberPlanRecordType = By.xpath("(//*[text()='Pharmacy'])[1]");
	public static By eleCCRTitle = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//a//*[@title='Contact Contact Relationships']");
	public static By eleFirstCCR = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),'CCR')])[1]");
	public static By eleMedicationReq = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()='Medication']//parent::div//parent::dt//following-sibling::dd//child::span//child::span)[1]");
	public static By eleContactRelationshipRec = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@title,'Patient')]//ancestor::td//preceding-sibling::th//a");
	public static By eleMemberPlanTitle = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//a//*[@title='Member Plans']");
	public static By MemberMenu = By.xpath("//*[text()='Member Plans']");
	public static By eleFirstMP = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),'TestAutomation Payer pharmacy - ICA-002')])[1]");
	public static By eleConditionCode = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Condition Code\"]//parent::div//parent::dt//following-sibling::dd//child::span//child::span)[2]");
	public static By eleCareProgram = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Care Program Enrollees\"])[1]");
	public static By eleCareProgramEnrollees = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()='Care Program Enrollees'])[1]");
	public static By eleCareProgramEnrolleeRec = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//th//a//slot//*[contains(text(), 'DMW')]");
	public static By eleRecordType = By.xpath(
			"//*[span[text()='Record Type']//parent::div]");
	public static By authConsentLabel = By
			.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='Authorization Form Consents']");
	public static By authConsentTable = By
			.xpath("//*[contains(@class,'active lafPageHost')]//div[contains(@class,'data-table-row tableRow')]");
	public static By healthCondTable = By
			.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='Health Conditions']");
	public static By medicationTable = By
			.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='Medication Requests']");
	public static By memPlanTable = By
			.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='Member Plans' and @title=\"Member Plans\"]");

	public static By recordName = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//th[@data-label=\"Name\"]//a//span[@class=\"slds-truncate\"]//span");
	public static By cpeRecordLink = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//th[@data-label=\"Name\"]//a");
	public static By AccSort = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Account Name\"]//parent::a");
	public static By listViewButton = By.xpath("//*[button[@title=\"Select a List View: Accounts\"]]");
	public static By eleNameList = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//th[contains(@class,\"slds-cell-edit cellContainer\")]//a");
	public static By eleNamesList = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//table[@aria-label='Recently Viewed']");
	public static By elePolicyHolderDOB = By
			.xpath("//*[text()='Policyholder DOB']//parent::div//following-sibling::div//input");
	public static By eleInsuranceDate = By
			.xpath("//*[text()='Insurance Add Date']//parent::div//following-sibling::div//input");

	public static By eleAutomation = By.xpath("(//*[text()='Patient'])[1]");
	public static By eleCPERecord = By.xpath("(//a[contains(@title, 'DMW Asthma')])[1]");
	public static By searchDocInput = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@placeholder=\"Search this list...\"]");
	public static By facilityRec = By.xpath(
			"(//th[@data-label='Account Name']//child::span//child::div//child::lightning-primitive-custom-cell//child::lst-output-lookup//child::force-lookup//child::div//following-sibling::a)[1]");
	public static By eleNew = By.xpath("//*[contains(@class,\"active lafPageHost\")]//a[@title='New']");
	public static By elePatient = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Patient\"]//parent::lightning-formatted-rich-text//parent::span//parent::label//span[@class='slds-radio_faux']");
	public static By eleClearButton = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@title=\"Clear Selection\"]");
	public static By eleErrorMessage = By.xpath("//*[text()=\"You cannot change the Care Program Enrollee Field\"]");
	public static By eleNext = By.xpath("//*[text()='Next']");
	public static By eleClose = By.xpath("//*[@title='Close error dialog']");
	public static By eleCPEPRecord = By
			.xpath("(*//span[contains(text(), 'CPE')])[1]");

	public static By eleSave = By.xpath("//*[text()='Save']");
	public static By eleAddInfo = By.xpath("//*[text()='Additional Document Information']");
	public static By elePhoneError = By
			.xpath("//*[li[contains(text(), 'ACC-VR37: Phone only accepts 10-digit number.')]]");
	public static By eleOtherPhoneError = By
			.xpath("//*[li[contains(text(), 'ACC-VR38: Other Phone only accepts 10-digit number.')]]");
	public static By eleMailingZipError = By
			.xpath("//*[li[contains(text(), 'ACC-VR40: Mailing Zip/Postal Code only accepts 5-digit number.')]]");

	public static String strAccountObjectsCreated1 = "(//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"Health Conditions\")]//following::div[@role=\"grid\"]//div[@role=\"row\" and @data-index=\"0\"]//span)[1]";
	public static By eleAccName = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Account Name\"]//parent::div//following-sibling::div//child::span//child::slot//child::lightning-formatted-name");

	public static By listSort = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Account Name\"]//parent::a");
	public static By accountRecord = By.xpath(
			"//div[contains(@class,\"oneConsoleTabContainer\")]//ul[contains(@class,\"tabBarItems\")]//li[contains(@class,\"slds-has-sub-tabs\")]//a[contains(@title,\"Received Document\")]");
	public static By dsrCHKBox = By.xpath(
			"//*[contains(@class,'active lafPageHost')]//*[text()=\"Add DCR in Progress?\"]//ancestor::span[@class=\"slds-checkbox\"]//input");
	public static By dsrRecord = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//th[@data-label=\"Name\"]//*[contains(text(),\"DCR\")]//ancestor::a");
	public static By eleOfficeContact = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Office Contact\"]//parent::lightning-formatted-rich-text//parent::span//parent::label//span[@class='slds-radio_faux']");
	public static By eleBillingZipError = By
			.xpath("//*[li[contains(text(), 'ACC-VR39: Billing Zip/Postal Code only accepts 5-digit number.')]]");
	public static By dsrAccount = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[@class=\"test-id__field-label\" and text()=\"Account\"]//parent::div//following-sibling::div/span//a//slot//span)[2]");

	public static By eleHealthCode = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@title,\"CON-\")]");
	public static By eleFirstMR = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(@title,\"MR-\")])[1]");
	public static By eleSecondMR = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(@title,\"MR-\")])[2]");
	public static By eleFirstReasonReference = By
			.xpath("(//*[contains(text(),'Reason Reference')])[1]//parent::div//following-sibling::div//a");
	public static By eleSecondReasonReference = By
			.xpath("(//*[contains(text(),'Reason Reference')])[3]//parent::div//following-sibling::div//a");
	public static By eleConsentTitle = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//lightning-formatted-text[@slot=\"primaryField\"]");
	public static By eleHCPSpecialty = By
			.xpath("//*[text()='Prescriber Specialty']//parent::div//following-sibling::div//child::span");
	public static By eleManualOverrideCheckbox = By.xpath(
			"//*[text()='Manual Override Help Info']//parent::button//parent::lightning-button-icon//parent::div//parent::lightning-helptext//following-sibling::div//child::span//child::input");
	public static By eleSaveBtn = By.xpath("//*[@name='SaveEdit']");
	public static By eleLastModDateSort = By.xpath("(//*[@title='Last Modified By'])[2]");
	public static By eleZipCode = By.xpath("//*[text()='Mailing Zip/Postal Code']//following-sibling::div");
	public static By eleEditZipCode = By.xpath("//*[@title='Edit Mailing Address']");
	public static By eleCancelEdit = By.xpath("//*[@name='CancelEdit']");
	public static By elePatientAccHistory = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@title=\"Person Account History\"]");
	public static By eleFirstAccount = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[@title=\"Account Name\"]//ancestor::thead//following-sibling::tbody//th//a)[1]");
	public static By CasesMenu = By.xpath("//*[text()='Cases']");
	public static By eleCaseNumber = By
			.xpath("(//*[@Title='Case Number']//ancestor::thead//following-sibling::tbody//th//a)[1]");
	public static By eleCaseHistory = By.xpath("//*[@Title='Case History']");
	public static By eleFirstRecord = By.xpath("(//*[contains(@class,\"active lafPageHost\")]//tbody//th//a)[1]");
	public static By eleAuditTrailHistory = By.xpath("//*[contains(@title,'History')]");
	public static By eleSelectDropDown = By.xpath("//*[contains(@class,\"active lafPageHost\")]//select");
	public static By eleWinnerPatient = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@placeholder=\"Search Accounts...\"]");
	public static By eleShowMoreResult = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"Show more results for\")]");
	public static By firstRecord = By.xpath("(//th[@data-label=\"Account Name\"]//lightning-base-formatted-text)[1]");
	public static By confirmationMSG = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//div[@id=\"wrapper-body\"]//p");
	public static By eleSelectButton = By.xpath("//*[text()=\"Select\"]");
	public static By eleNextMP = By.xpath("//*[text()='Next']");
	public static By eleEditButton = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Edit\"]");
	public static By searchCodeSets = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@placeholder=\"Search Code Sets...\"]");
	public static By startDate = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Date\"]//parent::label//parent::div//following-sibling::div//input)[1]");
	public static By eleSelectFirstHC = By
			.xpath("//*[text()=\"Select Item 1\"]//parent::label//span[@class=\"slds-radio_faux\"]");
	public static By eleNewCase = By.xpath("(//*[contains(@class,\"active lafPageHost\")]//a[@title='New'])[2]");
	public static By eleNewButton = By.xpath("//*[text()='New']");
	public static By eleNewAccount = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@title=\"New Account\"]");
	public static By eleAccHistory = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@title=\"Account History\"]");
	public static By folderBreadcrumbTitle = By.xpath("//ol[contains(@class, \"folderBreadcrumb\")]/li/span");

	public static By eleMIRec = By.xpath("//span[text()='Patient City']");
	public static By eleEditMI = By.xpath("//*[button[contains(@name, 'Edit')]]");
	public static By eleClearCPMI = By.xpath("(*//button[@title='Clear Selection'])[1]");
	public static By eleCPMISearch = By
			.xpath("//*[input[contains(@placeholder, 'Search Care Program Missing Informations...')]]");
	public static By eleSaveEditBtn = By.xpath("//*[@name='SaveEdit']");
	public static By eleMIError = By.xpath(
			"//*[li[contains(text(), 'There is already an MI Case open for this MI Piece. Please capture details as part of existing MI case.')]]");

	/************* Dynamic Elements ******************************************/

	public static String strDetailsLinkText = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Site\"]//ancestor::records-record-layout-item//a//span)[3]";
	public static String eleTextMessageConsentRow = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-show_inline-block\")]//*[@title=\"{0}\"]";
	public static String strCondCode = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//span//slot//span//child::span//slot//span";
	public static String strAccName = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//span//lightning-formatted-name";
	public static String strAccountObjectDetails = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"label-inline\")]//lightning-formatted-text";
	public static String strAccObjectPhone = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//span//slot//lightning-formatted-phone";
	public static String strAccObjEmail = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//span//lightning-formatted-email";
	public static String strAccObjAddress = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//parent::dt//following-sibling::dd//child::div//child::span//child::slot//child::lightning-formatted-address";
	public static String strAccountObjectsCreated = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]";
	public static String strFields = "//*[text()=\"{0}\"]//parent::div//parent::div//following-sibling::div//lightning-formatted-text";
	public static String strcareProgramEnrolleCheckbox = "(//*[text()=\"{0}\"]//parent::div//parent::div//following-sibling::div//child::label//child::span)[1]";
	public static String strmedication = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//ancestor::dt//following-sibling::dd//a//span//span//slot";
	public static String detailsPageTabsButton = "//*[contains(@class,\"active lafPageHost\")]//li//*[text()=\"{0}\"]";
	public static String authorizationObject = "//*[contains(@class,\"active lafPageHost\")]//*[text()= \"{0}\"]";
	public static String strDocumentPageTitle = "//*[text()=\"{0}\"]//parent::a";
	public static String strRecordName = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-cell-edit cellContainer\")]//*[text()=\"{0}\"]";
	public static String accDetailsLinkField = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-phone/a";
	public static String accDetailsEmail = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//emailui-formatted-email-wrapper//a";
	public static String strAccountRecord = "//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"{0}\")]//ancestor::div[@class=\"slds-grid\"]";
	public static String strCPERecord = "//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"{0}\")]//ancestor::a";
	public static String strRelatedContact = "//*[contains(@class,\"active lafPageHost\")]//td[@data-label=\"Related Contact\"]//a[@title=\"{0}\"]";
	public static String strMemberPlanName = "//*[contains(@class,\"active lafPageHost\")]//td[@data-label=\"Payer\"]//a[@title=\"{0}\"]//ancestor::td//preceding-sibling::th//a";
	public static String strMemPlanName = "//*[contains(@class,\"active lafPageHost\")]//th[@data-label=\"Name\"]//span[contains(text(), \"{0}\")]";
	public static String strMemberplanName = "(//*[contains(@class,\"active lafPageHost\")]//table//tbody//a[contains(text(),\"{0}\")]//ancestor::td//preceding-sibling::th//a)[1]";
	public static String memPlanName = "//*[contains(@class,\"active lafPageHost\")]//table//tbody//a[contains(@title,\"{0}\")]//ancestor::td//preceding-sibling::th//a";
	public static String eleCBFields = "//*[contains(@class,\"active lafPageHost\")]//a//*[@title=\"{0}\"]";
	public static String strAccountObjectFields = "//*[@name=\"{0}\"]";
	public static String strAccountName = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::a";
	public static String editButton = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@title, \"{0}\")]";
	public static String editFieldList = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//button//span[@class=\"slds-truncate\"]";
	public static String editFieldListOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//lightning-base-combobox-item";
	public static String eleButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";
	public static String detailsTitleLinkField = "//*[contains(@class,\"active lafPageHost\")]//p[text()=\"{0}\"]//parent::div//span[@class=\"slds-truncate\"]//slot";
	public static String detailsLinkField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"label-inline\")]//lightning-formatted-text";
	public static String ccrRecord = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::tr//span[contains(text(),\"CCR\")]//ancestor::span[contains(@class,\"align-spread\")]//a";
	public static String compactLayoutLinkField = "//*[contains(@class,\"active lafPageHost\")]//*[@title=\"{0}\"]//ancestor::records-highlights-details-item[@slot=\"secondaryFields\"]//span[@class=\"slds-truncate\"]//slot";
	public static String compactLayoutTextField = "//*[contains(@class,\"active lafPageHost\")]//*[@title=\"{0}\"]//parent::div//parent::records-highlights-details-item//lightning-formatted-text";
	public static String accDetailsLink = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//a";
	public static String strPatientFirstName = "//*[text()=\"Patient First Name\"]//ancestor::dt//following-sibling::dd//*[text()=\"{0}\"]";
	public static String strPatientLastName = "//*[text()=\"Patient Last Name\"]//ancestor::dt//following-sibling::dd//*[text()=\"{0}\"]";
	public static String strPatientEmail = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//span//lightning-formatted-email";
	public static String strPatientDOB = "//*[text()=\"Patient Date of Birth\"]//ancestor::dt//following-sibling::dd//*[text()=\"{0}\"]";
	public static String strDocInfo = "//*[text()=\"{0}\"]";
	public static String eleShowActionsBtn = "//a[@title=\"{0}\"]";
	public static String strButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";
	public static By eleSelectFirstRecord = By
			.xpath("//*[text()=\"Select Item 1\"]//parent::label//span[@class=\"slds-radio_faux\"]");
	public static String radioBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::label//span[@class=\"slds-radio_faux\"]";
	public static String strCommanRecordName = "//*[contains(@class,\"active lafPageHost\")]//th[contains(@data-label, \"Name\")]//span[contains(text(), \"{0}\")]";
	public static String strDropDownBoxOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[@part=\"combobox\"]//lightning-base-combobox-item//span[@class=\"slds-media__body\"]//span";
	public static String strDropDownBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//button";
	public static String strNewButton = "//*[@title=\"{0}\"]//ancestor::div[@class=\"slds-col slds-has-flexi-truncate firstHeaderRow\"]//following-sibling::div[2]//div[@title=\"New\"]";
	public static String strCPEReadOnlyFields = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::dt//following-sibling::dd//span[contains(@class, \"test-id__field-value\") and contains(@class, \"is-read-only\")]";
	public static String strCPEEditFields = "//*[contains(@class,\"active lafPageHost\")]//*[@title=\"{0}\" and contains(@class, \"edit-trigger\")]";
	public static String strAuthorizationFormStatusValue = "//*[@aria-label=\"{0}\"]";
	public static String strStatusListValue = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[text()=\"{1}\"]";
	public static String serachDropDownListBox = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"test-id\")]//*[text()=\"{0}\"]//following-sibling::div//input";
	public static String strSearchDropDownOptions1 = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"test-id\")]//li//span[contains(@class,\"option-text\")]//lightning-base-combobox-formatted-text";
	public static String searchDropDownListBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//following-sibling::div//lightning-base-combobox//button";
	public static String detailFields = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//span//lightning-formatted-text";
	public static String eleInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[@name=\"{0}\"]";
	public static String newAccountRadioBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::label//input//following-sibling::span";
	public static String button2 = "//*[contains(@class,\"active lafPageHost\")]//a[@title=\"{0}\"]";
	public static String strrecordName = "//*[contains(@class, \"active lafPageHost\")]//*[contains(text(), \"{0}\")]//ancestor::a";
	public static String actHistory = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@title,\"{0}\")]";
	public static String result = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strTextBoxesInput = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//following-sibling::div//input";
	public static String strTextBoxesInput2 = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//following-sibling::div//input)[2]";
	public static String ele = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"slds-form-element\")]//lightning-formatted-text";
	public static String strMasterRec = "//*[contains(@class,\"active lafPageHost\")]//table//tbody//th//a//span[text()=\"{0}\"]";
	public static String eleConsent = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"data-table-row tableRow\")]//ancestor::div//following-sibling::div//*[contains(text(),\"Withdrawn\")]//ancestor::div//preceding-sibling::div[@data-label=\"Name\"]//*[contains(text(),\"{0}\")]";
	public static String dashboardTablist = "//*[contains(@class,\"active lafPageHost\")]//ul[@role=\"tablist\"]//li/a[text()=\"{0}\"]";
	public static String tablistEle = "//div[@role=\"navigation\" and @aria-label=\"Workspaces\"]//a[@role=\"tab\"]/span[contains(text(),\"{0}\")]";
	public static By eleCPEStatusButton = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//button[contains(text(),'CPE Status Update')]");
	public static String eleReport = "//a[contains(text(),\"{0}\")]";
	public static String eleReport2 = "//*[contains(text(),\"{0}\")]//parent::a";

	String strInputText = "//*[contains(@class,\"active lafPageHost\")]//label[text()=\"{0}\"]//following-sibling::div//input[@name=\"ConsentExpirationDateTime\"]";

	public static String eleARStamp = "//h1//*[contains(text(),\"{0}\")]";

	public static String eleRow = "//div[@role=\"rowgroup\"]//*[contains(text(),\"{0}\")]";

	public static String strlinkfieldInputBox = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//span/slot//*[@slot=\"output\"]//a//span)[3]";
	public static By RelatedTabAcc = By.xpath("//*[@id=\"relatedListsTab__item\" and @data-label='Related']");
	public static String strCPEObjectsCreated = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]";

	public void navigateToToAccDetails() {

		waitAndVerifyElement(NavigationMenu);
		click(NavigationMenu);
		click(AccountMenu);
		setTimeOut(2000);

		click(SearchList);
		setTimeOut(1000);
		inputText(SearchList, accountName);
		genericKeyPress(SearchList, "Enter");
		waitAndVerifyElement(accRec);
		setTimeOut(5000);
		click(accRec);

		setTimeOut(2000);
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		setTimeOut(2000);
	}

	/*
	 * @author - Anand Pawar
	 * 
	 * Function - Validate Medication Request
	 */

	public void validateMRFromCPE(String dose1, String dose2) {
		try {
			By MR1 = By
					.xpath("(//*[contains(@class, 'active lafPageHost')]//*[@data-label=\"MedicationName\"]//span)[1]");
			scrollToElement(MR1);
			String actual = getText(MR1);
			highLightElement(MR1);
			if (actual.equalsIgnoreCase(dose1) || actual.equalsIgnoreCase(dose2)) {
				LoggingInfo("MR1 validated successfully");
			}

			By MR2 = By
					.xpath("(//*[contains(@class, 'active lafPageHost')]//*[@data-label=\"MedicationName\"]//span)[2]");
			scrollToElement(MR2);
			String actual2 = getText(MR2);
			highLightElement(MR2);
			if (actual2.equalsIgnoreCase(dose1) || actual2.equalsIgnoreCase(dose2)) {
				LoggingInfo("MR2 validated successfully");
			}

		} catch (Exception e) {
			Log.error("Failed to validate MR details" + e.getMessage());
			Assert.fail("Failed to validate MR details" + e.getMessage());
		}
	}

	/*
	 * @Author - Anand Pawar
	 */
	public void validateHealthConditionsFromCPE(String conditionCode) {
		try {
			By hc = By.xpath("//*[contains(@class, 'active lafPageHost')]//*[@data-label=\"HealthCondition\"]//span");
			String actual = getText(hc);
			Assert.assertEquals(conditionCode, actual);
			highLightElement(hc);

			LoggingInfo("validated Health Condition Code");

		} catch (Exception e) {
			Log.error("Failed to validate Health Conditions details" + e.getMessage());
			Assert.fail("Failed to validate Health Conditions details" + e.getMessage());
		}
	}

	/*
	 * @Author - Anand Pawar
	 */
	public void validateMRFromCPENoRecord() {
		try {
			By hc = By.xpath(
					"//*[contains(@class, 'active lafPageHost')]//*[@data-label=\"MedicationName\"]//*[@title=\"undefined\"]");
			highLightElement(hc);

			LoggingInfo("validated MR Record is blank");

		} catch (Exception e) {
			Log.error("Failed to validate MR   details" + e.getMessage());
			Assert.fail("Failed to validate MR   details" + e.getMessage());
		}
	}

	/*
	 * @Author - Anand Pawar
	 */
	public void validateHealthConditionsFromCPENoRecord() {
		try {
			By hc = By.xpath(
					"//*[contains(@class, 'active lafPageHost')]//*[@data-label=\"HealthCondition\"]//*[@title=\"undefined\"]");
			highLightElement(hc);

			LoggingInfo("validated Health Condition Code is blank");

		} catch (Exception e) {
			Log.error("Failed to validate Health Conditions details" + e.getMessage());
			Assert.fail("Failed to validate Health Conditions details" + e.getMessage());
		}
	}

	// Anand P
	public void searchAccAndClick(String accName) {
		try {
			click(SearchList);
			setTimeOut(1000);
			inputText(SearchList, accName);
			genericKeyPress(SearchList, "Enter");
			waitAndVerifyElement(accRec);
			setTimeOut(2000);
			click(listSort);
			setTimeOut(3000);
			click(accRec);
			setTimeOut(4000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Function: Search and open Required Record by providing Search Filter using
	 * GlobalSearch SearchFilter: Account, Cases,Care Program Enrollee....
	 * SearchValue: Record/Account/Case name to be searched....
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void globalSearch(String SearchFilter, String SearchValue) {
		try {
			waitForPageLoaded();
			setTimeOut(7000);
			By btnGlobalSearch = By.xpath("//*[@aria-label='Search' and @type='button']");
			waitAndVerifyElement(btnGlobalSearch);
			clickByJavascript(btnGlobalSearch);
			setTimeOut(3000);

			By eleSearchFilter = By.xpath("//div[@part='input-text']//*[contains(@data-value,'Search:')]");
			waitAndVerifyElement(eleSearchFilter);
			clickByJavascript(eleSearchFilter);
			setTimeOut(3000);

			String strFilterValue = "//ul[@aria-label='All Searchable Items']//li//span[@title='%s']//ancestor::lightning-base-combobox-item";
			String xp = String.format(strFilterValue, SearchFilter);
			By eleSearchFilterValue = By.xpath(xp);
			scrollToElement(eleSearchFilterValue);
			highLightElement(eleSearchFilterValue);
			setTimeOut(4000);
			click(eleSearchFilterValue);
			setTimeOut(4000);

			Actions act = new Actions(getWebDriver());
			By eleSearchInput = By.xpath(
					"//lightning-input[@class='saInput slds-grow slds-form-element']//div[@part='input-text']//label[contains(text(),'Search')]//following-sibling::div//input");
			act.sendKeys(Keys.TAB).perform();
			setTimeOut(3000);
			inputText(eleSearchInput, SearchValue);
			setTimeOut(4000);

			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(4000);

			// Verify Search result
			// String result="//*[contains(@class,\"active
			// lafPageHost\")]//*[text()=\"{0}\"]";
			By eleRecordName = getDynamicElement(result, SearchValue);
			waitAndVerifyElement(eleRecordName);

			LoggingInfo("Opened " + SearchValue + " successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to search " + SearchValue + " " + e.getMessage());
		}
	}

	public void navigateToAccountAutomation() {
		try {
			By eleAccount = By.xpath(
					"(//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"Automation\")]//ancestor::a)[1]");
			waitAndVerifyElement(eleAccount);
			clickByJavascript(eleAccount);
			setTimeOut(2000);
			LoggingInfo("clicked on Account successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Account" + e.getMessage());
			Assert.fail("Failed to  click on Account" + e.getMessage());

		}
	}

	public void globalSearchNormal(String SearchFilter, String SearchValue) {
		try {
			waitForPageLoaded();
			setTimeOut(7000);
			By btnGlobalSearch = By.xpath("//*[@aria-label='Search']");
			waitAndVerifyElement(btnGlobalSearch);
			clickByJavascript(btnGlobalSearch);
			setTimeOut(3000);

			By eleSearchFilter = By.xpath("//div[@part='input-text']//*[contains(@data-value,'Search:')]");
			waitAndVerifyElement(eleSearchFilter);
			clickByJavascript(eleSearchFilter);
			setTimeOut(3000);

			String strFilterValue = "//ul[@aria-label='All Searchable Items']//li//span[@title='%s']//ancestor::lightning-base-combobox-item";
			String xp = String.format(strFilterValue, SearchFilter);
			By eleSearchFilterValue = By.xpath(xp);
			scrollToElement(eleSearchFilterValue);
			highLightElement(eleSearchFilterValue);
			setTimeOut(4000);
			click(eleSearchFilterValue);
			setTimeOut(4000);

			Actions act = new Actions(getWebDriver());
			By eleSearchInput = By.xpath(
					"//*[@class='saInput slds-grow slds-form-element']//div[@part='input-text']//*[contains(text(),'Search')]//following-sibling::div//input");
			act.sendKeys(Keys.TAB).perform();
			setTimeOut(3000);
			inputText(eleSearchInput, SearchValue);
			setTimeOut(4000);

			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(4000);

			LoggingInfo("Opened " + SearchValue + " successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to search " + SearchValue + " " + e.getMessage());
		}
	}

	public void searchHCPAndClick(String hcp) {
		try {
			click(SearchList);
			setTimeOut(1000);
			inputText(SearchList, hcp);
			genericKeyPress(SearchList, "Enter");
			waitAndVerifyElement(accRec);
			setTimeOut(2000);
			click(listSort);
			setTimeOut(2000);
			click(accRec);
			setTimeOut(4000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// To navigate to Account object
	public void NavigateToAccObject(String patientName, String DateofBirth, String gender, String Phone, String email,
			String address, String patientHasInsurance, String Lang, String city, String state, String zip) {

		try {
			accountName = patientName;
			setTimeOut(5000);
			refresh();
			clickOnTab(tabsName.get(0));
			setTimeOut(2000);

			By AccountNameDetailsTab = getDynamicElement(strAccName, "Account Name");
			String constAccountName = getText(AccountNameDetailsTab);

			verifyDetails(AccountNameDetailsTab, patientName, "Account Name");

			By accObjectGender = getDynamicElement(strAccountObjectDetails, "Gender");
			verifyDetails(accObjectGender, gender, "Gender");

			By accObjectOtherPhone = getDynamicElement(strAccObjectPhone, "Other Phone");
			verifyDetails(accObjectOtherPhone, Phone, "Phone");

			By accObjEmail = getDynamicElement(strAccObjEmail, "Email");
			verifyDetails(accObjEmail, email, "Email");

			By accObjPrefLang = getDynamicElement(strAccountObjectDetails, "Preferred Language");
			verifyDetails(accObjPrefLang, Lang, "Preferred Language");

			setTimeOut(4000);
			accountObject.clickOnTab(tabsName.get(1));
			setTimeOut(2000);
			LoggingInfo("Click on Related Tab section");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify element " + e.getMessage());
		}

	}

	public void verifyConsentExpiryDate(String state, String PatientDOB, String AuthorizationDate) {

		try {
			setTimeOut(8000);
			clickByJavascript(RelatedTab);
			scrollToDocumentHeight();
			setTimeOut(1000);
			// waitAndVerifyElement(AuthorizationFormTextMessaging);
			// waitAndVerifyElement(AuthorizationFormHIPAA);
			LoggingInfo("Verify Authorization Form for Text Messaging and HIPAA Form");

			SoftAssert softAssert = new SoftAssert();

			refresh();
			setTimeOut(5000);
			clickByJavascript(RelatedTab);
			scrollToDocumentHeight();
			setTimeOut(1000);

			// String consentTextMsg = getText(AuthorizationFormTextMessaging);
			Boolean isPresent = getWebDriver()
					.findElements(By.xpath("//span[contains(text(), 'Text Messaging Consent')]")).size() > 0;
			Boolean iPresent1 = getWebDriver().findElements(By.xpath("//span[contains(text(), 'HIPAA Authorization')]"))
					.size() > 0;
			Boolean isPresent2 = getWebDriver()
					.findElements(By.xpath("//span[contains(text(), 'Patient Program Authorization')]")).size() > 0;
			//

			// AuthorizationFormConsent

			try {
				if (isPresent) {

					clickByJavascript(AuthorizationFormPPA);
					setTimeOut(5000);
					LoggingInfo("Clicks on Authorization Form for Text messaging");

					By ConsentExpiryDate = getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time");

					// To split it into date and time
					String cExpiryDt = getText(ConsentExpiryDate);
					String[] date = cExpiryDt.split(",");
					String consentExpDate = date[0];

					ConsentExpiryDate expDate = new ConsentExpiryDate();

					LocalDate PatientConsentDate = expDate.PPAConsentExpiryDate(state, PatientDOB, AuthorizationDate);
					String updatedPatientConsentDate = PatientConsentDate.toString();

					String consentExpDateUI = Utility_Function.changeFormatDate(consentExpDate);

					// comparison method

					if (consentExpDateUI.equalsIgnoreCase(updatedPatientConsentDate)) {
						System.out.println("Consent expiry date matches " + consentExpDateUI);
					} else {
						System.out.println("Consent expiry date does not match " + " actual " + consentExpDateUI + ","
								+ " expected " + updatedPatientConsentDate);
					}

				}
			} catch (Exception e) {
				softAssert.fail("No consent found");
			}

			navigateToToAccDetails();
			setTimeOut(3000);
			clickByJavascript(RelatedTab);
			scrollToDocumentHeight();
			setTimeOut(2000);

			if (iPresent1) { // HIPAA
				setTimeOut(2000);
				clickByJavascript(AuthorizationFormHIPAA);
				setTimeOut(2000);
				LoggingInfo("Clicks on Authorization Form for HIPAA");

				By ConsentHipaaExpiryDate = getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time");

				// To split it into date and time
				String cExpiryDtH = getText(ConsentHipaaExpiryDate);
				String[] dateH = cExpiryDtH.split(",");
				String consentExpDateH = dateH[0];

				ConsentExpiryDate expDate = new ConsentExpiryDate();

				LocalDate PatientConsentDateH = expDate.HIPAAConsentExpiryDate(state, PatientDOB, AuthorizationDate);
				String updatedPatientConsentDateHIPAA = PatientConsentDateH.toString();

				String consentExpiryDateUIHIPAA = Utility_Function.changeFormatDate(consentExpDateH);

				// comparison method
				if (consentExpiryDateUIHIPAA.equalsIgnoreCase(updatedPatientConsentDateHIPAA)) {
					System.out.println("Consent expiry date matches " + consentExpiryDateUIHIPAA);
				} else {
					System.out.println("Consent expiry date does not match " + " actual " + consentExpiryDateUIHIPAA
							+ "," + " expected " + updatedPatientConsentDateHIPAA);
				}

				// back to account page
				setTimeOut(4000);
				navigateToToAccDetails();
				setTimeOut(4000);
				clickByJavascript(RelatedTab);
				setTimeOut(2000);
				scrollToDocumentHeight();
				setTimeOut(2000);

			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Authorization Form Consent verification failed " + e.getMessage());
			Assert.fail("Authorization Form Consent verification failed" + ". Error - " + e.getMessage());
		}

	}

	public void verifyHIPAAConsentDate(String state, String patientDOB, String authorizationDate) {
		try {
			boolean isHIPAAPresent = getWebDriver()
					.findElements(By.xpath("//span[contains(text(), 'HIPAA Authorization')]")).size() > 0;
			Log.info("HIPAA Consent Date verification");

			if (isHIPAAPresent) {

				scrollToElement(AuthorizationFormHIPAA);
				clickByJavascript(AuthorizationFormHIPAA);

				// waitAndVerifyElement(AuthorizationFormHIPAA);

				String consentExpiryDateTime = getText(
						getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time"));
				String[] dateAndTime = consentExpiryDateTime.split(",");
				String consentExpiryDate = dateAndTime[0];

				LocalDate calculatedConsentExpiryDate = new ConsentExpiryDate().HIPAAConsentExpiryDate(state,
						patientDOB, authorizationDate);
				String formattedCalculatedConsentExpiryDate = formatDatemmdyyyy(calculatedConsentExpiryDate.toString());
				String consentExpiryDateUI = Utility_Function.changeFormatDate2(consentExpiryDate);

				if (consentExpiryDateUI.equalsIgnoreCase(formattedCalculatedConsentExpiryDate)) {
					Assert.assertTrue(true, "Consent expiry Date matches. Actual Value: " + consentExpiryDateUI
							+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
					LoggingInfo("Consent expiry Date matches. Actual Value: " + consentExpiryDateUI
							+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
				} else {
					Assert.fail("Consent expiry date does not match. Actual: " + consentExpiryDateUI + ", Expected: "
							+ formattedCalculatedConsentExpiryDate);
					LoggingInfo("Consent expiry Date does not match. Actual Value: " + consentExpiryDateUI
							+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
				}
			} else {
				Assert.fail("HIPAA Consent object not found");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Verification of HIPPA consent is failed" + e.getMessage());
		}
	}

	// Consent expiration date calculation if State/Address is missing for HIPPA
	public void verifyConsentDateHippa(String consentCapExcelDate) {

		setTimeOut(5000);
		clickOnTab(tabsName.get(1));
		scrollToBottomOfPage();
		setTimeOut(3000);
		clickByJavascript(AuthorizationFormHIPAA);
		setTimeOut(2000);
		LoggingInfo("Clicks on Authorization Form for HIPAA");
		By ConsentHipaaExpiryDate = getDynamicElement(strAccountObjectDetails, "Consent Capture Date");
		waitAndVerifyElement(ConsentHipaaExpiryDate);
		// To split it into date and time
		String consentexpirationDateHippa = getText(ConsentHipaaExpiryDate);
		String[] consentDateHippa = consentexpirationDateHippa.split(",");
		String consentExpAppDate = consentDateHippa[0]; // App Data Consent Captured

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
		LocalDate excelConsentDate = LocalDate.parse(consentCapExcelDate, formatter);
		LocalDate appConsentCapturedDate = LocalDate.parse(consentExpAppDate, formatter);

		LocalDate excelCapturedDate = excelConsentDate;
		LocalDate ConsentExpDate = appConsentCapturedDate.plusDays(180);

		String formattedExcelCapturedDate = excelCapturedDate.format(formatter);
		String formattedConsentExpiryAppData = ConsentExpDate.format(formatter);

		if (formattedExcelCapturedDate.equalsIgnoreCase(consentExpAppDate)) {
			System.out.println("Consent Captured Date matches" + " Actual Data- " + consentExpAppDate
					+ "   Expected Data - " + formattedExcelCapturedDate);
			LoggingInfo("Consent Captured Date matches " + "Actual Data- " + consentExpAppDate + "   Expected Data - "
					+ formattedExcelCapturedDate);
		} else {
			LoggingInfo("Consent Captured Date doesn't matches " + "Actual Data- " + consentExpAppDate
					+ "   Expected Data - " + formattedExcelCapturedDate);
			Assert.fail("Consent Captured Date doesn't matches" + "Actual - " + consentExpAppDate + "Expected - "
					+ formattedExcelCapturedDate);
		}

		By ConsentHipaaCapturedDate = getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time");

		// To split it into date and time
		String consentCapturedDateHippa = getText(ConsentHipaaCapturedDate);
		String[] consentCaptureDateHippa = consentCapturedDateHippa.split(",");
		String consentExpiryAppDate = consentCaptureDateHippa[0];

		if (formattedConsentExpiryAppData.equalsIgnoreCase(consentExpiryAppDate)) {
			System.out.println("Consent Expiry Date matches" + "  Actual Data -" + consentExpiryAppDate
					+ "Expected Data -" + formattedConsentExpiryAppData);
			LoggingInfo("Consent Expiry Date matches" + "  Actual Data -" + consentExpiryAppDate + "Expected Data -"
					+ formattedConsentExpiryAppData);
		} else {
			System.out.println("Consent Expiry Date doesn't matches" + "  Actual Data -" + consentExpiryAppDate
					+ "Expected Data -" + formattedConsentExpiryAppData);
			LoggingInfo("Consent Expiry Date doesn't matches" + "  Actual Data -" + consentExpiryAppDate
					+ "Expected Data -" + formattedConsentExpiryAppData);
			Assert.fail("Consent Expiry Date doesn't matches" + "  Actual Data -" + consentExpiryAppDate
					+ "Expected Data -" + formattedConsentExpiryAppData);
		}

		navigateToAccountAutomation();
		setTimeOut(4000);

	}

	// Consent expiration date calculation if State/Address is missing for PPA
	public void verifyConsentDatePpa(String consentCapExcelDate) throws InterruptedException {

		setTimeOut(5000);
		clickOnTab(tabsName.get(1));
		setTimeOut(3000);
		scrollToElement(AuthorizationFormPPA);
		clickByJavascript(AuthorizationFormPPA);
		setTimeOut(2000);
		LoggingInfo("Clicks on Authorization Form for PPA");

		By ConsentHipaaExpiryDate = getDynamicElement(strAccountObjectDetails, "Consent Capture Date");
		waitAndVerifyElement(ConsentHipaaExpiryDate);
		// To split it into date and time
		String consentexpirationDateHippa = getText(ConsentHipaaExpiryDate);
		String[] consentDateHippa = consentexpirationDateHippa.split(",");
		String consentExpAppDate = consentDateHippa[0]; // App Data Consent Captured

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
		LocalDate excelConsentDate = LocalDate.parse(consentCapExcelDate, formatter);
		LocalDate appConsentCapturedDate = LocalDate.parse(consentExpAppDate, formatter);

		LocalDate excelCapturedDate = excelConsentDate;
		LocalDate ConsentExpDate = appConsentCapturedDate.plusDays(180);

		String formattedExcelCapturedDate = excelCapturedDate.format(formatter);
		String formattedConsentExpiryAppData = ConsentExpDate.format(formatter);

		if (formattedExcelCapturedDate.equalsIgnoreCase(consentExpAppDate)) {
			System.out.println("Consent Captured Date matches" + " Actual Data- " + consentExpAppDate
					+ "   Expected Data - " + formattedExcelCapturedDate);
			LoggingInfo("Consent Captured Date matches " + "Actual Data- " + consentExpAppDate + "   Expected Data - "
					+ formattedExcelCapturedDate);
		} else {
			LoggingInfo("Consent Captured Date doesn't matches " + "Actual Data- " + consentExpAppDate
					+ "   Expected Data - " + formattedExcelCapturedDate);
			Assert.fail("Consent Captured Date doesn't matches" + "Actual - " + consentExpAppDate + "Expected - "
					+ formattedExcelCapturedDate);
		}

		By ConsentHipaaCapturedDate = getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time");

		// To split it into date and time
		String consentCapturedDateHippa = getText(ConsentHipaaCapturedDate);
		String[] consentCaptureDateHippa = consentCapturedDateHippa.split(",");
		String consentExpiryAppDate = consentCaptureDateHippa[0];

		if (formattedConsentExpiryAppData.equalsIgnoreCase(consentExpiryAppDate)) {
			System.out.println("Consent Expiry Date matches" + "  Actual Data -" + consentExpiryAppDate
					+ "Expected Data -" + formattedConsentExpiryAppData);
			LoggingInfo("Consent Expiry Date matches" + "  Actual Data -" + consentExpiryAppDate + "Expected Data -"
					+ formattedConsentExpiryAppData);
		} else {
			System.out.println("Consent Expiry Date doesn't matches" + "  Actual Data -" + consentExpiryAppDate
					+ "Expected Data -" + formattedConsentExpiryAppData);
			LoggingInfo("Consent Expiry Date doesn't matches" + "  Actual Data -" + consentExpiryAppDate
					+ "Expected Data -" + formattedConsentExpiryAppData);
			Assert.fail("Consent Expiry Date doesn't matches" + "  Actual Data -" + consentExpiryAppDate
					+ "Expected Data -" + formattedConsentExpiryAppData);
		}
	}

	public void verifyCareProgramEnrollees(String preferredSpecialtyPharmacy, String dUPIXENTMyWay) {

		try {
			setTimeOut(3000);
			accountObject.clickOnTab(tabsName.get(1));

			setTimeOut(2000);
			scrollToElement(eleCareProgramEnrollees);
			clickByJavascript(eleCareProgramEnrollees);
			setTimeOut(4000);
			LoggingInfo("Clicked on CareProgramEnrollees");

			refresh();
			setTimeOut(3000);
			click(eleCareProgramEnrolleeRec);
			setTimeOut(4000);
			LoggingInfo("Clicks on Care Program Enrollees record");

			// Verify Preferred Specialty Pharmacy checkbox
			// utilityPage.isCheckboxSelected(PrefSpecialtyPharmacyChkbox);

			LoggingInfo("Verify Preferred Specialty Pharmacy checkbox");
			By prefferedSpecialityPharmacyCheckbox = getDynamicElement(strcareProgramEnrolleCheckbox,
					"Preferred Specialty Pharmacy");
			waitAndVerifyElement(prefferedSpecialityPharmacyCheckbox);
			verifySoftAssertCheckBox(prefferedSpecialityPharmacyCheckbox, preferredSpecialtyPharmacy,
					"Preffered Speciality Pharmacy Checkbox");

			LoggingInfo("Verify DUPIXENT checkbox");
			By dupixentPharmacyCheckbox = getDynamicElement(strcareProgramEnrolleCheckbox, "DUPIXENT MyWay");
			waitAndVerifyElement(prefferedSpecialityPharmacyCheckbox);
			verifySoftAssertCheckBox(dupixentPharmacyCheckbox, dUPIXENTMyWay, "Preffered Speciality Pharmacy Checkbox");

			setTimeOut(4000);
			navigateToAccountAutomation();
			setTimeOut(4000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("CCR Title verification failed " + e.getMessage());
			Assert.fail("CCR Title verification failed" + ". Error - " + e.getMessage());
		}

	}

	public void verifyHealthCondition(String diagnosisCode) {

		try {

			setTimeOut(3000);

			clickOnTab(tabsName.get(1));
			navigateToHealthConditions();
			By healthConditionsRecAccObject = getDynamicElement(strAccountObjectsCreated1, "Health Conditions");
			scrollToElement(healthConditionsRecAccObject);
			// String healthNullRecords = getText(healthConditionsRecAccObject);
			String attributeValue = getAttributeValue(healthConditionsRecAccObject, "title");
			// strAccObjectNoRec1.getAttribute(attributeValue);

			// if(healthNullRecords.equalsIgnoreCase("(0)")) {
			// setTimeOut(1000);
			// LoggingInfo("Successfully verified Health Condition object with no records");
			if (attributeValue.equalsIgnoreCase("undefined")) {
				setTimeOut(1000);
				LoggingInfo("Successfully verified Health Condition object with no records");

			} else {
				setTimeOut(2000);
				LoggingInfo("Successfully verified Health Conditions object with records");
				setTimeOut(2000);
				By healthCond = getDynamicElement(strAccountObjectsCreated1, "Health Conditions");
				scrollToElement(healthCond);
				clickByJavascript(healthCond);
				setTimeOut(2000);
				LoggingInfo("Clicked on Health conditions section");
				refresh();
				waitAndVerifyElement(HealthConditionRec);
				scrollToElement(HealthConditionRec);
				click(HealthConditionRec);
				setTimeOut(2000);
				LoggingInfo("Clicks on Health Conditions record");
				// verifyDetails(eleConditionCode, diagnosisCode, "DiagnosisCode");

				By condCode = getDynamicElement(strCondCode, "Condition Code");
				verifyDetails(condCode, diagnosisCode, "Diagnosis Code");

				navigateToAccount();
				// accountObject.verifyAndClickOnRecord(ExcelTestData.get(patientName));
				setTimeOut(4000);
				// navigateToToAccDetails();
				// navigateToAccDetails();
				// setTimeOut(5000);

			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("CCR Title verification failed " + e.getMessage());
			Assert.fail("CCR Title verification failed" + ". Error - " + e.getMessage());
		}

	}

	public void VerifyMedicationRecord(String prescription5a, String prescription5b) {
		setTimeOut(3000);
		clickByJavascript(RelatedTab);

		By medicationReq = getDynamicElement(strAccountObjectsCreated, "Medication Requests");
		clickByJavascript(medicationReq);
		setTimeOut(2000);
		LoggingInfo("Clicks on Medication Requests section");
		refresh();
		setTimeOut(3000);

		waitAndVerifyElement(MedicationRequest1);
		click(MedicationRequest1);
		setTimeOut(2000);

		By medicationRequest1 = getDynamicElement(strmedication, "Medication");
		waitAndVerifyElement(medicationRequest1);
		verifySoftAssertCheckBox(medicationRequest1, prescription5a, "Prescription 5A");
		setTimeOut(5000);

		back();
		setTimeOut(4000);
		refresh();
		setTimeOut(2000);

		waitAndVerifyElement(MedicationRequest2);
		click(MedicationRequest2);
		setTimeOut(2000);

		By PrescriptionDose5B = getDynamicElement(strmedication, "Medication");
		waitAndVerifyElement(PrescriptionDose5B);
		verifySoftAssertCheckBox(PrescriptionDose5B, prescription5b, "Prescription 5B");
		setTimeOut(5000);
		navigateToToAccDetails();
		setTimeOut(4000);
	}

	public void verifyAndClickOnCCR() {

		try {
			setTimeOut(2000);
			scrollToElement(eleCCRTitle);
			waitAndVerifyElement(eleCCRTitle);
			LoggingInfo("CCR Title is loaded");
			clickByJavascript(eleCCRTitle);
			LoggingInfo("First CCR  is clicked");
			setTimeOut(2000);
			clickByJavascript(eleContactRelationshipRec);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("CCR Title verification failed " + e.getMessage());
			Assert.fail("CCR Title verification failed" + ". Error - " + e.getMessage());
		}

	}

	public void verifyCCR(String relationship) {
		try {
			setTimeOut(1000);
			Log.info("Verify Relationship is Present");
			By eleRelationship = getDynamicElement(strFields, "Relationship");
			String newRelationShip = "Patient-" + relationship;
			waitAndVerifyElement(eleRelationship);
			verifyDetails(eleRelationship, newRelationShip, "Relationship");
			LoggingInfo("Relationship is verified");
			setTimeOut(1000);
			setTimeOut(4000);
			navigateToAccountAutomation();
			setTimeOut(4000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Relationship verification failed " + e.getMessage());
			Assert.fail("Relationship verification failed  " + e.getMessage());

		}

	}

	public void verifyAndClickOnMemberPlan() {

		try {
			setTimeOut(3000);
			accountObject.clickOnTab(tabsName.get(1));
			scrollToHalfPage();
			waitAndVerifyElement(eleMemberPlanTitle);
			LoggingInfo("Member Plan Title is loaded");
			clickByJavascript(eleMemberPlanTitle);
			LoggingInfo("Member Plan  is clicked");
			setTimeOut(3000);
			refresh();
			setTimeOut(1000);
			waitAndVerifyElement(eleFirstMP);
			clickByJavascript(eleFirstMP);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Member plan title verification failed " + e.getMessage());
			Assert.fail("Member plan title verification failed" + ". Error - " + e.getMessage());
		}
	}

	public void verifyRecordType(String recordType) {
		try {
			setTimeOut(2000);
			Log.info("Verify Record type is Present");
			waitAndVerifyElement(eleRecordType);
			verifyDetails(eleRecordType, recordType, "Record Type");
			LoggingInfo("Record Type is verified");
			navigateToToAccDetails();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Record Type verification failed " + e.getMessage());
			Assert.fail("Record Type verification failed  " + e.getMessage());
		}
	}

	public void verifyAccountObjectsHasNoRecords(String Firstname, String MiddleName, String LastName,
			String DateofBirth, String gender, String Phone, String email, String address, String patientHasInsurance,
			String Lang) {

		try {
			setTimeOut(10000);
			accountName = Firstname + " " + MiddleName + " " + LastName;

			waitForPageLoaded();
			// navigateToToAccDetails();

			By AccountNameDetailsTab = getDynamicElement(strAccName, "Account Name");
			String constAccountName = getText(AccountNameDetailsTab);

			verifyDetails(AccountNameDetailsTab, accountName, "Account Name");

			By accObjectGender = getDynamicElement(strAccountObjectDetails, "Gender");
			verifyDetails(accObjectGender, gender, "Gender");

			By accObjectOtherPhone = getDynamicElement(strAccObjectPhone, "Other Phone");
			verifyDetails(accObjectOtherPhone, Phone, "Phone");

			By accObjEmail = getDynamicElement(strAccObjEmail, "Email");
			verifyDetails(accObjEmail, email, "Email");

			By accObjPrefLang = getDynamicElement(strAccountObjectDetails, "Preferred Language");
			verifyDetails(accObjPrefLang, Lang, "Preferred Language");

			setTimeOut(2000);
			accountObject.clickOnTab(tabsName.get(1));
			;
			setTimeOut(2000);
			LoggingInfo("Click on Related Tab section");

			// Verify Account Objects has no records
			// Authorization Form Consent

			scrollToDocumentHeight();
			setTimeOut(2000);
			// String authorizationConsent = getText(eleAuthorizationConsentTitle);
			By eleNoConsent = By.xpath("//*[@data-label=\"AuthorizationFormTextName\"]//*[@title=\"undefined\"]");
			waitAndVerifyElement(eleNoConsent);
			setTimeOut(2000);
			LoggingInfo("Successfully verified Authorization Consent object with no records");

			// Verify Member Plans has no records
			By memberPlanAccObject = getDynamicElement(strAccObject, "Member Plans");
			scrollToElement(memberPlanAccObject);
			By memberPlanRecAccObject = getDynamicElement(strAccObjectNoRec, "Member Plans");
			waitAndVerifyElement(memberPlanRecAccObject);
			setTimeOut(2000);
			LoggingInfo("Successfully verified Member Plans object with no records");

			// Verify Medication Requests has no records
			// By medicationRequestsRecAccObject = getDynamicElement(strAccObjectNoRec,
			// "Medication Requests");
			// waitAndVerifyElement(medicationRequestsRecAccObject);
			// setTimeOut(2000);
			// LoggingInfo("Successfully verified Medication Requests object with no
			// records");
			//
			// // Verify Health Conditions has no records
			// By healthConditionsRecAccObject = getDynamicElement(strAccObjectNoRec,
			// "Health Conditions");
			// waitAndVerifyElement(healthConditionsRecAccObject);
			// setTimeOut(2000);
			// LoggingInfo("Successfully verified Health Conditions object with no
			// records");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Verification failed for Account Object" + e.getMessage());
		}
	}

	/**
	 * Function: Click on tab table
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnTab(String tabname) {
		try {
			waitForPageLoaded();
			setTimeOut(3000);
			By detailTab = getDynamicElement(detailsPageTabsButton, tabname);
			waitAndVerifyElement(detailTab);
			scrollToElement(detailTab);
			clickByJavascript(detailTab);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to-" + tabname + e.getMessage());
			Assert.fail("Failed to navigate to-" + tabname + e.getMessage());
		}
	}

	/**
	 * Function: Click on Site
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnSite() {
		try {
			waitForPageLoaded();
			setTimeOut(3000);
			By eleSite = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@field-label=\"Site\"]//a");
			waitAndVerifyElement(eleSite);
			scrollToElement(eleSite);
			clickByJavascript(eleSite);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click to-" + e.getMessage());
			Assert.fail("Failed to click to-" + e.getMessage());
		}
	}

	/**
	 * Function: Click on HCP
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnHCP() {
		try {
			waitForPageLoaded();
			setTimeOut(3000);
			By eleHCP = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@field-label=\"Prescriber\"]//a");
			waitAndVerifyElement(eleHCP);
			scrollToElement(eleHCP);
			clickByJavascript(eleHCP);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click to-" + e.getMessage());
			Assert.fail("Failed to click to-" + e.getMessage());
		}
	}

	/**
	 * Function: verify Columns
	 * 
	 * @author Anand Pawar
	 **/
	public void verifyColumns(String... columns) {
		try {
			for (String label : columns) {
				By column = getDynamicElement(eleRow, label);
				waitAndVerifyElement(column);
				scrollToElement(column);
				highLightElement(column);
				LoggingInfo("'" + label + "'  column is displayed.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to-" + e.getMessage());
			Assert.fail("Failed to navigate to-" + e.getMessage());
		}
	}

	/**
	 * Function: verify Columns
	 * 
	 * @author Anand Pawar
	 **/
	public void verifyZipColumnNotPresent() {
		try {
			By eleZip = By.xpath("//div[@role=\"rowgroup\"]//*[contains(text(),'Zip')]");
			getWebDriver().findElement(eleZip);

		} catch (Exception e) {
			LoggingInfo("Zip column not present as expected");
			System.out.println("Zip column not present as expected");

		}
	}

	/**
	 * Function: Verify actual and expected data of authorization Form Consents
	 * table
	 * 
	 * @author Trupti Zure
	 **/

	public void authorizationFormConsents(String patientName, String careprogram, String patientCertDate,
			String patientCertSigned, String patientAuthDate, String patientAuthSign, String prescriberSignDate,
			String presSigned, String textMessagingConsent) {
		try {

			waitAndVerifyElement(authConsentLabel);
			scrollToElement(authConsentLabel);
			setTimeOut(2000);
			if (isElementPresent(authConsentTable)) {
				Log.info("verify Authorization Form Consent details");
				ArrayList<String> allData = getConsentTableData("Name", "AuthorizationFormTextName", "Status",
						"ConsentCaptureSourceType", "ConsentCaptureDate", "CareProgramName");

				ArrayList<String> expectedData = generateExpectedData(patientName, careprogram, patientCertDate,
						patientCertSigned, patientAuthDate, patientAuthSign, prescriberSignDate, presSigned,
						textMessagingConsent);

				// ArrayList<String> expectedData = generateExpectedData(patientName, "Dupixent
				// Patient Authorization Form Text", "Active",
				// "Written", prescriberSignDate, careprogram);

				// logData("Actual Data:", allData);
				// logData("Expected Data:", expectedData);

				if (compareArrayLists(allData, expectedData)) {
					Log.info("Authorization Form consent data matches with expected data");
					LoggingInfo("Authorization Form Consent details are verified");
					setTimeOut(2000);
				} else {
					Assert.fail("Authorization Form Consent data does not match with expected data. Actual Data: "
							+ allData.toString() + " Expected Data: " + expectedData.toString());
				}
			} else {
				Assert.fail("Authorization Form Consent details are not present");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Authorization Form Consent details-" + e.getMessage());
			Assert.fail("Failed to verify Authorization Form Consent details-" + e.getMessage());
		}
	}

	/**
	 * Function: Generate expected data for Authorization consent table
	 * 
	 * @author Trupti Zure
	 **/

	public ArrayList<String> generateExpectedData(String patientName, String careprogram, String patientCertDate,
			String patientCertSigned, String patientAuthDate, String patientAuthSign, String prescriberSignDate,
			String presSigned, String textMessagingConsent) {
		ArrayList<String> expectedData = new ArrayList<>();
		String[] consentTypes = { "Patient Program Authorization", "General Marketing Consent",
				"Email Communication Consent", "Telephone Communication Consent", "Written/Mail Communication Consent",
				"Text Messaging Consent", "HIPAA Authorization", "HCP Authorization" };

		String ppaConsentDate = (patientCertSigned.equalsIgnoreCase("Yes"))
				? consentCaptureDate.getPPAConsentCaptureDate(patientCertDate)
				: null;
		String generalMarketingConsentDate = (patientCertSigned.equalsIgnoreCase("Yes"))
				? consentCaptureDate.getConsentCapturedDateTime(patientCertDate)
				: null;
		String emailConsentDate = (patientCertSigned.equalsIgnoreCase("Yes"))
				? consentCaptureDate.getConsentCapturedDateTime(patientCertDate)
				: null;
		String teleConsentDate = (patientCertSigned.equalsIgnoreCase("Yes"))
				? consentCaptureDate.getConsentCapturedDateTime(patientCertDate)
				: null;
		String mailConsentDate = (patientCertSigned.equalsIgnoreCase("Yes"))
				? consentCaptureDate.getConsentCapturedDateTime(patientCertDate)
				: null;
		String textConsentDate = (textMessagingConsent.equalsIgnoreCase("TRUE"))
				? consentCaptureDate.getConsentCapturedDateTime(patientCertDate)
				: null;
		String hippaConsentDate = (patientAuthSign.equalsIgnoreCase("Yes"))
				? consentCaptureDate.getPPAConsentCaptureDate(patientAuthDate)
				: null;
		String hcpConsentDate = (presSigned.equalsIgnoreCase("Yes"))
				? consentCaptureDate.hcpConsentCapturedDateTime(prescriberSignDate)
				: null;

		for (String consentType : consentTypes) {
			String consentDate = null;

			if (consentType.equalsIgnoreCase("Patient Program Authorization")) {
				consentDate = ppaConsentDate;
			} else if (consentType.equalsIgnoreCase("General Marketing Consent")) {
				consentDate = generalMarketingConsentDate;
			} else if (consentType.equalsIgnoreCase("Email Communication Consent")) {
				consentDate = emailConsentDate;
			} else if (consentType.equalsIgnoreCase("Telephone Communication Consent")) {
				consentDate = teleConsentDate;
			} else if (consentType.equalsIgnoreCase("Written/Mail Communication Consent")) {
				consentDate = mailConsentDate;
			} else if (consentType.equalsIgnoreCase("Text Messaging Consent")) {
				consentDate = textConsentDate;
			} else if (consentType.equalsIgnoreCase("HIPAA Authorization")) {
				consentDate = hippaConsentDate;
			} else if (consentType.equalsIgnoreCase("HCP Authorization")) {
				consentDate = hcpConsentDate;
			}

			if (consentDate != null) {
				String consent = patientName + " : " + consentType;
				expectedData.add(consent + ", Dupixent Patient Authorization Form Text, Written, " + consentDate
						+ ", Active, " + careprogram);
			}
		}

		return expectedData;
	}

	public void verifyPPAConsentDate(String state, String patientDOB, String certDate) {
		try {
			boolean isHIPAAPresent = getWebDriver()
					.findElements(By.xpath("//span[contains(text(), 'Patient Program Authorization')]")).size() > 0;
			Log.info("PPA Consent Date verification");

			setTimeOut(5000);

			if (isHIPAAPresent) {
				scrollToElement(AuthorizationFormPPA);
				clickByJavascript(AuthorizationFormPPA);
				String consentExpiryDateTime = getText(
						getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time"));
				String[] dateAndTime = consentExpiryDateTime.split(",");
				String consentExpiryDate = dateAndTime[0];

				LocalDate calculatedConsentExpiryDate = new ConsentExpiryDate().PPAConsentExpiryDate(state, patientDOB,
						certDate);
				String formattedCalculatedConsentExpiryDate = formatDatemmdyyyy(calculatedConsentExpiryDate.toString());

				System.out.println(
						"Method calculated local date expiry date for PPA: " + formattedCalculatedConsentExpiryDate);

				String consentExpiryDateUI = Utility_Function.changeFormatDate2(consentExpiryDate);
				System.out.println("Expiry date fetched from Salesforce App for PPA: " + consentExpiryDateUI);

				if (consentExpiryDateUI.equalsIgnoreCase(formattedCalculatedConsentExpiryDate)) {
					Assert.assertTrue(true, "Consent expiry Date matches. Actual Value: " + consentExpiryDateUI
							+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
					LoggingInfo("Consent expiry Date matches. Actual Value: " + consentExpiryDateUI
							+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
				} else {
					Assert.fail("Consent expiry date does not match. Actual: " + consentExpiryDateUI + ", Expected: "
							+ formattedCalculatedConsentExpiryDate);
					LoggingInfo("Consent expiry Date does not match. Actual Value: " + consentExpiryDateUI
							+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
				}
			} else {
				Assert.fail("PPA Consent object not found");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Verification of PPA consent is failed" + e.getMessage());
		}
	}

	public void navigateToAccDetails(String accounttName) {
		try {

			waitAndVerifyElement(NavigationMenu);
			click(NavigationMenu);
			click(AccountMenu);
			setTimeOut(4000);

			click(SearchList);
			setTimeOut(3000);
			inputText(SearchList, accounttName);
			genericKeyPress(SearchList, "Enter");
			waitAndVerifyElement(accRec);
			setTimeOut(5000);
			click(accRec);

			setTimeOut(2000);
			refresh();
			click(DetailsTab);
			setTimeOut(2000);
			accountObject.clickOnTab(tabsName.get(1));
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to account details- " + e.getMessage());
		}
	}

	public void verifyHCPAuthorization(String Patientname) throws InterruptedException {

		setTimeOut(5000);
		String AuthorizationName = Patientname + " : HCP Authorization";
		By HCPObject = getDynamicElement(authorizationObject, AuthorizationName);
		scrollToElement(HCPObject);
		waitAndVerifyElement(HCPObject);
		clickByJavascript(HCPObject);
		LoggingInfo("User clicked on HCP Authorization");
		setTimeOut(3000);

		// Verify if element is displayed

		By consentExpiryDateTime = By.xpath(
				"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Consent Expiration Date Time\"]//parent::div//parent::dt//following-sibling::dd//lightning-formatted-text");
		boolean found = isElementDisplayed(consentExpiryDateTime);
		if (found) {
			Assert.fail("Consent Expiry Date for HCP Authorization is not empty");
		} else {
			Assert.assertTrue(true, "Consent Expiry Date for HCP Authorization is empty");
		}

	}

	public void verifyWrittenMailAuthorization(String Patientname, String state, String patientDOB, String certDate)
			throws InterruptedException {

		setTimeOut(5000);
		String AuthorizationName = Patientname + " : Written/Mail Communication Consent";
		By writtenMailObject = getDynamicElement(authorizationObject, AuthorizationName);
		scrollToElement(writtenMailObject);
		waitAndVerifyElement(writtenMailObject);
		clickByJavascript(writtenMailObject);
		LoggingInfo("User clicked on Written/Mail Communication Consent Authorization");
		refresh();
		waitForPageLoaded();
		setTimeOut(3000);

		String consentExpiryDateTime = getText(
				getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time"));
		String[] dateAndTime = consentExpiryDateTime.split(",");
		String consentExpiryDate = dateAndTime[0];

		LocalDate calculatedConsentExpiryDate = new ConsentExpiryDate().PPAConsentExpiryDate(state, patientDOB,
				certDate);
		String formattedCalculatedConsentExpiryDate = formatDatemmdyyyy(calculatedConsentExpiryDate.toString());

		System.out.println("Method calculated local date expiry date for Written/Mail Communication Consent: "
				+ formattedCalculatedConsentExpiryDate);

		String consentExpiryDateUI = Utility_Function.changeFormatDate2(consentExpiryDate);
		System.out.println("Expiry date fetched from Salesforce App for Written/Mail Communication Consent: "
				+ consentExpiryDateUI);

		if (consentExpiryDateUI.equalsIgnoreCase(formattedCalculatedConsentExpiryDate)) {
			Assert.assertTrue(true, "Consent expiry Date matches. Actual Value: " + consentExpiryDateUI
					+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
			LoggingInfo("Consent expiry Date matches. Actual Value: " + consentExpiryDateUI + ", Expected Value: "
					+ formattedCalculatedConsentExpiryDate);
		} else {
			Assert.fail("Consent expiry date does not match. Actual: " + consentExpiryDateUI + ", Expected: "
					+ formattedCalculatedConsentExpiryDate);
			LoggingInfo("Consent expiry Date does not match. Actual Value: " + consentExpiryDateUI
					+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
		}

	}

	public void verifyEmailAuthorization(String Patientname, String state, String patientDOB, String certDate)
			throws InterruptedException {

		setTimeOut(5000);
		String AuthorizationName = Patientname + " : Email Communication Consent";
		By EmailObject = getDynamicElement(authorizationObject, AuthorizationName);
		scrollToElement(EmailObject);
		waitAndVerifyElement(EmailObject);
		clickByJavascript(EmailObject);
		LoggingInfo("User clicked on EMail Communication Consent Authorization");
		setTimeOut(3000);
		refresh();
		waitForPageLoaded();
		String consentExpiryDateTime = getText(
				getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time"));
		String[] dateAndTime = consentExpiryDateTime.split(",");
		String consentExpiryDate = dateAndTime[0];

		LocalDate calculatedConsentExpiryDate = new ConsentExpiryDate().PPAConsentExpiryDate(state, patientDOB,
				certDate);
		String formattedCalculatedConsentExpiryDate = formatDatemmdyyyy(calculatedConsentExpiryDate.toString());

		System.out.println("Method calculated local date expiry date for EMail Communication Consent: "
				+ formattedCalculatedConsentExpiryDate);

		String consentExpiryDateUI = Utility_Function.changeFormatDate2(consentExpiryDate);
		System.out.println(
				"Expiry date fetched from Salesforce App for Email Communication Consent: " + consentExpiryDateUI);

		if (consentExpiryDateUI.equalsIgnoreCase(formattedCalculatedConsentExpiryDate)) {
			Assert.assertTrue(true, "Consent expiry Date matches. Actual Value: " + consentExpiryDateUI
					+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
			LoggingInfo("Consent expiry Date matches. Actual Value: " + consentExpiryDateUI + ", Expected Value: "
					+ formattedCalculatedConsentExpiryDate);
		} else {
			Assert.fail("Consent expiry date does not match. Actual: " + consentExpiryDateUI + ", Expected: "
					+ formattedCalculatedConsentExpiryDate);
			LoggingInfo("Consent expiry Date does not match. Actual Value: " + consentExpiryDateUI
					+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
		}

	}

	public void verifyGeneralAuthorization(String Patientname, String state, String patientDOB, String certDate)
			throws InterruptedException {

		setTimeOut(5000);
		String AuthorizationName = Patientname + " : General Marketing Consent";
		By GeneralMarketingObject = getDynamicElement(authorizationObject, AuthorizationName);
		scrollToElement(GeneralMarketingObject);
		waitAndVerifyElement(GeneralMarketingObject);
		clickByJavascript(GeneralMarketingObject);
		LoggingInfo("User clicked on General Marketing Consent Authorization");
		setTimeOut(3000);
		refresh();
		waitForPageLoaded();
		String consentExpiryDateTime = getText(
				getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time"));
		String[] dateAndTime = consentExpiryDateTime.split(",");
		String consentExpiryDate = dateAndTime[0];

		LocalDate calculatedConsentExpiryDate = new ConsentExpiryDate().PPAConsentExpiryDate(state, patientDOB,
				certDate);
		String formattedCalculatedConsentExpiryDate = formatDatemmdyyyy(calculatedConsentExpiryDate.toString());

		String consentExpiryDateUI = Utility_Function.changeFormatDate2(consentExpiryDate);

		if (consentExpiryDateUI.equalsIgnoreCase(formattedCalculatedConsentExpiryDate)) {
			Assert.assertTrue(true, "Consent expiry Date matches. Actual Value: " + consentExpiryDateUI
					+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
			LoggingInfo("Consent expiry Date matches. Actual Value: " + consentExpiryDateUI + ", Expected Value: "
					+ formattedCalculatedConsentExpiryDate);
		} else {
			Assert.fail("Consent expiry date does not match. Actual: " + consentExpiryDateUI + ", Expected: "
					+ formattedCalculatedConsentExpiryDate);
			LoggingInfo("Consent expiry Date does not match. Actual Value: " + consentExpiryDateUI
					+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
		}

	}

	public void verifyTextMessagingAuthorization(String Patientname, String state, String patientDOB, String certDate)
			throws InterruptedException {

		setTimeOut(5000);
		String AuthorizationName = Patientname + " : Text Messaging Consent";
		By TextMessagingObject = getDynamicElement(authorizationObject, AuthorizationName);
		scrollToElement(TextMessagingObject);
		waitAndVerifyElement(TextMessagingObject);
		clickByJavascript(TextMessagingObject);
		LoggingInfo("User clicked on General Marketing Consent Authorization");
		setTimeOut(3000);
		refresh();
		waitForPageLoaded();
		String consentExpiryDateTime = getText(
				getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time"));
		String[] dateAndTime = consentExpiryDateTime.split(",");
		String consentExpiryDate = dateAndTime[0];

		LocalDate calculatedConsentExpiryDate = new ConsentExpiryDate().PPAConsentExpiryDate(state, patientDOB,
				certDate);
		String formattedCalculatedConsentExpiryDate = formatDatemmdyyyy(calculatedConsentExpiryDate.toString());

		String consentExpiryDateUI = Utility_Function.changeFormatDate2(consentExpiryDate);
		System.out
				.println("Expiry date fetched from Salesforce App for Text Messaging Consent :" + consentExpiryDateUI);

		if (consentExpiryDateUI.equalsIgnoreCase(formattedCalculatedConsentExpiryDate)) {
			Assert.assertTrue(true, "Consent expiry Date matches. Actual Value: " + consentExpiryDateUI
					+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
			LoggingInfo("Consent expiry Date matches. Actual Value: " + consentExpiryDateUI + ", Expected Value: "
					+ formattedCalculatedConsentExpiryDate);
		} else {
			Assert.fail("Consent expiry date does not match. Actual: " + consentExpiryDateUI + ", Expected: "
					+ formattedCalculatedConsentExpiryDate);
			LoggingInfo("Consent expiry Date does not match. Actual Value: " + consentExpiryDateUI
					+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
		}

	}

	public void verifyTelephoneAuthorization(String Patientname, String state, String patientDOB, String certDate)
			throws InterruptedException {

		setTimeOut(5000);
		String authorizationName = Patientname + " : Telephone Communication Consent";
		By TelephoneObject = getDynamicElement(authorizationObject, authorizationName);
		scrollToElement(TelephoneObject);
		waitAndVerifyElement(TelephoneObject);
		clickByJavascript(TelephoneObject);
		LoggingInfo("User clicked on Telephone Communication Consent Authorization");
		setTimeOut(3000);
		refresh();
		waitForPageLoaded();
		String consentExpiryDateTime = getText(
				getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time"));
		String[] dateAndTime = consentExpiryDateTime.split(",");
		String consentExpiryDate = dateAndTime[0];

		LocalDate calculatedConsentExpiryDate = new ConsentExpiryDate().PPAConsentExpiryDate(state, patientDOB,
				certDate);
		String formattedCalculatedConsentExpiryDate = formatDatemmdyyyy(calculatedConsentExpiryDate.toString());

		String consentExpiryDateUI = Utility_Function.changeFormatDate2(consentExpiryDate);
		System.out.println(
				"Expiry date fetched from Salesforce App for Telephone Communication Consent " + consentExpiryDateUI);

		if (consentExpiryDateUI.equalsIgnoreCase(formattedCalculatedConsentExpiryDate)) {
			Assert.assertTrue(true, "Consent expiry Date matches. Actual Value: " + consentExpiryDateUI
					+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
			LoggingInfo("Consent expiry Date matches. Actual Value: " + consentExpiryDateUI + ", Expected Value: "
					+ formattedCalculatedConsentExpiryDate);
		} else {
			Assert.fail("Consent expiry date does not match. Actual: " + consentExpiryDateUI + ", Expected: "
					+ formattedCalculatedConsentExpiryDate);
			LoggingInfo("Consent expiry Date does not match. Actual Value: " + consentExpiryDateUI
					+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
		}

	}

	/*
	 * @author Trupti Zure
	 **/
	public void verifyCPE(String recordName) {
		try {
			scrollToPixel(0, 200);
			setTimeOut(2000);
			By cpeElement = By.xpath(
					"//*[contains(@class,'active lafPageHost')]//table[@aria-label='Care Program Enrollees']//th//a//span[@class='slds-truncate']//slot//span");
			scrollToElement(cpeElement);
			String actualData = getText(cpeElement);
			Assert.assertEquals(actualData, recordName);
			LoggingInfo("CPE object is created ");
		} catch (Exception e) {
			Log.error("Failed to verify CPE object " + e.getMessage());
			Assert.fail("Failed to verify CPE object " + e.getMessage());
		}
	}

	public String getHubIDField() {

		By eledhubID = getDynamicElement(detailFields, "Hub Id");
		waitAndVerifyElement(eledhubID);
		highLightElement(eledhubID);
		String actualValue = getText(eledhubID);
		return actualValue;
	}

	/**
	 * Function: Navigate to CPE record
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateCareProgramEnrollee() {
		try {
			scrollToPixel(0, 250);
			By careProgramEnrollee = getDynamicElement(strAccountObjectsCreated, "Care Program Enrollees");
			scrollToElement(careProgramEnrollee);
			clickByJavascript(careProgramEnrollee);
			setTimeOut(2000);
			LoggingInfo("Clicked on Care Program Enrollees");
		} catch (Exception e) {
			Log.error("Failed to navigate to CPE record  " + e.getMessage());
			Assert.fail("Failed to navigate to CPE record  " + e.getMessage());
		}
	}

	/**
	 * Function: Verify and click on CPE record
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyAndClickOnCPERecord(String cpeName) {
		try {
			waitAndVerifyElement(recordName);
			verifyDetails(recordName, cpeName, "Care program enrollee name");
			highLightElement(recordName);
			clickByJavascript(recordName);
			LoggingInfo("Care program enrollee record verified");
		} catch (Exception e) {
			Log.error("Failed to navigate to CPE record  " + e.getMessage());
			Assert.fail("Failed to navigate to CPE record  " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to all patient list view
	 * 
	 * @author Trupti Zure
	 **/

	public void navigateToAllPatientListView() {
		try {

			Log.info("Navigate to all care program enrollee worklist");
			click(listViewButton);
			waitForPageLoaded();
			By allPatientList = getDynamicElement(strDocumentPageTitle, "All Patients");
			waitAndVerifyElement(allPatientList);
			clickByJavascript(allPatientList);
			setTimeOut(2000);
			LoggingInfo("Navigated to All Patients Worklist");

		} catch (Exception e) {
			Log.error("Failed to navigate All Patient List View  " + e.getMessage());
			Assert.fail("Failed to navigate All Patient List View " + e.getMessage());
		}
	}

	/**
	 * Function: Search account record
	 * 
	 * @author Trupti Zure
	 **/

	public void searchRecord(String record) {
		try {

			waitForPageLoaded();
			setTimeOut(6000);
			click(searchDocInput);
			inputText(searchDocInput, record);
			genericKeyPress(searchDocInput, "Enter");
			setTimeOut(4000);
			waitForPageLoaded();
			setTimeOut(2000);

			// click(eleLastModDateSort);
			// setTimeOut(1000);
			// click(eleLastModDateSort);
			setTimeOut(1000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed search record" + e.getMessage());
			Assert.fail("Failed search record" + e.getMessage());

		}
	}

	/**
	 * Function: Click on account record
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnfirstRecord() {
		try {
			By record = By.xpath("//tbody//tr//th//a[1]");
			waitAndVerifyElement(record);
			clickByJavascript(record);
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed click on record" + e.getMessage());
			Assert.fail("Failed click on record" + e.getMessage());

		}
	}

	/**
	 * Function: Click on account record
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnRecord(String name) {
		try {
			By record = getDynamicElement(strRecordName, name);
			waitAndVerifyElement(record);
			clickByJavascript(record);
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed click on record" + e.getMessage());
			Assert.fail("Failed click on record" + e.getMessage());

		}
	}

	// Anand P
	public void clickOnFirstCase() {
		try {
			By record = By
					.xpath("(//*[contains(@class,\"active lafPageHost\")]//th[@data-label=\"Case Number\"]//a)[1]");
			waitAndVerifyElement(record);
			clickByJavascript(record);
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed click on record" + e.getMessage());
			Assert.fail("Failed click on record" + e.getMessage());

		}
	}

	/**
	 * Function: Search and open any random account record
	 * 
	 * @author Trupti Zure
	 **/
	public void searchAndOpenRecord() {
		String name = null;
		setTimeOut(3000);
		try {
			Random random = new Random();
			waitAndVerifyElement(eleNameList);
			List<WebElement> listOptions = getWebDriver().findElements(eleNameList);
			List<String> nameTextList = new ArrayList<>();

			for (int i = 0; i < listOptions.size(); i++) {
				String title = listOptions.get(i).getAttribute("title");

				if (!title.contains("Automation Specialty Pharmacy") && !title.contains("Pharmacy")
						&& !title.contains("Medical")) {
					nameTextList.add(title);
				}
			}

			String[] names = new String[nameTextList.size()];
			for (int j = 0; j < names.length; j++) {
				names[j] = nameTextList.get(j);
			}
			name = names[random.nextInt(names.length)];
			// Clicks on record
			searchRecord(name);
			click(eleAutomation);
			setTimeOut(2000);
			LoggingInfo("Search record on care program enrollees list-" + name);
			setTimeOut(2000);
			// clickOnRecord(name);
			setTimeOut(2000);
			LoggingInfo("Clicked on record-" + name);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Search record on care program enrollees list " + e.getMessage());
			Assert.fail("Failed to Search record on care program enrollees list " + e.getMessage());
		}

	}

	/**
	 * Function: Search and open any random account record
	 * 
	 * @author Sonica
	 **/
	public void searchRecordAndOpen() {
		try {
			click(eleAutomation);
			setTimeOut(2000);
			LoggingInfo("Search record on care program enrollees list");
			setTimeOut(1000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Search record on care program enrollees list " + e.getMessage());
			Assert.fail("Failed to Search record on care program enrollees list " + e.getMessage());
		}
	}

	/**
	 * Function: Search and open any random CPE record
	 * 
	 * @author Sonica
	 **/
	public void searchCPERecordAndOpen() {
		try {
			click(eleCPERecord);
			setTimeOut(2000);
			LoggingInfo("Search record on care program enrollees list");
			setTimeOut(1000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click record on care program enrollees list " + e.getMessage());
			Assert.fail("Failed to click record on care program enrollees list " + e.getMessage());
		}
	}

	/**
	 * Function: Get account details
	 * 
	 * @author Trupti Zure
	 **/
	public String[] getCPEDetails() {
		String[] cpeDetails = new String[5];
		try {

			// Account name
			waitAndVerifyElement(eleAccName);
			String accName = getText(eleAccName);
			cpeDetails[0] = accName;

			// Dob
			By eleDob = getDynamicElement(strAccountObjectDetails, "Birthdate");
			waitAndVerifyElement(eleDob);
			String dob = getText(eleDob);
			cpeDetails[1] = dob;

			// Email
			By eleEmail = getDynamicElement(accDetailsEmail, "Email");
			waitAndVerifyElement(eleEmail);
			scrollToElement(eleEmail);
			String email = getText(eleEmail);
			cpeDetails[2] = email;

			// patient phone
			By elePhone = getDynamicElement(accDetailsLinkField, "Phone");
			waitAndVerifyElement(elePhone);
			scrollToElement(elePhone);
			String phone = getText(elePhone);
			cpeDetails[3] = phone;

			// Patient zip Code
			By zipCod = By.xpath("(//*[@title='Mailing Address']//parent::div//following-sibling::p//child::a//child::div)[2]");
			scrollToTopOfPage();
			scrollToElement(zipCod);
			setTimeOut(1000);
			String zipCode = getText(zipCod);

			String regex = "(\\d{5})$"; // Matches 5 consecutive digits at the end of the string

			// Compile the regex pattern
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(zipCode);

			String code = null;
			// If a match is found, extract the zip code
			if (matcher.find()) {
				code = matcher.group(1);
				System.out.println("Zip Code: " + code);
			} else {
				System.out.println("No zip code found in the address.");
			}
			cpeDetails[4] = code;

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get CPE details:  " + e.getMessage());
			Assert.fail("Failed to get CPE details:  " + e.getMessage());
		}
		return cpeDetails;
	}

	/**
	 * Function: Verify HCO record
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyHCORecord(String recordName) {
		try {
			scrollToHalfPage();
			setTimeOut(2000);
			By element = getDynamicElement(strDetailsLinkText, "Site");
			waitAndVerifyElement(element);
			scrollToElement(element);
			String actualData = getText(element);
			Assert.assertEquals(actualData, recordName);
			LoggingInfo("HCO object is created ");

		} catch (Exception e) {
			Log.error("Failed to verify medication " + e.getMessage());
			Assert.fail("Failed to verify medication  " + e.getMessage());
		}
	}

	/*
	 * @Author - Anand Pawar
	 */
	public void verifyChildDocStatusField(String status) {
		try {
			waitForPageLoaded();
			By eleStatus = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Status\"]//parent::div/following-sibling::div//lightning-formatted-text");
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			verifyDetails(eleStatus, status, "status");
			LoggingInfo("Verified child doc status");
		} catch (Exception e) {
			Log.error("Failed to verify Account record status  " + e.getMessage());
			Assert.fail("Failed to verify Account record status  " + e.getMessage());
		}

	}

	/**
	 * Function: Navigate to account section
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToAccount() {
		try {
			setTimeOut(4000);
			waitAndVerifyElement(NavigationMenu);
			click(NavigationMenu);
			click(AccountMenu);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to account section:  " + e.getMessage());
			Assert.fail("Failed to navigate to account section:  " + e.getMessage());
		}
	}

	// Anand P
	public void navigateToReceivedDocument() {
		try {
			// div[contains(@class,"appNavItems")]
			By rcvdDoc = By.xpath("//div[contains(@class,\"appNavItems\")]//span[text()=\"Received Documents\"]");
			// (//div[contains(@class,"appNavItems")]//span)[1]
			waitAndVerifyElement(rcvdDoc);
			scrollToElement(rcvdDoc);
			click(rcvdDoc);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to account section:  " + e.getMessage());
			Assert.fail("Failed to navigate to account section:  " + e.getMessage());
		}
	}

	/**
	 * Function: verify and click on account
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyAndClickOnRecord(String recordName) {
		try {
			refresh();
			waitForPageLoaded();
			By recordList = By.xpath("//tr//th[@scope='row']//span//a");
			boolean recordFound = false;
			for (int attempt = 0; attempt < 3; attempt++) {
				if (methodToAvoidStaleElementReferenceErrorElement(recordList)) {
					waitAndVerifyElement(recordList);
					setTimeOut(1000);
					List<WebElement> listOptions = getWebDriver().findElements(recordList);

					for (WebElement element : listOptions) {
						String record = element.getAttribute("title");
						setTimeOut(1000);

						if (record.equalsIgnoreCase(recordName)) {

							JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
							js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
									highlightStyle);
							setTimeOut(1000);
							element.click();
							setTimeOut(2000);
							LoggingInfo("Clicked on record: " + recordName);
							recordFound = true;
							break;
						}
					}
				}

				if (recordFound) {
					break;
				}

				click(listSort);
				setTimeOut(2000);
			}

			if (!recordFound) {
				Log.error("Record not found after 3 attempts: " + recordName);
				Assert.fail("Failed to find record: " + recordName);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on account" + e.getMessage());
			Assert.fail("Failed to click on account " + e.getMessage());
		}
	}

	/**
	 * Function: verify Consent Expiration Date for TextMessaging Consent
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyConsentExpirationForTextMessaging(String Patientname, String state, String patientDOB,
			String certDate) throws InterruptedException, ParseException {
		try {
			SimpleDateFormat inputFormat = new SimpleDateFormat("M/d/yyyy");
			SimpleDateFormat outputFormat = new SimpleDateFormat("MM-dd-yyyy");
			String consentExpiryDateTime = getText(
					getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time"));
			String[] dateAndTime = consentExpiryDateTime.split(",");
			String consentExpiryDate = dateAndTime[0];
			Date date = inputFormat.parse(consentExpiryDate);
			String consentExpiryDateFormatted = outputFormat.format(date);

			String consentCapturedDateTime = getText(
					getDynamicElement(strAccountObjectDetails, "Consent Capture Date"));
			String[] consentDateTime = consentCapturedDateTime.split(",");
			String consentCapturedDate = consentDateTime[0];
			Date capturedDate = inputFormat.parse(consentCapturedDate);
			String consentCapturedDateFormatted = outputFormat.format(capturedDate);

			// Format the Date object into the desired output format
			LocalDate calculatedConsentExpiryDate = new ConsentExpiryDate().PPAConsentExpiryDate(state, patientDOB,
					consentCapturedDateFormatted);
			String formattedCalculatedConsentExpiryDate = formatDatemmdyyyy(calculatedConsentExpiryDate.toString());

			String consentExpiryDateUI = Utility_Function.changeFormatDate2(consentExpiryDate);

			if (consentExpiryDateUI.equalsIgnoreCase(formattedCalculatedConsentExpiryDate)) {
				Assert.assertTrue(true, "Consent expiry Date matches. Actual Value: " + consentExpiryDateUI
						+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
				LoggingInfo("Consent expiry Date matches. Actual Value: " + consentExpiryDateUI + ", Expected Value: "
						+ formattedCalculatedConsentExpiryDate);
			} else {
				Assert.fail("Consent expiry date does not match. Actual: " + consentExpiryDateUI + ", Expected: "
						+ formattedCalculatedConsentExpiryDate);
				LoggingInfo("Consent expiry Date does not match. Actual Value: " + consentExpiryDateUI
						+ ", Expected Value: " + formattedCalculatedConsentExpiryDate);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Consent Expiry Date " + e.getMessage());
			Assert.fail("Failed to validate Consent Expiry Date " + e.getMessage());
		}

	}

	/**
	 * Function: click on TextMessaging Consent Row from Related Section
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void clickOnTextMessagingConsentRecord(String Patientname) throws InterruptedException {
		try {
			scrollToBottomOfPage();
			setTimeOut(5000);
			String AuthorizationName = Patientname + " : Text Messaging Consent";
			By TextMessagingObject = getDynamicElement(eleTextMessageConsentRow, AuthorizationName);
			scrollToElement(TextMessagingObject);
			waitAndVerifyElement(TextMessagingObject);
			clickByJavascript(TextMessagingObject);
			LoggingInfo("User clicked on Text Messaging Consent Authorization");
			setTimeOut(3000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Text Consent Record " + e.getMessage());
			Assert.fail("Failed to click on Text Consent Record " + e.getMessage());
		}

	}

	public void navigateToAccountRecord(String accountName) {
		try {
			By accountRecord = getDynamicElement(strAccountRecord, accountName);
			waitAndVerifyElement(accountRecord);
			scrollToElement(accountRecord);
			click(accountRecord);
			setTimeOut(2000);
			LoggingInfo("Navigated to Account record");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to CPE record-" + e.getMessage());
			Assert.fail("Failed to navigate to CPE record-" + e.getMessage());
		}
	}

	/**
	 * Function: Click on CPE record
	 * 
	 * @author Trupti Zure
	 **/
	public void cickOnCPERecord(String cpeName) {
		try {
			By cpeRecord = getDynamicElement(strCPERecord, cpeName);
			waitAndVerifyElement(cpeRecord);
			scrollToElement(recordName);
			clickByJavascript(recordName);
			LoggingInfo("Clicked on CPE record");
			waitForPageLoaded();
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to navigate to CPE record  " + e.getMessage());
			Assert.fail("Failed to navigate to CPE record  " + e.getMessage());
		}
	}

	public void verifyMYPSQAReviewDocuments() {
		try {
			waitForPageLoaded();
			waitFor(4000);
			By title = By.xpath("//h2//*[@title=\"My PSQA Review Documents\"]");
			waitAndVerifyElement(title);
			scrollToElement(title);
			highLightElement(title);
			LoggingInfo("My PSQA Review Documents Title Verified successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
		}
	}

	/*
	 * @author - Anand Pawar
	 */
	public void verifyARHomepageTitle() {
		try {
			waitForPageLoaded();

			By eleframe = By.xpath("//iframe[@title='dashboard']");
			switchToFrame(eleframe);

			By title = By.xpath("//*[text()=\"AR Specialist Homepage\"]");
			waitAndVerifyElement(title);
			scrollToElement(title);
			highLightElement(title);
			LoggingInfo("ARS homepage Title Verified successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
		}
	}

	/*
	 * @author - Anand Pawar
	 */
	public void verifyCaseManagerHomepageTitle() {
		try {
			waitForPageLoaded();

			By eleframe = By.xpath("//iframe[@title='dashboard']");
			switchToFrame(eleframe);

			By title = By.xpath("//*[text()=\"Case Manager Homepage\"]");
			waitAndVerifyElement(title);
			scrollToElement(title);
			highLightElement(title);
			LoggingInfo("CM homepage Title Verified successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
		}
	}

	/*
	 * @author - Anand Pawar
	 */
	public void verifyReports(String... reports) {
		try {
			for (String label : reports) {
				By report = getDynamicElement(eleReport, label);
				waitAndVerifyElement(report);
				scrollToElement(report);
				highLightElement(report);
				LoggingInfo("'" + label + "'  report is displayed.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
		}
	}

	/*
	 * @author - Anand Pawar
	 */
	public void verifyReportsNotPresent(String... reports) {
		try {
			for (String report : reports) {
				WebElement reportElement = getWebDriver().findElement(By.xpath("//*[text()='" + report + "']"));

				System.out.println("Validation Failed: Report '" + report + "' is present on the ARS Dashboard.");
			}
		} catch (Exception e) {
			System.out.println("Validation Passed: Report '" + report + "' is NOT present on the ARS Dashboard.");
		}
	}

	/*
	 * @author - Anand Pawar
	 * 
	 */
	public void clickReportAndVerifyNoChanges(String... reports) {
		try {
			for (String label : reports) {

				By report = getDynamicElement(eleReport2, label);
				waitAndVerifyElement(report);
				scrollToElement(report);
				clickByJavascript(report);
				LoggingInfo("'" + label + "'  clicked.");

				waitForPageLoaded();
				By eleframe = By.xpath("//iframe[@title='Report Viewer']");
				switchToFrame(eleframe);

				By eleFilter = By.xpath("//*[text()=\"Filters\"]//parent::button[@aria-controls=\"filterPanel\"]");
				waitAndVerifyElement(eleFilter);
				clickByJavascript(eleFilter);
				LoggingInfo("'" + label + "'  clicked on filter.");

				By eleStatus = By.xpath("//button//*[contains(text(), 'Status')]");
				waitAndVerifyElement(eleStatus);
				highLightElement(eleStatus);

				getWebDriver().switchTo().defaultContent();

				By closeTab = By.xpath("//*[contains(@title,\"Close\")]");
				waitAndVerifyElement(closeTab);
				clickByJavascript(closeTab);

				By eleframe3 = By.xpath("//iframe[@title='dashboard']");
				switchToFrame(eleframe3);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * @author - Anand Pawar
	 * 
	 * Report Viewer - iframe
	 */
	public void clickReportAndVerifyARInProgress(String condition, String... reports) {
		try {
			for (String label : reports) {
				By report = getDynamicElement(eleReport, label);
				waitAndVerifyElement(report);
				scrollToElement(report);
				clickByJavascript(report);
				LoggingInfo("'" + label + "'  clicked.");

				waitForPageLoaded();

				By eleframe = By.xpath("//iframe[@title='Report Viewer']");
				switchToFrame(eleframe);

				By eleFilter = By.xpath("//*[text()=\"Filters\"]//parent::button[@aria-controls=\"filterPanel\"]");
				waitAndVerifyElement(eleFilter);
				clickByJavascript(eleFilter);

				WebElement arInProgressElement = getWebDriver()
						.findElement(By.xpath("//span[contains(text(), 'AR in Progress')]"));

				String xpathCondition = "//span[contains(text(), 'equals " + condition + "')]";

				WebElement equalsTrueElement = getWebDriver().findElement(By.xpath(xpathCondition));

				if (arInProgressElement != null && arInProgressElement.getText().equals("AR in Progress")
						&& equalsTrueElement != null && equalsTrueElement.getText().equals(condition)) {
					System.out.println("Validation passed! for " + label);
				} else {
					Log.error("Failed to verify ");
				}
				LoggingInfo("'" + label + "'  verified AR in progress equals. " + condition);

				By ele = getDynamicElement(eleARStamp, label);
				highLightElement(ele);
				LoggingInfo("'" + label + "'  verified AR Specialist stamped");

				getWebDriver().switchTo().defaultContent();

				By closeTab = By.xpath("//*[contains(@title,\"Close\")]");
				waitAndVerifyElement(closeTab);
				clickByJavascript(closeTab);

				By eleframe2 = By.xpath("//iframe[@title='dashboard']");
				switchToFrame(eleframe2);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
		}
	}

	public void clickReportAndVerifyARInProgress2(String condition, String... reports) {
		try {
			for (String label : reports) {
				By report = getDynamicElement(eleReport2, label);
				waitAndVerifyElement(report);
				scrollToElement(report);
				clickByJavascript(report);
				LoggingInfo("'" + label + "'  clicked.");

				waitForPageLoaded();

				By eleframe = By.xpath("//iframe[@title='Report Viewer']");
				switchToFrame(eleframe);

				By eleFilter = By.xpath("//*[text()=\"Filters\"]//parent::button[@aria-controls=\"filterPanel\"]");
				waitAndVerifyElement(eleFilter);
				clickByJavascript(eleFilter);

				WebElement arInProgressElement = getWebDriver()
						.findElement(By.xpath("//span[contains(text(), 'AR in Progress')]"));

				String xpathCondition = "//span[contains(text(), 'equals " + condition + "')]";

				WebElement equalsTrueElement = getWebDriver().findElement(By.xpath(xpathCondition));

				if (arInProgressElement != null && arInProgressElement.getText().equals("AR in Progress")
						&& equalsTrueElement != null && equalsTrueElement.getText().equals(condition)) {
					System.out.println("Validation passed! for " + label);
				} else {
					Log.error("Failed to verify ");
				}
				LoggingInfo("'" + label + "'  verified AR in progress equals. " + condition);

				By ele = getDynamicElement(eleARStamp, label);
				highLightElement(ele);
				LoggingInfo("'" + label + "'  verified AR Specialist stamped");

				getWebDriver().switchTo().defaultContent();

				By closeTab = By.xpath("//*[contains(@title,\"Close\")]");
				waitAndVerifyElement(closeTab);
				clickByJavascript(closeTab);

				By eleframe2 = By.xpath("//iframe[@title='dashboard']");
				switchToFrame(eleframe2);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
		}
	}

	public void verifyAndClickOnPSQAWidget() {
		try {
			By eleframe = By.xpath("//iframe[@title='dashboard']");
			switchToFrame(eleframe);
			By title = By.xpath("//h2//div[text()=\"PSQA Reviews Needing Attention\"]");
			waitAndVerifyElement(title);
			scrollToElement(title);
			highLightElement(title);
			LoggingInfo("PSQA Reviews Needing Attention Verified successfully");
			setTimeOut(2000);

			By eleLink = By.xpath("//a[text()=\"View Report (PSQA Reviews In Needs Review Status)\"]");
			waitAndVerifyElement(eleLink);
			clickByJavascript(eleLink);
			setTimeOut(2000);
			LoggingInfo("Clicked on PSQA report link");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
		}
	}

	public void verifyAndClickOnCPEAssignmentWidget() {
		try {
			By eleframe = By.xpath("//iframe[@title='dashboard']");
			switchToFrame(eleframe);
			By title = By.xpath("//h2//*[text()=\"Care Team Assignments Needing Attention\"]");
			waitAndVerifyElement(title);
			scrollToElement(title);
			highLightElement(title);
			LoggingInfo("CPE Assignments Reviews Needing Attention Verified successfully");
			setTimeOut(2000);

			By eleLink = By.xpath("//*[text()='View Report (CPEs In The Care Team Assignment Queue)']");
			waitAndVerifyElement(eleLink);
			clickByJavascript(eleLink);
			setTimeOut(2000);
			LoggingInfo("Clicked on CPE Assignment Queue report link");
			setTimeOut(2000);

			getWebDriver().switchTo().defaultContent();
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
		}
	}

	public void verifyPSQAReviewPage() {
		try {
			waitForPageLoaded();
			By eleframe = By.xpath("//iframe[@title='Report Viewer']");
			switchToFrame(eleframe);
			By title = By.xpath("//h1//*[@title='PSQA Reviews In Needs Review Status']");
			waitAndVerifyElement(title);
			scrollToElement(title);
			highLightElement(title);
			LoggingInfo("PSQA Review Documents Verified successfully");

			By reviwDataTitle = By.xpath("//*[text()=\"Needs Review\"]");
			waitAndVerifyElement(reviwDataTitle);
			scrollToElement(reviwDataTitle);
			highLightElement(reviwDataTitle);

			By reviwData = By.xpath("//table//td");
			waitAndVerifyElement(reviwData);
			scrollToElement(reviwData);
			highLightElement(reviwData);
			LoggingInfo("PSQA Review Worklist Data is present");
			setTimeOut(2000);

			getWebDriver().switchTo().defaultContent();
			setTimeOut(2000);

			By homeTab = By.xpath("//*[text()=\"Home\"]");
			click(homeTab);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
		}
	}

	public void verifyCPEQueuePage() {
		try {
			waitForPageLoaded();
			String pageTitle = getWebDriver().getTitle();
			setTimeOut(2000);
			LoggingInfo("User navigated to " + pageTitle + " Successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
		}
	}

	// Anand P
	public void navigateToAuthFormConsentTable() {

		try {
			waitAndVerifyElement(authConsentLabel);
			scrollToElement(authConsentLabel);
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to navigate Authorization Form Consent Table " + e.getMessage());
			Assert.fail("Failed to navigate Authorization Form Consent Table  " + e.getMessage());
		}

	}

	/*
	 * @author - Anand Pawar
	 */
	public void validateConsentStatusWithdrawn(String text) {

		try {

			By eleStatus = getDynamicElement(eleConsent, text);
			waitAndVerifyElement(eleStatus);
			highLightElement(eleStatus);
			clickByJavascript(eleStatus);

		} catch (Exception e) {
			Log.error("Failed to verify " + e.getMessage());
			Assert.fail("Failed to verify  " + e.getMessage());
		}

	}

	/*
	 * @author - Anand Pawar
	 */
	public void validateConsentExpirationDateTime() {

		try {

			waitForPageLoaded();
			By eleField = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()='Consent Expiration Date Time']//parent::div//following-sibling::div//lightning-formatted-text");
			waitAndVerifyElement(eleField);
			scrollToElement(eleField);
			highLightElement(eleField);

			LoggingInfo("Verified consent expiration date and time");

		} catch (Exception e) {
			Log.error("Failed to verify " + e.getMessage());
			Assert.fail("Failed to verify  " + e.getMessage());
		}

	}

	// Anand P
	public void navigateToHealthConditions() {

		try {
			waitAndVerifyElement(healthCondTable);
			scrollToElement(healthCondTable);
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to navigate Authorization Form Consent Table " + e.getMessage());
			Assert.fail("Failed to navigate Authorization Form Consent Table  " + e.getMessage());
		}

	}

	public void navigateToMemberPlantable() {

		try {
			waitAndVerifyElement(memPlanTable);
			scrollToElement(memPlanTable);
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to navigate to member plan table " + e.getMessage());
			Assert.fail("Failed to navigate to member plan table " + e.getMessage());
		}

	}

	public void navigateToMedicationRequestTable() {

		try {
			waitAndVerifyElement(medicationTable);
			scrollToElement(medicationTable);
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to navigate Authorization Form Consent Table " + e.getMessage());
			Assert.fail("Failed to navigate Authorization Form Consent Table  " + e.getMessage());
		}

	}

	/**
	 * Function: Navigate to Care Program enrollee section
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void navigateToCareProgramEnrollee() {
		By CareProgramMenu = By.xpath("//*[text()='Care Program Enrollees']");
		try {
			waitForPageLoaded();
			waitAndVerifyElement(NavigationMenu);
			click(NavigationMenu);
			setTimeOut(1000);
			click(CareProgramMenu);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to Care Program Enrollee section:  " + e.getMessage());
			Assert.fail("Failed to navigate to Care Program Enrollee section:  " + e.getMessage());
		}
	}

	// Anand P
	public void verifyDocTypeMedD() {
		LoggingInfo("Verify Document Type");
		By docType = By.xpath("//lightning-formatted-text[text()='Med D PAP Reenrollment']");
		try {
			waitAndVerifyElement(docType);
			highLightElement(docType);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Document Type  " + e.getMessage());
			Assert.fail("Failed to validate Document Type  " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to CCR record
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToCCR() {
		try {
			scrollToHalfPage();
			setTimeOut(3000);
			By ccrTable = getDynamicElement(strAccountObjectsCreated, "Contact Contact Relationships");
			scrollToElement(ccrTable);
			clickByJavascript(ccrTable);
			setTimeOut(2000);
			LoggingInfo("Clicked on Care Program Enrollees");
		} catch (Exception e) {
			Log.error("Failed to navigate to CPE record  " + e.getMessage());
			Assert.fail("Failed to navigate to CPE record  " + e.getMessage());
		}
	}

	/**
	 * Function: Click on HCP record
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnHCPRecord(String hcprecord) {
		try {
			By hcpRecord = getDynamicElement(strRelatedContact, hcprecord);
			waitAndVerifyElement(hcpRecord);
			click(hcpRecord);
			LoggingInfo("Clicked on HCP record");
		} catch (Exception e) {
			Log.error("Failed to Clicked on HCP record" + e.getMessage());
			Assert.fail("Failed to Clicked on HCP record  " + e.getMessage());
		}
	}

	/**
	 * Function: Validage DSR Record
	 * 
	 * @author Trupti Zure
	 **/
	public void validateDSR() {
		try {
			// Add DCR in Progress?
			waitAndVerifyElement(dsrCHKBox);
			scrollToElement(dsrCHKBox);
			String checkBoxValue = getAttributeValue(dsrCHKBox, "checked");
			Assert.assertEquals("true", checkBoxValue,
					"Add DCR in Progress?. Expected: '" + "true" + "', but got: '" + checkBoxValue + "'");
		} catch (Exception e) {
			Log.error("Failed to validate DSR request" + e.getMessage());
			Assert.fail("Failed to validate DSR request " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to DSR Record
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToDSR() {
		try {
			scrollToPixel(0, 600);
			setTimeOut(3000);
			By dsrTable = getDynamicElement(strAccountObjectsCreated, "Data Change Requests");
			scrollToElement(dsrTable);
			clickByJavascript(dsrTable);
		} catch (Exception e) {
			Log.error("Failed to navigate to DSR request" + e.getMessage());
			Assert.fail("Failed to navigate to DSR request" + e.getMessage());
		}
	}

	/**
	 * Function: Click on DSR Record
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnDSRRecord() {
		try {
			waitAndVerifyElement(dsrRecord);
			clickByJavascript(dsrRecord);
			LoggingInfo("Clicked on DSR record");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to click on DSR request" + e.getMessage());
			Assert.fail("Failed to click on DSR request" + e.getMessage());
		}
	}

	/**
	 * Function: Validate DSR record is created
	 * 
	 * @author Trupti Zure
	 **/

	public void validateDSRRecordIsCreated(String hcpName) {
		try {
			// HCP account
			waitAndVerifyElement(dsrAccount);
			scrollToElement(dsrAccount);
			String account = getText(dsrAccount);
			Assert.assertEquals(account, hcpName,
					"HCP account. Expected: '" + hcpName + "', but got: '" + account + "'");
			LoggingInfo("DSR record verified- " + hcpName);
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to validate DSR request" + e.getMessage());
			Assert.fail("Failed to validate DSR request" + e.getMessage());
		}
	}

	/**
	 * Function: Click on member plan table
	 *
	 * @author Trupti Zure
	 **/
	public void clickOnMemberPlan() {

		try {
			setTimeOut(3000);
			accountObject.clickOnTab(tabsName.get(1));
			scrollToHalfPage();
			waitAndVerifyElement(eleMemberPlanTitle);
			scrollToElement(eleMemberPlanTitle);
			setTimeOut(1000);
			LoggingInfo("Member Plan Title is loaded");
			clickByJavascript(eleMemberPlanTitle);
			LoggingInfo("Member Plan  is clicked");
			setTimeOut(3000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Member plan title verification failed " + e.getMessage());
			Assert.fail("Member plan title verification failed" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Validate member plan record is created
	 * 
	 * @author Trupti Zure
	 **/

	public void validateMemberPlans(String rxmemberplan, String medMemberplan) {
		try {
			ArrayList<String> allData = getDataByHeaders("Member Plans", "Payer", "Record Type");
			logData("Actual Data:", allData);
			ArrayList<String> expectedData = new ArrayList<>();
			expectedData.add(rxmemberplan + ", " + "Pharmacy");
			expectedData.add(medMemberplan + ", " + "Medical");
			logData("expecetd Data:", expectedData);
			boolean allExpectedFound = true;
			for (String expected : expectedData) {
				if (!allData.contains(expected)) {
					allExpectedFound = false;
					break;
				}
			}
			if (!allExpectedFound) {
				throw new AssertionError("Not all expected data is present in allData.");
			}

		} catch (Exception e) {
			Log.error("Failed to validate Member plan details" + e.getMessage());
			Assert.fail("Failed to validate Member plan details" + e.getMessage());
		}
	}

	/**
	 * Function:Click on member plan
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnMemberPlan(String memberPlan) {
		try {

			// By memberPlanName = getDynamicElement(strMemberPlanName, memberPlan);
			By memPlanName = getDynamicElement(strMemPlanName, memberPlan);
			waitAndVerifyElement(memPlanName);
			scrollToElement(memPlanName);
			clickByJavascript(memPlanName);
			LoggingInfo("Clicked on member plan");
			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to click on Member plan details" + e.getMessage());
			Assert.fail("Failed to click on Member plan details" + e.getMessage());
		}
	}

	// Anand P
	public void clickOnmemberPlan(String pname) {
		try {

			By memberPlanName = getDynamicElement(memPlanName, pname);
			scrollToElement(memberPlanName);
			clickByJavascript(memberPlanName);
			LoggingInfo("Clicked on member plan");
			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to click on Member plan details" + e.getMessage());
			Assert.fail("Failed to click on Member plan details" + e.getMessage());
		}
	}

	/**
	 * Function: Validate NO DSR record is created
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyNODSRisCreated() {
		try {

			By strAccountObjectsCreated = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Data Change Requests\"]//parent::a");
			boolean found = isElementPresent(strAccountObjectsCreated);
			Assert.assertFalse(found, "DSR request is created for member plan");
			LoggingInfo("DSR request is not created for member plan");

		} catch (Exception e) {
			Log.error("Failed to verify no dsr request is created" + e.getMessage());
			Assert.fail("Failed to verify no dsr request is created" + e.getMessage());
		}
	}

	public void navigateToMemberPlan() {
		try {
			waitAndVerifyElement(NavigationMenu);
			click(NavigationMenu);
			click(MemberMenu);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to Member Plan section:  " + e.getMessage());
			Assert.fail("Failed to navigate to Member Plan section:  " + e.getMessage());
		}
	}

	public void navigateToCoverageBenefit() {
		try {
			By coverageBenefit = getDynamicElement(strAccountObjectsCreated, "Coverage Benefits");
			scrollToElement(coverageBenefit);
			clickByJavascript(coverageBenefit);
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to navigate to Coverage Benefit" + e.getMessage());
			Assert.fail("Failed to navigate to Coverage Benefit" + e.getMessage());
		}
	}

	public void verifyCBFields() {
		try {
			By eleName = getDynamicElement(eleCBFields, "Name");
			waitAndVerifyElement(eleName);

			By elerecordType = getDynamicElement(eleCBFields, "Record Type");
			waitAndVerifyElement(elerecordType);

			By eleCreatedDate = getDynamicElement(eleCBFields, "Created Date");
			waitAndVerifyElement(eleCreatedDate);

			By eleCoverageStatus = getDynamicElement(eleCBFields, "Coverage Status");
			waitAndVerifyElement(eleCoverageStatus);

			By elePARequired = getDynamicElement(eleCBFields, "PA required?");
			waitAndVerifyElement(elePARequired);

			By elePatientMedicare = getDynamicElement(eleCBFields, "Patient has Medicare Part D? (Y/N)");
			waitAndVerifyElement(elePatientMedicare);

			By elePAOutcome = getDynamicElement(eleCBFields, "PA Outcome");
			waitAndVerifyElement(elePAOutcome);

			By elePayer1 = getDynamicElement(eleCBFields, "Payer Collected Pharmacy #1");
			waitAndVerifyElement(elePayer1);

			By elePayer2 = getDynamicElement(eleCBFields, "Payer Collected Pharmacy #2");
			waitAndVerifyElement(elePayer2);

			By elePayer3 = getDynamicElement(eleCBFields, "Payer Collected Pharmacy #3");
			waitAndVerifyElement(elePayer3);
			LoggingInfo("CB Fields verified successfuly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify CB Fields" + e.getMessage());
			Assert.fail("Failed to erify CB Fields" + e.getMessage());
		}
	}

	/**
	 * Function: Validate CCR record is created
	 * 
	 * @author Trupti Zure
	 **/
	public void validateCCR(String hcpCollaborating, String hcpPrescribing, String patientRelationship,
			String relation) {
		try {
			ArrayList<String> allData = getDataByHeaders("Contact Contact Relationships", "Related Contact",
					"Relationship");
			logData("Actual Data:", allData);
			ArrayList<String> expectedData = new ArrayList<>();
			expectedData.add(hcpCollaborating + ", " + "HCP-Collaborating");
			expectedData.add(patientRelationship + ", " + "Patient-" + relation);
			expectedData.add(hcpPrescribing + ", " + "HCP-Prescribing");
			logData("expecetd Data:", expectedData);
			boolean allExpectedFound = true;
			for (String expected : expectedData) {
				if (!allData.contains(expected)) {
					allExpectedFound = false;
					break;
				}
			}
			if (!allExpectedFound) {
				throw new AssertionError("Not all expected data is present in allData.");
			}

		} catch (Exception e) {
			Log.error("Failed to verify CCR records" + e.getMessage());
			Assert.fail("Failed to verify CCR records" + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to Medication requests
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateMedicationRequests() {
		try {
			scrollToHalfPage();
			setTimeOut(3000);
			By mrTable = getDynamicElement(strCPEObjectsCreated, "Medication Requests");
			scrollToElement(mrTable);
			clickByJavascript(mrTable);
			setTimeOut(2000);
			LoggingInfo("Clicked on Medication Requests");
		} catch (Exception e) {
			Log.error("Failed to navigate to Medication Requests" + e.getMessage());
			Assert.fail("Failed to navigate to Medication Requests" + e.getMessage());
		}
	}

	/**
	 * Function: Validate Medication Requests records is created
	 * 
	 * @author Trupti Zure
	 **/

	public void validateMedicationRequests(String dose5a, String dose5b, String hcp) {
		try {
			ArrayList<String> allData = getDataByHeaders("Medication Requests", "Medication");
			logData("Actual Data:", allData);

			ArrayList<String> expectedData = new ArrayList<>();
			expectedData.add(dose5b);
			expectedData.add(dose5a);
			logData("Expected Data:", expectedData);

			allData = normalizeData(allData);
			expectedData = normalizeData(expectedData);

			logData("Normalized Actual Data:", allData);
			logData("Normalized Expected Data:", expectedData);

			boolean allExpectedFound = true;
			for (String expected : expectedData) {
				if (!allData.contains(expected)) {
					allExpectedFound = false;
					break;
				}
			}

			if (!allExpectedFound) {
				throw new AssertionError("Not all expected data is present in allData.");
			}

		} catch (Exception e) {
			Log.error("Failed to validate Medication Requests: " + e.getMessage());
		}
	}

	/**
	 * Function: Normalize array list data
	 * 
	 * @author Trupti Zure
	 **/

	private ArrayList<String> normalizeData(ArrayList<String> data) {
		ArrayList<String> normalizedData = new ArrayList<>();
		for (String str : data) {
			if (str != null) {
				String normalizedStr = str.trim().replaceAll("\u00A0", " ").replaceAll("[^\\x20-\\x7E]", "")
						.toLowerCase();
				normalizedData.add(normalizedStr);
			}
		}
		return normalizedData;
	}

	/**
	 * Function: Navigate to Health Conditions record
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateHealthConditions() {
		try {
			scrollToHalfPage();
			setTimeOut(3000);
			By hcTable = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Health Conditions\"]");
			scrollToElement(hcTable);
			clickByJavascript(hcTable);
			setTimeOut(2000);
			LoggingInfo("Clicked on Medication Requests");
		} catch (Exception e) {
			Log.error("Failed to navigate to Health Conditions" + e.getMessage());
			Assert.fail("Failed to navigate to Health Conditions" + e.getMessage());
		}
	}

	/**
	 * Function: Validate Health Conditions record is created
	 * 
	 * @author Trupti Zure
	 **/

	public void validateHealthConditions(String conditionCode) {
		try {
			ArrayList<String> allData = getDataByHeaders("Health Conditions", "Condition Code");
			logData("Actual Data:", allData);
			ArrayList<String> expectedData = new ArrayList<>();
			expectedData.add(conditionCode);
			logData("expecetd Data:", expectedData);
			boolean allExpectedFound = true;
			for (String expected : expectedData) {
				if (!allData.contains(expected)) {
					allExpectedFound = false;
					break;
				}
			}
			if (!allExpectedFound) {
				throw new AssertionError("Not all expected data is present in allData.");
			}

		} catch (Exception e) {
			Log.error("Failed to validate Health Conditions details" + e.getMessage());
			Assert.fail("Failed to validate Health Conditions details" + e.getMessage());
		}
	}

	// Anand P
	public void clickFacility() {
		try {
			// scrollToElement(listSort);
			// clickByJavascript(listSort);
			setTimeOut(3000);
			waitAndVerifyElement(facilityRec);
			setTimeOut(2000);
			click(facilityRec);
			setTimeOut(4000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on Facility" + e.getMessage());
		}
	}

	public void newHealthCond() {

		By eleNew = By.xpath("(//*[contains(@class,\"active lafPageHost\")]//button//span[text()=\"New\"])[2]");
		clickByJavascript(eleNew);
		LoggingInfo("New Button Clicked successfuly");
	}

	public void clickOnNew() {
		try {
			waitAndVerifyElement(eleNew);
			click(eleNew);
			LoggingInfo("New Button Clicked successfuly");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click New Button  " + e.getMessage());
			Assert.fail("Failed to click New Button " + e.getMessage());
		}
	}

	public void clickOnOtherHCPHCO() {
		try {
			By eleRadio = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Other(HCP, HCO, Payer, SP)\"]//ancestor::span//child::label//span[contains(@class,\"radio\")]");
			waitAndVerifyElement(eleRadio);
			click(eleRadio);
			LoggingInfo("Radio Button Clicked successfuly");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click radio Button  " + e.getMessage());
			Assert.fail("Failed to click radio Button " + e.getMessage());
		}
	}

	public void selectPatient() {
		try {
			waitAndVerifyElement(elePatient);
			click(elePatient);
			LoggingInfo("Patient selected successfuly");
			click(eleNext);
			setTimeOut(4000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select Patient  " + e.getMessage());
			Assert.fail("Failed to select Patient  " + e.getMessage());
		}
	}

	public void verifyPhoneField() {
		try {
			By eleAccName = getDynamicElement(strAccountObjectFields, "lastName");
			scrollToElement(eleAccName);
			click(eleAccName);
			inputText(eleAccName, "Test");

			By elePhone = getDynamicElement(strAccountObjectFields, "Phone");
			scrollToElement(elePhone);
			click(elePhone);
			inputText(elePhone, "98765432345");
			LoggingInfo("Entered 11 digits to phone field successfuly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Enter 11 digits to phone field  " + e.getMessage());
			Assert.fail("Failed to Enter 11 digits to phone field  " + e.getMessage());
		}
	}

	public void clickOnSave() {
		try {
			setTimeOut(2000);

			click(eleSave);

			LoggingInfo("clicked on save successfuly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on save " + e.getMessage());
			Assert.fail("Failed to click on save  " + e.getMessage());
		}
	}

	public void validatedErrorMessageForPhone() {
		try {

			waitAndVerifyElement(elePhoneError);
			LoggingInfo("phone error message verified successfuly");
			setTimeOut(2000);
			click(eleClose);
			setTimeOut(2000);
			By elePhone = getDynamicElement(strAccountObjectFields, "Phone");
			scrollToElement(elePhone);
			click(elePhone);
			clearText(elePhone);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify error message " + e.getMessage());
			Assert.fail("Failed to verify error message  " + e.getMessage());
		}
	}

	public void verifyOtherPhoneField() {
		try {
			By eleOtherPhone = getDynamicElement(strAccountObjectFields, "PersonOtherPhone");
			scrollToElement(eleOtherPhone);
			click(eleOtherPhone);
			inputText(eleOtherPhone, "98765432345");
			LoggingInfo("Entered 11 digits to other phone field successfuly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Enter 11 digits to other phone field  " + e.getMessage());
			Assert.fail("Failed to Enter 11 digits to other phone field  " + e.getMessage());
		}
	}

	public void validatedErrorMessageForOtherPhone() {
		try {

			waitAndVerifyElement(eleOtherPhoneError);
			LoggingInfo("Other phone error message verified successfuly");
			setTimeOut(2000);
			click(eleClose);
			setTimeOut(2000);
			By eleOtherPhone = getDynamicElement(strAccountObjectFields, "PersonOtherPhone");
			scrollToElement(eleOtherPhone);
			click(eleOtherPhone);
			clearText(eleOtherPhone);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify error message " + e.getMessage());
			Assert.fail("Failed to verify error message  " + e.getMessage());
		}
	}

	public void verifyMailingZipField() {
		try {
			By eleMailing = getDynamicElement(strAccountObjectFields, "postalCode");
			scrollToElement(eleMailing);
			click(eleMailing);
			inputText(eleMailing, "234576");
			LoggingInfo("Entered 6 digits to Mailing Zip field successfuly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Enter 6 digits to Mailing Zip " + e.getMessage());
			Assert.fail("Failed to Enter 6 digits to Mailing Zip  " + e.getMessage());
		}
	}

	public void validatedErrorMessageForMailingZip() {
		try {

			waitAndVerifyElement(eleMailingZipError);
			LoggingInfo("Mailing Zip error message verified successfuly");
			click(eleClose);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify error message " + e.getMessage());
			Assert.fail("Failed to verify error message  " + e.getMessage());
		}
	}

	public void selectOfficeContact() {
		try {
			waitAndVerifyElement(eleOfficeContact);
			click(eleOfficeContact);
			LoggingInfo("Office Contact selected successfuly");
			click(eleNext);
			setTimeOut(4000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select office Contact  " + e.getMessage());
			Assert.fail("Failed to select office Contact " + e.getMessage());
		}
	}

	public void verifyBillingZipField() {
		try {

			By eleAccName = getDynamicElement(strAccountObjectFields, "lastName");
			scrollToElement(eleAccName);
			click(eleAccName);
			inputText(eleAccName, "Test");

			By eleBillingZip = getDynamicElement(strAccountObjectFields, "postalCode");
			scrollToElement(eleBillingZip);
			click(eleBillingZip);
			inputText(eleBillingZip, "234576");
			LoggingInfo("Entered 6 digits to Billing Zip field successfuly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Enter 6 digits to Billing Zip " + e.getMessage());
			Assert.fail("Failed to Enter 6 digits to Billing Zip  " + e.getMessage());
		}
	}

	public void validatedErrorMessageForBillingZip() {
		try {

			waitAndVerifyElement(eleBillingZipError);
			LoggingInfo("Billing Zip error message verified successfuly");
			click(eleClose);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify error message " + e.getMessage());
			Assert.fail("Failed to verify error message  " + e.getMessage());
		}
	}

	public void clickonAccount(String AccName) {
		try {
			setTimeOut(2000);

			By eleAccName = getDynamicElement(strAccountName, AccName);
			scrollToElement(eleAccName);
			clickByJavascript(eleAccName);
			LoggingInfo("clicked on Account Name successfuly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Account Name " + e.getMessage());
			Assert.fail("Failed to click on Account Name " + e.getMessage());
		}

	}

	public void ClickOnCPERecord(String cpeName) {
		try {
			setTimeOut(2000);
			scrollToElement(recordName);
			waitAndVerifyElement(recordName);
			verifyDetails(recordName, cpeName, "Care program enrollee name");
			highLightElement(recordName);
			LoggingInfo("Care program enrollee record verified");
		} catch (Exception e) {
			Log.error("Failed to navigate to CPE record  " + e.getMessage());
			Assert.fail("Failed to navigate to CPE record  " + e.getMessage());
		}
	}

	public void verifyAbsenceofPatientHasInsurance() {
		try {
			By elePatientInsurance = By.xpath("//*[text()='Patient has Insurance']");
			boolean res = isElementPresent(elePatientInsurance);
			if (!res) {
				LoggingInfo("Patient has insurance field is not present in person account page");
			} else {
				LoggingInfo("Patient has insurance field is  present in person account page");
				Assert.assertTrue(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify patient has insurance field " + e.getMessage());
			Assert.fail("Failed to verify patient has insurance field" + e.getMessage());
		}
	}

	/**
	 * Function: Click on CCR record
	 *
	 * @author Trupti
	 */

	public void clickOnCCRRecord(String recordname) {
		try {
			// click on first CCR record
			By eleCcrRecord = getDynamicElement(ccrRecord, recordname);
			waitAndVerifyElement(eleCcrRecord);
			scrollToElement(eleCcrRecord);
			clickByJavascript(eleCcrRecord);
			LoggingInfo("Clicked on CCR record");
			setTimeOut(1000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click On CCR Record " + e.getMessage());
			Assert.fail("Failed to click On CCR Record" + e.getMessage());
		}
	}

	/**
	 * Function: Click on relationship edit button
	 *
	 * @author Trupti
	 */
	public void clickOnRelationshipEditButton() {
		try {
			By relationEdit = getDynamicElement(editButton, "Edit Relationship");
			waitAndVerifyElement(relationEdit);
			scrollToElement(relationEdit);
			setTimeOut(2000);
			click(relationEdit);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on relationship edit button " + e.getMessage());
			Assert.fail("Failed Click on relationship edit button" + e.getMessage());
		}
	}

	/**
	 * Function: Validate relationship dropdown values
	 *
	 * @author Trupti
	 */

	public void validateRelationshipDropDownValues() {
		try {

			String[] expectedPickListValues = { "--None--", "Patient-Spouse/Partner", "Patient-Parent",
					"Patient-Guardian", "Patient-Child", "Patient-Caregiver", "HCP-Prescribing", "HCP-Collaborating",
					"Patient-Other" };
			// Relationship
			By relationshipList = getDynamicElement(editFieldList, "Relationship");
			waitAndVerifyElement(relationshipList);
			click(relationshipList);
			By relationshipListDropDownOptions = getDynamicElement(editFieldListOptions, "Relationship");
			waitAndVerifyElement(relationshipListDropDownOptions);

			List<WebElement> picklistValue = getWebDriver().findElements(By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Relationship\"]//parent::div//lightning-base-combobox-item"));
			boolean isValid = false;
			for (int i = 0; i < picklistValue.size(); i++) {
				String actualPickListValue = picklistValue.get(i).getText();
				for (String expectedValue : expectedPickListValues) {
					if (actualPickListValue.equalsIgnoreCase(expectedValue)) {
						isValid = true;
						break;
					}
				}

				Assert.assertTrue(isValid, "Invalid picklist value: " + actualPickListValue);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify relationship dropdown values " + e.getMessage());
			Assert.fail("Failed to verifyrelationship dropdown values" + e.getMessage());
		}
	}

	/**
	 * Function: Click on cancel button
	 *
	 * @author Trupti
	 */

	public void clickCancelButton() {
		try {
			LoggingInfo("Verify user is able to click on cancel button");
			By eleCancelButton = getDynamicElement(eleButton, "Cancel");
			waitAndVerifyElement(eleCancelButton);
			click(eleCancelButton);
			setTimeOut(2000);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify and click on new button " + e.getMessage());
			Assert.fail("Failed to verify and click on new button " + e.getMessage());
		}
	}

	/**
	 * Function: Verify HCP field is not visible
	 *
	 * @author Trupti
	 */
	public void verifyHCPFieldIsNotVisible() {
		try {

			By hcpField = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"HCP type\"]");
			boolean found = isElementPresent(hcpField);
			Assert.assertFalse(found, "HCP type field is visible when it should not be.");
			LoggingInfo("HCP type field is not visible on UI");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify  HCP field is not visible " + e.getMessage());
			Assert.fail("Failed to verify  HCP field is not visible " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Party Role Relationship
	 *
	 * @author Trupti
	 */
	public void verifyPartyRoleRelationship() {
		try {
			// Party Role Relationship
			By relationshipField = getDynamicElement(detailsTitleLinkField, "Party Role Relationship");
			waitAndVerifyElement(relationshipField);
			scrollToElement(relationshipField);
			verifyDetails(relationshipField, "Patient-Related Entity-CCR", "Party Role Relationship");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Party Role Relationship " + e.getMessage());
			Assert.fail("Failed to Party Role Relationship " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Relationship
	 *
	 * @author Trupti
	 */
	public void verifyRelationship(String ralationship) {
		try {
			// Relationship
			refresh();
			By elRelationship = getDynamicElement(detailsLinkField, "Relationship");
			waitAndVerifyElement(elRelationship);
			scrollToElement(elRelationship);
			if (ralationship.equals("Spouse/Partner") || ralationship.equals("Parent") || ralationship.equals("Child")
					|| ralationship.equals("Caregiver") || ralationship.equals("Other")
					|| ralationship.equals("Guardian"))
				ralationship = "Patient-" + ralationship;
			if (ralationship.equals("Prescribing") || ralationship.equals("Collaborating"))
				ralationship = "HCP-" + ralationship;
			verifyDetails(elRelationship, ralationship, "Relationship");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Relationship " + e.getMessage());
			Assert.fail("Failed to verify Relationship " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Party Role Relationship List
	 *
	 * @author Trupti
	 */
	public void verifyPartyRoleRelationshipList() {
		try {
			boolean isValid = false;
			String[] partyrelationship = { "Patient-Caregiver-CCR", "Patient-Child-CCR", "Patient-Guardian-CCR",
					"Patient-HCP-Collaborating-CCR", "Patient-HCP-Prescribing-CCR", "Patient-Household Member-CCR",
					"Patient-Parent-CCR", "Patient-Related Entity-CCR", "Patient-Spouse/Partner-CCR" };
			List<WebElement> relations = getWebDriver()
					.findElements(By.xpath("//*[contains(@class,\"active lafPageHost\")]//table//th[1]//a"));

			String relationValue = "";

			for (int i = 0; i < relations.size(); i++) {
				relationValue = relations.get(i).getText();
				for (String expectedValue : partyrelationship) {
					if (relationValue.equalsIgnoreCase(expectedValue)) {
						isValid = true;
						break;
					}
				}

			}
			LoggingInfo("Successfully Verified Party Role Relationship");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to party relationship value " + e.getMessage());
			Assert.fail("Failed to party relationship value " + e.getMessage());
		}
	}

	public void verifyAndClickOnHCPRecord(String recordName) {
		try {
			waitForPageLoaded();
			By recordList = By.xpath("//tr//th[@scope='row']//span//a");
			boolean recordFound = false;
			for (int attempt = 0; attempt < 3; attempt++) {
				if (methodToAvoidStaleElementReferenceErrorElement(recordList)) {
					waitAndVerifyElement(recordList);
					setTimeOut(1000);
					List<WebElement> listOptions = getWebDriver().findElements(recordList);

					for (WebElement element : listOptions) {
						String record = element.getText();
						setTimeOut(1000);

						if (record.equalsIgnoreCase(recordName)) {

							JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
							js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
									highlightStyle);
							setTimeOut(1000);
							element.click();
							setTimeOut(2000);
							LoggingInfo("Clicked on record: " + recordName);
							recordFound = true;
							break;
						}
					}
				}

				if (recordFound) {
					break;
				}

				click(listSort);
				setTimeOut(2000);
			}

			if (!recordFound) {
				Log.error("Record not found after 3 attempts: " + recordName);
				Assert.fail("Failed to find record: " + recordName);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on account" + e.getMessage());
			Assert.fail("Failed to click on account " + e.getMessage());
		}
	}

	public void validateContactPointDetails() {
		try {
			setTimeOut(2000);
			scrollToHalfPage();
			By eleCPPhone = getDynamicElement(eleCBFields, "Contact Point Phones");
			scrollToElement(eleCPPhone);
			waitAndVerifyElement(eleCPPhone);
			LoggingInfo("Verified Contact Point Phones ");

			By eleCPEmails = getDynamicElement(eleCBFields, "Contact Point Emails");
			scrollToElement(eleCPEmails);
			waitAndVerifyElement(eleCPEmails);
			LoggingInfo("Verified Contact Point Emails ");

			By eleCPAddress = getDynamicElement(eleCBFields, "Contact Point Addresses");
			scrollToElement(eleCPAddress);
			waitAndVerifyElement(eleCPAddress);
			LoggingInfo("Verified Contact Point Addresses ");

		}

		catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Contact Point fields " + e.getMessage());
			Assert.fail("Failed to verify Contact Point fields" + e.getMessage());
		}
	}

	public void validateTwoMedicationRequests(String dose5a, String dose5b, String hcp) {
		try {

			List<WebElement> allData2 = getWebDriver().findElements(
					By.xpath("//*[contains(@class, 'active lafPageHost')]//*[@data-label=\"MedicationName\"]//span"));

			ArrayList<String> allData = new ArrayList<>();
			for (WebElement element : allData2) {
				allData.add(element.getText().trim());
			}

			logData("Actual Data:", allData);

			ArrayList<String> expectedData = new ArrayList<>();
			expectedData.add(dose5b);
			expectedData.add(dose5a);
			logData("Expected Data:", expectedData);

			allData = normalizeData(allData);
			expectedData = normalizeData(expectedData);

			logData("Normalized Actual Data:", allData);
			logData("Normalized Expected Data:", expectedData);

			boolean allExpectedFound = true;
			for (String expected : expectedData) {
				if (!allData.contains(expected)) {
					allExpectedFound = false;
					break;
				}
			}

			if (!allExpectedFound) {
				throw new AssertionError("Not all expected data is present in allData.");
			}

		} catch (Exception e) {
			Log.error("Failed to validate 2 Medication Requests: " + e.getMessage());
		}
	}

	public void clickonFirstMedicationRequest() {
		try {
			setTimeOut(2000);
			scrollToElement(eleFirstMR);
			waitAndVerifyElement(eleFirstMR);
			clickByJavascript(eleFirstMR);
			LoggingInfo("Clicked on first MR Successfully");
		} catch (Exception e) {
			Log.error("Failed to click on first MR Record  " + e.getMessage());
			Assert.fail("Failed to click on first MR Record " + e.getMessage());
		}
	}

	// Anand P
	public void clickonHealthConditionRecord() {
		try {
			setTimeOut(2000);
			scrollToElement(eleHealthCode);
			waitAndVerifyElement(eleHealthCode);
			clickByJavascript(eleHealthCode);
			LoggingInfo("Clicked on health record Successfully");
		} catch (Exception e) {
			Log.error("Failed to click on Record  " + e.getMessage());
			Assert.fail("Failed to click on Record " + e.getMessage());
		}
	}

	public void validateFirstReasonReferenceField() {
		try {
			setTimeOut(2000);
			scrollToElement(eleFirstReasonReference);
			waitAndVerifyElement(eleFirstReasonReference);
			highLightElement(eleFirstReasonReference);
			LoggingInfo("verified first reason reference successfully");
		} catch (Exception e) {
			Log.error("Failed to verify first reason refrence successfully  " + e.getMessage());
			Assert.fail("Failed to verify first reason refrence successfully " + e.getMessage());
		}
	}

	public void clickonSecondMedicationRequest() {
		try {
			setTimeOut(2000);
			scrollToElement(eleSecondMR);
			waitAndVerifyElement(eleSecondMR);
			click(eleSecondMR);
			LoggingInfo("Clicked on second MR Successfully");
		} catch (Exception e) {
			Log.error("Failed to click on secord MR Record  " + e.getMessage());
			Assert.fail("Failed to click on second MR Record " + e.getMessage());
		}
	}

	public void validateSecondReasonReferenceField() {
		try {
			setTimeOut(2000);
			scrollToElement(eleSecondReasonReference);
			waitAndVerifyElement(eleSecondReasonReference);
			highLightElement(eleSecondReasonReference);
			LoggingInfo("verified second reason reference successfully");
		} catch (Exception e) {
			Log.error("Failed to verify second reason refrence successfully  " + e.getMessage());
			Assert.fail("Failed to verify second reason refrence successfully " + e.getMessage());
		}
	}

	/**
	 * Function: Get consent expiry date
	 * 
	 * @author Trupti Zure
	 **/
	public String getCalculatedConsentExpiryDate(String patientState, String dob, String patientCert)
			throws ParseException {
		LocalDate calculatedConsentExpiryDate = new ConsentExpiryDate().PPAConsentExpiryDate(patientState, dob,
				patientCert);

		String formattedCalculatedConsentExpiryDate = formatDatemmdyyyy(calculatedConsentExpiryDate.toString());

		formattedCalculatedConsentExpiryDate = changeDateFormatmmddyyyy(formattedCalculatedConsentExpiryDate);
		return formattedCalculatedConsentExpiryDate;
	}

	/**
	 * Function: Validate compact layout fields and data of consent page layout
	 * 
	 * @author Trupti Zure
	 **/
	public void validateCompactLayoutConsentFieldsData(String patientName, String consentName, String legalRep,
			String consentExpiryDate) {
		try {
			// Authorization Form Consent title
			waitAndVerifyElement(eleConsentTitle);
			scrollToElement(eleConsentTitle);
			String titleName = patientName + " : " + consentName;
			verifyDetails(eleConsentTitle, titleName, "Authorization Form Consent");

			// Consent giver,Authorization Form Text
			String[] expectedValues1 = { legalRep, "Dupixent Patient Authorization Form Text" };
			String[] fieldName1 = { "Consent Giver", "Authorization Form Text" };
			for (int i = 0; i < fieldName1.length; i++) {
				By field = getDynamicElement(compactLayoutLinkField, fieldName1[i]);
				waitAndVerifyElement(field);
				scrollToElement(field);
				verifyDetails(field, expectedValues1[i], fieldName1[i]);
			}

			// Consent Captured Source Type,Status,Consent Expiration Date Time
			String[] expectedValues2 = { "Written", "Active" };
			String[] fieldName2 = { "Consent Captured Source Type", "Status" };
			for (int i = 0; i < fieldName2.length; i++) {
				By field = getDynamicElement(compactLayoutTextField, fieldName2[i]);
				waitAndVerifyElement(field);
				scrollToElement(field);
				verifyDetails(field, expectedValues2[i], fieldName2[i]);
			}

			// Consent Expiration Date Time
			By expiryfield = getDynamicElement(compactLayoutTextField, "Consent Expiration Date Time");
			waitAndVerifyElement(expiryfield);
			scrollToElement(expiryfield);
			String date = getText(expiryfield).split(",")[0];
			Assert.assertEquals(date, consentExpiryDate);
			LoggingInfo("Consent Expiration Date is populated correctly-" + date);

		} catch (Exception e) {
			Log.error("Failed to Validate compact layout fields and data of consent page layout  " + e.getMessage());
			Assert.fail("Failed to Validate compact layout fields and data of consent page layout " + e.getMessage());
		}
	}

	/**
	 * Function: Validate information fields and data of consent page layout
	 * 
	 * @author Trupti Zure
	 **/

	public void validateInfoSecConsentFieldsData(String patientName, String consentName, String consentExpiryDate,
			String patientCertDate, String legalRep, String careProgram) {
		try {

			String titleName = patientName + " : " + consentName;
			consentCaptureDate = GetInstance(ConsentCaptureDate.class);
			String textConsentCaptureDate = consentCaptureDate.getConsentCapturedDateTimemdyyyy(patientCertDate);
			careProgram = careProgram.split("-")[0].trim();

			// Text fields-Name,Consent Captured Source Type,Status,Consent Capture Date
			String[] expectedValues1 = { titleName, "Written", "Active", textConsentCaptureDate };
			String[] fieldName1 = { "Name", "Consent Captured Source Type", "Status", "Consent Capture Date" };
			for (int i = 0; i < fieldName1.length; i++) {
				By field = getDynamicElement(strAccountObjectDetails, fieldName1[i]);
				waitAndVerifyElement(field);
				scrollToElement(field);
				verifyDetails(field, expectedValues1[i], fieldName1[i]);
			}

			// Consent Expiration Date Time
			By expiryfield = getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time");
			waitAndVerifyElement(expiryfield);
			scrollToElement(expiryfield);
			String date = getText(expiryfield).split(",")[0];
			Assert.assertEquals(date, consentExpiryDate);
			LoggingInfo("Consent Expiration Date is populated correctly-" + date);

			// Link fields-Authorization Form Text,Consent Giver,Care Program,Related Record
			String[] expectedValues2 = { "Dupixent Patient Authorization Form Text", legalRep, careProgram,
					patientName };
			String[] fieldName2 = { "Authorization Form Text", "Consent Giver", "Care Program", "Related Record" };
			for (int i = 0; i < fieldName2.length; i++) {
				By field = getDynamicElement(accDetailsLinkField, fieldName2[i]);
				waitAndVerifyElement(field);
				scrollToElement(field);
				highLightElement(field);
				verifyDetails(field, expectedValues2[i], fieldName2[i]);
			}

		} catch (Exception e) {
			Log.error("Failed to Validate information fields and data of consent page layout  " + e.getMessage());
			Assert.fail("Failed to Validate information fields and data of consent page layout " + e.getMessage());
		}
	}

	/**
	 * Function: Validate system information fields and data of consent page layout
	 * 
	 * @author Trupti Zure
	 **/

	public void validateSystemInformationFields() {
		try {
			scrollToBottomOfPage();
			String[] fieldName1 = { "Last Modified By", "Integration ID" };
			for (int i = 0; i < fieldName1.length; i++) {
				By field = getDynamicElement(strAccountObjectDetails, fieldName1[i]);
				waitAndVerifyElement(field);
				scrollToElement(field);
				String text = getText(field).split(",")[0];
				Assert.assertTrue(!text.isEmpty(), "Data is not present");
			}

			// Created By
			By field = getDynamicElement(strAccountObjectDetails, "Created By");
			waitAndVerifyElement(field);
			scrollToElement(field);
			String text = getText(field).split(",")[0];
			Assert.assertTrue(!text.isEmpty(), "Data is not present");
			LoggingInfo("System information field verified");

		} catch (Exception e) {
			Log.error("Failed to validate system information fields of consent page layout " + e.getMessage());
			Assert.fail("Failed to validate system information fields of consent page layout " + e.getMessage());
		}
	}

	/**
	 * Function: click on Consent account record
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void clickOnConsentAccountRecord() throws InterruptedException {
		try {
			By accfield = getDynamicElement(accDetailsLink, "Related Record");
			waitAndVerifyElement(accfield);
			scrollToElement(accfield);
			clickByJavascript(accfield);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Consent Account Record " + e.getMessage());
			Assert.fail("Failed to click on Consent Account Record " + e.getMessage());
		}

	}

	/**
	 * Function: click on Consent Row from Related Section
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnConsentRecord(String Patientname, String consentName) throws InterruptedException {
		try {
			scrollToBottomOfPage();
			setTimeOut(5000);
			String AuthorizationName = Patientname + " : " + consentName;
			By TextMessagingObject = getDynamicElement(eleTextMessageConsentRow, AuthorizationName);
			scrollToElement(TextMessagingObject);
			waitAndVerifyElement(TextMessagingObject);
			clickByJavascript(TextMessagingObject);
			LoggingInfo("User clicked on " + consentName);
			setTimeOut(3000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Consent Record " + e.getMessage());
			Assert.fail("Failed to click on consent Record " + e.getMessage());
		}

	}

	public void validateConsentExpiryDate(String consentExpiryDate) {
		try {
			// Consent Expiration Date Time
			By expiryfield = getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time");
			waitAndVerifyElement(expiryfield);
			scrollToElement(expiryfield);
			String date = getText(expiryfield).split(",")[0];
			Assert.assertEquals(date, consentExpiryDate);
			LoggingInfo("Consent Expiration Date is populated correctly-" + date);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Consent Expiry Date " + e.getMessage());
			Assert.fail("Failed to validate Consent Expiry Date " + e.getMessage());
		}
	}

	public void navigateToAdditionalInfoSection() {
		try {
			setTimeOut(2000);
			scrollToElement(eleAddInfo);
			waitAndVerifyElement(eleAddInfo);
			LoggingInfo("verified Additional Information successfully");
		} catch (Exception e) {
			Log.error("Failed to verify Additional Information successfully  " + e.getMessage());
			Assert.fail("Failed to verify Additional Information successfully " + e.getMessage());
		}
	}

	public void validateNewFields(String[] cpeDetails, String docID) {
		try {

			String pName = cpeDetails[0];
			String pDOB = cpeDetails[1];
			String pEmail = cpeDetails[2];
			String[] nameParts = cpeDetails[0].split(" ");
			String firstName = nameParts[0];
			String lastName = nameParts[nameParts.length - 1];

			By eledDocID = getDynamicElement(detailFields, "Document #");
			waitAndVerifyElement(eledDocID);
			highLightElement(eledDocID);
			String actualValue = getText(eledDocID);
			verifyField("Document ID", actualValue, docID);

			By elePatientFirstName = getDynamicElement(detailFields, "Patient First Name");
			waitAndVerifyElement(elePatientFirstName);
			scrollToElement(elePatientFirstName);
			highLightElement(elePatientFirstName);
			String actualName = getText(elePatientFirstName);
			verifyField("Patient First Name", actualName, firstName);

			By elePatientLastName = getDynamicElement(detailFields, "Patient Last Name");
			waitAndVerifyElement(elePatientLastName);
			highLightElement(elePatientLastName);
			String actualLName = getText(elePatientLastName);
			verifyField("Patient Last Name", actualLName, lastName);

			By elePatientEmail = getDynamicElement(strPatientEmail, "Patient Email Address");
			waitAndVerifyElement(elePatientEmail);
			highLightElement(elePatientEmail);
			String actualEmail = getText(elePatientEmail);
			verifyField("Patient Email", actualEmail, pEmail);

			String opDate = formatDatemddyyyy(pDOB);
			By elePatientDOB = getDynamicElement(detailFields, "Patient Date of Birth");
			waitAndVerifyElement(elePatientDOB);
			scrollToElement(elePatientDOB);
			highLightElement(elePatientDOB);
			String actualDob = getText(elePatientDOB);
			System.out.println(actualDob);
			// String actualDob = getText(elePatientDOB);

			By eleSumbitterName = getDynamicElement(strDocInfo, "Doc Submitter Name");
			waitAndVerifyElement(eleSumbitterName);
			highLightElement(eleSumbitterName);

			By eleSumbitterEmail = getDynamicElement(strDocInfo, "Doc Submitter Email Address");
			waitAndVerifyElement(eleSumbitterEmail);
			scrollToElement(eleSumbitterEmail);
			highLightElement(eleSumbitterEmail);

			By eleSumbitterRole = getDynamicElement(strDocInfo, "Doc Submitter Role");
			waitAndVerifyElement(eleSumbitterRole);
			highLightElement(eleSumbitterRole);
			LoggingInfo("verified Doc Submitter Role");

			By eleSumbitterFax = getDynamicElement(strDocInfo, "Submitter Fax Number");
			waitAndVerifyElement(eleSumbitterFax);
			highLightElement(eleSumbitterFax);
			LoggingInfo("verified Doc Submitter Fax");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate New fields " + e.getMessage());
		}
	}

	public void openCPERecord() throws Exception {

		try {

			By eleCPERec = By.xpath("(//*[contains(@class,\"active lafPageHost\")]//th//a[contains(text(),'')])[1]");
			waitAndVerifyElement(eleCPERec);
			scrollToElement(eleCPERec);
			clickByJavascript(eleCPERec);
			LoggingInfo("Clicked on CPE Record");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on CPE Record " + e.getMessage());
		}
	}

	/**
	 * Function: Validate HCP Specialty Name is present
	 * 
	 * @author Sonica P
	 **/
	public void validateHCPSpecialty() {
		try {
			scrollToElement(eleHCPSpecialty);
			waitAndVerifyElement(eleHCPSpecialty);
			LoggingInfo("Validate HCP SPecialty");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate HCP Specialty " + e.getMessage());
		}
	}

	/**
	 * Function: Validate Manual Override Checkbox is checked
	 * 
	 * @author Sonica P
	 **/
	public void validateManualOverRide() {
		try {
			refresh();
			By showMoreActionsBtn = getDynamicElement(eleShowActionsBtn, "Show one more action");
			scrollToElement(showMoreActionsBtn);
			click(showMoreActionsBtn);
			setTimeOut(2000);

			By editBtn = getDynamicElement(eleShowActionsBtn, "Edit");
			click(editBtn);
			click(eleManualOverrideCheckbox);
			click(eleSaveBtn);
			LoggingInfo("Validated Manual Override Checkbox");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Manual Override Button " + e.getMessage());
		}
	}

	/**
	 * Function: click on Copay Consent Row from Related Section
	 * 
	 * @author Sonica
	 **/
	public void clickOnCopayConsentRecord(String Patientname) throws InterruptedException {
		try {
			scrollToBottomOfPage();
			;
			setTimeOut(5000);
			String AuthorizationName = Patientname + " : Copay Consent";
			By TextMessagingObject = getDynamicElement(eleTextMessageConsentRow, AuthorizationName);
			scrollToElement(TextMessagingObject);
			waitAndVerifyElement(TextMessagingObject);
			clickByJavascript(TextMessagingObject);
			LoggingInfo("User clicked on Copay Consent Authorization");
			setTimeOut(3000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Text Consent Record " + e.getMessage());
			Assert.fail("Failed to click on Text Consent Record " + e.getMessage());
		}

	}

	/**
	 * Function: Search and open Required Record by providing Search Filter using
	 * GlobalSearch SearchFilter: Account, Cases,Care Program Enrollee....
	 * SearchValue: Record/Account/Case name to be searched....
	 * 
	 * @author Shanavaz Nishani
	 * 
	 *         public void globalSearch(String SearchFilter, String SearchValue) {
	 *         try { setTimeOut(5000); By btnGlobalSearch =
	 *         By.xpath("//button[@aria-label='Search']");
	 *         waitAndVerifyElement(btnGlobalSearch); click(btnGlobalSearch);
	 *         setTimeOut(3000);
	 * 
	 *         By eleSearchFilter =
	 *         By.xpath("//div[@part='input-text']//input[contains(@data-value,'Search:')]");
	 *         waitAndVerifyElement(eleSearchFilter); click(eleSearchFilter);
	 *         setTimeOut(3000);
	 * 
	 *         String strFilterValue = "//ul[@aria-label='All Searchable
	 *         Items']//li//span[@title='%s']//ancestor::lightning-base-combobox-item";
	 *         String xp =String.format(strFilterValue, SearchFilter); By
	 *         eleSearchFilterValue = By.xpath(xp);
	 *         scrollToElement(eleSearchFilterValue);
	 *         highLightElement(eleSearchFilterValue); setTimeOut(4000);
	 *         click(eleSearchFilterValue); setTimeOut(4000);
	 * 
	 *         Actions act = new Actions(getWebDriver()); By eleSearchInput =
	 *         By.xpath("//lightning-input[@class='saInput slds-grow
	 *         slds-form-element']//div[@part='input-text']//label[contains(text(),'Search')]//following-sibling::div//input");
	 *         act.sendKeys(Keys.TAB).perform(); setTimeOut(3000);
	 *         inputText(eleSearchInput, SearchValue); setTimeOut(4000);
	 * 
	 *         act.sendKeys(Keys.DOWN).perform(); setTimeOut(2000);
	 *         act.sendKeys(Keys.ENTER).perform();
	 * 
	 *         LoggingInfo("Opened " + SearchValue + " successfully"); } catch
	 *         (Exception e) { e.printStackTrace(); Log.error("Failed to search " +
	 *         SearchValue + " " + e.getMessage()); } }
	 **/

	/**
	 * Function: Click on active check button
	 *
	 * @author anand pawar
	 */
	public void clickActiveCheckBox() {
		try {
			JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
			String script = """
					    var checkbox = document.evaluate(
					        "//*[contains(@class,'active lafPageHost')]//span[text()='Active']/parent::label/following-sibling::div//input[@name='IsActive']",
					        document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

					    if (checkbox) {
					        checkbox.click();
					        return "Checkbox clicked.";
					    } else {
					        return "Checkbox not found.";
					    }
					""";

			Object result = js.executeScript(script);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on checkbox" + e.getMessage());
			Assert.fail("Failed Click on checkbox" + e.getMessage());
		}
	}

	public void clickActiveCheckBoxCTM() {
		try {

			By insuranceAddDate = getDynamicElement(strTextBoxesInput, "End Date");
			scrollToElement(insuranceAddDate);
			waitAndVerifyElement(insuranceAddDate);
			String date = getDateNDaysFromToday(2);
			inputText(insuranceAddDate, date);
			setTimeOut(2000);

			By eleTime = getDynamicElement(strTextBoxesInput2, "End Date");
			click(eleTime);
			setTimeOut(2000);

			JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
			String script = """
					    var checkbox = document.evaluate(
					        "//*[contains(@class,'active lafPageHost')]//span[text()='Active']/parent::label/following-sibling::div//input[@type='checkbox']",
					        document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;

					    if (checkbox) {
					        checkbox.click();
					        return "Checkbox clicked.";
					    } else {
					        return "Checkbox not found.";
					    }
					""";

			Object result = js.executeScript(script);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on checkbox" + e.getMessage());
			Assert.fail("Failed Click on checkbox" + e.getMessage());
		}
	}

	/**
	 * Function: navigate to all accounts
	 *
	 * @author Kavyashree
	 */

	public void navigateToAllaccount() {
		try {

			Log.info("Navigate to All Accounts");
			click(listViewButton);

			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, "All Accounts");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);
			LoggingInfo("Navigated to All Accounts");

		} catch (Exception e) {
			Log.error("Failed to navigate to All Accounts  " + e.getMessage());
			Assert.fail("Failed to navigate to All Accounts " + e.getMessage());
		}
	}

	/**
	 * Function: navigate to First Account
	 *
	 * @author Kavyashree
	 */

	public void clickonFirstAccount() {
		try {
			waitForPageLoaded();
			setTimeOut(2000);
			waitAndVerifyElement(eleFirstAccount);
			waitForPresenceOfElementLocated(eleFirstAccount);
			scrollToElement(eleFirstAccount);
			setTimeOut(3000);
			clickByJavascript(eleFirstAccount);
			LoggingInfo("Clicked on first account");

		} catch (Exception e) {
			Log.error("Failed to click on first account  " + e.getMessage());
			Assert.fail("Failed to click on first account  " + e.getMessage());
		}
	}

	/**
	 * Function: verify Patient History Tracing data
	 *
	 * @author Kavyashree
	 */

	public void verifyPatientHistoryTrackingdata() {
		try {

			setTimeOut(2000);
			scrollToHalfPage();
			;
			waitAndVerifyElement(elePatientAccHistory);
			scrollToElement(elePatientAccHistory);
			setTimeOut(2000);
			LoggingInfo("verified patient History Tracking data");

		} catch (Exception e) {
			Log.error("Failed to verify patient History Tracking data " + e.getMessage());
			Assert.fail("Failed to verify patient History Tracking data  " + e.getMessage());
		}
	}

	/**
	 * Function: navigate to First Case
	 *
	 * @author Kavyashree
	 */

	public void clickonFirstCase() {
		try {
			setTimeOut(2000);
			click(eleCaseNumber);
			LoggingInfo("Clicked on first Case");

		} catch (Exception e) {
			Log.error("Failed to click on first Case  " + e.getMessage());
			Assert.fail("Failed to click on first Case  " + e.getMessage());
		}
	}

	/**
	 * Function: verify Case History
	 *
	 * @author Kavyashree
	 */

	public void verifyCaseHistory() {
		try {

			setTimeOut(2000);
			waitAndVerifyElement(eleCaseHistory);
			setTimeOut(2000);
			LoggingInfo("verified case History Tracking data");

		} catch (Exception e) {
			Log.error("Failed to verify case History Tracking data " + e.getMessage());
			Assert.fail("Failed to verify case History Tracking data  " + e.getMessage());
		}
	}

	/**
	 * Function: navigate to Injection Training
	 *
	 * @author Kavyashree
	 */

	public void navigateToInjectionTraining() {
		try {

			click(listViewButton);
			waitForPageLoaded();
			By eleIT = getDynamicElement(strDocumentPageTitle, "Injection Training");
			waitAndVerifyElement(eleIT);
			clickByJavascript(eleIT);
			setTimeOut(2000);
			LoggingInfo("Navigated to Injection Training");

		} catch (Exception e) {
			Log.error("Failed to navigate to Injection Training " + e.getMessage());
			Assert.fail("Failed to navigate to Injection Training " + e.getMessage());
		}
	}

	/**
	 * Function: navigate to Welcome Message
	 *
	 * @author Kavyashree
	 */

	public void navigateToWelcomeMessage() {
		try {

			click(listViewButton);
			waitForPageLoaded();
			By eleWM = getDynamicElement(strDocumentPageTitle, "Welcome Message");
			waitAndVerifyElement(eleWM);
			clickByJavascript(eleWM);
			setTimeOut(2000);
			LoggingInfo("Navigated to welcome Message");

		} catch (Exception e) {
			Log.error("Failed to navigate to welcome message  " + e.getMessage());
			Assert.fail("Failed to navigate to welcome message " + e.getMessage());
		}
	}

	/**
	 * Function: navigate to order follow up
	 *
	 * @author Kavyashree
	 */

	public void navigateToOrderFollowUp() {
		try {

			click(listViewButton);
			waitForPageLoaded();
			By eleOrder = getDynamicElement(strDocumentPageTitle, "Order Follow Up");
			waitAndVerifyElement(eleOrder);
			clickByJavascript(eleOrder);
			setTimeOut(2000);
			LoggingInfo("Navigated to Order Follow Up");

		} catch (Exception e) {
			Log.error("Failed to navigate to Order Follow Up  " + e.getMessage());
			Assert.fail("Failed to navigate to Order Follow Up " + e.getMessage());
		}
	}

	/**
	 * Function: navigate to First Record
	 *
	 * @author Kavyashree
	 */

	public void clickonfirstRecord() {
		try {
			setTimeOut(2000);
			click(eleFirstRecord);
			LoggingInfo("Clicked on first Record");

		} catch (Exception e) {
			Log.error("Failed to click on first Record  " + e.getMessage());
			Assert.fail("Failed to click on first Record  " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Audit trail related list
	 *
	 * @author Kavyashree
	 */

	public void verifyHistory() {
		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleAuditTrailHistory);
			LoggingInfo("verified Audit trail related list");

		} catch (Exception e) {
			Log.error("Failed to verify Audit trail related list  " + e.getMessage());
			Assert.fail("Failed to verify Audit trail related list  " + e.getMessage());
		}
	}

	/**
	 * Function: Check status field of record
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyStatusField(String status) {
		try {
			waitForPageLoaded();
			By eleStatus = getDynamicElement(strAccountObjectDetails, "Status");
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			verifyDetails(eleStatus, status, "Account status");
			LoggingInfo("Verified care program enrollee status");
		} catch (Exception e) {
			Log.error("Failed to verify Account record status  " + e.getMessage());
			Assert.fail("Failed to verify Account record status  " + e.getMessage());
		}

	}

	/**
	 * Function: Click on account status update
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnAccountStatusUpdate() {
		try {
			By accountUpdate = getDynamicElement(strButton, "Account Status Update");
			waitAndVerifyElement(accountUpdate);
			scrollToElement(accountUpdate);
			click(accountUpdate);
			Log.info("Click on account status update button");
		} catch (Exception e) {
			Log.error("Failed to click on account status button  " + e.getMessage());
			Assert.fail("Failed to click on account status button  " + e.getMessage());
		}
	}

	/**
	 * Function: Select status
	 * 
	 * @author Trupti Zure
	 **/
	public void selectStatus(String status) {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			selectItemFromList(eleSelectDropDown, status);
			LoggingInfo("Selected account status as-" + status);
		} catch (Exception e) {
			Log.error("Failed to select on account status  " + e.getMessage());
			Assert.fail("Failed to select on account status " + e.getMessage());
		}
	}

	/**
	 * Function: Select winner patient
	 * 
	 * @author Trupti Zure
	 **/
	public String selectWinnerPatient() {
		String account = null;
		try {
			waitAndVerifyElement(eleWinnerPatient);
			inputText(eleWinnerPatient, "Automation");
			waitAndVerifyElement(eleShowMoreResult);
			clickByJavascript(eleShowMoreResult);
			waitAndVerifyElement(eleSelectFirstRecord);
			click(eleSelectFirstRecord);
			// Get Account name
			waitAndVerifyElement(firstRecord);
			account = getText(firstRecord);
			scrollToElement(eleSelectButton);
			click(eleSelectButton);
			setTimeOut(2000);
			waitAndVerifyElement(eleNext);
			clickByJavascript(eleNext);
			LoggingInfo("Selected winner patient as -" + account);
		} catch (Exception e) {
			Log.error("Failed to select winner patient " + e.getMessage());
			Assert.fail("Failed to select winner patient " + e.getMessage());
		}
		return account;
	}

	/**
	 * Function: Validate confirmation status and values
	 * 
	 * @author Trupti Zure
	 **/

	public void validateConfirmationStatusAndValues() {
		try {
			waitAndVerifyElement(confirmationMSG);

			String actualMsg = getText(confirmationMSG).trim();
			String expectedMsg = "This will inactivate the patient and remove it from all the Care Programs. Do you wish to Continue?";
			Assert.assertEquals(actualMsg, expectedMsg, "Confirmation message does not match the expected text.");

			// Validate the presence of "Yes" and "No" radio buttons
			By yesRadioButton = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Yes\"]//ancestor::label//span[@class=\"slds-radio_faux\"]");
			By noRadioButton = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"No\"]//ancestor::label//span[@class=\"slds-radio_faux\"]");

			Assert.assertTrue(isElementDisplayed(yesRadioButton), "'Yes' radio button is not displayed.");
			Assert.assertTrue(isElementDisplayed(noRadioButton), "'No' radio button is not displayed.");

			LoggingInfo(
					"User received confirmation prompt: 'This will inactivate the patient and remove it from all the Care Programs. Do you wish to Continue?' and options consist of Yes and No.");

		} catch (Exception e) {
			Log.error("Failed to validate confirmation status and values: " + e.getMessage());
			Assert.fail("Failed to validate confirmation status and values: " + e.getMessage());
		}
	}

	/**
	 * Function: Confirm account status update
	 * 
	 * @author Trupti Zure
	 **/
	public void confirmAccountStatusUpdate(String option) {
		try {
			By eleradioBox = getDynamicElement(radioBox, option);
			clickByJavascript(eleradioBox);
			Log.info("Selected -" + option);
			click(eleNext);
			Log.info("Clicked on Next");
		} catch (Exception e) {
			Log.error("Failed to select winner patient " + e.getMessage());
			Assert.fail("Failed to select winner patient " + e.getMessage());
		}
	}

	/**
	 * Function: Validate winner patient account is read only
	 * 
	 * @author Trupti Zure
	 **/

	public void validatePatientAccountFieldIsReadOnly(String name) {
		try {
			waitAndVerifyElement(eleEditButton);
			scrollToElement(eleEditButton);
			clickByJavascript(eleEditButton);
			By patientField = By.xpath(
					"//div[@class='actionBody']//records-record-layout-item[@field-label='Winner Patient']//span[contains(@class, 'test-id__field-value') and contains(@class, 'is-read-only')]");
			waitAndVerifyElement(patientField);
			scrollToElement(patientField);

			// Confirm the field is read-only via class
			String classAttr = getAttributeValue(patientField, "class");
			Assert.assertTrue(classAttr.contains("is-read-only"), "Field is not marked as read-only.");
			By patientFieldText = By.xpath(
					"(//div[@class='actionBody']//records-record-layout-item[@field-label='Winner Patient']//span[contains(@class, 'test-id__field-value') and contains(@class, 'is-read-only')]//span)[2]");

			String fieldValue = getText(patientFieldText);
			Assert.assertEquals(fieldValue, name, "Patient name does not match.");

			LoggingInfo("Verified that the patient account field is read-only and shows the correct name.");

		} catch (Exception e) {
			Log.error("Failed to verify patient account read-only field: " + e.getMessage());
			Assert.fail("Failed to verify patient account read-only field: " + e.getMessage());
		}
	}

	/**
	 * Function: Click on member plan record
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnMemberPlanRecord(String recordName) {
		try {
			By record = getDynamicElement(strCommanRecordName, recordName);
			waitAndVerifyElement(record);
			clickByJavascript(record);
			LoggingInfo("Clicked on-" + recordName);
		} catch (Exception e) {
			Log.error("Failed to Clicked on HCP record" + e.getMessage());
			Assert.fail("Failed to Clicked on HCP record  " + e.getMessage());
		}
	}

	/**
	 * Function: Verify member plan details
	 *
	 * @author Navita
	 **/
	public void validateMemberPlanDetails(String InsuAddDate, String DOB, String ID) {
		try {
			LoggingInfo("Verify Member Plan Fields ");
			setTimeOut(2000);
			By insuAddDate = getDynamicElement(strAccountObjectDetails, "Insurance Add Date");
			scrollToElement(insuAddDate);
			waitAndVerifyElement(insuAddDate);
			verifyDetails(insuAddDate, InsuAddDate, "Insurance Add Date");
			LoggingInfo(" Insurance Add Date " + insuAddDate + " Verified Successfully ");

			By policyHolderDOB = getDynamicElement(strAccountObjectDetails, "Policyholder DOB");
			scrollToElement(policyHolderDOB);
			waitAndVerifyElement(policyHolderDOB);
			verifyDetails(policyHolderDOB, DOB, "Policyholder DOB");
			LoggingInfo(" Policyholder DOB " + policyHolderDOB + " Verified Successfully ");

			By planID = getDynamicElement(strAccountObjectDetails, "Plan ID");
			scrollToElement(planID);
			waitAndVerifyElement(planID);
			verifyDetails(planID, ID, "Plan ID");
			LoggingInfo(" Plan ID " + planID + " Verified Successfully ");

		} catch (Exception e) {
			Log.error("Failed to verify Consent Status " + e.getMessage());
			Assert.fail("Failed to verify Consent Status " + e.getMessage());
		}
	}

	/**
	 * Function: Click on medication record
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnMedicationRecordByIndex(int index) {
		try {
			By record = By.xpath(
					"(//*[contains(@class,'active lafPageHost')]//th[contains(@data-label, 'Name')]//span[@class='slds-truncate']//span[contains(text(), 'MR-')])["
							+ index + "]");
			waitAndVerifyElement(record);
			clickByJavascript(record);
			LoggingInfo("Clicked on medication record " + index);

		} catch (Exception e) {
			Log.error("Failed to click on the record with index " + index + ": " + e.getMessage());
			Assert.fail("Failed to click on the record with index " + index + ": " + e.getMessage());
		}
	}

	/**
	 * Function:Collect health condition
	 * 
	 * @author Trupti
	 **/
	public void addNewHealthCondition(String hcCode) {

		try {
			By searchPatient = By
					.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@placeholder=\"Search Accounts...\"]");
			waitAndVerifyElement(searchPatient);
			scrollToElement(searchPatient);
			// inputText(searchPatient, );
			click(searchPatient);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

			By searchIndication = By
					.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@placeholder=\"Search Care Programs...\"]");
			waitAndVerifyElement(searchIndication);
			scrollToElement(searchIndication);
			// inputText(searchPatient, );
			click(searchIndication);
			// Actions act1 = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

			// Condition Code
			waitForPageLoaded();
			waitAndVerifyElement(searchCodeSets);
			scrollToElement(searchCodeSets);
			inputText(searchCodeSets, hcCode);
			waitAndVerifyElement(eleShowMoreResult);
			clickByJavascript(eleShowMoreResult);
			waitAndVerifyElement(eleSelectFirstHC);
			click(eleSelectFirstHC);
			scrollToElement(eleSelectButton);
			click(eleSelectButton);
			setTimeOut(2000);
			LoggingInfo("Successfully selected Health condition code");

			// StartDate
			waitAndVerifyElement(startDate);
			scrollToElement(startDate);
			String startdate = getBackDateNDaysFromToday(10);
			inputText(startDate, startdate);

			// Eosinophil Count Populated
			By eosDropDown = getDynamicElement(strDropDownBox, "Eosinophil Count Populated");
			waitAndVerifyElement(eosDropDown);
			scrollToElement(eosDropDown);
			click(eosDropDown);
			By eosDropDownOptions = getDynamicElement(strDropDownBoxOptions, "Eosinophil Count Populated");
			waitAndVerifyElement(eosDropDownOptions);
			selectItemFromList(eosDropDown, eosDropDownOptions, "No", "Eosinophil Count Populated");

			By saveBtn = getDynamicElement(eleButton, "Save");
			click(saveBtn);
			setTimeOut(5000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enroll team memebers: " + e.getMessage());
			Assert.fail("Failed to enroll team memebers: " + e.getMessage());
		}
	}

	public void VerifyToEnterPatientDetails(String firstname, String lastName) {
		try {
			By eleFirstName = getDynamicElement(strAccountObjectFields, "firstName");
			scrollToElement(eleFirstName);
			click(eleFirstName);
			inputText(eleFirstName, firstname);

			By eleLastName = getDynamicElement(strAccountObjectFields, "lastName");
			scrollToElement(eleLastName);
			click(eleLastName);
			inputText(eleLastName, lastName);
			LoggingInfo("Entered name successfuly");

		} catch (Exception e) {
			Log.error("Failed to enter patient details " + e.getMessage());
			Assert.fail("Failed to enter patient details  " + e.getMessage());
		}
	}

	/**
	 * Function: Click on Next button
	 * 
	 * @author Kavyashree
	 **/

	public void clickOnNext() {
		try {
			setTimeOut(2000);
			click(eleNext);
			setTimeOut(4000);
			LoggingInfo("clicked on next button successfuly");

		} catch (Exception e) {
			Log.error("Failed to click on next button " + e.getMessage());
			Assert.fail("Failed to click on next button  " + e.getMessage());
		}
	}

	/**
	 * Function: Validate Status and winner patient fields is read only
	 * 
	 * @author Kavyashree
	 **/

	public void validateStatusAndWinnerPatientIsReadOnly() {
		try {
			waitAndVerifyElement(eleEditButton);
			scrollToElement(eleEditButton);
			clickByJavascript(eleEditButton);
			By winnerpatientField = By.xpath(
					"//div[@class='actionBody']//records-record-layout-item[@field-label='Winner Patient']//span[contains(@class, 'test-id__field-value') and contains(@class, 'is-read-only')]");
			waitAndVerifyElement(winnerpatientField);
			scrollToElement(winnerpatientField);

			// Confirm the field is read-only via class
			String classAttr = getAttributeValue(winnerpatientField, "class");
			Assert.assertTrue(classAttr.contains("is-read-only"), "Field is not marked as read-only.");

			By eleStatusField = By.xpath(
					"//div[@class='actionBody']//records-record-layout-item[@field-label='Status']//span[contains(@class, 'test-id__field-value') and contains(@class, 'is-read-only')]");
			waitAndVerifyElement(eleStatusField);
			scrollToElement(eleStatusField);

			// Confirm the field is read-only via class
			String classAttrStatus = getAttributeValue(eleStatusField, "class");
			Assert.assertTrue(classAttrStatus.contains("is-read-only"), "Field is not marked as read-only.");

			LoggingInfo("Verified that the Status and winner patient fields  is read-only ");

		} catch (Exception e) {
			Log.error("Failed to verify Status and winner patient fields are read-only field: " + e.getMessage());
			Assert.fail("Failed to verify Status and winner patient fields read-only field: " + e.getMessage());
		}
	}

	/**
	 * Function: Verify to create Pharmacy Member Plan
	 * 
	 * @author Kavyashree
	 **/

	public void VerifyToCreatePMP(String patientDOB, String memberPlan) {
		try {
			setTimeOut(2000);
			click(eleNextMP);
			setTimeOut(4000);
			Actions act = new Actions(getWebDriver());
			By eleSearchPayer = By.xpath("//*[@placeholder='Search Accounts...']");
			scrollToElement(eleSearchPayer);
			click(eleSearchPayer);
			inputText(eleSearchPayer, memberPlan);
			setTimeOut(4000);
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(4000);

			waitAndVerifyElement(elePolicyHolderDOB);
			verifyAndEnterInfoInputField(elePolicyHolderDOB, patientDOB, patientDOB);

			waitAndVerifyElement(eleInsuranceDate);
			verifyAndEnterInfoInputField(eleInsuranceDate, patientDOB, patientDOB);

			By elePlanID = By.xpath("//input[@name='PlanID_ICC__c']");
			scrollToElement(elePlanID);
			click(elePlanID);
			inputText(elePlanID, "234567");

			LoggingInfo("Created Pharmacy Payer successfully");

		} catch (Exception e) {
			Log.error("Failed to Create Pharmacy Payer" + e.getMessage());
			Assert.fail("Failed to Create Pharmacy Payer " + e.getMessage());
		}
	}

	/**
	 * Function: Click on New Member plan
	 * 
	 * @author Kavyashree
	 **/

	public void clickOnNewMemberPlan() {
		try {
			setTimeOut(20000);
			By NewButton = getDynamicElement(strNewButton, "Member Plans");
			clickByJavascript(NewButton);
			setTimeOut(4000);
			LoggingInfo("clicked on New button successfuly");

		} catch (Exception e) {
			Log.error("Failed to click on New button " + e.getMessage());
			Assert.fail("Failed to click on New button  " + e.getMessage());
		}
	}

	/**
	 * Function: Verify to create Medical Member Plan
	 * 
	 * @author Kavyashree
	 **/

	public void VerifyToCreateMMP(String memberPlan) {
		try {
			setTimeOut(2000);
			By eleMedical = By.xpath(
					"//*[contains(@class,'active lafPageHost')]//*[text()='Medical']//ancestor::label//span[@class='slds-radio--faux topdown-radio--faux']");
			clickByJavascript(eleMedical);
			setTimeOut(2000);
			click(eleNextMP);
			setTimeOut(2000);

			Actions act = new Actions(getWebDriver());
			By eleSearchPayer = By.xpath("//input[@placeholder='Search Accounts...']");
			scrollToElement(eleSearchPayer);
			click(eleSearchPayer);
			inputText(eleSearchPayer, memberPlan);
			setTimeOut(4000);
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(4000);

			LoggingInfo("Created Medical Payer successfully");

		} catch (Exception e) {
			Log.error("Failed to Create Medical Payer" + e.getMessage());
			Assert.fail("Failed to Create Medical Payer " + e.getMessage());
		}
	}

	/**
	 * Function: Click on New Medication Request
	 * 
	 * @author Kavyashree
	 **/

	public void clickOnNewMedicationRequest() {
		try {
			setTimeOut(2000);
			By NewButton = By.xpath("(//button//span[text()='New'])[1]");
			scrollToElement(NewButton);
			clickByJavascript(NewButton);
			setTimeOut(4000);
			LoggingInfo("clicked on New Medication Request button successfuly");

		} catch (Exception e) {
			Log.error("Failed to click on New Medication Request  button " + e.getMessage());
			Assert.fail("Failed to click on New Medication Request button  " + e.getMessage());
		}
	}

	/**
	 * Function: Verify to create Medication Request
	 * 
	 * @author Kavyashree
	 **/

	public void VerifyToCreateMR() {
		try {
			setTimeOut(2000);

			Actions act = new Actions(getWebDriver());
			By eleStatus = By.xpath("//label[text()='Status']//following-sibling::div//button");
			scrollToElement(eleStatus);
			click(eleStatus);
			setTimeOut(4000);
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(4000);

			By eleQuickStart = By.xpath("//label[text()='QuickStart Rx (Y/N)']//following-sibling::div//button");
			scrollToElement(eleQuickStart);
			click(eleQuickStart);
			setTimeOut(4000);
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(4000);

			LoggingInfo("Created Medication Request successfully");

		} catch (Exception e) {
			Log.error("Failed to Create Medication Request" + e.getMessage());
			Assert.fail("Failed to Create Medication Request " + e.getMessage());
		}
	}

	/**
	 * Function: Verify to click on Pharmacy Record
	 * 
	 * @author Kavyashree
	 **/

	public void clickOnPharmacyRecord() {
		try {
			setTimeOut(20000);
			By elePharmacyRecord = By
					.xpath("((//span[text()='Name'])[1]//ancestor::thead//following-sibling::tbody//a)[1]");
			clickByJavascript(elePharmacyRecord);
			setTimeOut(4000);
			LoggingInfo("clicked on Pharmacy Record successfuly");

		} catch (Exception e) {
			Log.error("Failed to click Pharmacy Record " + e.getMessage());
			Assert.fail("Failed to click  Pharmacy Record   " + e.getMessage());
		}
	}

	/**
	 * Function: Verify to click on Medical Record
	 * 
	 * @author Kavyashree
	 **/

	public void clickOnMedicalRecord() {
		try {
			setTimeOut(2000);
			By eleMedicalRecord = By
					.xpath("((//span[text()='Name'])[1]//ancestor::thead//following-sibling::tbody//a)[3]");
			click(eleMedicalRecord);
			setTimeOut(4000);
			LoggingInfo("clicked on Medical Record successfuly");

		} catch (Exception e) {
			Log.error("Failed to click  Medical Record " + e.getMessage());
			Assert.fail("Failed to click  Medical Record   " + e.getMessage());
		}
	}

	/**
	 * Function: Verify to click on Medication Request
	 * 
	 * @author Kavyashree
	 **/

	public void clickOnMedicationRequest() {
		try {
			setTimeOut(2000);
			By eleMedicationRequest = By
					.xpath("((//span[text()='Name'])[2]//ancestor::thead//following-sibling::tbody//a)[1]");
			click(eleMedicationRequest);
			setTimeOut(4000);
			LoggingInfo("clicked on Medication Request successfuly");

		} catch (Exception e) {
			Log.error("Failed to  click Medication Request Record " + e.getMessage());
			Assert.fail("Failed to click  Medication Request Record   " + e.getMessage());
		}
	}

	/**
	 * Function: Click on CPEP Record
	 * 
	 * @author Kavyashree
	 **/
	public void clickOnCPEPRecord() {
		try {
			setTimeOut(3000);
			clickByJavascript(eleCPEPRecord);
			setTimeOut(2000);
			LoggingInfo("clicked on CPEP Record successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on CPEP Record " + e.getMessage());
			Assert.fail("Failed to click on CPEP Record " + e.getMessage());
		}
	}

	/**
	 * Function: Verify CPE Read only fields f
	 * 
	 * @author Kavyashree
	 **/
	public void verifyCPEPReadOnlyFields() {
		try {
			setTimeOut(3000);
			By eleProduct = getDynamicElement(strCPEReadOnlyFields, "Product");
			waitAndVerifyElement(eleProduct);
			scrollToElement(eleProduct);
			Assert.assertTrue(getAttributeValue(eleProduct, "class").contains("is-read-only"),
					"Field is  marked as read-only.");
			setTimeOut(2000);

			By eleStatus = getDynamicElement(strCPEReadOnlyFields, "Status");
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);

			Assert.assertTrue(getAttributeValue(eleStatus, "class").contains("is-read-only"),
					"Field is  marked as read-only.");
			setTimeOut(2000);

			By eleCPP = getDynamicElement(strCPEReadOnlyFields, "Care Program Product");
			waitAndVerifyElement(eleCPP);
			scrollToElement(eleCPP);

			Assert.assertTrue(getAttributeValue(eleCPP, "class").contains("is-read-only"),
					"Field is  marked as read-only.");
			setTimeOut(2000);

			By eleCreatedBy = getDynamicElement(strCPEReadOnlyFields, "Created By");
			waitAndVerifyElement(eleCreatedBy);
			scrollToElement(eleCreatedBy);

			Assert.assertTrue(getAttributeValue(eleCreatedBy, "class").contains("is-read-only"),
					"Field is  marked as read-only.");
			setTimeOut(2000);

			By eleLastModifiedBy = getDynamicElement(strCPEReadOnlyFields, "Last Modified By");
			waitAndVerifyElement(eleLastModifiedBy);
			scrollToElement(eleLastModifiedBy);

			Assert.assertTrue(getAttributeValue(eleLastModifiedBy, "class").contains("is-read-only"),
					"Field is  marked as read-only.");
			setTimeOut(2000);

			By eleBrand = getDynamicElement(strCPEReadOnlyFields, "Brand");
			waitAndVerifyElement(eleBrand);
			scrollToElement(eleBrand);
			Assert.assertTrue(getAttributeValue(eleBrand, "class").contains("is-read-only"),
					"Field is  marked as read-only.");
			setTimeOut(2000);

			LoggingInfo("verified Read only fields successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Read only fields  " + e.getMessage());
			Assert.fail("Failed to verify Read only fields  " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Name and CPE Fields are editiable f
	 * 
	 * @author Kavyashree
	 **/
	public void verifyNameAndCPEField() {
		try {
			By eleName = getDynamicElement(strCPEEditFields, "Edit Name");
			waitAndVerifyElement(eleName);
			scrollToElement(eleName);

			Assert.assertTrue(getAttributeValue(eleName, "class").contains("edit-trigger"),
					"Field is  marked as Edit.");
			setTimeOut(2000);

			By eleCPE = getDynamicElement(strCPEEditFields, "Edit Care Program Enrollee");
			waitAndVerifyElement(eleCPE);
			scrollToElement(eleCPE);

			Assert.assertTrue(getAttributeValue(eleCPE, "class").contains("edit-trigger"), "Field is  marked as Edit.");
			setTimeOut(2000);

			LoggingInfo("Verified Name and CPE are editable fields successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Name and CPE are editable fields " + e.getMessage());
			Assert.fail("Failed to verify Name and CPE are editable fields " + e.getMessage());
		}
	}

	/**
	 * Function: Verify to change CPE f
	 * 
	 * @author Kavyashree
	 **/
	public void verifyToChangeCPEField() {
		try {

			By eleCPE = getDynamicElement(strCPEEditFields, "Edit Care Program Enrollee");
			waitAndVerifyElement(eleCPE);
			scrollToElement(eleCPE);
			// String classAttr = getAttributeValue(eleProduct, "class");
			clickByJavascript(eleCPE);
			setTimeOut(2000);
			clickByJavascript(eleClearButton);
			setTimeOut(2000);
			Actions act = new Actions(getWebDriver());
			setTimeOut(4000);
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(4000);
			click(eleSave);

			LoggingInfo("Verified to change CPE");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to change CPE " + e.getMessage());
			Assert.fail("Failed to change CPE " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Error Message f
	 * 
	 * @author Kavyashree
	 **/
	public void verifyErrorMessage() {
		try {

			setTimeOut(2000);
			waitAndVerifyElement(eleErrorMessage);

			LoggingInfo("Verified Error Message successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify error message" + e.getMessage());
			Assert.fail("Failed to verify error message " + e.getMessage());
		}
	}

	/**
	 * Function: Create Medication Request for open MI case(Prescription Missing)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void createMedicationRequest(String status, String quickStartVal, String medicationName) {
		try {
			By searchPatient = By
					.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@placeholder=\"Search Accounts...\"]");
			waitAndVerifyElement(searchPatient);
			scrollToElement(searchPatient);
			// inputText(searchPatient, );
			click(searchPatient);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

			By searchIndication = By
					.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@placeholder=\"Search Care Programs...\"]");
			waitAndVerifyElement(searchIndication);
			scrollToElement(searchIndication);
			// inputText(searchPatient, );
			click(searchIndication);
			// Actions act1 = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

			By authorizationStatus = getDynamicElement(strAuthorizationFormStatusValue, "Status");
			scrollToElement(authorizationStatus);
			setTimeOut(1000);
			selectItemFromDropdown(strAuthorizationFormStatusValue, strStatusListValue, "Status", status);
			setTimeOut(2000);

			By quickStart = getDynamicElement(strAuthorizationFormStatusValue, "QuickStart Rx (Y/N)");
			scrollToElement(quickStart);
			setTimeOut(1000);
			selectItemFromDropdown(strAuthorizationFormStatusValue, strStatusListValue, "QuickStart Rx (Y/N)",
					quickStartVal);
			setTimeOut(2000);

			By careProgram = getDynamicElement(serachDropDownListBox, "Medication");
			scrollToElement(careProgram);
			setTimeOut(1000);
			click(careProgram);
			inputText(careProgram, medicationName);
			setTimeOut(500);
			selectItemFromDropdown(serachDropDownListBox, strSearchDropDownOptions1, "Medication", medicationName);
			LoggingInfo("Medication Related record is created successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Create Medication Request" + e.getMessage());
			Assert.fail("Failed to Create Medication Request " + e.getMessage());
		}
	}

	/**
	 * Function: Create Pharmacy Member Plan for open MI case(Insurance Missing)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void createPharmacyMemberPlan(String payerPharmacy, String payerName, String patientDOB) throws Exception {
		try {
			setTimeOut(2000);
			click(eleNextMP);
			setTimeOut(2000);
			By careProgram = getDynamicElement(serachDropDownListBox, "Payer");
			scrollToElement(careProgram);
			setTimeOut(1000);
			click(careProgram);
			inputText(careProgram, payerPharmacy);
			setTimeOut(500);
			selectItemFromDropdown(serachDropDownListBox, strSearchDropDownOptions1, "Payer", payerPharmacy);

			By eleName = By.xpath("//input[@name=\"Name\"]");
			scrollToElement(eleName);
			click(eleName);
			inputText(eleName, "Test Payer");

			waitAndVerifyElement(elePolicyHolderDOB);
			verifyAndEnterInfoInputField(elePolicyHolderDOB, patientDOB, patientDOB);

			waitAndVerifyElement(eleInsuranceDate);
			verifyAndEnterInfoInputField(eleInsuranceDate, patientDOB, patientDOB);

			By elePlanID = By.xpath("//input[@name='PlanID_ICC__c']");
			scrollToElement(elePlanID);
			click(elePlanID);
			inputText(elePlanID, "234567");

			LoggingInfo("Created Insurance related record(Pharmacy) successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Create Pharmacy Member plan record " + e.getMessage());
			Assert.fail("Failed to Create Pharmacy Member plan record " + e.getMessage());
		}

	}

	/**
	 * Function: Verify Absence of New Button
	 * 
	 * @author Kavyashree
	 **/
	public void verifyAbsenceOfNewButton() {
		try {
			boolean found;
			setTimeOut(2000);
			By newButton = By.xpath("//*[text()='New']");
			found = isElementPresent(newButton);
			Assert.assertFalse(found, "New button present");
			LoggingInfo("Verified Absence of New button successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Absence of New button successfully" + e.getMessage());
			Assert.fail("Failed to verify Absence of New button successfully " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Absence of Activity widget
	 * 
	 * @author Trupti
	 **/
	public void verifyAbsenceOfActivityWidget() {
		try {
			By activityWidget = By.xpath("//div[contains(@class,'widget')]");
			boolean found = isElementPresent(activityWidget);

			Assert.assertFalse(found, "Activity widget is unexpectedly present on the page.");
			LoggingInfo("Verified absence of Activity widget successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify absence of Activity widget: " + e.getMessage());
			Assert.fail("Verification of Activity widget absence failed: " + e.getMessage());
		}
	}

	public void clickOnCaseNewButton() {
		try {
			waitAndVerifyElement(eleNewCase);
			clickByJavascript(eleNewCase);
			LoggingInfo("New Button Clicked successfuly");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click New Button  " + e.getMessage());
			Assert.fail("Failed to click New Button " + e.getMessage());
		}
	}

	public void clickOnCPERecord(String cpeName) {
		try {
			Log.info("Attempting to click on CPE record: " + cpeName);
			String xpath = "(//*[contains(@class, 'active lafPageHost')]//span[contains(normalize-space(text()), '"
					+ cpeName + "')])[1]";
			By cpeRecordElement = By.xpath(xpath);
			waitAndVerifyElement(cpeRecordElement);
			scrollToElement(cpeRecordElement);
			clickByJavascript(cpeRecordElement);

			LoggingInfo("Successfully clicked on CPE record: " + cpeName);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to CPE record: " + cpeName + " | " + e.getMessage());
			Assert.fail("Failed to navigate to CPE record: " + cpeName + " | " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to Healthcare Practitioner Facilities record
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToHealthcarePractitioner() {
		try {
			scrollToHalfPage();
			By hcoTable = getDynamicElement(strAccountObjectsCreated, "Healthcare Practitioner Facilities");
			scrollToElement(hcoTable);
			clickByJavascript(hcoTable);
			setTimeOut(2000);
			LoggingInfo("Clicked on \"Healthcare Practitioner Facilities\"");
		} catch (Exception e) {
			Log.error("Failed to navigate to HCO record  " + e.getMessage());
			Assert.fail("Failed to navigate to HCO record  " + e.getMessage());
		}
	}

	/**
	 * Function: Add new HCP account to HCO record
	 * 
	 * @author Trupti Zure
	 **/
	public void addHCPtoFacilityRecord(String hco, String hcp) {
		try {
			// Practitioner Facility Name
			By eleFacName = getDynamicElement(eleInputBox, "Name");
			waitAndVerifyElement(eleFacName);
			inputText(eleFacName, hco);

			// HCP Account
			waitAndVerifyElement(eleWinnerPatient);
			click(eleWinnerPatient);
			setTimeOut(2000);
			waitAndVerifyElement(eleNewAccount);
			scrollToElement(eleNewAccount);
			click(eleNewAccount);

			// select hcp radioBox
			By hcpRadioBox = getDynamicElement(newAccountRadioBox, "HCP");
			waitAndVerifyElement(hcpRadioBox);
			scrollToElement(hcpRadioBox);
			clickByJavascript(hcpRadioBox);

			// click on next
			By nextButton = getDynamicElement(eleButton, "Next");
			waitAndVerifyElement(nextButton);
			click(nextButton);

			By eleHCPName = getDynamicElement(eleInputBox, "firstName");
			waitAndVerifyElement(eleHCPName);
			String hcpFName = "Automation";
			inputText(eleHCPName, hcpFName);

			By eleHCPLName = getDynamicElement(eleInputBox, "lastName");
			waitAndVerifyElement(eleHCPLName);
			scrollToElement(eleHCPLName);
			inputText(eleHCPLName, hcp);

			By eleCred = getDynamicElement(eleInputBox, "Credentials_ICC__c");
			waitAndVerifyElement(eleCred);
			scrollToElement(eleCred);
			inputText(eleCred, hcpFName);

			By saveButton = By
					.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Save\"]//parent::button)[2]");
			waitAndVerifyElement(saveButton);
			scrollToElement(saveButton);
			clickByJavascript(saveButton);
			setTimeOut(5000);
			clickActiveCheckBox();

			By saveBtn = getDynamicElement(eleButton, "Save");
			clickByJavascript(saveBtn);
			setTimeOut(2000);
			refresh();

		} catch (Exception e) {
			Log.error("Failed to create new HCP record " + e.getMessage());
			Assert.fail("Failed to create new HCP record  " + e.getMessage());
		}
	}

	/**
	 * Function: click on new button
	 * 
	 * @author Trupti Zure
	 **/

	public void clickNewButton() {
		try {
			Log.info("Verify user is able to click on new button");
			By eleNewButton = getDynamicElement(button2, "New");
			waitAndVerifyElement(eleNewButton);
			scrollToElement(eleNewButton);
			click(eleNewButton);
			setTimeOut(2000);
			Log.info("User clicks on new button");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify and click on new button " + e.getMessage());
			Assert.fail("Failed to verify and click on new button " + e.getMessage());
		}
	}

	/**
	 * Function: Click on cancel button
	 *
	 * @author Trupti
	 */

	public void clickCancelButtonOnEditAccount() {
		try {
			LoggingInfo("Verify user is able to click on cancel button");
			By eleCancelButton = By
					.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Cancel\"]//parent::button)[3]");
			waitAndVerifyElement(eleCancelButton);
			click(eleCancelButton);
			setTimeOut(2000);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on cancel button on edit account " + e.getMessage());
			Assert.fail("Failed to click on cancel button on edit account " + e.getMessage());
		}
	}

	/**
	 * Function: Click on cancel button
	 *
	 * @author Trupti
	 */
	public void navigateToListView(String listviewName) {
		try {
			refresh();
			waitForPageLoaded();
			Log.info("Navigate to " + listviewName);
			waitForPresenceOfElementLocated(listViewButton);
			clickByJavascript(listViewButton);
			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, listviewName);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);
			LoggingInfo("Navigated to " + listviewName);

		} catch (Exception e) {
			Log.error("Failed to navigate to " + listviewName + e.getMessage());
			Assert.fail("Failed to navigate to " + listviewName + e.getMessage());
		}
	}

	/**
	 * Function: verify Account History Tracing data
	 *
	 * @author Trupti
	 */

	public void verifyAccountHistoryTrackingdata() {
		try {

			setTimeOut(2000);
			scrollToHalfPage();
			waitAndVerifyElement(eleAccHistory);
			scrollToElement(eleAccHistory);
			setTimeOut(2000);
			LoggingInfo("verified Account History Tracking data");

		} catch (Exception e) {
			Log.error("Failed to verify Account History Tracking data " + e.getMessage());
			Assert.fail("Failed to verify Account History Tracking data  " + e.getMessage());
		}
	}

	/**
	 * Function: Click on Related record
	 *
	 * @author Trupti
	 */

	public void clickOnRelatedRecord(String recordname) {
		try {
			By eleRecord = getDynamicElement(strrecordName, recordname);
			waitAndVerifyElement(eleRecord);
			scrollToElement(eleRecord);
			clickByJavascript(eleRecord);
			LoggingInfo("Clicked on record");
			setTimeOut(1000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Record " + e.getMessage());
			Assert.fail("Failed to click on Record" + e.getMessage());
		}
	}

	/**
	 * Function: Click on Related record
	 *
	 * @author Trupti
	 */

	public void verifyHistoryTrackingData(String title) {
		try {
			By eleHistory = getDynamicElement(actHistory, title);
			waitForPresenceOfElementLocated(eleHistory);
			LoggingInfo(title + "tracking data is visible on the Related List ");
			setTimeOut(1000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify  " + e.getMessage());
			Assert.fail("Failed to click on Record" + e.getMessage());
		}
	}

	/**
	 * Function: Validate Authorization Consent Form is created in Authorization
	 * Table
	 *
	 * @author Shanavaz Nishani
	 */
	public void validateConsentRecords(String AuthConsentFormName) throws InterruptedException {
		boolean isConsentRecordsPresent = false;
		List<WebElement> consentRecords = getWebDriver().findElements(By.xpath(
				"//*[contains(@class,\"active lafPageHost\")]//runtime_omnistudio_common-data-table-cell[@data-field-name=\"Name\"]//span"));
		System.out.println("Consent Records Count: " + consentRecords.size());
		for (WebElement record : consentRecords) {
			String consentFormName = record.getText().trim();
			if (consentFormName.contains(AuthConsentFormName)) {
				scrollToWebElement(record);
				JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);", record,
						highlightStyle);
				isConsentRecordsPresent = true;
				LoggingInfo("Consent Form for " + AuthConsentFormName + " is present in the Authorization Table");
				break;
			}
		}
		if (!isConsentRecordsPresent) {
			Log.error("Consent Form for " + AuthConsentFormName + " is not present in the Authorization Table");
			Assert.fail("Consent Form for " + AuthConsentFormName + " is not present in the Authorization Table");
		}
	}

	/**
	 * Function: Validate Consent Capture date and format
	 *
	 * @author Shanavaz Nishani
	 */
	public void validateConsentSignedDate(String consentSignedDate) throws Exception {

		By ele = getDynamicElement(strAccountObjectDetails, "Consent Capture Date");
		String consentCaptureDate = getText(ele).trim();
		if (consentCaptureDate.matches("\\d{1,2}/\\d{1,2}/\\d{4}")) {
			String consentExpiryDateUI = Utility_Function.changeFormatDate2(consentCaptureDate);
			LocalDate consignedDateForParsing = LocalDate.parse(Utility_Function.changeDateFormat(consentSignedDate));
			String formattedCalculatedConsentExpiryDate = formatDatemmdyyyy(consignedDateForParsing.toString());

			if (consentExpiryDateUI.equals(formattedCalculatedConsentExpiryDate)) {
				LoggingInfo("Consent Capture Date is matching with the signed date: " + consentCaptureDate);
			} else {
				LoggingInfo("Consent Capture Date does not match with the signed date. Expected: " + consentSignedDate
						+ ", Actual: " + consentCaptureDate);
				Assert.fail("Consent Capture Date does not match with the signed date.");
			}
		} else {
			LoggingInfo("Consent Capture Date is not in Required format M/d/yyyy: " + consentCaptureDate);
		}

	}

	/**
	 * Function: Verify Status field for ConsentForms in detials page
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateConsentStatusField(String strOutcome) {
		try {
			LoggingInfo("Verify Consent Status Field ");
			setTimeOut(2000);
			By outcome = getDynamicElement(strAccountObjectDetails, "Status");
			scrollToElement(outcome);
			waitAndVerifyElement(outcome);
			verifyDetails(outcome, strOutcome, "Status");
			LoggingInfo(" Consent Status " + outcome + " Verified Successfully ");

		} catch (Exception e) {
			Log.error("Failed to verify Consent Status " + e.getMessage());
			Assert.fail("Failed to verify Consent Status " + e.getMessage());
		}
	}

	/**
	 * Function: Validate Status of Consent Form
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateStatus(String status) throws Exception {
		By eleStatus = getDynamicElement(strAccountObjectDetails, "Status");
		waitAndVerifyElement(eleStatus);
		scrollToElement(eleStatus);
		String ConsentStatus = getText(eleStatus).trim();
		if (ConsentStatus.equalsIgnoreCase(status)) {
			LoggingInfo("Status is Active");
		} else {
			Log.error("Expected status: " + status + ", but found: " + ConsentStatus);
			Assert.fail("Expected status: " + status + ", but found: " + ConsentStatus);
		}
	}

	/**
	 * Function: Verify if the Consent Expiration date is in future.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyFutureDate() throws Exception {
		By expiryfield = getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time");
		waitAndVerifyElement(expiryfield);
		scrollToElement(expiryfield);
		String date = getText(expiryfield).split(",")[0];

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/d/yyyy");
		LocalDate fieldDate = LocalDate.parse(date, formatter);
		LocalDate today = LocalDate.now();

		if (fieldDate.isAfter(today)) {
			LoggingInfo(date + " is in the future.");
		} else {
			Assert.fail("The date is not in the future. Found: " + date);
			Log.error(date + " is not in the future.");
		}
	}

	/**
	 * Function: Validate Authorization Consent Form is not created/Present in
	 * Authorization
	 * Table
	 *
	 * @author Shanavaz Nishani
	 */
	public void validateConsentRecordIsNotPresent(String AuthConsentFormName) throws InterruptedException {
		List<WebElement> consentRecords = getWebDriver().findElements(By.xpath(
				"//*[contains(@class,\"active lafPageHost\")]//runtime_omnistudio_common-data-table-cell[@data-field-name=\"Name\"]//span"));

		for (WebElement record : consentRecords) {
			String consentFormName = record.getText().trim();
			if (consentFormName.contains(AuthConsentFormName)) {
				scrollToWebElement(record);
				JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
				js.executeScript("arguments[0].setAttribute('style', arguments[1]);", record, highlightStyle);
				Log.error("Consent Form for " + AuthConsentFormName
						+ " is unexpectedly present in the Authorization Table");
				Assert.fail("Consent Form for " + AuthConsentFormName
						+ " is unexpectedly present in the Authorization Table");
				return; // No need to continue loop once found
			}
		}
		LoggingInfo("Consent Form for " + AuthConsentFormName + " is correctly not present in the Authorization Table");
	}

	/**
	 * Function: Verify record presence and validate fields in Master Correspondence
	 * 
	 * @author Shanavaz Nishani
	 * @param correspondenceName - Name of the correspondence
	 * @param statusActive       - Active status of the record
	 * @param DUPcode            - JRC/PRB Code
	 * @param JRCJPBDate         - JRC/PRB Date
	 **/
	public void recordValidation(String correspondenceName, String statusActive, String DUPcode, String JRCJPBDate)
			throws Exception {
		String[] expectedValues = { correspondenceName, DUPcode, JRCJPBDate };
		String[] fieldsToValidate = { "Correspondence Name", "JRC/PRB Code", "JRC/PRB Date" };

		List<WebElement> records = getWebDriver()
				.findElements(By.xpath("//*[contains(@class,\"active lafPageHost\")]//table//tbody//tr"));
		System.out.println(records.size());
		boolean recordFound = false;
		if (records.size() == 0) {
			Log.error("No records found in the table.");
			Assert.fail("No records found in the table.");
		} else {
			for (WebElement row : records) {
				String name = row.findElement(By.xpath(".//td[@data-label=\"JRC/PRB Code\"]//div//span")).getText()
						.trim();
				String active = row.findElement(By.xpath(".//td[@data-label=\"Active\"]//div//span")).getText().trim();

				if (name.equalsIgnoreCase(DUPcode) && active.equalsIgnoreCase(statusActive)) {

					LoggingInfo(
							"Record with Name: " + DUPcode + " and Active status: " + statusActive + " is present.");
					row.findElement(By.xpath(".//th//a")).click();
					recordFound = true;
					break;
				}

			}
			if (!recordFound) {
				Log.error("Record with Name: " + DUPcode + " and Active status: " + statusActive
						+ " is not present.");
				Assert.fail(
						"Record with Name: " + DUPcode + " and Active status: " + statusActive
								+ " is not present.");
			}

			for (int i = 0; i < fieldsToValidate.length; i++) {

				String fieldName = fieldsToValidate[i];
				String expectedVal = expectedValues[i];
				By eleDupcode = getDynamicElement(ele, fieldName);
				scrollToElement(eleDupcode);

				if (getText(eleDupcode).trim().contains(expectedVal)) {
					highLightElement(eleDupcode);
					Log.info("Verified " + fieldName + " with value: " + expectedVal);
				} else {
					Log.error("Expected " + fieldName + ": " + expectedVal + ", but found: "
							+ getText(eleDupcode).trim());
					Assert.fail("Expected " + fieldName + ": " + expectedVal + ", but found: "
							+ getText(eleDupcode).trim());
				}

			}
			LoggingInfo(fieldsToValidate[0] + ", " + fieldsToValidate[2] + ", DUP Code - is updated as Expected");

		}
	}

	/**
	 * Function: Open Master Correspondence Record
	 * 
	 * @author Shanavaz Nishani
	 * @param masterCorspName - Name of the Master Correspondence Record to open
	 **/
	public void openMasterCorsp(String masterCorspName) {

		By eleMasterRec = getDynamicElement(strMasterRec, masterCorspName);
		try {
			waitAndVerifyElement(eleMasterRec);
			scrollToElement(eleMasterRec);
			clickByJavascript(eleMasterRec);
			setTimeOut(2000);
			LoggingInfo("Clicked on Master Correspondence Record: " + masterCorspName);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Master Correspondence Record: " + masterCorspName + " | " + e.getMessage());
			Assert.fail("Failed to click on Master Correspondence Record: " + masterCorspName + " | " + e.getMessage());
		}
	}

	/**
	 * Function: Validate Active status of the record
	 * 
	 * @author Shanavaz Nishani
	 * @param statusActive - Expected active status of the record
	 **/
	public void validateActiveStatus(String statusActive) throws Exception {
		By eleDupcode = getDynamicElement(ele, "Active");
		scrollToElement(eleDupcode);
		highLightElement(eleDupcode);
		String ActualactiveStatus = getText(eleDupcode).trim();
		if (ActualactiveStatus.equalsIgnoreCase(statusActive)) {
			LoggingInfo("Active status is as expected: " + statusActive);
		} else {
			Log.error("Expected Active status: " + statusActive + ", but found: " + ActualactiveStatus);
			Assert.fail("Expected Active status: " + statusActive + ",but found: " + ActualactiveStatus);
		}
	}

	/**
	 * Function: This function validates the details of a field in the Details page.
	 * 
	 * @author Shanavaz Nishani
	 * @param fieldName     - Name of the field to validate
	 * @param expectedValue - Expected value of the field
	 **/
	public void validateDetails(String fieldName, String expectedValue) {
		String strFieldName = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//parent::div//following-sibling::div//a";
		By eleField = getDynamicElement(strFieldName, fieldName);
		try {
			waitAndVerifyElement(eleField);
			scrollToElement(eleField);
			String actualValue = getText(eleField).trim();
			if (actualValue.equalsIgnoreCase(expectedValue)) {
				LoggingInfo(fieldName + " is verified successfully with value: " + expectedValue);
			} else {
				Log.error("Expected " + fieldName + ": " + expectedValue + ", but found: " + actualValue);
				Assert.fail("Expected " + fieldName + ": " + expectedValue + ", but found: " + actualValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + fieldName + ": " + e.getMessage());
			Assert.fail("Failed to verify " + fieldName + ": " + e.getMessage());
		}
	}

	/**
	 * Function: Validate Active checkbox in the Details page
	 * 
	 * @author Shanavaz Nishani
	 * @param shouldBeChecked - Expected state of the checkbox (Active for checked,
	 *                        Inactive for unchecked)
	 **/
	public void validateActiveCheckbox(boolean shouldBeChecked) {
		By eleActiveCheckbox = By.xpath(
				"//*[contains(@class,\"active lafPageHost\")]//span[@class='test-id__field-label' and contains(text(),'Active')]//parent::div//following-sibling::div//input[@type='checkbox']");
		try {
			waitAndVerifyElement(eleActiveCheckbox);
			scrollToElement(eleActiveCheckbox);
			boolean isChecked = isCheckboxSelected(eleActiveCheckbox);
			if (isChecked == shouldBeChecked) {
				if (shouldBeChecked) {
					System.out.println("The checkbox correctly checked (active).");
				} else {
					System.out.println("The checkbox is correctly unchecked (inactive).");
				}
			} else {
				if (shouldBeChecked) {
					System.out.println("ERROR: The checkbox for is NOT checked, but it should be active (checked).");
				} else {
					System.out.println(
							"ERROR: The checkbox for is NOT unchecked, but it should be inactive (unchecked).");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Active checkbox: " + e.getMessage());
			Assert.fail("Failed to verify Active checkbox: " + e.getMessage());
		}

	}

	/**
	 * Function: Open Healthcare Practitioner or Healthcare Organization from
	 * Details Page
	 * 
	 * @author Shanavaz Nishani
	 * @param prescriberOrSite - Name of the Fileds to open (Precsriber or Site)
	 **/
	public void openHCPorHCOFromDetailsPage(String prescriberOrSite) throws Exception {
		try {
			String strHCPorHCO = "//Span[text()=\"{0}\"]//parent::div//following-sibling::div//a";
			By eleHCPorHCO = getDynamicElement(strHCPorHCO, prescriberOrSite);
			scrollToElement(eleHCPorHCO);
			highLightElement(eleHCPorHCO);
			clickByJavascript(eleHCPorHCO);
			LoggingInfo("Clicked on " + prescriberOrSite + " successfully");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on " + prescriberOrSite + ": " + e.getMessage());
			Assert.fail("Failed to click on " + prescriberOrSite + ": " + e.getMessage());
		}

	}

	/**
	 * Function: This function validates the Healthcare Practitioner Facility record
	 * created.
	 * 
	 * @author Shanavaz Nishani
	 * @param HCOsiteName - Name of the Healthcare Practitioner Facility to validate
	 **/
	public void validateHealthCarePractFacilityName(String HCOsiteName) {

		try {
			By eleHCPFacilityName = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Healthcare Practitioner Facilities\"]//tbody//td[contains(@data-label,\"Account\")]//a//span");
			if (!isElementPresent(eleHCPFacilityName)) {
				Log.error("Healthcare Practitioner Facilities record is not present");
				Assert.fail("Healthcare Practitioner Facilities record is not present");
			} else {
				waitAndVerifyElement(eleHCPFacilityName);
				scrollToElement(eleHCPFacilityName);
				String facilityName = getText(eleHCPFacilityName).trim();
				if (facilityName.contains(HCOsiteName)) {
					highLightElement(eleHCPFacilityName);
					LoggingInfo(
							"Healthcare Practitioner Facilities record is created and existing HCO is related to newly created HCP"
									+ facilityName);
				} else {
					Log.error("Existing HCO is not related to newly created HCP");
					Assert.fail("Existing HCO is related to newly created HCP");
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Healthcare Practitioner Facility Name: " + e.getMessage());
			Assert.fail("Failed to verify Healthcare Practitioner Facility Name: " + e.getMessage());
		}

	}

	/**
	 * Function: Click on Dropdown for Related Contact. This function validates if a
	 * conatact record is present, and selects required option from dropdown.
	 * 
	 * @author Shanavaz Nishani
	 * @param relatedRecordName - Name of the related contact record
	 * @param dropdownOption    - Option to select from the dropdown
	 **/
	public void clickViewRelationShipforRelatedContact(String relatedRecordName, String dropdownOption) {

		String strAccName = "//article[@aria-label=\"{0}\"]//child::button/span[text()=\"Show Actions\"]";
		By eleAccName = getDynamicElement(strAccName, relatedRecordName);
		try {
			if (isElementPresent(eleAccName)) {
				LoggingInfo("Related Contact Record is present: " + relatedRecordName);
				waitAndVerifyElement(eleAccName);
				scrollToElement(eleAccName);
				clickByJavascript(eleAccName);
				String strViewRelationShip = "//div[@role=\"menu\"]//ul//li//a[@title=\"{0}\"]";
				By eleViewRelationShip = getDynamicElement(strViewRelationShip, dropdownOption);
				waitAndVerifyElement(eleViewRelationShip);
				// scrollToElement(eleViewRelationShip);
				click(eleViewRelationShip);
				Log.info("Clicked on View Relationship successfully");
				setTimeOut(2000);
			} else {
				Log.error("Related Contact Record is not present: " + relatedRecordName);
				Assert.fail("Related Contact Record is not present: " + relatedRecordName);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on View Relationship: " + e.getMessage());
			Assert.fail("Failed to click on View Relationship: " + e.getMessage());
		}
	}

	/**
	 * Function: This function validates the presence of Member Plans and verifies
	 * their details.
	 * 
	 * @author Shanavaz Nishani
	 * @param payerName  - Name of the payer
	 * @param status     - Status of the member plan
	 * @param planType   - Type of the plan (Primary/Secondary/Tertiary)
	 * @param recordType - Record type (Pharmacy)
	 **/
	public void validateMemberPlansCreated(String payerName, String status, String planType, String recordType) {
		List<WebElement> memberPlans = getWebDriver().findElements(By
				.xpath("//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Member Plans\"]/tbody//tr"));
		List<String> fieldName = Arrays.asList("Status", "Primary/Secondary/Tertiary");
		List<String> expectedValue = Arrays.asList(status, planType);
		if (memberPlans.isEmpty()) {
			Log.error("No Member Plans found in the table.");
			Assert.fail("No Member Plans found in the table.");
		} else {
			for (WebElement plan : memberPlans) {
				String planName = plan.findElement(By.xpath(".//td[@data-label=\"Payer\"]//a//span")).getText()
						.trim();
				if (planName.contains(payerName)) {
					LoggingInfo(
							"Member Plan with name: " + planName + " is present for " + recordType + " record type.");

					By ele = getDynamicElement(".//th//a//span[contains(text(),\"{0}\")]", planName);

					plan.findElement(ele).click();

					for (int i = 0; i < fieldName.size(); i++) {
						String strMemFields = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//ancestor::div[contains(@class,\"slds-form-element\")]//lightning-formatted-text";
						By eleMemberPlan = getDynamicElement(strMemFields, fieldName.get(i));
						try {
							scrollToElement(eleMemberPlan);
							String actualValue = getText(eleMemberPlan).trim();
							if (actualValue.equalsIgnoreCase(expectedValue.get(i))) {
								LoggingInfo(
										fieldName.get(i) + " is verified successfully with value: " + expectedValue);
							} else {
								Log.error("Expected " + fieldName.get(i) + ": " + expectedValue + ", but found: "
										+ actualValue);
								Assert.fail("Expected " + fieldName.get(i) + ": " + expectedValue + ", but found: "
										+ actualValue);
							}
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}

					return; // Exit after finding the first matching plan
				}
			}
			Log.error("Member Plan with name 'Automation' is not present.");
			Assert.fail("Member Plan with name 'Automation' is not present.");
		}
	}

	public void validateHealthCondtCode(String conditionCode) {
		List<WebElement> healthCondcode = getWebDriver()
				.findElements(By.xpath("//*[@data-label='HealthCondition']//span"));

		for (WebElement code : healthCondcode) {
			String codeText = code.getText().trim();
			if (codeText.equalsIgnoreCase(conditionCode)) {
				LoggingInfo("Health Condition Code is present: " + codeText);
				return; // Exit after finding the first matching code
			}
		}
	}

	/**
	 * Function: This function validates the presence of a Medication Request and
	 * its status.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateMedicationRequests(String medicationName, String Medicationstatus) throws Exception {
		String strMedication = "//span[contains(text(),\"{0}\")]//ancestor::div[@data-label=\"MedicationName\"]//preceding-sibling::div[@data-label=\"Name\"]//span";
		By eleMedication = getDynamicElement(strMedication, medicationName);
		if (isElementPresent(eleMedication)) {
			waitAndVerifyElement(eleMedication);
			scrollToElement(eleMedication);
			LoggingInfo("Medication Request with name: " + medicationName + " is present.");
			clickByJavascript(eleMedication);
			By eleStatus = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//span[text()=\"Status\"]//ancestor::div[contains(@class,\"slds-form-element\")]//lightning-formatted-text");
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			String status = getText(eleStatus).trim();
			if (status.equalsIgnoreCase(status)) {
				LoggingInfo("Medication Request with name: " + medicationName + " is present and status is: " + status);
			} else {
				Log.error("Medication Request with name: " + medicationName
						+ " is present but status is not as expected. Expected: " + status);
				Assert.fail("Medication Request with name: " + medicationName
						+ " is present but status is not as expected.");
			}
		} else {
			Log.error("Medication Request with name: " + medicationName + " is not present.");
			Assert.fail("Medication Request with name: " + medicationName + " is not present.");
		}

	}

	/**
	 * Function: Click on CPE Status dropdown and select the option
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void clickCPEStatusDrpdwn(String option) {
		if (isElementDisplayed(eleCPEStatusButton) && option.equals("CPE Status Update")) {
			docMgmt.clickOnCPEStatusButton();
		} else {
			By cpeStatusUpdateDrpdwn = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//button[@class=\"slds-button slds-button_icon-border-filled fix-slds-button_icon-border-filled slds-button_last\"]");
			click(cpeStatusUpdateDrpdwn);

			String stroption = "//lightning-menu-item//a/span[text()=\"{0}\"]";
			By eleOption = getDynamicElement(stroption, option);
			waitAndVerifyElement(eleOption);
			clickByJavascript(eleOption);
		}

	}

	public void validateNoContactPicklistValues() {
		try {
			Log.info("Verifying 'No Contact' picklist field and its values on HCO Account page...");

			String[] expectedPickListValues = { "--None--", "No Call", "No Email", "No Fax", "No Contact" };

			By relationEdit = getDynamicElement(editButton, "Edit No Contact");
			waitAndVerifyElement(relationEdit);
			scrollToElement(relationEdit);
			setTimeOut(2000);
			click(relationEdit);

			By noContactField = getDynamicElement(editFieldList, "No Contact");
			waitAndVerifyElement(noContactField);
			click(noContactField);

			By noContactDropdownOptions = getDynamicElement(editFieldListOptions, "No Contact");
			waitAndVerifyElement(noContactDropdownOptions);

			List<WebElement> picklistOptions = getWebDriver().findElements(By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"No Contact\"]//parent::div//lightning-base-combobox-item"));

			List<String> actualPicklistValues = new ArrayList<>();
			for (WebElement option : picklistOptions) {
				String value = option.getText().trim();
				actualPicklistValues.add(value);
				Log.info("Found picklist value: " + value);
			}

			for (String expectedValue : expectedPickListValues) {
				Assert.assertTrue(actualPicklistValues.contains(expectedValue),
						"Missing expected picklist value: " + expectedValue);
			}

			String defaultValue = actualPicklistValues.get(0);
			Assert.assertTrue(defaultValue.equals("--None--") || defaultValue.isEmpty(),
					"Default value should be blank or '--None--', but found: " + defaultValue);

			LoggingInfo("'No Contact' picklist values validated successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify 'No Contact' picklist values: " + e.getMessage());
			Assert.fail("Failed to verify 'No Contact' picklist values: " + e.getMessage());
		}
	}

	/**
	 * Function: Click on HIPAA Consent Record
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void openHIPAAConsent() throws Exception {
		try {
			waitAndVerifyElement(AuthorizationFormHIPAA);
			scrollToElement(AuthorizationFormHIPAA);
			clickByJavascript(AuthorizationFormHIPAA);
			LoggingInfo("HIPAA Consent Record is opened");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to open HIPAA Consent Record:  " + e.getMessage());
		}

	}

	/**
	 * Function: Enter Consent Exp Date on HIPAA consent rec
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void enterConsentExpDate(int days) throws Exception {
		try {
			String dateLessThan90Days = utilityPage.getNthDayFromTodayFormat(days);
			By eleDOB = getDynamicElement(strInputText, "Date");
			waitAndVerifyElement(eleDOB);
			scrollToElement(eleDOB);
			setTimeOut(2000);
			clearInputFieldText(eleDOB);
			inputText(eleDOB, dateLessThan90Days);
			LoggingInfo("Consent Exp Date Entered : " + days + " days from today");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Enter Consent Exp Date :  " + e.getMessage());
		}

	}

	/**
	 * Function: Validate status of AFC
	 * 
	 * @author Tejal
	 * 
	 **/
	public void verifyProgramStatus(String programName, String expectedStatus) {
		try {
			Log.info("Verifying that CARE Program '" + programName + "' has status: " + expectedStatus);

			boolean isProgramPresent = getWebDriver().findElements(By.xpath("//span[@title='" + programName + "']"))
					.size() > 0;

			if (isProgramPresent) {

				String xpath = "//span[@title='" + programName + "']"
						+ "/ancestor::div[contains(@class,'slds-hint-parent') or contains(@class,'slds-grid')][1]"
						+ "//span[normalize-space(.)='" + expectedStatus + "']";

				List<WebElement> allStatuses = getWebDriver().findElements(By.xpath(xpath));

				if (allStatuses.size() > 0) {
					for (int i = 0; i < allStatuses.size(); i++) {

						By statusLocator = By.xpath("(" + xpath + ")[" + (i + 1) + "]");

						highLightElement(statusLocator);

						String actualStatus = allStatuses.get(i).getText().trim();
						if (actualStatus.equalsIgnoreCase(expectedStatus)) {
							Assert.assertTrue(true, "Status matches for '" + programName + "': " + actualStatus);
							LoggingInfo("Status matches for '" + programName + "': " + actualStatus);
						} else {
							Assert.fail("Status mismatch for '" + programName + "'. Actual: " + actualStatus
									+ ", Expected: " + expectedStatus);
							LoggingInfo("Status mismatch for '" + programName + "'. Actual: " + actualStatus
									+ ", Expected: " + expectedStatus);
						}
					}
				} else {
					Assert.fail("No rows found with expected status '" + expectedStatus + "' for program '"
							+ programName + "'");
					LoggingInfo("No rows found with expected status '" + expectedStatus + "' for program '"
							+ programName + "'");
				}
			} else {
				Assert.fail("CARE Program '" + programName + "' not found in table");
				LoggingInfo("CARE Program '" + programName + "' not found in table");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Verification of program status failed for '" + programName + "': " + e.getMessage());
		}
	}

	public void clickPageOfAFC(String pageNumber) {
		try {
			Log.info("Clicking on pagination button: " + pageNumber);

			By pageButtonLocator = By
					.xpath("//button[@data-index='" + pageNumber + "' and normalize-space()='" + pageNumber + "']");

			getWebDriver().findElement(pageButtonLocator).click();

			LoggingInfo("Clicked on pagination button: " + pageNumber);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on pagination button: " + pageNumber + " - " + e.getMessage());
			Assert.fail("Could not click on pagination button: " + pageNumber);
		}
	}

	/**
	 * Function: Get Integration ID of patient account
	 * 
	 * @author Anand Pawar
	 **/
	public String getIntegrationID() {
		String ID = "";
		try {
			waitForPageLoaded();
			setTimeOut(3000);
			By detailID = getDynamicElement(detailFields, "Integration ID");
			waitAndVerifyElement(detailID);
			scrollToElement(detailID);
			highLightElement(detailID);
			ID = getText(detailID);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get-" + e.getMessage());
			Assert.fail("Failed to get-" + e.getMessage());
		}

		return ID;
	}

	/**
	 * Function: Navigate to CCR record
	 * 
	 * @author Tejal
	 **/
	public void navigateToCCRTable() {
		try {
			scrollToHalfPage();
			setTimeOut(3000);
			By ccrTable = getDynamicElement(strAccountObjectsCreated, "Contact Contact Relationships");
			scrollToElement(ccrTable);

			setTimeOut(2000);
			LoggingInfo("Clicked on Care Program Enrollees");
		} catch (Exception e) {
			Log.error("Failed to navigate to CPE record  " + e.getMessage());
			Assert.fail("Failed to navigate to CPE record  " + e.getMessage());
		}
	}

	/**
	 * Function: Validate health condition
	 * 
	 * @author Tejal
	 * 
	 **/
	public void verifyHealthConditionIsPresent() {
		try {
			Log.info("Scrolling to 'Health Conditions' section");

			By healthConditionsHeader = By
					.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='Health Conditions']");
			waitAndVerifyElement(healthConditionsHeader);
			scrollToElement(healthConditionsHeader);
			setTimeOut(3000);
			highLightElement(healthConditionsHeader);
			Log.info(
					"validate Health condition record is created with the Diagnosis code populated in the enrollment form");
			By conditionElement = By.xpath("//*[@title='L50.9 - Urticaria, unspecified']");

			if (getWebDriver().findElements(conditionElement).isEmpty()) {
				Log.error("Condition 'L50.9 - Urticaria,unspecified' is NOT present on the page.");
				Assert.fail("Condition 'L50.9 - Urticaria,unspecified' is not found.");
			} else {
				Log.info("Condition 'L50.9 - Urticaria, unspecified");
				highLightElement(conditionElement);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Exception occurred while verifying health condition: " + e.getMessage());
			Assert.fail("Failed during verification of health condition: " + e.getMessage());
		}
	}

	/**
	 * Function: Click on pharamcy record
	 * 
	 * @author Trupti Zure
	 * 
	 **/
	public void clickOnPharamcyRecord() {
		try {
			By memberPlanName = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//table//tbody//td[@data-label=\"Record Type\"]//span[contains(text(),\"Pharmacy\")]//ancestor::tr//th[@data-label=\"Name\"]//a");

			scrollToElement(memberPlanName);
			clickByJavascript(memberPlanName);
			LoggingInfo("Clicked on member plan");
			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to click on Member plan details" + e.getMessage());
			Assert.fail("Failed to click on Member plan details" + e.getMessage());
		}
	}

	/**
	 * Function: Verify member plan details
	 * 
	 * @author Trupti Zure
	 * 
	 **/
	public void verifyMemberPlanDetailsFields() {
		try {
			List<String> requiredFields = Arrays.asList("Insurance Add Date", "Policyholder DOB", "Plan ID");

			for (String field : requiredFields) {
				By fieldLocator = getDynamicElement(strAccountObjectDetails, field);

				waitAndVerifyElement(fieldLocator);
				scrollToElement(fieldLocator);

				String fieldValue = getText(fieldLocator).trim();

				if (fieldValue.isEmpty()) {
					Assert.fail("Field '" + field + "' is present but has no value.");
				}

				Log.info("Verified: '" + field + "' is present with value: " + fieldValue);
			}

			Log.info("All required member plan details fields are present and populated.");

		} catch (Exception e) {
			Log.error("Error verifying Member Plan Details fields: " + e.getMessage());
			Assert.fail("Failed to verify Member Plan Details fields: " + e.getMessage());
		}
	}

	/**
	 * Function: Verify and edit member plan details
	 * 
	 * @author Trupti Zure
	 * 
	 **/
	public void verifyAndEditMemberPlanDetailsFields(String insuranceAddDate, String policyHolderDOB, String planID) {
		try {
			Map<String, String> fieldValues = new HashMap<>();
			fieldValues.put("Insurance Add Date", insuranceAddDate);
			fieldValues.put("Policyholder DOB", policyHolderDOB);
			fieldValues.put("Plan ID", planID);

			List<String> fieldsToEdit = new ArrayList<>();

			for (String field : fieldValues.keySet()) {
				By fieldLocator = getDynamicElement(strAccountObjectDetails, field);

				// Try reading via JS to avoid visibility/formatting issues
				WebElement element = getWebDriver().findElement(fieldLocator);
				String fieldValue = (String) ((JavascriptExecutor) getWebDriver())
						.executeScript("return arguments[0].innerText;", element);

				fieldValue = fieldValue.trim();
				Log.info("Field '" + field + "' value read as: '" + fieldValue + "'");

				if (fieldValue.isEmpty()) {
					fieldsToEdit.add(field);
				}
			}

			if (!fieldsToEdit.isEmpty()) {
				Log.info("Some fields are missing values: " + fieldsToEdit);
				By relationEdit = getDynamicElement(editButton, fieldsToEdit.get(0));
				waitAndVerifyElement(relationEdit);
				scrollToElement(relationEdit);
				setTimeOut(2000);
				click(relationEdit);

				for (String field : fieldsToEdit) {
					By inputLocator = getDynamicElement(strTextBoxesInput, field);
					waitAndVerifyElement(inputLocator);
					inputText(inputLocator, fieldValues.get(field));
					Log.info("Updated field '" + field + "' with value: " + fieldValues.get(field));
				}

				By saveButton = By.xpath("//button[contains(text(),'Save')]");
				waitAndVerifyElement(saveButton);
				click(saveButton);
				Log.info("Saved updated Member Plan Details.");

				verifyMemberPlanDetailsFields();
			} else {
				Log.info("All required member plan details fields are present and populated.");
			}

		} catch (Exception e) {
			Log.error("Error verifying or editing Member Plan Details fields: " + e.getMessage());
			Assert.fail("Failed to verify or edit Member Plan Details fields: " + e.getMessage());
		}
	}

	/**
	 * Function: Get full name of CPE
	 * 
	 * @author Trupti Zure
	 * 
	 **/
	public String getCPEName() {
		String cpe = null;
		By cpeNameXpath = By.xpath("//*[contains(@class,\"active lafPageHost\")]//h1//lightning-formatted-text");
		waitAndVerifyElement(cpeNameXpath);
		cpe = getText(cpeNameXpath);
		return cpe;

	}

	/**
	 * Function: Click on MI record
	 * 
	 * @author Sonica
	 **/
	public void clickOnMIRec() {
		try {
			waitForPageLoaded();
			setTimeOut(3000);
			waitAndVerifyElement(eleMIRec);
			click(eleMIRec);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to MI record");
			Assert.fail("Failed to navigate to Mi record");
		}
	}

	/**
	 * Function: Edit MI record
	 * 
	 * @author Sonica
	 **/
	public void editMIRec(String miValue) {
		try {
			waitForPageLoaded();
			setTimeOut(3000);
			waitAndVerifyElement(eleEditMI);
			clickByJavascript(eleMIRec);
			setTimeOut(2000);
			click(eleClearCPMI);
			selectItemFromList(eleCPMISearch, miValue);
			setTimeOut(2000);
			click(eleSaveEditBtn);
			setTimeOut(2000);
			waitAndVerifyElement(eleMIError);
			setTimeOut(1000);
			click(eleCancelEdit);
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to MI record");
			Assert.fail("Failed to navigate to Mi record");
		}
	}

	public void verifyConsentIsCreated(String name, String consentType, String expectedDate, String status,
			String careProgram, String createdBy) {
		try {
			waitAndVerifyElement(authConsentLabel);
			scrollToElement(authConsentLabel);

			ArrayList<String> actualData = getConsentTableData("Name", "ConsentCaptureDate", "Status",
					"CareProgramName", "CreatedByName");
			logData("Actual Consent Table Data:", actualData);

			String expectedRow = name + " : " + consentType + ", " + expectedDate + ", " + status + ", " + careProgram
					+ ", " + createdBy;
			Log.info("Expected Consent Row: " + expectedRow);

			if (!actualData.contains(expectedRow)) {
				throw new AssertionError("Expected consent row not found: " + expectedRow);
			}

			Log.info("Consent verification successful. Expected row found.");
		} catch (Exception e) {
			Log.error("Exception occurred while verifying consent creation: " + e.getMessage());
			Assert.fail("Consent verification failed: " + e.getMessage());
		}
	}

	public boolean isNextButtonEnabledAndClick() {
		try {
			WebElement nextButton = getWebDriver()
					.findElement(By.xpath("//button[contains(@aria-label,'Page 2 of 2')]"));

			if (nextButton.isDisplayed() && nextButton.isEnabled()) {
				nextButton.click();
				setTimeOut(3000);
				return true;
			}
		} catch (NoSuchElementException e) {
		}
		return false;
	}

	/**
	 * Function: Verify consentExpirationDate is populated as future date
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyConsentExpirationDateIsFuture(String consentName, String expectedDate) {
		try {
			Log.info("Verifying expiration date for consent: " + consentName + " with date: " + expectedDate);

			scrollToBottomOfPage();

			String consentRecordXpath = "//span[contains(text(), '" + expectedDate + "')]"
					+ "//ancestor::div[contains(@class,'slds-data-table-row tableRow')]" + "//span[contains(text(),'"
					+ consentName + "')]";

			boolean consentFound = false;

			do {
				By eleConsent = By.xpath(consentRecordXpath);

				if (isElementPresent(eleConsent)) {
					consentFound = true;

					scrollToElement(eleConsent);
					clickByJavascript(eleConsent);

					String consentExpiryDateTime = getText(
							getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time"));

					if (consentExpiryDateTime == null || consentExpiryDateTime.trim().isEmpty()) {
						Assert.fail("Consent Expiration Date Time is empty or not populated.");
					}

					String[] dateAndTime = consentExpiryDateTime.split(",");
					String consentExpiryDate = dateAndTime[0].trim();

					LocalDate expiryDate = LocalDate.parse(consentExpiryDate, DateTimeFormatter.ofPattern("M/d/yyyy"));
					LocalDate today = LocalDate.now();

					if (expiryDate.isAfter(today)) {
						LoggingInfo("PASS: Consent Expiration Date is a future date: " + consentExpiryDate);
					} else {
						Assert.fail("FAIL: Consent Expiration Date is not in the future: " + consentExpiryDate);
					}

					break;
				}

			} while (isNextButtonEnabledAndClick());

			if (!consentFound) {
				Assert.fail("Consent '" + consentName + "' with date '" + expectedDate + "' not found.");
			}

		} catch (Exception e) {
			Log.error("Verification of consent expiration date failed: " + e.getMessage());
			Assert.fail("Exception during consent expiration date verification: " + e.getMessage());
		}
	}

	public String formatDate(String expectedDate)

	{
		String formattedExpectedDate = null;
		formattedExpectedDate = LocalDate.parse(expectedDate, DateTimeFormatter.ofPattern("MM-dd-yyyy"))
				.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

		return formattedExpectedDate;
	}

	/**
	 * Function: Navigate to Sidebar Options on Dashboard or Reports
	 * 
	 * @author Shraddha
	 * 
	 **/
	public void navigateToFolderSideBarOption(String folderoption) {
		try {
			By folderele = getDynamicElement(dashboardTablist, folderoption);
			waitForelementToBeClickable(folderele);
			click(folderele);
			waitForPageLoaded();
			waitAndVerifyElement(folderBreadcrumbTitle);
			if (getText(folderBreadcrumbTitle).equalsIgnoreCase(folderoption)) {
				highLightElement(folderBreadcrumbTitle);
				LoggingInfo(folderoption + " is selected.");
			} else {
				Log.error("Unable to navigate to " + folderoption);
				Assert.fail("Unable to navigate to " + folderoption);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to Dashboard option " + e.getMessage());
			Assert.fail("Failed to navigate to Dashboard option " + e.getMessage());
		}
	}

	/**
	 * Function: Validate Dashboard folders
	 * 
	 * @author Shraddha
	 * 
	 **/
	public void validateDashboardFolders(List<String> namesToVerify) {

		for (String name : namesToVerify) {
			try {
				By nameColumn = By.xpath("//table//tr//lightning-formatted-url/a[contains(text(), '" + name + "')]");
				scrollToElement(nameColumn);
				String nameText = getText(nameColumn);

				if (nameText.equals(name)) {
					LoggingInfo(nameText + " folder is present on dashboard");
				} else {
					Log.error(nameText + " folder is present on dashboard");
					Assert.fail(nameText + " folder is present on dashboard");
				}
			} catch (Exception e) {
				Log.error("Error occurred while verifying folder: " + name + e.getMessage());
				Assert.fail("Error occurred while verifying folder: " + name + e.getMessage());
			}
		}
	}

	/**
	 * Function: Open dashboard folder
	 * 
	 * @author Shraddha
	 * 
	 **/
	public void openDashboardFolder(String name) {

		try {
			By nameEle = By
					.xpath("//table//tr/th[@data-label='Dashboard Name']//lightning-formatted-url/a[contains(text(), '"
							+ name + "')]");
			setTimeOut(1000);
			scrollToElement(nameEle);
			setTimeOut(1000);
			waitForvisiblityOfElementLocated(nameEle);
			setTimeOut(1000);
			waitForelementToBeClickable(nameEle);
			LoggingInfo(name + " folder is visible");

			WebElement element = getWebDriver().findElement(nameEle);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", element);
			waitForPageLoaded();
			setTimeOut(5000);

			By eleiframe = By.xpath("//iframe[@title='dashboard']");
			switchToFrame(eleiframe);

			By headerxpath = By.xpath(
					"//h1/span[contains(text(),'Dashboard')]/following-sibling::span[contains(@class, 'slds-page-header__title')]");
			waitForvisiblityOfElementLocated(headerxpath);
			String headername = getText(headerxpath);
			if (headername.equals(name)) {
				LoggingInfo("User is able to access dashboard " + name);
			} else {
				Log.error("Unable to access " + name);
			}
		} catch (Exception e) {
			Log.error("Error occurred while verifying folder : " + name + e.getMessage());
			Assert.fail("Error occurred while verifying folder: " + name + e.getMessage());
		}
	}

	/**
	 * Function: Validate All components on dashboard folder
	 * 
	 * @author Shraddha
	 * 
	 **/
	public void validateAllComponents() {

		List<String> frameNamesToVerify = Arrays.asList("Total BV Tasks by Owner", "Total PA/Appeal Tasks by Owner",
				"Total Triage Tasks by Owner", "Total Quick Start Tasks by Owner", "Total PAP Tasks by Owner",
				"Total IAP Tasks by Owner", "Total Inbound Calls by Owner", "Total Mobile App Activity by Owner",
				"Total AEs Reported by Owner", "PA Follow up on Results Tasks", "Total Welcome Messages by Case Owner",
				"Total Outbound Calls by Owner", "CPEs without CM or FRM filled out");
		for (String fname : frameNamesToVerify) {
			try {
				By frameheader = By.xpath("//div[contains(@title,'" + fname + "')]");
				waitAndVerifyElement(frameheader);
				scrollToElement(frameheader);
				if (isElementPresent(frameheader)) {
					highLightElement(frameheader);
					LoggingInfo("Data is present and visible for " + fname);
				} else {
					Log.error("Data not present for " + fname);
					Assert.fail("Data not present for " + fname);
				}
			} catch (Exception e) {
				Log.error("Error occurred while verifying component: " + fname + e.getMessage());
				Assert.fail("Error occurred while verifying component: " + fname + e.getMessage());
			}
		}
	}

	/**
	 * Function: Open any CPE record from dashboard
	 * 
	 * @author Shraddha
	 * 
	 **/
	public void openCPERecordfromDashboard() {
		try {
			By cpeFrame = By.xpath("//div[contains(@title,'CPEs without CM or FRM filled out')]");
			scrollToElement(cpeFrame);

			By cpeDataRefresh = By.xpath(
					"//div/button[span[contains(text(), 'Refresh \"CPEs without CM or FRM filled out\"')]]/span");
			waitForelementToBeClickable(cpeDataRefresh);
			WebElement refreshIconEle = getWebDriver().findElement(cpeDataRefresh);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", refreshIconEle);
			setTimeOut(28000);
			waitForPageLoaded();

			By cpeTableEle = By.xpath(
					"//div[contains(@title,'CPEs without CM or FRM filled out')]/../following-sibling::div//table[contains(@class, 'data-grid-full-table')]");
			waitForvisiblityOfElementLocated(cpeTableEle);

			By cpelink = By.xpath("//table//tr/td[@data-row-index='0' and @data-column-index='0']//a");
			waitForelementToBeClickable(cpelink);
			WebElement cpeLinkEle = getWebDriver().findElement(cpelink);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", cpeLinkEle);
			setTimeOut(5000);
			waitForPageLoaded();

			getWebDriver().switchTo().defaultContent();

			By cpeheader = By.xpath("//slot/records-entity-label[text()='Care Program Enrollee']");
			waitAndVerifyElement(cpeheader);

			if (getText(cpeheader).equalsIgnoreCase("Care Program Enrollee")) {
				highLightElement(cpeheader);
				LoggingInfo("User is able to open CPE");
			} else {
				Log.error("Unable to open CPE");
				Assert.fail("Unable to open CPE");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to open CPE " + e.getMessage());
			Assert.fail("Failed to open CPE " + e.getMessage());
		}
	}

	public void navigateToTab(String Name) {
		getWebDriver().switchTo().defaultContent();
		By tabEle = getDynamicElement(tablistEle, Name);
		waitAndVerifyElement(tabEle);
		click(tabEle);
		waitForPageLoaded();
		setTimeOut(2000);
	}

	/**
	 * Function: Open Reports folder
	 * 
	 * @author Shraddha
	 * 
	 **/
	public void openReportsFolder(String name) {

		try {
			By nameEle = By
					.xpath("//table//tr/th[@data-label='Report Name']//lightning-formatted-url/a[contains(text(), '"
							+ name + "')]");
			scrollToElement(nameEle);
			waitForvisiblityOfElementLocated(nameEle);
			waitForelementToBeClickable(nameEle);
			highLightElement(nameEle);
			LoggingInfo(name + " folder is visible");

			WebElement element = getWebDriver().findElement(nameEle);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", element);
			waitForPageLoaded();
			setTimeOut(5000);

			By eleiframe = By.xpath("//iframe[@title='Report Viewer']");
			switchToFrame(eleiframe);

			By headerxpath = By.xpath(
					"//h1/span[contains(text(),'Report')]/following-sibling::span[contains(@class, 'slds-page-header__title') and contains(text(), '"
							+ name + "')]");
			waitForvisiblityOfElementLocated(headerxpath);
			String headername = getText(headerxpath);
			if (headername.equals(name)) {
				highLightElement(headerxpath);
				LoggingInfo("User is able to access report " + name);
			} else {
				Log.error("Unable to access report " + name);
			}
		} catch (Exception e) {
			Log.error("Error occurred while verifying folder : " + name + e.getMessage());
			Assert.fail("Error occurred while verifying folder: " + name + e.getMessage());
		}
	}

	/**
	 * Function : Close Tab using tab Name
	 * 
	 * @author Shraddha
	 */
	public void closeTab(String Name) {
		getWebDriver().switchTo().defaultContent();
		By closeEle = By.xpath("//button[contains(@title, 'Close " + Name + "')]");
		waitAndVerifyElement(closeEle);
		click(closeEle);
		waitForPageLoaded();
	}

	/**
	 * Function:Validate field values with links
	 * 
	 * @author Shraddha Shetty
	 **/

	public void validateLinkFields(String fieldLabel, String expectedvalue) {

		try {
			By inputBox = getDynamicElement(strlinkfieldInputBox, fieldLabel);
			waitAndVerifyElement(inputBox);

			String inputvalue = getText(inputBox);
			// getAttributeValue(inputBox, "value");
			Assert.assertEquals(inputvalue, expectedvalue, "Failed to verify value of : " + fieldLabel);
			LoggingInfo(fieldLabel + " - value is as expected");

		} catch (Exception e) {
			Log.error("Failed to validate Fields " + e.getMessage());
			Assert.fail("Failed to validate Fields " + e.getMessage());
		}
	}

	/**
	 * @Author - Shraddha Shetty
	 **/
	public void openHealthConditionsFromCPE() {
		try {
			By hc = By.xpath("//*[contains(@class, 'active lafPageHost')]//*[@data-label=\"HealthCondition\"]//span");
			highLightElement(hc);
			click(hc);
			waitForPageLoaded();

			LoggingInfo("Health Condition record is opened");

		} catch (Exception e) {
			Log.error("Failed to validate Health Conditions details" + e.getMessage());
			Assert.fail("Failed to validate Health Conditions details" + e.getMessage());
		}
	}

	/**
	 * Function: Verify Case Owner for Case record
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyCaseOwnerForCase(String OwnerName) {
		try {
			waitForPageLoaded();
			By eleCaseOwner = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//span[@class=\"owner-name slds-grow\"]//slot//span");
			waitAndVerifyElement(eleCaseOwner);
			scrollToElement(eleCaseOwner);
			highLightElement(eleCaseOwner);
			verifyDetails(eleCaseOwner, OwnerName, "Case Owner");
			LoggingInfo("Verified care program enrollee status");
		} catch (Exception e) {
			Log.error("Failed to verify Account record status  " + e.getMessage());
			Assert.fail("Failed to verify Account record status  " + e.getMessage());
		}

	}

	/**
	 * Function: Click on link from field(e.g. Care Program, Care Program Enrollee
	 * etc)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void clickOnLinkFromField(String fieldName) {

		String ss = "//*[contains(@class,\"active lafPageHost\")]//span[@class=\"test-id__field-label\" and text()=\"{0}\"]//parent::div//following-sibling::div//a";
		By eleLink = getDynamicElement(ss, fieldName);
		try {
			waitAndVerifyElement(eleLink);
			scrollToElement(eleLink);
			highLightElement(eleLink);
			clickByJavascript(eleLink);
			LoggingInfo("Clicked on link from field: " + fieldName);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on link from field: " + fieldName + " | " + e.getMessage());
			Assert.fail("Failed to click on link from field: " + fieldName + " | " + e.getMessage());

		}
	}

	/**
	 * Function: Verify if field is Hyperlink and text matches
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyIfFieldisHyperlink(String fieldName, String fieldText) throws Exception {

		String xpath = String.format(
				"//*[contains(@class,\"active lafPageHost\")]//span[@class=\"test-id__field-label\" and text()='%s']//parent::div//following-sibling::div",
				fieldName);
		WebElement caseField = getWebDriver().findElement(By.xpath(xpath));

		try {
			WebElement linkElement = caseField.findElement(By.xpath(".//a"));

			// Step 3: Get href and visible text
			String href = linkElement.getAttribute("href");
			String actualText = linkElement.findElement(By.xpath(".//slot//span//span")).getText().trim();

			if (href != null && !href.isEmpty()) {
				Log.info(fieldName + " field is a Hyperlink");

				if (actualText.equals(fieldText)) {
					Log.info(fieldText + " value is as expected.");
					LoggingInfo(fieldName + " field is a Hyperlink and Text matches. Value: " + fieldText);
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].style.border='2px solid red'",
							linkElement);
				} else {
					Log.info("Text does NOT match. Expected: " + fieldText);
				}

			} else {
				Log.error("Anchor tag found but no href attribute.");
				LoggingInfo(fieldName + " field is NOT a Hyperlink");
			}

		} catch (Exception e) {
			Log.error("No hyperlink found inside the Case field.");
			Assert.fail();
		}
	}

	/**
	 * Function: Validate Active checkbox in the Details page
	 * 
	 * @author Shanavaz Nishani
	 * @param shouldBeChecked - Expected state of the checkbox (true for checked,
	 *                        false for unchecked)
	 **/
	public void validateCheckboxStatus(String checkBoxName, boolean shouldBeChecked) {
		String strCheckBox = "//*[contains(@class,\"active lafPageHost\")]//span[@class=\"test-id__field-label\" and contains(text(),\"{0}\")]//parent::div//following-sibling::div//input[@type=\"checkbox\"]";
		By eleActiveCheckbox = getDynamicElement(strCheckBox, checkBoxName);
		try {
			waitAndVerifyElement(eleActiveCheckbox);
			scrollToElement(eleActiveCheckbox);
			boolean isChecked = isCheckboxSelected(eleActiveCheckbox);
			if (shouldBeChecked) {
				if (isChecked) {
					LoggingInfo("The checkbox " + checkBoxName + " is checked.");
				} else {
					Log.error("The checkbox " + checkBoxName + " is unchecked. But it should be Checked.");
					Assert.fail("The checkbox " + checkBoxName + " is unchecked. But it should be Checked.");
				}
			} else {
				if (!isChecked) {
					System.out.println("The checkbox " + checkBoxName + " is unchecked.");
					Log.error("The checkbox " + checkBoxName + " is unchecked.");
				} else {
					Log.error("The checkbox " + checkBoxName + " is checked. But it should be Unchecked.");
					Assert.fail("The checkbox " + checkBoxName + " is checked. But it should be Unchecked.");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Active checkbox: " + e.getMessage());
			Assert.fail("Failed to verify Active checkbox: " + e.getMessage());
		}

	}

	String ssss = "//span[text()=\"{0}\"]//parent::div//following-sibling::div//span[contains(@class, \"test-id__field-value\") and contains(@class, \"is-read-only\")]";

	/**
	 * Function: Validate if field is marked as read-only in the Details page
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateReadOnlyField(String fieldName) throws Exception {
		By eleStatus = getDynamicElement(ssss, fieldName);
		waitAndVerifyElement(eleStatus);
		scrollToElement(eleStatus);
		Assert.assertTrue(getAttributeValue(eleStatus, "class").contains("is-read-only"),
				fieldName + " Field is  marked as read-only.");
		LoggingInfo(fieldName + " Field is  marked as read-only.");
		setTimeOut(2000);
	}

	/**
	 * Function: Verify if field is null in the Details page
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void VerifyFieldisNull(String fieldName) {
		String field = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div";
		By eleField = getDynamicElement(field, fieldName);

		try {
			waitAndVerifyElement(eleField);
			scrollToElement(eleField);
			String fieldText = getText(eleField).trim();
			if (fieldText.isEmpty()) {
				LoggingInfo(fieldName + " field is null as expected.");
			} else {
				Log.error(fieldName + " field is not null. Found: " + fieldText);
				Assert.fail(fieldName + " field is not null. Found: " + fieldText);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + fieldName + ": " + e.getMessage());
			Assert.fail("Failed to verify " + fieldName + ": " + e.getMessage());
		}
	}

	/**
	 * Function: Get CPE details from field
	 * 
	 * @author Shanavaz Nishani
	 **/
	public String getCpeDetails(String cpeFieldName) {
		String strCPEField = "//*[contains(@class,\"active lafPageHost\")]//span[@class=\"test-id__field-label\" and text()=\"{0}\"]//parent::div//following-sibling::div//a//slot//span//span";
		String fieldval = "";
		By eleCPEField = getDynamicElement(strCPEField, cpeFieldName);
		try {
			waitAndVerifyElement(eleCPEField);
			scrollToElement(eleCPEField);
			fieldval = getText(eleCPEField).trim();
			LoggingInfo(cpeFieldName + " : " + fieldval);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + cpeFieldName + ": " + e.getMessage());
			Assert.fail("Failed to verify " + cpeFieldName + ": " + e.getMessage());

		}
		return fieldval;

	}

	/**
	 * Function: Get Case Number from Case record
	 * 
	 * @author Shanavaz Nishani
	 **/
	public String getCaseNumber() {
		String caseID = "";
		try {
			By eleCaseID = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),'Case')]//parent::slot//parent::div//following-sibling::slot//lightning-formatted-text");
			caseID = getText(eleCaseID).trim();
			Log.info("Case Number: " + caseID);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			Log.error("Failed to get Case Number: " + e.getMessage());
			Assert.fail("Failed to get Case Number: " + e.getMessage());
		}

		return caseID;
	}

	/**
	 * Function: Switch tab on CPE header
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void switchTabOnCPEheader(String tabName) {

		String strTab = "//ul[@class=\"tabBarItems slds-tabs--default__nav\"]//li//a[@role=\"tab\"]//span[@class=\"title slds-truncate\" and text()=\"{0}\"]";
		By eleTab = getDynamicElement(strTab, tabName);
		try {
			waitAndVerifyElement(eleTab);
			scrollToElement(eleTab);
			clickByJavascript(eleTab);
			LoggingInfo("Clicked on tab: " + tabName);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on tab: " + tabName + " | " + e.getMessage());
			Assert.fail("Failed to click on tab: " + tabName + " | " + e.getMessage());

		}
	}

	/**
	 * Function: Click on Edit Type DSR Record
	 * 
	 * @author Anand Pawar
	 **/
	public void clickOnEditTypeDSRRecord() {
		try {
			waitAndVerifyElement(editTypeDSRRecord);
			clickByJavascript(editTypeDSRRecord);
			LoggingInfo("Clicked on Edit Type DSR record");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to click on DSR request" + e.getMessage());
			Assert.fail("Failed to click on DSR request" + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to DSR Line Records
	 * 
	 * @author Anand Pawar
	 **/
	public void navigateToDSRLineItems() {
		try {
			setTimeOut(3000);
			By dsrTable = getDynamicElement(strAccountObjectsCreated, "Data Change Request Line Items");
			scrollToElement(dsrTable);
			clickByJavascript(dsrTable);
		} catch (Exception e) {
			Log.error("Failed to navigate to DSR request" + e.getMessage());
			Assert.fail("Failed to navigate to DSR request" + e.getMessage());
		}
	}
	

/**
	 * Function: update street and city name in account
	 * 
	 * @author Tejal
	 **/
	public void updateStreetAndCity() {
	    try {
	       

	        waitAndVerifyElement(eleEditZipCode);
	        scrollToElement(eleEditZipCode);
	        click(eleEditZipCode);
	        Log.info("Clicked on Edit Mailing Address");

	    
	        By streetTextArea = By.xpath("//textarea[@name='street']");
	        waitAndVerifyElement(streetTextArea);
	        verifyAndEnterInfoInputField(streetTextArea, "/new, street", "Street");
	        Log.info("Street updated to: /new street");

	        
	        By cityInput = By.xpath("//input[@name='city']");
	        waitAndVerifyElement(cityInput);
	        verifyAndEnterInfoInputField(cityInput, "/newyork,", "City");
	        Log.info("City updated to:/newyork,");

	    } catch (Exception e) {
	        e.printStackTrace();
	        Log.error("Failed to update street and city: " + e.getMessage());
	        Assert.fail("Failed to update street and city: " + e.getMessage());
	    }
	}
	

}
