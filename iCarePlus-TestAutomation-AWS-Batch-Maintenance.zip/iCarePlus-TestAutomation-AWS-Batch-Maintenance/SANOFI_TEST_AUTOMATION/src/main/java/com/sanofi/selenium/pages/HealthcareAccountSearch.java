package com.sanofi.selenium.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.sanofi.selenium.core.Utility_Function;

public class HealthcareAccountSearch extends Utility_Function {

	public HealthcareAccountSearch(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	/************************
	 * Elements
	 **************************************************/
	public static By accountsearchTitle = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Account Search\"]");
	public static By searchButton = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Search\"]//parent::button)[1]");
	public static By hcoZip = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//runtime_omnistudio_omniscript-omniscript-text[@data-omni-key=\"iccHCOZip\"]//*[text()=\"Zip\"]//parent::label//parent::div//following-sibling::div//input");
	public static By eleSpName = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//runtime_omnistudio_omniscript-omniscript-text[@data-omni-key=\"iccSPSearchName\"]//input");
	public static By elePayerName = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//runtime_omnistudio_omniscript-omniscript-text[@data-omni-key=\"iccRxPayerSearchName\"]//input");
	/************************
	 * Dynamic Elements
	 **************************************************/
	public static String buttons = "//*[contains(@class,\"active lafPageHost\")]//input[@value=\"{0}\"]";
	public static String strInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strCellValue2 = "//*[contains(@class,\"active lafPageHost\")]//table//tr//td[@data-cell-value=\"{0}\"]//lightning-base-formatted-text";
	public static String strSearchbutton = "(//*[contains(@class,\"active lafPageHost\")]//*[@data-omni-key=\"{0}\"]//*[text()=\"Search\"]//parent::button)[1]";
	public static String strCellValue = "//*[contains(@class,\"active lafPageHost\")]//table//tr[1]//td[@data-label=\"{0}\"]//lightning-base-formatted-text";

	/**
	 * Function: Verify Account search page is displayed
	 *
	 * @author Trupti
	 */
	public void verifyAccountSearchPage() {
		try {
			waitForPageLoaded();
			setTimeOut(3000);
			boolean found = verifyElement(accountsearchTitle);
			Assert.assertTrue(found, "Account search page not found");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify account search page" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: validate search buttons
	 *
	 * @author Trupti
	 */
	public void validateSearchButtons(String searchButtonName) {
		try {
			By buttonName = getDynamicElement(buttons, searchButtonName);
			boolean found = verifyElement(buttonName);
			Assert.assertTrue(found, "Search button not found");
			LoggingInfo("Search button peresent on account search page- " + searchButtonName);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate Search buttons" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Click on search button
	 *
	 * @author Trupti
	 */
	public void clickOnButton(String searchButtonName) {
		try {
			By buttonName = getDynamicElement(buttons, searchButtonName);
			waitAndVerifyElement(buttonName);
			clickByJavascript(buttonName);
			LoggingInfo("Clicked on-" + searchButtonName);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on button" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Validate HCP search criteria
	 *
	 * @author Trupti
	 */

	public void validateHCPSearchCriteria(String[] eleInputBoxValues) {
		try {
			String[] labelName = { "Prescriber First Name", "Prescriber Last Name", "Specialty", "Prescriber NPI#" };
			for (int i = 0; i < labelName.length; i++) {
				By eleInputBox = getDynamicElement(strInputBox, labelName[i]);
				waitAndVerifyElement(eleInputBox);
				scrollToElement(eleInputBox);
				inputText(eleInputBox, eleInputBoxValues[i]);
				setTimeOut(1500);
				LoggingInfo("Search criteria entered in - " + labelName[i] + "value- " + eleInputBoxValues[i]);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate HCP Search Criteria" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Click on search button
	 *
	 * @author Trupti
	 */
	public void clickOnSearchButton(String omnikey) {
		try {
			waitForPageLoaded();
			By eleSearchButton = getDynamicElement(strSearchbutton, omnikey);
			scrollToElement(eleSearchButton);
			click(eleSearchButton);
			LoggingInfo("Clicked on search button");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click On Search Button" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Validate HCP search result
	 *
	 * @author Trupti
	 */
	public void validateHCPSearchResult(String[] eleInputBoxValues) {
		try {
			String[] celleNames = { "HCP Name", "Specialty", "Prescriber NPI #" };

			// HCP Name
			String HCPname = eleInputBoxValues[0] + " " + eleInputBoxValues[1];
			By hcpNameValue = getDynamicElement(strCellValue, celleNames[0]);
			waitAndVerifyElement(hcpNameValue);
			scrollToElement(hcpNameValue);
			verifyDetails(hcpNameValue,HCPname,celleNames[0]);

			// Specialty
			By specialtyValue = getDynamicElement(strCellValue, celleNames[1]);
			waitAndVerifyElement(specialtyValue);
			verifyDetails(specialtyValue, eleInputBoxValues[2], celleNames[1]);

			// Prescriber NPI #
			By npiValue = getDynamicElement(strCellValue, celleNames[2]);
			waitAndVerifyElement(npiValue);
			verifyDetails(npiValue, eleInputBoxValues[3], celleNames[2]);

			LoggingInfo("HCP search result validated successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate HCP Search Result. Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Click on HCP search button
	 *
	 * @author Trupti
	 */
	public void clickOnHCPSearchButton() {
		try {
			clickOnSearchButton("iccHCPSearch");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on HCP search button" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Validate HCO search criteria
	 *
	 * @author Trupti
	 */
	public void validateHCOSearchCriteria(String[] eleInputBoxValues, String zip) {
		try {
			String[] labelName = { "Site/Facility Name", "Fax" };
			for (int i = 0; i < labelName.length; i++) {
				By eleInputBox = getDynamicElement(strInputBox, labelName[i]);
				waitAndVerifyElement(eleInputBox);
				scrollToElement(eleInputBox);
				inputText(eleInputBox, eleInputBoxValues[i]);
				setTimeOut(1500);
				LoggingInfo("Search criteria entered in - " + labelName[i] + "value- " + eleInputBoxValues[i]);
			}
			// zip
			waitAndVerifyElement(hcoZip);
			scrollToElement(hcoZip);
			inputText(hcoZip, zip);
			LoggingInfo("Search criteria entered in zip- " + zip);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate HCO search Criteria" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Click on HCO search button
	 *
	 * @author Trupti
	 */
	public void clickOnHCOSearchButton() {
		try {
			clickOnSearchButton("IntegrationProcedureAction1");
			clickOnSearchButton("IntegrationProcedureAction1");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on HCO search button" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Validate HCO search result
	 *
	 * @author Trupti
	 */

	public void validateHCOSearchResult(String[] eleInputBoxValues) {
		try {
			String[] cellNames = { "Facility Name", "Fax", "Billing Zip/Postal Code" };

			// Facility Name
			String facilityname = eleInputBoxValues[0];
			By elFacilityname = getDynamicElement(strCellValue, cellNames[0]);
			waitAndVerifyElement(elFacilityname);
			scrollToElement(elFacilityname);
			verifyDetails(elFacilityname, facilityname, cellNames[0]);

			// Fax
			String fax = eleInputBoxValues[1];
			By faxValue = getDynamicElement(strCellValue, cellNames[1]);
			waitAndVerifyElement(faxValue);
			verifyDetails(faxValue, fax, cellNames[1]);

			LoggingInfo("HCP search result validated successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate HCP search result. Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Validate SP search criteria
	 *
	 * @author Trupti
	 */
	public void validateSPSearchCriteria(String spName) {
		try {

			waitAndVerifyElement(eleSpName);
			scrollToElement(eleSpName);
			inputText(eleSpName, spName);
			setTimeOut(1500);
			LoggingInfo("Search criteria entered in Specialty Pharmacy Name " + spName);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate SP search criteria" + ". Error - " + e.getMessage());
		}
	}

	public void clickOnSPSearchButton() {
		try {
			clickOnSearchButton("iccSearchSPIP");
			clickOnSearchButton("iccSearchSPIP");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on SP search button" + ". Error - " + e.getMessage());
		}
	}

	public void validateSPSearchResult(String sp) {
		try {
			// Account Name
			By spNameValue = getDynamicElement(strCellValue2,sp);
			waitAndVerifyElement(spNameValue);
			scrollToElement(spNameValue);
			verifyDetails(spNameValue, sp, sp);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate SP search result" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Validate Payer search criteria
	 *
	 * @author Trupti
	 */

	public void validatePayerSearchCriteria(String payer) {
		try {

			waitAndVerifyElement(elePayerName);
			scrollToElement(elePayerName);
			inputText(elePayerName, payer);
			setTimeOut(1500);
			LoggingInfo("Search criteria entered in Payer Name Name " + payer);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate payer search criteria" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Click on payer search button
	 *
	 * @author Trupti
	 */

	public void clickOnPayerSearchButton() {
		try {
			clickOnSearchButton("iccPayerSearchIP");
			clickOnSearchButton("iccPayerSearchIP");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on payer search button" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Validate payer search result
	 *
	 * @author Trupti
	 */

	public void validatePayerSearchResult(String payerName) {
		try {
			// Account Name
			By payerNameValue = getDynamicElement(strCellValue2, payerName);
			waitAndVerifyElement(payerNameValue);
			scrollToElement(payerNameValue);
			verifyDetails(payerNameValue, payerName, "Account Name");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate payer search result" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Validate source system result - ICARE, RCM
	 *
	 * @author Trupti
	 */
	public void validateSourceSystemResult() {
		try {

			waitForPageLoaded();
			setTimeOut(3000);

			List<WebElement> sourceSystem = getWebDriver().findElements(By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//table//tr//td[@data-label=\"Source System\"]//lightning-base-formatted-text"));

			boolean sourceFound = false;
			for (int i = 0; i < sourceSystem.size(); i++) {
				WebElement element = sourceSystem.get(i);
				String text = element.getText();

				if (text.contains("ICARE+")) {
					sourceFound = true;
				}
				if (text.contains("RCM")) {
					sourceFound = true;
				}
			}

			Assert.assertTrue(sourceFound, "Missing source system results");
			LoggingInfo("Source system results validated successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate source system - " + e.getMessage());
		}
	}

}
