package com.sanofi.selenium.constants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public interface EnrollmentConstants {

	public static final ArrayList<String> appLauncherMenuItem = new ArrayList<>(Arrays.asList("Received Documents",
			"Documents", "Assessment Tasks", "Accounts", "Home", "Cases", "Authorization Form Consent",
			"Care Program Enrollees", "Orders", "Member Plans", "Campaigns", "Correspondences",
			"Healthcare Account Search", "Party Role Relationships", "Products", "Care Program Products",
			"Master Correspondence Sets", "Contact Contact Relationships", "Coverage Benefits", "Health Conditions",
			"Medication Requests", "Care Program Enrollee Team Members", "Voice Call", "Medication Dispenses", "Dashboards", "Reports"));

	public static final ArrayList<String> ownerName = new ArrayList<>(
			Arrays.asList("Received Document Worklist", "Automation_DIS Test_User"));

	public static final ArrayList<String> receivedDocDetailsTabSections = new ArrayList<>(
			Arrays.asList("Details", "Related Information", "Additional Document Information", "System Information"));

	public static final ArrayList<String> tabsName = new ArrayList<>(
			Arrays.asList("Details", "Related", "MI", "Document"));

	public static final ArrayList<String> status = new ArrayList<>(
			Arrays.asList("Draft", "In Review", "Superseded", "Needs Review", "Processing","Submitted","Completed"));

	public static final ArrayList<String> documentType = new ArrayList<>(
			Arrays.asList("Enrollment Form", "Invalid Document", "Med D PAP Reenrollment", "Renewal Enrollment Form", "Appeal Request Form", 
					"PAP Documentation", "Consent Form", "Clinical Documentation", "Payer Documentation", "Prescription Information", 
					"Specialty Pharmacy Documentation", "Income Documentation", "Other"));
	
	public static final ArrayList<String> condition = new ArrayList<>(
			Arrays.asList("True", "False"));

	public static final ArrayList<String> documentOCRstatus = new ArrayList<>(
			Arrays.asList("Draft", "OCR In Progress", "Success"));

	static final ArrayList<String> careProgramProductType = new ArrayList<>(
			Arrays.asList("DMW Nasal Polyposis : Dupixent"));

	public static final ArrayList<String> careProgramProduct = new ArrayList<>(Arrays.asList(
			"DMW Nasal Polyposis - Dupixent", "DMW Prurigo Nodularis - Dupixent", "DMW Atopic Dermatitis - Dupixent",
			"DMW Asthma - Dupixent", "DMW EoE - Dupixent", "DMW COPD - Dupixent","DMW BP - Dupixent"));

	public static final ArrayList<String> carePrograms = new ArrayList<>(Arrays.asList("DMW Nasal Polyposis",
			"DMW Prurigo Nodularis", "DMW Atopic Dermatitis", "DMW EoE", "DMW COPD"));

	public static final ArrayList<String> authorizationSigned = new ArrayList<>(Arrays.asList("Yes", "No"));

	public static final ArrayList<String> patientcertSigned = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> textMessaging = new ArrayList<>(Arrays.asList("Yes", "No"));

	public static final ArrayList<String> quickStartRx = new ArrayList<>(Arrays.asList("Yes", "No", "-- Clear --"));

	public static final ArrayList<String> prescriberSignature = new ArrayList<>(
			Arrays.asList("Yes", "No", "-- Clear --"));
	public static final ArrayList<String> patientHasInsurance = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> eosCount = new ArrayList<>(Arrays.asList("Yes", "No","3"));
	public static final ArrayList<String> patientDepedent = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> constRecordType = new ArrayList<>(Arrays.asList("Pharmacy", "Medical"));

	// Do not add any other product in this list
	public static final ArrayList<String> productsMobileApp = new ArrayList<>(
			Arrays.asList("MobileApp - DMW Asthma", "MobileApp - DMW Nasal Polyposis", "MobileApp - DMW EoE",
					"MobileApp - DMW Atopic Dermatitis", "MobileApp - DMW Prurigo Nodularis", "MobileApp - DMW COPD"));

	public static final ArrayList<String> consentNames = new ArrayList<>(
			Arrays.asList("Patient Program Authorization", "General Marketing Consent", "Email Communication Consent",
					"Telephone Communication Consent", "Written/Mail Communication Consent", "Text Messaging Consent",
					"HIPAA Authorization", "HCP Authorization"));

	public static final ArrayList<String> requiredFormFields = new ArrayList<>(Arrays.asList("Name", "Month DOB",
			"Day DOB", "Year DOB", "Phone1", "Phone 2", "Phone 3", "Signature:Patient"));

	public static final ArrayList<String> requiredFormFieldsMedD = new ArrayList<>(
			Arrays.asList("First Name", "Last Name", "DOB", "Gender", "Phone", "Signature:Patient",
					"People in household", "Annual Income", "Please print patient name", "Email"));

	public static final ArrayList<String> formCategory = new ArrayList<>(Arrays.asList("Enrollment Form",
			"Formulario de inscripcion", "PAP Re-enrollment Form", "Formulario de reinscripcion"));

	public static final ArrayList<String> requiredFormFieldsSpanish = new ArrayList<>(
			Arrays.asList("Custom Field 3", "Custom Field 2", "Custom Field 8", "Custom Field 9", "Custom Field 10",
					"Custom Field 14", "Custom Field 27", "Click to sign required", "Signature 2"));

	public static final ArrayList<String> correspondences = new ArrayList<>(
			Arrays.asList("Quick Start Program Notification of Program End Date - MD Fax", "DMW PAP Renewal MD Fax",
					"DMW PAP Approval Medicare Enrollee - MD Fax", "DMW PAP Discontinuation - MD Fax",
					"Initial Free Goods Shipment Confirmation - HCP Fax","MCS-744"));

	public static final ArrayList<String> corresDates = new ArrayList<>(Arrays.asList("12/27/2024", "12/27/2026",
			"1/15/2025", "12/3/2026", "12/4/2026", "12/9/2026", "1/29/2025", "1/13/2027"));

	public static final ArrayList<String> searchFilter = new ArrayList<>(
			Arrays.asList("Accounts", "Care Program Enrollees"));

	public static final ArrayList<String> fuzzyPatientData1 = new ArrayList<>(Arrays.asList("AutomationChristian", "Hernandez",
			"11940", "christianhernandez@gmail.com", "11-01-1954", "A.", "(231) 157-8467", "AutomationChristian"));

	public static final ArrayList<String> existingPatientData = new ArrayList<>(
			Arrays.asList("AutomationChristian Pamela Hernandez", "AutomationSharon Paul Smith", "Lucia Cathy","AutomationStella Morris"));

	public static final ArrayList<String> fuzzyPatientData2 = new ArrayList<>(Arrays.asList("AutomationStella",
			"Morris", "16292", "stellamorris@gmail.com", "05-17-1975", "A.", "(813) 609-7538"));

	public static final ArrayList<String> fuzzyPatientData3 = new ArrayList<>(Arrays.asList("AutomationSharon", "Smith", "13400",
			"sharonsmith@example.com", "09-28-1989", "A.", "(501) 860-4970", "AutomationSha", "Smith"));
	public static final ArrayList<String> fuzzyPatientData4 = new ArrayList<>(
			Arrays.asList("Luzia", "Cathi", "12345", "example@example.com", "01-01-1996", "L.", "(161) 718-1909"));

	public static final ArrayList<String> fuzzyPatientData5 = new ArrayList<String>(
			Arrays.asList("Tarun", "Pandey", "78722", "Vogkrtq@testmail.com", "09-15-1998", "(129) 721-2725"));

	public static final ArrayList<String> existingPatientData5 = new ArrayList<>(
			Arrays.asList("Tarun Pandey", "Sara Cathie", "Lucia Cathi"));

	public static final ArrayList<String> fuzzyPatientData6 = new ArrayList<String>(
			Arrays.asList("S.", "Cathi", "11940", "sarahcathie@yahoo.com", "11-01-1954", "(231) 157-8467"));

	public static final ArrayList<String> fuzzyPatientData7 = new ArrayList<String>(
			Arrays.asList("Luc", "Cathy", "12345", "example@example.com", "01-01-1990", "(692) 357-6877"));

	public static final ArrayList<String> existingAccNames = new ArrayList<>(
			Arrays.asList("Beatrice Jackmen", "Lucia Cathy", "William Jackman", "Sara Cathie","AutomationSharon Paul Smith","Beatriz Jackman"));

	public static final ArrayList<String> firstName = new ArrayList<>(
			Arrays.asList("Beatriz", "B.", "AutomationSha", "AutomationSharon", "A.","S."));

	public static final ArrayList<String> lastName = new ArrayList<>(
			Arrays.asList("Jackman", "Cathy", "Smith", "Hernandez","Cathie"));

	public static final ArrayList<String> zips = new ArrayList<>(Arrays.asList("13400", "11940"));

	public static final ArrayList<String> emails = new ArrayList<>(
			Arrays.asList("example@example.com", "sharonsmith@example.com", "sarahcathie@yahoo.com"));

	public static final ArrayList<String> phoneNumbers = new ArrayList<>(
			Arrays.asList("5018604970", "2311578467", "1617181909"));

	public static final ArrayList<String> TaxIDs = new ArrayList<>(
			Arrays.asList("607195390", "161819090"));
	public static final ArrayList<String> dobs = new ArrayList<>(Arrays.asList("09-28-1989","11-01-1954"));

	public static final ArrayList<String> careProgramMI = new ArrayList<>(Arrays.asList("DMW Asthma : HCP Zip",
			"Incorrect Enrollment Form Version", "Incorrect Enrollment Form Indication"));

	public static final ArrayList<String> statusReason = new ArrayList<>(Arrays.asList("Active"));

	public static final ArrayList<String> accountListView = new ArrayList<>(
			Arrays.asList("All Accounts", "All Office Contacts", "All HCPs", "All Caregivers", "All Payers",
					"All Facilities", "All Specialty Pharmacies"));

	public static final ArrayList<String> accountHistory = new ArrayList<>(
			Arrays.asList("Authorization Form Consent History", "Care Program Enrollee History",
					"Care Program Enrollee Product History", "Contact Contact Relationship History",
					"Coverage Benefit History", "Health Condition History", "Medication Request History",
					"Member Plan History", "Correspondence History", "Order History", "Received Document History"));

	// Do not add any other record type in this list
	Map<String, String[]> ActiveDUPCodes = new HashMap<String, String[]>() {
		{
			put("DUP.23.01.0038",
					new String[] { "DMW Enrollment Form Confirmation - MD Fax", "12/16/2026" });
			put("DUP.23.01.0080",
					new String[] { "DMW New UM Criteria Requirements - MD Fax", "12/16/2026" });
			put("DUP.23.01.0075", new String[] { "DMW Lash MD Fax - Unable to Contact", "12/16/2026" });

			put("DUP.23.01.0076", new String[] { "DMW IAP Approval - MD Fax", "1/3/2027" });
			put("DUP.23.01.0077", new String[] { "DMW IAP Discontinuation - MD Fax", "1/3/2027" });
			put("DUP.23.01.0079", new String[] { "DMW Lash MD Fax - Interim Access Denial", "1/3/2027" });
			put("DUP.23.01.0078",
					new String[] { "DMW IAP Discontinuation Obtained Coverage - MD Fax", "1/3/2027" });
			put("DUP.23.01.0283",
					new String[] { "DMW SP Enrollment Form Confirmation - MD Fax", "1/3/2027" });
			put("DUP.23.01.0282", new String[] { "DMW Lash MD Fax - PA Expiring 30 Days", "12/16/2026" });
			put("US.DUP.25.01.0089", new String[] { "DMW Quick Start Program Ineligible - MD Fax", "1/27/2027" });
			put("US.DUP.25.01.0092", new String[] { "DMW Quick Start Program Enrolled - MD Fax", "1/27/2027" });
			put("US.DUP.25.01.0263", new String[] { "DMW Appeal Coordination - MD Fax", "3/7/2027" });
		}
	};

	// Do not add any other record type in this list
	Map<String, String[]> inactiveDUPcodes = new HashMap<String, String[]>() {
		{
			put("DUP.23.01.0052", new String[] { "DMW Quick Start Program Denial - MD Fax", "1/29/2025" });
			put("DUP.23.01.0134", new String[] { "DMW Quick Start Approval - HCP Fax", "1/31/2025" });
			put("DUP.23.03.0067", new String[] { "DMW Appeal Coordination - HCP Fax", "3/19/2025" });

		}
	};


	public static final ArrayList<String> CorrespondenceActiveStatus = new ArrayList<>(Arrays.asList("Yes", "No"));
	
	public static final ArrayList<String> DashboardSideBarOptions = new ArrayList<>(
			Arrays.asList("All Dashboards", "All Folders"));
	
	public static final ArrayList<String> ReportsSideBarOptions = new ArrayList<>(
			Arrays.asList("All Reports"));
	
	public static final ArrayList<String> dashboardFolders = new ArrayList<>(Arrays.asList("Dupixent BV Manager Dashboard", "Dupixent CM Manager", 
			"Dupixent Program Manager Dashboard", "Dupixent Control Tower Dashboard", "Dupixent Triage Dashboard", "Dupixent Aging Dashboard", 
			"Dupixent Data Intake Team Dashboard", "Dupixent COPD Launch Dashboard"));
	
	public static final ArrayList<String> reportsFolders = new ArrayList<>(Arrays.asList("Accounts By Inactive Status", "Accounts with Duplicate in Name"));
}
