package com.sanofi.selenium.apiutils;

import java.io.FileInputStream;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;

import org.apache.http.conn.ssl.SSLSocketFactory;

import com.sanofi.selenium.constants.APIConstants;
import com.sanofi.selenium.core.BaseTest;
import io.restassured.RestAssured;
import io.restassured.config.SSLConfig;
import io.restassured.response.Response;

public class CertificateAuth extends BaseTest {

	/**
	 * Function: To send certicates with API request
	 * 
	 * @author Pratiksha Dixit
	 * 
	 * @return API response
	 * @throws KeyStoreException
	 * @throws NoSuchAlgorithmException
	 * @throws UnrecoverableKeyException
	 * @throws KeyManagementException
	 */
	public static String certificateAuthSetupForWebsites(String certificateFileName, String certPassword,
			String payload, String keyValue, String baseUri)
			throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {
		KeyStore KeyStore = null;
		SSLConfig config = null;
		Response respo = null;
		String body = "";

		try {
			KeyStore = KeyStore.getInstance("PKCS12");
			KeyStore.load(
					new FileInputStream(System.getProperty("user.dir") + "/CertificatesAPI/" + certificateFileName),
					certPassword.toCharArray());

		} catch (Exception ex) {
			System.out.println("Error while loading keystore >>>>>>>>>");
			ex.printStackTrace();
		}
		if (KeyStore != null) {
			SSLSocketFactory clientAuthFactory = new SSLSocketFactory(KeyStore, certPassword);

			// set the config in rest assured
			config = new SSLConfig().with().sslSocketFactory(clientAuthFactory).and().allowAllHostnames();

			RestAssured.config = RestAssured.config().sslConfig(config);
			respo = RestAssured.given().header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constApiKey, keyValue).body(payload).when().post(baseUri).then().assertThat().statusCode(200)
					.extract().response();

			body = respo.getBody().asString();

		}
		return body;

	}

}
