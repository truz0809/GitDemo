package com.sanofi.selenium.constants;

import java.util.ArrayList;

import java.util.Arrays;

public interface EnrollmentFormPDFConstants {

	/************** Patient Info-PDF Constants *****************/

	public static final ArrayList<String> patientInfoInputBoxes = new ArrayList<>(

			Arrays.asList("Name.Page 1", "Language.Page 1", "Address.Page 1", "City.Page 1", "State.Page 1",

					"Zip.Page 1", "Email.Page 1", "Representative name.Page 1", "Representative relationship.Page 1"));

	public static final ArrayList<String> patientInfoInputBoxesCOPD = new ArrayList<>(

			Arrays.asList("Patient Name Page 1", "Language 1", "Address 1", "City 1", "State 1",

					"Zip 1", "Email 1", "Representative name", "Representative relationship "));

	public static final ArrayList<String> patientGender = new ArrayList<>(

			Arrays.asList("Male.Page 1", "Female.Page 1"));

	public static final ArrayList<String> patientGenderCOPD = new ArrayList<>(

			Arrays.asList("Female 1", "Male 1"));

	public static final ArrayList<String> patientInfoChecktBoxes = new ArrayList<>(Arrays.asList("Text .Page 1",

			"Text.Page 1", "Voicemail.Page 1", "AM.Page 1", "Afternoon.Page 1", "PM.Page 1"));

	public static final ArrayList<String> patientInfoChecktBoxesCOPD = new ArrayList<>(Arrays.asList("Text Consent",

			"Text ", "Voicemail ", "AM ", "Afternoon ", "PM "));

	public static final ArrayList<String> patientInformationAuthSign = new ArrayList<>(

			Arrays.asList("Month sec6.Page 1", "Date sec6.Page 1", "Year sec6.Page 1"));

	public static final ArrayList<String> patientInformationAuthSignCOPD = new ArrayList<>(

			Arrays.asList("Sec 6 Date: Month ", "Sec 6 Date: Day", "Sec 6 Date: Year"));

	public static final ArrayList<String> patientInformationDOB = new ArrayList<>(

			Arrays.asList("Month DOB.Page 1", "Day DOB.Page 1", "Year DOB.Page 1"));

	public static final ArrayList<String> patientInformationDOBCOPD = new ArrayList<>(

			Arrays.asList("Patient Month DOB 1", "Patient Day DOB 1", "Patient Year DOB 1"));

	public static final ArrayList<String> patientInformationCertSign = new ArrayList<>(

			Arrays.asList("Month sec7.Page 1", "Date sec7.Page 1", "Year sec7.Page 1"));

	public static final ArrayList<String> patientInformationCertSignCOPD = new ArrayList<>(

			Arrays.asList("Sec 7 Date: Month ", "Sec 7 Date: Day", "Sec 7 Date: Year"));

	public static final ArrayList<String> patientPriPhn = new ArrayList<>(

			Arrays.asList("Phone1.Page 1", "Phone 2.Page 1", "Phone 3.Page 1"));

	public static final ArrayList<String> patientPriPhnCOPD = new ArrayList<>(

			Arrays.asList("Patient Primary Phone 1", "Patient Primary Phone 2", "Patient Primary Phone 3"));

	public static final ArrayList<String> patientSecPhn = new ArrayList<>(

			Arrays.asList("Phone4.Page 1", "Phone 5.Page 1", "Phone 6.Page 1"));

	public static final ArrayList<String> patientSecPhnCOPD = new ArrayList<>(

			Arrays.asList("Patient Secondary Phone 1", "Patient Secondary Phone 2", "Patient Secondary Phone 3"));
	
	/************** Patient Insurance-PDF Constants *****************/

	public static final ArrayList<String> patientInsInputBoxes = new ArrayList<>(

			Arrays.asList("Rx Name.Page 1", "Rx ID.Page 1", "Rx group.Page 1", "Rx bin.Page 1", "Rx PCN.Page 1",

					"Med Insure Name .Page 1", "Med Insure ID .Page 1", "Med Insure group.Page 1",

					"Policyholder name.Page 1", "Policyholder relationship.Page 1", "PSP Name.Page 1"));

	public static final ArrayList<String> patientInsInputBoxesCOPD = new ArrayList<>(

			Arrays.asList("Primary Rx Name ", "Rx ID ", "Rx group", "Rx bin ", "Rx PCN ",

					"Primary Med Insure ", "Med Insure Policy ID#", "Med Insure group # ",

					"Policyholder name ", "Policyholder relationship ", "PSP Name 1"));

	public static final ArrayList<String> rxphone = new ArrayList<>(

			Arrays.asList("Rx phone 1.Page 1", "Rx phone 2.Page 1", "Rx phone 3.Page 1"));

	public static final ArrayList<String> rxphoneCOPD = new ArrayList<>(

			Arrays.asList("Rx phone 1", "Rx phone 2", "Rx phone 3"));

	public static final ArrayList<String> medphone = new ArrayList<>(

			Arrays.asList("Med Insure phone 1.Page 1", "Med Insure phone 2.Page 1", "Med Insure phone 3.Page 1"));

	public static final ArrayList<String> medphoneCOPD = new ArrayList<>(

			Arrays.asList("Med Insure phone 1", "Med Insure phone 2", "Med Insure phone 3"));

	public static final ArrayList<String> pharmphone = new ArrayList<>(

			Arrays.asList("PSP phone 1.Page 1", "PSP phone 2.Page 1", "PSP phone 3.Page 1"));

	public static final ArrayList<String> pharmphoneCOPD = new ArrayList<>(

			Arrays.asList("PSP phone 1", "PSP phone 2", "PSP phone 3"));

	public static final ArrayList<String> pharmfax = new ArrayList<>(

			Arrays.asList("PSP fax 1.Page 1", "PSP fax 2.Page 1", "PSP fax 3.Page 1"));

	public static final ArrayList<String> pharmfaxCOPD = new ArrayList<>(

			Arrays.asList("PSP fax 1", "PSP fax 2", "PSP fax 34"));

	public static final ArrayList<String> patientInsuranceCheckBoxes = new ArrayList<>(

			Arrays.asList("No insurance.Page 1", "DMW.Page 1", "PSP.Page 1"));

	public static final ArrayList<String> patientInsuranceCheckBoxesCOPD = new ArrayList<>(

			Arrays.asList("No insurance check box", "DMW Check box", "PSP check box"));

	public static final ArrayList<String> prescriberInfoInputBoxes = new ArrayList<>(Arrays.asList(

			"Prescriber name.Page 1", "Prescriber spec.Page 1", "Prescriber address.Page 1", "Prescriber city.Page 1",

			"Prescriber state.Page 1", "Prescriber zip.Page 1", "Prescriber NPI.Page 1", "site name.Page 1",

			"Prescriber contact.Page 1", "Prescriber email.Page 1", "Prescriber tax id.Page 1"));

	public static final ArrayList<String> prescriberInfoInputBoxesCOPD = new ArrayList<>(Arrays.asList(

			"Prescriber name ", "Prescriber spec ", "Prescriber address ", "Prescriber city ",

			"Prescriber state ", "Prescriber zip ", "Prescriber NPI", "site name ",

			"Prescriber office contact name", "Prescriber office contact email", "Prescriber tax id  "));

	public static final ArrayList<String> prescriberfax = new ArrayList<>(

			Arrays.asList("Prescriber fax 1.Page 1", "Prescriber fax 2.Page 1", "Prescriber fax 3.Page 1"));

	public static final ArrayList<String> prescriberfaxCOPD = new ArrayList<>(

			Arrays.asList("Prescriber office contact fax 1", "Prescriber office contact fax 2",
					"Prescriber office contact fax 3"));

	public static final ArrayList<String> prescriberphone = new ArrayList<>(

			Arrays.asList("Prescriber phone 1.Page 1", "Prescriber phone 2.Page 1", "Prescriber phone 3.Page 1"));

	public static final ArrayList<String> prescriberphoneCOPD = new ArrayList<>(

			Arrays.asList("Prescriber office contact Ph 1", "Prescriber office contact Ph 2",
					"Prescriber office contact Ph 3"));

	public static final ArrayList<String> diagnosisDate = new ArrayList<>(

			Arrays.asList("Diagnosis date 1.Page 1", "Diagnosis date 2.Page 1", "Diagnosis date 3.Page 1"));

	public static final ArrayList<String> diagnosisDateCOPD = new ArrayList<>(

			Arrays.asList("Date Tested Month - Page 2", "Date Tested Day - Page 2", "Date Tested Year - Page 2"));

	public static final ArrayList<String> nasalDiagnoisCode = new ArrayList<>(

			Arrays.asList("Diagnosis 12", "Diagnosis 14", "Diagnosis 13", "ICD-10-CM 4"));

	public static final ArrayList<String> copdDiagnoisCode = new ArrayList<>(

			Arrays.asList("ICD-10 - J44 - Page 2", "ICD-10 - Other Page 2", "ICD-10 - Page 2"));

	public static final ArrayList<String> prescriptionInfoInputBoxesNasal = new ArrayList<>(

			Arrays.asList("Patient name 2.Page 2", "Prescriber name 2.Page 2", "Prescriber address 2.Page 2",

					"Prescriber NPI 2.Page 2", "Refills 20", "Refills 21", "Allergies 20", "Allergies 21",

					"Collaborating MD 6", "NPI 7"));

	public static final ArrayList<String> dobNasal = new ArrayList<>(

			Arrays.asList("Month DOB  2.Page 2", "Date DOB 2.Page 2", "Year DOB 2.Page 2"));

	public static final ArrayList<String> prescriptionInfoCheckBoxesNasal = new ArrayList<>(

			Arrays.asList("Sample 20", "Syringe 20", "Pen 20", "New start 17", "Sample 21", "Syringe 21", "Pen 21"));

	public static final ArrayList<String> sampleProvidedDateANasal = new ArrayList<>(

			Arrays.asList("Month sample 20", "Date sample 20", "Year sample 20"));

	public static final ArrayList<String> sampleProvidedDateBNasal = new ArrayList<>(

			Arrays.asList("Month sample 21", "Date sample 21", "Year sample 21"));

	public static final ArrayList<String> presSIGNNasal = new ArrayList<>(

			Arrays.asList("Month prescriber 5", "Date prescriber 5", "Year prescriber 5"));

	public static final ArrayList<String> subSIGNNasal = new ArrayList<>(

			Arrays.asList("Month subs 6", "Date subs 6", "Year subs 6"));

	/***************************************************************************************/

	public static final ArrayList<String> asthamaDiagnoisCode = new ArrayList<>(

			Arrays.asList("Diagnosis", "Diagnosis 1", "Diagnosis 2", "Diagnosis 3", "Diagnosis 4", "ICD-10-CM Asthma"));

	public static final ArrayList<String> prescriptionInfoInputBoxesAsthama = new ArrayList<>(Arrays.asList(

			"Patient name.Page 2", "Prescriber name.Page 2", "Prescriber address.Page 2", "Prescriber NPI.Page 2",

			"Refills 12", "Refills 13", "Allergies 12", "Allergies 13", "Collaborating MD 2", "NPI 3"));

	public static final ArrayList<String> prescriptionInfoInputBoxesCOPD = new ArrayList<>(Arrays.asList(

			"Patient name - Page 1", "Prescriber name - page 2 ", "Prescriber address - Page 2", "NPI#",

			"5a Refills ", "5b Refills ", "5a Know drug allergies", "5b Know drug allergies", "Collaborating MD Name",
			"NPI#"));

	public static final ArrayList<String> prescriptionInfoCheckBoxesAstma = new ArrayList<>(

			Arrays.asList("Sample 12", "Syringe 12", "Pen 12", "New start 13", "Sample 13", "Syringe 13", "Pen 13"));

	public static final ArrayList<String> sampleProvidedDateAAsthma = new ArrayList<>(

			Arrays.asList("Month sample 12", "Date sample 12", "Year sample 12"));

	public static final ArrayList<String> sampleProvidedDateBAsthma = new ArrayList<>(

			Arrays.asList("Month sample 13", "Date sample 13", "Year sample 13"));

	public static final ArrayList<String> presSIGNAsthma = new ArrayList<>(

			Arrays.asList("Month prescriber", "Date prescriber", "Year prescriber"));

	public static final ArrayList<String> subSIGNAsthma = new ArrayList<>(

			Arrays.asList("Month subs 2", "Date subs 2", "Year subs 2"));

	public static final ArrayList<String> prescriptionInfoInputBoxesEOE = new ArrayList<>(Arrays.asList(

			"Patient name Page 2", "Prescriber name Page 2", "Prescriber address Page 2", "Prescriber NPI Page 2",

			"Refills 18", "Refills 19", "Allergies 18", "Allergies 19", "Collaborating MD Name ", "NPI#"));

	public static final ArrayList<String> prescriptionInfoCheckBoxesEOE = new ArrayList<>(Arrays

			.asList("Sample Provided 18", "Syringe 18", "Pen 18", "New start 19", "Sample 19", "Syringe 19", "Pen 19"));

	public static final ArrayList<String> sampleProvidedDateAEOE = new ArrayList<>(

			Arrays.asList("Month sample 18", "Date sample 18", "Year sample 18"));

	public static final ArrayList<String> sampleProvidedDateBEOE = new ArrayList<>(

			Arrays.asList("Month sample 19", "Date sample 19", "Year sample 19"));

	public static final ArrayList<String> presSIGNEOE = new ArrayList<>(

			Arrays.asList("Month prescriber 7", "Date prescriber 7", "Year prescriber 7"));

	public static final ArrayList<String> subSIGNEOE = new ArrayList<>(

			Arrays.asList("Month prescriber 8", "Date prescriber 8", "Year prescriber 8"));

	public static final ArrayList<String> eoeDiagnoisCode = new ArrayList<>(

			Arrays.asList("Diagnosis 17.Page 1", "Diagnosis 18.Page 1", "ICD-10-CM 7"));

	public static final ArrayList<String> prescriptionInfoInputBoxesNodularis = new ArrayList<>(

			Arrays.asList("Patient name 2.Page 2", "Prescriber name 2.Page 2", "Prescriber address 2.Page 2",

					"Prescriber NPI 2.Page 2", "Refills 16", "Refills 17", "Allergies 16", "Allergies 17",

					"Collaborating MD 4", "NPI 5"));

	public static final ArrayList<String> prescriptionInfoCheckBoxesNodularis = new ArrayList<>(

			Arrays.asList("Sample 16", "Syringe 16", "Pen 16", "New start 15", "Sample 17", "Syringe 17", "Pen 17"));

	public static final ArrayList<String> sampleProvidedDateANodularis = new ArrayList<>(

			Arrays.asList("Month sample 16", "Date sample 16", "Year sample 16"));

	public static final ArrayList<String> sampleProvidedDateBNodularis = new ArrayList<>(

			Arrays.asList("Month sample 17", "Date sample 17", "Year sample 17"));

	public static final ArrayList<String> presSIGNNodularis = new ArrayList<>(

			Arrays.asList("Month prescriber 3", "Date prescriber 3", "Year prescriber 3"));

	public static final ArrayList<String> subSIGNNodularis = new ArrayList<>(

			Arrays.asList("Month subs 4", "Date subs 4", "Year subs 4"));

	public static final ArrayList<String> nodularisDiagnoisCode = new ArrayList<>(

			Arrays.asList("Diagnosis 8", "Diagnosis 10", "ICD-10-CM PN"));

	public static final ArrayList<String> prescriptionInfoInputBoxesdermatis = new ArrayList<>(

			Arrays.asList("Patient name.Page 2", "Prescriber name.Page 2", "Prescriber address.Page 2",

					"Prescriber NPI.Page 2", "Refills 14", "Refills 15", "Allergies 14", "Allergies 15",

					"Collaborating MD 3", "NPI 4"));

	public static final ArrayList<String> prescriptionInfoCheckBoxesdermatis = new ArrayList<>(

			Arrays.asList("Sample 14", "Syringe 14", "Pen 14", "New start 14", "Sample 15", "Syringe 15", "Pen 15"));

	public static final ArrayList<String> sampleProvidedDateAdermatis = new ArrayList<>(

			Arrays.asList("Month sample 14", "Date sample 14", "Year sample 14"));

	public static final ArrayList<String> sampleProvidedDateBdermatis = new ArrayList<>(

			Arrays.asList("Month sample 15", "Date sample 15", "Year sample 15"));

	public static final ArrayList<String> presSIGNdermatis = new ArrayList<>(

			Arrays.asList("Month prescriber 2", "Date prescriber 2", "Year prescriber 2"));
	
	public static final ArrayList<String> presSIGNCOPD = new ArrayList<>(

			Arrays.asList("Prescriber Sig: Month", "Prescriber Sig: Day", "Prescriber Sig: Year"));

	public static final ArrayList<String> subSIGNdermatis = new ArrayList<>(

			Arrays.asList("Month subs 3", "Date subs 3", "Year subs 3"));

	public static final ArrayList<String> subSIGNCOPD = new ArrayList<>(

			Arrays.asList("Subs Permitted: Month ", "Subs Permitted: Day", "Subs Permitted: Year"));

	public static final ArrayList<String> dermatisDiagnoisCode = new ArrayList<>(

			Arrays.asList("Diagnosis 5", "Diagnosis 6", "Diagnosis 7", "ICD-10-CM 2"));

	public static final ArrayList<String> weightEoe = new ArrayList<>(

			Arrays.asList("Weight 18", "Weight 19"));

}