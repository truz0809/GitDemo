package com.sanofi.selenium.constants;

import java.util.ArrayList;
import java.util.Arrays;

public interface TriageConstant {

    public static final ArrayList<String> mrStatus = new ArrayList<>(
			Arrays.asList("Active", "Cancelled"));


}
