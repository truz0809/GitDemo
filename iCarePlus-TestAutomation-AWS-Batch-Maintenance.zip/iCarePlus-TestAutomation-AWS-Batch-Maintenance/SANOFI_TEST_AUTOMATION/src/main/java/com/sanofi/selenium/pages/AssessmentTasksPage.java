package com.sanofi.selenium.pages;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;
import java.time.format.DateTimeFormatter;

public class AssessmentTasksPage extends Utility_Function {

	public AssessmentTasksPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	String highlightStyle = "background-color: yellow; border: 3px solid red;";
	String ID;
	

	/************************
	 * Elements
	 **************************************************/
	public static By listViewButton = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@title=\"Select a List View: Assessment Tasks\"]");
	public static By cpeList = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//a//*[text()=\"CPE\"]//ancestor::table//td[4]//span[contains(@part,\"formatted-rich-text\")]//a");
	
	public static By assignToMeButton = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@title='Assign to me']");
	public static By createdDateColumn = By.xpath("//*[text()=\"Created\"]//parent::a");

	public static By dateList = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//ancestor::table//th//lst-formatted-text//span");

	public static By recentlyViewedDropdown = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//button[@title='Select a List View: Accounts']");
	
	/************************
	 * Dynamic Elements
	 * 
	 **************************************************/
	public static String strDocumentPageTitle = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String listViewOptions = "//*[text()=\"{0}\"]//parent::a";
	public static String checkboxes = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@href,\"{0}\")]//ancestor::tr//span[contains(@class,\"checkbox\")]";
	public static String eleOpenCPERecord = "//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"{0}\")]//ancestor::tr//span//a";
	public static String strCreatedDate = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@href,\"{0}\")]//ancestor::tr//th//lst-formatted-text//span";

	
	/**
	 * Function: Verify recently view is displayed when list view is loaded
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyRecentlyViewList() {

		try {
			Log.info("Recently View Documents List");
			waitForPageLoaded();
			By allReceiveddocumentList = getDynamicElement(strDocumentPageTitle, "Recently Viewed");
			waitAndVerifyElement(allReceiveddocumentList);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to load Recently Viewed List" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Clicking on recently view is displayed when list view is loaded
	 * 
	 * @author Sonica P
	 **/
	public void clickRecentlyViewList() {

		try {
			Log.info("Recently View Documents List");
			waitForPageLoaded();
//			By allReceiveddocumentList = getDynamicElement(strDocumentPageTitle, "Recently Viewed");
			click(recentlyViewedDropdown);
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to load Recently Viewed List" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Navigate to all BV worklist view
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToAllBVWorklist() {
	try {
		Log.info("Navigate to All BV Worklist");
		click(listViewButton);

		By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
		waitAndVerifyElement(eleSearch);
		clickByJavascript(eleSearch);
		inputText(eleSearch, "All BV Worklist");
		Actions act = new Actions(getWebDriver());
		act.sendKeys(Keys.DOWN).perform();
		setTimeOut(2000);
		act.sendKeys(Keys.ENTER).perform();
		setTimeOut(8000);
	//	refresh();
		LoggingInfo("Navigated to All BV Worklist");
	} catch (Exception e) {
		e.printStackTrace();
		Log.error("Failed to navigated to All BVS Worklist " + e.getMessage());
		Assert.fail("Failed to navigated to All BVS Worklist " + e.getMessage());
	}

	}

	/**
	 * Function: Verify and assigned CPE record to BV
	 * 
	 * @author Trupti Zure
	 **/
	public String verifyAndAssignCPERecord(String ID) {
	    String recordCreatedDate = null;
	    int retryCount = 0;
	    int maxRetries = 5;

	    while (retryCount < maxRetries) {
	        try {
	            waitForPageLoaded();
	            setTimeOut(2000);  // Consider replacing with explicit waits

	            if (methodToAvoidStaleElementReferenceErrorElement(cpeList)) {
	                waitAndVerifyElement(cpeList);
	                List<WebElement> listOptions = getWebDriver().findElements(cpeList);

	                for (WebElement element : listOptions) {
	                    ((JavascriptExecutor) getWebDriver()).executeScript(
	                        "arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });", element
	                    );

	                    String href = element.getAttribute("href");
	                    String extractedId = extractRecordIdFromHref(href); 
	                    setTimeOut(1000);

	                    if (extractedId != null && extractedId.contains(ID)) {
	                        LoggingInfo("Matching CPE ID found: " + extractedId);

	                        ((JavascriptExecutor) getWebDriver()).executeScript(
	                            "arguments[0].setAttribute('style', arguments[1]);", element, highlightStyle
	                        );

	                        // Get and log created date
	                        By createdDate = getDynamicElement(strCreatedDate, ID);
	                        waitAndVerifyElement(createdDate);
	                        waitForvisiblityOfElementLocated(createdDate);
	                        recordCreatedDate = getText(createdDate);

	                        // Select checkbox
	                        By checkbox = getDynamicElement(checkboxes, ID);
	                        waitAndVerifyElement(checkbox);
	                        clickByJavascript(checkbox);
	                        LoggingInfo("Clicked on checkbox");

	                        // Assign to me
	                        waitAndVerifyElement(assignToMeButton);
	                        clickByJavascript(assignToMeButton);
	                        LoggingInfo("Clicked on Assign to me button");

	                        break;  // Exit loop after success
	                    }
	                }

	                if (recordCreatedDate != null) {
	                    break;  // Exit retry loop
	                } else {
	                    LoggingInfo("CPE ID not found in current attempt: " + ID);
	                    scrollToElement(createdDateColumn);
	                    clickByJavascript(createdDateColumn);
	                    setTimeOut(3000);
	                }
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	            Log.error("Failed to verify or assign CPE record: " + e.getMessage());
	        }

	        retryCount++;
	        if (retryCount < maxRetries) {
	            LoggingInfo("Retrying... attempt " + (retryCount + 1));
	        }
	    }

	    if (recordCreatedDate == null) {
	        LoggingInfo("Could not find and assign CPE record after " + maxRetries + " attempts: " + ID);
	        Assert.fail("Failed to verify and assign CPE record for ID: " + ID);
	    }

	    return recordCreatedDate;
	}

	/**
	 * Function: Navigate to CPE Record and capture the URL ID
	 * 
	 * @author SOnica
	 **/
	public String navigateAndGetID() {
		String url = getCurrentPageURL();
		navigateToURL(url);

		String url1[] = url.split("/");
		String actualId = url1[6];
		String croppedId = actualId;
		croppedId = actualId.substring(0, 15);
		String ID = croppedId;
		System.out.println("Unique ID: " + ID);

		return ID;

//
//		By cpeID = By.xpath("//a[@href='/" + croppedId + "']");
//		System.out.print(cpeID);
//		setTimeOut(2000);
//		return cpeID;

	}

	/// Sonica

	/**
	 * Function: Verify and assigned CPE record to BV
	 * 
	 * @author Sonica
	 
	public String verifyAndAssignCPERecordByLink() {
		String recordCreatedDate = null;
		int retryCount = 0;
		int maxRetries = 3;

		while (retryCount < maxRetries) {
			waitForPageLoaded();
			setTimeOut(2000);

			try {
				JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
				if (methodToAvoidStaleElementReferenceErrorElement(cpeList)) {
					waitAndVerifyElement(cpeList);
					setTimeOut(1000);
					List<WebElement> listOptions = getWebDriver().findElements(cpeList);
					boolean idFound = false;
					int startIdx = 0;

					while (startIdx < listOptions.size()) {
						WebElement element = listOptions.get(startIdx);
						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								element);

						setTimeOut(1000);

						//////
						By createdDate = getDynamicElement(strCreatedDate, ID);
						waitAndVerifyElement(createdDate);
						waitForvisiblityOfElementLocated(createdDate);
						setTimeOut(2000);
						recordCreatedDate = getText(createdDate);
						setTimeOut(3000);

						By checkbox = getDynamicElement(checkboxes, ID);
						waitAndVerifyElement(checkbox);
						clickByJavascript(checkbox);
						setTimeOut(2000);
						LoggingInfo("Clicked on checkbox");
						idFound = true;

						waitAndVerifyElement(assignToMeButton);
						clickByJavascript(assignToMeButton);
						setTimeOut(2000);
						LoggingInfo("Clicked on Assign to me button");
						setTimeOut(2000);

						break;
					}

					if (idFound) {
						break;
					} else {
						LoggingInfo("cpeID not found: ");
						scrollToElement(createdDateColumn);
						clickByJavascript(createdDateColumn);
						setTimeOut(3000);
					}

				}

			} catch (Exception e) {
				e.printStackTrace();
				Log.error("Failed to verify document record " + e.getMessage());
				Assert.fail("Failed to verify document record " + e.getMessage());
			}

			retryCount++;
			if (retryCount < maxRetries) {
				LoggingInfo("Retrying.. " + (retryCount + 1));
			}
		}

		if (retryCount == maxRetries) {
			LoggingInfo("Could not find and assign account: ");
		}

		return recordCreatedDate;
	}**/

	/**
	 * Function: Verify My Assessment Tasks View is displayed when Bv assigns the
	 * record
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyMyAssessmentTasksView() {
		try {
			waitForPageLoaded();
			By myAssessmentListView = getDynamicElement(strDocumentPageTitle, "My Assessment Tasks");
			waitAndVerifyElement(myAssessmentListView);
			setTimeOut(2000);
			LoggingInfo("Navigated to My Assessment Tasks");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigated to My Assessment Tasks " + e.getMessage());
			Assert.fail("Failed to navigated to My Assessment Tasks " + e.getMessage());
		}
	}

	/**
	 * Function: Open CPE task from BV worklist
	 * 
	 * @author Trupti Zure
	 **/
	public void openCPETask(String createdDate) {
		try {
			waitForPageLoaded();
			setTimeOut(8000);
			documentsPage.verifyMyAssessmentTaskList();

			if (methodToAvoidStaleElementReferenceErrorElement(dateList)) {
				waitAndVerifyElement(dateList);
				setTimeOut(5000);
				List<WebElement> listOptions = getWebDriver().findElements(dateList);
				boolean cpeFound = false;
				for (int i = 0; i < listOptions.size(); i++) {
					((JavascriptExecutor) getWebDriver()).executeScript(
							"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
							listOptions.get(i));
					String cpeDate = listOptions.get(i).getText();
					setTimeOut(1000);

					if (cpeDate.equalsIgnoreCase(createdDate)) {
						WebElement element = listOptions.get(i);
						JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
						js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, highlightStyle);
						setTimeOut(1000);
						By cpeRecordLink = getDynamicElement(eleOpenCPERecord, createdDate);
						waitAndVerifyElement(cpeRecordLink);
						scrollToElement(cpeRecordLink);
						clickByJavascript(cpeRecordLink);
						cpeFound = true;
						setTimeOut(4000);
						LoggingInfo("Clicked on the CPE record");
						break;
					}
				}

				if (!cpeFound) {
					scrollToTopOfPage();
					scrollToElement(createdDateColumn);
					click(createdDateColumn);
					// Recursive call to search for docID again
					openCPETask(createdDate);
					setTimeOut(2000);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on record " + e.getMessage());
			Assert.fail("Failed to click on record " + e.getMessage());
		}
	}

	/**
	 * Function: Select List View from the list view dropdown
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void clickOnListView(String listName) {
		try {
			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, listName);
			setTimeOut(5000);

			String strList = "//lightning-base-combobox-formatted-text[@title=\"{0}\"]//parent::span";
			By eleList = getDynamicElement(strList, listName);
			clickByJavascript(eleList);
			setTimeOut(5000);
			LoggingInfo("Navigated to "+ listName );

			
			Log.info("Clicked on List View " + listName);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on List View " + listName + e.getMessage());
			Assert.fail("Failed to click on List View  " + listName + e.getMessage());
		}

	}
	
	/**Add commentMore actions
	 * Function: Navigate to CPE Record and capture the URL ID
	 * 
	 * @author SOnic
	 **/
	public By navigateAndCropURL() {
		String url = getCurrentPageURL();
		navigateToURL(url);
		
		String url1[] = url.split("/");
		String actualId = url1[6];
		String croppedId = actualId;
		croppedId = actualId.substring(0, 15);
		ID = "/" + croppedId;
		

		By cpeID = By.xpath("//a[@href='/" + croppedId + "']");
		System.out.print(cpeID);
		setTimeOut(2000);
		return cpeID;
		
	}

	/// Sonica

	/**
	 * Function: Verify and assigned CPE record to BV
	 * 
	 * @author SOnic
	 **/
	public String verifyAndAssignCPERecordByLink() {
		String recordCreatedDate = null;
		int retryCount = 0;
		int maxRetries = 3;

		while (retryCount < maxRetries) {
			waitForPageLoaded();
			setTimeOut(2000);

			try {
				JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
				if (methodToAvoidStaleElementReferenceErrorElement(cpeList)) {
					waitAndVerifyElement(cpeList);
					setTimeOut(1000);
					List<WebElement> listOptions = getWebDriver().findElements(cpeList);
					boolean idFound = false;
					int startIdx = 0;

					while (startIdx < listOptions.size()) {
						WebElement element = listOptions.get(startIdx);
						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								element);
						setTimeOut(1000);

						//////
						By createdDate = getDynamicElement(strCreatedDate, ID);
						waitAndVerifyElement(createdDate);
						waitForvisiblityOfElementLocated(createdDate);
						setTimeOut(2000);
						recordCreatedDate = getText(createdDate);
						setTimeOut(3000);

						By checkbox = getDynamicElement(checkboxes, ID);
						waitAndVerifyElement(checkbox);
						clickByJavascript(checkbox);
						setTimeOut(2000);
						LoggingInfo("Clicked on checkbox");
						idFound = true;

						waitAndVerifyElement(assignToMeButton);
						clickByJavascript(assignToMeButton);
						setTimeOut(2000);
						LoggingInfo("Clicked on Assign to me button");
						setTimeOut(2000);
						
						break;
					}

					if (idFound) {
						break;
					} else {
						LoggingInfo("cpeID not found: ");
						scrollToElement(createdDateColumn);
						clickByJavascript(createdDateColumn);
						setTimeOut(3000);
					}
			
				}

			} catch (Exception e) {
				e.printStackTrace();
				Log.error("Failed to verify document record " + e.getMessage());
				Assert.fail("Failed to verify document record " + e.getMessage());
			}

			retryCount++;
			if (retryCount < maxRetries) {
				LoggingInfo("Retrying.. " + (retryCount + 1));
			}
		}

		if (retryCount == maxRetries) {
			LoggingInfo("Could not find and assign account: ");
		}

		return recordCreatedDate;
	}
	
	private String extractRecordIdFromHref(String href) {
	    if (href == null || href.isEmpty()) return null;

	    Pattern pattern = Pattern.compile("/([a-zA-Z0-9]{15,18})$");
	    Matcher matcher = pattern.matcher(href);

	    if (matcher.find()) {
	        return matcher.group(1);
	    } else {
	        return null;
	    }
	}
	
	public String assignFirstCPERecord() {
	    String recordCreatedDate = null;
	    String extractedId = null;
	    int retryCount = 0;
	    int maxRetries = 5;

	    while (retryCount < maxRetries) {
	        try {
	            waitForPageLoaded();
	            setTimeOut(2000);  
	            if (methodToAvoidStaleElementReferenceErrorElement(cpeList)) {
	                waitAndVerifyElement(cpeList);
	                List<WebElement> listOptions = getWebDriver().findElements(cpeList);

	                if (!listOptions.isEmpty()) {
	                    WebElement firstElement = listOptions.get(0);

	                    ((JavascriptExecutor) getWebDriver()).executeScript(
	                        "arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });", 
	                        firstElement
	                    );

	                    String href = firstElement.getAttribute("href");
	                    extractedId = extractRecordIdFromHref(href); // Assuming this extracts ID from href

	                    LoggingInfo("First CPE ID found: " + extractedId);

	                    ((JavascriptExecutor) getWebDriver()).executeScript(
	                        "arguments[0].setAttribute('style', arguments[1]);", 
	                        firstElement, highlightStyle
	                    );

	                    // Get and log created date
	                    By createdDate = getDynamicElement(strCreatedDate, extractedId);
	                    waitAndVerifyElement(createdDate);
	                    waitForvisiblityOfElementLocated(createdDate);
	                    recordCreatedDate = getText(createdDate);

	                    // Select checkbox
	                    By checkbox = getDynamicElement(checkboxes, extractedId);
	                    waitAndVerifyElement(checkbox);
	                    clickByJavascript(checkbox);
	                    LoggingInfo("Clicked on checkbox");

	                    // Assign to me
	                    waitAndVerifyElement(assignToMeButton);
	                    clickByJavascript(assignToMeButton);
	                    LoggingInfo("Clicked on Assign to me button");

	                    break;  // Success, exit retry loop
	                } else {
	                    LoggingInfo("No CPE records found in current attempt.");
	                }
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	            Log.error("Failed to verify or assign first CPE record: " + e.getMessage());
	        }

	        retryCount++;
	        if (retryCount < maxRetries) {
	            LoggingInfo("Retrying... attempt " + (retryCount + 1));
	        }
	    }

	    if (recordCreatedDate == null) {
	        LoggingInfo("Could not find and assign any CPE record after " + maxRetries + " attempts.");
	        Assert.fail("Failed to verify and assign first available CPE record.");
	    }

	    return recordCreatedDate;
	}

	public void verifyCPETaskDisplayed(String createdDate) {
	    try {
	        waitForPageLoaded();
	        setTimeOut(8000);

	        if (methodToAvoidStaleElementReferenceErrorElement(dateList)) {
	            waitAndVerifyElement(dateList);
	            setTimeOut(5000);
	            List<WebElement> listOptions = getWebDriver().findElements(dateList);
	            boolean cpeFound = false;

	            for (WebElement element : listOptions) {
	                ((JavascriptExecutor) getWebDriver()).executeScript(
	                    "arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });", element
	                );
	                String cpeDate = element.getText().trim();
	                setTimeOut(1000);

	                if (cpeDate.equalsIgnoreCase(createdDate)) {
	                    ((JavascriptExecutor) getWebDriver()).executeScript(
	                        "arguments[0].setAttribute('style', arguments[1]);", element, highlightStyle
	                    );
	                    LoggingInfo("CPE task with created date found: " + createdDate);
	                    cpeFound = true;
	                    break;
	                }
	            }

	            if (!cpeFound) {
	                LoggingInfo("CPE task with created date not found in current view: " + createdDate);
	                scrollToElement(createdDateColumn);
	                clickByJavascript(createdDateColumn);
	                verifyCPETaskDisplayed(createdDate); 
	                setTimeOut(2000);
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        Log.error("Failed to verify CPE task with date " + createdDate + ". Error: " + e.getMessage());
	        Assert.fail("CPE task with created date not found: " + createdDate);
	    }
	}


}
