package com.sanofi.selenium.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.Markup;
import com.sanofi.selenium.core.BaseTest;
//import com.sanofi.selenium.utils.JiraCreateIssue;
import com.sanofi.selenium.utils.JiraServiceProvider;

public class Listeners extends BaseTest implements ITestListener {

	@Override
	public void onTestStart(ITestResult result) {
		result.getMethod().getDescription();
		extentTest.get().log(Status.INFO, "Testcase Execution started");

	}

	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		try {
			extentTest.get().log(Status.PASS, "Find below Passed scenario Snapshot",
					MediaEntityBuilder.createScreenCaptureFromPath(BaseTest.captureScreenShot("Passed")).build());
			System.out.println("Reached to Pass");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void infostep(String message) {
		extentTest.get().log(Status.INFO, message);

	}

	public static void ReportPassWithoutSnip(String message) {
		extentTest.get().log(Status.PASS, message);

	}

	/**
	 * Function: get Report log with screenshot
	 * 
	 * @author Dipali Yadav
	 * @param Log Message
	 * @return
	 */
	public static void ReportPass(String message) {
		try {
			extentTest.get().log(Status.PASS, message,
					MediaEntityBuilder.createScreenCaptureFromPath(BaseTest.captureScreenShot("Passed")).build());
		} catch (IOException e) {
			// TODO Auto-generated catch blockBelow
			e.printStackTrace();

		}
	}

	public static void ReportFail(String message) {
		try {
			extentTest.get().log(Status.FAIL, message,
					MediaEntityBuilder.createScreenCaptureFromPath(BaseTest.captureScreenShot("Failure")).build());
			System.out.println("Reached to fail");
		} catch (IOException e) {
			// TODO Auto-generated catch blockBelow
			e.printStackTrace();

		}

	}

	/**
	 * Function: get Report failed log with screenshot
	 * 
	 * @author Dipali Yadav
	 * @param
	 * @return
	 */
	@Override
	public void onTestFailure(ITestResult result) {

		try {
			extentTest.get().log(Status.FAIL, "Find below failed scenario Snapshot",
					MediaEntityBuilder.createScreenCaptureFromPath(BaseTest.captureScreenShot("Failure")).build());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		extentTest.get().log(Status.SKIP, "Test is skipped");

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestFailedButWithinSuccessPercentage(result);
	}

	@Override
	public void onTestFailedWithTimeout(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestFailedWithTimeout(result);
	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub

		ITestListener.super.onStart(context);
	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
	}

}
