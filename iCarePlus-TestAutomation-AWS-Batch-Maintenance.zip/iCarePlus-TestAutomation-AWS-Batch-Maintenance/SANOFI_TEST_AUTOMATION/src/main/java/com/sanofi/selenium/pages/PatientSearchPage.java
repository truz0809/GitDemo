package com.sanofi.selenium.pages;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class PatientSearchPage extends Utility_Function {
	public PatientSearchPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	String careProgProdErrorMsg = "Error: Product Indication is required";
	String patientSearchNoRecordsMsg = "No records to display";
	String zipCodeAlert = "Zip should contain only 5 digits";

	/************************* Elements *************************/

	public static By elePageTitle = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"omniscript-body\")]//*[text()=\"Patient Search\"]");
	public static By elePatientSearch = By.xpath("//*[text()='Search Patient']//parent::button");
	public static By eleBackToClassify = By.xpath("//*[text()='Back to Classify']");
	public static By eleNext = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()='Next' and @class='btnLabel']");
	public static By eleSubmit = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()='Submit']");
	public static By eleSelectPatientRadioBtn = By
			.xpath("//tr//*[contains(@class,\"slds-grid_align-spread\")]//*[@title=\"Select\"]");
	public static By eleDocumentLinkedText = By.xpath("//*[contains(text(), 'Document has been linked to patient: ')]");
	public static By eleCareProgramProduct = By.xpath(
			"//*[contains(text(),'Product Indication')]//ancestor::div[@class=\"slds-grid\"]//following-sibling::div//input");
	public static By patientSearchDOB = By.xpath("//input[@aria-label='Patient DOB']");
	public static By elePatientDOB = By
			.xpath("//*[text()='Patient DOB']//parent::div//following-sibling::div//input");
	public static By eleExistingPatient = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"Automation\")]//ancestor::tbody//span[contains(@class,\"slds-grid slds-grid_align-spread\")])[1]");

	public static By eleCareProgramDropdown = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()='Product Indication']//parent::label//parent:: div //following-sibling:: div // li //child::span[contains(@class,\"option-text\")]");

	public static By eleCareProgramError = By.xpath("//*[contains(text(), 'Error:')]");
	// public static By searchTable = By.xpath("//*[contains(@class,\"active
	// lafPageHost\")]//table[contains(@class,\"slds-table\")]");
	// public static By accountNameCellLocator = By.xpath("//td[@data-label='Account
	// Name']//lightning-base-formatted-text");

	public static By documentType = By.xpath(
			"//*[text()='Document Type Selected']//ancestor::div[@class='slds-grid']//following-sibling::input");
	public static By documentLinkText = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-text-block\")]//lightning-formatted-rich-text//p)[4]");
	public static By caseMangerAssignedMsg = By.xpath("//*[contains(@class,\"active lafPageHost\")]//p[text()=\"Case Manager has been assigned successfully\"]");
	public static By accountNameCellLocator = By
			.xpath("//*[@data-label='Account Name']//lightning-base-formatted-text");

	/************************* Dynamic Elements *************************/

	public static String selectBtn = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::td//preceding-sibling::th//child::button";
	public static String strTextBoxesInput = "//*[text()=\"{0}\"]//ancestor::div[@class=\"slds-grid\"]//following-sibling::div//input";
	public static String strErrorMsgPatientSearch = "//*[text()=\"{0}\"]";
	public static String strInputBoxXpath = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-form-container\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String selectPatient = "(//*[contains(@class,\"active lafPageHost\")]//*[(text()=\"{0}\")]//ancestor::tbody//button)[1]";

	public static By linkPatientDoc = By.xpath("(//*[contains(text(), 'Document has been linked to patient: ')]/a)[1]");
	By receivedDocsTable = By.xpath("//table[@aria-label='Received Documents' and @role='grid']");
	By receivedDocs = By.xpath(
			"//table[@aria-label='Received Documents' and @role='grid']//tr/th[@data-label='Name']//child::span/slot//slot");
	public static String strBtn = "//*[contains(@class,\"active lafPageHost\")]//button[@title=\"{0}\"]";
	public static String strDropDownBox = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"field_textarea\")]//*[@aria-label=\"{0}\"]//parent::div//button";
	public static String strDropDownBoxOptions = "//*[contains(@class,\"active lafPageHost\")]//div[@aria-label=\"{0}\"]//lightning-base-combobox-item";
	public static String strTableAvailable = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"Available\"]//parent::div//child::div//ul//li//span";
	public static String eleClearSelectionButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"label-stacked\")]//button[@title=\"Clear Selection\"]";
	public static String strClearBtn = "//div//*[text()=\"{0}\"]//ancestor::slot[@name='input']//*[@title='Clear Selection']";
	public static String elePrescriberFields = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::lightning-grouped-combobox//input";
	public static String strFields = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//a//span)[3]";
	public static By searchTable = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-table\")]");
	public static String elepageName = "//div[text()=\"{0}\"]//preceding-sibling::button";
	public static String strerror = "//*[text()=\"{0}\"]";

	/**
	 * Function: Verify Patient search page is present
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyPatientSearchPageTitle() {

		try {
			setTimeOut(10000);
			Log.info("Verify Patient search Page Present");
			waitAndVerifyElement(elePageTitle);
			LoggingInfo("Patient search Page is loaded");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Page load failed " + e.getMessage());
			Assert.fail("Page load has Failed" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function : Enter and Search the Existing Patient whose status is "Active" 
	 * 
	 * @author a.a.rajendra.chandak
	 * 
	 */
	public void SearchAndSelectActivePatientDetails() throws Exception 
	{
		try
		{
		String pFullName = "AutomationLillian Shirley Gonzalez";
		String FNamePatientSearch = "AutomationLillian";
		String LNamePatientSearch = "Gonzalez";
		String PatientEmailSearch = "lilliangonzalez@hotmail.com";
		String PatientDOBSearch = "09-20-1958";
		
		waitForPageLoaded();
		By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Patient First Name");
		By elepatientLNameInput = getDynamicElement(strTextBoxesInput, "Patient Last Name");

		waitAndVerifyElement(elepatientFNameInput);
		inputText(elepatientFNameInput, FNamePatientSearch);
		LoggingInfo("Enters First Name correctly");
		setTimeOut(2000);

		waitAndVerifyElement(elepatientLNameInput);
		setTimeOut(2000);
		inputText(elepatientLNameInput, LNamePatientSearch);
		LoggingInfo("Enters Last name correctly");
		setTimeOut(2000);

		// patientSearchDOB
		waitAndVerifyElement(patientSearchDOB);
		setTimeOut(2000);
		inputText(patientSearchDOB, PatientDOBSearch);
		LoggingInfo("Enters DOB correctly");
		setTimeOut(2000);

		// patientSearchEmail
		By elepatientEmailInput = getDynamicElement(strTextBoxesInput, "Patient Email");
		waitAndVerifyElement(elepatientEmailInput);
		setTimeOut(2000);
		inputText(elepatientEmailInput, PatientEmailSearch);
		LoggingInfo("Enters Email correctly");
		setTimeOut(2000);

		// Search existing Patient
		waitAndVerifyElement(elePatientSearch);
		click(elePatientSearch);
		setTimeOut(5000);
		LoggingInfo("Successfully clicks on patient search button");

		By elePatient = getDynamicElement(selectPatient, pFullName);
		click(elePatient);
		setTimeOut(2000);
		LoggingInfo("Selects existing Patient radio button");
		setTimeOut(2000);

		waitAndVerifyElement(eleNext);
		scrollToElement(eleNext);
		click(eleNext);
		setTimeOut(4000);
		refresh();
		setTimeOut(4000);
		}
	 	catch (Exception e) 
	 	{
			e.printStackTrace();
			Log.error("Failed to enter Patient search fields" + e.getMessage());
			Assert.fail("Patient Search fields verification failed " + e.getMessage());
		}	
	}


	// Anand P
	public void verifyAndClickExisitngPatient() {

		try {
			setTimeOut(2000);
			Log.info("Verify exsiting Patient");
			waitAndVerifyElement(eleExistingPatient);
			click(eleExistingPatient);
			LoggingInfo("Clicked on exisitng patient");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click " + e.getMessage());
			Assert.fail("Failed to click" + ". Error - " + e.getMessage());

		}

	}

	public void selectExistingPatient() throws Exception {
		String pName = "AutomationGeorge Richard Simmons";
		String FNamePatientSearch = "AutomationGeorge";
		String LNamePatientSearch = "Simmons";
		String PhonePatientSearch = "(488) 321-7095";
		String PatientEmailSearch = "Djsztfu@testmail.com";
		String PatientDOBSearch = "12-25-1952";
		String zipCode = "10743";

		waitForPageLoaded();
		By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Patient First Name");
		By elepatientLNameInput = getDynamicElement(strTextBoxesInput, "Patient Last Name");
		By elepatientZipCodeInput = getDynamicElement(strTextBoxesInput, "Patient Mailing Zip Code");

		waitAndVerifyElement(elepatientFNameInput);
		inputText(elepatientFNameInput, FNamePatientSearch);
		setTimeOut(2000);

		waitAndVerifyElement(elepatientLNameInput);
		setTimeOut(2000);
		inputText(elepatientLNameInput, LNamePatientSearch);
		setTimeOut(2000);

		// ------------
		By elepatientPhoneInput = getDynamicElement(strTextBoxesInput, "Patient Phone");
		waitAndVerifyElement(elepatientPhoneInput);
		scrollToElement(elepatientPhoneInput);
		click(elepatientPhoneInput);
		// getWebDriver().findElement(elepatientPhoneInput).clear();
		// inputText(elepatientPhoneInput,PhonePatientSearch);
		verifyAndInputTextWithActionClass(elepatientPhoneInput, PhonePatientSearch);
		setTimeOut(2000);

		// patientSearchDOB
		waitAndVerifyElement(patientSearchDOB);
		setTimeOut(2000);
		inputText(patientSearchDOB, PatientDOBSearch);
		setTimeOut(2000);

		waitAndVerifyElement(elepatientZipCodeInput);
		clearText(elepatientZipCodeInput);
		setTimeOut(2000);
		inputText(elepatientZipCodeInput, zipCode);
		setTimeOut(2000);

		// patientSearchEmail
		By elepatientEmailInput = getDynamicElement(strTextBoxesInput, "Patient Email");
		waitAndVerifyElement(elepatientEmailInput);
		setTimeOut(2000);
		inputText(elepatientEmailInput, PatientEmailSearch);
		setTimeOut(2000);
		LoggingInfo("All Patient details has been entered/verified correctly");

		// Search existing Patient
		waitAndVerifyElement(elePatientSearch);
		clickByJavascript(elePatientSearch);
		setTimeOut(5000);

		// select patient record
		By eleBtn = getDynamicElement(selectBtn, pName);
		waitAndVerifyElement(eleBtn);
		clickByJavascript(eleBtn);
		setTimeOut(2000);
		LoggingInfo("Selected existing patient correctly");

		// click on next button
		waitAndVerifyElement(eleNext);
		scrollToElement(eleNext);
		click(eleNext);
		setTimeOut(4000);
		refresh();

		/*waitAndVerifyElement(eleDocumentLinkedText);
		String documentLinkedText = getText(eleDocumentLinkedText);
		setTimeOut(2000);
		LoggingInfo("Verified document linked text " + documentLinkedText);*/
	}

	/**
	 * Function: Verify Patient search page fields
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyPatientSearchFields(String docType, String patientFN, String patientLN, String patientDocType,
			String patientMail, String patientPhone, String patientZip, String patientCareProgram, String patientDOB) {
		try {

			// Document Type Selected
			setTimeOut(5000);
			waitAndVerifyElement(documentType);
			verifyHardAssertInputFieldBox(documentType, docType, "Document Type Selected");

			// First name
			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Patient First Name");
			scrollToElement(elepatientFNameInput);
			waitAndVerifyElement(elepatientFNameInput);
			verifyHardAssertInputFieldBox(elepatientFNameInput, patientFN, "Patient First Name");

			// Last Name
			By elepatientLNameInput = getDynamicElement(strTextBoxesInput, "Patient Last Name");
			scrollToElement(elepatientLNameInput);
			waitAndVerifyElement(elepatientLNameInput);
			verifyHardAssertInputFieldBox(elepatientLNameInput, patientLN, "Patient Last Name");

			// DOB
			// By elepatientDOBInput = getDynamicElement(strTextBoxesInput, "Patient DOB");
			waitAndVerifyElement(elePatientDOB);
			verifyHardAssertCalendarDate(elePatientDOB, patientDOB, patientDOB);

			By elepatientPhoneInput = getDynamicElement(strTextBoxesInput, "Patient Phone");
			waitAndVerifyElement(elepatientPhoneInput);
			verifyHardAssertInputFieldBox(elepatientPhoneInput, patientPhone, patientPrimaryphone);

			By elepatientEmailInput = getDynamicElement(strTextBoxesInput, "Patient Email");
			waitAndVerifyElement(elepatientEmailInput);
			scrollToElement(elepatientEmailInput);
			verifyHardAssertInputFieldBox(elepatientEmailInput, patientMail, patientEmail);

			By elepatientZipCodeInput = getDynamicElement(strTextBoxesInput, "Patient Mailing Zip Code");
			waitAndVerifyElement(elepatientZipCodeInput);
			verifySoftAssertInputFieldBox(elepatientZipCodeInput, patientZip, zip);

			// careprogramproduct

			waitAndVerifyElement(eleCareProgramProduct);
			scrollToElement(eleCareProgramProduct);
			click(eleCareProgramProduct);
			selectItemFromList(eleCareProgramProduct, eleCareProgramDropdown, patientCareProgram,
					"Care program product");
			setTimeOut(2000);

			Assert.assertTrue(true, "Patient search fields verified successfully");

			LoggingInfo("Patient search fields has been verified correctly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Patient search fields" + e.getMessage());
			Assert.fail("Patient Search fields verification failed " + e.getMessage());
		}

	}

	/**
	 * Function: Verify Back to classify
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyBackToClassify() {
		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleBackToClassify);
			LoggingInfo("successfully verified Back to classify");
			Assert.assertTrue(true, "Successfully verified back to classify");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify back to classify " + e.getMessage());
			Assert.fail("Failed to verify back to classify" + e.getMessage());
		}

	}

	/**
	 * Function: Verify Patient search button
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyPatientSearchButton() {
		try {

			waitForPageLoaded();
			waitAndVerifyElement(elePatientSearch);
			clickByJavascript(elePatientSearch);
			setTimeOut(5000);
			LoggingInfo("Successfully verified patient search button");
			Assert.assertTrue(true, "Successfully verified patient search button");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify patient search button " + e.getMessage());
			Assert.fail("Failed to verify patient search button" + e.getMessage());
		}
	}

	/**
	 * Function: Verify Care Program Product Error Message
	 * 
	 * @author Sonica P
	 */
	public void verifyCareProgProductError() {
		try {

			setTimeOut(3000);
			waitForPageLoaded();
			waitAndVerifyElement(eleNext);
			scrollToElement(eleNext);
			click(eleNext);
			setTimeOut(2000);

			waitAndVerifyElement(eleCareProgramError);
			verifyTextPresent(eleCareProgramError, careProgProdErrorMsg);
			setTimeOut(2000);
			LoggingInfo("Successfully verified Care Program Product Error message when the field is not filled");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Care Program Product error message " + e.getMessage());
		}
	}

	/**
	 * Function: Click on Next button
	 * 
	 * @author Kavyashree MB
	 */
	public void clickOnNextButton() {
		try {
			waitForPageLoaded();
			waitAndVerifyElement(eleNext);
			scrollToElement(eleNext);
			click(eleNext);
			setTimeOut(5000);
			LoggingInfo("Successfully clicked on next button");
			Assert.assertTrue(true, "Successfully clicked on next button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on next button" + e.getMessage());
			Assert.fail("Failed to click on next button" + e.getMessage());
		}
	}

	public void verifyExistingPatient() {
		try {

			String zipCodeError = "157766";
			// String zipCode = "15776";
			String FNameWrongPatientSearch = "John";
			String LNameWrongPatientSearch = "Rustom";
			// String FNamePatientSearch = "Jimmy";
			// String LNamePatientSearch = "donotuse";
			// String PhonePatientSearch = "6746121109";
			// String PatientEmailSearch = "samarth@mail.com";
			// String PatientDOBSearch = "03-21-1980";
			String FNamePatientSearch = "AutomationChristopher";
			String LNamePatientSearch = "Green";
			String PhonePatientSearch = "(486)925-3833";
			String PatientEmailSearch = "christophergreen@gmail.com";
			String PatientDOBSearch = "01-27-1984";
			String zipCode = "16231";

			waitForPageLoaded();
			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Patient First Name");
			waitAndVerifyElement(elepatientFNameInput);
			inputText(elepatientFNameInput, FNameWrongPatientSearch);
			setTimeOut(2000);

			By elepatientLNameInput = getDynamicElement(strTextBoxesInput, "Patient Last Name");
			waitAndVerifyElement(elepatientLNameInput);
			inputText(elepatientLNameInput, LNameWrongPatientSearch);
			setTimeOut(2000);

			waitAndVerifyElement(elePatientSearch);
			click(elePatientSearch);
			setTimeOut(5000);

			By elePatientSearchNoRecords = getDynamicElement(strErrorMsgPatientSearch, "No records to display");
			waitAndVerifyElement(elePatientSearchNoRecords);
			verifyTextPresent(elePatientSearchNoRecords, patientSearchNoRecordsMsg);
			LoggingInfo("Succefully verified no record is displayed");

			By elepatientZipCodeInput = getDynamicElement(strTextBoxesInput, "Patient Mailing Zip Code");
			waitAndVerifyElement(elepatientZipCodeInput);
			setTimeOut(2000);
			inputText(elepatientZipCodeInput, zipCodeError);
			setTimeOut(2000);

			waitAndVerifyElement(eleNext);
			click(eleNext);
			setTimeOut(2000);

			By eleZipCodeError = getDynamicElement(strErrorMsgPatientSearch, "Zip should contain only 5 digits");
			waitAndVerifyElement(eleZipCodeError);
			setTimeOut(2000);
			verifyTextPresent(eleZipCodeError, zipCodeAlert);
			setTimeOut(2000);

			waitAndVerifyElement(elepatientZipCodeInput);
			clearText(elepatientZipCodeInput);
			setTimeOut(2000);
			inputText(elepatientZipCodeInput, zipCode);
			setTimeOut(2000);
			setTimeOut(2000);

			waitAndVerifyElement(elepatientFNameInput);
			inputText(elepatientFNameInput, FNamePatientSearch);
			setTimeOut(2000);

			waitAndVerifyElement(elepatientLNameInput);
			setTimeOut(2000);
			inputText(elepatientLNameInput, LNamePatientSearch);
			setTimeOut(2000);

			By elepatientPhoneInput = getDynamicElement(strTextBoxesInput, "Patient Phone");
			waitAndVerifyElement(elepatientPhoneInput);
			scrollToElement(elepatientPhoneInput);
			click(elepatientPhoneInput);
			getWebDriver().findElement(elepatientPhoneInput).clear();
			setTimeOut(2000);
			scrollToElement(elepatientPhoneInput);
			click(elepatientPhoneInput);
			Robot robot = new Robot();
			for (int i = 0; i < PhonePatientSearch.length(); i++) {
				char c = PhonePatientSearch.charAt(i);
				int keyCode = KeyEvent.getExtendedKeyCodeForChar(c);
				if (Character.isDigit(c)) {
					robot.keyPress(keyCode);
					robot.keyRelease(keyCode);
					Thread.sleep(50);
				}
			}

			LoggingInfo("Enters Phone correctly");
			setTimeOut(2000);

			// patientSearchDOB
			waitAndVerifyElement(patientSearchDOB);
			setTimeOut(2000);
			inputText(patientSearchDOB, PatientDOBSearch);
			setTimeOut(2000);

			// patientSearchEmail
			By elepatientEmailInput = getDynamicElement(strTextBoxesInput, "Patient Email");
			waitAndVerifyElement(elepatientEmailInput);
			setTimeOut(2000);
			inputText(elepatientEmailInput, PatientEmailSearch);
			setTimeOut(2000);
			LoggingInfo("All Patient details has been entered/verified correctly");

			// Search existing Patient
			waitAndVerifyElement(elePatientSearch);
			clickByJavascript(elePatientSearch);
			setTimeOut(5000);

			clickByJavascript(eleSelectPatientRadioBtn);
			setTimeOut(2000);

			LoggingInfo("Existing patient selected successfully");

			waitAndVerifyElement(eleNext);
			click(eleNext);
			setTimeOut(4000);

			waitAndVerifyElement(eleDocumentLinkedText);
			String documentLinkedText = getText(eleDocumentLinkedText);
			setTimeOut(2000);
			LoggingInfo("Verifies document linked text " + documentLinkedText);

			click(eleNext);
			setTimeOut(4000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on patient search button " + e.getMessage());
			Assert.fail("Failed to click on patient search button" + e.getMessage());
		}
	}

	// Anand P
	public void verifyAndClickBackToClassify() {
		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleBackToClassify);
			scrollToElement(eleBackToClassify);
			LoggingInfo("successfully verified Back to classify");
			clickByJavascript(eleBackToClassify);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify back to classify " + e.getMessage());
			Assert.fail("Failed to verify back to classify" + e.getMessage());
		}

	}

	// Anand P
	public void enterCareProgram(String patientCareProgram) {
		try {
			waitForPageLoaded();
			waitAndVerifyElement(eleCareProgramProduct);
			scrollToElement(eleCareProgramProduct);
			click(eleCareProgramProduct);
			selectItemFromList(eleCareProgramProduct, eleCareProgramDropdown, patientCareProgram,
					"Care program product");
			setTimeOut(2000);

			searchPatientButton();

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to enter Care Program name" + ". Error - " + e.getMessage());

		}
	}

	public void enterPatientSearchFields(String docType, String patientFN, String patientLN, String patientDocType,
			String patientMail, String patientPhone, String patientZip, String patientCareProgram, String patientDOB) {
		try {

			// Document Type Selected
			setTimeOut(5000);
			waitAndVerifyElement(documentType);
			verifyHardAssertInputFieldBox(documentType, docType, "Document Type Selected");

			// careprogramproduct

			waitAndVerifyElement(eleCareProgramProduct);
			click(eleCareProgramProduct);
			selectItemFromList(eleCareProgramProduct, eleCareProgramDropdown, patientCareProgram,
					"Care program product");
			setTimeOut(2000);

			// First name
			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Patient First Name");
			waitAndVerifyElement(elepatientFNameInput);
			verifyAndEnterInfoInputField(elepatientFNameInput, patientFN, "Patient First Name");

			// Last Name
			By elepatientLNameInput = getDynamicElement(strTextBoxesInput, "Patient Last Name");
			waitAndVerifyElement(elepatientLNameInput);
			verifyAndEnterInfoInputField(elepatientLNameInput, patientLN, "Patient Last Name");

			// DOB
			// By elepatientDOBInput = getDynamicElement(strTextBoxesInput, "Patient DOB");
			waitAndVerifyElement(elePatientDOB);
			verifyAndEnterInfoInputField(elePatientDOB, patientDOB, patientDOB);

			// Phone
			By phoneElementTextBox = getDynamicElement(strTextBoxesInput, "Patient Phone");
			waitAndVerifyElement(phoneElementTextBox);
			verifyAndInputTextWithActionClass(phoneElementTextBox, patientPhone);

			By elepatientEmailInput = getDynamicElement(strTextBoxesInput, "Patient Email");
			waitAndVerifyElement(elepatientEmailInput);
			verifyAndEnterInfoInputField(elepatientEmailInput, patientMail, patientEmail);

			By elepatientZipCodeInput = getDynamicElement(strTextBoxesInput, "Patient Mailing Zip Code");
			waitAndVerifyElement(elepatientZipCodeInput);
			scrollToElement(elepatientZipCodeInput);
			verifyAndEnterInfoInputField(elepatientZipCodeInput, patientZip, zip);

			Assert.assertTrue(true, "Patient search fields verified successfully");

			LoggingInfo("All Patient details has been entered/verified correctly");
			searchPatientButton();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter Patient search fields" + e.getMessage());
			Assert.fail("Patient Search fields verification failed " + e.getMessage());
		}

	}

	public void searchExistingPatient(String fName, String lName, String dob, String phone, String email,
			String zipCodeP) {
		try {
			waitForPageLoaded();
			// Patient First Name
			By elepatientFNameInput = getDynamicElement(strInputBoxXpath, "Patient First Name");
			waitAndVerifyElement(elepatientFNameInput);
			scrollToElement(elepatientFNameInput);
			clearText(elepatientFNameInput);
			inputText(elepatientFNameInput, fName);

			// Last name
			By elepatientLNameInput = getDynamicElement(strInputBoxXpath, "Patient Last Name");
			waitAndVerifyElement(elepatientLNameInput);
			scrollToElement(elepatientLNameInput);
			clearText(elepatientLNameInput);
			inputText(elepatientLNameInput, lName);

			// Patient DOB
			waitAndVerifyElement(elePatientDOB);
			clearText(elePatientDOB);
			inputText(elePatientDOB, dob);

			// Patient Phone
			By elepatientPhone = getDynamicElement(strInputBoxXpath, "Patient Phone");
			waitAndVerifyElement(elepatientPhone);
			scrollToElement(elepatientPhone);
			clearText(elepatientPhone);
			scrollToElement(elepatientPhone);
			click(elepatientPhone);

			sendKeysWithRobotClass(phone);

			// Patient Email
			By elepatientemail = getDynamicElement(strInputBoxXpath, "Patient Email");
			waitAndVerifyElement(elepatientemail);
			scrollToElement(elepatientemail);
			clearText(elepatientemail);
			inputText(elepatientemail, email);

			// Patient Email
			By elepatientZip = getDynamicElement(strInputBoxXpath, "Patient Mailing Zip Code");
			waitAndVerifyElement(elepatientZip);
			scrollToElement(elepatientZip);
			clearText(elepatientZip);
			inputText(elepatientZip, zipCodeP);

			// Search existing Patient
			waitAndVerifyElement(elePatientSearch);
			clickByJavascript(elePatientSearch);
			setTimeOut(7000);
			clickByJavascript(elePatientSearch);
			LoggingInfo("Successfully clicks on patient search button");

			clickByJavascript(eleSelectPatientRadioBtn);
			setTimeOut(2000);
			LoggingInfo("Selects existing Patient radio button");
			setTimeOut(2000);

			waitAndVerifyElement(eleNext);
			scrollToElement(eleNext);
			click(eleNext);
			setTimeOut(4000);

			// waitAndVerifyElement(eleDocumentLinkedText);
			// String documentLinkedText = getText(eleDocumentLinkedText);
			// setTimeOut(2000);
			// LoggingInfo("Verifies document linked text " + documentLinkedText);

			setTimeOut(4000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter Patient search fields" + e.getMessage());
			Assert.fail("Patient Search fields verification failed " + e.getMessage());
		}
	}

	public void verifyReceivedDocumentInRelatedTab(String expectedDocName) throws Exception {
		try {
			setTimeOut(3000);
			scrollToElement(receivedDocsTable);
			careProgram.clickOnViewAll("Received Documents");

			setTimeOut(5000);
			boolean isRecordFound = false;
			List<WebElement> receivedDocsList = getWebDriver().findElements(receivedDocs);
			System.out.println(receivedDocsList.size());
			if (receivedDocsList.isEmpty()) {
				System.out.println("No records found in table");
			} else {
				for (WebElement receivedDoc : receivedDocsList) {
					String receivedDocName = receivedDoc.getText();
					if (receivedDocName.contains(expectedDocName)) {
						System.out.println("Found the record: " + receivedDocName);
						isRecordFound = true;
						break;
					}
				}
				if (!isRecordFound) {
					Log.info(expectedDocName + " Not of found");
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Record not Found in Received Documents list" + e.getMessage());
			Assert.fail("Record not Found in Received Documents list" + e.getMessage());
		}

	}

	public void selectExistingPatientWithFaxNumber() throws Exception {
		String FNamePatientSearch = "AutomationClaire Lucy";
		String LNamePatientSearch = "Davis";
		String PhonePatientSearch = "3985147562";
		String PatientEmailSearch = "clairedavis@hotmail.com";
		String PatientDOBSearch = "12-23-1998";
		String zipCode = "83416";

		waitForPageLoaded();
		By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Patient First Name");
		By elepatientLNameInput = getDynamicElement(strTextBoxesInput, "Patient Last Name");
		By elepatientZipCodeInput = getDynamicElement(strTextBoxesInput, "Patient Mailing Zip Code");

		waitAndVerifyElement(elepatientZipCodeInput);
		clearText(elepatientZipCodeInput);
		setTimeOut(2000);
		inputText(elepatientZipCodeInput, zipCode);
		setTimeOut(2000);

		waitAndVerifyElement(elepatientFNameInput);
		inputText(elepatientFNameInput, FNamePatientSearch);
		setTimeOut(2000);

		waitAndVerifyElement(elepatientLNameInput);
		setTimeOut(2000);
		inputText(elepatientLNameInput, LNamePatientSearch);
		setTimeOut(2000);
		LoggingInfo("Entered first name and last name correctly");

		// ------------
		By elepatientPhoneInput = getDynamicElement(strTextBoxesInput, "Patient Phone");
		waitAndVerifyElement(elepatientPhoneInput);
		scrollToElement(elepatientPhoneInput);
		click(elepatientPhoneInput);
		getWebDriver().findElement(elepatientPhoneInput).clear();
		setTimeOut(2000);
		scrollToElement(elepatientPhoneInput);
		click(elepatientPhoneInput);
		Robot robot = new Robot();
		for (int i = 0; i < PhonePatientSearch.length(); i++) {
			char c = PhonePatientSearch.charAt(i);
			int keyCode = KeyEvent.getExtendedKeyCodeForChar(c);
			if (Character.isDigit(c)) {
				robot.keyPress(keyCode);
				robot.keyRelease(keyCode);
				Thread.sleep(50);
			}
		}

		// patientSearchDOB
		waitAndVerifyElement(patientSearchDOB);
		setTimeOut(2000);
		inputText(patientSearchDOB, PatientDOBSearch);
		setTimeOut(2000);

		// patientSearchEmail
		By elepatientEmailInput = getDynamicElement(strTextBoxesInput, "Patient Email");
		waitAndVerifyElement(elepatientEmailInput);
		setTimeOut(2000);
		inputText(elepatientEmailInput, PatientEmailSearch);
		setTimeOut(2000);

		LoggingInfo("Entered email and date of birth correctly");

		// Search existing Patient
		waitAndVerifyElement(elePatientSearch);
		clickByJavascript(elePatientSearch);
		setTimeOut(5000);

		clickByJavascript(eleSelectPatientRadioBtn);
		setTimeOut(2000);
		LoggingInfo("Selects existing Patient radio button");
		setTimeOut(2000);

		waitAndVerifyElement(eleNext);
		scrollToElement(eleNext);
		click(eleNext);
		setTimeOut(4000);

		// waitAndVerifyElement(eleDocumentLinkedText);
		// String documentLinkedText = getText(eleDocumentLinkedText);
		// setTimeOut(2000);
		// LoggingInfo("Verifies document linked text " + documentLinkedText);
		//
		// // click on Linked Doc text
		// waitAndVerifyElement(linkPatientDoc);
		// scrollToElement(linkPatientDoc);
		// clickByJavascript(linkPatientDoc);
		// LoggingInfo("Clicked on Linked Document link" + documentLinkedText);
	}

	public void highlightElement(WebElement strElement) {
		// Create object of a JavascriptExecutor interface
		JavascriptExecutor executor = (JavascriptExecutor) getWebDriver();
		executor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');",
				strElement);

	}

	public void updateStatusField(String status) throws Exception {

		By statusDropDown = getDynamicElement(strDropDownBox, "Status");
		waitAndVerifyElement(statusDropDown);
		scrollToElement(statusDropDown);
		click(statusDropDown);
		setTimeOut(1000);
		By statusDropDownList = getDynamicElement(strDropDownBoxOptions, "Status");
		waitAndVerifyElement(statusDropDownList);

		List<WebElement> statusList = getWebDriver().findElements(statusDropDownList);
		for (WebElement li : statusList) {
			if (li.getText().contains(status)) {
				scrollToWebElement(li);
				li.click();
				break;
			}
		}
		LoggingInfo("Selected Status as- " + status);
		setTimeOut(2000);
	}

	public void fieldEditButton() throws Exception {
		try {
			By ParentRecDocEditBtn = getDynamicElement(strBtn, "Edit PSQA Review Outcome");
			scrollToElement(ParentRecDocEditBtn);
			click(ParentRecDocEditBtn);
			setTimeOut(3000);
			LoggingInfo("Clicked on Edit button");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Edit button " + e.getMessage());
			Assert.fail("Failed to click on Edit button " + e.getMessage());

		}
	}

	public void updateSourceChannelField(String channel) throws Exception {

		By statusDropDown = getDynamicElement(strDropDownBox, "Source Channel");
		waitAndVerifyElement(statusDropDown);
		scrollToElement(statusDropDown);
		click(statusDropDown);
		setTimeOut(1000);
		By statusDropDownList = getDynamicElement(strDropDownBoxOptions, "Source Channel");
		waitAndVerifyElement(statusDropDownList);

		List<WebElement> statusList = getWebDriver().findElements(statusDropDownList);
		for (WebElement li : statusList) {
			if (li.getText().contains(channel)) {
				scrollToWebElement(li);
				li.click();
				break;
			}
		}
		LoggingInfo("Selected Source Channel as- " + channel);
		setTimeOut(2000);
	}

	public void selectReviewOutcome() throws Exception {
		String[] PSQAReviewOutcomeList = { "Enrollement Form", "Missing Information", "Adverse Event",
				"Product Technical Complaint", "Consent Management", "Rx Request", "PAP", "Supplemental Document",
				"Other" };

		// Create a Random object
		Random random = new Random();
		int randomIndex = random.nextInt(PSQAReviewOutcomeList.length);
		String randomOutcome = PSQAReviewOutcomeList[randomIndex];
		System.out.println("Randomly selected outcome: " + randomOutcome);

		List<WebElement> availableTable = getWebDriver().findElements(By.xpath(strTableAvailable));
		for (WebElement option : availableTable) {
			if (option.getText().contains(randomOutcome)) {
				scrollToWebElement(option);
				option.click();
				By MoveToChosenBtn = By.xpath("//button[@title='Move to Chosen']");
				click(MoveToChosenBtn);
				break;
			}

		}
		LoggingInfo("Selected PSQA Review Outcome as- " + randomOutcome);
		// highLightElement(Done);

	}

	/**
	 * Function: Clear existing patient search fields
	 *
	 * 
	 * @author: Trupti Zure
	 * 
	 *          public void clearExistingFields() { try { String[] fieldLabels = {
	 *          "Patient First Name", "Patient Last Name", "Patient Phone", "Patient
	 *          Email", "Patient Mailing Zip Code" };
	 * 
	 *          for (String label : fieldLabels) { By inputBox =
	 *          getDynamicElement(strTextBoxesInput, label);
	 *          scrollToElement(inputBox); clearInputFieldText(inputBox); }
	 * 
	 *          // Patient DOB clearInputFieldText(patientSearchDOB);
	 * 
	 *          } catch (Exception e) { e.printStackTrace(); String errorMsg =
	 *          "Failed to clear one or more input fields: " + e.getMessage();
	 *          Log.error(errorMsg); Assert.fail(errorMsg); } }
	 */

	/**
	 * Function: Verify Fuzzy Logic for Existing Patient
	 * 
	 * @author: Trupti Zure
	 * 
	 *          public void verifyFuzzyLogicExistingPatient(String
	 *          FNamePatientSearch, String LNamePatientSearch, String
	 *          PatientEmailSearch, String Phone, String zipCode, String
	 *          PatientDOBSearch) { try {
	 * 
	 *          By elepatientFNameInput = getDynamicElement(strTextBoxesInput,
	 *          "Patient First Name"); By elepatientLNameInput =
	 *          getDynamicElement(strTextBoxesInput, "Patient Last Name"); By
	 *          elepatientZipCodeInput = getDynamicElement(strTextBoxesInput,
	 *          "Patient Mailing Zip Code"); By elepatientEmailInput =
	 *          getDynamicElement(strTextBoxesInput, "Patient Email"); By
	 *          elepatientPhoneInput = getDynamicElement(strTextBoxesInput, "Patient
	 *          Phone");
	 * 
	 *          if (FNamePatientSearch != null && !FNamePatientSearch.isEmpty()) {
	 *          waitAndVerifyElement(elepatientFNameInput);
	 *          inputText(elepatientFNameInput, FNamePatientSearch);
	 *          setTimeOut(2000);
	 * 
	 *          if (LNamePatientSearch != null && !LNamePatientSearch.isEmpty()) {
	 *          waitAndVerifyElement(elepatientLNameInput);
	 *          inputText(elepatientLNameInput, LNamePatientSearch);
	 *          setTimeOut(2000);
	 * 
	 *          } // patientSearchDOB if (PatientDOBSearch != null &&
	 *          !PatientDOBSearch.isEmpty()) {
	 * 
	 *          waitAndVerifyElement(patientSearchDOB); setTimeOut(2000);
	 *          verifyAndInputTextWithActionClass(patientSearchDOB,
	 *          PatientDOBSearch); setTimeOut(2000); } if (Phone != null &&
	 *          !Phone.isEmpty()) { waitAndVerifyElement(elepatientPhoneInput);
	 *          verifyAndInputTextWithActionClass(elepatientPhoneInput, Phone);
	 *          setTimeOut(2000); } // patientSearchEmail if (PatientEmailSearch !=
	 *          null && !PatientEmailSearch.isEmpty()) {
	 *          waitAndVerifyElement(elepatientEmailInput); setTimeOut(2000);
	 *          inputText(elepatientEmailInput, PatientEmailSearch);
	 *          setTimeOut(2000); } if (zipCode != null && !zipCode.isEmpty()) {
	 *          waitAndVerifyElement(elepatientZipCodeInput);
	 *          inputText(elepatientZipCodeInput, zipCode); setTimeOut(2000); }
	 * 
	 *          searchPatientButton(); } } catch (Exception e) {
	 *          e.printStackTrace(); Log.error("Failed to verify the details" +
	 *          e.getMessage()); Assert.fail("Failed to verify the details" +
	 *          e.getMessage()); }
	 * 
	 *          }
	 */

	/**
	 * Function: validate search result
	 * 
	 * @author Trupti
	 * 
	 *         public void validateSearchResult(String expectedAccountName) { try {
	 *         waitAndVerifyElement(searchTable); String actualAccountName =
	 *         getText(accountNameCellLocator); Log.info("Expected Account Name: " +
	 *         expectedAccountName); Log.info("Actual Account Name: " +
	 *         actualAccountName); Assert.assertEquals(actualAccountName,
	 *         expectedAccountName, "Account name match!"); LoggingInfo("Account
	 *         name validated successfully.");
	 * 
	 *         } catch (Exception e) { e.printStackTrace(); Log.error("Failed to
	 *         validate account name: " + e.getMessage()); Assert.fail("Error during
	 *         account name validation: " + e.getMessage()); } }
	 */

	/**
	 * Function: click on Search Patient Button
	 * 
	 * @author Anand Pawar
	 * 
	 * 
	 * 
	 *         public void searchPatientButton() { try {
	 *         waitAndVerifyElement(elePatientSearch);
	 *         scrollToElement(elePatientSearch); click(elePatientSearch);
	 *         setTimeOut(5000); LoggingInfo("Successfully clicks on patient search
	 *         button"); setTimeOut(2000); } catch (Exception e) {
	 *         e.printStackTrace(); Assert.fail("Failed to enter Care Program name"
	 *         + ". Error - " + e.getMessage());
	 * 
	 *         } }
	 */

	public String updatePatientRecDoc(String patientFirstName) throws Exception {
		By elePatientDoc = By.xpath("//div//*[text()='Parent Received Document']//../child::div//child::input");
		String fieldValue = getAttributeValue(elePatientDoc, "data-value");

		if (fieldValue != null) {
			By parentNameFieldClearBtn = getDynamicElement(eleClearSelectionButton, "Parent Received Document");
			scrollToElement(parentNameFieldClearBtn);
			click(parentNameFieldClearBtn);
			setTimeOut(2000);
		}

		By ParentNameField = getDynamicElement(elePrescriberFields, "Parent Received Document");
		scrollToElement(ParentNameField);
		inputText(ParentNameField, "Automation");
		setTimeOut(5000);

		String strList = "//lightning-base-combobox-formatted-text[contains(@title,'Automation')]//parent::span";

		List<WebElement> list = getWebDriver().findElements(By.xpath(strList));
		String parentDocName = null;
		for (WebElement li : list) {
			if (li.getText().contains("Automation") && !li.getText().contains(patientFirstName)) {
				scrollToWebElement(li);
				parentDocName = li.getText();
				li.click();
				break;
			}
		}
		LoggingInfo("Parent Received Document updated as- " + parentDocName);
		return parentDocName;
	}

	public void validateFieldsUpdated(String field, String textToValidate) {
		try {
			By eleField = getDynamicElement(strFields, field);
			String fieldText = getText(eleField);
			if (fieldText.contains(textToValidate)) {
				LoggingInfo("Field - " + field + " is updated with value - " + textToValidate);
			} else {
				Log.error("Field - " + field + " is not updated with value - " + textToValidate);
				Assert.fail("Field - " + field + " is not updated with value - " + textToValidate);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Fields text " + e.getMessage());
			Assert.fail("Failed to validate Fields text " + e.getMessage());

		}

	}

	public String updateCPE() throws Exception {
		By eleCPEName = By.xpath("//div//*[text()='Care Program Enrollee']//../child::div//child::input");
		String cpeName = getAttributeValue(eleCPEName, "data-value");
		if (cpeName != null) {
			By parentNameFieldClearBtn = getDynamicElement(eleClearSelectionButton, "Care Program Enrollee");
			scrollToElement(parentNameFieldClearBtn);
			click(parentNameFieldClearBtn);
			setTimeOut(2000);
		}
		By ParentNameField = getDynamicElement(elePrescriberFields, "Care Program Enrollee");
		scrollToElement(ParentNameField);
		inputText(ParentNameField, "Automation");
		setTimeOut(2000);

		String strList = "//lightning-base-combobox-formatted-text[contains(@title,'Automation')]//parent::span";

		List<WebElement> list = getWebDriver().findElements(By.xpath(strList));
		String CPEName = null;
		for (WebElement li : list) {
			if (li.getText().contains("Automation")) {
				scrollToWebElement(li);
				CPEName = li.getText();
				li.click();
				break;
			}
		}
		LoggingInfo("Care Program Enrollee updated as- " + CPEName);
		return CPEName;
	}

	public void validatePSQAReviewOutcomeListValues() throws Exception {
		String strPSQAOutcome = "//*[contains(text(),'PSQA Review Outcome')]//following::ul/li//span[@class='slds-truncate']";
		String[] PSQAReviewOutcomeList = { "Enrollement Form", "Missing Information", "Adverse Event",
				"Product Technical Complaint", "Consent Management", "Rx Request", "PAP", "Supplemental Document",
				"Other" };

		List<WebElement> PSQAReviewOutcomes = getWebDriver().findElements(By.xpath(strPSQAOutcome));

		for (WebElement outcome : PSQAReviewOutcomes) {
			for (String outcomeOption : PSQAReviewOutcomeList) {
				if (outcome.getText().contains(outcomeOption)) {
					System.out.println("PSQA Review Outcome List Value is present: " + outcomeOption);
					scrollToWebElement(outcome);
					highlightElement(outcome);
					break;
				}
			}
		}
		LoggingInfo("PSQA Review Outcome List Values are validated successfully");
	}

	public void errorValidation() throws Exception {
		String strChosenTable = "//span[text()='Chosen']//parent::div//child::div//ul//li";
		By MoveToAvailableBtn = By.xpath("//button[@title='Move to Available']");

		List<WebElement> chosenTable = getWebDriver().findElements(By.xpath(strChosenTable));
		if (chosenTable.size() > 0) {
			for (WebElement option : chosenTable) {
				option.click();
				setTimeOut(2000);
				clickByJavascript(MoveToAvailableBtn);
			}
		}

		updateStatusField("Completed");

		clickOnButton("Save");
		String errormsg = "The field PSQA Review Outcome must be populated when Completed value is selected in Status field.";

		errorMessageValidation(errormsg);
		LoggingInfo("Error message - " + errormsg);
	}

	// Anand P
	public void selectExistingPatient2(String patientCareProgram) throws Exception {

		waitAndVerifyElement(eleCareProgramProduct);
		click(eleCareProgramProduct);
		selectItemFromList(eleCareProgramProduct, eleCareProgramDropdown, patientCareProgram, "Care program product");
		setTimeOut(2000);

		String pFullName = "AutomationChristine Adam Jenkins";
		String FNamePatientSearch = "AutomationChristine";
		String LNamePatientSearch = "Jenkins";
		String PhonePatientSearch = "4423753461";
		String PatientEmailSearch = "christinejenkins@gmail.com";
		String PatientDOBSearch = "04-11-1963";
		String zipCode = "13636";

		waitForPageLoaded();
		By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Patient First Name");
		By elepatientLNameInput = getDynamicElement(strTextBoxesInput, "Patient Last Name");
		By elepatientZipCodeInput = getDynamicElement(strTextBoxesInput, "Patient Mailing Zip Code");

		waitAndVerifyElement(elepatientZipCodeInput);
		clearText(elepatientZipCodeInput);
		setTimeOut(2000);
		inputText(elepatientZipCodeInput, zipCode);
		setTimeOut(2000);
		LoggingInfo("Enters zip code correctly");
		setTimeOut(2000);

		waitAndVerifyElement(elepatientFNameInput);
		inputText(elepatientFNameInput, FNamePatientSearch);
		LoggingInfo("Enters First Name correctly");
		setTimeOut(2000);

		waitAndVerifyElement(elepatientLNameInput);
		setTimeOut(2000);
		inputText(elepatientLNameInput, LNamePatientSearch);
		LoggingInfo("Enters Last name correctly");
		setTimeOut(2000);

		// ------------
		By elepatientPhoneInput = getDynamicElement(strTextBoxesInput, "Patient Phone");
		waitAndVerifyElement(elepatientPhoneInput);
		verifyAndInputTextWithActionClass(elepatientPhoneInput, PhonePatientSearch);

		
//		scrollToElement(elepatientPhoneInput);
//		click(elepatientPhoneInput);
//		getWebDriver().findElement(elepatientPhoneInput).clear();
//		setTimeOut(2000);
//		scrollToElement(elepatientPhoneInput);
//		click(elepatientPhoneInput);
//		Robot robot = new Robot();
//		for (int i = 0; i < PhonePatientSearch.length(); i++) {
//			char c = PhonePatientSearch.charAt(i);
//			int keyCode = KeyEvent.getExtendedKeyCodeForChar(c);
//			if (Character.isDigit(c)) {
//				robot.keyPress(keyCode);
//				robot.keyRelease(keyCode);
//				Thread.sleep(50);
//			}
//		}

		// patientSearchDOB
		waitAndVerifyElement(patientSearchDOB);
		setTimeOut(2000);
		inputText(patientSearchDOB, PatientDOBSearch);
		LoggingInfo("Enters DOB correctly");
		setTimeOut(2000);

		// patientSearchEmail
		By elepatientEmailInput = getDynamicElement(strTextBoxesInput, "Patient Email");
		waitAndVerifyElement(elepatientEmailInput);
		setTimeOut(2000);
		inputText(elepatientEmailInput, PatientEmailSearch);
		LoggingInfo("Enters Email correctly");
		setTimeOut(2000);

		// Search existing Patient
		waitAndVerifyElement(elePatientSearch);
		click(elePatientSearch);
		setTimeOut(5000);
		LoggingInfo("Successfully clicks on patient search button");

		By elePatient = getDynamicElement(selectPatient, pFullName);
		click(elePatient);
		setTimeOut(2000);
		LoggingInfo("Selects existing Patient radio button");
		setTimeOut(2000);

		waitAndVerifyElement(eleNext);
		scrollToElement(eleNext);
		click(eleNext);
		setTimeOut(4000);

		refresh();

		waitAndVerifyElement(eleDocumentLinkedText);
		String documentLinkedText = getText(eleDocumentLinkedText);
		setTimeOut(2000);
		LoggingInfo("Verified document linked text " + documentLinkedText);

	}

	/**
	 * Function:Verify document linked test
	 *
	 * @author Trupti
	 */
	public void verifyDocLinkedText(String patientName) {
		try {
			WebElement spanElement = getWebDriver().findElement(By.xpath(
					"(//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-text-block\")]//lightning-formatted-rich-text//p)[4]"));
			JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
			String docLinkText = (String) js.executeScript("return arguments[0].textContent;", spanElement);
			String expectedText = "Document has been linked to patient: " + patientName;
			Assert.assertEquals(docLinkText, expectedText);
			LoggingInfo("Document has been linked to patient: " + patientName + "is verified");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate document linked text " + e.getMessage());
			Assert.fail("Failed to validate document linked text " + e.getMessage());

		}

	}

	/**
	 * Function:Verify DMW enrollment text message
	 *
	 * @author Trupti
	 */

	public void verifyDMWEnrollmentText(String patientName) {
		try {
			WebElement spanElement = getWebDriver().findElement(
					By.xpath("//*[contains(@class,\"active lafPageHost\")]//span[contains(@class,\"ui-provider\")]"));
			JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
			String DmwText = (String) js.executeScript("return arguments[0].textContent;", spanElement);
			String expectedText = "Patient " + patientName + " is already enrolled in DMW.";
			Assert.assertEquals(DmwText, expectedText);
			LoggingInfo("Patient " + patientName + " is already enrolled in DMW is verified");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate enrollment text " + e.getMessage());
			Assert.fail("Failed to validate enrollment text " + e.getMessage());

		}

	}

	/**
	 * Function:Search existing patient without document linked test
	 *
	 * @author Trupti
	 */
	public void searchExistingPatient2(String fName, String lName, String dob, String phone, String email,
			String zipCode) {
		try {
			waitForPageLoaded();
			// Patient First Name
			By elepatientFNameInput = getDynamicElement(strInputBoxXpath, "Patient First Name");
			waitAndVerifyElement(elepatientFNameInput);
			scrollToElement(elepatientFNameInput);
			clearText(elepatientFNameInput);
			inputText(elepatientFNameInput, fName);

			// Last name
			By elepatientLNameInput = getDynamicElement(strInputBoxXpath, "Patient Last Name");
			waitAndVerifyElement(elepatientLNameInput);
			scrollToElement(elepatientLNameInput);
			clearText(elepatientLNameInput);
			inputText(elepatientLNameInput, lName);

			// Patient DOB
			waitAndVerifyElement(elePatientDOB);
			clearText(elePatientDOB);
			inputText(elePatientDOB, dob);

			// Patient Phone
			By elepatientPhone = getDynamicElement(strInputBoxXpath, "Patient Phone");
			waitAndVerifyElement(elepatientPhone);
			scrollToElement(elepatientPhone);
			sendKeysWithActionClass(elepatientPhone, phone);

			// Patient Email
			By elepatientemail = getDynamicElement(strInputBoxXpath, "Patient Email");
			waitAndVerifyElement(elepatientemail);
			scrollToElement(elepatientemail);
			clearText(elepatientemail);
			inputText(elepatientemail, email);
			setTimeOut(2000);

			// Patient ZipCode
			By elepatientZipCode = getDynamicElement(strInputBoxXpath, "Patient Mailing Zip Code");
			waitAndVerifyElement(elepatientZipCode);
			scrollToElement(elepatientZipCode);
			setTimeOut(1000);
			clearText(elepatientZipCode);
			setTimeOut(1000);
			inputText(elepatientZipCode, zipCode);
			setTimeOut(3000);

			// Search existing Patient
			waitAndVerifyElement(elePatientSearch);
			click(elePatientSearch);
			setTimeOut(5000);
			click(elePatientSearch);
			setTimeOut(5000);

			clickByJavascript(eleSelectPatientRadioBtn);
			setTimeOut(2000);
			LoggingInfo("Selects existing Patient radio button");
			setTimeOut(2000);

			waitAndVerifyElement(eleNext);
			scrollToElement(eleNext);
			click(eleNext);

			setTimeOut(4000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter Patient search fields" + e.getMessage());
			Assert.fail("Patient Search fields verification failed " + e.getMessage());
		}
	}

	// Anand P
	public void verifyDocumentLinkedText() {

		try {
			setTimeOut(10000);
			waitAndVerifyElement(eleDocumentLinkedText);
			setTimeOut(2000);
			String documentLinkedText = getText(eleDocumentLinkedText);
			setTimeOut(2000);
			LoggingInfo("Verifies document linked text " + documentLinkedText);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify text" + e.getMessage());
			Assert.fail("Page to verify text" + ". Error - " + e.getMessage());

		}

	}

	// Trupti
	public void verifyCaseMangerAssignedMSG() {
		try {
			boolean found = isElementDisplayed(caseMangerAssignedMsg);
			Assert.assertTrue(found, "Case Manager has been assigned successfully message not found");
			LoggingInfo("Case Manager has been assigned successfully message displayed");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify text" + e.getMessage());
			Assert.fail("Page to verify text" + ". Error - " + e.getMessage());

		}
	}

	public void searchPatientButton() {
		try {
			waitAndVerifyElement(elePatientSearch);
			scrollToElement(elePatientSearch);
			click(elePatientSearch);
			setTimeOut(5000);
			LoggingInfo("Successfully clicks on patient search button");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to enter Care Program name" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Clear existing patient search fields
	 *
	 * 
	 * @author: Trupti Zure
	 */
	public void clearExistingFields() {
		try {
			String[] fieldLabels = { "Patient First Name", "Patient Last Name", "Patient Phone", "Patient Email",
					"Patient Mailing Zip Code" };

			for (String label : fieldLabels) {
				By inputBox = getDynamicElement(strTextBoxesInput, label);
				scrollToElement(inputBox);
				clearInputFieldText(inputBox);
			}

			// Patient DOB
			clearInputFieldText(patientSearchDOB);

		} catch (Exception e) {
			e.printStackTrace();
			String errorMsg = "Failed to clear one or more input fields: " + e.getMessage();
			Log.error(errorMsg);
			Assert.fail(errorMsg);
		}
	}

	/**
	 * Function: Verify Fuzzy Logic for Existing Patient
	 * 
	 * @author: Trupti Zure
	 */
	public void verifyFuzzyLogicExistingPatient(String FNamePatientSearch, String LNamePatientSearch,
			String PatientEmailSearch, String Phone, String zipCode, String PatientDOBSearch) {
		try {

			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Patient First Name");
			By elepatientLNameInput = getDynamicElement(strTextBoxesInput, "Patient Last Name");
			By elepatientZipCodeInput = getDynamicElement(strTextBoxesInput, "Patient Mailing Zip Code");
			By elepatientEmailInput = getDynamicElement(strTextBoxesInput, "Patient Email");
			By elepatientPhoneInput = getDynamicElement(strTextBoxesInput, "Patient Phone");

			if (FNamePatientSearch != null && !FNamePatientSearch.isEmpty()) {
				waitAndVerifyElement(elepatientFNameInput);
				inputText(elepatientFNameInput, FNamePatientSearch);
				setTimeOut(2000);

				if (LNamePatientSearch != null && !LNamePatientSearch.isEmpty()) {
					waitAndVerifyElement(elepatientLNameInput);
					inputText(elepatientLNameInput, LNamePatientSearch);
					setTimeOut(2000);

				}
				// patientSearchDOB
				if (PatientDOBSearch != null && !PatientDOBSearch.isEmpty()) {

					waitAndVerifyElement(patientSearchDOB);
					setTimeOut(2000);
					verifyAndEnterInfoInputField(patientSearchDOB, PatientDOBSearch,"Patient DOB");
					setTimeOut(2000);
				}
				if (Phone != null && !Phone.isEmpty()) {
					waitAndVerifyElement(elepatientPhoneInput);
					verifyAndInputTextWithActionClass(elepatientPhoneInput, Phone);
					setTimeOut(2000);
				}
				// patientSearchEmail
				if (PatientEmailSearch != null && !PatientEmailSearch.isEmpty()) {
					waitAndVerifyElement(elepatientEmailInput);
					setTimeOut(2000);
					inputText(elepatientEmailInput, PatientEmailSearch);
					setTimeOut(2000);
				}
				if (zipCode != null && !zipCode.isEmpty()) {
					waitAndVerifyElement(elepatientZipCodeInput);
					inputText(elepatientZipCodeInput, zipCode);
					setTimeOut(2000);
				}

				searchPatientButton();
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify the details" + e.getMessage());
			Assert.fail("Failed to verify the details" + e.getMessage());
		}

	}

	/**
	 * Function: Validate search result
	 * 
	 * @author: Trupti Zure
	 */

	public void validateSearchResult(String expectedAccountName) {
		try {
			waitAndVerifyElement(searchTable);
			String actualAccountName = getText(accountNameCellLocator);
			Log.info("Expected Account Name: " + expectedAccountName);
			Log.info("Actual Account Name: " + actualAccountName);
			Assert.assertEquals(actualAccountName, expectedAccountName, "Account name match!");
			LoggingInfo("Account name validated successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate account name: " + e.getMessage());
			Assert.fail("Error during account name validation: " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to Inprogress EF pages(eg Patient search,Insurance
	 * Information)
	 * 
	 * @author: Shanavaz Nishani
	 */
	public void navigateToInprogressEFpages(String pageName) throws Exception {

		try {
			By elePageName = getDynamicElement(elepageName, pageName);
			waitAndVerifyElement(elePageName);
			scrollToElement(elePageName);
			click(elePageName);
			Log.info("Navigated to " + pageName + " successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to " + pageName + e.getMessage());
			Assert.fail("Failed to navigate to " + pageName + e.getMessage());
		}

	}

	/**
	 * Function: Verify no records to display message in Patient search page
	 * 
	 * @author: Shanavaz Nishani
	 */
	public void verifyNorecords() {
		try {
			By elePatientSearchNoRecords = getDynamicElement(strErrorMsgPatientSearch, "No records to display");
			waitAndVerifyElement(elePatientSearchNoRecords);
			verifyTextPresent(elePatientSearchNoRecords, patientSearchNoRecordsMsg);
			LoggingInfo("Succefully verified no record is displayed");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify No record displayed " + e.getMessage());
			Assert.fail("Failed to verify No record displayed " + e.getMessage());
		}

	}

	/**
	 * Function: Verify minimum search criteria not met message in Patient search
	 * page
	 * 
	 * @author: Shanavaz Nishani
	 */
	public void verifyMinCriteriaNotMet() {
		try {
			By elePatientSearchNoRecords = getDynamicElement(strerror, "Minimum search criteria not met");
			waitAndVerifyElement(elePatientSearchNoRecords);
			verifyTextPresent(elePatientSearchNoRecords, "Minimum search criteria not met");
			LoggingInfo("Succefully verified minimum search criteria not met message is displayed");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify error Min criteria not met " + e.getMessage());
			Assert.fail("Failed to verify error Min criteria not met " + e.getMessage());
		}

	}

	/**
	 * Function: This function is used to enter existing patient details in the
	 * Patient search page.
	 * 
	 * @author: Shanavaz Nishani
	 */
	public void enterExistingPatientDetails(String Fname, String Lname, String dob,
			String email, String zipCode, String phone) throws Exception {
		List<String> fieldName = Arrays.asList("Patient First Name", "Patient Last Name", "Patient Email",
				"Patient Mailing Zip Code");
		List<String> expectedValue = Arrays.asList(Fname, Lname, email, zipCode);

		for (int i = 0; i < fieldName.size(); i++) {
			By requiredField = getDynamicElement(strInputBoxXpath, fieldName.get(i));
			waitAndVerifyElement(requiredField);
			scrollToElement(requiredField);
			setTimeOut(1000);
			clearText(requiredField);
			setTimeOut(1000);
			inputText(requiredField, expectedValue.get(i));
			setTimeOut(3000);
		}
		By elepatientPhoneInput = getDynamicElement(strTextBoxesInput, "Patient Phone");
		waitAndVerifyElement(elepatientPhoneInput);
		scrollToElement(elepatientPhoneInput);
		click(elepatientPhoneInput);
		getWebDriver().findElement(elepatientPhoneInput).clear();
		setTimeOut(2000);
		scrollToElement(elepatientPhoneInput);
		click(elepatientPhoneInput);
		Robot robot = new Robot();
		for (int i = 0; i < phone.length(); i++) {
			char c = phone.charAt(i);
			int keyCode = KeyEvent.getExtendedKeyCodeForChar(c);
			if (Character.isDigit(c)) {
				robot.keyPress(keyCode);
				robot.keyRelease(keyCode);
				Thread.sleep(50);
			}
		}

		waitAndVerifyElement(elePatientDOB);
		clearText(elePatientDOB);
		inputText(elePatientDOB, dob);
	}

	/**
	 * Function: This function searches and selects an existing patient.
	 * 
	 * @author: Shanavaz Nishani
	 */
	public void searchAndSelectExistingPat() throws Exception {
		try {
			waitAndVerifyElement(elePatientSearch);
			scrollToElement(elePatientSearch);
			click(elePatientSearch);
			setTimeOut(2000);
			clickByJavascript(elePatientSearch);
			setTimeOut(5000);

			clickByJavascript(eleSelectPatientRadioBtn);
			setTimeOut(2000);
			LoggingInfo("Selects existing Patient radio button");
			setTimeOut(2000);

			waitAndVerifyElement(eleNext);
			scrollToElement(eleNext);
			click(eleNext);
			setTimeOut(4000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to search and select existing patient " + e.getMessage());
			Assert.fail("Failed to search and select existing patient " + e.getMessage());
		}
	}
	
	
	public void selectExistingPatient(String patientCareProgram) throws Exception {

		waitAndVerifyElement(eleCareProgramProduct);
		click(eleCareProgramProduct);
		selectItemFromList(eleCareProgramProduct, eleCareProgramDropdown, patientCareProgram, "Care program product");
		setTimeOut(2000);

		String pFullName = "AutomationKevin Ted Johnson";
		String FNamePatientSearch = "AutomationKevin";
		String LNamePatientSearch = "Johnson";
		String PhonePatientSearch = "9894905660";
		String PatientEmailSearch = "kevinjohnson@gmail.com";
		String PatientDOBSearch = "08-24-1956";
		String zipCode = "18785";

		waitForPageLoaded();
		By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Patient First Name");
		By elepatientLNameInput = getDynamicElement(strTextBoxesInput, "Patient Last Name");
		By elepatientZipCodeInput = getDynamicElement(strTextBoxesInput, "Patient Mailing Zip Code");

		waitAndVerifyElement(elepatientZipCodeInput);
		clearText(elepatientZipCodeInput);
		setTimeOut(2000);
		inputText(elepatientZipCodeInput, zipCode);
		setTimeOut(2000);
		LoggingInfo("Enters zip code correctly");
		setTimeOut(2000);

		waitAndVerifyElement(elepatientFNameInput);
		inputText(elepatientFNameInput, FNamePatientSearch);
		LoggingInfo("Enters First Name correctly");
		setTimeOut(2000);

		waitAndVerifyElement(elepatientLNameInput);
		setTimeOut(2000);
		inputText(elepatientLNameInput, LNamePatientSearch);
		LoggingInfo("Enters Last name correctly");
		setTimeOut(2000);

		By elepatientPhoneInput = getDynamicElement(strTextBoxesInput, "Patient Phone");
		waitAndVerifyElement(elepatientPhoneInput);
		scrollToElement(elepatientPhoneInput);
		click(elepatientPhoneInput);
		getWebDriver().findElement(elepatientPhoneInput).clear();
		setTimeOut(2000);
		scrollToElement(elepatientPhoneInput);
		click(elepatientPhoneInput);
		Robot robot = new Robot();
		for (int i = 0; i < PhonePatientSearch.length(); i++) {
			char c = PhonePatientSearch.charAt(i);
			int keyCode = KeyEvent.getExtendedKeyCodeForChar(c);
			if (Character.isDigit(c)) {
				robot.keyPress(keyCode);
				robot.keyRelease(keyCode);
				Thread.sleep(50);
			}
		}

		// patientSearchDOB
		waitAndVerifyElement(patientSearchDOB);
		setTimeOut(2000);
		inputText(patientSearchDOB, PatientDOBSearch);
		LoggingInfo("Enters DOB correctly");
		setTimeOut(2000);

		// patientSearchEmail
		By elepatientEmailInput = getDynamicElement(strTextBoxesInput, "Patient Email");
		waitAndVerifyElement(elepatientEmailInput);
		setTimeOut(2000);
		inputText(elepatientEmailInput, PatientEmailSearch);
		LoggingInfo("Enters Email correctly");
		setTimeOut(2000);

		// Search existing Patient
		waitAndVerifyElement(elePatientSearch);
		click(elePatientSearch);
		setTimeOut(5000);
		LoggingInfo("Successfully clicks on patient search button");

		By elePatient = getDynamicElement(selectPatient, pFullName);
		click(elePatient);
		setTimeOut(2000);
		LoggingInfo("Selects existing Patient radio button");
		setTimeOut(2000);

		waitAndVerifyElement(eleNext);
		scrollToElement(eleNext);
		click(eleNext);
	
	

	}
	
	
	/*
	 * @Author - Anand Pawar
	 */
	public void fieldEditStatus() throws Exception {
		try {
			By ParentRecDocEditBtn = getDynamicElement(strBtn, "Edit Status");
			scrollToElement(ParentRecDocEditBtn);
			click(ParentRecDocEditBtn);
			setTimeOut(3000);
			LoggingInfo("Clicked on Edit button");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Edit button " + e.getMessage());
			Assert.fail("Failed to click on Edit button " + e.getMessage());

		}
	}

	
	/*
	 * @Author - Anand Pawar
	 */
	
	public void validateStatusDropdownValue() throws Exception {
		try {
			
			By eleBtn=By.xpath("//*[@aria-label=\"Status\" and @type=\"button\"]");
			waitAndVerifyElement(eleBtn);
			clickByJavascript(eleBtn);
			
			By eleRecord =By.xpath("//*[contains(@class,\"active lafPageHost\")]//div[@aria-label=\"Status\"]//lightning-base-combobox-item//span//child::span[text()=\"Needs Review\"]");
			scrollToElement(eleRecord);
			highLightElement(eleRecord);
			setTimeOut(3000);
			LoggingInfo("Validated Needs Review Status");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Edit button " + e.getMessage());
			Assert.fail("Failed to click on Edit button " + e.getMessage());

		}
	}


}
