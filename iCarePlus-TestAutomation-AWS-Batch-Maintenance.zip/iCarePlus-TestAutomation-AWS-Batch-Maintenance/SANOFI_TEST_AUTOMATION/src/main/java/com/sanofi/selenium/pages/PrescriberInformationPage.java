package com.sanofi.selenium.pages;

import java.time.Duration;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.sanofi.selenium.constants.ExcelTestDataConstants;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class PrescriberInformationPage extends Utility_Function {

	String searchNoRecordsMsg = "No records to display";

	public PrescriberInformationPage(WebDriver driver) {
		super(driver);
		loginPage = GetInstance(LoginPage.class);
	}

	/************************* Elements *************************/

	public static By elePageTitle = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"omniscript-body\")]//*[text()='Prescriber Information']");
	public static By hcpSearchButton = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Search\"]//parent::button)[1]");
	public static By hcoSearchButton = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Search\"]//parent::button)[3]");
	public static By eleDuplicateNPI = By.xpath("//*[text()=\"CreateHCPAndHCOAccount\"]");
	public static By btnGoBack = By.xpath("//button[text()=\"Go Back\"]");

	/************************* Dynamic Elements *************************/
	public static String strInputBoxesXpath = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strdropDownXpath = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String dropDownOptionsXpath = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]";
	public static String checkbox = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-checkbox\")]//*[text()=\"{0}\"]//parent::label//child::span[1]";

	public static String eleSearchBarDropDownXpath = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div[contains(@class,\"slds-combobox\")]";
	public static String elePrevNextButtons = "//*[contains(@class,\"omniscript-button-position\")]//*[text()=\"{0}\"]";
	public static String selectRadioButton = "(//*[contains(@class,\"active lafPageHost\")]//*[@data-omni-key=\"{0}\"]//following::label)[1]";
	public static String eleStateList = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//child::li";
	public static String strErrorMsgSearch = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strSelectButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::tbody//*[@title=\"Select\"]";
	public static String strAccountObjectDetails = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"label-inline\")]//lightning-formatted-text";

	/**
	 * Function: Verify Prescriber Information page present
	 * 
	 * @author Trupti Zure
	 */

	public void verifyPrescriberInfoPageTitle() {
		try {

			setTimeOut(3000);
			waitForPageLoaded();
			Log.info("Verify Prescriber Information Page Present");
			waitAndVerifyElement(elePageTitle);
			LoggingInfo("Prescriber Information Page is loaded");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Page load has Failed" + ". Error - " + e.getMessage());

		}
	}

	public void verifyPrescriberInfo(String prescriberFName, String prescriberLName, String prescriberSpecialty,
			String prescriberNPI, String State, String prescriberStateLicense) {
		try {
			Log.info("Verify Prescriber Information");
			waitForPageLoaded();

			By prescriberFNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Prescriber First Name");
			waitAndVerifyElement(prescriberFNameElementTextBox);
			verifyHardAssertInputFieldBox(prescriberFNameElementTextBox, prescriberFName, "Prescriber First Name");

			By prescriberLNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Prescriber Last Name");
			waitAndVerifyElement(prescriberLNameElementTextBox);
			verifyHardAssertInputFieldBox(prescriberLNameElementTextBox, prescriberLName, "Prescriber Last Name");

			By specialtyElementTextBox = getDynamicElement(strInputBoxesXpath, "Specialty");
			waitAndVerifyElement(specialtyElementTextBox);
			verifySoftAssertInputFieldBox(specialtyElementTextBox, prescriberSpecialty, specialty);

			By prescriberNPITextBox = getDynamicElement(strInputBoxesXpath, "Prescriber NPI #");
			waitAndVerifyElement(prescriberNPITextBox);
			verifyHardAssertInputFieldBox(prescriberNPITextBox, prescriberNPI, ExcelTestDataConstants.prescriberNPI);

			if (State == "Puerto Rico") {
				By prescriberStateLicenseElementTextBox = getDynamicElement(strInputBoxesXpath,
						"Prescriber State License # (Required in Puerto Rico only)");
				waitAndVerifyElement(prescriberStateLicenseElementTextBox);
				verifyHardAssertInputFieldBox(prescriberStateLicenseElementTextBox, prescriberStateLicense,
						ExcelTestDataConstants.prescriberstateLicense);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Page verification has failed" + ". Error - " + e.getMessage());
		}

	}

	public void enterPrescriberInfo(String prescriberFName, String prescriberLName, String prescriberSpecialty,
			String prescriberNPI, String State, String prescriberStateLicense) {
		try {
			Log.info("Verify Prescriber Information");
			waitForPageLoaded();

			By prescriberFNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Prescriber First Name");
			waitAndVerifyElement(prescriberFNameElementTextBox);
			verifyAndEnterInfoInputField(prescriberFNameElementTextBox, prescriberFName, "Prescriber First Name");

			By prescriberLNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Prescriber Last Name");
			waitAndVerifyElement(prescriberLNameElementTextBox);
			verifyAndEnterInfoInputField(prescriberLNameElementTextBox, prescriberLName, "Prescriber Last Name");

			By specialtyElementTextBox = getDynamicElement(strInputBoxesXpath, "Specialty");
			waitAndVerifyElement(specialtyElementTextBox);
			verifyAndEnterInfoInputField(specialtyElementTextBox, prescriberSpecialty, "Specialty");

			By prescriberNPITextBox = getDynamicElement(strInputBoxesXpath, "Prescriber NPI #");
			waitAndVerifyElement(prescriberNPITextBox);
			// click(prescriberNPITextBox);
			verifyAndInputTextWithActionClass(prescriberNPITextBox, prescriberNPI);

			if (State == "Puerto Rico") {
				By prescriberStateLicenseElementTextBox = getDynamicElement(strInputBoxesXpath,
						"Prescriber State License # (Required in Puerto Rico only)");
				waitAndVerifyElement(prescriberStateLicenseElementTextBox);
				verifyAndEnterInfoInputField(prescriberStateLicenseElementTextBox, prescriberStateLicense,
						"Prescriber State License");
			}

			LoggingInfo("Prescriber Information has been entered/verified successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Page verification has failed" + ". Error - " + e.getMessage());
		}

	}

	public void verifyPrescriberAddressInfo(String prescriberAddressExcel, String prescriberCityExcel,
			String prescriberStateExcel, String prescriberZipExcel) {
		try {

			Log.info("Verify Prescriber Address Information");

			setTimeOut(10000);
			By prescriberAddressElementTextBox = getDynamicElement(strInputBoxesXpath, "Address");
			waitAndVerifyElement(prescriberAddressElementTextBox);
			verifyHardAssertInputFieldBox(prescriberAddressElementTextBox, prescriberAddressExcel, prescriberAddress);

			By prescriberCityElementTextBox = getDynamicElement(strInputBoxesXpath, "City");
			waitAndVerifyElement(prescriberCityElementTextBox);
			verifyHardAssertInputFieldBox(prescriberCityElementTextBox, prescriberCityExcel, prescriberCity);

			By prescriberStateElementTextBox = getDynamicElement(strdropDownXpath, "State");
			waitAndVerifyElement(prescriberStateElementTextBox);

			verifyHardAssertDropDown(prescriberStateElementTextBox, prescriberStateExcel, prescriberState);

			By prescriberZipElementTextBox = getDynamicElement(strInputBoxesXpath, "Zip");
			waitAndVerifyElement(prescriberZipElementTextBox); // soft assert use need to change value
			verifySoftAssertInputFieldBox(prescriberZipElementTextBox, prescriberZipExcel, prescriberZip);

		} catch (

		Exception e) {
			e.printStackTrace();
			Assert.fail("Prescriber Address verificatin has failed" + ". Error - " + e.getMessage());
		}

	}

	public void enterPrescriberAddressInfo(String prescriberAddressExcel, String prescriberCityExcel,
			String prescriberStateExcel, String prescriberZipExcel) {
		try {

			Log.info("Verify Prescriber Address Information");

			setTimeOut(10000);
			By prescriberAddressElementTextBox = getDynamicElement(strInputBoxesXpath, "Address");
			waitAndVerifyElement(prescriberAddressElementTextBox);
			scrollToElement(prescriberAddressElementTextBox);
			verifyAndEnterInfoInputField(prescriberAddressElementTextBox, prescriberAddressExcel, prescriberAddress);

			By prescriberCityElementTextBox = getDynamicElement(strInputBoxesXpath, "City");
			waitAndVerifyElement(prescriberCityElementTextBox);
			verifyAndEnterInfoInputField(prescriberCityElementTextBox, prescriberCityExcel, prescriberCity);

			By prescriberStateElementTextBox = getDynamicElement(strdropDownXpath, "State");
			waitAndVerifyElement(prescriberStateElementTextBox);
			String preState = getAttributeValue(prescriberStateElementTextBox, "value");
			if (!preState.equalsIgnoreCase(prescriberStateExcel)) {
				By prescriberStateElementList = getDynamicElement(eleStateList, "State");
				click(prescriberStateElementTextBox);
				selectItemFromList(prescriberStateElementTextBox, prescriberStateElementList, prescriberStateExcel,
						"Prescriber State");
			} else {
				highLightElement(prescriberStateElementTextBox);
				Log.info("Actual text " + preState + " matches with expected text " + prescriberStateExcel);
			}

			By prescriberZipElementTextBox = getDynamicElement(strInputBoxesXpath, "Zip");
			waitAndVerifyElement(prescriberZipElementTextBox); // soft assert use need to change value
			verifyAndEnterInfoInputField(prescriberZipElementTextBox, prescriberZipExcel, prescriberZip);

			LoggingInfo("Prescriber Address Information has been entered/verified successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Prescriber Address verificatin has failed" + ". Error - " + e.getMessage());
		}

	}

	public void verifySiteFacilityInfo(String siteFacilityName, String officePhone, String ofcContactFName,
			String ofcContactLName, String ofcMail, String ofcFax, String taxID) {
		try {

			Log.info("Verify Prescriber Site/Facility Information Information");

			By siteFacNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Site/Facility Name");
			waitAndVerifyElement(siteFacNameElementTextBox);
			scrollToElement(siteFacNameElementTextBox);
			verifyHardAssertInputFieldBox(siteFacNameElementTextBox, siteFacilityName, sitefacilityname);

			By phoneElementTextBox = getDynamicElement(strInputBoxesXpath, "Phone");
			waitAndVerifyElement(phoneElementTextBox);
			verifyHardAssertInputFieldBox(phoneElementTextBox, officePhone, officePhone);

			By ofcContactFNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Office Contact First Name");
			waitAndVerifyElement(ofcContactFNameElementTextBox);
			verifyHardAssertInputFieldBox(ofcContactFNameElementTextBox, ofcContactFName, "Office Contact First Name");

			By ofcContactLNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Office Contact Last Name");
			waitAndVerifyElement(ofcContactLNameElementTextBox);
			verifyHardAssertInputFieldBox(ofcContactLNameElementTextBox, ofcContactLName, "Office Contact Last Name");

			By ofcContactEmailElementTextBox = getDynamicElement(strInputBoxesXpath, "Office Contact Email");
			waitAndVerifyElement(ofcContactEmailElementTextBox);
			verifyHardAssertInputFieldBox(ofcContactEmailElementTextBox, ofcMail, officeContactEmail);

			By ofcFaxElementTextBox = getDynamicElement(strInputBoxesXpath, "Fax");
			waitAndVerifyElement(ofcFaxElementTextBox);
			verifyHardAssertInputFieldBox(ofcFaxElementTextBox, ofcFax, officeFax);

			By taxIDTextBox = getDynamicElement(strInputBoxesXpath, "Tax ID #");
			waitAndVerifyElement(taxIDTextBox);
			verifyHardAssertInputFieldBox(taxIDTextBox, taxID, taxID);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Prescriber Site/Facility Information has failed" + ". Error - " + e.getMessage());
		}
	}

	public void enterSiteFacilityInfo(String siteFacilityName, String officePhone, String ofcContactFName,
			String ofcContactLName, String ofcMail, String ofcFax, String taxID) {
		try {

			Log.info("Verify Prescriber Site/Facility Information");

			By siteFacNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Site/Facility Name");
			waitAndVerifyElement(siteFacNameElementTextBox);
			scrollToElement(siteFacNameElementTextBox);
			verifyAndEnterInfoInputField(siteFacNameElementTextBox, siteFacilityName, sitefacilityname);

			By phoneElementTextBox = getDynamicElement(strInputBoxesXpath, "Phone");
			waitAndVerifyElement(phoneElementTextBox);
			// click(phoneElementTextBox);
			verifyAndInputTextWithActionClass(phoneElementTextBox, officePhone);

			By ofcContactFNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Office Contact First Name");
			waitAndVerifyElement(ofcContactFNameElementTextBox);
			verifyAndEnterInfoInputField(ofcContactFNameElementTextBox, ofcContactFName, "Office Contact First Name");

			By ofcContactLNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Office Contact Last Name");
			waitAndVerifyElement(ofcContactLNameElementTextBox);
			verifyAndEnterInfoInputField(ofcContactLNameElementTextBox, ofcContactLName, "Office Contact Last Name");

			By ofcContactEmailElementTextBox = getDynamicElement(strInputBoxesXpath, "Office Contact Email");
			waitAndVerifyElement(ofcContactEmailElementTextBox);
			verifyAndEnterInfoInputField(ofcContactEmailElementTextBox, ofcMail, officeContactEmail);

			By ofcFaxElementTextBox = getDynamicElement(strInputBoxesXpath, "Fax");
			waitAndVerifyElement(ofcFaxElementTextBox);
			// click(ofcFaxElementTextBox);
			verifyAndInputTextWithActionClass(ofcFaxElementTextBox, ofcFax);

			By taxIDTextBox = getDynamicElement(strInputBoxesXpath, "Tax ID #");
			waitAndVerifyElement(taxIDTextBox);
			verifyAndEnterInfoInputField(taxIDTextBox, taxID, taxID);

			LoggingInfo("Prescriber Site/Facility Information has been entered/verified successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Prescriber Site/Facility Information has failed" + ". Error - " + e.getMessage());
		}
	}

	public void clicOnPreviousButton() {
		try {
			By previousButton = getDynamicElement(elePrevNextButtons, "Previous");
			waitAndVerifyElement(previousButton);
			click(previousButton);
			Log.info("Clicked on Previous Button");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on Previous Button-" + "Error - " + e.getMessage());
		}
	}

	public void clickOnNextButton() {
		try {
			By nextButton = getDynamicElement(elePrevNextButtons, "Next");
			waitAndVerifyElement(nextButton);
			setTimeOut(2000);
			scrollToElement(nextButton);
			clickByJavascript(nextButton);
			Log.info("Clicked on Next Button");
			handleDuplicateNPI();

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on Previous Button-" + "Error - " + e.getMessage());
		}
	}

	public class RandomUtils {

		/**
		 * Generates a random 10-digit integer (as a long).
		 * 
		 * @return A 10-digit random number.
		 */
		public static long generateRandom10DigitNumber() {
			Random random = new Random();

			// First digit should not be zero, so we start from 1_000_000_000
			long min = 1_000_000_000L;
			long max = 9_999_999_999L;

			return min + ((long) (random.nextDouble() * (max - min)));
		}
	}

	/*
	 * 
	 * Author - Anand Pawar
	 */

	public void handleDuplicateNPI() {
		WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(10));

		List<WebElement> elements = getWebDriver().findElements(eleDuplicateNPI);
		if (!elements.isEmpty() && elements.get(0).isDisplayed()) {
			try {
				WebElement goBackBtn = wait.until(ExpectedConditions.elementToBeClickable(btnGoBack));
				goBackBtn.click();
				System.out.println("Duplicate NPI found. GoBack button clicked.");

				String randomInt = generatePhoneNumber();

				By prescriberNPITextBox = getDynamicElement(strInputBoxesXpath, "Prescriber NPI #");
				scrollToElement(prescriberNPITextBox);
				waitAndVerifyElement(prescriberNPITextBox);
				verifyAndInputTextWithActionClass(prescriberNPITextBox, randomInt);
				setTimeOut(2000);
				insuranceinfo.clickOnNextButton();
				setTimeOut(2000);

			} catch (Exception e) {
				System.out.println("GoBack button not clickable: " + e.getMessage());
			}
		} else {
			System.out.println("Duplicate NPI not present. Continuing...");
		}
	}

	public void selectHCPRecord() {
		try {
			waitAndVerifyElement(hcpSearchButton);
			setTimeOut(2000);
			click(hcpSearchButton);
			setTimeOut(2000);
			By hcpRecord = getDynamicElement(selectRadioButton, "iccHCPSearchComponent");
			waitAndVerifyElement(hcpRecord);
			setTimeOut(2000);
			click(hcpRecord);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("HCP record selection failed-" + "Error - " + e.getMessage());
		}
	}

	public void updateZipandSpeciality(String prescriberSpecialty, String prescriberZipExcel) throws Exception {
		try {
			By specialtyElementTextBox = getDynamicElement(strInputBoxesXpath, "Specialty");
			scrollToElement(specialtyElementTextBox);
			waitAndVerifyElement(specialtyElementTextBox);
			verifyAndEnterInfoInputField(specialtyElementTextBox, prescriberSpecialty, "Specialty");

			By prescriberZipElementTextBox = getDynamicElement(strInputBoxesXpath, "Zip");
			scrollToElement(prescriberZipElementTextBox);
			waitAndVerifyElement(prescriberZipElementTextBox); // soft assert use need to change value
			verifyAndEnterInfoInputField(prescriberZipElementTextBox, prescriberZipExcel, prescriberZip);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Prescriber Speciality and Zip update failed" + "Error - " + e.getMessage());
		}

	}

	/**
	 * Function: Verify Prescriber Name
	 *
	 * @author Trupti
	 */

	public void verifyPrescriberName(String prescriberFName, String prescriberLName) {
		try {
			Log.info("Verify Prescriber First name and Last Name");
			waitForPageLoaded();

			By prescriberFNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Prescriber First Name");
			waitAndVerifyElement(prescriberFNameElementTextBox);
			verifyHardAssertInputFieldBox(prescriberFNameElementTextBox, prescriberFName, "Prescriber First Name");

			By prescriberLNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Prescriber Last Name");
			waitAndVerifyElement(prescriberLNameElementTextBox);
			verifyHardAssertInputFieldBox(prescriberLNameElementTextBox, prescriberLName, "Prescriber Last Name");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Prescriber name verification failed" + "Error - " + e.getMessage());
		}

	}

	public void searchRecord() {
		try {
			waitAndVerifyElement(hcpSearchButton);
			scrollToElement(hcpSearchButton);
			setTimeOut(2000);
			clickByJavascript(hcpSearchButton);
			setTimeOut(2000);
			LoggingInfo("Clicked on HCP search button");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Prescriber Search failed" + "Error - " + e.getMessage());
		}

	}

	public void verifyNoRecordsDisplayMessage() {
		try {
			By elePatientSearchNoRecords = getDynamicElement(strErrorMsgSearch, "No records to display");
			waitAndVerifyElement(elePatientSearchNoRecords);
			verifyTextPresent(elePatientSearchNoRecords, searchNoRecordsMsg);
			LoggingInfo("Succefully verified no record is displayed");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Prescriber Search failed" + "Error - " + e.getMessage());
		}
	}

	public void searchAndSelectHCP(String hcpName) {
		try {
			searchRecord();
			By hcpbutton = getDynamicElement(strSelectButton, hcpName);
			waitAndVerifyElement(hcpbutton);
			scrollToElement(hcpbutton);
			click(hcpbutton);
			LoggingInfo("Selected HCP as- " + hcpName);
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select HCP information " + ". Error - " + e.getMessage());
		}
	}

	// Anand P
	public void selectRCMHCP(String hcpName, String patinetName) {
		try {

			// Verify Source system using show details and then select RCM HCP
			By showAction = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Show actions\"]//ancestor::button");
			waitAndVerifyElement(showAction);
			scrollToElement(showAction);
			clickByJavascript(showAction);

			By showDetails = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Show details\"]");
			waitAndVerifyElement(showDetails);
			scrollToElement(showDetails);
			clickByJavascript(showDetails);
			setTimeOut(2000);

			// Check source system
			By soyrceSystem = getDynamicElement(strAccountObjectDetails, "Source System");
			waitAndVerifyElement(soyrceSystem);
			scrollToElement(soyrceSystem);
			String source = getText(soyrceSystem);
		//	Assert.assertEquals(source, "RCM", "Source system does not match");

			// navigate back to patient EF wizard
			missingInformatioPage.navigateToCPERecord(patinetName);
			setTimeOut(2000);

			// Select HCP
			By hcpbutton = getDynamicElement(strSelectButton, hcpName);
			waitAndVerifyElement(hcpbutton);
			scrollToElement(hcpbutton);
			click(hcpbutton);
			LoggingInfo("Selected HCP as- " + hcpName);
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select HCP information " + ". Error - " + e.getMessage());
		}
	}

	public void searchAndSelectHCO(String hcoName) {
		try {
			waitAndVerifyElement(hcoSearchButton);
			scrollToElement(hcoSearchButton);
			setTimeOut(2000);
			click(hcoSearchButton);
			setTimeOut(2000);
			By hcobutton = getDynamicElement(strSelectButton, hcoName);
			waitAndVerifyElement(hcobutton);
			scrollToElement(hcobutton);
			click(hcobutton);
			LoggingInfo("Selected HCO as- " + hcoName);
			setTimeOut(1000);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select HCO information " + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Clear HCO fields
	 * 
	 * @author Shanavaz Nishani
	 */
	public void clearHCOFields() {
		try {
			By ofcContactFNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Office Contact First Name");
			waitAndVerifyElement(ofcContactFNameElementTextBox);
			clearText(ofcContactFNameElementTextBox);

			By ofcContactLNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Office Contact Last Name");
			waitAndVerifyElement(ofcContactLNameElementTextBox);
			clearText(ofcContactLNameElementTextBox);

			By ofcContactEmailElementTextBox = getDynamicElement(strInputBoxesXpath, "Office Contact Email");
			waitAndVerifyElement(ofcContactEmailElementTextBox);
			clearText(ofcContactEmailElementTextBox);

			By taxIDTextBox = getDynamicElement(strInputBoxesXpath, "Tax ID #");
			waitAndVerifyElement(taxIDTextBox);
			clearText(taxIDTextBox);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to clear HCO fields" + ". Error - " + e.getMessage());
		}

	}

	/**
	 * Function: Enter HCO details
	 * 
	 * @author Shanavaz Nishani
	 */
	public void enterHCOInfo(String ofcContactFName, String ofcContactLName, String ofcMail, String taxID) {
		try {
			By ofcContactFNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Office Contact First Name");
			waitAndVerifyElement(ofcContactFNameElementTextBox);
			verifyAndEnterInfoInputField(ofcContactFNameElementTextBox, ofcContactFName, "Office Contact First Name");

			By ofcContactLNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Office Contact Last Name");
			waitAndVerifyElement(ofcContactLNameElementTextBox);
			verifyAndEnterInfoInputField(ofcContactLNameElementTextBox, ofcContactLName, "Office Contact Last Name");

			By ofcContactEmailElementTextBox = getDynamicElement(strInputBoxesXpath, "Office Contact Email");
			waitAndVerifyElement(ofcContactEmailElementTextBox);
			verifyAndEnterInfoInputField(ofcContactEmailElementTextBox, ofcMail, officeContactEmail);

			By taxIDTextBox = getDynamicElement(strInputBoxesXpath, "Tax ID #");
			waitAndVerifyElement(taxIDTextBox);
			verifyAndEnterInfoInputField(taxIDTextBox, taxID, taxID);

			LoggingInfo("Prescriber Site/Facility Information has been entered/verified successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Prescriber Site/Facility Information has failed" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Clear HCP fields
	 * 
	 * @author Anand Pawar
	 */
	public void clearHCPFields() {
		try {

			By prescriberFNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Prescriber First Name");
			waitAndVerifyElement(prescriberFNameElementTextBox);
			clearText(prescriberFNameElementTextBox);

			By prescriberLNameElementTextBox = getDynamicElement(strInputBoxesXpath, "Prescriber Last Name");
			waitAndVerifyElement(prescriberLNameElementTextBox);
			clearText(prescriberLNameElementTextBox);

			By specialtyElementTextBox = getDynamicElement(strInputBoxesXpath, "Specialty");
			waitAndVerifyElement(specialtyElementTextBox);
			clearText(specialtyElementTextBox);

			By prescriberNPITextBox = getDynamicElement(strInputBoxesXpath, "Prescriber NPI #");
			waitAndVerifyElement(prescriberNPITextBox);
			clearText(prescriberNPITextBox);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to clear HCO fields" + ". Error - " + e.getMessage());
		}

	}

	/*
	 * Function - Enter only NPI
	 * 
	 * @author - Anand Pawar
	 */
	public void enterPrescriberNPI(String prescriberNPI) {
		try {
			Log.info("Verify Prescriber Information");
			waitForPageLoaded();

			By prescriberNPITextBox = getDynamicElement(strInputBoxesXpath, "Prescriber NPI #");
			waitAndVerifyElement(prescriberNPITextBox);
			verifyAndInputTextWithActionClass(prescriberNPITextBox, prescriberNPI);
			setTimeOut(2000);

			LoggingInfo("Prescriber NPI Information has been entered/verified successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("NPI verification has failed" + ". Error - " + e.getMessage());
		}
	}

	public void searchAndSelectHCP() {
		try {
			searchRecord();
			By hcpbutton = By.xpath("//*[contains(@class,\"active lafPageHost\")]//button[@title=\"Select\"]");
			waitAndVerifyElement(hcpbutton);
			scrollToElement(hcpbutton);
			click(hcpbutton);
			LoggingInfo("Selected HCP button");
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select HCP information " + ". Error - " + e.getMessage());
		}
	}

}
