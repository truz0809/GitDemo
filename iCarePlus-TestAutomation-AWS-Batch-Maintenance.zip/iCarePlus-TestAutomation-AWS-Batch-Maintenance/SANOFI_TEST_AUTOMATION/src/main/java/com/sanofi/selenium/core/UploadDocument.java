package com.sanofi.selenium.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.time.Duration;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;

import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.HomePortal;
import com.sanofi.selenium.pages.LoginPage;
import com.sanofi.selenium.utils.Log;

public class UploadDocument extends Utility_Function {

	public UploadDocument(WebDriver driver) {
		super(driver);
	}

	public String fileName;

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		homeportalPage = GetInstance(HomePortal.class);

	}

	public static By doneButton = By.xpath("//*[text()='Done']//parent::button");
	public static By eleError = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()='Please assign this received document to yourself and then proceed']");
	public static By eleFileInput = By.xpath("//input[@type=\"file\"]");
	public static By greenTickIcon = By.xpath("//*[@icon-name=\"utility:success\"]//*[local-name()='svg' and @data-key=\"success\" and contains(@class, \"slds-icon\")]");

	
	public void handleLoginScreen() {
	    try {
	        WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(5)); // short timeout
	        WebElement nextButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='employeeLoginLink salesforceIdentityEmployeeLoginLink2']//a")));
	       
	        if (nextButton.isDisplayed()) {
	            System.out.println("Login screen appeared. Clicking Next.");
	            nextButton.click();
	        }
	    } catch (Exception e) {
	        System.out.println("Login screen not present. Proceeding without action.");
	    }
	}
	/**
	 * Function: Upload the document either through manual upload or via the
	 * Dupixent portal.
	 *
	 * @author Anand Pawar
	 */

	public String uploadDoc(String filePath, String[] cpeDetails) {
		setUp();
		String documentID = "";

		try {
			if (uploadType.equalsIgnoreCase("DupixentPortalUpload")) {

				Log.info("FilePath" + filePath);
				String pName = cpeDetails[0];
				String pDOB = cpeDetails[1];
				String pEmail = cpeDetails[2];

				String[] cpEDetails = { pName, pDOB, pEmail };
				Logger("Launch the dupixent My way Portal URL for QA/Val org'.");
				navigateToDupxientUrl();

				dupixentPortal.handleLoginScreen();
				
				Logger("Once URL is launched, from the welcome a Pop up is displayed Click on \"I am a Patient or Caregiver\" button.");
				dupixentPortal.clickOnAcceptAllCookies();
				handleLoginScreen();
				dupixentPortal.clickOnAcceptAllCookies();
				dupixentPortal.clickOnPatientorCaregiverButton();
			
				Logger("Click the \"Upload Document\" button in the home page.");
				dupixentPortal.clickOnUploadDocButton();

				Logger("In the next page Enter Enrollment code and submit it.");
				dupixentPortal.enterAccessCode("8443879370");
				dupixentPortal.clickOnSubmitCodeButton();

				Logger("Enter the details Patient Information section and submit enrollment Form");
				dupixentPortal.enterPatientInfo(cpEDetails);
				dupixentPortal.clickOnSubmitDocCheckBox();
				dupixentPortal.clickOnConsentCheckBoxes();
				uploadFileWithSendKeys(filePath);
				dupixentPortal.clickOnSubmitButton();

				documentID = dupixentPortal.getDocumentID();
				
				loginAsSystemAdmin(documentID, filePath);

			} else if (uploadType.equalsIgnoreCase("SFUpload")) {

				Logger("STEP 2.1: Open ICARE Connect App from the App launcher.");
				documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0),
						DocumentPage.class);

				Logger("STEP 2.2: Navigate to the Received Document Object from the app launcher.");
				documentsPage.verifyRecentlyViewDocumentList();

				Logger("STEP 2.3: Click on the Upload Document Button and upload a PDF Enrollment Form.");
				documentsPage.VerifyUploadDocumentButton();
				documentsPage.uploadEnrollmentDocument(filePath);

				Logger("STEP 2.4:Once the PDF Enrollment Form is uploaded, navigate to the 'Received Document Worklist' list view of the Received Document.");
				fileName = documentsPage.getFileName(filePath);
				documentsPage.verifyRecord(fileName);

				documentID = documentsPage.getParentDocumentID(fileName);
				loginAsSystemAdmin(documentID, filePath);

				loginAsSystemAdmin(documentID, filePath);

			} else
				System.out.println("Invalid upload Type selection");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Upload activity failed " + e.getMessage());
		}

		return documentID;

	}

	/**
	 * Function: Upload the document either through manual upload or via the
	 * Dupixent portal.
	 *
	 * @author Sonica P
	 */

	public String uploadsDoc(String filePath, String[] cpeDetails) {
		setUp();
		String documentID = "";

		try {
			if (uploadType.equalsIgnoreCase("DupixentPortalUpload")) {

				String pName = cpeDetails[0];
				String pDOB = cpeDetails[1];
				String pEmail = cpeDetails[2];

				String[] cpEDetails = { pName, pDOB, pEmail };
				Logger("Launch the dupixent My way Portal URL for QA/Val org'.");
				navigateToDupxientUrl();

				Logger("Once URL is launched, from the welcome a Pop up is displayed Click on \"I am a Patient or Caregiver\" button.");

				dupixentPortal.clickOnAcceptAllCookies();
				dupixentPortal.clickOnPatientorCaregiverButton();

				Logger("Click the \"Upload Document\" button in the home page.");
				dupixentPortal.clickOnUploadDocButton();

				Logger("In the next page Enter Enrollment code and submit it.");
				dupixentPortal.enterAccessCode("8443879370");
				dupixentPortal.clickOnSubmitCodeButton();

				Logger("Enter the details Patient Information section and submit enrollment Form");
				dupixentPortal.enterPatientInfo(cpEDetails);
				dupixentPortal.clickOnSubmitDocCheckBox();
				dupixentPortal.clickOnConsentCheckBoxes();
				uploadFileWithSendKeys(filePath);
				dupixentPortal.clickOnSubmitButton();

				documentID = dupixentPortal.getDocumentID();

				loginAsSystemAdmintoValidateError(documentID, filePath);

			} else if (uploadType.equalsIgnoreCase("SFUpload")) {

				Logger("STEP 2.1: Open ICARE Connect App from the App launcher.");
				documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0),
						DocumentPage.class);

				Logger("STEP 2.2: Navigate to the Received Document Object from the app launcher.");
				documentsPage.verifyRecentlyViewDocumentList();

				Logger("STEP 2.3: Click on the Upload Document Button and upload a PDF Enrollment Form.");
				documentsPage.VerifyUploadDocumentButton();
				documentsPage.uploadEnrollmentDocument(filePath);

				Logger("STEP 2.4:Once the PDF Enrollment Form is uploaded, navigate to the 'Received Document Worklist' list view of the Received Document.");
				fileName = documentsPage.getFileName(filePath);
				documentsPage.verifyRecord(fileName);

				documentID = documentsPage.getParentDocumentID(fileName);
				loginAsSystemAdmintoValidateError(documentID, filePath);

				loginAsSystemAdmintoValidateError(documentID, filePath);

			} else
				System.out.println("Invalid upload Type selection");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Upload activity failed " + e.getMessage());
		}

		return documentID;

	}

	/**
	 * Function: Navigate to salesforce url
	 *
	 * @author Anand Pawar
	 */
	public void loginAsDISUser() {

//		Logger("STEP 1: After Submitting the Documents from the Dupix Portal, Now Log in org As DIS User");
//		navigateToSFUrl();
		boolean homepage = dupixentPortal.verifyLoginScreen();
		loginPage = GetInstance(LoginPage.class);
		if (homepage) {
			homeportalPage = loginPage.userLogin(PSRUserName, UserPassword);
		}
		homeportalPage.closeTabs();

		Logger("STEP 2: Open ICARE Connect App from the App launcher and navigate to recieved document object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

	}
	
	public void loginAsUser(String username, String password) {

//		Logger("STEP 1: After Submitting the Documents from the Dupix Portal, Now Log in org As DIS User");
//		navigateToSFUrl();
		boolean homepage = dupixentPortal.verifyLoginScreen();
		loginPage = GetInstance(LoginPage.class);
		if (homepage) {
			homeportalPage = loginPage.userLogin(username, password);
		}
		homeportalPage.closeTabs();

		Logger("STEP 2: Open ICARE Connect App from the App launcher and navigate to recieved document object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

	}

	/**
	 * Function: Login as DIS User and Password for validating error
	 *
	 * @author Sonica P
	 */
	public void loginAsDISUserName(String docID, String filePath) {

		Logger("STEP 1: After Submitting the Documents from the Dupix Portal, Now Log in org As DIS User");
		navigateToSFUrl();
		boolean homepage = dupixentPortal.verifyLoginScreen();
		loginPage = GetInstance(LoginPage.class);
		if (homepage) {
			homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
		}
		homeportalPage.closeTabs();

		Logger("STEP 2: Open ICARE Connect App from the App launcher and navigate to recieved document object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

		documentsPage.verifyRecentlyViewDocumentList();
		documentsPage.navigateToAllReceivedDoc();

		documentsPage.openDocumentFromAllRecivedDocList(docID);
		fileName = documentsPage.getFileName(filePath);
		documentsPage.verifyRecordAndClick(fileName);
	}

	/**
	 * Function: Navigate to Dupixent url
	 *
	 * @author Trupti
	 */
	public void navigateToDupxientUrl() {
		try {
			setTimeOut(3000);
			String baseUrl = Configuration.readApplicationFile("DupixentMyWayPortalURL");
			getWebDriver().navigate().to(baseUrl);
			waitForPageLoaded();
			setTimeOut(2000);
		} catch (UnhandledAlertException e) {
			String baseUrl = Configuration.readApplicationFile("DupixentMyWayPortalURL");
			getWebDriver().navigate().to(baseUrl);
			waitForPageLoaded();
			setTimeOut(4000);
			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void validateError() {
		try {
			waitAndVerifyElement(eleError);
			LoggingInfo("Error message verified");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to verify Error message " + e.getMessage());
			Assert.fail("Failed to verify Error message " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to Dupixent url
	 *
	 * @author Trupti
	 */
	public void navigateToSFUrl() {
		try {
			setTimeOut(3000);
			String sfBaseUrl = Configuration.readApplicationFile("url");
			getWebDriver().navigate().to(sfBaseUrl);
			waitForPageLoaded();
			setTimeOut(2000);
		} catch (UnhandledAlertException e) {
			String sfBaseUrl = Configuration.readApplicationFile("url");
			getWebDriver().navigate().to(sfBaseUrl);
			waitForPageLoaded();
			setTimeOut(4000);
			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void uploadWithAutoIt(String filePath) throws IOException {
		setTimeOut(5000);
		String autoItExePath = System.getProperty("user.dir") + File.separator + "FIleUpload.exe";
		setTimeOut(2000);
		String command = "\"" + autoItExePath + "\" \"" + filePath + "\"";
		setTimeOut(4000);
		Runtime.getRuntime().exec(command);
	}

	public void uploadPDFDocument(String file) {
		try {
			Log.info("Upload enrollment Document");
			documentsPage.uploadFile(file);
			setTimeOut(5000);
			waitForPresenceOfElementLocated(doneButton);
			setTimeOut(7000);
			click(doneButton);
			LoggingInfo("Successfully uploaded document");
			Assert.assertTrue(true, "Successfully uploaded document ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to upload document " + e.getMessage());
			Assert.fail("Failed to upload document" + e.getMessage());
		}
	}

	/**
	 * Function: Login as System Admin User
	 *
	 * @author Anand Pawar
	 */

	public void loginAsSystemAdmin(String docID, String filePath) {
		Logger("STEP 1: After Submitting the Documents from the Dupix Portal, Now Log in org As DIS User");
		navigateToSFUrl();
		boolean homepage = dupixentPortal.verifyLoginScreen();
		loginPage = GetInstance(LoginPage.class);
		if (homepage) {
			homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		} else {
			documentsPage.logout();
			homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		}
		homeportalPage.closeTabs();

		Logger("STEP 2: Open ICARE Connect App from the App launcher and navigate to recieved document object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		documentsPage.verifyRecentlyViewDocumentList();
		documentsPage.navigateToAllReceivedDocPMUser();
		documentsPage.openDocumentFromAllRecivedDocList(docID);
		fileName = documentsPage.getFileName(filePath);
		documentsPage.verifyRecordAndClick(fileName);
		setTimeOut(2000);
		documentsPage.changeOwner();

		Logger("STEP 3: User Logout the Application.");
		documentsPage.logout();

		loginAsDISUser();

	}

	/**
	 * Function: Login as System Admin User to Validate Error
	 *
	 * @author Sonica P
	 */

	public void loginAsSystemAdmintoValidateError(String docID, String filePath) {
		Logger("STEP 1: After Submitting the Documents from the Dupix Portal, Now Log in org As DIS User");
		navigateToSFUrl();
		boolean homepage = dupixentPortal.verifyLoginScreen();
		loginPage = GetInstance(LoginPage.class);
		if (homepage) {
			homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		} else {
			documentsPage.logout();
			homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		}
		homeportalPage.closeTabs();

		Logger("STEP 2: Open ICARE Connect App from the App launcher and navigate to recieved document object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

		documentsPage.verifyRecentlyViewDocumentList();
		documentsPage.navigateToAllReceivedDoc();

		documentsPage.openDocumentFromAllRecivedDocList(docID);
		fileName = documentsPage.getFileName(filePath);
		documentsPage.verifyRecordAndClick(fileName);

		validateError();
		documentsPage.changeOwner();

		Logger("STEP 3: User Logout the Application.");
		documentsPage.logout();

		loginAsDISUser();

	}

	public void RelaunchPortalInIncognito() {
		try {
			EdgeOptions option = new EdgeOptions();
			option.addArguments("inprivate");
			setDriver(new EdgeDriver(option));
			loginPage = GetInstance(LoginPage.class);
			setTimeOut(3000);
			String baseUrl = Configuration.readApplicationFile("DupixentMyWayPortalURL");
			getWebDriver().navigate().to(baseUrl);
			waitForPageLoaded();
			setTimeOut(2000);

			LoggingInfo("verified cookies settings message ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify cookies settings message  " + e.getMessage());
			Assert.fail("Failed to verify cookies settings message  " + e.getMessage());
		}
	}

	public String uploadDocAWS(String filePath, String[] cpeDetails, String testCaseNumber) {
		setUp();
		String documentID = "";

		try {
			if (uploadType.equalsIgnoreCase("AWS_Workaround")) {

				String pName = cpeDetails[0];
				String pDOB = cpeDetails[1];
				String pEmail = cpeDetails[2];

				String[] cpEDetails = { pName, pDOB, pEmail };
				Logger("Launch the dupixent My way Portal URL for QA/Val org'.");
				navigateToDupxientUrl();

				Logger("Once URL is launched, from the welcome a Pop up is displayed Click on \"I am a Patient or Caregiver\" button.");
				// dupixentPortal.clickOnAcceptAllCookies();
				dupixentPortal.clickOnPatientorCaregiverButton();

				Logger("Click the \"Upload Document\" button in the home page.");
				dupixentPortal.clickOnUploadDocButton();

				Logger("In the next page Enter Enrollment code and submit it.");
				dupixentPortal.enterAccessCode("8443879370");
				dupixentPortal.clickOnSubmitCodeButton();

				Logger("Enter the details Patient Information section and submit enrollment Form");
				dupixentPortal.enterPatientInfo(cpEDetails);
				dupixentPortal.clickOnSubmitDocCheckBox();
				dupixentPortal.clickOnConsentCheckBoxes();
				dupixentPortal.clickOnUploadFileButton();
				uploadPDFDocument(filePath);
				dupixentPortal.clickOnSubmitButton();

				documentID = dupixentPortal.getDocumentID();

				writeDocumentIdToExcel(filePath, testCaseNumber, documentID);

			} else
				System.out.println("Invalid upload Type selection");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Upload activity failed " + e.getMessage());
		}

		return documentID;

	}

	private void writeDocumentIdToExcel(String filePath, String testCaseNumber, String documentID) {
		FileInputStream file = null;
		FileOutputStream outFile = null;
		Workbook workbook = null;
		Sheet sheet = null;

		try {

			String testDataFilePath = System.getProperty("user.dir") + "/TestData/EnrollmentFormTestData.xlsx";

			File excelFile = new File(testDataFilePath);
			file = new FileInputStream(excelFile);
			workbook = new XSSFWorkbook(file);

			sheet = workbook.getSheetAt(1);

			int testCaseRowNumber = Integer.parseInt(testCaseNumber.replaceAll("[^0-9]", ""));

			Row row = sheet.getRow(testCaseRowNumber);
			if (row == null) {
				row = sheet.createRow(testCaseRowNumber); // Create a new row if it doesn't exist
			}

			Cell cell = row.getCell(80);
			if (cell == null) {
				cell = row.createCell(80);
			}
			cell.setCellValue(documentID);

			String fileName = documentsPage.getFileName(filePath);
			cell = row.getCell(81);
			if (cell == null) {
				cell = row.createCell(81);
			}
			cell.setCellValue(fileName);

			outFile = new FileOutputStream(excelFile);
			workbook.write(outFile);

		} catch (IOException e) {
			e.printStackTrace();
			Log.error("Failed to write document ID to Excel: " + e.getMessage());
		} finally {
			try {
				if (file != null) {
					file.close();
				}
				if (outFile != null) {
					outFile.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Function: Login as program manager
	 *
	 * @author Anand Pawar
	 */

	public void loginAsPMUser(String docID, String fileName) {
		Logger("STEP 1: After Submitting the Documents from the Dupix Portal, Now Log in org As DIS User");
		navigateToSFUrl();
		boolean homepage = dupixentPortal.verifyLoginScreen();
		loginPage = GetInstance(LoginPage.class);
		if (homepage) {
			homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		} else {
			documentsPage.logout();
			homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		}
		homeportalPage.closeTabs();

		Logger("STEP 2: Open ICARE Connect App from the App launcher and navigate to recieved document object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

		documentsPage.verifyRecentlyViewDocumentList();
		documentsPage.navigateToAllReceivedDoc();

		documentsPage.searchDocument(fileName);
		documentsPage.verifyRecordAndClick(fileName);

		documentsPage.changeOwner();

		Logger("STEP 3: User Logout the Application.");
		documentsPage.logout();

		loginAsDISUser();

	}

	public void uploadFileWithSendKeys(String filePath) throws InterruptedException {
		By fileInputLocator = By.xpath("//input[@type='file']");
		scrollToElement(fileInputLocator);
		WebElement fileInput = getWebDriver().findElement(fileInputLocator);
		fileInput.sendKeys(filePath);
		waitForPresenceOfElementLocated(doneButton);
		setTimeOut(7000);
		waitAndVerifyElement(greenTickIcon);
		click(doneButton);
		setTimeOut(1000);
		LoggingInfo("Successfully uploaded document");
		Assert.assertTrue(true, "Successfully uploaded document ");

	}

	
}
