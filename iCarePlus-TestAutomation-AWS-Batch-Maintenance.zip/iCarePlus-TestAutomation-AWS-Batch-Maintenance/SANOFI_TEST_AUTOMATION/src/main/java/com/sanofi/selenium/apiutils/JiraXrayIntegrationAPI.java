package com.sanofi.selenium.apiutils;

import static io.restassured.RestAssured.given;


import java.io.*;
import java.time.Instant;
import java.util.Base64;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpHeaders;

import org.testng.Assert;


import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sanofi.selenium.constants.APIConstants;
import com.sanofi.selenium.core.ReadXmlConfiguration;
import com.sanofi.selenium.core.Utility_Function;

import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;

public class JiraXrayIntegrationAPI implements APIConstants {

	/**
	 * Function: To Get the Access token for hitting the xray API
	 * 
	 * @author Pratiksha Dixit
	 * @param payload
	 * @return API response: Access token
	 */
	public String getXrayAutheticationToken() throws Exception {
		String token = "";
		String payloadForXray = "{\r\n" + "\"client_id\": \"" + constXrayClientID + "\",\r\n"
				+ "    \"client_secret\": \"" + constXrayClientSecret + "\"\r\n" + "}";
		try {
			String response = given().header("Content-Type", "application/json").body(payloadForXray).when()
					.post(constXrayJIRAEndURI + "/authenticate").then().assertThat().statusCode(200).extract()
					.response().asPrettyString().toString();
			token = response.substring(1, response.length() - 1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return token;
	}

	/**
	 * Function: Update Execution Cycle issue type in xray jira by passing
	 * testng-result.xml file
	 * 
	 * @author Pratiksha Dixit
	 * @param filename,acccesstoken,project key and execution key
	 */
	public void xrayUpdateTestRun(File filename, String response, String projectKey, String execKey) throws Exception {
		try {
			String importResponse = given().header("Authorization", "Bearer " + response)
					.header("Content-Type", "text/xml").body(filename).when()
					.post(constXrayJIRAEndURI + "/import/execution/testng?projectKey=" + projectKey + "&testExecKey="
							+ execKey)
					.then().assertThat().statusCode(200).extract().response().asPrettyString().toString();

			JsonPath js = new JsonPath(importResponse);
			Assert.assertTrue(js.getString("key").equals(execKey));
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Function: To hit the Xray api and update the execution status along with
	 * evidence in jira execution issue type
	 * 
	 * @author Pratiksha Dixit
	 * @param accessToken,Execution Key,TestPlanKey,Hashmap(Jirakey and status
	 *                              values)
	 */
	public void updateAutomatedResultInXrayExecutionCycleViaAPI(String jiraAccessToken, String jiraExecutionKeys,
			String testPlanKey, String testKey, String statusValue, String evidencePath, String commentValue)
			throws IOException {
		ReentrantLock lock = new ReentrantLock();
		try {
			lock.lock();
			String evidences[] = evidencePath.split(",");
			JsonArray evidencesJson = new JsonArray();
			Instant instant = Instant.now();
			String startTime = instant.toString();
			Utility_Function.setTimeOut(10000);
			Instant instant1 = Instant.now();
			String finishTime = instant1.toString();

			for (int i = 0; i < evidences.length; i++) {
				File evidenceFile = new File(evidences[i]);
				byte[] filecontent = FileUtils.readFileToByteArray(evidenceFile);
				String encoded_FileContent = Base64.getEncoder().encodeToString(filecontent);
				JsonObject evidence = new JsonObject();
				evidence.addProperty("data", encoded_FileContent);
				evidence.addProperty("filename", evidenceFile.getName());
				evidence.addProperty("contentType", "application/html");
				evidencesJson.add(evidence);
			}
			JsonObject json = new JsonObject();
			JsonObject test1 = new JsonObject();
			json.addProperty("testExecutionKey",jiraExecutionKeys);
			JsonArray testArray = new JsonArray();
			JsonObject test;

			if (testKey != "") {
				String[] keyValue = testKey.split(",");
				for (int i = 0; i < keyValue.length; i++) {
					test = new JsonObject();
					test.addProperty("testKey", keyValue[i]);
					test.addProperty("start", startTime);
					test.addProperty("finish", finishTime);
					test.addProperty("comment", commentValue);
					test.addProperty("status", statusValue);
					test.add("evidences", evidencesJson);
					testArray.add(test);

					/*
					 * test1.addProperty("testPlanKey", testPlanKey); json.add("info", test1);
					 */

				}
				System.out.println("This is JIRA access token "+ jiraAccessToken);
				System.out.println("Reached start of JIRA execution");
				json.add("tests", testArray);
				String payloadForExecution = json.toString();
				System.out.println("Started API");
				String importResponse = given().header("Authorization", "Bearer " + jiraAccessToken)
						.header("Content-Type", "application/json").header(HttpHeaders.CONNECTION, "close")
						.body(payloadForExecution).when().post(constXrayJIRAEndURI + "/import/execution").then()
						.statusCode(200).extract().response().asString();

				JsonPath js = new JsonPath(importResponse);
				String keyJIRAresult=js.getString("key");
				System.out.println(importResponse);
				System.out.println(keyJIRAresult);
				Assert.assertTrue(keyJIRAresult.equalsIgnoreCase(jiraExecutionKeys));
				System.out.println("Reached To End JIRA execution");
			}
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			lock.unlock();
		}
	}

}
