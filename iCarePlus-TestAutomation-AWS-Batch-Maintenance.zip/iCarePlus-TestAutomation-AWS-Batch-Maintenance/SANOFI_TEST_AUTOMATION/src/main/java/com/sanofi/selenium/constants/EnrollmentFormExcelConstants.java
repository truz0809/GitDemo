package com.sanofi.selenium.constants;

import java.util.ArrayList;
import java.util.Arrays;

public interface EnrollmentFormExcelConstants extends ExcelTestDataConstants {

	public static final ArrayList<String> patientInfoInputBoxesExcel = new ArrayList<>(Arrays.asList(patientName,
			language, patientAddress, city, state, zip, patientEmail, legalRepresentativeName, legalrelationship));

	public static final ArrayList<String> patientInfoCheckBoxesExcel = new ArrayList<>(
			Arrays.asList(textMessagingConsent, text, voicemail, bestTimingAM, bestTimingAfternoon, bestTimingPM));

	public static final ArrayList<String> patientInsuranceInputBoxesExcel = new ArrayList<>(
			Arrays.asList(rxPayerName, rxPolicyID, rxGroup, rxBIN, rxPCN, medicalPayerName, medicalPolicyID,
					medicalGroup, policyholderName, insrelationshipToPatient, specialtyPharmacyName));

	public static final ArrayList<String> patientInsuranceCheckBoxesExcel = new ArrayList<>(
			Arrays.asList(patienthasNOInsurance, dUPIXENTMyWay, preferredSpecialtyPharmacy));

	public static final ArrayList<String> prescriberInputBoxesExcel = new ArrayList<>(
			Arrays.asList(prescriberName, specialty, prescriberAddress, prescriberCity, prescriberState, prescriberZip,
					prescriberNPI, sitefacilityname, officeContactName, officeContactEmail, taxID));

	public static final ArrayList<String> prescriptionInfoInputBoxesExcel = new ArrayList<>(Arrays.asList(patientName,
			prescriberName, prescriberAddress, prescriberNPI, prescriptionARefillCaptured, prescriptionBRefillCaptured,
			aKnownDrugAllergies, bKnownDrugAllergies, collaboratingMDName, NursePractitionerNPI));

	public static final ArrayList<String> prescriptionInfoCheckBoxesExcel = new ArrayList<>(
			Arrays.asList(aSampleProvided, aPrefilledSyringe, aPrefilledPen, prescription5BQuickStart, bSampleProvided,
					bPrefilledSyringe, bPrefilledPen));

	public static final ArrayList<String> weightExcel = new ArrayList<>(Arrays.asList(aWeight, bWeight));
}