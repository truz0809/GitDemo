package com.sanofi.selenium.pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class FreeGoodsPage extends Utility_Function {
	public FreeGoodsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	/************************* Elements *************************/
	 
	public static By eleParentCampaign = By.xpath(
			"(//*[text()='Parent Campaign']//ancestor::thead//following-sibling::tbody//*[@data-label=\"Parent Campaign\"]//a)[1]");
	public static String strCPERecord = "(//*[contains(@class,\"wsTabset oneConsoleTabset\")]//*[contains(@class,\"tabBarItems\")]//*[contains(@title,\"{0}\")])[1]";
	// public static By eleParentCampaign = By.xpath("(//span[text()='Campaign
	// Name']//ancestor::thead//following-sibling::tbody//th//a)[1]");
	public static By eleChildCampaign = By.xpath("(//*[@title='Child Campaign'])[1]");
	public static By eleCampaignNameInput = By
			.xpath("//*[text()=\"Campaign Name\"]//parent::label//parent::div//input");
	public static By eleDescription = By.xpath("//*[text()=\"Description\"]//parent::label//parent::div//textarea");
	public static By eleMasterCorrespondence = By
			.xpath("//*[text()=\"Master Correspondence\"]//parent::label//parent::div//input");
	public static By eleSave = By.xpath("//*[contains(@class, 'modal-footer')]//*[text()=\"Save\"]//parent::button");
	public static By elechildcampaignrecord = By.xpath(
			"(//*[@Title='Campaign Name' and @class='initialSortAsc ascending']//ancestor::thead//following-sibling::tbody//div//a)[1]");
	public static By eleCampaignName = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Campaign Name\"]//parent::div//following-sibling::div//span//span");
	public static By eleCampaignType = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Type\"]//parent::div//following-sibling::div//span//span");
	public static By eleTherapeuticArea = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Therapeutic Area\"]//parent::div//following-sibling::div//span//span");
	public static By eleInitiateCampaign = By.xpath("(//*[@title='Initiate Campaign']//parent::a)[1]");
	public static By eleAddCampaign = By.xpath("(//*[@title='Add Campaign Members']//parent::a)[1]");
	public static By eleEndCampaign = By.xpath("(//*[@title='End Campaign']//parent::a)[1]");
	public static By eleMessage = By.xpath(
			"//*[text()='Compaign Process Started.']");
	public static By eleMessage2=By.xpath("//*[text()='Please click on \"Add Campaign members\" so that Campaign Members can be added, post that Start the Campaign by clicking on \"Initiate Campaign\".']");
	public static By eleFinish = By.xpath("//*[text()='Finish']//parent::button");
	public static By eleBtnSave = By.xpath("//*[@title='Save']");
	public static By elerecParentCampaign = By.xpath("(//*[contains(@class, \"active lafPageHost\")]//table//tbody/tr/td[2]//a)[1]");
	public static By eleCampaignNameField = By
				.xpath("//*[text()='Campaign Name']//parent::label//following-sibling::input");
	public static By eleCampaigDescriptionField = By
				.xpath("//*[text()='Description']//parent::label//following-sibling::textarea");
	public static By strSuccess = By.xpath("//lightning-formatted-text[text()=\"Testing\"]");
	/************************* Dynamic Elements *************************/
 
	public static String strTextBoxesInput = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
 
	public static String strMaterCorrespondenceDropdown = "//*[text()=\"Master Correspondence\"]//parent::label//following-sibling::div//div[@role=\"listbox\"]//li//div[@title=\"{0}\"]";
	public static String strDateFields = "//*[text()=\"{0}\"]//parent::label//following-sibling::div//input";
 
	public static String caseRadioButton = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-form\")]//*[text()=\"{0}\"]//parent::label//*[contains(@class,\"slds-radio\")]";
	public static String eleButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";
	public static String eleBtn = "//*[contains(@class, \"active lafPageHost\")]//*[@title=\"{0}\"]";
	public static String strFields = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"])[1]";
	public static String strCombobox = "//*[@class='select-options']//ul/li/a";
	public static String strInput = "//*[contains(@class, \"active lafPageHost\")]//*[text()=\"{0}\"]//parent::span//following-sibling::div//child::a";
	public static String strmembers = "//*[contains(@class, \"active lafPageHost\")]//tbody//tr//td[3]";
	public static String strcampaignrec = "//*[contains(@class, \"active lafPageHost\")]//tbody//*[@data-aura-class='forceOutputLookupWithPreview']/a";
 

	public String verifyParentCampaignRecord() {
		String parentName="";
		
		try {
			waitForPageLoaded();
			setTimeOut(3000);
			waitAndVerifyElement(eleParentCampaign);
			setTimeOut(2000);
			
			By eleTitle=By.xpath("(//*[text()='Parent Campaign']//ancestor::thead//following-sibling::tbody//*[@data-label=\"Parent Campaign\"]//a//span)[1]");
			 parentName=getText(eleTitle);
			
			LoggingInfo("Parent Campaign verified successfuly");
			setTimeOut(2000);
			click(eleParentCampaign);
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to verify Parent Campaign " + e.getMessage());
			Assert.fail("Failed to verify Parent Campaign " + e.getMessage());
		}
		return parentName;

	}

	public void verifyCreateChildCampaignButton() {
		try {
			waitForPageLoaded();
			setTimeOut(3000);
			waitAndVerifyElement(eleChildCampaign);
			setTimeOut(2000);
			LoggingInfo("Child Campaign button verified successfuly");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to verify Child Campaign button " + e.getMessage());
			Assert.fail("Failed to verify child Campaign button " + e.getMessage());
		}
	}

	public void clickOnChildCampaign() {
		try {
			waitForPageLoaded();
			setTimeOut(3000);
			click(eleChildCampaign);
			setTimeOut(2000);
			LoggingInfo("clicked on child campaign");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to click on child Campaign " + e.getMessage());
			Assert.fail("Failed to click on child Campaign" + e.getMessage());
		}
	}

	public void createChildCampain(String channel, String masterCorrespondencefields) {
		try {

			waitAndVerifyElement(eleCampaignNameInput);
			clearText(eleCampaignNameInput);
			setTimeOut(2000);
			inputText(eleCampaignNameInput, "Child" + channel);
			setTimeOut(2000);
			LoggingInfo("Enters Campaign Name");
			setTimeOut(2000);

			waitAndVerifyElement(eleDescription);
			clearText(eleDescription);
			setTimeOut(2000);
			inputText(eleDescription, "Test" + channel);
			setTimeOut(2000);
			LoggingInfo("Enters Description");
			setTimeOut(2000);

			waitAndVerifyElement(eleMasterCorrespondence);
			click(eleMasterCorrespondence);
			setTimeOut(2000);
			inputText(eleMasterCorrespondence, masterCorrespondencefields);
			setTimeOut(2000);
			By eleMasterCorrespondenceOption = getDynamicElement(strMaterCorrespondenceDropdown,
					masterCorrespondencefields);
			setTimeOut(2000);
			click(eleMasterCorrespondenceOption);
			setTimeOut(1000);
			LoggingInfo("Enters Mater Correspondence");
			setTimeOut(2000);

			DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			Date dateobj = new Date();
			By eleStartDate = getDynamicElement(strDateFields, "Start Date");

			waitAndVerifyElement(eleStartDate);
			setTimeOut(2000);
			inputText(eleStartDate, df.format(dateobj));
			LoggingInfo("Enters Start Date");
			setTimeOut(2000);

			By eleEndDate = getDynamicElement(strDateFields, "End Date");

			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(new Date()); // Using today's date
			c.add(Calendar.DATE, 5); // Adding 5 days
			String enddate = sdf.format(c.getTime());

			waitAndVerifyElement(eleEndDate);
			setTimeOut(2000);
			inputText(eleEndDate, enddate);
			LoggingInfo("Enters End Date");
			setTimeOut(2000);

			click(eleSave);
			LoggingInfo("clicks on save");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to Create child campaign " + e.getMessage());
			Assert.fail("Failed to Create child campaign " + e.getMessage());
		}
	}

	public void verifychildCampaignName(String parent) {
		try {
			String parentName=parent;
 	        String currentDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

			waitForPageLoaded();
			waitAndVerifyElement(elechildcampaignrecord);
			setTimeOut(1000);			
			
			String text = getText(elechildcampaignrecord);
			String actualText=text.trim();
			  String channel = actualText
			            .replace(parentName, "")            
			            .replace(currentDate, "")           
			            .trim(); 

	        String expectedText = parentName + " " + channel + " " + currentDate;
			
	        if (actualText.equals(expectedText)) {
	            System.out.println("Match: " + actualText);
	        } else {
	            System.out.println("Mismatch");
				Log.error("Name not matching as expected ");
				  System.out.println("Expected: " + expectedText);
		          System.out.println("Actual  : " + actualText);
	        }
					
		
			click(elechildcampaignrecord);
			setTimeOut(2000);
			LoggingInfo("verified child campaign Name");
			setTimeOut(2000);

		} catch (Exception e) {
			
			Log.error("Failed to verify child Campaign Name " + e.getMessage());
			Assert.fail("Failed to verify child Campaign Name" + e.getMessage());
		}
	}

	public void verifyChildCampaignFields() {
		try {
			waitForPageLoaded();
			setTimeOut(1000);
			waitAndVerifyElement(eleCampaignName);
			scrollToElement(eleCampaignName);
			LoggingInfo("verified campaign Name");
			setTimeOut(2000);

			waitAndVerifyElement(eleCampaignType);
			LoggingInfo("verified campaign Type");
			setTimeOut(2000);

			waitAndVerifyElement(eleTherapeuticArea);
			LoggingInfo("verified Therapeutic area");
			scrollToElement(eleTherapeuticArea);
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to verify child Campaign fields" + e.getMessage());
			Assert.fail("Failed to verify child Campaign fields" + e.getMessage());
		}
	}

	public void verifyaddCampaignMembersAndEndCampaign() {
		try {
		//	waitAndVerifyElement(eleAddCampaign);
			setTimeOut(1000);
			LoggingInfo("verified add campaign");

			waitAndVerifyElement(eleEndCampaign);
			setTimeOut(1000);
			LoggingInfo("verified end campaign");

		} catch (Exception e) {
			Log.error("Failed to verify add campaign and end campaign  " + e.getMessage());
			Assert.fail("Failed to verify add campaign and end campaign " + e.getMessage());
		}
	}
	
	
	/* 
	 * Function : Verify start date of compaign
	 * 
	 * @Author - Anand Pawar
	 * 
	 */
	public void verifyActualStartDateOfCompaign() {
		try {
			By eleDate=By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Actual Start Date\"]//parent::div//following-sibling::div//span//span");
			waitAndVerifyElement(eleDate);
            scrollToElement(eleDate);
			setTimeOut(1000);
			LoggingInfo("verified Start Date");

		} catch (Exception e) {
			Log.error("Failed to verify start date " + e.getMessage());
			Assert.fail("Failed to verify start Date " + e.getMessage());
		}
	}

	public void verifyInitiateCampaign() throws Exception {
		try {
			waitAndVerifyElement(eleInitiateCampaign);
			scrollToElement(eleInitiateCampaign);
			setTimeOut(1000);
			clickByJavascript(eleInitiateCampaign);
			LoggingInfo("verified to initiate campaign");
			setTimeOut(2000);
			try {
				List<WebElement> msgElements = getWebDriver().findElements(eleMessage);

				if (!msgElements.isEmpty() && msgElements.get(0).isDisplayed()) {
				    System.out.println("Message is present: Campaign has started.");
				    verifyActualStartDateOfCompaign();
				}
			}catch(NoSuchElementException e) {
				System.out.println("Add campaign member message is present");
			}
			setTimeOut(2000);
			LoggingInfo("Verified message");
 
		} catch (NoSuchElementException e) {
			System.out.println("Add campaign member message is present");
		}
	}
	
	
	/**
	 * Function: Click on New button
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void clickOnFinishBtn() {
		try {
			
			setTimeOut(5000);
 			clickByJavascript(eleFinish);
			LoggingInfo("Clicked on New Button");
			;
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on New Button " + e.getMessage());
			Assert.fail("Failed to Click on New Button " + e.getMessage());

		}
	}

	/**
	 * Function: Click on New button
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void clickOnNewButton() {
		try {
			
			setTimeOut(5000);
			By eleNewBtn = getDynamicElement(eleBtn, "New");
			click(eleNewBtn);
			LoggingInfo("Clicked on New Button");
			;
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on New Button " + e.getMessage());
			Assert.fail("Failed to Click on New Button " + e.getMessage());

		}
	}

	/**
	 * Function: Click on save button
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void clickOnSave() {
		try {
			
			setTimeOut(2000);
			click(eleBtnSave);
			Log.info("Clicked on Save Button.");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on Save Button " + e.getMessage());
			Assert.fail("Failed to Click on Save Button " + e.getMessage());
		}

	}

	/**
	 * Function: select Campaign from New Campaign page
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void selectNewCampaignChildORParent(String campaignType) throws Exception {
		try {
			Log.info("Verify user is able to select Radio button for New Campaign");
			By eleParentNewCamp = getDynamicElement(caseRadioButton, campaignType);
			click(eleParentNewCamp);
			setTimeOut(3000);

			Log.info("Verify user is able to click on Next button");
			By eleNextButton = getDynamicElement(eleButton, "Next");
			waitAndVerifyElement(eleNextButton);
			scrollToElement(eleNextButton);
			click(eleNextButton);
			setTimeOut(2000);
			LoggingInfo(campaignType + " Campaign selected from the New Campaign Page.");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select New Campaign option " + e.getMessage());
			Assert.fail("Failed to select New Campaign option " + e.getMessage());
		}

	}

	/**
	 * Function: Validate page layout fields for Master Campaign
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateMasterCampaignPageLayout() {
		try {
			
			String[] fieldsToValidate = { "Campaign Name", "Campaign Purpose", "Start Date", "Description", "Year",
					"Status", "End Date", "Created By", "Therapeutic Area", "Last Modified By", "Campaign Owner" };
			for (String field : fieldsToValidate) {
				By eleCampaignName = getDynamicElement(strFields, field);
				boolean FldPresent = verifyElement(eleCampaignName);
				if (FldPresent) {
					Assert.assertTrue(FldPresent, field + " Field is present on PageLayout.");
					LoggingInfo(field + " Field is present on PageLayout.");
				} else {
					Assert.fail(field + "Field is not present on layout.");
					LoggingInfo(field + " Field is not present on PageLayout.");
				}

			}
			LoggingInfo("Fields on Master Campaign Page Layout Validated.");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Validate Master Campaign page Layout " + e.getMessage());
			Assert.fail("Failed to Validate Master Campaign page Layout " + e.getMessage());
		}

	}

	/**
	 * Function: Open existing Parent Campaign record from Recntly Viewed list
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void openMasterCampaignRecord() {
		try {
			setTimeOut(2000);
			clickByJavascript(elerecParentCampaign);
			LoggingInfo("Clicked on Parent Campaign Record.");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Open Parent Campaign Record " + e.getMessage());
			Assert.fail("Failed to Open Parent Campaign Record " + e.getMessage());
		}
	}

	/**
	 * Function: Fill all the feidls and create Master Campaign
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void createParentCampaign(String campName, String description, String parentCampaignStatus, String year)
			throws Exception {
		try {
			inputText(eleCampaignNameField, campName);
			setTimeOut(2000);

			scrollToElement(eleCampaigDescriptionField);
			inputText(eleCampaigDescriptionField, description);

			By fldYearInput = getDynamicElement(strInput, "Year");
			scrollToElement(fldYearInput);
			click(fldYearInput);
			setTimeOut(2000);
			List<WebElement> eles = getWebDriver().findElements(By.xpath(strCombobox));
			for (WebElement ele : eles) {
				if (ele.getText().contains(year)) {
					ele.click();
					break;
				}
			}
			setTimeOut(2000);
			By fldStatusInput = getDynamicElement(strInput, "Status");
			scrollToElement(fldStatusInput);
			click(fldStatusInput);
			setTimeOut(2000);
			List<WebElement> elesStatus = getWebDriver().findElements(By.xpath(strCombobox));
			for (WebElement elestatus : elesStatus) {
				if (elestatus.getText().contains(parentCampaignStatus)) {
					elestatus.click();
					break;
				}
			}
			setTimeOut(3000);
			LoggingInfo("Master Campaign Fields entered on the page layout");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to create Master Campaign Record " + e.getMessage());
			Assert.fail("Failed to create Master Campaign Record " + e.getMessage());
		}

	}

	/**
	 * Function: Verify Success message for Master Campaign creation
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateParentCampaignCreated() {
		try {	
			refresh();
			if (verifyElement(strSuccess)) {
				highLightElement(strSuccess);
				LoggingInfo("Master Campaign record is created successfully.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to create Master Campaign Record " + e.getMessage());
			Assert.fail("Failed to create Master Campaign Record " + e.getMessage());
		}
	}

	
	/**
	 * Function: Validate if Child campaigns created
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateChildCampaignsCreated() throws Exception {
		try {
			List<WebElement> childCampaigns = getWebDriver().findElements(By.xpath(strcampaignrec));
			if (childCampaigns.size() > 0) {
				for (WebElement childCamp : childCampaigns) {
					String campaignName = childCamp.getText();
					if (campaignName.contains("Fax")) {
						LoggingInfo("Child Campaign is created for Fax");
					} else if (campaignName.contains("Email")) {
						LoggingInfo("Child Campaign is created for Email");
					} else if (campaignName.contains("Voice")) {
						LoggingInfo("Child Campaign is created for Phone");
					} else if (campaignName.contains("Direct Mail")) {
						LoggingInfo("Child Campaign is created for Direct Mail");
					}
				}
			} else {
				System.out.println("No Child campaign records were created");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Child campaigns created " + e.getMessage());
			Assert.fail("Failed to verify Child campaigns created " + e.getMessage());
		}

	}

	/**
	 * Function: Click and open child campaign records
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void openChildCampaignMember(String childCampName) {
		List<WebElement> childCampaigns = getWebDriver().findElements(By.xpath(strcampaignrec));
		for (WebElement childCamp : childCampaigns) {
			String campName = childCamp.getText().trim();

			if (campName.contains(childCampName)) {
				((JavascriptExecutor) getWebDriver()).executeScript(
						"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
						childCamp);
				childCamp.click();
				setTimeOut(2000);
				LoggingInfo("Clicked on " + campName + "Child Campaign");
				break;
			}

		}
	}

	/**
	 * Function:Verify if Campaign members added to child campaign
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyCampaignMembersAdded() {

		try {
			List<WebElement> eleCampaignMembers = getWebDriver()
					.findElements(By.xpath("//*[contains(@class, \"active lafPageHost\")]//tbody//tr"));
			if (eleCampaignMembers.size() == 0) {
				click(eleAddCampaign);
			}
			if (eleCampaignMembers.size() > 0) {
				LoggingInfo("Campaign Members have been added to Child Campaign");
			} else {
				LoggingInfo("No Campaign members added to Child Campaign");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Verify Campaign Members " + e.getMessage());
			Assert.fail("Failed to Verify Campaign Members " + e.getMessage());
		}

	}

	/**
	 * Function: Verify and click on Add Campaign Member button
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyaddCampaignMembers() {
		try {
			refresh();
			waitAndVerifyElement(eleAddCampaign);
			click(eleAddCampaign);
			setTimeOut(1000);
			LoggingInfo("Clicked on Add Campaign Members button");

		} catch (Exception e) {
			Log.error("Failed to verify add campaign and end campaign  " + e.getMessage());
			Assert.fail("Failed to verify add campaign and end campaign " + e.getMessage());
		}
	}

	

	public void navigateToCPERecord(String parentCampaign) {
		try {
			By cpeRecord = getDynamicElement(strCPERecord, parentCampaign);
			waitAndVerifyElement(cpeRecord);
			scrollToElement(cpeRecord);
			click(cpeRecord);
			setTimeOut(2000);
			LoggingInfo("Navigated to Care program enrollee record");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to CPE record-" + e.getMessage());
			Assert.fail("Failed to navigate to CPE record-" + e.getMessage());
		}
	}

	/**
	 * Function: Verify if Campaign Members and their status is displayed.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateCampaignMemberandStatusDisplayed() {
		try {
			
			By eletableCampaignMembers = By.xpath("//*[@title='Campaign Members']");
			click(eletableCampaignMembers);
			setTimeOut(2000);

			List<WebElement> campaignMembers = getWebDriver().findElements(By.xpath(strmembers));
			for (WebElement Member : campaignMembers) {
				String memberName = Member.getText();
				if (!memberName.isEmpty()) {
					WebElement eleMemberStatus = Member.findElement(By.xpath(".//following-sibling::td[4]"));
					String memberStatus = eleMemberStatus.getText();
					if (!memberStatus.isEmpty()) {
						LoggingInfo("Campaign Members and Campaign Member status are displayed.");
						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Validate Campaign Member and Status Field " + e.getMessage());
			Assert.fail("Failed to Validate Campaign Member and Status Field " + e.getMessage());
		}

	}

}
