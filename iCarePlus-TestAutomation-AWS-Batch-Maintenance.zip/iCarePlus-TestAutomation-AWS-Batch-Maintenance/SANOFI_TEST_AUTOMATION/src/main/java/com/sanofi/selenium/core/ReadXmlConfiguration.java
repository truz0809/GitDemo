package com.sanofi.selenium.core;

import org.testng.annotations.Test;
import org.testng.reporters.XMLConstants;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReadXmlConfiguration {

	private static final String FILENAME = "target/surefire-reports/testng-results.xml";
	Map<String, String> reportmap = new HashMap<String, String>();

	public Map<String, String> readXML() throws DOMException {

		// Instantiate the Factory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {

			// optional, but recommended
			// process XML securely, avoid attacks like XML External Entities (XXE)
			//dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

			// parse XML file
			DocumentBuilder db = dbf.newDocumentBuilder();

			Document doc = db.parse(new File(FILENAME));
			doc.getDocumentElement().normalize();

			System.out.println("Root Element :" + doc.getDocumentElement().getNodeName());
			System.out.println("------");

			// get <staff>
			NodeList list = doc.getElementsByTagName("test-method");

			for (int temp = 0; temp < list.getLength(); temp++) {

				Node node = list.item(temp);

				if (node.getNodeType() == Node.ELEMENT_NODE) {

					Element element = (Element) node;

					// get testng-results attribute
					String name = element.getAttribute("name");
					String status;
					if (!(name.equalsIgnoreCase("setUp") || name.equalsIgnoreCase("before")
							|| name.equalsIgnoreCase("tearDownSuite"))) {
						status = element.getAttribute("status");
						NodeList list1 = element.getElementsByTagName("attribute");
						for (int temp1 = 0; temp1 < list1.getLength(); temp1++) {
							Node node1 = list1.item(temp1);
							Element element1 = (Element) node1;
							String name1 = element1.getAttribute("name");
							if (name1.equalsIgnoreCase("test")) {
								reportmap.put(element1.getTextContent().trim(), status);

							}
						}
					}

				}

			}
			System.out.println(reportmap);
		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}
		return reportmap;

	}

}
