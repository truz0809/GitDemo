package com.sanofi.selenium.apiutils;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantLock;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;

import com.sanofi.selenium.constants.APIConstants;

import com.sanofi.selenium.core.Configuration;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.core.BaseTest;

import com.sanofi.selenium.enums.APIEnum;

import io.restassured.path.json.JsonPath;

public class Payload extends BaseTest {

	private static final String LOGINURL = null;

	/**
	 * Function: To setup and hit API for Marketing Website Form
	 * 
	 * @author Kruti Unnithan
	 * @param randNum1, randNum2, WebFormVal =
	 *                  Cablivi/Eloctate/Alprolix/CAD/Enjaymo, emailVal
	 * @return API response
	 */
	public static String apiSetupForMarketingWebsiteForm(int randNum1, int randNum2, APIEnum WebFormVal,
			String emailVal) {

		String constApiKeyValueMarketing = Configuration.readApplicationFile("API_Value_Marketing");// Modifier : Yuti
																									// Shah
		String constBasicAuthValueMarketing = Configuration.readApplicationFile("Basic_Auth_Marketing");// Modifier :
																										// Yuti Shah

		return given().header(APIConstants.constApiKey, constApiKeyValueMarketing)
				.header(APIConstants.constSourceSystemKey, APIConstants.constSourceSystemValueToCreateLead)
				.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
				.header(APIConstants.constBasicAuthKey, constBasicAuthValueMarketing)
				.body(Payload.payloadForMarketingWebsiteForm(randNum1, randNum2, WebFormVal, emailVal)).when()
				.post(marketing_Endpoint).then().assertThat().statusCode(200).extract().response().asPrettyString()
				.toString();
	}

	/**
	 * Function: To generate payload for Marketing Website Form
	 * 
	 * @author Kruti Unnithan
	 * @param randNum1, randNum2, WebFormVal =
	 *                  Cablivi/Eloctate/Alprolix/CAD/Enjaymo, emailVal
	 * @return Generated payload
	 */
	public static String payloadForMarketingWebsiteForm(int randNum1, int randNum2, APIEnum WebFormVal,
			String emailVal) {
		String payload = "{\r\n\t" + "\"FirstName\": \"a" + randNum1 + "pi" + randNum2 + "\",\r\n\t"
				+ "\"LastName\": \"a" + randNum1 + "test" + randNum2 + "\",\r\n\t" + "\"Email\": \"" + emailVal
				+ "\",\r\n\t" + "\"Birthday\": \"197" + randNum2 % 10 + "-" + "01-" + "1" + randNum2 % 10 + "\",\r\n\t"
				+ "\"PhoneNumber\": \"(988) 8" + randNum1 + "-" + randNum2 + "99\",\r\n\t"
				+ "\"PatientType\": \"Is Caregiver\",\r\n\t" + "\"WebformName\": \"" + WebFormVal + "\",\r\n\t"
				+ "\"Address1\": \"Mid Highway\",\r\n\t" + "\"Address2\": \"Epson Street\",\r\n\t"
				+ "\"City\": \"Manhattan\",\r\n\t" + "\"State\": \"NY\",\r\n\t" + "\"Zip\": \"1" + randNum1 + ""
				+ randNum2 % 10 + "1\",\r\n\t" + "\"SelectedGift\": \"Speaker\",\r\n\t"
				+ "\"PrivacyPolicyAgreement\": \"Yes\",\r\n\t" + "\"shareStory\": \"Yes\",\r\n\t"
				+ "\"Treatment\": \"On Demand\",\r\n\t" + "\"ContactType\": \"Email,Phone\",\r\n\t"
				+ "\"TSD\": \"No\"\r\n}";
		return payload;
	}

	/**
	 * Function: To setup and hit API for Marketing Website Unsubscribe
	 * 
	 * @author Kruti Unnithan
	 * @param WebFormVal = Cablivi/Eloctate/Alprolix/CAD/Enjaymo, emailVal
	 */
	public static void apiSetupForMarketingWebsiteUnsubscribe(String emailVal, APIEnum WebFormVal) {

		String constApiKeyValueMarketing = Configuration.readApplicationFile("API_Value_Marketing");// Modifier : Yuti
																									// Shah
		String constBasicAuthValueMarketing = Configuration.readApplicationFile("Basic_Auth_Marketing");// Modifier :
																										// Yuti Shah

		given().header(APIConstants.constApiKey, constApiKeyValueMarketing)
				.header(APIConstants.constSourceSystemKey, APIConstants.constSourceSystemValueToUnsubscribe)
				.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
				.header(APIConstants.constBasicAuthKey, constBasicAuthValueMarketing)
				.body(Payload.payloadForMarketingWebsiteUnsubscribe(emailVal, WebFormVal)).when()
				.post(marketing_Endpoint).then().assertThat().statusCode(200);

	}

	/**
	 * Function: To generate payload for Marketing Website Unsubscribe
	 * 
	 * @author Kruti Unnithan
	 * @param WebFormVal = Cablivi/Eloctate/Alprolix/CAD/Enjaymo, emailVal
	 * @return Generated payload
	 */
	public static String payloadForMarketingWebsiteUnsubscribe(String emailVal, APIEnum WebformVal) {

		return "{\r\n\r\n    " + "\"Email\": \"" + emailVal + "\",\r\n    " + "\"WebformName\": \"" + WebformVal
				+ "\"\r\n\r\n}";
	}

	/**
	 * Function: To execute SOQL query
	 * 
	 * @author Kruti Unnithan
	 * @param authVals0, authVals1, queryStatement
	 * @return Result set
	 */
	public static String queryExecution(String authVals0, String authVals1, String queryStatement) {

		return given().auth().oauth2(authVals1).when().get(authVals0 + "/query?q=" + queryStatement).then().extract()
				.response().asPrettyString().toString();
	}

	/**
	 * Function: To execute batch job
	 * 
	 * @author Kruti Unnithan
	 * @param authVals0, authVals1, batchCommand
	 */
	public static String batchExecution(String authVals0, String authVals1, String batchCommand) {
		String resp = "";
		try {
			resp = given().auth().oauth2(authVals1).when()
					.get(authVals0 + "/tooling/executeAnonymous/?anonymousBody=" + batchCommand).then().extract()
					.response().asPrettyString().toString();
			JsonPath js = new JsonPath(resp);
			boolean executionStatus = js.getBoolean("success");
			Assert.assertTrue(executionStatus);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Batch execution failed." + " Error - " + e.getMessage());
		}
		return resp;
	}

	/**
	 * Function: To setup and hit API for AssistRx
	 * 
	 * @author Chaithanya
	 * @param requestBody
	 * @return API response
	 */
	public static String postAPICallAssistRX(String payLoad) {
		String constApiKeyValue = Configuration.readApplicationFile("API_Value_AssistRx");
		String constBasicAuthValueAssistRX = Configuration.readApplicationFile("Basic_Auth_AssistRX");
		return given().header(APIConstants.constApiKey, constApiKeyValue)
				.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
				.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
				.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX).body(payLoad).when()
				.post(assistRx_Endpoint).then().assertThat().statusCode(200).extract().response().asString();
	}

	/**
	 * Function: To setup and hit API for AssistRx
	 * 
	 * @author Kruti Unnithan
	 * @param randNum1, randNum2, WebFormVal = Cablivi/Eloctate/Alprolix/CAD/Enjaymo
	 * @return API response
	 */
	public static String apiSetupForAssitRx(int randNum1, int randNum2, APIEnum WebFormVal, String viaType) {

		String constApiKeyValue = Configuration.readApplicationFile("API_Value_AssistRx");// Modifier : Yuti Shah
		String constBasicAuthValueAssistRX = Configuration.readApplicationFile("Basic_Auth_AssistRX");// Modifier : Yuti
																										// Shah

		if (viaType.equalsIgnoreCase("Copay")) {

			return given().header(APIConstants.constApiKey, constApiKeyValue)
					.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX)
					.body(Payload.payloadForAssitRxCoPay(randNum1, randNum2, WebFormVal)).when().post(assistRx_Endpoint)
					.then().assertThat().statusCode(200).extract().response().asString();
		} else if (viaType.equalsIgnoreCase("QuickStart")) {

			return given().header(APIConstants.constApiKey, constApiKeyValue)
					.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX)
					.body(Payload.payloadForAssitRxQS(randNum1, randNum2, WebFormVal)).when().post(assistRx_Endpoint)
					.then().assertThat().statusCode(200).extract().response().asString();
		} else {

			return given().header(APIConstants.constApiKey, constApiKeyValue)
					.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX)
					.body(Payload.payloadForAssitRxPAP(randNum1, randNum2, WebFormVal)).when().post(assistRx_Endpoint)
					.then().assertThat().statusCode(200).extract().response().asString();
		}
	}

	/**
	 * Function: To setup and hit API for AssistRx RD copay Enrollement with program
	 * case get created
	 * 
	 * @author Dipali Yadav
	 * @param randNum1, randNum2, WebFormVal = RD product-Lumizyme,Cerdelga etc.
	 * @return API response
	 */
	public static String apiSetupForAssitRxRD(int randNum1, int randNum2, String zipCode, APIEnum WebFormVal,
			String viaType) {
		String APIResponse = null;

		String constApiKeyValue = Configuration.readApplicationFile("API_Value_AssistRx");// Modifier : Yuti Shah
		String constBasicAuthValueAssistRX = Configuration.readApplicationFile("Basic_Auth_AssistRX");// Modifier : Yuti
																										// Shah

		if (viaType.equalsIgnoreCase("Copay")) {
			APIResponse = given().header(APIConstants.constApiKey, constApiKeyValue)
					.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX)
					.body(Payload.payloadForAssitRxCoPayRD(randNum1, randNum2, zipCode, WebFormVal)).when()
					.post(assistRx_Endpoint).then().assertThat().statusCode(200).extract().response().asString();
		}
		if (viaType.equalsIgnoreCase("IAP")) {
			APIResponse = given().header(APIConstants.constApiKey, constApiKeyValue)
					.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX)
					.body(Payload.payloadForAssitRxIAPRDHCPPortal(randNum1, randNum2, zipCode, WebFormVal)).when()
					.post(assistRx_Endpoint).then().assertThat().statusCode(200).extract().response().asString();
			APIResponse = given().header(APIConstants.constApiKey, constApiKeyValue)
					.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX)
					.body(Payload.payloadForAssitRxIAPRDPatientPortal(randNum1, randNum2, zipCode, WebFormVal)).when()
					.post(assistRx_Endpoint).then().assertThat().statusCode(200).extract().response().asString();
		}
		if (viaType.equalsIgnoreCase("PAP")) {
			APIResponse = given().header(APIConstants.constApiKey, constApiKeyValue)
					.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX)
					.body(Payload.payloadForAssitRxPAPRDHCPPortal(randNum1, randNum2, zipCode, WebFormVal)).when()
					.post(assistRx_Endpoint).then().assertThat().statusCode(200).extract().response().asString();
			APIResponse = given().header(APIConstants.constApiKey, constApiKeyValue)
					.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX)
					.body(Payload.payloadForAssitRxPAPRDPatientPortal(randNum1, randNum2, zipCode, WebFormVal)).when()
					.post(assistRx_Endpoint).then().assertThat().statusCode(200).extract().response().asString();
		}
		if (viaType.equalsIgnoreCase("QuickStart")) {
			APIResponse = given().header(APIConstants.constApiKey, constApiKeyValue)
					.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX)
					.body(Payload.payloadForAssitRxQuickStartRDHCPPortal(randNum1, randNum2, zipCode, WebFormVal))
					.when().post(assistRx_Endpoint).then().assertThat().statusCode(200).extract().response().asString();
			APIResponse = given().header(APIConstants.constApiKey, constApiKeyValue)
					.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX)
					.body(Payload.payloadForAssitRxQuickStartRDPatientPortal(randNum1, randNum2, zipCode, WebFormVal))
					.when().post(assistRx_Endpoint).then().assertThat().statusCode(200).extract().response().asString();
		}
		return APIResponse;
	}

	/**
	 * Function: To setup and hit API for AssistRx RD copay Enrollement with program
	 * case get created
	 * 
	 * @author Dipali Yadav
	 * @param randNum1, randNum2, WebFormVal = RD product-Lumizyme,Cerdelga etc.
	 * @return API response
	 */
	public static String apiSetupForMCKesson(String MCKToken, String MCKPayload) {
		accessToken = MCKToken;
		String respo = given().auth().oauth2(accessToken)
				.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
				.header(APIConstants.constApiKey, mCK_ApiKey).body(MCKPayload).post(mCK_Endpoint_URL).then()
				.assertThat().statusCode(200).extract().response().asString();
		return respo;
	}

	/**
	 * Function: To setup and hit API for AssistRx RD copay Enrollement with program
	 * case get created
	 * 
	 * @author skumarsahu
	 * @param randNum1, randNum2, WebFormVal = RD product-Lumizyme,Cerdelga etc.
	 * @return API response
	 */
	public static String apiSetupForEnrollmentThroughMcKesson(String accessToken, int randNum1, int randNum2,
			String zipCode, String enrollDate, APIEnum WebFormVal) {
		String respo = given().auth().oauth2(accessToken)
				.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
				.header(APIConstants.constApiKey, mCK_ApiKey)
				.body(Payload.payloadForMcKessonCoPayEnrollment(randNum1, randNum2, zipCode, enrollDate, WebFormVal))
				.post(mCK_Endpoint_URL).then().assertThat().statusCode(200).extract().response().asString();
		return respo;
	}

	/**
	 * Function: To setup and hit API for Patient Response from AssistRx RD
	 * QuickStart Enrollment
	 * 
	 * @author skumarsahu
	 * @param randNum1, randNum2, WebFormVal = RD product-Lumizyme,Cerdelga etc.
	 * @return API response
	 */
	public static String apiSetupForPatientResponseForQS(String accessToken, int randNum1, int randNum2, String zipCode,
			APIEnum WebFormVal) {

		String constApiKeyValue = Configuration.readApplicationFile("API_Value_AssistRx");// Modifier : Yuti Shah
		String constBasicAuthValueAssistRX = Configuration.readApplicationFile("Basic_Auth_AssistRX");// Modifier : Yuti
																										// Shah
		return given().header(APIConstants.constApiKey, constApiKeyValue)
				.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
				.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
				.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX)
				.body(Payload.payloadForAssitRxPatientResponseQS(randNum1, randNum2, zipCode, WebFormVal)).when()
				.post(assistRx_Endpoint).then().assertThat().statusCode(200).extract().response().asString();
	}

	/**
	 * Function: To setup and hit API for Shipment and Invoice
	 * 
	 * @author skumarsahu
	 * @param randNum1, randNum2, Order ID.
	 * @return API response
	 */
	public static String apiSetupForShipmentAndInvoice(String accessToken, int randNum1, int randNum2, String orderID,
			String viaType) {
		if (viaType.equalsIgnoreCase("Shipment")) {

			String respo = given().auth().oauth2(accessToken)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.body(Payload.payloadForShipmentCreation(randNum1, randNum2, orderID))
					.post(LOGINURL + constOrderShipmentPathParms).then().assertThat().statusCode(201).extract()
					.response().asString();
			return respo;
		} else {

			String respo = given().auth().oauth2(accessToken)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.body(Payload.payloadForInvoiceCreation(randNum1, randNum2, orderID))
					.post(LOGINURL + constOrderInvoicePathParms).then().assertThat().statusCode(201).extract()
					.response().asString();
			return respo;
		}
	}

	/**
	 * Function: To generate payload for AssitRx CoPay
	 * 
	 * @author Yuti Shah
	 * @param randNum1, randNum2, WebFormVal = Cablivi/Eloctate/Alprolix/CAD/Enjaymo
	 * @return Generated payload
	 */

	public static String payloadForAssitRxCoPay(int randNum1, int randNum2, APIEnum WebFormVal) {
		return "{\r\n\t\t\"PatientParticipation\": false,\r\n\t\t" + "\"Consents\": [\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"HIPAA Authorization\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-25-02T00:00:00\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"chris10\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"Parent\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"HIPAA Authorization � Designee\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeLastName\": \"g10ayle\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-24-02T00:00:00\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"Patient Services Authorization\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-24-02T00:00:00\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"s10ignertestfullsign\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"eSignature And Records\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-24-02T00:00:00\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"Marketing Opt-In\",\r\n\t\t\t\t" + "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-24-02T00:00:00\"\r\n\t\t\t}\r\n\t\t],\r\n\t\t"
				+ "\"FinancialInformation\": \"\",\r\n\t\t" + "\"ExternalId\": \"\",\r\n\t\t"
				+ "\"Practice\": \"\",\r\n\t\t" + "\"Product\": \"" + WebFormVal + "\",\r\n\t\t"
				+ "\"Patient\": {\r\n\t\t\t" + "\"DateOfBirth\": \"199" + randNum2 % 10 + "-07-0" + randNum2 % 10
				+ "T00:00:00\",\r\n\t\t\t" + "\"Address\": {\r\n\t\t\t\t" + "\"AddressLine2\": \"\",\r\n\t\t\t\t"
				+ "\"AddressLine1\": \"add" + randNum2 + "r strret\",\r\n\t\t\t\t" + "\"State\": \"KS\",\r\n\t\t\t\t"
				+ "\"PostalCode\": 99945,\r\n\t\t\t\t" + "\"Country\": \"\",\r\n\t\t\t\t"
				+ "\"City\": \"kansas\"\r\n\t\t\t},\r\n\t\t\t" + "\"FirstName\": \"c" + randNum1 + "od" + randNum2
				+ "e\",\r\n\t\t\t" + "\"ExternalPatientId\": \"\",\r\n\t\t\t" + "\"Gender\": \"M\",\r\n\t\t\t"
				+ "\"MiddleName\": \"\",\r\n\t\t\t" + "\"EmailAddress\": \"" + randNum2 + "test@check.com" + randNum1
				+ "\",\r\n\t\t\t" + "\"Phones\": [\r\n\t\t\t\t{\r\n\t\t\t\t\t" + "\"Number\": 53463609" + randNum1 % 10
				+ "4,\r\n\t\t\t\t\t" + "\"PhoneType\": 3\r\n\t\t\t\t}\r\n\t\t\t],\r\n\t\t\t"
				+ "\"AuthorizedRepresentatives\": \"\",\r\n\t\t\t" + "\"PatientId\": \"64F3D901-0DCA-4F" + randNum2
				+ "-8" + randNum1 + "4-3BECB0C733C6\",\r\n\t\t\t" + "\"ParentGuardian\": {\r\n\t\t\t\t"
				+ "\"FirstName\": \"" + randNum1 + "john" + randNum2 + "\",\r\n\t\t\t\t" + "\"LastName\": \"" + randNum1
				+ "rhode" + randNum2 + "\"\r\n\t\t\t},\r\n\t\t\t" + "\"LastName\": \"Qa" + randNum2 + "R" + randNum1
				+ "\",\r\n\t\t\t" + "\"PreferredContactType\": 1,\r\n" + "\"SSN\": \"8976\"\r\n\t\t},\r\n\t\t"
				+ "\"PrescribingInformation\": {\r\n\t\t\t" + "\"PatientWeight\": 98,\r\n\t\t\t"
				+ "\"Frequency\": \"\",\r\n\t\t\t" + "\"Icd10\": \"\",\r\n\t\t\t"
				+ "\"PatientWeightUnit\": \"lbs\",\r\n\t\t\t" + "\"Dose\": \"\"\r\n\t\t},\r\n\t\t"
				+ "\"ArxId\": \"9BE17E-04-48A8-BC35-769881YY" + randNum2 + "\" ,\r\n\t\t" + "\"PbmInsurances\": [\r\n"
				+ "		{\r\n" + "			\"InsuranceId\": \"61a73d6b-0378-4b86-a19e-12f0d0cecbeb\",\r\n"
				+ "			\"RelationshipToMember\": null,\r\n" + "			\"Rank\": 1,\r\n"
				+ "			\"ProcessorControlNumber\": null,\r\n" + "			\"PolicyHolderBirthDate\": null,\r\n"
				+ "			\"PolicyHolderLastName\": null,\r\n" + "			\"InsuranceGroupNumber\": null,\r\n"
				+ "			\"PbmName\": \"Acara\",\r\n" + "			\"PolicyHolderFirstName\": null,\r\n"
				+ "			\"PlanType\": \"Commercial Plan\",\r\n"
				+ "			\"BankIdentificationNumber\": \"161461\",\r\n" + "			\"PhoneNumber\": null,\r\n"
				+ "			\"InsuranceMemberNumber\": null\r\n" + "		}\r\n" + "	],\r\n\t\t"
				+ "\"Source\": \"PES\",\r\n\t\t" + "\"Prescriber\": \"\",\r\n\t\t"
				+ "\"ServiceType\": \"ProgramEnrollment\",\r\n\t\t" + "\"PatientParticipationEmail\": \"\",\r\n\t\t"
				+ "\"Pharmacy\": \"\",\r\n\t\t" + "\"MedicalInsurances\": [\r\n" + "		{\r\n"
				+ "			\"PolicyHolderBirthDate\": null,\r\n" + "			\"PolicyHolderLastName\": null,\r\n"
				+ "			\"InsuranceGroupNumber\": \"161461651651\",\r\n"
				+ "			\"InsuranceId\": \"61a73d6b-0378-4b86-a19e-12f0d0cecbeb\",\r\n"
				+ "			\"RelationshipToMember\": \"Self (Patient)\",\r\n"
				+ "			\"PolicyHolderFirstName\": null,\r\n" + "			\"FaxNumber\": null,\r\n"
				+ "			\"InsuranceCompanyName\": \"Amazon INC\",\r\n" + "			\"PlanType\": \"Medicaid\",\r\n"
				+ "			\"PhoneNumber\": null,\r\n" + "			\"Rank\": 1,\r\n"
				+ "			\"InsuranceMemberNumber\": null\r\n" + "		}\r\n" + "	],\r\n"
				+ "\"Copay\": {\r\n\t\t\t" + "\"ValidPrescription\": true,\r\n\t\t\t"
				+ "\"CoveredForReimbursement\": false,\r\n\t\t\t" + "\"IsEligibleForCopay\": true,\r\n\t\t\t"
				+ "\"FAPatientAcceptsCopayTerms\": true,\r\n\t\t\t" + "\"IsUsResident\": true,\r\n\t\t\t"
				+ "\"IsMilitary\": \"\",\r\n\t\t\t" + "\"HasGovernmentAssistance\": \"\",\r\n\t\t\t"
				+ "\"HasMilitaryAssistance\": \"\",\r\n\t\t\t" + "\"CardId\": \"\",\r\n\t\t\t"
				+ "\"HasCommercialInsurance\": true\r\n\t\t},\r\n" + "\"Attachments\": [\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"Extension\": \".pdf\",\r\n\t\t\t\t" + "\"ContentType\": \"application/pdf\",\r\n\t\t\t\t"
				+ "\"Content\": \"JVBE\",\r\n\t\t\t\t" + "\"FileName\": \"Patient Authorization Form\",\r\n\t\t\t\t"
				+ "\"FormType\": \"Consent\",\r\n\t\t\t\t" + "\"Descriptor\": \"Consent Form\",\r\n\t\t\t\t"
				+ "\"AttachmentId\": \"ab3e76e8-f5ba-4ca6-be29-0c0447001fc1\"\r\n\t\t\t},\r\n{\r\n\t\t\t\t"
				+ "\"Extension\": \".pdf\",\r\n\t\t\t\t" + "\"ContentType\": \"application/pdf\",\r\n\t\t\t\t"
				+ "\"Content\": \"JVBE\",\r\n"
				+ "\"FileName\": \"Patient Assistance Program Form_PES_PAP_Fabry.pdf\",\r\n\t\t\t\t"
				+ "\"FormType\": \"UploadedFile\",\r\n\t\t\t\t"
				+ "\"Descriptor\": \"Supporting documentation for assistance\",\r\n\t\t\t\t"
				+ "\"AttachmentId\": \"413c92f8-bff6-49d4-a9c3-d12a4378fbed\"\r\n\r\n\t\t\t}\r\n]\r\n\t}";

	}

	/**
	 * Function: To generate payload for AssitRx CoPay
	 * 
	 * @author Kruti Unnithan
	 * @param randNum1, randNum2, WebFormVal = Cablivi/Eloctate/Alprolix/CAD/Enjaymo
	 * @return Generated payload
	 */

	public static String payloadForAssitRxPAP(int randNum1, int randNum2, APIEnum WebFormVal) {

		String Payload = "{\r\n\t\t\"PatientParticipation\": false,\r\n\t\t" + "\"Consents\": [\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"HIPAA Authorization\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2023-04-20T15:49:37.562\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"chris10\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"Parent\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"HIPAA Authorization - Designee\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeLastName\": \"g10ayle\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2023-04-20T15:49:37.562\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"Patient Services Authorization\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2023-04-20T15:49:37.562\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"s10ignertestfullsign\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"eSignature And Records\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2023-04-20T15:49:37.562\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"Marketing Opt-In\",\r\n\t\t\t\t" + "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2023-04-20T15:49:37.562\"\r\n\t\t\t}\r\n\t\t],\r\n\t\t"
				+ "\"FinancialInformation\": {\r\n\t\t\t" + "\"HouseholdIncome\": 45000,\r\n\t\t\t"
				+ "\"HouseholdSize\": 2\r\n\t\t},\r\n\t\t" + "\"ExternalId\": \"\",\r\n\t\t"
				+ "\"Practice\": \"\",\r\n\t\t" + "\"Product\": \"" + WebFormVal + "\",\r\n\t\t"
				+ "\"Patient\": {\r\n\t\t\t" + "\"DateOfBirth\": \"199" + randNum2 % 10 + "-07-0" + randNum2 % 10
				+ "T00:00:00\",\r\n\t\t\t" + "\"Address\": {\r\n\t\t\t\t" + "\"AddressLine2\": \"\",\r\n\t\t\t\t"
				+ "\"AddressLine1\": \"add" + randNum2 + "r strret\",\r\n\t\t\t\t" + "\"State\": \"KS\",\r\n\t\t\t\t"
				+ "\"PostalCode\": \"40504\",\r\n\t\t\t\t" + "\"Country\": \"\",\r\n\t\t\t\t"
				+ "\"City\": \"kansas\"\r\n\t\t\t},\r\n\t\t\t" + "\"FirstName\": \"c" + randNum1 + "od" + randNum2
				+ "e\",\r\n\t\t\t" + "\"ExternalPatientId\": \"\",\r\n\t\t\t" + "\"Gender\": \"M\",\r\n\t\t\t"
				+ "\"MiddleName\": \"\",\r\n\t\t\t" + "\"EmailAddress\": \"" + randNum2 + "test" + randNum1
				+ "@check.com" + "\",\r\n\t\t\t" + "\"Phones\": [\r\n\t\t\t\t{\r\n\t\t\t\t\t" + "\"Number\": 53463609"
				+ randNum1 % 10 + "4,\r\n\t\t\t\t\t" + "\"PhoneType\": 3\r\n\t\t\t\t}\r\n\t\t\t],\r\n\t\t\t"
				+ "\"AuthorizedRepresentatives\": \"\",\r\n\t\t\t" + "\"PatientId\": \"78G5F6" + randNum1
				+ "-2ASD-7H86-98" + randNum2 + "-6RTYJ7F988O8\",\r\n\t\t\t" + "\"ParentGuardian\": {\r\n\t\t\t\t"
				+ "\"FirstName\": \"" + randNum1 + "john" + randNum2 + "\",\r\n\t\t\t\t" + "\"LastName\": \"" + randNum1
				+ "rhode" + randNum2 + "\"\r\n\t\t\t},\r\n\t\t\t" + "\"LastName\": \"Qa" + randNum2 + "R" + randNum1
				+ "\",\r\n\t\t\t" + "\"PreferredContactType\": 1,\r\n" + "\"SSN\": \"8976\"\r\n\t\t},\r\n\t\t"
				+ "\"PrescribingInformation\": {\r\n\t\t\t" + "\"PatientWeight\": 98,\r\n\t\t\t"
				+ "\"Frequency\": \"\",\r\n\t\t\t" + "\"Icd10\": \"\",\r\n\t\t\t"
				+ "\"PatientWeightUnit\": \"lbs\",\r\n\t\t\t" + "\"Dose\": \"\"\r\n\t\t},\r\n\t\t"
				+ "\"ArxId\": \"8HJ76H-04-48A8-BC35-68765KKU" + randNum2 + "\" ,\r\n\t\t"
				+ "\"PbmInsurances\": \"\",\r\n\t\t" + "\"Source\": \"PES\",\r\n\t\t" + "\"Prescriber\": \"\",\r\n\t\t"
				+ "\"ServiceType\": \"ProgramEnrollment\",\r\n\t\t" + "\"PatientParticipationEmail\": \"\",\r\n\t\t"
				+ "\"Pharmacy\": \"\",\r\n\t\t" + "\"MedicalInsurances\": \"\",\r\n" + "\"Copay\": {\r\n\t\t\t"
				+ "\"ValidPrescription\": false,\r\n\t\t\t" + "\"CoveredForReimbursement\": false,\r\n\t\t\t"
				+ "\"IsEligibleForCopay\": false,\r\n\t\t\t" + "\"FAPatientAcceptsCopayTerms\": false,\r\n\t\t\t"
				+ "\"IsUsResident\": false,\r\n\t\t\t" + "\"IsMilitary\":null,\r\n\t\t\t"
				+ "\"HasGovernmentAssistance\":null,\r\n\t\t\t" + "\"HasMilitaryAssistance\":null,\r\n\t\t\t"
				+ "\"CardId\": \"\",\r\n\t\t\t" + "\"HasCommercialInsurance\": false\r\n\t\t},\r\n"
				+ "\"Attachments\": [\r\n\t\t\t{\r\n\t\t\t\t" + "\"Extension\": \".pdf\",\r\n\t\t\t\t"
				+ "\"ContentType\": \"application/pdf\",\r\n\t\t\t\t" + "\"Content\": \"JVBE\",\r\n\t\t\t\t"
				+ "\"FileName\": \"Patient Authorization Form\",\r\n\t\t\t\t" + "\"FormType\": \"Consent\",\r\n\t\t\t\t"
				+ "\"Descriptor\": \"Consent Form\",\r\n\t\t\t\t"
				+ "\"AttachmentId\": \"ab3e76e8-f5ba-4ca6-be29-0c0447001fc1\"\r\n\t\t\t},\r\n{\r\n\t\t\t\t"
				+ "\"Extension\": \".pdf\",\r\n\t\t\t\t" + "\"ContentType\": \"application/pdf\",\r\n\t\t\t\t"
				+ "\"Content\": \"JVBE\",\r\n"
				+ "\"FileName\": \"Patient Assistance Program Form_PES_PAP_Fabry.pdf\",\r\n\t\t\t\t"
				+ "\"FormType\": \"UploadedFile\",\r\n\t\t\t\t"
				+ "\"Descriptor\": \"Supporting documentation for assistance\",\r\n\t\t\t\t"
				+ "\"AttachmentId\": \"413c92f8-bff6-49d4-a9c3-d12a4378fbed\"\r\n\r\n\t\t\t}\r\n]\r\n\t}";
		System.out.println(Payload);
		return Payload;
	}

	/**
	 * Function: To generate payload for AssitRx CoPay RD
	 * 
	 * @author Dipali Yadav
	 * @param randNum1, randNum2, WebFormVal = Cerdelga,Lumizyme etc.
	 * @return Generated payload
	 */

	public static String payloadForAssitRxCoPayRD(int randNum1, int randNum2, String expZip, APIEnum WebFormVal) {
		return "{\r\n\t\t\"PatientParticipation\": false,\r\n\t\t" + "\"Consents\": [\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"testsdsd\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"Patient Services Authorization\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-09-19T00:00:00\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"CopayProgramAuthorization\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-09-19T00:00:00\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"TextMessagingConsent\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-09-19T00:00:00\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"s10ignertestfullsign\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"HIPAA Authorization\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-09-19T00:00:00\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"eSignature And Records\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-24-02T00:00:00\"\r\n\t\t\t}\r\n\t\t],\r\n\t\t"
				+ "\"FinancialInformation\": \"\",\r\n\t\t" + "\"ExternalId\": \"\",\r\n\t\t"
				+ "\"Practice\": \"\",\r\n\t\t" + "\"Product\": \"" + WebFormVal + "\",\r\n\t\t"
				+ "\"Patient\": {\r\n\t\t\t" + "\"DateOfBirth\": \"199" + randNum2 % 10 + "-07-0" + randNum2 % 10
				+ "T00:00:00\",\r\n\t\t\t" + "\"Address\": {\r\n\t\t\t\t" + "\"AddressLine2\": \"\",\r\n\t\t\t\t"
				+ "\"AddressLine1\": \"add" + randNum2 + "r strret\",\r\n\t\t\t\t" + "\"State\": \"KS\",\r\n\t\t\t\t"
				+ "\"PostalCode\": \"" + expZip + "\",\r\n\t\t\t\t" + "\"Country\": \"\",\r\n\t\t\t\t"
				+ "\"City\": \"Manhattan\"\r\n\t\t\t},\r\n\t\t\t" + "\"FirstName\": \"Aut" + randNum1 + "api" + randNum2
				+ "e\",\r\n\t\t\t" + "\"ExternalPatientId\": \"\",\r\n\t\t\t" + "\"Gender\": \"M\",\r\n\t\t\t"
				+ "\"MiddleName\": \"\",\r\n\t\t\t" + "\"EmailAddress\": \"rdassistrxcopaytestdata@check" + randNum1
				+ ".com\",\r\n\t\t\t" + "\"Phones\": [\r\n\t\t\t\t{\r\n\t\t\t\t\t" + "\"Number\": 53463609"
				+ randNum1 % 10 + "4,\r\n\t\t\t\t\t" + "\"PhoneType\": 2\r\n\t\t\t\t}\r\n\t\t\t],\r\n\t\t\t"
				+ "\"AuthorizedRepresentatives\": \"\",\r\n\t\t\t"
				+ "\"PatientId\": \"747A2F93-217A-4E54-A7A8-257C1EE1CF29\",\r\n\t\t\t"
				+ "\"ParentGuardian\": {\r\n\t\t\t\t" + "\"FirstName\": \"" + randNum1 + "john" + randNum2
				+ "\",\r\n\t\t\t\t" + "\"LastName\": \"" + randNum1 + "rhode" + randNum2 + "\"\r\n\t\t\t},\r\n\t\t\t"
				+ "\"LastName\": \"test" + randNum2 + "R" + randNum1 + "\",\r\n\t\t\t"
				+ "\"PreferredContactType\": 1,\r\n" + "\"SSN\": \"8976\"\r\n\t\t},\r\n\t\t"
				+ "\"PrescribingInformation\": {\r\n\t\t\t" + "\"PatientWeight\": 98,\r\n\t\t\t"
				+ "\"Frequency\": \"\",\r\n\t\t\t" + "\"Icd10\": \"\",\r\n\t\t\t"
				+ "\"PatientWeightUnit\": \"lbs\",\r\n\t\t\t" + "\"Dose\": \"\"\r\n\t\t},\r\n\t\t"
				+ "\"ArxId\": \"9BE17E-04-48A8-BC35-769881YY" + randNum2 + "\" ,\r\n\t\t" + "\"PbmInsurances\": [\r\n"
				+ "		{\r\n" + "			\"InsuranceId\": \"61a73d6b-0378-4b86-a19e-12f0d0cecbeb\",\r\n"
				+ "			\"RelationshipToMember\": null,\r\n" + "			\"Rank\": 1,\r\n"
				+ "			\"ProcessorControlNumber\": null,\r\n" + "			\"PolicyHolderBirthDate\": null,\r\n"
				+ "			\"PolicyHolderLastName\": null,\r\n" + "			\"InsuranceGroupNumber\": null,\r\n"
				+ "			\"PbmName\": \"Acara\",\r\n" + "			\"PolicyHolderFirstName\": null,\r\n"
				+ "			\"PlanType\": \"Commercial Plan\",\r\n"
				+ "			\"BankIdentificationNumber\": \"161461\",\r\n" + "			\"PhoneNumber\": null,\r\n"
				+ "			\"InsuranceMemberNumber\": null\r\n" + "		}\r\n" + "	],\r\n\t\t"
				+ "\"Source\": \"PES\",\r\n\t\t" + "\"Prescriber\": \"\",\r\n\t\t"
				+ "\"ServiceType\": \"ProgramEnrollment\",\r\n\t\t" + "\"PatientParticipationEmail\": \"\",\r\n\t\t"
				+ "\"Pharmacy\": \"\",\r\n\t\t" + "\"MedicalInsurances\": [\r\n" + "		{\r\n"
				+ "			\"PolicyHolderBirthDate\": null,\r\n" + "			\"PolicyHolderLastName\": null,\r\n"
				+ "			\"InsuranceGroupNumber\": \"161461651651\",\r\n"
				+ "			\"InsuranceId\": \"38044f7b-6892-420b-8033-238876181b98\",\r\n"
				+ "			\"RelationshipToMember\": \"Self (Patient)\",\r\n"
				+ "			\"PolicyHolderFirstName\": null,\r\n" + "			\"FaxNumber\": null,\r\n"
				+ "			\"InsuranceCompanyName\": \"Amazon INC\",\r\n" + "			\"PlanType\": \"Medicaid\",\r\n"
				+ "			\"PhoneNumber\": \"999-999-9999\",\r\n" + "			\"Rank\": 1,\r\n"
				+ "			\"InsuranceMemberNumber\": \"INC-1236415\"\r\n" + "		}\r\n" + "	],\r\n"
				+ "\"Copay\": {\r\n\t\t\t" + "\"ValidPrescription\": true,\r\n\t\t\t"
				+ "\"CoveredForReimbursement\": false,\r\n\t\t\t" + "\"IsEligibleForCopay\": true,\r\n\t\t\t"
				+ "\"FAPatientAcceptsCopayTerms\": true,\r\n\t\t\t" + "\"IsUsResident\": true,\r\n\t\t\t"
				+ "\"IsMilitary\": \"\",\r\n\t\t\t" + "\"HasGovernmentAssistance\": \"\",\r\n\t\t\t"
				+ "\"HasMilitaryAssistance\": \"\",\r\n\t\t\t" + "\"CardId\": \"\",\r\n\t\t\t"
				+ "\"HasCommercialInsurance\": true\r\n\t\t},\r\n" + "\"Attachments\": [\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"Extension\": \".pdf\",\r\n\t\t\t\t" + "\"ContentType\": \"application/pdf\",\r\n\t\t\t\t"
				+ "\"Content\": \"JVBE\",\r\n\t\t\t\t" + "\"FileName\": \"Patient Authorization Form\",\r\n\t\t\t\t"
				+ "\"FormType\": \"Consent\",\r\n\t\t\t\t" + "\"Descriptor\": \"Consent Form\",\r\n\t\t\t\t"
				+ "\"AttachmentId\": \"ab3e76e8-f5ba-4ca6-be29-0c0447001fc1\"\r\n\t\t\t},\r\n{\r\n\t\t\t\t"
				+ "\"Extension\": \".pdf\",\r\n\t\t\t\t" + "\"ContentType\": \"application/pdf\",\r\n\t\t\t\t"
				+ "\"Content\": \"JVBE\",\r\n"
				+ "\"FileName\": \"Patient Assistance Program Form_PES_PAP_Fabry.pdf\",\r\n\t\t\t\t"
				+ "\"FormType\": \"UploadedFile\",\r\n\t\t\t\t"
				+ "\"Descriptor\": \"Supporting documentation for assistance\",\r\n\t\t\t\t"
				+ "\"AttachmentId\": \"413c92f8-bff6-49d4-a9c3-d12a4378fbed\"\r\n\r\n\t\t\t}\r\n]\r\n\t}";

	}

	/**
	 * Function: To generate payload for AssitRx CoPay RD
	 * 
	 * @author Dipali Yadav
	 * @param randNum1, randNum2, WebFormVal = Cerdelga,Lumizyme etc.
	 * @return Generated payload
	 */

	public static String payloadForMCKessonCoPayRD(String patientFirstName1, String patientLastName1,
			String PatientIdValue, String ArxIdValue, String dateOfBirth, int randNum1, int randNum2, String zipcode,
			int expInitialEnrollmentDate, APIEnum WebFormVal) {
		String PayloadMck = null;

		String currentDate = Utility_Function.getDueDateInNumbericFormat(expInitialEnrollmentDate);
		String constAddress1 = null;
		PayloadMck = "{\r\n" + "    \"Patient_Address_Line1\": \"" + constAddress1 + "\",\r\n"
				+ "    \"Physician_Fax\": 2108266477,\r\n" + "    \"Patient_Product\": \"" + WebFormVal + "\",\r\n\t\t"
				+ "    \"Infusion_Site_State\": \"TX\",\r\n"
				+ "    \"Infusion_Site_Address\": \"3247 CANDLEWOOD LANE\",\r\n"
				+ "    \"Infusion_Site_Zip\": 78217,\r\n" + "    \"Mckesson_Patient_ID\": 3349059,\r\n"
				+ "    \"Patient_Preferred_Contact_Method\": \"Home\",\r\n" + "    \"Rx_Group_Number\": 50777984,\r\n"
				+ "    \"Patient_Is_US_Resident\": \"Yes\",\r\n"
				+ "    \"Patient_Copay_Program_Vendor\": \"McKesson\",\r\n"
				+ "    \"Patient_Benefit_Type\": \"Commercial\",\r\n"
				+ "    \"Patient_Consent_Status\": \"Consented\",\r\n"
				+ "    \"Primary_Insurer_Name\": \"4353535\",\r\n" + "    \"Medical_Copay_ID\": 17752099,\r\n"
				+ "    \"Patient_Date_Of_Birth\":\"" + dateOfBirth + "T00:00:00\",\r\n"
				+ "    \"Physician_Address_Line1\": \"3247 CANDLEWOOD LANE\",\r\n"
				+ "    \"Prescribing_Physician_FirstName\": \"Helen\",\r\n"
				+ "    \"Infusion_Site_City\": \"SAN ANTONIO\",\r\n" + "    \"Physician_Zipcode\": 78217,\r\n"
				+ "    \"Primary_Insurance_Plan_Type\": 2,\r\n"
				+ "    \"Patient_Copay_Enrollment_Status\": \"Currently Enrolled\",\r\n"
				+ "    \"Patient_Home_Phone\": 53463609" + randNum1 % 10 + "4,\r\n\t\t\t\t\t"
				+ "    \"Patient_Enrollment_Type\": \"ENROLLMENT\",\r\n"
				+ "    \"Physician_City\": \"SAN ANTONIO\",\r\n"
				+ "    \"Prescribing_Physician_LastName\": \"Albanese\",\r\n" + "    \"Patient_FirstName\":\""
				+ patientFirstName1 + "\"," + "    \"AssistRx_ID\": \"" + ArxIdValue + "\",\r\n\t\t"
				+ "    \"Patient_LastName\":\"" + patientLastName1 + "\"," + "    \"Patient_State\": \"TX\",\r\n"
				+ "    \"Pharmacy_Card_ID\": 1029359240,\r\n" + "    \"Patient_City\": \"texas\",\r\n"
				+ "    \"Rx_Bin_Number\": 610524,\r\n" + "    \"Infusion_Site_Phone\": 2108266477,\r\n"
				+ "    \"Initial_Enrollment_Date\": \"" + currentDate + "\",\r\n"
				+ "    \"Physician_State\": \"TX\",\r\n" + "    \"Commercial_Start_Date\": \"" + currentDate + "\",\r\n"
				+ "    \"Patient_Copay_Enrollment_Source\": \"ASSISTRX\",\r\n"
				+ "    \"Patient_Consent_Source\": \"ASSISTRX\",\r\n" + "    \"Physician_Phone\": 2108266477,\r\n"
				+ "    \"Patient_Zipcode\": \"" + zipcode + "\",\r\n\t\t\t\t" + "    \"AssistRX_Patient_ID\": \""
				+ PatientIdValue + "\",\r\n\t\t" + "    \"Patient_Gender\": \"M\"\r\n" + "  }";
		System.out.println("Mackesson Payload-" + PayloadMck);
		return PayloadMck;
	}

	/**
	 * Function: To generate payload for AssitRx IAP To HCP Portal RD
	 * 
	 * @author Dipali Yadav
	 * @param randNum1, randNum2, WebFormVal = Cerdelga,Lumizyme etc.
	 * @return Generated payload to HCP Portal.
	 */

	public static String payloadForAssitRxIAPRDHCPPortal(int randNum1, int randNum2, String expZip,
			APIEnum WebFormVal) {
		return "{\r\n" + "	\"PatientParticipation\": true,\r\n" + "	\"Consents\": [\r\n" + "		{\r\n"
				+ "			\"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "			\"ConsentDesigneeRelationship\": \"\",\r\n" + "			\"ExpirationDate\": \"\",\r\n"
				+ "			\"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "			\"ConsentName\": \"eSignature And Records\",\r\n"
				+ "			\"ConsentGivenBy\": \"\",\r\n" + "			\"ConsentDesigneeLastName\": \"\",\r\n"
				+ "			\"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "		},\r\n" + "		{\r\n"
				+ "			\"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "			\"ConsentDesigneeRelationship\": \"\",\r\n" + "			\"ExpirationDate\": \"\",\r\n"
				+ "			\"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "			\"ConsentName\": \"IAPPrescriberCertification\",\r\n"
				+ "			\"ConsentGivenBy\": \"\",\r\n" + "			\"ConsentDesigneeLastName\": \"\",\r\n"
				+ "			\"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "		}\r\n" + "	],\r\n"
				+ "    \"FinancialInformation\": \"\",\r\n" + "    \"ExternalId\": \"\",\r\n"
				+ "    \"Practice\": {\r\n" + "        \"OfficeContactRole\": \"\",\r\n"
				+ "        \"Email\": \"\",\r\n" + "        \"Address\": {\r\n"
				+ "            \"AddressLine2\": \"\",\r\n" + "            \"AddressLine1\": \"Mck01\",\r\n"
				+ "            \"State\": \"NY\",\r\n" + "            \"PostalCode\": 10005,\r\n"
				+ "            \"Country\": \"\",\r\n" + "            \"City\": \"Manhattan\"\r\n" + "        },\r\n"
				+ "        \"PracticeId\": \"3c4afb1a-ca05-4645-89e6-1c611bafb8b6\",\r\n" + "        \"Phone\": {\r\n"
				+ "            \"Number\": 9632587410,\r\n" + "            \"PhoneType\": 0\r\n" + "        },\r\n"
				+ "        \"OfficeContactName\": \"\",\r\n" + "        \"Fax\": {\r\n"
				+ "            \"Number\": 9513246870,\r\n" + "            \"PhoneType\": 0\r\n" + "        },\r\n"
				+ "        \"Name\": \"Sanofitest\"\r\n" + "    },\r\n" + "    \"Product\": \"" + WebFormVal + "\",\r\n"
				+ "    \"Patient\": {\r\n" + "        \"DateOfBirth\": \"199" + randNum2 % 10 + "-07-0" + randNum2 % 10
				+ "T00:00:00\",\r\n\t\t\t" + "        \"Address\": {\r\n" + "            \"AddressLine2\": \"\",\r\n"
				+ "            \"AddressLine1\": \"S2\",\r\n" + "            \"State\": \"NY\",\r\n"
				+ "            \"PostalCode\": \"" + expZip + "\",\r\n" + "            \"Country\": \"\",\r\n"
				+ "            \"City\": \"Manhattan\"\r\n" + "        },\r\n" + "        \"FirstName\": \"APIFord"
				+ randNum2 + "R" + randNum1 + "\",\r\n" + "        \"ExternalPatientId\": \"\",\r\n"
				+ "        \"Gender\": \"M\",\r\n" + "        \"MiddleName\": \"\",\r\n"
				+ "        \"EmailAddress\": \"rdassistrxIAPtestdata@check" + randNum1 + ".com\",\r\n"
				+ "        \"Phones\": {\r\n" + "            \"Number\": \"99521588" + randNum1 + "\",\r\n"
				+ "            \"PhoneType\": 2\r\n" + "        },\r\n"
				+ "        \"AuthorizedRepresentatives\": \"\",\r\n" + "        \"PatientId\": \"9" + randNum1
				+ "9G7U4-3G" + randNum2 + "-986S-" + generateRandomString(1) + "MF-7F3H" + generateRandomString(1)
				+ "7732\",\r\n" + "        \"ParentGuardian\": \"\",\r\n" + "        \"LastName\": \"TestMotors"
				+ randNum2 + "R" + randNum1 + "\",\r\n" + "        \"PreferredContactType\": 0\r\n" + "    },\r\n"
				+ "    \"PrescribingInformation\": {\r\n" + "        \"PatientWeight\": 83,\r\n"
				+ "        \"Milligrams\": 20,\r\n" + "        \"Frequency\": \"Once in a week\",\r\n"
				+ "        \"Icd10\": 1021232551,\r\n" + "        \"PatientWeightUnit\": \"kgs\"\r\n" + "    },\r\n"
				+ "    \"ArxId\": \"88y5321g-" + randNum2 + "9o-" + generateRandomString(1) + "7U-b6a4-gh474dsef7"
				+ generateRandomString(1) + "\",\r\n" + "    \"PbmInsurances\": {\r\n"
				+ "        \"InsuranceId\": \"2eadf8c1-1a13-461f-bff7-8acd8e0e4409\",\r\n"
				+ "        \"RelationshipToMember\": \"\",\r\n" + "        \"Rank\": 1,\r\n"
				+ "        \"ProcessorControlNumber\": \"\",\r\n"
				+ "        \"PolicyHolderBirthDate\": \"1996-11-11T00:00:00\",\r\n"
				+ "        \"PolicyHolderLastName\": \"Motors\",\r\n" + "        \"InsuranceGroupNumber\": \"\",\r\n"
				+ "        \"PbmName\": \"\",\r\n" + "        \"PolicyHolderFirstName\": \"Ford\",\r\n"
				+ "        \"PlanType\": \"Medicaid Plan\",\r\n" + "        \"BankIdentificationNumber\": \"\",\r\n"
				+ "        \"PhoneNumber\": \"\",\r\n" + "        \"InsuranceMemberNumber\": \"\"\r\n" + "    },\r\n"
				+ "    \"Source\": \"HCP\",\r\n" + "    \"Prescriber\": {\r\n" + "        \"Specialty\": \"\",\r\n"
				+ "        \"PrescriberInUS\": \"\",\r\n" + "        \"Npi\": 1236547896,\r\n"
				+ "        \"FirstName\": \"Hyun\",\r\n" + "        \"DeaNumber\": 165161566,\r\n"
				+ "        \"TaxIdNumber\": \"\",\r\n" + "        \"LastName\": \"Bin\",\r\n"
				+ "        \"PrescriberId\": \"00000000-0000-0000-0000-000000000000\",\r\n"
				+ "        \"StateLicenseNumber\": 12654119\r\n" + "    },\r\n"
				+ "    \"ServiceType\": \"InterimAccess\",\r\n"
				+ "    \"PatientParticipationEmail\": \"kindhupraveen@deloitte.com\",\r\n"
				+ "    \"Pharmacy\": \"\",\r\n" + "    \"Copay\": \"\",\r\n" + "    \"MedicalInsurances\": {\r\n"
				+ "        \"PolicyHolderBirthDate\": \"1996-11-11T00:00:00\",\r\n"
				+ "        \"PolicyHolderLastName\": \"Motors\",\r\n"
				+ "        \"InsuranceGroupNumber\": 10963256,\r\n"
				+ "        \"InsuranceId\": \"2eadf8c1-1a13-461f-bff7-8acd8e0e4409\",\r\n"
				+ "        \"RelationshipToMember\": \"\",\r\n" + "        \"PolicyHolderFirstName\": \"Ford\",\r\n"
				+ "        \"FaxNumber\": \"\",\r\n" + "        \"InsuranceCompanyName\": \"Magna Life saver\",\r\n"
				+ "        \"PlanType\": \"Commercial\",\r\n" + "        \"PhoneNumber\": \"999-521-5484\",\r\n"
				+ "        \"Rank\": 1,\r\n" + "        \"InsuranceMemberNumber\": 63262625\r\n" + "    }\r\n" + "}";

	}

	/**
	 * Function: To generate payload for AssitRx IAP To patient Portal RD
	 * 
	 * @author Dipali Yadav
	 * @param randNum1, randNum2, WebFormVal = Cerdelga,Lumizyme etc.
	 * @return Generated payload to HCP Portal.
	 */

	public static String payloadForAssitRxIAPRDPatientPortal(int randNum1, int randNum2, String expZip,
			APIEnum WebFormVal) {
		return "{\r\n" + "    \"PatientParticipation\": true,\r\n" + "    \"Consents\": [\r\n" + "        {\r\n"
				+ "            \"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "            \"ConsentDesigneeRelationship\": \"\",\r\n" + "            \"ExpirationDate\": \"\",\r\n"
				+ "            \"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "            \"ConsentName\": \"CareConnectPSSIAPShareHealthInfoConsent\",\r\n"
				+ "            \"ConsentGivenBy\": \"Patient\",\r\n"
				+ "            \"ConsentDesigneeLastName\": \"\",\r\n"
				+ "            \"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "        },\r\n" + "        {\r\n"
				+ "            \"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "            \"ConsentDesigneeRelationship\": \"\",\r\n" + "            \"ExpirationDate\": \"\",\r\n"
				+ "            \"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "            \"ConsentName\": \"eSignature And Records\",\r\n"
				+ "            \"ConsentGivenBy\": \"Patient\",\r\n"
				+ "            \"ConsentDesigneeLastName\": \"\",\r\n"
				+ "            \"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "        },\r\n" + "        {\r\n"
				+ "            \"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "            \"ConsentDesigneeRelationship\": \"\",\r\n" + "            \"ExpirationDate\": \"\",\r\n"
				+ "            \"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "            \"ConsentName\": \"PSSIAPServicesConsent\",\r\n"
				+ "            \"ConsentGivenBy\": \"Patient\",\r\n"
				+ "            \"ConsentDesigneeLastName\": \"\",\r\n"
				+ "            \"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "        }\r\n" + "    ],\r\n"
				+ "    \"FinancialInformation\": \"\",\r\n" + "    \"ExternalId\": \"\",\r\n"
				+ "    \"Practice\": {\r\n" + "        \"OfficeContactRole\": \"\",\r\n"
				+ "        \"Email\": \"\",\r\n" + "        \"Address\": {\r\n"
				+ "            \"AddressLine2\": \"\",\r\n" + "            \"AddressLine1\": \"Mck01\",\r\n"
				+ "            \"State\": \"NY\",\r\n" + "            \"PostalCode\": 10005,\r\n"
				+ "            \"Country\": \"\",\r\n" + "            \"City\": \"Manhattan\"\r\n" + "        },\r\n"
				+ "        \"PracticeId\": \"3c4afb1a-ca05-4645-89e6-1c611bafb8b6\",\r\n" + "        \"Phone\": {\r\n"
				+ "            \"Number\": 9632587410,\r\n" + "            \"PhoneType\": 0\r\n" + "        },\r\n"
				+ "        \"OfficeContactName\": \"\",\r\n" + "        \"Fax\": {\r\n"
				+ "            \"Number\": 9513246870,\r\n" + "            \"PhoneType\": 0\r\n" + "        },\r\n"
				+ "        \"Name\": \"Sanofitest\"\r\n" + "    },\r\n" + "    \"Product\": \"" + WebFormVal + "\",\r\n"
				+ "    \"Patient\": {\r\n" + "        \"DateOfBirth\": \"199" + randNum2 % 10 + "-07-0" + randNum2 % 10
				+ "T00:00:00\",\r\n\t\t\t" + "        \"Address\": {\r\n" + "            \"AddressLine2\": \"\",\r\n"
				+ "            \"AddressLine1\": \"S2\",\r\n" + "            \"State\": \"NY\",\r\n"
				+ "            \"PostalCode\": \"" + expZip + "\",\r\n" + "            \"Country\": \"\",\r\n"
				+ "            \"City\": \"Manhattan\"\r\n" + "        },\r\n" + "        \"FirstName\": \"APIFord"
				+ randNum2 + "R" + randNum1 + "\",\r\n" + "        \"ExternalPatientId\": \"\",\r\n"
				+ "        \"Gender\": \"M\",\r\n" + "        \"MiddleName\": \"\",\r\n"
				+ "        \"EmailAddress\": \"rdassistrxIAPtestdata@check" + randNum1 + ".com\",\r\n\t\t\t"
				+ "        \"Phones\": {\r\n" + "            \"Number\": \"99521588" + randNum1 + "\",\r\n"
				+ "            \"PhoneType\": 2\r\n" + "        },\r\n"
				+ "        \"AuthorizedRepresentatives\": \"\",\r\n" + "        \"PatientId\": \"9" + randNum1
				+ "9G7U4-3G" + randNum2 + "-986S-" + generateRandomString(1) + "MF-7F3H" + generateRandomString(1)
				+ "7732\",\r\n" + "        \"ParentGuardian\": \"\",\r\n" + "        \"LastName\": \"TestMotors"
				+ randNum2 + "R" + randNum1 + "\",\r\n" + "        \"PreferredContactType\": 0\r\n" + "    },\r\n"
				+ "    \"PrescribingInformation\": {\r\n" + "        \"PatientWeight\": 83,\r\n"
				+ "        \"Milligrams\": 20,\r\n" + "        \"Frequency\": \"Once in a week\",\r\n"
				+ "        \"Icd10\": 1021232551,\r\n" + "        \"PatientWeightUnit\": \"kgs\"\r\n" + "    },\r\n"
				+ "    \"ArxId\": \"88y5321g-" + randNum2 + "9o-" + generateRandomString(1) + "7U-b6a4-gh474dsef7"
				+ generateRandomString(1) + "\",\r\n" + "    \"PbmInsurances\": {\r\n"
				+ "        \"InsuranceId\": \"2eadf8c1-1a13-461f-bff7-8acd8e0e4409\",\r\n"
				+ "        \"RelationshipToMember\": \"\",\r\n" + "        \"Rank\": 1,\r\n"
				+ "        \"ProcessorControlNumber\": \"\",\r\n"
				+ "        \"PolicyHolderBirthDate\": \"1996-11-11T00:00:00\",\r\n"
				+ "        \"PolicyHolderLastName\": \"Motors\",\r\n" + "        \"InsuranceGroupNumber\": \"\",\r\n"
				+ "        \"PbmName\": \"\",\r\n" + "        \"PolicyHolderFirstName\": \"Ford\",\r\n"
				+ "        \"PlanType\": \"Medicaid Plan\",\r\n" + "        \"BankIdentificationNumber\": \"\",\r\n"
				+ "        \"PhoneNumber\": \"\",\r\n" + "        \"InsuranceMemberNumber\": \"\"\r\n" + "    },\r\n"
				+ "    \"Source\": \"PES\",\r\n" + "    \"Prescriber\": {\r\n" + "        \"Specialty\": \"\",\r\n"
				+ "        \"PrescriberInUS\": \"\",\r\n" + "        \"Npi\": 1236547896,\r\n"
				+ "        \"FirstName\": \"Hyun\",\r\n" + "        \"DeaNumber\": 165161566,\r\n"
				+ "        \"TaxIdNumber\": \"\",\r\n" + "        \"LastName\": \"Bin\",\r\n"
				+ "        \"PrescriberId\": \"00000000-0000-0000-0000-000000000000\",\r\n"
				+ "        \"StateLicenseNumber\": 12654119\r\n" + "    },\r\n"
				+ "    \"ServiceType\": \"InterimAccess\",\r\n"
				+ "    \"PatientParticipationEmail\": \"kindhupraveen@deloitte.com\",\r\n"
				+ "    \"Pharmacy\": \"\",\r\n" + "    \"Copay\": \"\",\r\n" + "    \"MedicalInsurances\": {\r\n"
				+ "        \"PolicyHolderBirthDate\": \"1996-11-11T00:00:00\",\r\n"
				+ "        \"PolicyHolderLastName\": \"Motors\",\r\n"
				+ "        \"InsuranceGroupNumber\": 10963256,\r\n"
				+ "        \"InsuranceId\": \"2eadf8c1-1a13-461f-bff7-8acd8e0e4409\",\r\n"
				+ "        \"RelationshipToMember\": \"\",\r\n" + "        \"PolicyHolderFirstName\": \"Ford\",\r\n"
				+ "        \"FaxNumber\": \"\",\r\n" + "        \"InsuranceCompanyName\": \"Magna Life saver\",\r\n"
				+ "        \"PlanType\": \"Commercial\",\r\n" + "        \"PhoneNumber\": \"999-521-5484\",\r\n"
				+ "        \"Rank\": 1,\r\n" + "        \"InsuranceMemberNumber\": 63262625\r\n" + "    }\r\n" + "}";
	}

	/**
	 * Function: To generate payload for AssitRx PAP To HCP Portal RD
	 * 
	 * @author Dipali Yadav
	 * @param randNum1, randNum2, WebFormVal = Cerdelga,Lumizyme etc.
	 * @return Generated payload to HCP Portal.
	 */

	public static String payloadForAssitRxPAPRDHCPPortal(int randNum1, int randNum2, String expZip,
			APIEnum WebFormVal) {
		return "{\r\n" + "	\"PatientParticipation\": true,\r\n" + "	\"Consents\": [\r\n" + "		{\r\n"
				+ "			\"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "			\"ConsentDesigneeRelationship\": \"\",\r\n" + "			\"ExpirationDate\": \"\",\r\n"
				+ "			\"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "			\"ConsentName\": \"eSignature And Records\",\r\n"
				+ "			\"ConsentGivenBy\": \"\",\r\n" + "			\"ConsentDesigneeLastName\": \"\",\r\n"
				+ "			\"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "		},\r\n" + "		{\r\n"
				+ "			\"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "			\"ConsentDesigneeRelationship\": \"\",\r\n" + "			\"ExpirationDate\": \"\",\r\n"
				+ "			\"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "			\"ConsentName\": \"PAPPrescriberCertification\",\r\n"
				+ "			\"ConsentGivenBy\": \"\",\r\n" + "			\"ConsentDesigneeLastName\": \"\",\r\n"
				+ "			\"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "		}\r\n" + "	],\r\n"
				+ "    \"FinancialInformation\": \"\",\r\n" + "    \"ExternalId\": \"\",\r\n"
				+ "    \"Practice\": {\r\n" + "        \"OfficeContactRole\": \"\",\r\n"
				+ "        \"Email\": \"\",\r\n" + "        \"Address\": {\r\n"
				+ "            \"AddressLine2\": \"\",\r\n" + "            \"AddressLine1\": \"Mck01\",\r\n"
				+ "            \"State\": \"NY\",\r\n" + "            \"PostalCode\": 10005,\r\n"
				+ "            \"Country\": \"\",\r\n" + "            \"City\": \"Manhattan\"\r\n" + "        },\r\n"
				+ "        \"PracticeId\": \"3c4afb1a-ca05-4645-89e6-1c611bafb8b6\",\r\n" + "        \"Phone\": {\r\n"
				+ "            \"Number\": 9632587410,\r\n" + "            \"PhoneType\": 0\r\n" + "        },\r\n"
				+ "        \"OfficeContactName\": \"\",\r\n" + "        \"Fax\": {\r\n"
				+ "            \"Number\": 9513246870,\r\n" + "            \"PhoneType\": 0\r\n" + "        },\r\n"
				+ "        \"Name\": \"Sanofitest\"\r\n" + "    },\r\n" + "    \"Product\": \"" + WebFormVal + "\",\r\n"
				+ "    \"Patient\": {\r\n" + "        \"DateOfBirth\": \"199" + randNum2 % 10 + "-07-0" + randNum2 % 10
				+ "T00:00:00\",\r\n\t\t\t" + "        \"Address\": {\r\n" + "            \"AddressLine2\": \"\",\r\n"
				+ "            \"AddressLine1\": \"S2\",\r\n" + "            \"State\": \"NY\",\r\n"
				+ "            \"PostalCode\": \"" + expZip + "\",\r\n" + "            \"Country\": \"\",\r\n"
				+ "            \"City\": \"Manhattan\"\r\n" + "        },\r\n" + "        \"FirstName\": \"APIFord"
				+ randNum2 + "R" + randNum1 + "\",\r\n" + "        \"ExternalPatientId\": \"\",\r\n"
				+ "        \"Gender\": \"M\",\r\n" + "        \"MiddleName\": \"\",\r\n"
				+ "        \"EmailAddress\": \"rdassistrxIAPtestdata@check" + randNum1 + ".com\",\r\n"
				+ "        \"Phones\": {\r\n" + "            \"Number\": \"99521588" + randNum1 + "\",\r\n"
				+ "            \"PhoneType\": 2\r\n" + "        },\r\n"
				+ "        \"AuthorizedRepresentatives\": \"\",\r\n" + "        \"PatientId\": \"3" + randNum1
				+ "9X7U4-3G" + randNum2 + "-986S-" + generateRandomString(1) + "FM-7F3H" + generateRandomString(1)
				+ "7732\",\r\n" + "        \"ParentGuardian\": \"\",\r\n" + "        \"LastName\": \"TestMotors"
				+ randNum2 + "R" + randNum1 + "\",\r\n" + "        \"PreferredContactType\": 0\r\n" + "    },\r\n"
				+ "    \"PrescribingInformation\": {\r\n" + "        \"PatientWeight\": 83,\r\n"
				+ "        \"Milligrams\": 20,\r\n" + "        \"Frequency\": \"Once in a week\",\r\n"
				+ "        \"Icd10\": 1021232551,\r\n" + "        \"PatientWeightUnit\": \"kgs\"\r\n" + "    },\r\n"
				+ "    \"ArxId\": \"32y5321k-" + randNum2 + "9o-" + generateRandomString(1) + "6K-b6a4-ty674dsef7"
				+ generateRandomString(1) + "\",\r\n" + "    \"PbmInsurances\": {\r\n"
				+ "        \"InsuranceId\": \"2eadf8c1-1a13-461f-bff7-8acd8e0e4409\",\r\n"
				+ "        \"RelationshipToMember\": \"\",\r\n" + "        \"Rank\": 1,\r\n"
				+ "        \"ProcessorControlNumber\": \"\",\r\n"
				+ "        \"PolicyHolderBirthDate\": \"1996-11-11T00:00:00\",\r\n"
				+ "        \"PolicyHolderLastName\": \"Motors\",\r\n" + "        \"InsuranceGroupNumber\": \"\",\r\n"
				+ "        \"PbmName\": \"\",\r\n" + "        \"PolicyHolderFirstName\": \"Ford\",\r\n"
				+ "        \"PlanType\": \"Medicaid Plan\",\r\n" + "        \"BankIdentificationNumber\": \"\",\r\n"
				+ "        \"PhoneNumber\": \"\",\r\n" + "        \"InsuranceMemberNumber\": \"\"\r\n" + "    },\r\n"
				+ "    \"Source\": \"HCP\",\r\n" + "    \"Prescriber\": {\r\n" + "        \"Specialty\": \"\",\r\n"
				+ "        \"PrescriberInUS\": \"\",\r\n" + "        \"Npi\": 1236547896,\r\n"
				+ "        \"FirstName\": \"Hyun\",\r\n" + "        \"DeaNumber\": 165161566,\r\n"
				+ "        \"TaxIdNumber\": \"\",\r\n" + "        \"LastName\": \"Bin\",\r\n"
				+ "        \"PrescriberId\": \"00000000-0000-0000-0000-000000000000\",\r\n"
				+ "        \"StateLicenseNumber\": 12654119\r\n" + "    },\r\n" + "    \"ServiceType\": \"PAP\",\r\n"
				+ "    \"PatientParticipationEmail\": \"kindhupraveen@deloitte.com\",\r\n"
				+ "    \"Pharmacy\": \"\",\r\n" + "    \"Copay\": \"\",\r\n" + "    \"MedicalInsurances\": {\r\n"
				+ "        \"PolicyHolderBirthDate\": \"1996-11-11T00:00:00\",\r\n"
				+ "        \"PolicyHolderLastName\": \"Motors\",\r\n"
				+ "        \"InsuranceGroupNumber\": 10963256,\r\n"
				+ "        \"InsuranceId\": \"2eadf8c1-1a13-461f-bff7-8acd8e0e4409\",\r\n"
				+ "        \"RelationshipToMember\": \"\",\r\n" + "        \"PolicyHolderFirstName\": \"Ford\",\r\n"
				+ "        \"FaxNumber\": \"\",\r\n" + "        \"InsuranceCompanyName\": \"Magna Life saver\",\r\n"
				+ "        \"PlanType\": \"Commercial\",\r\n" + "        \"PhoneNumber\": \"999-521-5484\",\r\n"
				+ "        \"Rank\": 1,\r\n" + "        \"InsuranceMemberNumber\": 63262625\r\n" + "    }\r\n" + "}";

	}

	/**
	 * Function: To generate payload for AssitRx PAP To patient Portal RD
	 * 
	 * @author Dipali Yadav
	 * @param randNum1, randNum2, WebFormVal = Cerdelga,Lumizyme etc.
	 * @return Generated payload to HCP Portal.
	 */

	public static String payloadForAssitRxPAPRDPatientPortal(int randNum1, int randNum2, String expZip,
			APIEnum WebFormVal) {
		return "{\r\n" + "    \"PatientParticipation\": true,\r\n" + "    \"Consents\": [\r\n" + "        {\r\n"
				+ "            \"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "            \"ConsentDesigneeRelationship\": \"\",\r\n" + "            \"ExpirationDate\": \"\",\r\n"
				+ "            \"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "            \"ConsentName\": \"CareConnectPSSPAPShareHealthInfoConsent\",\r\n"
				+ "            \"ConsentGivenBy\": \"Patient\",\r\n"
				+ "            \"ConsentDesigneeLastName\": \"\",\r\n"
				+ "            \"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "        },\r\n" + "        {\r\n"
				+ "            \"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "            \"ConsentDesigneeRelationship\": \"\",\r\n" + "            \"ExpirationDate\": \"\",\r\n"
				+ "            \"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "            \"ConsentName\": \"eSignature And Records\",\r\n"
				+ "            \"ConsentGivenBy\": \"Patient\",\r\n"
				+ "            \"ConsentDesigneeLastName\": \"\",\r\n"
				+ "            \"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "        },\r\n" + "        {\r\n"
				+ "            \"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "            \"ConsentDesigneeRelationship\": \"\",\r\n" + "            \"ExpirationDate\": \"\",\r\n"
				+ "            \"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "            \"ConsentName\": \"PSSPAPServicesConsent\",\r\n"
				+ "            \"ConsentGivenBy\": \"Patient\",\r\n"
				+ "            \"ConsentDesigneeLastName\": \"\",\r\n"
				+ "            \"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "        }\r\n" + "    ],\r\n"
				+ "    \"FinancialInformation\": \"\",\r\n" + "    \"ExternalId\": \"\",\r\n"
				+ "    \"Practice\": {\r\n" + "        \"OfficeContactRole\": \"\",\r\n"
				+ "        \"Email\": \"\",\r\n" + "        \"Address\": {\r\n"
				+ "            \"AddressLine2\": \"\",\r\n" + "            \"AddressLine1\": \"Mck01\",\r\n"
				+ "            \"State\": \"NY\",\r\n" + "            \"PostalCode\": 10005,\r\n"
				+ "            \"Country\": \"\",\r\n" + "            \"City\": \"Manhattan\"\r\n" + "        },\r\n"
				+ "        \"PracticeId\": \"3c4afb1a-ca05-4645-89e6-1c611bafb8b6\",\r\n" + "        \"Phone\": {\r\n"
				+ "            \"Number\": 9632587410,\r\n" + "            \"PhoneType\": 0\r\n" + "        },\r\n"
				+ "        \"OfficeContactName\": \"\",\r\n" + "        \"Fax\": {\r\n"
				+ "            \"Number\": 9513246870,\r\n" + "            \"PhoneType\": 0\r\n" + "        },\r\n"
				+ "        \"Name\": \"Sanofitest\"\r\n" + "    },\r\n" + "    \"Product\": \"" + WebFormVal + "\",\r\n"
				+ "    \"Patient\": {\r\n" + "        \"DateOfBirth\": \"199" + randNum2 % 10 + "-07-0" + randNum2 % 10
				+ "T00:00:00\",\r\n\t\t\t" + "        \"Address\": {\r\n" + "            \"AddressLine2\": \"\",\r\n"
				+ "            \"AddressLine1\": \"S2\",\r\n" + "            \"State\": \"NY\",\r\n"
				+ "            \"PostalCode\": \"" + expZip + "\",\r\n" + "            \"Country\": \"\",\r\n"
				+ "            \"City\": \"Manhattan\"\r\n" + "        },\r\n" + "        \"FirstName\": \"APIFord"
				+ randNum2 + "R" + randNum1 + "\",\r\n" + "        \"ExternalPatientId\": \"\",\r\n"
				+ "        \"Gender\": \"M\",\r\n" + "        \"MiddleName\": \"\",\r\n"
				+ "        \"EmailAddress\": \"rdassistrxIAPtestdata@check" + randNum1 + ".com\",\r\n\t\t\t"
				+ "        \"Phones\": {\r\n" + "            \"Number\": \"99521588" + randNum1 + "\",\r\n"
				+ "            \"PhoneType\": 2\r\n" + "        },\r\n"
				+ "        \"AuthorizedRepresentatives\": \"\",\r\n" + "        \"PatientId\": \"3" + randNum1
				+ "9X7U4-3G" + randNum2 + "-986S-" + generateRandomString(1) + "FM-7F3H" + generateRandomString(1)
				+ "7732\",\r\n" + "        \"ParentGuardian\": \"\",\r\n" + "        \"LastName\": \"TestMotors"
				+ randNum2 + "R" + randNum1 + "\",\r\n" + "        \"PreferredContactType\": 0\r\n" + "    },\r\n"
				+ "    \"PrescribingInformation\": {\r\n" + "        \"PatientWeight\": 83,\r\n"
				+ "        \"Milligrams\": 20,\r\n" + "        \"Frequency\": \"Once in a week\",\r\n"
				+ "        \"Icd10\": 1021232551,\r\n" + "        \"PatientWeightUnit\": \"kgs\"\r\n" + "    },\r\n"
				+ "    \"ArxId\": \"32y5321k-" + randNum2 + "9o-" + generateRandomString(1) + "6K-b6a4-ty674dsef7"
				+ generateRandomString(1) + "\",\r\n" + "    \"PbmInsurances\": {\r\n"
				+ "        \"InsuranceId\": \"2eadf8c1-1a13-461f-bff7-8acd8e0e4409\",\r\n"
				+ "        \"RelationshipToMember\": \"\",\r\n" + "        \"Rank\": 1,\r\n"
				+ "        \"ProcessorControlNumber\": \"\",\r\n"
				+ "        \"PolicyHolderBirthDate\": \"1996-11-11T00:00:00\",\r\n"
				+ "        \"PolicyHolderLastName\": \"Motors\",\r\n" + "        \"InsuranceGroupNumber\": \"\",\r\n"
				+ "        \"PbmName\": \"\",\r\n" + "        \"PolicyHolderFirstName\": \"Ford\",\r\n"
				+ "        \"PlanType\": \"Medicaid Plan\",\r\n" + "        \"BankIdentificationNumber\": \"\",\r\n"
				+ "        \"PhoneNumber\": \"\",\r\n" + "        \"InsuranceMemberNumber\": \"\"\r\n" + "    },\r\n"
				+ "    \"Source\": \"PES\",\r\n" + "    \"Prescriber\": {\r\n" + "        \"Specialty\": \"\",\r\n"
				+ "        \"PrescriberInUS\": \"\",\r\n" + "        \"Npi\": 1236547896,\r\n"
				+ "        \"FirstName\": \"Hyun\",\r\n" + "        \"DeaNumber\": 165161566,\r\n"
				+ "        \"TaxIdNumber\": \"\",\r\n" + "        \"LastName\": \"Bin\",\r\n"
				+ "        \"PrescriberId\": \"00000000-0000-0000-0000-000000000000\",\r\n"
				+ "        \"StateLicenseNumber\": 12654119\r\n" + "    },\r\n" + "    \"ServiceType\": \"PAP\",\r\n"
				+ "    \"PatientParticipationEmail\": \"kindhupraveen@deloitte.com\",\r\n"
				+ "    \"Pharmacy\": \"\",\r\n" + "    \"Copay\": \"\",\r\n" + "    \"MedicalInsurances\": {\r\n"
				+ "        \"PolicyHolderBirthDate\": \"1996-11-11T00:00:00\",\r\n"
				+ "        \"PolicyHolderLastName\": \"Motors\",\r\n"
				+ "        \"InsuranceGroupNumber\": 10963256,\r\n"
				+ "        \"InsuranceId\": \"2eadf8c1-1a13-461f-bff7-8acd8e0e4409\",\r\n"
				+ "        \"RelationshipToMember\": \"\",\r\n" + "        \"PolicyHolderFirstName\": \"Ford\",\r\n"
				+ "        \"FaxNumber\": \"\",\r\n" + "        \"InsuranceCompanyName\": \"Magna Life saver\",\r\n"
				+ "        \"PlanType\": \"Commercial\",\r\n" + "        \"PhoneNumber\": \"999-521-5484\",\r\n"
				+ "        \"Rank\": 1,\r\n" + "        \"InsuranceMemberNumber\": 63262625\r\n" + "    }\r\n" + "}";
	}

	/**
	 * Function: To setup API For checking the changes made in ICC reflecting in
	 * atlantis
	 * 
	 * @author Pratiksha Dixit
	 * @param
	 * @return API response
	 */
	public static String apiSetUpForAtlantis(String apiKeyValue, String uri, String programId, String fromDate,
			String todate, String pageNumberValue) {
		return given().header(APIConstants.constApiKey, apiKeyValue)
				.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
				.queryParam("from", fromDate).queryParam("to", todate).queryParam("pageNumber", pageNumberValue).when()
				.get(uri + programId + "/channels").then().assertThat().statusCode(200).extract().response()
				.asPrettyString().toString();
	}

	/**
	 * Function: To generate payload for McKesson CoPay Enrollment
	 * 
	 * @author skumarsahu
	 * @param randNum1, randNum2, WebFormVal = Cablivi/Eloctate/Alprolix/CAD/Enjaymo
	 * @return Generated payload
	 */

	public static String payloadForMcKessonCoPayEnrollment(int randNum1, int randNum2, String zipCode,
			String enrollDate, APIEnum WebFormVal) {
		return "{\r\n" + "    \"Patient_Address_Line1\": \"PARIS HILL ST\",\r\n"
				+ "    \"Patient_Address_Line2\": \"PARIS HILL ST\",\r\n" + "    \"Patient_Product\": \"" + WebFormVal
				+ "\",\r\n" + "    \"Infusion_Site_State\": \"AZ\",\r\n"
				+ "    \"Infusion_Site_Address\": \"47 NEW SCOTLAND AVE\",\r\n"
				+ "    \"Infusion_Site_Zip\": 12208,\r\n" + "    \"Mckesson_Patient_ID\": 6495" + randNum1 % 10
				+ randNum1 % 10 + randNum1 % 10 + ",\r\n" + "    \"Patient_Preferred_Contact_Method\": \"Home\",\r\n"
				+ "    \"Rx_Group_Number\": 50777984,\r\n" + "    \"Patient_Is_US_Resident\": \"Yes\",\r\n"
				+ "    \"Patient_Copay_Program_Vendor\": \"McKesson\",\r\n"
				+ "    \"Patient_Benefit_Type\": \"Commercial\",\r\n"
				+ "    \"Patient_Consent_Status\": \"Consented\",\r\n"
				+ "    \"Primary_Insurer_Name\": \"SIT INSURANCE3\",\r\n" + "    \"Medical_Copay_ID\": 178426"
				+ randNum1 % 10 + ",\r\n" + "    \"Patient_Email\": \"terry" + randNum1 + "@vbase.com\",\r\n"
				+ "    \"Patient_Date_Of_Birth\": \"12/1" + randNum2 % 10 + "/199" + randNum2 % 10 + "\" ,\r\n"
				+ "    \"Physician_Address_Line1\": \"47 NEW SCOTLAND AVE\",\r\n"
				+ "    \"Prescribing_Physician_FirstName\": \"Preston\",\r\n"
				+ "    \"Infusion_Site_City\": \"ALBANY\",\r\n" + "    \"Physician_Zipcode\": 12208,\r\n"
				+ "    \"Primary_Insurance_Plan_Type\": 1,\r\n"
				+ "    \"Patient_Copay_Enrollment_Status\": \"Currently Enrolled\",\r\n"
				+ "    \"Patient_Home_Phone\": 899521588" + randNum2 % 10 + ",\r\n"
				+ "    \"Patient_Enrollment_Type\": \"ENROLLMENT\",\r\n" + "    \"Physician_City\": \"ALBANY\",\r\n"
				+ "    \"Prescribing_Physician_LastName\": \"Carter\",\r\n" + "    \"Patient_FirstName\": \"" + randNum1
				+ "John" + randNum2 + "\",\r\n" + "    \"Patient_LastName\": \"" + randNum2 + "Daley" + randNum1
				+ "\",\r\n" + "    \"Patient_State\": \"AZ\",\r\n" + "    \"Pharmacy_Card_ID\": 1029359240,\r\n"
				+ "    \"Patient_City\": \"SCOTTSDALE\",\r\n" + "    \"Rx_Bin_Number\": 610524,\r\n"
				+ "    \"Initial_Enrollment_Date\": \"" + enrollDate + "\",\r\n"
				+ "    \"Physician_State\": \"NY\",\r\n" + "    \"Commercial_Start_Date\": \"" + enrollDate + "\",\r\n"
				+ "    \"Patient_Copay_Enrollment_Source\": \"FAX\",\r\n"
				+ "    \"Patient_Consent_Source\": \"FAX\",\r\n" + "    \"Patient_Zipcode\": " + zipCode + ",\r\n"
				+ "    \"Patient_Gender\": \"M\"\r\n" + "  }";

	}

	/**
	 * Function: To generate Invoice through Payload
	 * 
	 * @author skumarsahu
	 * @param randNum1, randNum2, OrderSFDCID
	 * @return Generated payload
	 */

	public static String payloadForInvoiceCreation(int randNum1, int randNum2, String OrderSFDCID) {
		return "{\r\n" + "    \"iCC_Order_ID__c\":\"" + OrderSFDCID + "\",\r\n"
				+ "    \"iCC_GMID__c\":\"000000000000797526\",\r\n" + "    \"iCC_Invoice_Item_Number__c\":\"70302"
				+ randNum1 + "813-000010\",\r\n" + "    \"iCC_Invoice_Number__c\":\"7030" + randNum1 + "87" + randNum2
				+ "13\",\r\n" + "    \"iCC_Delivery_Number__c\":\"6017" + randNum1 + "5472\",\r\n"
				+ "    \"iCC_Delivery_Number_Position__c\":\"6017" + randNum1 + "5472-90" + randNum1 + "01\",\r\n"
				+ "    \"iCC_Invoice_Date__c\":\"2023-1" + randNum1 % 10 + "-0" + randNum2 % 10
				+ "T07:36:31.000+0000\",\r\n" + "    \"iCC_Due_Date__c\":\"2023-1" + randNum1 % 10 + "-0"
				+ randNum2 % 10 + "T07:36:31.000+0000\",\r\n" + "    \"iCC_Invoice_Total__c\":\"7577.40\",\r\n"
				+ "    \"iCC_Tax_Amount__c\":\"75.03\"\r\n" + "}";

	}

	/**
	 * Function: To generate Shipment through Payload
	 * 
	 * @author skumarsahu
	 * @param randNum1, randNum2, OrderSFDCID
	 * @return Generated payload
	 */

	public static String payloadForShipmentCreation(int randNum1, int randNum2, String OrderSFDCID) {
		return "{\r\n" + "    \"iCC_Order_ID__c\": \"" + OrderSFDCID + "\",\r\n"
				+ "    \"iCC_GMID__c\":\"000000000000797526\",\r\n" + "    \"iCC_Quantity__c\":\"1\",\r\n"
				+ "    \"iCC_Lot_Number__c\":\"BY0457\",\r\n" + "    \"iCC_ERP_Order_Number__c\":\"1017274108\",\r\n"
				+ "    \"iCC_Sales_Order_Position__c\":\"000030\",\r\n" + "    \"iCC_Ship_Date__c\":\"2023-1"
				+ randNum1 % 10 + "-0" + randNum2 % 10 + "T07:36:31.000+0000\",\r\n"
				+ "    \"iCC_Delivery_Number__c\":\"62" + randNum1 + "5472\",\r\n"
				+ "    \"iCC_Delivery_Number_Position__c\":\"60" + randNum1 + "285472-900" + randNum1 + "1\",\r\n"
				+ "    \"iCC_Lot_Expiration_Date__c\":\"2023-1" + randNum1 % 10 + "-0" + randNum2 % 10
				+ "T07:36:31.000+0000\"\r\n" + "}";
	}

	/**
	 * Function: To generate payload for AssitRx Quick Start
	 * 
	 * @author skumarsahu
	 * @param randNum1, randNum2, WebFormVal = Nexviazyme
	 * @return Generated payload
	 */

	public static String payloadForAssitRxQS(int randNum1, int randNum2, APIEnum WebFormVal) {

		return "{\r\n\t\t\"PatientParticipation\": false,\r\n\t\t" + "\"Consents\": [\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"HIPAA Authorization\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-25-02T00:00:00\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"chris10\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"Parent\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"HIPAA Authorization � Designee\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeLastName\": \"g10ayle\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-24-02T00:00:00\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"Patient Services Authorization\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-24-02T00:00:00\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"s10ignertestfullsign\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"Financial Assistance\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-24-02T00:00:00\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"eSignature And Records\",\r\n\t\t\t\t"
				+ "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t" + "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-24-02T00:00:00\"\r\n\t\t\t},\r\n\t\t\t{\r\n\t\t\t\t"
				+ "\"ConsentDesigneeFirstName\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeRelationship\": \"\",\r\n\t\t\t\t" + "\"ExpirationDate\": \"\",\r\n\t\t\t\t"
				+ "\"ConsentProvidedBy\": \"t10etssignfull\",\r\n\t\t\t\t"
				+ "\"ConsentName\": \"Marketing Opt-In\",\r\n\t\t\t\t" + "\"ConsentGivenBy\": \"Patient\",\r\n\t\t\t\t"
				+ "\"ConsentDesigneeLastName\": \"\",\r\n\t\t\t\t"
				+ "\"EffectiveDate\": \"2022-24-02T00:00:00\"\r\n\t\t\t}\r\n\t\t],\r\n\t\t"
				+ "\"FinancialInformation\": {\r\n\t\t\t" + "\"HouseholdIncome\": 45000,\r\n\t\t\t"
				+ "\"HouseholdSize\": 2\r\n\t\t},\r\n\t\t" + "\"ExternalId\": \"\",\r\n\t\t"
				+ "\"Practice\": \"\",\r\n\t\t" + "\"Product\": \"" + WebFormVal + "\",\r\n\t\t"
				+ "\"Patient\": {\r\n\t\t\t" + "\"DateOfBirth\": \"199" + randNum2 % 10 + "-07-0" + randNum2 % 10
				+ "T00:00:00\",\r\n\t\t\t" + "\"Address\": {\r\n\t\t\t\t" + "\"AddressLine2\": \"\",\r\n\t\t\t\t"
				+ "\"AddressLine1\": \"add" + randNum2 + "r strret\",\r\n\t\t\t\t" + "\"State\": \"KS\",\r\n\t\t\t\t"
				+ "\"PostalCode\": 40504,\r\n\t\t\t\t" + "\"Country\": \"\",\r\n\t\t\t\t"
				+ "\"City\": \"kansas\"\r\n\t\t\t},\r\n\t\t\t" + "\"FirstName\": \"c" + randNum1 + "od" + randNum2
				+ "e\",\r\n\t\t\t" + "\"ExternalPatientId\": \"\",\r\n\t\t\t" + "\"Gender\": \"M\",\r\n\t\t\t"
				+ "\"MiddleName\": \"\",\r\n\t\t\t" + "\"EmailAddress\": \"" + randNum2 + "test@check.com" + randNum1
				+ "\",\r\n\t\t\t" + "\"Phones\": [\r\n\t\t\t\t{\r\n\t\t\t\t\t" + "\"Number\": 53463609" + randNum1 % 10
				+ "4,\r\n\t\t\t\t\t" + "\"PhoneType\": 3\r\n\t\t\t\t}\r\n\t\t\t],\r\n\t\t\t"
				+ "\"AuthorizedRepresentatives\": \"\",\r\n\t\t\t"
				+ "\"PatientId\": \"64F3D901-0DCA-4F61-8834-3BECB0C733C6\",\r\n\t\t\t"
				+ "\"ParentGuardian\": {\r\n\t\t\t\t" + "\"FirstName\": \"" + randNum1 + "john" + randNum2
				+ "\",\r\n\t\t\t\t" + "\"LastName\": \"" + randNum1 + "rhode" + randNum2 + "\"\r\n\t\t\t},\r\n\t\t\t"
				+ "\"LastName\": \"Qa" + randNum2 + "R" + randNum1 + "\",\r\n\t\t\t"
				+ "\"PreferredContactType\": 1,\r\n" + "\"SSN\": \"8976\"\r\n\t\t},\r\n\t\t"
				+ "\"PrescribingInformation\": {\r\n\t\t\t" + "\"PatientWeight\": 98,\r\n\t\t\t"
				+ "\"Frequency\": \"\",\r\n\t\t\t" + "\"Icd10\": \"\",\r\n\t\t\t"
				+ "\"PatientWeightUnit\": \"lbs\",\r\n\t\t\t" + "\"Dose\": \"\"\r\n\t\t},\r\n\t\t"
				+ "\"ArxId\": \"9BE17E-04-48A8-BC35-769881YY" + randNum2 + "\" ,\r\n\t\t"
				+ "\"PbmInsurances\": \"\",\r\n\t\t" + "\"Source\": \"PES\",\r\n\t\t" + "\"Prescriber\": \"\",\r\n\t\t"
				+ "\"ServiceType\": \"Patient Services eConsent\",\r\n\t\t"
				+ "\"PatientParticipationEmail\": \"\",\r\n\t\t" + "\"Pharmacy\": \"\",\r\n\t\t"
				+ "\"MedicalInsurances\": \"\",\r\n" + "\"Copay\": {\r\n\t\t\t"
				+ "\"ValidPrescription\": false,\r\n\t\t\t" + "\"CoveredForReimbursement\": false,\r\n\t\t\t"
				+ "\"IsEligibleForCopay\": false,\r\n\t\t\t" + "\"FAPatientAcceptsCopayTerms\": false,\r\n\t\t\t"
				+ "\"IsUsResident\": false,\r\n\t\t\t" + "\"IsMilitary\": \"\",\r\n\t\t\t"
				+ "\"HasGovernmentAssistance\": \"\",\r\n\t\t\t" + "\"HasMilitaryAssistance\": \"\",\r\n\t\t\t"
				+ "\"CardId\": \"\",\r\n\t\t\t" + "\"HasCommercialInsurance\": false\r\n\t\t},\r\n"
				+ "\"Attachments\": [\r\n\t\t\t{\r\n\t\t\t\t" + "\"Extension\": \".pdf\",\r\n\t\t\t\t"
				+ "\"ContentType\": \"application/pdf\",\r\n\t\t\t\t" + "\"Content\": \"JVBE\",\r\n\t\t\t\t"
				+ "\"FileName\": \"Patient Authorization Form\",\r\n\t\t\t\t" + "\"FormType\": \"Consent\",\r\n\t\t\t\t"
				+ "\"Descriptor\": \"Consent Form\",\r\n\t\t\t\t"
				+ "\"AttachmentId\": \"ab3e76e8-f5ba-4ca6-be29-0c0447001fc1\"\r\n\t\t\t},\r\n{\r\n\t\t\t\t"
				+ "\"Extension\": \".pdf\",\r\n\t\t\t\t" + "\"ContentType\": \"application/pdf\",\r\n\t\t\t\t"
				+ "\"Content\": \"JVBE\",\r\n"
				+ "\"FileName\": \"Patient Assistance Program Form_PES_QS_Fabry.pdf\",\r\n\t\t\t\t"
				+ "\"FormType\": \"UploadedFile\",\r\n\t\t\t\t"
				+ "\"Descriptor\": \"Supporting documentation for assistance\",\r\n\t\t\t\t"
				+ "\"AttachmentId\": \"413c92f8-bff6-49d4-a9c3-d12a4378fbed\"\r\n\r\n\t\t\t}\r\n]\r\n\t}";
	}

	/**
	 * Function: To generate payload for Patient Response via AssitRx Quick Start
	 * 
	 * @author skumarsahu
	 * @param randNum1, randNum2, WebFormVal = Nexviazyme
	 * @return Generated payload
	 */

	public static String payloadForAssitRxPatientResponseQS(int randNum1, int randNum2, String zipCode,
			APIEnum WebFormVal) {

		return "{\r\n" + "    \"formSubmittedBy\": \"Patient\",\r\n" + "    \"lastName\": \"ice\",\r\n"
				+ "    \"identifier\": [\r\n" + "        {\r\n" + "            \"type\": \"AssistRx\",\r\n"
				+ "            \"value\": \"7BCA892C-AD1F-49BE-8568-7FA54A96E77C\"\r\n" + "        },\r\n"
				+ "        {\r\n" + "            \"type\": \"ExternalId\",\r\n"
				+ "            \"value\": \"a1g3F000001o1vUQAQ\"\r\n" + "        },\r\n" + "        {\r\n"
				+ "            \"type\": \"iCCHubId\",\r\n" + "            \"value\": \"ICA-000142783\"\r\n"
				+ "        }\r\n" + "    ],\r\n" + "    \"formType\": \"PAP\",\r\n"
				+ "    \"onSanofiProduct\": true,\r\n" + "    \"communicationLanguage\": \"\",\r\n"
				+ "    \"address\": {\r\n" + "        \"zipCode\": \"" + zipCode + "\",\r\n"
				+ "        \"address2\": \"line two\",\r\n" + "        \"city\": \"Dallas\",\r\n"
				+ "        \"address1\": \"address venue\",\r\n" + "        \"addressType\": \"Home\",\r\n"
				+ "        \"primaryAddress\": true,\r\n" + "        \"state\": \"TX\"\r\n" + "    },\r\n"
				+ "    \"gender\": \"M\",\r\n" + "    \"isCareGiver\": false,\r\n" + "    \"homePhone\": \"9856"
				+ randNum1 + "9754\",\r\n" + "    \"dateOfBirth\": \"1996-0" + randNum2 % 10 + "-0" + randNum1 % 10
				+ "T00:00:00\",\r\n" + "    \"program\": [\r\n" + "        {\r\n"
				+ "            \"isEventPresent\": false,\r\n" + "            \"disease\": \"Pompe\",\r\n"
				+ "            \"engagementProgramName\": \"CareConnectPSS Nexviazyme\",\r\n"
				+ "            \"enrollmentDate\": \"2022-11-17\",\r\n" + "            \"Practice\": {\r\n"
				+ "                \"OfficeContactRole\": \"Chief Doctor\",\r\n"
				+ "                \"Email\": null,\r\n" + "                \"Address\": {\r\n"
				+ "                    \"AddressLine2\": null,\r\n"
				+ "                    \"AddressLine1\": \"addres road one\",\r\n"
				+ "                    \"State\": \"TX\",\r\n" + "                    \"PostalCode\": \"75001\",\r\n"
				+ "                    \"Country\": null,\r\n" + "                    \"City\": \"Dallas\"\r\n"
				+ "                },\r\n"
				+ "                \"PracticeId\": \"23bd2908-690a-465b-980c-58ec9dc66cb9\",\r\n"
				+ "                \"Phone\": {\r\n" + "                    \"Number\": \"98" + randNum1 + "21"
				+ randNum2 + "12\",\r\n" + "                    \"PhoneType\": 0\r\n" + "                },\r\n"
				+ "                \"OfficeContactName\": \"Dr santhanam\",\r\n" + "                \"Fax\": {\r\n"
				+ "                    \"Number\": \"9873213221\",\r\n" + "                    \"PhoneType\": 0\r\n"
				+ "                },\r\n" + "                \"Name\": \"happy care\"\r\n" + "            },\r\n"
				+ "            \"patientParticipation\": false,\r\n" + "            \"consent\": [\r\n"
				+ "                {\r\n" + "                    \"designeeLastName\": \"\",\r\n"
				+ "                    \"endDate\": \"\",\r\n"
				+ "                    \"designeeRelationship\": \"\",\r\n"
				+ "                    \"permission\": \"Granted\",\r\n"
				+ "                    \"consentSource\": \"\",\r\n"
				+ "                    \"serviceName\": \"RD HIPAA Auth (PAP)\",\r\n"
				+ "                    \"responseDate\": \"2022-11-17\",\r\n"
				+ "                    \"eSigned\": true,\r\n" + "                    \"designeeFirstName\": \"\",\r\n"
				+ "                    \"consentProvidedBy\": \"Patient\",\r\n"
				+ "                    \"consentType\": \"Electronic\",\r\n"
				+ "                    \"documentId\": \"405daea1-f726-40ab-b0ea-a398f3b0d778\",\r\n"
				+ "                    \"startDate\": \"2022-11-17\",\r\n"
				+ "                    \"consentFormVersion\": \"PAP MAT-US-2104208-V4.0-08/2021\"\r\n"
				+ "                },\r\n" + "                {\r\n"
				+ "                    \"designeeLastName\": \"\",\r\n" + "                    \"endDate\": \"\",\r\n"
				+ "                    \"designeeRelationship\": \"\",\r\n"
				+ "                    \"permission\": \"Granted\",\r\n"
				+ "                    \"consentSource\": \"\",\r\n"
				+ "                    \"serviceName\": \"RD PAP Authorization\",\r\n"
				+ "                    \"responseDate\": \"2022-11-17\",\r\n"
				+ "                    \"eSigned\": true,\r\n" + "                    \"designeeFirstName\": \"\",\r\n"
				+ "                    \"consentProvidedBy\": \"Patient\",\r\n"
				+ "                    \"consentType\": \"Electronic\",\r\n"
				+ "                    \"documentId\": \"405daea1-f726-40ab-b0ea-a398f3b0d778\",\r\n"
				+ "                    \"startDate\": \"2022-11-17\",\r\n"
				+ "                    \"consentFormVersion\": \"PAP MAT-US-2104208-V4.0-08/2021\"\r\n"
				+ "                }\r\n" + "            ],\r\n" + "            \"productName\": \"Nexviazyme\",\r\n"
				+ "            \"Prescriber\": {\r\n" + "                \"Specialty\": null,\r\n"
				+ "                \"PrescriberInUS\": null,\r\n" + "                \"Npi\": \"9484899848\",\r\n"
				+ "                \"FirstName\": \"hcp\",\r\n" + "                \"DeaNumber\": \"98899\",\r\n"
				+ "                \"TaxIdNumber\": \"88989\",\r\n" + "                \"LastName\": \"prescribe\",\r\n"
				+ "                \"PrescriberId\": \"00000000-0000-0000-0000-000000000000\",\r\n"
				+ "                \"StateLicenseNumber\": \"898989\"\r\n" + "            },\r\n"
				+ "            \"prescription\": {\r\n" + "                \"dosage\": \"1mg\",\r\n"
				+ "                \"weightInKg\": \"78\",\r\n"
				+ "                \"diagnosisCode\": \"8845465454\",\r\n" + "                \"documentId\": \"\",\r\n"
				+ "                \"dosageFrequency\": \"every day\",\r\n" + "                \"weightInLb\": \"\"\r\n"
				+ "            },\r\n" + "            \"documentId\": [\r\n" + "                {\r\n"
				+ "                    \"id\": \"405daea1-f726-40ab-b0ea-a398f3b0d778\"\r\n" + "                }\r\n"
				+ "            ],\r\n" + "            \"leadChannel\": \"AssistRx\",\r\n"
				+ "            \"status\": \"Pending\",\r\n" + "            \"patientParticipationEmail\": \"\"\r\n"
				+ "        }\r\n" + "    ],\r\n" + "    \"lastFourDigitSSN\": \"\",\r\n"
				+ "    \"firstName\": \"Autotest\",\r\n" + "    \"mobilePhone\": \"9879879876\",\r\n"
				+ "    \"attachment\": [\r\n" + "        {\r\n"
				+ "            \"fileName\": \"HCP_Patient Assistance Program Form\",\r\n"
				+ "            \"attachmentType\": \"EnrollmentForm\",\r\n"
				+ "            \"fileExtension\": \".pdf\",\r\n"
				+ "            \"attachmentCategory\": \"Enrollment Form;; Patient Consent\",\r\n"
				+ "            \"externalId\": \"907c7cc6-26ea-4088-8672-5bf475c319eb\",\r\n"
				+ "            \"descriptor\": \"Enrollment Form\",\r\n"
				+ "            \"contentType\": \"application/pdf\",\r\n"
				+ "            \"attachmentSource\": \"AssistRx\",\r\n" + "            \"content\": \"JVBER\"\r\n"
				+ "        },\r\n" + "        {\r\n"
				+ "            \"fileName\": \"PES_Patient Assistance Program Form\",\r\n"
				+ "            \"attachmentType\": \"Consent\",\r\n" + "            \"fileExtension\": \".pdf\",\r\n"
				+ "            \"attachmentCategory\": \"Patient Consent\",\r\n"
				+ "            \"externalId\": \"405daea1-f726-40ab-b0ea-a398f3b0d778\",\r\n"
				+ "            \"descriptor\": \"Consent Form\",\r\n"
				+ "            \"contentType\": \"application/pdf\",\r\n"
				+ "            \"attachmentSource\": \"AssistRx\",\r\n" + "            \"content\": \"JVBE\"\r\n"
				+ "        }\r\n" + "    ],\r\n" + "    \"preferredCommunicationChannel\": \"\",\r\n"
				+ "    \"accountSource\": \"Website\",\r\n" + "    \"healthPlans\": [\r\n" + "        {\r\n"
				+ "            \"idPolicyNo\": \"9347537\",\r\n" + "            \"rxGrp\": \"\",\r\n"
				+ "            \"planType\": \"Primary\",\r\n" + "            \"rxCardId\": \"\",\r\n"
				+ "            \"cardholderEmployer\": \"\",\r\n" + "            \"planSubCategory\": \"\",\r\n"
				+ "            \"recordType\": \"Medical Plan\",\r\n" + "            \"planCategory\": \"\",\r\n"
				+ "            \"rxPCN\": \"\",\r\n" + "            \"renewalDate\": \"\",\r\n"
				+ "            \"insurancePhoneNo\": \"875-896-8046\",\r\n"
				+ "            \"cardholderLastName\": \"ice\",\r\n"
				+ "            \"cardholderDateOfBirth\": \"\",\r\n"
				+ "            \"cardholderFirstName\": \"autotest\",\r\n"
				+ "            \"insuranceProvider\": \"Full insured\",\r\n"
				+ "            \"cardholderRelationToPatient\": \"Self\",\r\n" + "            \"pbmPhoneNo\": \"\",\r\n"
				+ "            \"groupNo\": \"983\",\r\n" + "            \"effectiveDate\": \"\",\r\n"
				+ "            \"rxBin\": \"\",\r\n" + "            \"expirationDate\": \"\"\r\n" + "        }\r\n"
				+ "    ],\r\n" + "    \"isOther\": false,\r\n" + "    \"email\": \"testpat@san.com\"\r\n" + "}";
	}

	/**
	 * Function: To generate payload for AssitRx QuickStart To HCP Portal RD
	 * 
	 * @author Dipali Yadav
	 * @param randNum1, randNum2, WebFormVal = Cerdelga,Lumizyme etc.
	 * @return Generated payload to HCP Portal.
	 */

	public static String payloadForAssitRxQuickStartRDHCPPortal(int randNum1, int randNum2, String expZip,
			APIEnum WebFormVal) {
		return "{\r\n" + "	\"PatientParticipation\": true,\r\n" + "	\"Consents\": [\r\n" + "		{\r\n"
				+ "			\"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "			\"ConsentDesigneeRelationship\": \"\",\r\n" + "			\"ExpirationDate\": \"\",\r\n"
				+ "			\"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "			\"ConsentName\": \"eSignature And Records\",\r\n"
				+ "			\"ConsentGivenBy\": \"\",\r\n" + "			\"ConsentDesigneeLastName\": \"\",\r\n"
				+ "			\"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "		},\r\n" + "		{\r\n"
				+ "			\"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "			\"ConsentDesigneeRelationship\": \"\",\r\n" + "			\"ExpirationDate\": \"\",\r\n"
				+ "			\"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "			\"ConsentName\": \"QuickStartPrescriberCertification\",\r\n"
				+ "			\"ConsentGivenBy\": \"\",\r\n" + "			\"ConsentDesigneeLastName\": \"\",\r\n"
				+ "			\"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "		}\r\n" + "	],\r\n"
				+ "    \"FinancialInformation\": \"\",\r\n" + "    \"ExternalId\": \"\",\r\n"
				+ "    \"Practice\": {\r\n" + "        \"OfficeContactRole\": \"\",\r\n"
				+ "        \"Email\": \"\",\r\n" + "        \"Address\": {\r\n"
				+ "            \"AddressLine2\": \"\",\r\n" + "            \"AddressLine1\": \"Mck01\",\r\n"
				+ "            \"State\": \"NY\",\r\n" + "            \"PostalCode\": 10005,\r\n"
				+ "            \"Country\": \"\",\r\n" + "            \"City\": \"Manhattan\"\r\n" + "        },\r\n"
				+ "        \"PracticeId\": \"3c4afb1a-ca05-4645-89e6-1c611bafb8b6\",\r\n" + "        \"Phone\": {\r\n"
				+ "            \"Number\": 9632587410,\r\n" + "            \"PhoneType\": 0\r\n" + "        },\r\n"
				+ "        \"OfficeContactName\": \"\",\r\n" + "        \"Fax\": {\r\n"
				+ "            \"Number\": 9513246870,\r\n" + "            \"PhoneType\": 0\r\n" + "        },\r\n"
				+ "        \"Name\": \"Sanofitest\"\r\n" + "    },\r\n" + "    \"Product\": \"" + WebFormVal + "\",\r\n"
				+ "    \"Patient\": {\r\n" + "        \"DateOfBirth\": \"199" + randNum2 % 10 + "-07-0" + randNum2 % 10
				+ "T00:00:00\",\r\n\t\t\t" + "        \"Address\": {\r\n" + "            \"AddressLine2\": \"\",\r\n"
				+ "            \"AddressLine1\": \"S2\",\r\n" + "            \"State\": \"NY\",\r\n"
				+ "            \"PostalCode\": \"" + expZip + "\",\r\n" + "            \"Country\": \"\",\r\n"
				+ "            \"City\": \"Manhattan\"\r\n" + "        },\r\n"
				+ "        \"FirstName\": \"QuickStartTest" + randNum2 + "R" + randNum1 + "\",\r\n"
				+ "        \"ExternalPatientId\": \"\",\r\n" + "        \"Gender\": \"M\",\r\n"
				+ "        \"MiddleName\": \"\",\r\n" + "        \"EmailAddress\": \"rdassistrxQuickStart@check"
				+ randNum1 + ".com\",\r\n" + "        \"Phones\": {\r\n" + "            \"Number\": \"99521588"
				+ randNum1 + "\",\r\n" + "            \"PhoneType\": 2\r\n" + "        },\r\n"
				+ "        \"AuthorizedRepresentatives\": \"\",\r\n" + "        \"PatientId\": \"5" + randNum1
				+ "8Z1B7-5E" + randNum2 + "-471F-" + generateRandomString(1) + "DA-6B3A" + generateRandomString(1)
				+ "2114\",\r\n" + "        \"ParentGuardian\": \"\",\r\n" + "        \"LastName\": \"Testing" + randNum2
				+ "R" + randNum1 + "\",\r\n" + "        \"PreferredContactType\": 0\r\n" + "    },\r\n"
				+ "    \"PrescribingInformation\": {\r\n" + "        \"PatientWeight\": 83,\r\n"
				+ "        \"Milligrams\": 20,\r\n" + "        \"Frequency\": \"Once in a week\",\r\n"
				+ "        \"Icd10\": 1021232551,\r\n" + "        \"PatientWeightUnit\": \"kgs\"\r\n" + "    },\r\n"
				+ "    \"ArxId\": \"11c2674f-" + randNum2 + "4d-" + generateRandomString(1) + "7b-b6a4-af64d1bef7"
				+ generateRandomString(1) + "\",\r\n" + "    \"PbmInsurances\": {\r\n"
				+ "        \"InsuranceId\": \"2eadf8c1-1a13-461f-bff7-8acd8e0e4409\",\r\n"
				+ "        \"RelationshipToMember\": \"\",\r\n" + "        \"Rank\": 1,\r\n"
				+ "        \"ProcessorControlNumber\": \"\",\r\n"
				+ "        \"PolicyHolderBirthDate\": \"1996-11-11T00:00:00\",\r\n"
				+ "        \"PolicyHolderLastName\": \"Motors\",\r\n" + "        \"InsuranceGroupNumber\": \"\",\r\n"
				+ "        \"PbmName\": \"\",\r\n" + "        \"PolicyHolderFirstName\": \"Ford\",\r\n"
				+ "        \"PlanType\": \"Medicaid Plan\",\r\n" + "        \"BankIdentificationNumber\": \"\",\r\n"
				+ "        \"PhoneNumber\": \"\",\r\n" + "        \"InsuranceMemberNumber\": \"\"\r\n" + "    },\r\n"
				+ "    \"Source\": \"HCP\",\r\n" + "    \"Prescriber\": {\r\n" + "        \"Specialty\": \"\",\r\n"
				+ "        \"PrescriberInUS\": \"\",\r\n" + "        \"Npi\": 1236547896,\r\n"
				+ "        \"FirstName\": \"Hyun\",\r\n" + "        \"DeaNumber\": 165161566,\r\n"
				+ "        \"TaxIdNumber\": \"\",\r\n" + "        \"LastName\": \"Bin\",\r\n"
				+ "        \"PrescriberId\": \"00000000-0000-0000-0000-000000000000\",\r\n"
				+ "        \"StateLicenseNumber\": 12654119\r\n" + "    },\r\n"
				+ "    \"ServiceType\": \"QuickStart\",\r\n"
				+ "    \"PatientParticipationEmail\": \"kindhupraveen@deloitte.com\",\r\n"
				+ "    \"Pharmacy\": \"\",\r\n" + "    \"Copay\": \"\",\r\n" + "    \"MedicalInsurances\": {\r\n"
				+ "        \"PolicyHolderBirthDate\": \"1996-11-11T00:00:00\",\r\n"
				+ "        \"PolicyHolderLastName\": \"Motors\",\r\n"
				+ "        \"InsuranceGroupNumber\": 10963256,\r\n"
				+ "        \"InsuranceId\": \"2eadf8c1-1a13-461f-bff7-8acd8e0e4409\",\r\n"
				+ "        \"RelationshipToMember\": \"\",\r\n" + "        \"PolicyHolderFirstName\": \"Ford\",\r\n"
				+ "        \"FaxNumber\": \"\",\r\n" + "        \"InsuranceCompanyName\": \"Magna Life saver\",\r\n"
				+ "        \"PlanType\": \"Commercial\",\r\n" + "        \"PhoneNumber\": \"999-521-5484\",\r\n"
				+ "        \"Rank\": 1,\r\n" + "        \"InsuranceMemberNumber\": 63262625\r\n" + "    }\r\n" + "}";

	}

	/**
	 * Function: To generate payload for AssitRx QuickStart To patient Portal RD
	 * 
	 * @author Dipali Yadav
	 * @param randNum1, randNum2, WebFormVal = Cerdelga,Lumizyme etc.
	 * @return Generated payload to patient Portal.
	 */

	public static String payloadForAssitRxQuickStartRDPatientPortal(int randNum1, int randNum2, String expZip,
			APIEnum WebFormVal) {
		return "{\r\n" + "    \"PatientParticipation\": true,\r\n" + "    \"Consents\": [\r\n" + "        {\r\n"
				+ "            \"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "            \"ConsentDesigneeRelationship\": \"\",\r\n" + "            \"ExpirationDate\": \"\",\r\n"
				+ "            \"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "            \"ConsentName\": \"CareConnectPSSQSShareHealthInfoConsent\",\r\n"
				+ "            \"ConsentGivenBy\": \"Patient\",\r\n"
				+ "            \"ConsentDesigneeLastName\": \"\",\r\n"
				+ "            \"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "        },\r\n" + "        {\r\n"
				+ "            \"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "            \"ConsentDesigneeRelationship\": \"\",\r\n" + "            \"ExpirationDate\": \"\",\r\n"
				+ "            \"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "            \"ConsentName\": \"eSignature And Records\",\r\n"
				+ "            \"ConsentGivenBy\": \"Patient\",\r\n"
				+ "            \"ConsentDesigneeLastName\": \"\",\r\n"
				+ "            \"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "        },\r\n" + "        {\r\n"
				+ "            \"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "            \"ConsentDesigneeRelationship\": \"\",\r\n" + "            \"ExpirationDate\": \"\",\r\n"
				+ "            \"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "            \"ConsentName\": \"PSSQuickStartConsent\",\r\n"
				+ "            \"ConsentGivenBy\": \"Patient\",\r\n"
				+ "            \"ConsentDesigneeLastName\": \"\",\r\n"
				+ "            \"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "        }\r\n" + "    ],\r\n"
				+ "    \"FinancialInformation\": \"\",\r\n" + "    \"ExternalId\": \"\",\r\n"
				+ "    \"Practice\": {\r\n" + "        \"OfficeContactRole\": \"\",\r\n"
				+ "        \"Email\": \"\",\r\n" + "        \"Address\": {\r\n"
				+ "            \"AddressLine2\": \"\",\r\n" + "            \"AddressLine1\": \"Mck01\",\r\n"
				+ "            \"State\": \"NY\",\r\n" + "            \"PostalCode\": 10005,\r\n"
				+ "            \"Country\": \"\",\r\n" + "            \"City\": \"Manhattan\"\r\n" + "        },\r\n"
				+ "        \"PracticeId\": \"3c4afb1a-ca05-4645-89e6-1c611bafb8b6\",\r\n" + "        \"Phone\": {\r\n"
				+ "            \"Number\": 9632587410,\r\n" + "            \"PhoneType\": 0\r\n" + "        },\r\n"
				+ "        \"OfficeContactName\": \"\",\r\n" + "        \"Fax\": {\r\n"
				+ "            \"Number\": 9513246870,\r\n" + "            \"PhoneType\": 0\r\n" + "        },\r\n"
				+ "        \"Name\": \"Sanofitest\"\r\n" + "    },\r\n" + "    \"Product\": \"" + WebFormVal + "\",\r\n"
				+ "    \"Patient\": {\r\n" + "        \"DateOfBirth\": \"198" + randNum2 % 10 + "-07-0" + randNum2 % 10
				+ "T00:00:00\",\r\n\t\t\t" + "        \"Address\": {\r\n" + "            \"AddressLine2\": \"\",\r\n"
				+ "            \"AddressLine1\": \"S2\",\r\n" + "            \"State\": \"NY\",\r\n"
				+ "            \"PostalCode\": \"" + expZip + "\",\r\n" + "            \"Country\": \"\",\r\n"
				+ "            \"City\": \"Manhattan\"\r\n" + "        },\r\n"
				+ "        \"FirstName\": \"QuickStartTest" + randNum2 + "R" + randNum1 + "\",\r\n"
				+ "        \"ExternalPatientId\": \"\",\r\n" + "        \"Gender\": \"M\",\r\n"
				+ "        \"MiddleName\": \"\",\r\n" + "        \"EmailAddress\": \"rdassistrxQuickStart@check"
				+ randNum1 + ".com\",\r\n\t\t\t" + "        \"Phones\": {\r\n" + "            \"Number\": \"99521588"
				+ randNum1 + "\",\r\n" + "            \"PhoneType\": 2\r\n" + "        },\r\n"
				+ "        \"AuthorizedRepresentatives\": \"\",\r\n" + "        \"PatientId\": \"5" + randNum1
				+ "8Z1B7-5E" + randNum2 + "-471F-" + generateRandomString(1) + "DA-6B3A" + generateRandomString(1)
				+ "2114\",\r\n" + "        \"ParentGuardian\": \"\",\r\n" + "        \"LastName\": \"Testing" + randNum2
				+ "R" + randNum1 + "\",\r\n" + "        \"PreferredContactType\": 0\r\n" + "    },\r\n"
				+ "    \"PrescribingInformation\": {\r\n" + "        \"PatientWeight\": 83,\r\n"
				+ "        \"Milligrams\": 20,\r\n" + "        \"Frequency\": \"Once in a week\",\r\n"
				+ "        \"Icd10\": 1021232551,\r\n" + "        \"PatientWeightUnit\": \"kgs\"\r\n" + "    },\r\n"
				+ "    \"ArxId\": \"11c2674f-" + randNum2 + "4d-" + generateRandomString(1) + "7b-b6a4-af64d1bef7"
				+ generateRandomString(1) + "\",\r\n" + "    \"PbmInsurances\": {\r\n"
				+ "        \"InsuranceId\": \"2eadf8c1-1a13-461f-bff7-8acd8e0e4409\",\r\n"
				+ "        \"RelationshipToMember\": \"\",\r\n" + "        \"Rank\": 1,\r\n"
				+ "        \"ProcessorControlNumber\": \"\",\r\n"
				+ "        \"PolicyHolderBirthDate\": \"1996-11-11T00:00:00\",\r\n"
				+ "        \"PolicyHolderLastName\": \"Motors\",\r\n" + "        \"InsuranceGroupNumber\": \"\",\r\n"
				+ "        \"PbmName\": \"\",\r\n" + "        \"PolicyHolderFirstName\": \"Ford\",\r\n"
				+ "        \"PlanType\": \"Medicaid Plan\",\r\n" + "        \"BankIdentificationNumber\": \"\",\r\n"
				+ "        \"PhoneNumber\": \"\",\r\n" + "        \"InsuranceMemberNumber\": \"\"\r\n" + "    },\r\n"
				+ "    \"Source\": \"PES\",\r\n" + "    \"Prescriber\": {\r\n" + "        \"Specialty\": \"\",\r\n"
				+ "        \"PrescriberInUS\": \"\",\r\n" + "        \"Npi\": 1236547896,\r\n"
				+ "        \"FirstName\": \"Hyun\",\r\n" + "        \"DeaNumber\": 165161566,\r\n"
				+ "        \"TaxIdNumber\": \"\",\r\n" + "        \"LastName\": \"Bin\",\r\n"
				+ "        \"PrescriberId\": \"00000000-0000-0000-0000-000000000000\",\r\n"
				+ "        \"StateLicenseNumber\": 12654119\r\n" + "    },\r\n"
				+ "    \"ServiceType\": \"QuickStart\",\r\n"
				+ "    \"PatientParticipationEmail\": \"kindhupraveen@deloitte.com\",\r\n"
				+ "    \"Pharmacy\": \"\",\r\n" + "    \"Copay\": \"\",\r\n" + "    \"MedicalInsurances\": {\r\n"
				+ "        \"PolicyHolderBirthDate\": \"1996-11-11T00:00:00\",\r\n"
				+ "        \"PolicyHolderLastName\": \"Motors\",\r\n"
				+ "        \"InsuranceGroupNumber\": 10963256,\r\n"
				+ "        \"InsuranceId\": \"2eadf8c1-1a13-461f-bff7-8acd8e0e4409\",\r\n"
				+ "        \"RelationshipToMember\": \"\",\r\n" + "        \"PolicyHolderFirstName\": \"Ford\",\r\n"
				+ "        \"FaxNumber\": \"\",\r\n" + "        \"InsuranceCompanyName\": \"Magna Life saver\",\r\n"
				+ "        \"PlanType\": \"Commercial\",\r\n" + "        \"PhoneNumber\": \"999-521-5484\",\r\n"
				+ "        \"Rank\": 1,\r\n" + "        \"InsuranceMemberNumber\": 63262625\r\n" + "    }\r\n" + "}";
	}

	/**
	 * Function: To setup and hit API for AssistRx RD copay Enrollement with program
	 * case get created
	 * 
	 * @author skumarsahu/Pratiksha Dixit
	 * @param randNum1, randNum2, WebFormVal = RD product-Lumizyme,Cerdelga etc.
	 * @return API response
	 */
	public static String apiSetupForEnrollmentORWithDrawalThroughMcKesson(String accessToken, int randNum1,
			int randNum2, String zipCode, String enrollDate, APIEnum WebFormVal, String enddate, boolean withDrawal,
			String icaId) {
		String respo = "";
		if (withDrawal) {
			given().auth().oauth2(accessToken)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constApiKey, mCK_ApiKey)
					.body(Payload.payloadForMcKessonCoPayWithdrawal(randNum1, randNum2, WebFormVal, enrollDate, enddate,
							zipCode, icaId))
					.post(mCK_Endpoint_URL).then().assertThat().statusCode(200).extract().response().asString();
		} else {
			respo = given().auth().oauth2(accessToken)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constApiKey, mCK_ApiKey)
					.body(Payload.payloadForMcKessonCoPayEnrollment(randNum1, randNum2, zipCode, enrollDate,
							WebFormVal))
					.post(mCK_Endpoint_URL).then().assertThat().statusCode(200).extract().response().asString();

		}
		return respo;
	}

	/**
	 * Function: To generate payload for McKesson CoPay Withdrawal
	 * 
	 * @author Pratiksha Dixit
	 * @param randNum1, randNum2, WebFormVal = Cablivi/Eloctate/Alprolix/CAD/Enjaymo
	 * @return Generated payload
	 */

	public static String payloadForMcKessonCoPayWithdrawal(int randNum1, int randNum2, APIEnum WebFormVal,
			String enrollDate, String enrollEndDate, String zipcodeValue, String icaId) {
		return "{\r\n" + "    \"Patient_Address_Line1\": \"PARIS HILL ST\",\r\n" + "    \"Patient_Product\": \""
				+ WebFormVal + "\",\r\n" + "    \"Mckesson_Patient_ID\": 6495" + randNum1 % 10 + randNum1 % 10
				+ randNum1 % 10 + ",\r\n" + "    \"Rx_Group_Number\": 50777984,\r\n"
				+ "    \"Patient_Is_US_Resident\": \"Yes\",\r\n"
				+ "    \"Patient_Copay_Program_Vendor\": \"McKesson\",\r\n"
				+ "    \"Patient_Benefit_Type\": \"Commercial\",\r\n"
				+ "    \"Patient_Consent_Status\": \"Consented\",\r\n" + "    \"Medical_Copay_ID\": 178426"
				+ randNum1 % 10 + ",\r\n" + "    \"Patient_Email\": \"terry" + randNum1 + "@vbase.com\",\r\n"
				+ "    \"Patient_Date_Of_Birth\": \"12/1" + randNum2 % 10 + "/199" + randNum2 % 10 + "\" ,\r\n"
				+ "    \"Patient_Copay_Enrollment_Status\": \"Declined/Discontinued\",\r\n"
				+ "    \"Patient_Enrollment_Type\": \"TERMINATE\",\r\n" + "    \"Initial_Enrollment_Date\": \""
				+ enrollDate + "\",\r\n" + "    \"Charitable_End_Date\": \"" + enrollEndDate + "\",\r\n"
				+ "    \"Charitable_Start_Date\": \"" + enrollDate + "\",\r\n" + "    \"Patient_FirstName\": \""
				+ randNum1 + "John" + randNum2 + "\",\r\n" + "    \"Patient_LastName\": \"" + randNum2 + "Daley"
				+ randNum1 + "\",\r\n" + "    \"Patient_State\": \"AZ\",\r\n" + "    \"Patient_PNT_ID\": \"" + icaId
				+ "\",\r\n" + "    \"Pharmacy_Card_ID\": 2029958219,\r\n" + "    \"Patient_City\": \"SCOTTSDALE\",\r\n"
				+ "    \"Rx_Bin_Number\": 610524,\r\n" + "    \"Initial_Enrollment_Date\": \"" + enrollDate + "\",\r\n"
				+ "    \"Patient_Copay_Enrollment_Source\": \"GENESIS\",\r\n" + "    \"Salesforce_Patient_ID\": \""
				+ icaId + "\",\r\n" + "    \"Patient_Consent_Source\": \"GENESIS\",\r\n" + "    \"Patient_Zipcode\": "
				+ zipcodeValue + ",\r\n" + "    \"Patient_Gender\": \"M\"\r\n" + "}";

	}

	/**
	 * Function: To generate payload for Assist Rx Patient Enrollment without any
	 * Service case To PatientProtal RD
	 * 
	 * @author Dipali Yadav
	 * @param randNum1, randNum2, WebFormVal = Cerdelga etc.
	 * @return Generated payload
	 */
	public static String payloadForAssitRxPatientEnrollmentRDPatientPortal(String patientFName, String patientLName,
			String DOB, String emailID, String phoneNumber, int randNum2, String expZip, String payerName,
			APIEnum WebFormVal) {
		return "{\r\n" + "    \"PatientParticipation\": true,\r\n" + "    \"Consents\": [\r\n" + "        {\r\n"
				+ "            \"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "            \"ConsentDesigneeRelationship\": \"\",\r\n" + "            \"ExpirationDate\": \"\",\r\n"
				+ "            \"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "            \"ConsentName\": \"Patient Services Authorization\",\r\n"
				+ "            \"ConsentGivenBy\": \"Patient\",\r\n"
				+ "            \"ConsentDesigneeLastName\": \"\",\r\n"
				+ "            \"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "        },\r\n" + "        {\r\n"
				+ "            \"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "            \"ConsentDesigneeRelationship\": \"\",\r\n" + "            \"ExpirationDate\": \"\",\r\n"
				+ "            \"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "            \"ConsentName\": \"eSignature And Records\",\r\n"
				+ "            \"ConsentGivenBy\": \"Patient\",\r\n"
				+ "            \"ConsentDesigneeLastName\": \"\",\r\n"
				+ "            \"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "        },\r\n" + "        {\r\n"
				+ "            \"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "            \"ConsentDesigneeRelationship\": \"\",\r\n" + "            \"ExpirationDate\": \"\",\r\n"
				+ "            \"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "            \"ConsentName\": \"HIPAA Authorization\",\r\n"
				+ "            \"ConsentGivenBy\": \"Patient\",\r\n"
				+ "            \"ConsentDesigneeLastName\": \"\",\r\n"
				+ "            \"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "        }\r\n" + "    ],\r\n"
				+ "    \"FinancialInformation\": null,\r\n" + "    \"ExternalId\": \"\",\r\n"
				+ "    \"Practice\": \"\",\r\n" + "    \"Product\": \"" + WebFormVal + "\",\r\n"
				+ "    \"Patient\": {\r\n" + "        \"DateOfBirth\": \"" + DOB + "\",\r\n"
				+ "        \"Address\": {\r\n" + "            \"AddressLine2\": \"\",\r\n"
				+ "            \"AddressLine1\": \"S3\",\r\n" + "            \"State\": \"NY\",\r\n"
				+ "            \"PostalCode\": \"" + expZip + "\",\r\n" + "            \"Country\": \"\",\r\n"
				+ "            \"City\": \"Manhattan\"\r\n" + "        },\r\n" + "        \"FirstName\": \""
				+ patientFName + "\",\r\n" + "        \"ExternalPatientId\": \"\",\r\n"
				+ "        \"Gender\": \"M\",\r\n" + "        \"MiddleName\": \"\",\r\n"
				+ "        \"EmailAddress\": \"" + emailID + "\",\r\n" + "        \"Phones\": {\r\n"
				+ "            \"Number\": \"" + phoneNumber + "\",\r\n" + "            \"PhoneType\": 2\r\n"
				+ "        },\r\n" + "        \"AuthorizedRepresentatives\": \"\",\r\n" + "        \"PatientId\": \"5"
				+ randNum2 + "9G1B7-5E" + randNum2 + "-991K-" + generateRandomString(1) + "BA-6B3A"
				+ generateRandomString(1) + "2114\",\r\n" + "        \"ParentGuardian\": null,\r\n"
				+ "        \"LastName\": \"" + patientLName + "\",\r\n" + "        \"PreferredContactType\": 0\r\n"
				+ "    },\r\n" + "    \"PrescribingInformation\": null,\r\n" + "    \"ArxId\": \"166h2674f-" + randNum2
				+ "9j-" + generateRandomString(1) + "7b-b6a4-af90k1bef7" + generateRandomString(1) + "\",\r\n"
				+ "    \"PbmInsurances\": \"\",\r\n" + "    \"Attachments\": [\r\n"
				+ "        \"Extension\": \".pdf\",\r\n" + "        \"ContentType\": \"application/pdf\",\r\n"
				+ "        \"Content\": \"JVBE\",\r\n"
				+ "        \"FileName\": \"PES_CareConnectPSS Patient Enrollment Form\",\r\n"
				+ "        \"FormType\": \"EnrollmentForm\",\r\n" + "        \"Descriptor\": \"Enrollment Form\",\r\n"
				+ "        \"AttachmentId\": \"afde9dc0-8366-4f76-84df-022b54230883\"\r\n" + "    ],\r\n"
				+ "    \"Source\": \"PES\",\r\n" + "    \"Prescriber\": \"\",\r\n"
				+ "    \"ServiceType\": \"ProgramEnrollment\",\r\n" + "    \"PatientParticipationEmail\": \"\",\r\n"
				+ "    \"Pharmacy\": \"\",\r\n" + "    \"Copay\": null,\r\n" + "    \"MedicalInsurances\": [\r\n"
				+ "        \"PolicyHolderBirthDate\": \"" + DOB + "\",\r\n"
				+ "        \"PolicyHolderLastName\": \"TestMotors56R\",\r\n"
				+ "        \"InsuranceGroupNumber\": 6325783,\r\n" + "        \"InsuranceId\": \"\",\r\n"
				+ "        \"RelationshipToMember\": \"\",\r\n"
				+ "        \"PolicyHolderFirstName\": \"APIFord56R\",\r\n" + "        \"FaxNumber\": \"\",\r\n"
				+ "        \"InsuranceCompanyName\": \"" + payerName + "\",\r\n"
				+ "        \"PlanType\": \"Primary\",\r\n" + "        \"PhoneNumber\": \"764-236-7888\",\r\n"
				+ "        \"Rank\": 1,\r\n" + "        \"InsuranceMemberNumber\": 743728\r\n" + "    ]\r\n" + "}";

	}

	/**
	 * Function: To generate payload for Assist Rx Patient Enrollment with health
	 * plan update and without any Service case creation To HCP Portal RD
	 * 
	 * @author Dipali Yadav
	 * @param randNum1, randNum2, WebFormVal = Cerdelga etc.
	 * @return Generated payload
	 */
	public static String payloadForAssitRxPatientEnrollmentWithHealthPlanUpdateRDHCPPortal(String patientFName,
			String patientLName, String DOB, String emailID, String phoneNumber, int randNum2, String expZip,
			String payerName, APIEnum WebFormVal) {
		return "{\r\n" + "    \"PatientParticipation\": true,\r\n" + "    \"Consents\": [\r\n" + "        {\r\n"
				+ "            \"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "            \"ConsentDesigneeRelationship\": \"\",\r\n" + "            \"ExpirationDate\": \"\",\r\n"
				+ "            \"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "            \"ConsentName\": \"eSignature And Records\",\r\n"
				+ "            \"ConsentGivenBy\": \"\",\r\n" + "            \"ConsentDesigneeLastName\": \"\",\r\n"
				+ "            \"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "        },\r\n" + "        {\r\n"
				+ "            \"ConsentDesigneeFirstName\": \"\",\r\n"
				+ "            \"ConsentDesigneeRelationship\": \"\",\r\n" + "            \"ExpirationDate\": \"\",\r\n"
				+ "            \"ConsentProvidedBy\": \"Fordmotors\",\r\n"
				+ "            \"ConsentName\": \"PAPPrescriberCertification\",\r\n"
				+ "            \"ConsentGivenBy\": \"\",\r\n" + "            \"ConsentDesigneeLastName\": \"\",\r\n"
				+ "            \"EffectiveDate\": \"2022-04-01T00:00:00\"\r\n" + "        }\r\n" + "    ],\r\n"
				+ "    \"FinancialInformation\": \"\",\r\n" + "    \"ExternalId\": \"\",\r\n"
				+ "    \"Practice\": {\r\n" + "        \"OfficeContactRole\": \"\",\r\n"
				+ "        \"Email\": \"\",\r\n" + "        \"Address\": {\r\n"
				+ "            \"AddressLine2\": \"\",\r\n" + "            \"AddressLine1\": \"Mck01\",\r\n"
				+ "            \"State\": \"NY\",\r\n" + "            \"PostalCode\": 10005,\r\n"
				+ "            \"Country\": \"\",\r\n" + "            \"City\": \"Manhattan\"\r\n" + "        },\r\n"
				+ "        \"PracticeId\": \"3c4afb1a-ca05-4645-89e6-1c611bafb8b6\",\r\n" + "        \"Phone\": {\r\n"
				+ "            \"Number\": 9632587410,\r\n" + "            \"PhoneType\": 0\r\n" + "        },\r\n"
				+ "        \"OfficeContactName\": \"\",\r\n" + "        \"Fax\": {\r\n"
				+ "            \"Number\": 9513246870,\r\n" + "            \"PhoneType\": 0\r\n" + "        },\r\n"
				+ "        \"Name\": \"Sanofitest\"\r\n" + "    },\r\n" + "    \"Product\": \"" + WebFormVal + "\",\r\n"
				+ "    \"Patient\": {\r\n" + "        \"DateOfBirth\": \"" + DOB + "\",\r\n"
				+ "        \"Address\": {\r\n" + "            \"AddressLine2\": \"\",\r\n"
				+ "            \"AddressLine1\": \"S3\",\r\n" + "            \"State\": \"NY\",\r\n"
				+ "            \"PostalCode\": \"" + expZip + "\",\r\n" + "            \"Country\": \"\",\r\n"
				+ "            \"City\": \"Manhattan\"\r\n" + "        },\r\n" + "        \"FirstName\": \""
				+ patientFName + "\",\r\n" + "        \"ExternalPatientId\": \"\",\r\n"
				+ "        \"Gender\": \"M\",\r\n" + "        \"MiddleName\": \"\",\r\n"
				+ "        \"EmailAddress\": \"" + emailID + "\",\r\n" + "        \"Phones\": {\r\n"
				+ "            \"Number\": \"" + phoneNumber + "\",\r\n" + "            \"PhoneType\": 2\r\n"
				+ "        },\r\n" + "        \"AuthorizedRepresentatives\": \"\",\r\n" + "        \"PatientId\": \"5"
				+ randNum2 + "9G1B7-5E" + randNum2 + "-991K-" + generateRandomString(1) + "BA-6B3A"
				+ generateRandomString(1) + "2114\",\r\n" + "        \"ParentGuardian\": \"\",\r\n"
				+ "        \"LastName\": \"" + patientLName + "\",\r\n" + "        \"PreferredContactType\": 0\r\n"
				+ "    },\r\n" + "    \"PrescribingInformation\": {\r\n" + "        \"PatientWeight\": 83,\r\n"
				+ "        \"Milligrams\": 20,\r\n" + "        \"Frequency\": \"Once in a week\",\r\n"
				+ "        \"Icd10\": 1021232551,\r\n" + "        \"PatientWeightUnit\": \"kgs\"\r\n" + "    },\r\n"
				+ "    \"ArxId\": \"166h2674f-" + randNum2 + "9j-" + generateRandomString(1) + "7b-b6a4-af90k1bef7"
				+ generateRandomString(1) + "\",\r\n" + "    \"PbmInsurances\": \"\",\r\n"
				+ "    \"Attachments\": {\r\n" + "        \"Extension\": \".pdf\",\r\n"
				+ "        \"ContentType\": \"application/pdf\",\r\n" + "        \"Content\": \"JVBE\",\r\n"
				+ "        \"FileName\": \"HCP_Patient Assistance Program Form\",\r\n"
				+ "        \"FormType\": \"EnrollmentForm\",\r\n" + "        \"Descriptor\": \"Enrollment Form\",\r\n"
				+ "        \"AttachmentId\": \"cc8cb50c-7830-40ec-ae54-de734dca156a\"\r\n" + "    },\r\n"
				+ "    \"Source\": \"HCP\",\r\n" + "    \"Prescriber\": {\r\n" + "        \"Specialty\": \"\",\r\n"
				+ "        \"PrescriberInUS\": \"\",\r\n" + "        \"Npi\": 1236547896,\r\n"
				+ "        \"FirstName\": \"Hyun\",\r\n" + "        \"DeaNumber\": 165161566,\r\n"
				+ "        \"TaxIdNumber\": \"\",\r\n" + "        \"LastName\": \"Bin\",\r\n"
				+ "        \"PrescriberId\": \"00000000-0000-0000-0000-000000000000\",\r\n"
				+ "        \"StateLicenseNumber\": 12654119\r\n" + "    },\r\n" + "    \"ServiceType\": \"PAP\",\r\n"
				+ "    \"PatientParticipationEmail\": \"kindhupraveen@deloitte.com\",\r\n"
				+ "    \"Pharmacy\": \"\",\r\n" + "    \"Copay\": \"\",\r\n" + "    \"MedicalInsurances\": {\r\n"
				+ "        \"PolicyHolderBirthDate\": \"1982-01-01T00:00:00\",\r\n"
				+ "        \"PolicyHolderLastName\": \"Wessy\",\r\n" + "        \"InsuranceGroupNumber\": 6325783,\r\n"
				+ "        \"InsuranceId\": \"\",\r\n" + "        \"RelationshipToMember\": \"\",\r\n"
				+ "        \"PolicyHolderFirstName\": \"John\",\r\n" + "        \"FaxNumber\": \"\",\r\n"
				+ "        \"InsuranceCompanyName\": \"" + payerName + "\",\r\n"
				+ "        \"PlanType\": \"Primary\",\r\n" + "        \"PhoneNumber\": \"764-236-7888\",\r\n"
				+ "        \"Rank\": 1,\r\n" + "        \"InsuranceMemberNumber\": 743724\r\n" + "    }\r\n" + "}";

	}

	/**
	 * Function: To setup and hit API for AssistRx RD normal Enrollement with
	 * program case get created and Also create health insurance through HCP portal.
	 * 
	 * @author Dipali Yadav
	 * @param randNum1, randNum2, WebFormVal = RD product-Lumizyme,Cerdelga etc.
	 * @return API response
	 */
	public static String apiSetupForAssitRxRDEnrollmentThroughPatientPortal_HealthPlanUpdateThroughHCPPrtal(
			String paitentFirstName, String patientLastName, String expDOB, String respEmail, String respPhone,
			int randNum2, String zipCode, String payerName, APIEnum WebFormVal, String viaType) {
		String APIResponse = null;

		String constApiKeyValue = Configuration.readApplicationFile("API_Value_AssistRx");
		String constBasicAuthValueAssistRX = Configuration.readApplicationFile("Basic_Auth_AssistRX");

		if (viaType.equalsIgnoreCase("PatientPortal")) {

			APIResponse = given().header(APIConstants.constApiKey, constApiKeyValue)
					.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX)
					.body(Payload.payloadForAssitRxPatientEnrollmentRDPatientPortal(paitentFirstName, patientLastName,
							expDOB, respEmail, respPhone, randNum2, zipCode, payerName, APIEnum.Nexviazyme))
					.when().post(assistRx_Endpoint).then().assertThat().statusCode(200).extract().response().asString();
		}
		if (viaType.equalsIgnoreCase("HCPPortal")) {

			APIResponse = given().header(APIConstants.constApiKey, constApiKeyValue)
					.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
					.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
					.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX)
					.body(Payload.payloadForAssitRxPatientEnrollmentWithHealthPlanUpdateRDHCPPortal(paitentFirstName,
							patientLastName, expDOB, respEmail, respPhone, randNum2, zipCode, payerName,
							APIEnum.Nexviazyme))
					.when().post(assistRx_Endpoint).then().assertThat().statusCode(200).extract().response().asString();

		}

		return APIResponse;
	}

	/**
	 * Function: Generic payload to for paitent enrollment and creating BI/BV, Copay
	 * Cases etc from annexus website
	 * 
	 * @author Pratiksha Dixit/Modified-Dipali Yadav
	 * @return Generated payload
	 */

	public static String payloadForAnnexus(String patientFName, String patientLName, String genderValue, String emailID,
			String phoneNumber, String DOB, String randNum1, int randNum2, String expZip, String engagementProgramName,
			String dieaseName, String enrollmentDate, String productName, String formSubmittedBy, String formType,
			ArrayList<String> consents, String fundedByGov, String hasValidPrescription, String hascommInsurance,
			String meetResidency, String military, String usPrescriber, String houseHoldSize, String houseHoldIncome) {
		String payload;
		String ConsentsValue = null;
		JSONArray jsonArray = new JSONArray();
		for (int i = 0; i < consents.size(); i++) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("designeeLastName", JSONObject.NULL);
			jsonObject.put("endDate", JSONObject.NULL);
			jsonObject.put("designeeRelationship", JSONObject.NULL);
			jsonObject.put("permission", "Granted");
			jsonObject.put("consentSource", "Website");
			jsonObject.put("serviceName", consents.get(i));

			jsonObject.put("responseDate", "2022-12-06");
			jsonObject.put("eSigned", true);

			jsonObject.put("designeeFirstName", "");
			jsonObject.put("consentProvidedBy", "");
			jsonObject.put("consentType", "Electronic");
			jsonObject.put("documentId", "50a8bb68-7d67-445f-bc87-a8f94a663d1d");
			jsonObject.put("startDate", "2022-12-06");
			jsonObject.put("consentFormVersion", "MAT-US-2102338-v2.0-09/2021");
			jsonArray.put(jsonObject);
		}
		ConsentsValue = jsonArray.toString();

		payload = "{\r\n" + "    \"formSubmittedBy\": \"" + formSubmittedBy + "\",\r\n" + "    \"lastName\": \""
				+ patientLName + "\",\r\n" + "    \"identifier\": [\r\n" + "          {\r\n"
				+ "                 \"Type\": \"AnnexusPatientId\",\r\n" + "                 \"Value\": \""
				+ generateRandomString(3) + generateRandomString(6) + randNum2 + "\"\r\n" + "          },\r\n"
				+ "          {\r\n" + "                 \"Type\": \"AnnexusEnrollmentId\",\r\n"
				+ "              \"Value\": \"" + generateRandomString(4) + GenerateRandomNumber(5) + randNum2
				+ "\"\r\n" + "       }\r\n" + "    ],\r\n" + "    \"formType\": \"" + formType + "\",\r\n"
				+ "    \"onSanofiProduct\": true,\r\n" + "    \"Email\": \"" + emailID + "\",\r\n"
				+ "    \"communicationLanguage\": \"\",\r\n" + "    \"address\": {\r\n" + "  \"zipCode\": \"" + expZip
				+ "\",\r\n" + "          \"address2\": \"\",\r\n" + "          \"city\": \"Culpeper\",\r\n"
				+ "          \"address1\": \"878 N. Fairfield Court\",\r\n" + "          \"addressType\": \"\",\r\n"
				+ "          \"primaryAddress\": true,\r\n" + "          \"state\": \"VA\"\r\n" + "    },\r\n"
				+ "    \"gender\": \"" + genderValue + "\",\r\n" + "    \"isCareGiver\": false,\r\n"
				+ "    \"homePhone\": \"" + phoneNumber + "\",\r\n" + "    \"association\": [\r\n" + "          {\r\n"
				+ "                 \"firstName\": \"Indhuww\",\r\n" + "              \"lastName\": \"ICSIEHIAvv\",\r\n"
				+ "                 \"phone\": \"\",\r\n" + "                 \"relationship\": \"Parent\",\r\n"
				+ "                 \"suppressEvent\": true,\r\n" + "                 \"email\": \"\",\r\n"
				+ "                 \"primary\": false\r\n" + "    }\r\n" + "    ],\r\n" + "    \"dateOfBirth\": \""
				+ DOB + "\" ,\r\n" + "    \"program\": [\r\n" + "          {\r\n" + "                 \"disease\": \""
				+ dieaseName + "\",\r\n" + "                 \"engagementProgramName\": \"" + engagementProgramName
				+ "\",\r\n" + "                 \"enrollmentDate\": \"" + enrollmentDate + "\",\r\n"
				+ "                 \"Practice\": {},\r\n" + "                 \"eligibility\": {\r\n"
				+ "                        \"hasValidPrescription\": " + hasValidPrescription + ",\r\n"
				+ "                        \"fundedByGov\":" + fundedByGov + ",\r\n"
				+ "                        \"householdSize\": \"" + houseHoldSize + "\",\r\n"
				+ "                        \"hasCommercialInsurance\": " + hascommInsurance + ",\r\n"
				+ "                        \"meetsResidencyReq\": " + meetResidency + ",\r\n"
				+ "                        \"isMilitary\": " + military + ",\r\n"
				+ "                        \"USPrescriber\": " + usPrescriber + ",\r\n"
				+ "                        \"documentId\": null,\r\n"
				+ "                        \"caseOutcome\": \"\",\r\n"
				+ "                        \"householdIncome\": \"" + houseHoldIncome + "\"\r\n"
				+ "                 },\r\n" + "                 \"patientParticipation\": false,\r\n"
				+ "         \"consent\": " + ConsentsValue + "," + "                 \"productName\": \"" + productName
				+ "\",\r\n" + "                 \"Prescriber\": {},\r\n" + "                 \"prescription\": {\r\n"
				+ "                       \"Type\": \"Prescription\",\r\n"
				+ "                        \"WeightInKg\": \"\",\r\n"
				+ "                        \"diagnosisCode\": \"C90.0\",\r\n"
				+ "                        \"documentId\": \"\",\r\n"
				+ "                        \"dosageFrequency\": \"\",\r\n"
				+ "                        \"Dosage\": \"24065601\",\r\n"
				+ "                        \"WeightInLb\": \"\",\r\n"
				+ "                        \"rxStartDate\": \"\"\r\n" + "                 },\r\n"
				+ "                 \"Pharmacy\": {\r\n" + "                        \"PharmacyId\": \"\",\r\n"
				+ "                        \"SpecialtyType\": \"CVS Specialty\",\r\n"
				+ "                        \"Address\": null,\r\n" + "                        \"Phone\": null,\r\n"
				+ "                       \"Fax\": null,\r\n" + "                        \"NCPDP\": \"\",\r\n"
				+ "                        \"EmailAddress\": \"\",\r\n" + "                       \"Name\": \"\"\r\n"
				+ "                 },\r\n" + "                 \"documentId\": [\r\n" + "                       {\r\n"
				+ "                              \"id\": \"50a8bb68-7d67-445f-bc87-a8f94a663d1d\"\r\n"
				+ "                       }\r\n" + "                 ],\r\n"
				+ "                 \"leadChannel\": \"AnnexusHealth\",\r\n" + "                 \"status\": \"\",\r\n"
				+ "                 \"patientParticipationEmail\": \"\"\r\n" + "          }\r\n" + "    ],\r\n"
				+ "    \"firstName\": \"" + patientFName + "\",\r\n" + "    \"mobilePhone\": \"\",\r\n"
				+ "  \"attachment\": [\r\n" + "        {\r\n"
				+ "            \"fileName\": \"CareASSIST Patient Support Program\",\r\n"
				+ "            \"fileExtension\": \".pdf\",\r\n"
				+ "            \"attachmentCategory\": \"Enrollment Form\",\r\n"
				+ "            \"externalId\": \"50a8bb68-7d67-445f-bc87-a8f94a663d1d\",\r\n"
				+ "            \"descriptor\": \"\",\r\n"
				+ "            \"content\": \"XWUtOakkzTmprS0pTVkZUMFlL\",\r\n"
				+ "            \"attachmentSource\": \"AnnexusHealth\"\r\n" + "        }\r\n" + "    ],"
				+ "       \"preferredCommunicationChannel\": \"\",\r\n" + "    \"accountSource\": \"Website\",\r\n"
				+ "    \"healthPlans\": [\r\n" + "          {\r\n" + "                 \"idPolicyNo\": \"\",\r\n"
				+ "                 \"rxGrp\": \"\",\r\n" + "                 \"planType\": \"Primary\",\r\n"
				+ "                 \"rxCardId\": \"\",\r\n" + "                 \"cardholderEmployer\": \"\",\r\n"
				+ "                 \"planSubCategory\": \"\",\r\n"
				+ "                 \"recordType\": \"Medical Plan\",\r\n"
				+ "                 \"planCategory\": \"\",\r\n" + "                 \"rxPCN\": \"\",\r\n"
				+ "                 \"renewalDate\": \"\",\r\n" + "                 \"insurancePhoneNo\": \"\",\r\n"
				+ "                 \"cardholderLastName\": \"\",\r\n"
				+ "                 \"cardholderDateOfBirth\": \"\",\r\n"
				+ "                 \"cardholderFirstName\": \"\",\r\n"
				+ "                 \"insuranceProvider\": \"VA Healthcare Insurance\",\r\n"
				+ "                 \"cardholderRelationToPatient\": \"\",\r\n"
				+ "                 \"pbmPhoneNo\": \"\",\r\n" + "                 \"documentId\": null,\r\n"
				+ "                 \"groupNo\": \"\",\r\n" + "                 \"effectiveDate\": \"\",\r\n"
				+ "                 \"rxBin\": \"\",\r\n" + "                 \"expirationDate\": \"\"\r\n"
				+ "          },\r\n" + "          {\r\n" + "                 \"idPolicyNo\": \"\",\r\n"
				+ "                 \"rxGrp\": \"\",\r\n" + "                 \"planType\": \"Primary\",\r\n"
				+ "                 \"rxCardId\": \"\",\r\n" + "                 \"cardholderEmployer\": \"\",\r\n"
				+ "                 \"planSubCategory\": \"\",\r\n"
				+ "                 \"recordType\": \"Pharmacy Plan\",\r\n"
				+ "                 \"planCategory\": \"\",\r\n" + "                 \"rxPCN\": \"\",\r\n"
				+ "                 \"renewalDate\": \"\",\r\n" + "                 \"insurancePhoneNo\": \"\",\r\n"
				+ "                 \"cardholderLastName\": \"\",\r\n"
				+ "                 \"cardholderDateOfBirth\": \"\",\r\n"
				+ "                 \"cardholderFirstName\": \"\",\r\n"
				+ "                 \"insuranceProvider\": \"\",\r\n"
				+ "                 \"cardholderRelationToPatient\": \"\",\r\n"
				+ "                 \"pbmPhoneNo\": \"\",\r\n" + "                 \"documentId\": null,\r\n"
				+ "                 \"groupNo\": \"\",\r\n" + "                 \"effectiveDate\": \"\",\r\n"
				+ "                 \"rxBin\": \"\",\r\n" + "                 \"expirationDate\": \"\"\r\n"
				+ "          }\r\n" + "    ],\r\n" + "    \"isOther\": false\r\n" + "}";
		return payload;

	}

	/**
	 * Function: Generic payload to for paitent enrollment and creating BI/BV, Copay
	 * Cases from Trial Card website
	 * 
	 * @author Pratiksha Dixit/Modified-Dipali Yadav
	 * @return Generated payload
	 */
	public static String payloadForTrialCard(String patientFName, String patientLName, String genderValue,
			String emailID, String phoneNumber, String DOB, int randNum2, String expZip, String consentFormVersion,
			String enrollmentDate, String productName, String formSubmittedBy, String formType, String copayConsentType,
			String coverageEndDate, String fundedByGov, String hasValidPrescription, String hascommInsurance,
			String meetResidency, String military, String usPrescriber, String hubId) {

		String payload = "{\r\n" + "       \"formSubmittedBy\": \"" + formSubmittedBy + "\",\r\n"
				+ "       \"lastName\": \"" + patientLName + "\",\r\n" + "       \"identifier\": [\r\n"
				+ "           {\r\n" + "                 \"type\": \"TrialCardPatientId\",\r\n"
				+ "                 \"value\": \"" + randNum2 + Utility_Function.generateRandomNumber()
				+ generateRandomString(5) + "\"\r\n" + "           },\r\n" + "           {\r\n"
				+ "                 \"type\": \"iCCHubId\",\r\n" + "                 \"value\": \"" + hubId + "\"\r\n"
				+ "           },\r\n" + "           {\r\n" + "                 \"type\": \"TrialCardEnrollmentId\",\r\n"
				+ "                 \"value\": \"" + randNum2 + GenerateRandomNumber(3) + randNum2 + "\"\r\n"
				+ "           }\r\n" + "       ],\r\n" + "       \"formType\": \"" + formType + "\",\r\n"
				+ "       \"communicationLanguage\": \"\",\r\n" + "       \"address\": {\r\n" + "  \"zipCode\": \""
				+ expZip + "\",\r\n" + "           \"address2\": \"\",\r\n" + "           \"city\": \"Culpeper\",\r\n"
				+ "           \"address1\": \"878 N. Fairfield Court\",\r\n" + "           \"addressType\": null,\r\n"
				+ "           \"primaryAddress\": true,\r\n" + "           \"state\": \"VA\"\r\n" + "       },\r\n"
				+ "       \"gender\": \"" + genderValue + "\",\r\n" + "       \"requestType\": \"ENROLL\",\r\n"
				+ "       \"copayVendor\": \"TrialCard\",\r\n" + "       \"homePhone\": \"" + phoneNumber + "\",\r\n"
				+ "       \"enrollmentDate\": \"" + enrollmentDate + "\",\r\n" + "       \"Practice\": null,\r\n"
				+ "       \"eligibility\": {\r\n" + "                        \"hasValidPrescription\": "
				+ hasValidPrescription + ",\r\n" + "                        \"fundedByGov\":" + fundedByGov + ",\r\n"
				+ "                        \"householdSize\": \"\",\r\n"
				+ "                        \"hasCommercialInsurance\": " + hascommInsurance + ",\r\n"
				+ "                        \"meetsResidencyReq\": " + meetResidency + ",\r\n"
				+ "                        \"isMilitary\": " + military + ",\r\n"
				+ "                        \"USPrescriber\": " + usPrescriber + ",\r\n"
				+ "                        \"documentId\": null,\r\n" + "           \"caseOutcome\": \"Eligible\",\r\n"
				+ "                        \"householdIncome\": \"\"\r\n" + "                 },\r\n"
				+ "       \"dateOfBirth\": \"" + DOB + "\" ,\r\n" + "       \"consent\": {\r\n"
				+ "           \"designeeLastName\": \"\",\r\n"
				+ "           \"endDate\": \"2023-02-03T00:00:00.000Z\",\r\n"
				+ "           \"designeeRelationship\": \"\",\r\n" + "           \"permission\": \"Granted\",\r\n"
				+ "           \"consentSource\": \"Website\",\r\n" + "        \"serviceName\": \"" + copayConsentType
				+ "\",\r\n" + "           \"responseDate\": \"2023-01-30T00:00:00.000Z\",\r\n"
				+ "           \"eSigned\": true,\r\n" + "           \"designeeFirstName\": \"\",\r\n"
				+ "           \"consentProvidedBy\": \"\",\r\n" + "           \"consentType\": \"Electronic\",\r\n"
				+ "           \"documentId\": \"B5C6F82B-20FC-4B44-8C06-130ED2C63D41\",\r\n"
				+ "           \"startDate\": \"2023-01-30T00:00:00.000Z\",\r\n"
				+ "           \"consentFormVersion\": \"" + consentFormVersion + "\"\r\n" + "       },\r\n"
				+ "       \"productName\": \"" + productName + "\",\r\n" + "       \"firstName\": \"" + patientFName
				+ "\",\r\n" + "       \"Prescriber\": null,\r\n" + "       \"mobilePhone\": \"" + phoneNumber
				+ "\",\r\n" + "       \"Pharmacy\": null,\r\n" + "       \"accountSource\": \"Website\",\r\n"
				+ "       \"copay\": {\r\n" + "           \"initialEnrollmentDate\": \"" + enrollmentDate
				+ "T13:52:22.07\",\r\n" + "           \"coverageType\": \"Drug and Infusion\",\r\n"
				+ "           \"coverageStartDate\": \"" + enrollmentDate + "T00:00:00\",\r\n"
				+ "           \"medical\": {\r\n" + "                 \"bin\": \"56155\",\r\n"
				+ "                 \"cardId\": \"17752099\",\r\n" + "                 \"pcn\": \"\",\r\n"
				+ "                 \"groupNumber\": \"00003697\"\r\n" + "           },\r\n"
				+ "           \"eligibleReEnrollmentDate\": \"" + enrollmentDate + "T13:52:22.07\",\r\n"
				+ "           \"pharmacy\": {\r\n" + "                 \"bin\": \"610020\",\r\n"
				+ "                 \"cardId\": \"1029359240\",\r\n" + "                 \"pcn\": \"\",\r\n"
				+ "                 \"groupNumber\": \"50777984\"\r\n" + "           },\r\n"
				+ "           \"coverageEndDate\": \"" + coverageEndDate + "T00:00:00\"\r\n" + "       },\r\n"
				+ "       \"email\": \"" + emailID + "\"\r\n" + "}";
		return payload;
	}

	/**
	 * Function: To generate payload for Trail Card CoPay Withdrawal
	 * 
	 * @author Pratiksha Dixit
	 * @return Generated payload
	 */

	public static String payloadForWithdrawalFromTrailCard(String productname, String icaId) {
		return "{\r\n" + "	\"formSubmittedBy\": \"Copay Site\",\r\n" + "	\"identifier\": [\r\n" + "		{\r\n"
				+ "			\"type\": \"iCCHubId\",\r\n" + "			\"value\": \"" + icaId + "\"\r\n"
				+ "		}\r\n" + "	],\r\n" + "	\"formType\": \"Copay\",\r\n" + "	\"requestType\": \"WITHDRAW\",\r\n"
				+ "	\"copayVendor\": \"TrialCard\",\r\n" + "	\"accountSource\": \"iCC\",\r\n"
				+ "	\"copay\": {\r\n" + "		\"coverageType\": \"Drug and Infusion\"\r\n" + "	},\r\n"
				+ "	\"productName\": \"" + productname + "\"\r\n" + "}";

	}

	/**
	 * Function: To generate payload for Assistrx Copay ONC
	 * 
	 * @author Pratiksha Dixit
	 * @return Generated payload
	 */
	public static String payloadForAssistrxCopayONC(String zipcode, String phoneNumber, String consentName,
			String paitentFirstName, String lastName, String dob, String emailValue, int randm1, int ran2,
			String productValue) {
		return "{\r\n" + "	\"PatientParticipation\": false,\r\n" + "	\"Consents\": [{\r\n"
				+ "			\"ConsentDesigneeFirstName\": null,\r\n"
				+ "			\"ConsentDesigneeRelationship\": null,\r\n" + "			\"ExpirationDate\": null,\r\n"
				+ "			\"ConsentProvidedBy\": null,\r\n"
				+ "			\"ConsentName\": \"PrescriberCertification\",\r\n"
				+ "			\"ConsentGivenBy\": \"sudharsan\",\r\n" + "			\"ConsentDesigneeLastName\": null,\r\n"
				+ "			\"EffectiveDate\": \"2023-02-21T11:36:13.734\"\r\n" + "		},\r\n" + "		{\r\n"
				+ "			\"ConsentDesigneeFirstName\": null,\r\n"
				+ "			\"ConsentDesigneeRelationship\": null,\r\n" + "			\"ExpirationDate\": null,\r\n"
				+ "			\"ConsentProvidedBy\": null,\r\n" + "			\"ConsentName\": \"" + consentName
				+ "\",\r\n" + "			\"ConsentGivenBy\": \"sudharsan\",\r\n"
				+ "			\"ConsentDesigneeLastName\": null,\r\n"
				+ "			\"EffectiveDate\": \"2023-02-21T11:36:13.734\"\r\n" + "		}\r\n" + "	],\r\n"
				+ "	\"FinancialInformation\": {\r\n" + "		\"HouseholdIncome\": null,\r\n"
				+ "		\"HouseholdSize\": null\r\n" + "	},\r\n" + "	\"ExternalId\": null,\r\n"
				+ "	\"Practice\": {\r\n" + "		\"OfficeContactRole\": \"Manager\",\r\n"
				+ "		\"Email\": null,\r\n" + "		\"Address\": {\r\n" + "			\"AddressLine2\": null,\r\n"
				+ "			\"AddressLine1\": \"24 Avenue\",\r\n" + "			\"State\": \"MI\",\r\n"
				+ "			\"PostalCode\": \"" + zipcode + "\",\r\n" + "			\"Country\": null,\r\n"
				+ "			\"City\": \"Bayport\"\r\n" + "		},\r\n"
				+ "		\"PracticeId\": \"aba5c7dd-6d07-4032-a22f-10c0592ec8aa\",\r\n"
				+ "		\"PracticeType\": \"Hospital Outpatient\",\r\n" + "		\"Phone\": {\r\n"
				+ "			\"Number\": \"1234567890\",\r\n" + "			\"PhoneType\": 0\r\n" + "		},\r\n"
				+ "		\"OfficeContactName\": \"Jayson\",\r\n" + "		\"Fax\": {\r\n"
				+ "			\"Number\": \"2523555151\",\r\n" + "			\"PhoneType\": 0\r\n" + "		},\r\n"
				+ "		\"Name\": \"test\"\r\n" + "	},\r\n" + "	\"Product\": \"" + productValue + "\",\r\n"
				+ "	\"Patient\": {\r\n" + "		\"DateOfBirth\": \"" + dob + "T00:00:00\",\r\n"
				+ "		\"Address\": {\r\n" + "			\"AddressLine2\": null,\r\n"
				+ "			\"AddressLine1\": \"24 Avenue\",\r\n" + "			\"State\": \"MI\",\r\n"
				+ "			\"PostalCode\": \"" + zipcode + "\",\r\n" + "			\"Country\": null,\r\n"
				+ "			\"City\": \"Afton\"\r\n" + "		},\r\n" + "		\"FirstName\": \"" + paitentFirstName
				+ "\",\r\n" + "		\"ExternalPatientId\": null,\r\n" + "		\"Gender\": \"M\",\r\n"
				+ "		\"MiddleName\": null,\r\n" + "		\"EmailAddress\": \"" + emailValue + "\",\r\n"
				+ "		\"Phones\": [{\r\n" + "				\"Number\": \"" + phoneNumber + "\",\r\n"
				+ "				\"PhoneType\": 3,\r\n" + "				\"OkToLeaveMessage\": true\r\n"
				+ "			},\r\n" + "			{\r\n" + "				\"Number\": \"" + phoneNumber + "\",\r\n"
				+ "				\"PhoneType\": 2,\r\n" + "				\"OkToLeaveMessage\": null\r\n"
				+ "			}\r\n" + "		],\r\n" + "		\"AuthorizedRepresentatives\": null,\r\n"
				+ "		\"PatientId\": \"8BC57FE4-9020-4402-8C3F-2251147F" + randm1 + "\",\r\n"
				+ "		\"ParentGuardian\": null,\r\n" + "		\"PreferredLanguage\": \"English\",\r\n"
				+ "		\"LastName\": \"" + lastName + "\",\r\n" + "		\"PreferredContactType\": 0\r\n"
				+ "	},\r\n" + "	\"PrescribingInformation\": {\r\n" + "		\"PatientWeight\": null,\r\n"
				+ "		\"Quantity\": \"\",\r\n" + "		\"Frequency\": null,\r\n" + "		\"Refills\": \"\",\r\n"
				+ "		\"Icd10\": null,\r\n" + "		\"PatientWeightUnit\": null,\r\n" + "		\"Dose\": null\r\n"
				+ "	},\r\n" + "	\"ArxId\": \"11c2674f-734d-447b-b6a4-af64d1bef7" + ran2 + "\",\r\n"
				+ "	\"PbmInsurances\": null,\r\n" + "	\"Source\": \"HCP\",\r\n"
				+ "	\"PatientParticipationMobile\": null,\r\n" + "	\"Prescriber\": {\r\n"
				+ "		\"PhysicianStateLicenseNumber\": null,\r\n" + "		\"Npi\": \"1962420315\",\r\n"
				+ "		\"FirstName\": \"SAM\",\r\n"
				+ "		\"PrescriberId\": \"00000000-0000-0000-0000-000000000000\",\r\n"
				+ "		\"LicensedState\": null,\r\n" + "		\"Specialty\": null,\r\n"
				+ "		\"PrescriberInUS\": null,\r\n" + "		\"PhysicianName\": \"SAM SMITH\",\r\n"
				+ "		\"DeaNumber\": null,\r\n" + "		\"PhysicianLicensedState\": null,\r\n"
				+ "		\"TaxIdNumber\": \"123456789\",\r\n" + "		\"LastName\": \"SMITH\",\r\n"
				+ "		\"StateLicenseNumber\": null\r\n" + "	},\r\n" + "	\"ServiceType\": \"Copay\",\r\n"
				+ "	\"PatientParticipationEmail\": null,\r\n" + "	\"Pharmacy\": null,\r\n" + "\"Copay\": {\r\n\t\t\t"
				+ "\"ValidPrescription\": true,\r\n\t\t\t" + "\"CoveredForReimbursement\": false,\r\n\t\t\t"
				+ "\"IsEligibleForCopay\": null,\r\n\t\t\t" + "\"FAPatientAcceptsCopayTerms\": true,\r\n\t\t\t"
				+ "\"IsUsResident\": true,\r\n\t\t\t" + "\"IsMilitary\": \"true\",\r\n\t\t\t"
				+ "\"HasGovernmentAssistance\": \"true\",\r\n\t\t\t" + "\"HasMilitaryAssistance\": \"true\",\r\n\t\t\t"
				+ "\"CardId\": \"\",\r\n\t\t\t" + "\"HasCommercialInsurance\": true\r\n\t\t},\r\n"
				+ "	\"MedicalInsurances\": [{\r\n" + "		\"PolicyHolderBirthDate\": \"2001-02-01T00:00:00\",\r\n"
				+ "		\"PolicyHolderLastName\": \"testUAT\",\r\n"
				+ "		\"InsuranceGroupNumber\": \"5614321653\",\r\n"
				+ "		\"InsuranceId\": \"f3b03ad5-f6a1-4d44-a247-147d1ae06936\",\r\n"
				+ "		\"RelationshipToMember\": \"parent\",\r\n" + "		\"PolicyHolderFirstName\": \"Mayon\",\r\n"
				+ "		\"FaxNumber\": null,\r\n" + "		\"InsuranceCompanyName\": \"TATA AIA\",\r\n"
				+ "		\"PlanType\": null,\r\n" + "		\"PhoneNumber\": \"1234567890\",\r\n"
				+ "		\"Rank\": 1,\r\n" + "		\"InsuranceMemberNumber\": \"643654365\"\r\n" + "	}]\r\n" + "}";
	}

	/**
	 * Function: To generate payload for Assistrx Copay ONC
	 * 
	 * @author varsrinivasan
	 * @return Generated payload
	 */

	public static String payloadForAssistrxCopayONCWithAttachments(String zipcode, String phoneNumber,
			String consentName, String paitentFirstName, String lastName, String dob, String emailValue, int randm1,
			int ran2, String char1, String char2, String productValue) {
		return "{\r\n" + "	\"PatientParticipation\": false,\r\n" + "	\"Consents\": [{\r\n"
				+ "			\"ConsentDesigneeFirstName\": null,\r\n"
				+ "			\"ConsentDesigneeRelationship\": null,\r\n" + "			\"ExpirationDate\": null,\r\n"
				+ "			\"ConsentProvidedBy\": null,\r\n"
				+ "			\"ConsentName\": \"PrescriberCertification\",\r\n"
				+ "			\"ConsentGivenBy\": \"sudharsan\",\r\n" + "			\"ConsentDesigneeLastName\": null,\r\n"
				+ "			\"EffectiveDate\": \"2023-02-21T11:36:13.734\"\r\n" + "		},\r\n" + "		{\r\n"
				+ "			\"ConsentDesigneeFirstName\": null,\r\n"
				+ "			\"ConsentDesigneeRelationship\": null,\r\n" + "			\"ExpirationDate\": null,\r\n"
				+ "			\"ConsentProvidedBy\": null,\r\n" + "			\"ConsentName\": \"" + consentName
				+ "\",\r\n" + "			\"ConsentGivenBy\": \"sudharsan\",\r\n"
				+ "			\"ConsentDesigneeLastName\": null,\r\n"
				+ "			\"EffectiveDate\": \"2023-02-21T11:36:13.734\"\r\n" + "		}\r\n" + "	],\r\n"
				+ "	\"FinancialInformation\": {\r\n" + "		\"HouseholdIncome\": null,\r\n"
				+ "		\"HouseholdSize\": null\r\n" + "	},\r\n" + "	\"ExternalId\": null,\r\n"
				+ "	\"Practice\": {\r\n" + "		\"OfficeContactRole\": \"Manager\",\r\n"
				+ "		\"Email\": null,\r\n" + "		\"Address\": {\r\n" + "			\"AddressLine2\": null,\r\n"
				+ "			\"AddressLine1\": \"24 Avenue\",\r\n" + "			\"State\": \"MI\",\r\n"
				+ "			\"PostalCode\": \"" + zipcode + "\",\r\n" + "			\"Country\": null,\r\n"
				+ "			\"City\": \"Bayport\"\r\n" + "		},\r\n"
				+ "		\"PracticeId\": \"aba5c7dd-6d07-4032-a22f-10c0592ec8aa\",\r\n"
				+ "		\"PracticeType\": \"Hospital Outpatient\",\r\n" + "		\"Phone\": {\r\n"
				+ "			\"Number\": \"1234567890\",\r\n" + "			\"PhoneType\": 0\r\n" + "		},\r\n"
				+ "		\"OfficeContactName\": \"Jayson\",\r\n" + "		\"Fax\": {\r\n"
				+ "			\"Number\": \"2523555151\",\r\n" + "			\"PhoneType\": 0\r\n" + "		},\r\n"
				+ "		\"Name\": \"test\"\r\n" + "	},\r\n" + "	\"Product\": \"" + productValue + "\",\r\n"
				+ "	\"Patient\": {\r\n" + "		\"DateOfBirth\": \"" + dob + "T00:00:00\",\r\n"
				+ "		\"Address\": {\r\n" + "			\"AddressLine2\": null,\r\n"
				+ "			\"AddressLine1\": \"24 Avenue\",\r\n" + "			\"State\": \"MI\",\r\n"
				+ "			\"PostalCode\": \"" + zipcode + "\",\r\n" + "			\"Country\": \"United States\",\r\n"
				+ "			\"City\": \"Afton\"\r\n" + "		},\r\n" + "		\"FirstName\": \"" + paitentFirstName
				+ "\",\r\n" + "		\"ExternalPatientId\": null,\r\n" + "		\"Gender\": \"M\",\r\n"
				+ "		\"MiddleName\": null,\r\n" + "		\"EmailAddress\": \"" + emailValue + "\",\r\n"
				+ "		\"Phones\": [{\r\n" + "				\"Number\": \"" + phoneNumber + "\",\r\n"
				+ "				\"PhoneType\": 3,\r\n" + "				\"OkToLeaveMessage\": true\r\n"
				+ "			},\r\n" + "			{\r\n" + "				\"Number\": \"" + phoneNumber + "\",\r\n"
				+ "				\"PhoneType\": 2,\r\n" + "				\"OkToLeaveMessage\": null\r\n"
				+ "			}\r\n" + "		],\r\n" + "		\"AuthorizedRepresentatives\": null,\r\n"
				+ "		\"PatientId\": \"5" + randm1 + "8Z1B7-5E" + ran2 + "-471F-" + char1 + "DA-6B3A" + char2
				+ "2114\",\r\n" + "		\"ParentGuardian\": null,\r\n" + "		\"PreferredLanguage\": \"English\",\r\n"
				+ "		\"LastName\": \"" + lastName + "\",\r\n" + "		\"PreferredContactType\": 0\r\n"
				+ "	},\r\n" + "	\"PrescribingInformation\": {\r\n" + "		\"PatientWeight\": null,\r\n"
				+ "		\"Quantity\": \"\",\r\n" + "		\"Frequency\": null,\r\n" + "		\"Refills\": \"\",\r\n"
				+ "		\"Icd10\": null,\r\n" + "		\"PatientWeightUnit\": null,\r\n" + "		\"Dose\": null\r\n"
				+ "	},\r\n" + "	\"ArxId\": \"11c2674f-" + ran2 + "4d-" + char2 + "7b-b6a4-af64d1bef7" + char1
				+ "\",\r\n" + "	\"PbmInsurances\": null, \"Attachments\":"
				+ " [ { \"Extension\": \".pdf\", \"ContentType\": \"application/pdf\", "
				+ "\"Content\": \"Test\", \"FileName\": \"HCP CareASSIST Enrollment Form\", "
				+ "\"FormType\": \"EnrollmentForm\", \"Descriptor\": \"Enrollment Form\", "
				+ "\"AttachmentId\": \"6ecad230-917b-4096-982e-bcb21049a9fb\" } ],\r\n" + "	\"Source\": \"HCP\",\r\n"
				+ "	\"PatientParticipationMobile\": null,\r\n" + "	\"Prescriber\": {\r\n"
				+ "		\"PhysicianStateLicenseNumber\": null,\r\n" + "		\"Npi\": \"1962420315\",\r\n"
				+ "		\"FirstName\": \"SAM\",\r\n"
				+ "		\"PrescriberId\": \"00000000-0000-0000-0000-000000000000\",\r\n"
				+ "		\"LicensedState\": null,\r\n" + "		\"Specialty\": null,\r\n"
				+ "		\"PrescriberInUS\": null,\r\n" + "		\"PhysicianName\": \"SAM SMITH\",\r\n"
				+ "		\"DeaNumber\": null,\r\n" + "		\"PhysicianLicensedState\": null,\r\n"
				+ "		\"TaxIdNumber\": \"123456789\",\r\n" + "		\"LastName\": \"SMITH\",\r\n"
				+ "		\"StateLicenseNumber\": null\r\n" + "	},\r\n" + "	\"ServiceType\": \"Copay\",\r\n"
				+ "	\"PatientParticipationEmail\": null,\r\n" + "	\"Pharmacy\": null,\r\n" + "\"Copay\": {\r\n\t\t\t"
				+ "\"ValidPrescription\": true,\r\n\t\t\t" + "\"CoveredForReimbursement\": false,\r\n\t\t\t"
				+ "\"IsEligibleForCopay\": null,\r\n\t\t\t" + "\"FAPatientAcceptsCopayTerms\": true,\r\n\t\t\t"
				+ "\"IsUsResident\": true,\r\n\t\t\t" + "\"IsMilitary\": \"true\",\r\n\t\t\t"
				+ "\"HasGovernmentAssistance\": \"true\",\r\n\t\t\t" + "\"HasMilitaryAssistance\": \"true\",\r\n\t\t\t"
				+ "\"CardId\": \"\",\r\n\t\t\t" + "\"HasCommercialInsurance\": true\r\n\t\t},\r\n"
				+ "	\"MedicalInsurances\": [{\r\n" + "		\"PolicyHolderBirthDate\": \"2001-02-01T00:00:00\",\r\n"
				+ "		\"PolicyHolderLastName\": \"testUAT\",\r\n"
				+ "		\"InsuranceGroupNumber\": \"5614321653\",\r\n"
				+ "		\"InsuranceId\": \"f3b03ad5-f6a1-4d44-a247-147d1ae06936\",\r\n"
				+ "		\"RelationshipToMember\": \"parent\",\r\n" + "		\"PolicyHolderFirstName\": \"Mayon\",\r\n"
				+ "		\"FaxNumber\": null,\r\n" + "		\"InsuranceCompanyName\": \"TATA AIA\",\r\n"
				+ "		\"PlanType\": null,\r\n" + "		\"PhoneNumber\": \"1234567890\",\r\n"
				+ "		\"Rank\": 1,\r\n" + "		\"InsuranceMemberNumber\": \"643654365\"\r\n" + "	}]\r\n" + "}";
	}

	/**
	 * Function: To generate payload for Enrollment API
	 * 
	 * @author Pratiksha Dixit
	 * @return Generated payload
	 */

	public static String payloadForEnrollmentAPI(String lastName, String externalId, String formTypeValue, String icaId,
			int rand1, String productNameValue, String engagementValue, String phoneNumber, String firstName,
			String diseaseValue, String serviceNameValue, String enrollmentDateValue) {

		return "{\r\n" + "	\"formSubmittedBy\": \"Patient\",\r\n" + "	\"lastName\": \"" + lastName + "\",\r\n"
				+ "	\"identifier\": [\r\n" + "		{\r\n" + "			\"type\": \"AssistRx\",\r\n"
				+ "			\"value\": \"3a83403a-2c68-40cf-aabc-7431084c04" + rand1 + "\"\r\n" + "		},\r\n"
				+ "		{\r\n" + "			\"type\": \"ExternalId\",\r\n" + "			\"value\": \"" + externalId
				+ "\"\r\n" + "		},\r\n" + "		{\r\n" + "			\"type\": \"iCCHubId\",\r\n"
				+ "			\"value\": \"" + icaId + "\"\r\n" + "		}\r\n" + "	],\r\n" + "	\"formType\": \""
				+ formTypeValue + "\",\r\n" + "	\"onSanofiProduct\": true,\r\n"
				+ "	\"communicationLanguage\": \"\",\r\n" + "	\"address\": {\r\n" + "		\"zipCode\": \"00000\",\r\n"
				+ "		\"address2\": \"\",\r\n" + "		\"city\": \"\",\r\n" + "		\"address1\": \"\",\r\n"
				+ "		\"addressType\": \"Home\",\r\n" + "		\"primaryAddress\": true,\r\n"
				+ "		\"state\": \"\"\r\n" + "	},\r\n" + "	\"gender\": \"U\",\r\n" + "	\"isCareGiver\": false,\r\n"
				+ "	\"homePhone\": \"\",\r\n" + "	\"dateOfBirth\": \"1987-08-07T00:00:00\",\r\n"
				+ "	\"program\": [\r\n" + "		{\r\n" + "			\"isEventPresent\": false,\r\n"
				+ "			\"disease\": \"" + diseaseValue + "\",\r\n"
				+ "			\"patientParticipationMobile\": \"\",\r\n" + "			\"prescription\": {\r\n"
				+ "				\"dosage\": \"\",\r\n" + "				\"refills\": \"\",\r\n"
				+ "				\"quantity\": \"\",\r\n" + "				\"weightInKg\": \"\",\r\n"
				+ "				\"diagnosisCode\": \"\",\r\n" + "				\"documentId\": \"\",\r\n"
				+ "				\"dosageFrequency\": \"\",\r\n" + "				\"weightInLb\": \"\"\r\n"
				+ "			},\r\n" + "			\"engagementProgramName\": \"" + engagementValue + "\",\r\n"
				+ "			\"enrollmentDate\": \"" + enrollmentDateValue + "\",\r\n"
				+ "			\"leadChannel\": \"AssistRx\",\r\n" + "			\"patientParticipation\": false,\r\n"
				+ "			\"consent\": [\r\n" + "{\r\n" + "					\"designeeLastName\": \"\",\r\n"
				+ "					\"endDate\": \"\",\r\n" + "					\"designeeRelationship\": \"\",\r\n"
				+ "					\"permission\": \"Granted\",\r\n"
				+ "					\"consentSource\": \"\",\r\n" + "					\"serviceName\": \""
				+ serviceNameValue + "\",\r\n" + "					\"responseDate\": \"2023-03-09\",\r\n"
				+ "					\"eSigned\": false,\r\n" + "					\"designeeFirstName\": \"\",\r\n"
				+ "					\"consentProvidedBy\": \"Patient\",\r\n"
				+ "					\"consentType\": \"Electronic\",\r\n"
				+ "					\"documentId\": \"\",\r\n" + "					\"startDate\": \"2023-03-09\",\r\n"
				+ "					\"consentFormVersion\": \"MAT-US-2208781-v2.0-01/2023\"\r\n"
				+ "				}\r\n" + "				\r\n" + "			],\r\n" + "			\"productName\": \""
				+ productNameValue + "\",\r\n" + "			\"status\": \"Pending\",\r\n"
				+ "			\"patientParticipationEmail\": \"\"\r\n" + "		}\r\n" + "	],\r\n"
				+ "	\"lastFourDigitSSN\": \"\",\r\n" + "	\"firstName\": \"" + firstName + "\",\r\n"
				+ "	\"mobilePhone\": \"" + phoneNumber + "\",\r\n" + "	\"attachment\": [\r\n" + "		{\r\n"
				+ "			\"fileName\": \"PES CareAssist Consent Form\",\r\n"
				+ "			\"attachmentType\": \"Consent Form\",\r\n" + "			\"fileExtension\": \".pdf\",\r\n"
				+ "			\"attachmentCategory\": \"\",\r\n"
				+ "			\"externalId\": \"11c391b9-96f4-4ce4-ab43-77cd8465794d\",\r\n"
				+ "			\"descriptor\": \"Consent Form\",\r\n"
				+ "			\"contentType\": \"application/pdf\",\r\n"
				+ "			\"attachmentSource\": \"AssistRx\",\r\n" + "			\"content\": \"JVBER\"\r\n"
				+ "		}\r\n" + "	],\r\n" + "	\"OkToLeaveMessage\": false,\r\n"
				+ "	\"preferredCommunicationChannel\": \"\",\r\n" + "	\"accountSource\": \"Website\",\r\n"
				+ "	\"isOther\": false,\r\n" + "	\"email\": \"\"\r\n" + "}";
	}

	/**
	 * Function: To setup the api for assistrx
	 * 
	 * @author pratiksha Dixit
	 * @param Payload
	 * @return API response
	 */
	public static String genericApiSetupForAssistRx(String payload) {
		String APIResponse = null;

		String constApiKeyValue = Configuration.readApplicationFile("API_Value_AssistRx");
		String constBasicAuthValueAssistRX = Configuration.readApplicationFile("Basic_Auth_AssistRX");

		APIResponse = given().header(APIConstants.constApiKey, constApiKeyValue)
				.header(APIConstants.constSourceSystemKey, APIEnum.AssistRx)
				.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
				.header(APIConstants.constBasicAuthKey, constBasicAuthValueAssistRX).body(payload).when()
				.post(assistRx_Endpoint).then().assertThat().statusCode(200).extract().response().asString();

		return APIResponse;
	}

	/**
	 * Function: To hit the enrollment API
	 * 
	 * @author Pratiksha Dixit
	 * @param accessToken,Payload
	 * @return API response
	 */
	public static String apiSetupForEnrollmentAPI(String accessToken, String payload) {
		String respo = given().auth().oauth2(accessToken)
				.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue).body(payload)
				.post(enrollmentURI).then().assertThat().statusCode(200).extract().response().asString();
		return respo;
	}

	/**
	 * Function: Payload For AssistRX
	 * 
	 * @author Chaithanya
	 * @param arraylist of consent product name , patient first name, last name,
	 *                  email, Date of birth, array list of required tags
	 * @return Payload
	 
	@SuppressWarnings("finally")
	public static synchronized String payloadForAssistRX(ArrayList<String> consents, Enum Product,
			String patientFirstName, String patientLastName, String email, String dateOfBirth,
			ArrayList<String> requiredTags, String source, boolean patientParticipation, String serviceType) {
		String Payload = null;
		ReentrantLock lock = new ReentrantLock();
		  lock.lock();
		  try{
			  String ConsentsValue = null,FinacialInformationValue = null, PracticeValue= null,PatienValue = null,
					  PrescribingInformationValue= null,PrescriberValue=null,MedicalInsurancesvalue=null,
							  pbmInsurances = null,copayValue=null,authorizedRespValue=null;
			  int randNum1 = Utility_Function.generateRandomNumber();
			  int randNum2 = Utility_Function.generateRandomNumber();
			  String randChar = Utility_Function.generateRandomChar();
			  boolean PatientParticipationValue = patientParticipation ;
			  JSONArray jsonArray = new JSONArray();
				for(int i=0;i<consents.size();i++) {
						JSONObject jsonObject = new JSONObject();
						if(consents.get(i).equalsIgnoreCase("HIPAA Authorization - Designee")) {
							jsonObject.put("ConsentDesigneeFirstName", patientFirstName);
							jsonObject.put("ConsentDesigneeRelationship", "Parent");
							jsonObject.put("ConsentDesigneeLastName", patientLastName);
						}else {
							jsonObject.put("ConsentDesigneeFirstName", JSONObject.NULL);
							jsonObject.put("ConsentDesigneeRelationship", JSONObject.NULL);
							jsonObject.put("ConsentDesigneeLastName", JSONObject.NULL);
						}
						jsonObject.put("ExpirationDate", JSONObject.NULL);
						jsonObject.put("ConsentProvidedBy", patientFirstName);
						jsonObject.put("ConsentName", consents.get(i));
						jsonObject.put("ConsentGivenBy", "Patient");
						jsonObject.put("EffectiveDate", "2023-04-20T15:49:37.562");
						jsonArray.put(jsonObject);
					}
				ConsentsValue = jsonArray.toString();
				if(requiredTags.contains("finacialInformation")) {
					 FinacialInformationValue = "{\"HouseholdIncome\": \"44.00\",\"HouseholdSize\": \"5\"}";
				}
				if(requiredTags.contains("AuthorizedRepresentatives"))
				{
					authorizedRespValue="[{\"FirstName\": \"Consent1\",\"LastName\": \"Automation\",\"Relationship\": \"Parent\"}]";	
				}
				
				String constAddress1 = null;
				if(requiredTags.contains("practice")) {
					PracticeValue = "{\"OfficeContactRole\": \"Doctor\",\"Email\": null,\"Address\": "
							+ "{\"AddressLine2\": null,\"AddressLine1\": \""+constAddress1+"\",\"State\": \"TX\","
							+ "\"PostalCode\": \""+zipCode+"\",\"Country\": null,\"City\": \"texas\"},"
							+ "\"PracticeId\": \"4db6f066-4274-4760-93dd-48be003a644a\","
							+ "\"PracticeType\": \"Prescriber Office/Clinic\",\"Phone\": "
							+ "{\"Number\": \"9087272919\",\"PhoneType\": 0},\"OfficeContactName\": \"Test\","
							+ "\"Fax\": {\"Number\": \"1093747482\",\"PhoneType\": 0},\"Name\": \"Medic Hospital\"}";
				}
				
				String actualEMail = null;
				if(email!=null) {
					actualEMail = "\""+email+"\""; 
				}
			  
				PatienValue= "{\"DateOfBirth\":\""+dateOfBirth+"T00:00:00\",\"Address\":{\"AddressLine2\":\"\",\"AddressLine1\":\""+constAddress1+"\","
						+ "\"State\":\"TX\",\"PostalCode\":\""+zipCode+"\",\"Country\":null,\"City\":\"texas\"},\"FirstName\":\""+patientFirstName+"\","
					+ "\"ExternalPatientId\":null,\"Gender\":\"M\",\"MiddleName\":null,\"EmailAddress\":"+actualEMail+",\"Phones\":[{\"Number\":\"1561616516\","
						+ "\"PhoneType\":3,\"OkToLeaveMessage\":false},{\"Number\":\"1561616516\","
						+ "\"PhoneType\":2,\"OkToLeaveMessage\":true}],\"AuthorizedRepresentatives\":"+authorizedRespValue+",\"PatientId\":"
						+ "\"5"+randChar+"8Z1B7-5G"+randNum1+"-471J-"+randNum2+"DN-6B3A"+randNum2+"2564\","
						+ "\"ParentGuardian\": {\"FirstName\": \""+randNum1+"john"+randNum2+"\",\"LastName\": \""+randNum1+"rhode"+randNum2+"\""
						+ " },\"PreferredLanguage\":\"English\",\"SSN\": \"8976\",\"LastName\":\""+patientLastName+"\",\"PreferredContactType\":1}";
				
				if(requiredTags.contains("prescribingInformation")) {
						String code;
					if(Product==APIEnum.Jevtana) {
						code = "R97.21";
					}else {
						code = "C90.00";
					}
					PrescribingInformationValue = "{\"PatientWeight\": \"43\",\"Quantity\":\"1.00000\",\"Frequency\": \"1\",\"Refills\": \"\",\"Icd10\": "
							+ "\""+code+"\",\"PatientWeightUnit\": \"kg\",\"Dose\": \"1 MG\"}";
				}
				String AttachmentsValue = null;
			if(requiredTags.contains("attachments")) {
				String assistRxproductsAttchment = null;
				if(assistRxproductsAttchment.contains(Product.toString())) {
					AttachmentsValue=  "[{\"Extension\": \".pdf\",\"ContentType\": \"application/pdf\",\"Content\": \"twDracY80acM\",\"FileName\": "
							+ "\"Patient Authorization Form\",\"FormType\": \"Consent\",\"Descriptor\": \"Consent Form\",\"AttachmentId\": "
							+ "\"aebca16d-"+randNum2+"d0-4ced-9eeb-a06c04"+randNum1+"b9d6\"}]";
					
				}else {
				if(source.equals("HCP"))	{
					AttachmentsValue=  "[{\"Extension\": \".pdf\",\"ContentType\": \"application/pdf\",\"Content\": \"test\",\"FileName\": "
						+ "\"HCP CareASSIST Enrollment Form\",\"FormType\": \"EnrollmentForm\",\"Descriptor\": \"Enrollment Form\","
						+ "\"AttachmentId\": \""+randNum1+"fb62f9-4e37-46db-b8b1-"+randNum2+"e594a040d7\"}]";
				}
					if (source.equals("PES")) {
						AttachmentsValue = "[{\"Extension\": \".pdf\",\"ContentType\": \"application/pdf\",\"Content\": \"test\",\"FileName\": "
								+ "\"PES CareASSIST Enrollment Form\",\"FormType\": \"EnrollmentForm\",\"Descriptor\": \"Enrollment Form\","
								+ "\"AttachmentId\": \"" + randNum1 + "fb62f9-4e37-40qv-b8b1-" + randNum2
								+ "e404n040d6\"}]";
					}
				}
			} else {
				AttachmentsValue = "[]";
			}

			if (requiredTags.contains("prescriber")) {
				PrescriberValue = "{\"PhysicianStateLicenseNumber\": null,\"Npi\": \"1092801094\",\"FirstName\": \"Test\","
						+ "\"PrescriberId\": \"00000000-0000-0000-0000-000000000000\",\"LicensedState\": null,"
						+ "\"Specialty\": null,\"PrescriberInUS\": null,\"PhysicianName\": \"Testerman, Grace\",\"DeaNumber\": null,"
						+ "\"PhysicianLicensedState\": null,\"TaxIdNumber\": \"878190279\",\"LastName\": \"Test\",\"StateLicenseNumber\": null}";
			}

			if (requiredTags.contains("medicalInsurances")) {
				MedicalInsurancesvalue = "[{\"PolicyHolderBirthDate\": \"1990-09-09T00:00:00\",\"PolicyHolderLastName\": \"LupaAutomation\","
						+ "\"InsuranceGroupNumber\": null,\"InsuranceId\": \"b6674cda-84b9-4ed6-94aa-201d88d63d07\",\"RelationshipToMember\":"
						+ " \"self\",\"PolicyHolderFirstName\": \"Jason\",\"FaxNumber\": null,\"InsuranceCompanyName\": \""
						+ payerName + "\","
						+ "\"PlanType\": null,\"PhoneNumber\": null,\"Rank\": 1,\"InsuranceMemberNumber\": \"1900734872\"}]";
			}

			if (requiredTags.contains("pbmInsurances")) {
				pbmInsurances = "[{\"InsuranceId\": \"61a73d6b-0378-4b86-a19e-12f0d0cecbeb\",\"RelationshipToMember\": null,\"Rank\": 1,"
						+ "\"ProcessorControlNumber\": null,\"PolicyHolderBirthDate\": null,\"PolicyHolderLastName\": null,\"InsuranceGroupNumber\":"
						+ " null,\"PbmName\": \"Acara\",\"PolicyHolderFirstName\": null,\"PlanType\": \"Commercial Plan\",\"BankIdentificationNumber\":"
						+ " \"161461\",\"PhoneNumber\": null,\"InsuranceMemberNumber\": null}]";
			}

			if (requiredTags.contains("copay")) {
				copayValue = "{\"ValidPrescription\": true,\"CoveredForReimbursement\": false,\"IsEligibleForCopay\": true,\"FAPatientAcceptsCopayTerms\":"
						+ " true,\"IsUsResident\": true,\"IsMilitary\": null,\"HasGovernmentAssistance\": null,\"HasMilitaryAssistance\": null,\"CardId\":"
						+ " null,\"HasCommercialInsurance\": true}";
			}

			Payload = "{\"PatientParticipation\": " + PatientParticipationValue + "," + "\"Consents\": " + ConsentsValue
					+ "," + "\"FinancialInformation\": " + FinacialInformationValue + "," + "\"ExternalId\": null,"
					+ "\"Practice\": " + PracticeValue + "," + "\"Product\": \"" + Product + "\"," + "\"Patient\": "
					+ PatienValue + "," + "\"PrescribingInformation\": " + PrescribingInformationValue + ","
					+ "\"ArxId\": \"" + "h" + randChar + "9" + randNum1 + "bc-2f" + randChar + "-4h1o-" + randNum2
					+ "dg-f" + randChar + "0" + randNum1 + "b" + randNum2 + "bd4" + "\"," + "\"PbmInsurances\": "
					+ pbmInsurances + "," + "\"Attachments\": " + AttachmentsValue + "," + "\"Source\": \"" + source
					+ "\"," + "\"PatientParticipationMobile\": null," + "\"Prescriber\": " + PrescriberValue + ","
					+ "\"ServiceType\": \"" + serviceType + "\"," + "\"PatientParticipationEmail\": null,"
					+ "\"Pharmacy\": null," + "\"Copay\": " + copayValue + "," + "\"MedicalInsurances\": "
					+ MedicalInsurancesvalue + " }";
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			lock.unlock();
			return Payload;
		}
	}*/

	/**
	 * Function: To generate payload for Marketing Website Form
	 * 
	 * @author Gayathiri
	 * @param randNum1, randNum2, WebFormVal =
	 *                  Cablivi/Eloctate/Alprolix/CAD/Enjaymo, emailVal
	 * @return Generated payload
	 */
	public static String payloadForCerdelgaWebsiteForm(String firstname, String lastname, String email, String zipcode,
			String status, String disease, String EP) {
		String payload = "{\"lastName\": \"" + lastname + "\",\"firstName\": \"" + firstname
				+ "\",\"onSanofiProduct\": false,\"address\": {\"zipCode\": \"" + zipcode + "\","
				+ "\"address2\": \"\",\"city\": \"Not Provided\",\"address1\": \"Not Provided\",\"addressType\": \"Home\",\"primaryAddress\": true,\"state\":"
				+ " \"NY\"},\"mobilePhone\": \"8765432109\",\"homePhone\": \"\",\"isCareGiver\": false,\"preferredCommunicationChannel\": \"\","
				+ "\"communicationLanguage\": \"\",\"accountSource\": \"Website\",\"program\": [{ \"disease\": \""
				+ disease + "\", \"engagementProgramName\": " + "\"" + EP + "\", \"diagnosisStatus\": \"" + status
				+ "\", \"diseaseSubType\": \"Type I\", \"enrollmentDate\": \"2023-06-21\", "
				+ "\"leadChannel\": \"Cerdelga.com\", \"consent\": [{ \"endDate\": \"\", \"consentProvidedBy\": \"Patient\", \"consentType\": \"Electronic\","
				+ " \"permission\": \"Granted\", \"serviceName\": \"RD Marketing Consent\", \"responseDate\": \"2023-06-21\", \"startDate\": \"2023-06-21\", "
				+ "\"consentFormVersion\": \"MAT-US-2003209. April 2020\" } ], \"productName\": \"Cerdelga\"}],\"isOther\": false,\"email\": "
				+ "\"" + email + "\" }";
		return payload;
	}

	/**
	 * Function: To generate payload for Website i.e Fitusiran
	 * 
	 * @author Pratiksha Dixit
	 * @param State, Zipcode, Diease, EP etc
	 * @return Generated payload
	 */

	public static String payloadForFitusiranWebsiteEnrollment(String firstname, String lastname, String email,
			String zipcode, String status, String disease, String EP, String phoneNumber, String state,
			String enrollmentDateValue, String productValue, String leadchannelValue) {
		String payload = "{\r\n" + "	\"isCareGiver\": false,\r\n" + "	\"isOther\": false,\r\n"
				+ "	\"onSanofiProduct\": true,\r\n" + "	\"preferredCommunicationChannel\": \"Email\",\r\n"
				+ "	\"lastName\": \"" + lastname + "\",\r\n" + "	\"firstName\": \"" + firstname + "\",\r\n"
				+ "	\"homePhone\": \"" + phoneNumber + "\",\r\n" + "	\"email\": \"" + email + "\",\r\n"
				+ "	\"accountSource\": \"Website\",\r\n" + "	\"mobilePhone\": null,\r\n" + "	\"address\": {\r\n"
				+ "		\"zipCode\": \"" + zipcode + "\",\r\n" + "		\"address2\": null,\r\n"
				+ "		\"city\": \"Not Provided\",\r\n" + "		\"address1\": \"Not Provided\",\r\n"
				+ "		\"addressType\": \"Home\",\r\n" + "		\"primaryAddress\": true,\r\n" + "		\"state\": \""
				+ state + "\"\r\n" + "	},\r\n" + "	\"program\": [\r\n" + "		{\r\n" + "			\"disease\": \""
				+ disease + "\",\r\n" + "			\"engagementProgramName\": \"" + EP + "\",\r\n"
				+ "			\"enrollmentDate\": \"" + enrollmentDateValue + "\",\r\n" + "			\"productName\": \""
				+ productValue + "\",\r\n" + "			\"status\": \"" + status + "\",\r\n"
				+ "			\"leadChannel\": \"" + leadchannelValue + "\",\r\n" + "			\"consent\": [\r\n"
				+ "				{\r\n" + "					\"endDate\": \"\",\r\n"
				+ "					\"consentProvidedBy\": \"Patient\",\r\n"
				+ "					\"consentType\": \"Electronic\",\r\n"
				+ "					\"permission\": \"Granted\",\r\n"
				+ "					\"serviceName\": \"RBD Marketing Consent\",\r\n"
				+ "					\"responseDate\": \"" + enrollmentDateValue + "\",\r\n"
				+ "					\"startDate\": \"" + enrollmentDateValue + "\"\r\n" + "				}\r\n"
				+ "			]\r\n" + "		}\r\n" + "	]\r\n" + "}";
		return payload;
	}

	/**
	 * Function: To generate API setup for Cerledga Website Form
	 * 
	 * @author Gayathiri
	 * @param payload
	 */
	public static String apiSetupForCerdelgaWebsiteForm(String payload) {

		String constApiKeyValueCerdelga = Configuration.readApplicationFile("API_Value_Cerdelga");
		String constBasicAuthValueCerdelga = Configuration.readApplicationFile("Basic_Auth_Cerdelga");
		String constCerdelgaURL = Configuration.readApplicationFile("URI_Cerdelga");

		return given().header(APIConstants.constApiKey, constApiKeyValueCerdelga)
				.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
				.header(APIConstants.constBasicAuthKey, constBasicAuthValueCerdelga).body(payload).when()
				.post(constCerdelgaURL).then().assertThat().statusCode(200).extract().response().asPrettyString()
				.toString();
	}

	/**
	 * Function: To setup and hit API for CADUnraveled.com for GP
	 * 
	 * @author Pratiksha Dixit
	 * @param WebFormVal = CADUnraveled.com
	 */
	public static String apiSetupFoCADUnraveledcomGPWebsite(String payloadValue) {

		String constApiKeyValueMarketing = Configuration.readApplicationFile("API_Value_Marketing");
		String constBasicAuthValueMarketing = Configuration.readApplicationFile("Basic_Auth_Marketing");

		return given().header(APIConstants.constApiKey, constApiKeyValueMarketing)
				.header(APIConstants.constSourceSystemKey, APIConstants.constSourceSystemValueToCreateLead)
				.header(APIConstants.constContentTypeKey, APIConstants.constContentTypeValue)
				.header(APIConstants.constBasicAuthKey, constBasicAuthValueMarketing).body(payloadValue).when()
				.post(marketing_Endpoint).then().assertThat().statusCode(200).extract().response().asPrettyString()
				.toString();

	}

	/**
	 * Function: To generate payload for Marketing Website Form
	 * 
	 * @author Pratiksha Dixit
	 * @param firstname,lastname,website, email, phonenumber
	 * 
	 * @return Generated payload
	 */
	public static String payloadForCadunraveled(String firstName, String lastName, String websiteName, String emailVal,
			String zipcodeValue, String phoneNumberValue, String stateValue,String type,String quizResultValue,String diagnosedStatus) {
	
		String payload = "{\r\n" + "    \"Zip\": \"" + zipcodeValue + "\",\r\n"
				+ "    \"PatientType\": \""+type+"\",\r\n" + "    \"Email\": \"" + emailVal + "\",\r\n"
				+ "    \"ContactType\": \"\",\r\n" + "    \"TSD\": \"\",\r\n" + "    \"FirstName\": \"" + firstName
				+ "\",\r\n" + "    \"Address2\": \"\",\r\n" + "    \"Birthday\": \"\",\r\n"
				+ "    \"Address1\": \"Not Provided\",\r\n" + "    \"City\": \"Not Provided\",\r\n"
				+ "    \"PrivacyPolicyAgreement\": \"yes\",\r\n" + "    \"shareStory\": \"\",\r\n"
				+ "    \"Treatment\": \"\",\r\n" + "    \"State\": \"" + stateValue + "\",\r\n"
				+ "    \"PhoneNumber\": \"" + phoneNumberValue + "\",\r\n" + "    \"SelectedGift\": \"Care Kit\",\r\n"
				+ "    \"Country\": \"United States\",\r\n" + "    \"LastName\": \"" + lastName + "\",\r\n"
				+ "    \"SelectedUser\": \"Yes\",\r\n" + "    \"WebformName\": \"" + websiteName + "\",\r\n"	
				+ "    \"QuizResultCode\": \""+quizResultValue+"\",\r\n" + "    \"DiagnosisDuration\": \""+diagnosedStatus+"\"\r\n"
				+ "}";
		return payload;
	}

}