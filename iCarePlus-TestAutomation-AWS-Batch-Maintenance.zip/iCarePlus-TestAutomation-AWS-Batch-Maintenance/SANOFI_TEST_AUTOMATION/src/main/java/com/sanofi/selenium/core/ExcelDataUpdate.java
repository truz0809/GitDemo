package com.sanofi.selenium.core;

import org.openqa.selenium.WebDriver;
import org.apache.poi.ss.usermodel.*;
import com.sanofi.selenium.utils.TestDataContext;

import java.io.*;
import java.util.*;

public class ExcelDataUpdate extends Utility_Function {
	public ExcelDataUpdate(WebDriver driver) {
		super(driver);
	}

	// Thread-safe lock for all Excel operations across JVM
	private static final Object excelLock = new Object();

	private static final Map<String, String> FUNCTIONALITY_TO_SHEET_NAME = Map.ofEntries(
			Map.entry("Enrollment", "PDF_Data"), Map.entry("Consent Management", "Consent_Management"),
			Map.entry("MissingInformation", "MI_Management"), Map.entry("Free Goods", "Free_Goods"),
			Map.entry("DocumentManagement", "Doc_MGMNT"), Map.entry("Fax", "Fax"),
			Map.entry("AdminSetup", "AdminSetup"), Map.entry("BenefitVerification", "BenefitVerification"),
			Map.entry("CareProgram", "CareProgram"), Map.entry("CopayWorkflow", "CopayWorkflow"),
			Map.entry("DocDropPortal", "DocDropPortal"), Map.entry("PARenewAppeal", "PARenewAppeal"),
			Map.entry("PatientEducation", "PatientEducation"), Map.entry("PatientEnrollment", "PatientEnrollment"),
			Map.entry("ProgramAndCareTeamMGMNT", "ProgramAndCareTeamMGMNT"),
			Map.entry("ReportsDashboard", "ReportsDashboard"), Map.entry("RGNAlerts", "RGNAlerts"),
			Map.entry("RGNAM", "RGNAM"), Map.entry("RGNPhone", "RGNPhone"), Map.entry("RGNTTP", "RGNTTP"),
			Map.entry("SecurityAccessMgmnt", "SecurityAccessMgmnt"),
			Map.entry("SpecialtyPharmacyDataDispenses", "SpecialtyPharmacyDataDispenses"),
			Map.entry("TriageToPharmacy", "TriageToPharmacy"),
			Map.entry("BenefitsVerificationWorkflow", "BenefitsVerificationWorkflow"),
			Map.entry("IAPWorkflow", "IAPWorkflow"),
			Map.entry("MissingInformationManagement", "MissingInformationManagement"),
			Map.entry("PAPWorkflow", "PAPWorkflow"),
			Map.entry("PriorAuthorizationWorkflow", "PriorAuthorizationWorkflow"),
			Map.entry("QuickStartWorkFlow", "QuickStartWorkFlow"));

	// System.getProperty("user.dir") + "/TestData/EnrollmentFormTestData.xlsx";
	private String sheetName;

	public void selectExcelSheet(String functionality) {
		this.sheetName = FUNCTIONALITY_TO_SHEET_NAME.getOrDefault(functionality, functionality);
	}

	public static String getLatestTestDataFilePath() {
		String testDataDirPath = System.getProperty("user.dir") + "/TestData";
		File folder = new File(testDataDirPath);

		File[] matchingFiles = folder
				.listFiles((dir, name) -> name.matches("Test_[a-f0-9\\-]{36}_EnrollmentFormTestData\\.xlsx"));

		if (matchingFiles != null && matchingFiles.length > 0) {
			File latestFile = matchingFiles[0];
			for (File file : matchingFiles) {
				if (file.lastModified() > latestFile.lastModified()) {
					latestFile = file;
				}
			}
			return latestFile.getAbsolutePath();
		} else {
			throw new RuntimeException("No matching test data file found in " + testDataDirPath);
		}
	}

	public void updateExcelData(String tcNum, String[] columnsToUpdate, String[] columnValues) {
	    synchronized (excelLock) {
	        try (FileInputStream fis = new FileInputStream(getTestDataFilePath());
	             Workbook workbook = WorkbookFactory.create(fis)) {

	            Sheet sheet = workbook.getSheet(sheetName);
	            if (sheet == null) {
	                System.err.println("Sheet not found: " + sheetName);
	                return;
	            }

	            Row headerRow = sheet.getRow(0);
	            if (headerRow == null) {
	                System.err.println("Header row not found in sheet.");
	                return;
	            }

	            int[] columnIndices = new int[columnsToUpdate.length];
	            for (int i = 0; i < columnsToUpdate.length; i++) {
	                columnIndices[i] = findColumnIndex(headerRow, columnsToUpdate[i]);
	                if (columnIndices[i] == -1) {
	                    System.err.println("Column not found: " + columnsToUpdate[i]);
	                }
	            }

	            int rowIndex = findRowIndex(sheet, tcNum);
	            if (rowIndex == -1) {
	                System.err.println("Test case not found: " + tcNum);
	                return;
	            }

	            Row row = sheet.getRow(rowIndex);
	            
	            // ADD THIS: Verify correct row with retry mechanism
	            String actualTcNum = getCellValueAsString(row.getCell(0));
	            if (!tcNum.equals(actualTcNum)) {
	                System.out.println("Row mismatch detected. Expected: " + tcNum + ", Found: " + actualTcNum + ". Retrying...");
	                
	                // Retry finding the correct row
	                rowIndex = findRowIndex(sheet, tcNum);
	                if (rowIndex == -1) {
	                    throw new RuntimeException("TC " + tcNum + " not found after retry");
	                }
	                
	                row = sheet.getRow(rowIndex);
	                actualTcNum = getCellValueAsString(row.getCell(0));
	                
	                if (!tcNum.equals(actualTcNum)) {
	                    throw new RuntimeException("Excel data corruption persists: Expected TC " + tcNum + " but found " + actualTcNum + " even after retry");
	                }
	                
	                System.out.println("Retry successful. Found correct row for TC: " + tcNum);
	            }
	            
	            for (int i = 0; i < columnIndices.length; i++) {
	                if (columnIndices[i] != -1) {
	                    Cell cell = row.getCell(columnIndices[i], Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
	                    cell.setCellValue(columnValues[i]);
	                }
	            }

	            try (FileOutputStream fos = new FileOutputStream(getTestDataFilePath())) {
	                workbook.write(fos);
	                System.out.println("Excel updated for TC: " + tcNum + " by thread: " + Thread.currentThread().getName());
	            }

	        } catch (Exception e) {
	            System.err.println("Error updating Excel: " + e.getMessage());
	            e.printStackTrace();
	        }
	    }
	}

	public void removeExcelData(String tcNum, String[] columnsToRemove) {
	    synchronized (excelLock) {
	        try (FileInputStream fis = new FileInputStream(getTestDataFilePath());
	             Workbook workbook = WorkbookFactory.create(fis)) {

	            Sheet sheet = workbook.getSheet(sheetName);
	            if (sheet == null) {
	                System.err.println("Sheet not found: " + sheetName);
	                return;
	            }

	            Row headerRow = sheet.getRow(0);
	            int[] columnIndices = Arrays.stream(columnsToRemove).mapToInt(col -> findColumnIndex(headerRow, col))
	                    .toArray();

	            int rowIndex = findRowIndex(sheet, tcNum);
	            if (rowIndex != -1) {
	                Row row = sheet.getRow(rowIndex);
	                
	                // ADD THIS: Verify correct row with retry mechanism
	                String actualTcNum = getCellValueAsString(row.getCell(0));
	                if (!tcNum.equals(actualTcNum)) {
	                    System.out.println("Row mismatch detected. Expected: " + tcNum + ", Found: " + actualTcNum + ". Retrying...");
	                    
	                    // Retry finding the correct row
	                    rowIndex = findRowIndex(sheet, tcNum);
	                    if (rowIndex == -1) {
	                        throw new RuntimeException("TC " + tcNum + " not found after retry");
	                    }
	                    
	                    row = sheet.getRow(rowIndex);
	                    actualTcNum = getCellValueAsString(row.getCell(0));
	                    
	                    if (!tcNum.equals(actualTcNum)) {
	                        throw new RuntimeException("Excel data corruption persists: Expected TC " + tcNum + " but found " + actualTcNum + " even after retry");
	                    }
	                    
	                    System.out.println("Retry successful. Found correct row for TC: " + tcNum);
	                }
	                
	                for (int colIndex : columnIndices) {
	                    if (colIndex != -1 && row.getCell(colIndex) != null) {
	                        row.removeCell(row.getCell(colIndex));
	                    }
	                }
	            }

	            try (FileOutputStream fos = new FileOutputStream(getTestDataFilePath())) {
	                workbook.write(fos);
	                System.out.println("Data removed from TC: " + tcNum + " by thread: " + Thread.currentThread().getName());
	            }

	        } catch (Exception e) {
	            System.err.println("Error removing Excel data: " + e.getMessage());
	            e.printStackTrace();
	        }
	    }
	}
	private String getCellValueAsString(Cell cell) {
	    if (cell == null) return "";
	    
	    switch (cell.getCellTypeEnum()) {
	        case STRING:
	            return cell.getStringCellValue().trim();
	        case NUMERIC:
	            return String.valueOf((long) cell.getNumericCellValue());
	        case BOOLEAN:
	            return String.valueOf(cell.getBooleanCellValue());
	        default:
	            return "";
	    }
	}
	
	
	public void updateExcelTestData(String testCaseNumber, Map<String, String> testData, String functionality) {
		List<String> columns = new ArrayList<>(testData.keySet());
		List<String> values = new ArrayList<>(testData.values());

		selectExcelSheet(functionality);
		updateExcelData(testCaseNumber, columns.toArray(new String[0]), values.toArray(new String[0]));
	}

	private static int findColumnIndex(Row headerRow, String columnName) {
		for (int i = 0; i < headerRow.getLastCellNum(); i++) {
			Cell cell = headerRow.getCell(i);
			if (cell.getCellTypeEnum() == CellType.STRING) {
				if (columnName.equalsIgnoreCase(cell.getStringCellValue().trim())) {
					return i;
				}
			}
		}
		return -1;
	}

	private static int findRowIndex(Sheet sheet, String testCaseNumber) {
		for (int i = 1; i <= sheet.getLastRowNum(); i++) {
			Row row = sheet.getRow(i);
			if (row == null)
				continue;
			Cell cell = row.getCell(0);
			if (cell.getCellTypeEnum() == CellType.STRING) {
				if (testCaseNumber.equals(cell.getStringCellValue().trim())) {
					return i;
				}
			}

		}
		return -1;
	}

	private String getTestDataFilePath() {
		return TestDataContext.getExcelPath();
	}

	public Map<String, String> createTestData(Map<String, String> testData) {
		return new HashMap<>(testData);
	}

	public static void setThreadSpecificTestDataFilePath(String path) {
		TestDataContext.setExcelPath(path);
	}

}
