package com.sanofi.selenium.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.sanofi.selenium.constants.TestData;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class BenefitVerificationPage extends Utility_Function {

	public BenefitVerificationPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	String memberPlanText;
	Random random = new Random();
	String[] firstNames = TestData.firstNames;
	String[] lastNames = TestData.lastNames;
	String firstName = firstNames[random.nextInt(firstNames.length)];
	String lastName = lastNames[random.nextInt(lastNames.length)];
	String fullName = firstName + " " + lastName;

	/************************* Elements *************************/

	public static By eleCareProgramDropdown = By.xpath("//*[@title='Select a List View: Care Program Enrollees']");
	public static By elePendingBV = By.xpath("//*[text()='Pending BVs']");
	public static By eleSearchDocInput = By.xpath("//*[@placeholder=\"Search this list...\"]");
	public static By eleCheckbox = By.xpath(
			"(//*[text()=\"Select item 1\"]//preceding-sibling::span//ancestor::div[contains(@class,\"slds-grid--align-spread\")]//span)[1]");
	public static By eleMyBVs = By.xpath("//*[@title='Select a List View: Care Program Enrollees']");
	public static By eleAssignToMeButton = By.xpath("//*[@title='Assign to me']");
	public static By eleCareProgramRecord = By.xpath(
			"//span[text()=\"Select item 1\"]//preceding-sibling::span//ancestor::div[contains(@class,\"slds-grid--align-spread\")]//ancestor::td//following-sibling::td//span");
	public static By eleBenefitsVerification = By.xpath("//p[@title='Benefits Verification']");
	public static By eleMyTaskTitle = By.xpath("//*[text()='My Tasks']");
	public static By eleBVCaptureStatus = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Review and Finalize Benefit\"]//parent::div//*[text()=\"Not Started\"]");
	public static By eleRequiredStatus = By.xpath("//*[text()='Required']");
	public static By eleReviewandFinalizeBenefit = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Review and Finalize Benefit\"]");
	public static String eleBVIcon = "(//*[local-name()='svg' and @class='slds-icon' and @data-key='work_type'])[1]";
	public static By eleMedicalPayercheckbox = By.xpath(
			"//*[contains(text(),\"Pharmacy\")]//preceding-sibling::span//ancestor::div[contains(@class,\"slds-checkbox\")]//label//span[1]");

	public static By eleShowDetailsButton = By.xpath("(//*[contains(text(),\"Show Details\")])[1]");
	public static By reviewAndFinalizeBenefitTimeline = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Timeline\"]//following::*[text()=\"Review and Finalize Benefit\"])[1]");
	public static By attemptOutreachForConsentsChkbx = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"Attempt Outreach for Consents?\")]//preceding-sibling::*[contains(@class,\"slds-checkbox\")]");

	public static By eleMemberPlan = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"* Member Plan\"]//parent::label//parent::div//following-sibling::*[contains(@class,\"slds-combobox\")]");
	public static By eleCoverageBenefitName = By
			.xpath("(//*[text()='Name']//parent::label//parent::div//following-sibling::div//input)[2]");
	public static By eleErrorMessage = By.xpath(
			"//*[text()='Select a task related to a care program enrollee work order step that’s in progress.']");
	public static By eleSaveButton = By.xpath("(//*[text()='Save'])[2]");
	public static By eleCompleteRecord = By.xpath("(//*[text()='Complete'])[1]");
	public static By eleReviewAndSummaryOfBenefits = By.xpath("//*[text()='Review and Send Summary of Benefits']");
	public static By eleReviewAndSummaryOfBenefitsRequired = By.xpath("(//*[text()='Required'])[2]");
	public static By eleOutcomeReason = By.xpath(
			"//*[contains(@class,\"slds-combobox\")]//*[text()='Outcome Reason']//parent::label//parent::div//following-sibling::div");
	public static By eleOutcomeReasonDropdown = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"Outcome Reason\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]");
	public static By eleSaveOutcome = By.xpath("(//*[text()='Save'])[2]");
	public static By eleSaveOutcome1 = By.xpath("(//*[text()='Save'])[1]");
	// changesw
	public static By eleBVSummaryState = By.xpath("(//*[text()='Done'])[4]");
	// changesw
	public static By eleBVSummaryCompletedState = By.xpath("(//*[text()='Completed'])[2]");

	public static String elePAIcon = "(//*[local-name()='svg' and @class='slds-icon' and @data-key='work_type'])[2]";
	// changesw
	public static By eleSavePADetails = By.xpath("//*[text()='Save']");
	public static By eleHCPFollowUp = By.xpath("//*[text()='Not Started']");
	public static By PASummaryRequired = By.xpath("(//*[text()='Required'])[2]");
	public static By PAPharmacySave = By.xpath("(//*[text()='Save'])[4]");
	public static By eleMedicalSave = By.xpath("(//*[text()='Save'])[1]");
	public static By PACompletion = By.xpath("(//*[text()='Complete'])[2]");
	public static By elePharmacySave = By.xpath("(//*[text()=\"Save\" and @class='btnLabel']//parent::button)[1]");
	public static By eleCoverageBenefit = By.xpath("(//*[text()=\"Save\" and @class='btnLabel']//parent::button)[2]");
	public static By eleattemptOutreachconsents = By.xpath(
			"//*[text()=\"Attempt Outreach for Consents?\"]//parent::label[@class=\"slds-checkbox__label\"]//span");

	public static By showDetails = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Show Details\"]//parent::button)[1]");
	public static String checkBox = "//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"{0}\")]//ancestor::div[contains(@class,\"slds-checkbox\")]//input";
	public static By elePayerPharamcy1 = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Payer Designated Specialty Pharmacy #1\"]//ancestor::runtime_omnistudio_omniscript-omniscript-text-block//following-sibling::runtime_omnistudio_omniscript-omniscript-text//input)[1]");
	public static By elePayerPharamcy2 = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Payer Designated Specialty Pharmacy #2\"]//ancestor::runtime_omnistudio_omniscript-omniscript-text-block//following-sibling::runtime_omnistudio_omniscript-omniscript-text//input)[1]");
	public static By elePayerPharamcy3 = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Payer Designated Specialty Pharmacy #3\"]//ancestor::runtime_omnistudio_omniscript-omniscript-text-block//following-sibling::runtime_omnistudio_omniscript-omniscript-text//input");
	public static By eleCompleteButton = By
			.xpath("(//*[text()=\"Complete\" and @class='btnLabel']//parent::button)[1]");
	public static By hcoCard = By.xpath("//*[text()='HCO Information']");
	public static By assessmentlistViewButton = By.xpath("//*[contains(@title,'Select a List View: Assessment Tasks') and @type='button']");

	/************************* Dynamic Elements *************************/

	public static String strBVStatus = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]";
	public static String strBVFields = "//p[text()=\"{0}\"]";
	public static String strReviewAndFinalizeBenefitSection = "//*[text()=\"{0}\"]";
	public static String strTextBoxesInput = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strMemberPlans = "(//*[contains(text(),\"{0}\")])[1]";
	public static By eleMemberPlanDropdown = By.xpath(
			"((//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Member Plan\"])[2]//ancestor::runtime_omnistudio_omniscript-omniscript-lookup//following-sibling::runtime_omnistudio_omniscript-omniscript-select)[1]//child::input");
	public static String strSubHeadingText = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strCoverageBenefitFieldList = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::*[contains(@class,\"option-text\")]";
	public static String strCoverageBenefitFieldsText = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//child::input";
	public static String strBVStatusLabel = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strBVHeading = "//h1[text()=\"{0}\"]";

	public static String strOutcomeDropdown = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//child::div//child::div//following-sibling::div//ul//li//div//span//span";
	public static String strSearchBarDropdown = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div[contains(@class,\"slds-combobox\")]//input";

	public static String strPriorAuth = "//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div";
	public static String strPriorAuthDropdown = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::*[contains(@class,\"option-text\")]";
	public static String strPriorAuthDateField = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String eleButton = "//*[contains(@class,\"active lafPageHost\")]//*[@title=\"{0}\"]";
	public static String strInputBpx = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strPharmcySearch = "//*[contains(@class,\"active lafPageHost\")]//*[@data-omni-key=\"{0}\"]//button";
	public static String payerRadioBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::tr//lightning-button//button[@title=\"Select\"]";
	public static String payerPharmacy1Select = "//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"{0}\")]//ancestor::tr//lightning-button//*[@title=\"Select\"]";
	public static String taskButton = "(//*[contains(@class,\"active lafPageHost\")]//*[@class=\"slds-section__title\"]//*[text()=\"{0}\"]//parent::div//span)[1]";
	public static String strSubTaskStatus = "(//*[contains(@class,\"active lafPageHost\")]//*[@class=\"card\"]//*[text()=\"{0}\"]//parent::div//li)[2]";
	public static String strDropDownInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String searchDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]";
	public static String strDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]";
	public static String strInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strSection = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";
	public static String strInputBoxPAPending = "//*[contains(@class,\"active lafPageHost\")]//runtime_omnistudio_omniscript-omniscript-text[@data-omni-key=\"ICC_PAAppealProcessorPending\"]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String checkBoxSubmissionChannel = "(//*[contains(@class,\"active lafPageHost\")]//*[@name=\"PASubmissionChannelNotFile\"]//parent::div//span[text()=\"{0}\"]//parent::label//span)[1]";
	public static String checkBoxPAOutcomeChannel = "(//*[contains(@class,\"active lafPageHost\")]//*[@name=\"ICC_PAResultsHCPNotificationChannel__c\"]//parent::div//span[text()=\"{0}\"]//parent::label//span)[1]";
	public static String newEleFields = "//*[text()=\"{0}\"]";
	public static String patientCardFields = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[@class=\"vloc-min-height\"]//span";
	public static String strPayerSearch = "//*[contains(@class,\"active lafPageHost\")]//*[@data-omni-key=\"{0}\"]//input[1]";
	public static String strPayerSearch1 = "//*[contains(@class,\"active lafPageHost\")]//*[@data-omni-key=\"{0}\"]/following::button[1]";
	public static String strDocumentPageTitle = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String viewAllButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::span[text()=\"View All\"]";


	public static String relatedTabSection = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	//public static String viewAllButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::span[text()=\"View All\"]";


	public void verifytheBVTaskInitiated() {
		try {
			setTimeOut(2000);
			By BVButton = getDynamicElement(eleButton, "Benefits Verification");
			waitAndVerifyElement(BVButton);
			scrollToElement(BVButton);
			click(BVButton);
			setTimeOut(2000);
			String buttonState = getAttributeValue(BVButton, "aria-pressed");
			// Assert the state of the button
			Assert.assertEquals(buttonState, "true", "BV flow is initialized");
			LoggingInfo("BV flow is initialized");
			// setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to check the status of BV flow intiation " + e.getMessage());
			Assert.fail("Failed to check the status of BV flow intiation " + e.getMessage());
		}
	}






	public void navigateToCPEPTable() 
	{
		try 
		{
			LoggingInfo("Click on Related tab");
			By relatedTab = getDynamicElement(relatedTabSection, "Related");
			waitAndVerifyElement(relatedTab);
			scrollToElement(relatedTab);
			clickByJavascript(relatedTab);
			LoggingInfo("Navigate to Care Program Enrollee Products SPs Table ");
			By orderTable = getDynamicElement(relatedTabSection, "Care Program Enrollee Product SPs");
			waitAndVerifyElement(orderTable);
			scrollToElement(orderTable);
			LoggingInfo("Navigated to Orders");
			setTimeOut(2000);
		} 
		catch (Exception e) 
		{
			Log.error("Failed to navigate to orders table  " + e.getMessage());
			Assert.fail("Failed to navigate to orders table  " + e.getMessage());
		}
	}





	public void verifytheBVTaskNotInitiated() {
		try {
			By BVButton = getDynamicElement(eleButton, "Benefits Verification");
//			waitAndVerifyElement(BVButton);
//			scrollToElement(BVButton);
//			click(BVButton);
			setTimeOut(4000);
			String buttonState = getAttributeValue(BVButton, "aria-pressed");
			// Assert the state of the button
			Assert.assertEquals(buttonState, "false", "BV flow is not initialized");
			LoggingInfo("BV flow is not initialized, Hence Verified.");
			// setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to check the status of BV flow intiation " + e.getMessage());
			Assert.fail("Failed to check the status of BV flow intiation " + e.getMessage());
		}
	}

	public void verifyCPEPSPsTable(String tableName)
	{
		try
		{
			
			setTimeOut(5000);
			Log.info("Open each record of the table");
		
			List<WebElement> li = getWebDriver().findElements(By.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='Payer']//ancestor::td//preceding-sibling::th"));

			for (WebElement element : li) 
			{
			String eleText = element.getText();
			element.click();
			setTimeOut(3000);
			String title = getWebDriver().getTitle(); 
			System.out.println(title);
			String[] split = title.split("|");
			String word = split[0].trim();
			System.out.print(word);
			WebElement SPType = getWebDriver().findElement(By.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='Selected for Triage']//parent::div//parent::div//following-sibling::div//span")); 
			String value = SPType.getText();
			Assert.assertEquals(value, "No", "Selected For Triage");
			WebElement closeBtn = getWebDriver().findElement(By.xpath("//ul[contains(@class,'tabBarItems slds-tabs--default__nav')]//li/a[contains(@ title,'"+word+"')]/..//div//button[contains(@ title , 'Close')]"));
			closeBtn.click();
			}			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("Failed to verify Selected For Triage Field" + e.getMessage());
			Assert.fail("Failed to verify Selected For Triage Field" + ". Error - " + e.getMessage());	
		}
	}	





	public void verifySelectedSpecialityPharmacyIsBlank() 
	{
		try 
		{
			Log.info("Verify Selected Specialty Pharmacy field");
			By selectedSP = getDynamicElement(spEle, "Selected Specialty Pharmacy");
		//	waitAndVerifyElement(selectedSP);
			scrollToElement(selectedSP);
			String selectedSPName = getWebDriver().findElement(selectedSP).getAttribute("value");
			Assert.assertEquals(selectedSPName, null, "Selected Specialty Pharmacy");
			LoggingInfo("Verified Selected Speciality Pharmacy field is null");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Log.error("Failed to verify Selected Specialty Pharmacy field" + e.getMessage());
			Assert.fail("Failed to verify Selected Specialty Pharmacy field" + ". Error - " + e.getMessage());
		}
	}

	
	public static String spEle="//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"slds-form-element\")]//span//slot//span//slot//span";

	public static String correspondenceInputField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"slds-form-element\")]//lightning-formatted-text";

	public void verifySPTypeIsBlank() 
	{
		try 
		{
			Log.info("Verify SP Type field");
			By SPType = getDynamicElement(correspondenceInputField, "SP Type");
			scrollToElement(SPType);
			String SPTypeName = getWebDriver().findElement(SPType).getAttribute("value");
			Assert.assertEquals(SPTypeName, null, "SP Type");
			LoggingInfo("Verified SP Type field is null");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Log.error("Failed to verify SP Type field" + e.getMessage());
			Assert.fail("Failed to verify SP Type field" + ". Error - " + e.getMessage());
		}
	}
	

	public void clickOnViewAll(String tablename) 
	{
		try 
		{
			Log.info("Click on View All lInk of the table");
			By viewAllbutton = getDynamicElement(viewAllButton, tablename);
			waitAndVerifyElement(viewAllbutton);
			scrollToElement(viewAllbutton);
			setTimeOut(4000);
			waitForPageLoaded();
			waitForelementToBeClickable(viewAllbutton);
			setTimeOut(2000);
			clickByJavascript(viewAllbutton);
			LoggingInfo("Clicked on view all button");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Log.error("Failed to click on view all button " + e.getMessage());
			Assert.fail("Failed to click on view all button " + e.getMessage());
		}
	}








	public void verifyBVTasks() {

		try {
			setTimeOut(1000);
			Actions act = new Actions(getWebDriver());
			WebElement BVIcon = getWebDriver().findElement(By.xpath(eleBVIcon));
			act.moveToElement(BVIcon).click(BVIcon).perform();
			setTimeOut(2000);
			waitAndVerifyElement(eleMyTaskTitle);
			By eleBVCapture = getDynamicElement(strBVStatus, "BV Capture");
			waitAndVerifyElement(eleBVCapture);
			LoggingInfo("BV Capture verified successfully");

//			By eleBVSummary = getDynamicElement(strBVStatus, "BV Summary");
//			waitAndVerifyElement(eleBVSummary);
//			LoggingInfo("BV Summary verified successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify BV Tasks  " + e.getMessage());
			Assert.fail("Failed to verify BV Tasks " + ". Error - " + e.getMessage());

		}

	}

	// Anand P

	public void verifyMyTasksTitle() {

		try {
			setTimeOut(3000);
			waitForPageLoaded();
			scrollToElement(eleMyTaskTitle);
			waitAndVerifyElement(eleMyTaskTitle);
			LoggingInfo("MyTasks card verified successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to My Tasks title " + e.getMessage());
			Assert.fail("Failed to My Tasks title  " + ". Error - " + e.getMessage());

		}

	}

	// Anand P

	public void clickOutreachAttemptChebox() {

		try {
			By eleAttempt = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Attempt Outreach for Consents?\"]//parent::label//parent::div//following-sibling::div//span[contains(@class,\"checkbox\")]");
			scrollToElement(eleAttempt);
			waitAndVerifyElement(eleAttempt);
			clickByJavascript(eleAttempt);
			LoggingInfo("Clicked on checkbox");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click " + e.getMessage());
			Assert.fail("Failed to click  " + ". Error - " + e.getMessage());

		}

	}

	// Anand P
	public void verifyOtherCards() {

		String[] cards = { "Patient Information", "HCP Information", "Medical/Coverage Information" };

		try {
			for (String card : cards) {
				By cardElement = getDynamicElement(strBVStatus, card);
				setTimeOut(4000);
				scrollToElement(cardElement);
				waitAndVerifyElement(cardElement);
				LoggingInfo("Successfully Verified Card " + card);
			}

			setTimeOut(4000);
			scrollToElement(hcoCard);
			waitAndVerifyElement(hcoCard);
			LoggingInfo("Successfully Verified HCO Card ");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify others cards  " + e.getMessage());
			Assert.fail("Failed to verify others cards  " + ". Error - " + e.getMessage());
		}
	}

	// Anand P
	public void verifySectionNotVisible() {
		try {
			setTimeOut(2000);
			WebElement section1 = getWebDriver().findElement(By.xpath("//*[contains(text(),'Caregiver Information')]"));
			Assert.assertFalse(section1.isDisplayed(), "Caregiver Information section should not be visible");
			setTimeOut(2000);
			WebElement section2 = getWebDriver().findElement(By.xpath("//span[text()='Office Contact Information']"));
			Assert.assertFalse(section2.isDisplayed(), "Office Contact Information Section should not be visible");

		} catch (Exception e) {
			e.printStackTrace();
			LoggingInfo("Validated Caregiver Information and Office contact Information not visible as expected");
		}

	}

	// Anand P
	public void validateNewFieldsInPatienInfo(String email, String caregiver, String relationship) {
		String[] newFields = { "Email Address", "Relationship", "Caregiver" };

		try {
			for (String field : newFields) {
				By fieldelement = getDynamicElement(newEleFields, field);
				setTimeOut(2000);
				scrollToElement(fieldelement);
				waitAndVerifyElement(fieldelement);
				LoggingInfo("Successfully Verified new field " + field + " in Patient Information Section ");
			}

			// Email Address
			By fieldEmailText = getDynamicElement(patientCardFields, "Email Address");
			setTimeOut(5000);
			String emailText = getText(fieldEmailText);
			Assert.assertEquals(emailText, email, "Email matched as per input data");
			LoggingInfo("Successfully Verified text in email field as " + emailText);

			// Caregiver
			By fieldCaregiverText = getDynamicElement(patientCardFields, "Caregiver");
			setTimeOut(2000);
			String caregiverText = getText(fieldCaregiverText);
			Assert.assertEquals(caregiverText, caregiver, "caregiver details matched as per input data");
			LoggingInfo("Successfully Verified text in caregiver field as " + caregiverText);

			// "Relationship"
			By fieldRelationshipText = getDynamicElement(patientCardFields, "Relationship");
			setTimeOut(2000);
			String relationText = getText(fieldRelationshipText);
			String expectedrelationship = "Patient-" + relationship;
			Assert.assertEquals(relationText, expectedrelationship, "Relationship details matched as per input data");
			LoggingInfo("Successfully Verified text in relationship filed as " + relationText);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate New fields in Patient information section  " + e.getMessage());
			Assert.fail("Failed to validate New fields in Patient information section" + ". Error - " + e.getMessage());
		}

	}

	// Anand P

	public void validateNewFieldsInHCOInfo(String officeContact, String officeEmail) {
		String[] newHCOFields = { "HCO Type", "Office Contact Name", "Office Contact Email" };

		try {
			for (String field : newHCOFields) {
				By fieldelement = getDynamicElement(newEleFields, field);
				setTimeOut(2000);
				scrollToElement(fieldelement);
				waitAndVerifyElement(fieldelement);
				LoggingInfo("Successfully Verified new field " + field + " in HCO Information Section ");
			}

			// Office Contact Email
			By contact = getDynamicElement(patientCardFields, "Office Contact Name");
			setTimeOut(2000);
			scrollToElement(contact);
			String contactText = getText(contact);
			Assert.assertEquals(contactText, officeContact, "Office Contact Name matched as per input data");
			LoggingInfo("Successfully Verified text office contact name field as " + contactText);

			// Office Contact Email
			By contactEmail = getDynamicElement(patientCardFields, "Office Contact Email");
			setTimeOut(2000);
			String emailText = getText(contactEmail);
			Assert.assertEquals(emailText, officeEmail, "Office Contact Email matched as per input data");
			LoggingInfo("Successfully Verified text in office Email field as " + emailText);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate New fields in HCO information section  " + e.getMessage());
			Assert.fail("Failed to validate New fields in HCO information section" + ". Error - " + e.getMessage());
		}

	}

	// Anand P

	public void validateMedicalCoverageSectionFields(String expectedSPName, String diagonsis, String expectedMedication,
			String payer, String planType, String outcome) {
		String[] fieldsMedicalSection = { "Copay Consent on file?", "Email Consent on file?", "Specialty Pharmacy",
				"Diagnosis", "Medication Name", "Primary Payer Name", "Primary Member Plan Type", "Member Number",
				"BV Outcome", "PA Outcome" };
		try {
			LoggingInfo("Navigate and verify Medical/Coverage section");
			By eleMed = getDynamicElement(strBVStatus, "Medical/Coverage Information");
			scrollToElement(eleMed);
			waitAndVerifyElement(eleMed);
			LoggingInfo("Verified Medical/Coverage section title");

			for (String field : fieldsMedicalSection) {
				By fieldelement = getDynamicElement(newEleFields, field);
				setTimeOut(2000);
				scrollToElement(fieldelement);
				waitAndVerifyElement(fieldelement);
				LoggingInfo("Successfully Verified new field " + field + " in Medical/Coverage Section ");
			}

			String[] fieldsMedical = { "Diagnosis", "Medication Name", "Primary Payer Name", "Primary Member Plan Type",
					"BV Outcome" };
			String[] fieldMedicalText = { diagonsis, expectedMedication, payer, planType, outcome };

			// Specialty Pharmacy
			By spName = getDynamicElement(patientCardFields, "Specialty Pharmacy");
			setTimeOut(2000);
			String spNameText = getText(spName);
			if (spNameText.contains(expectedSPName)) {
				Assert.assertTrue(true);
				LoggingInfo("Successfully Verified text in Specialty Pharmacy field as " + expectedSPName);
			} else {
				Assert.assertFalse(false, "Specialty Pharmacy does not match");
			}

			for (int i = 0; i < fieldsMedical.length; i++) {
				String fieldLabel = fieldsMedical[i];
				By fieldName = getDynamicElement(patientCardFields, fieldLabel);
				setTimeOut(2000);
				scrollToElement(fieldName);
				String fieldText = getText(fieldName);
				Assert.assertEquals(fieldText, fieldMedicalText[i], "Field text matched as per input data");
				LoggingInfo("Successfully Verified field text " + fieldText);
			}

		} catch (

		Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate New fields in Medical/Coverage section  " + e.getMessage());
			Assert.fail("Failed to validate New fields in Medical/Coverage section" + ". Error - " + e.getMessage());

		}

	}

	// Anand P
	public void validatePatienConsentOnfile() {
		try {
			LoggingInfo("Navigate and verify Medical/Coverage section");
			By eleMed = getDynamicElement(strBVStatus, "Medical/Coverage Information");
			scrollToElement(eleMed);
			waitAndVerifyElement(eleMed);
			LoggingInfo("Verified Medical/Coverage section title");

			By elePatientConsent = getDynamicElement(newEleFields, "Patient Consent on file?");
			setTimeOut(2000);
			scrollToElement(elePatientConsent);
			waitAndVerifyElement(elePatientConsent);
			LoggingInfo("Successfully Verified field patient consent on file present in Medical/Coverage Section ");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate patient consent on file  " + e.getMessage());
			Assert.fail("Failed to validate patient consent on file" + ". Error - " + e.getMessage());
		}
	}

	// Anand P
	public void validateNewHCPFields() {

		try {
			LoggingInfo("Navigate and verify HCP section");
			By eleHCP = getDynamicElement(strBVStatus, "HCP Information");
			scrollToElement(eleHCP);
			waitAndVerifyElement(eleHCP);
			LoggingInfo("Verified HCP Information section title");

			By eleHCPName = getDynamicElement(newEleFields, "HCP Name");
			setTimeOut(2000);
			scrollToElement(eleHCPName);
			waitAndVerifyElement(eleHCPName);
			LoggingInfo("Successfully Verified field HCP Name present in HCP Information Section ");

			By eleHCPType = getDynamicElement(newEleFields, "HCP Type");
			setTimeOut(2000);
			scrollToElement(eleHCPType);
			waitAndVerifyElement(eleHCPType);
			LoggingInfo("Successfully Verified field HCP Type present in HCP Information Section ");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate HCP Information details  " + e.getMessage());
			Assert.fail("Failed to validate  HCP Information details" + ". Error - " + e.getMessage());
		}

	}

	public void verifyBVCaptureState() {

		try {
			setTimeOut(2000);
			By eleBVCapture = getDynamicElement(strBVStatus, "BV Capture");
			clickByJavascript(eleBVCapture);
			setTimeOut(2000);
			waitAndVerifyElement(eleReviewandFinalizeBenefit);
			scrollToElement(eleBVCapture);
			click(eleReviewandFinalizeBenefit);
			setTimeOut(3000);
			waitAndVerifyElement(eleBVCaptureStatus);

			LoggingInfo("verified ‘Review and Finalize Benefit’  section and is in Not Started state initially");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify ‘Review and Finalize Benefit’  section and its initially state  "
					+ e.getMessage());
			Assert.fail("Failed to verify ‘Review and Finalize Benefit’  section and its initially state" + ". Error - "
					+ e.getMessage());

		}

	}

	public void verifyMemberPlanSection(String pharmacypayerName, String medicalPayerName) {

		try {
			setTimeOut(2000);
			By elepharmacypayerName = getDynamicElement(strMemberPlans, pharmacypayerName);
			scrollToElement(elepharmacypayerName);
			waitAndVerifyElement(elepharmacypayerName);
			LoggingInfo("verified Pharmacy Payer Name Field");
			setTimeOut(1000);
			By elemedicalPayerName = getDynamicElement(strMemberPlans, medicalPayerName);
			waitAndVerifyElement(elemedicalPayerName);
			LoggingInfo("verified Medical Payer Name Field");
			setTimeOut(1000);
			LoggingInfo("verified Member Plan section Fields");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Member Plan section Fields " + e.getMessage());
			Assert.fail("Failed to verify Member Plan section Fields" + ". Error - " + e.getMessage());

		}

	}

	// Anand P

	public void checkActiveMemberPlan(String memberPlan) {
		try {
			LoggingInfo("Validate Only active member plan is present");
			WebElement pharmacyCheckBox = getWebDriver().findElement(By.xpath(
					"//[contains(@class,\"active lafPageHost\")]//span[contains(text(),memberPlan)]//ancestor::div[contains(@class,\"slds-checkbox\")]//input"));
			Assert.assertFalse(pharmacyCheckBox.isDisplayed(), "Pharmacy Checkbox should not be present on the page.");

		} catch (Exception e) {
			LoggingInfo("Validated Only active member plan is present");

		}
	}

	public void verifyMedicalRecord(String medicalPayer, String groupNumber, String memberNumber,
			String policyHolderDOB, String insuranceAddDate, String planID) {

		try {
			setTimeOut(2000);

			checkStateOfMemeberPlan("TestAutomation Payer Medical");

			By elemedicalPayerName = getDynamicElement(strTextBoxesInput, "Payer");
			waitAndVerifyElement(elemedicalPayerName);
			// verifyHardAssertInputFieldBox(elemedicalPayerName,medicalPayer,"Payer Name");
			LoggingInfo("verified Medical Payer Name Field");
			// setTimeOut(2000);
			By elegroupNumber = getDynamicElement(strTextBoxesInput, "Group Number");
			waitAndVerifyElement(elegroupNumber);
			// verifyHardAssertInputFieldBox(elegroupNumber,groupNumber,"Group Number");
			LoggingInfo("verified Group Number");
			setTimeOut(2000);
			By eleMemberNumber = getDynamicElement(strTextBoxesInput, "Member Number");
			waitAndVerifyElement(eleMemberNumber);
			// verifyHardAssertInputFieldBox(eleMemberNumber, memberNumber, "Medical Policy
			// ID");
			setTimeOut(4000);

			// Data input

			By elePolicyHolderDOB = getDynamicElement(strPriorAuthDateField, "Policyholder DOB");
			waitAndVerifyElement(elePolicyHolderDOB);
			click(elePolicyHolderDOB);
			inputText(elePolicyHolderDOB, policyHolderDOB);

			By elePlanType = getDynamicElement(strCoverageBenefitFieldsText, "Plan Type");
			By elePharmacyDeductiblelist = getDynamicElement(strCoverageBenefitFieldList, "Plan Type");
			click(elePlanType);
			selectItemFromList(elePlanType, elePharmacyDeductiblelist, "Private Commercial", "Plan Type");
			LoggingInfo("verified Plan Type ");

			By eleInsuranceAddDate = getDynamicElement(strPriorAuthDateField, "Insurance Add Date");
			waitAndVerifyElement(eleInsuranceAddDate);
			click(eleInsuranceAddDate);
			inputText(eleInsuranceAddDate, insuranceAddDate);

			By elePlanId = getDynamicElement(strTextBoxesInput, "Plan ID");
			waitAndVerifyElement(elePlanId);
			click(elePlanId);
			inputText(elePlanId, planID);

			waitAndVerifyElement(eleMedicalSave);
			click(eleMedicalSave);
			setTimeOut(3000);

			LoggingInfo("verified Medical Record section Fields");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Medical Record section Fields " + e.getMessage());
			Assert.fail("Failed to verify Medical Record   section Fields" + ". Error - " + e.getMessage());

		}

	}

	public void verifyPharmacyRecord(String payerName, String rxBIN, String rxPCN, String policyHolderDOB,
			String insuranceAddDate, String planID) {

		try {
			setTimeOut(3000);
			checkStateOfMemeberPlan("TestAutomation Payer Pharmacy");

			By elepayerName = getDynamicElement(strTextBoxesInput, "Payer");
			waitAndVerifyElement(elepayerName);
			verifyHardAssertInputFieldBox(elepayerName, payerName, "Rx Payer Name");
			LoggingInfo("verified Rx Payer Name Field");
			setTimeOut(2000);

			By eleName = getDynamicElement(strTextBoxesInput, "Name");
			waitAndVerifyElement(eleName);
			LoggingInfo("verified Name Field");
			setTimeOut(2000);

			By eleRxBIN = getDynamicElement(strTextBoxesInput, "Rx BIN #");
			waitAndVerifyElement(eleRxBIN);
			verifyHardAssertInputFieldBox(eleRxBIN, rxBIN, "Rx BIN");
			LoggingInfo("verified Rx BIN Field");
			setTimeOut(2000);

			By eleRxPCN = getDynamicElement(strTextBoxesInput, "Rx PCN #");
			waitAndVerifyElement(eleRxPCN);
			scrollToElement(eleRxPCN);
			verifyHardAssertInputFieldBox(eleRxPCN, rxPCN, "Rx PCN");
			LoggingInfo("verified Rx PCN Field");
			setTimeOut(2000);

			By elePlanType = getDynamicElement(strCoverageBenefitFieldsText, "Plan Type");
			waitAndVerifyElement(elePlanType);
			scrollToElement(elePlanType);
			By elePharmacyDeductiblelist = getDynamicElement(strCoverageBenefitFieldList, "Plan Type");
			waitAndVerifyElement(elePlanType);
			click(elePlanType);
			selectItemFromList(elePlanType, elePharmacyDeductiblelist, "Private Commercial", "Plan Type");
			LoggingInfo("verified Plan Type");
			setTimeOut(3000);

			waitAndVerifyElement(elePharmacySave);
			scrollToElement(elePharmacySave);
			click(elePharmacySave);
			setTimeOut(3000);
			LoggingInfo("verified Pharmacy Record section Fields");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Pharmacy Record section Fields " + e.getMessage());
			Assert.fail("Failed to verify Pharmacy Record  section Fields" + ". Error - " + e.getMessage());

		}

	}

	public void verifyMemberPlan() {

		try {
			LoggingInfo("verify to select Member Plan section option");
			setTimeOut(1000);
			scrollToElement(eleMemberPlan);
			waitAndVerifyElement(eleMemberPlan);
			click(eleMemberPlan);
			setTimeOut(2000);
			Actions actMemberPlan = new Actions(getWebDriver());
			actMemberPlan.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
			setTimeOut(1000);
			LoggingInfo("Verified to select Member plan");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Medical Record section Fields " + e.getMessage());
			Assert.fail("Failed to verify Medical Record   section Fields" + ". Error - " + e.getMessage());

		}

	}

	public void enterCoverageBenefitMandatoryFields() {

		try {
			setTimeOut(3000);

			// waitAndVerifyElement(eleCoverageBenefitName);
			// inputText(eleCoverageBenefitName, "Autotest");
			// LoggingInfo("verified coverage benefit Name ");
			setTimeOut(3000);

			By eleCoverageStatus = getDynamicElement(strCoverageBenefitFieldsText, "Coverage Status");
			scrollToElement(eleCoverageStatus);
			click(eleCoverageStatus);
			By eleCoverageStatuslist = getDynamicElement(strCoverageBenefitFieldList, "Coverage Status");
			selectItemFromList(eleCoverageStatus, eleCoverageStatuslist, "Covered", "Coverage Status");
			setTimeOut(2000);

			By elePharmacyDeductible = getDynamicElement(strCoverageBenefitFieldsText, "* Pharmacy Deductible");
			waitAndVerifyElement(elePharmacyDeductible);
			scrollToElement(elePharmacyDeductible);
			click(elePharmacyDeductible);
			By elePharmacyDeductiblelist = getDynamicElement(strCoverageBenefitFieldList, "* Pharmacy Deductible");
			selectItemFromList(elePharmacyDeductible, elePharmacyDeductiblelist, "Yes", "Pharmacy Deductible");
			LoggingInfo("verified Pharmacy Deductible ");
			setTimeOut(2000);

			// By eleprescriptionServiceID = getDynamicElement(strTextBoxesInput,
			// "Prescription Service ID");
			// scrollToElement(eleprescriptionServiceID);
			// waitAndVerifyElement(eleprescriptionServiceID);
			// int number = 10000 + random.nextInt(999999);
			// String prescriptionServiceID = String.valueOf(number);
			// inputText(eleprescriptionServiceID, prescriptionServiceID);
			// LoggingInfo("verified Prescription service ID");

			// setTimeOut(2000);
			// By eleBenefits = getDynamicElement(strCoverageBenefitFieldsText, "Medical and
			// pharmacy benefits combined?");
			// waitAndVerifyElement(eleBenefits);
			// click(eleBenefits);
			// By eleBenefitslist = getDynamicElement(strCoverageBenefitFieldList,"Medical
			// and pharmacy benefits combined?");
			// setTimeOut(2000);
			// selectItemFromList(eleBenefits, eleBenefitslist, "YES", "Medical and pharmacy
			// benefits combined?");
			// LoggingInfo("verified Medical and pharmacy benefits combined");

			setTimeOut(2000);
			By elepatientHasMedicarePartD = getDynamicElement(strCoverageBenefitFieldsText,
					"* Patient has Medicare Part D? (Y/N)");
			scrollToElement(elepatientHasMedicarePartD);
			waitAndVerifyElement(elepatientHasMedicarePartD);
			click(elepatientHasMedicarePartD);
			By elepatientHasMedicarePartDlist = getDynamicElement(strCoverageBenefitFieldList,
					"* Patient has Medicare Part D? (Y/N)");
			selectItemFromList(elepatientHasMedicarePartD, elepatientHasMedicarePartDlist, "YES",
					"Patient has Medicare Part D? (Y/N)");
			LoggingInfo("verified Patient has medicare part D");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify coverage benefit mandatory fields" + e.getMessage());
			Assert.fail("Failed to verify coverage benefit mandatory fields" + ". Error - " + e.getMessage());

		}

	}

	public void verifyThePARequired(String paOptionYes, String paOptionNo) {

		try {

			LoggingInfo("verify to select PA Required option as  Yes and Prior authorization section is displayed");
			setTimeOut(3000);

			By elePARequired = getDynamicElement(strCoverageBenefitFieldsText, "* PA required?");
			scrollToElement(elePARequired);
			waitAndVerifyElement(elePARequired);
			click(elePARequired);
			By elePARequiredlist = getDynamicElement(strCoverageBenefitFieldList, "* PA required?");
			selectItemFromList(elePARequired, elePARequiredlist, "YES", "PA required?");
			LoggingInfo("verified PA Required");
			LoggingInfo("verified fill coverage benefit mandatory fields ");

			By elePriorAuthorization = getDynamicElement(strSubHeadingText, "Prior Authorization");
			setTimeOut(2000);
			click(elePriorAuthorization);
			// setTimeOut(2000);
			// By elePAOutcome = getDynamicElement(strTextBoxesInput, "PA Outcome");
			// waitAndVerifyElement(elePAOutcome);
			// setTimeOut(4000);

			LoggingInfo("Verified PA Required section ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify PA Required section" + e.getMessage());
			Assert.fail("Failed to verify PA Required section" + ". Error - " + e.getMessage());

		}

	}

	public void verifyNotOnFileDisplayed() {
		LoggingInfo("verify  PA ROutcome option as  Not on File is selected");
		By elePARequiredAndNotOnFile = getDynamicElement(strSubHeadingText, "PA Required & Not on File");
		waitAndVerifyElement(elePARequiredAndNotOnFile);
		setTimeOut(4000);
		LoggingInfo("Verified PA Required Not on File section ");
	}

	public void VerifyPARequiredAndNotonFile(String notOnFile) {

		try {
			LoggingInfo("verify to select PA ROutcome option as  Not on File ");

			setTimeOut(4000);
			By elePAOutcome = getDynamicElement(strCoverageBenefitFieldsText, "* PA Outcome");
			waitAndVerifyElement(elePAOutcome);
			By elePAOutcomelist = getDynamicElement(strCoverageBenefitFieldList, "* PA Outcome");

			click(elePAOutcome);
			selectItemFromList(elePAOutcome, elePAOutcomelist, notOnFile, "PA Outcome");
			setTimeOut(4000);
			By elePARequiredAndNotOnFile = getDynamicElement(strSubHeadingText, "PA Required & Not on File");
			waitAndVerifyElement(elePARequiredAndNotOnFile);
			setTimeOut(4000);

			LoggingInfo("Verified PA Required Not on File section ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify PA Required Not on File" + e.getMessage());
			Assert.fail("Failed to verify PA Required Not on File" + ". Error - " + e.getMessage());

		}

	}

	public void VerifyPARequiredAndSelectedOption(String pAOutcome, String pAOptionSelected) {

		try {
			LoggingInfo("verify to select PA ROutcome option as " + pAOptionSelected);

			setTimeOut(4000);
			By elePAOutcome = getDynamicElement(strCoverageBenefitFieldsText, "* PA Outcome");
			waitAndVerifyElement(elePAOutcome);
			By elePAOutcomelist = getDynamicElement(strCoverageBenefitFieldList, "* PA Outcome");

			click(elePAOutcome);
			selectItemFromList(elePAOutcome, elePAOutcomelist, pAOutcome, "PA Outcome");
			setTimeOut(4000);
			By elePARequiredAndSelectedOption = getDynamicElement(strSubHeadingText, pAOptionSelected);
			waitAndVerifyElement(elePARequiredAndSelectedOption);
			setTimeOut(4000);

			LoggingInfo("Verified " + pAOptionSelected);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + pAOptionSelected + e.getMessage());
			Assert.fail("Failed to verify " + pAOptionSelected + ". Error - " + e.getMessage());

		}

	}

	public void verifySaveButton() {

		try {
			LoggingInfo("verify to Save Button ");
			waitAndVerifyElement(eleSaveButton);
			setTimeOut(3000);
			scrollToElement(eleSaveButton);
			click(eleSaveButton);
			setTimeOut(3000);
			LoggingInfo("Verified Save Button ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Save Button" + e.getMessage());
			Assert.fail("Failed to verify Save Button" + ". Error - " + e.getMessage());

		}

	}

	public void verifyBVTaskcompleted() {
		try {
			setTimeOut(1000);
			By BVCompletion = getDynamicElement(strBVStatus, "Complete");
			waitAndVerifyElement(BVCompletion);
			click(BVCompletion);
			LoggingInfo("BV flow is completed");

		} catch (Exception e) {
			Log.error("Failed to complete BV flow  " + e.getMessage());
			Assert.fail("Failed to complete BV flow  " + e.getMessage());
		}
	}

	public void verifyToClickBVSummarysection() {
		try {
			waitForPageLoaded();
			setTimeOut(3000);
			By eleBVSummary = getDynamicElement(strBVStatus, "BV Summary");
			waitAndVerifyElement(eleBVSummary);
			LoggingInfo("Verified BV Summary section");
			clickByJavascript(eleBVSummary);

		} catch (Exception e) {
			Log.error("Failed to complete BV flow  " + e.getMessage());
			Assert.fail("Failed to complete BV flow  " + e.getMessage());
		}
	}

	public void verifyReviewAndSendSummarySection() {

		try {
			setTimeOut(4000);
			waitAndVerifyElement(eleReviewAndSummaryOfBenefits);
			scrollToElement(eleReviewAndSummaryOfBenefits);
			click(eleReviewAndSummaryOfBenefits);
			setTimeOut(3000);
			waitAndVerifyElement(eleReviewAndSummaryOfBenefitsRequired);
			clickByJavascript(eleReviewAndSummaryOfBenefitsRequired);
			LoggingInfo("Verified BV Review and Summary Benefits section");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify BV Review and send summary section" + e.getMessage());
			Assert.fail("Failed to verify BV Review and send summary section" + ". Error - " + e.getMessage());

		}
	}

	public void verifyToSelectCoveredWithRestrictions(String outcomeOption, String outcomeReasonOption) {

		try {
			setTimeOut(5000);
			By eleOutcome = getDynamicElement(strSearchBarDropdown, "Outcome");
			click(eleOutcome);
			By eleOutcomeDropdown = getDynamicElement(strOutcomeDropdown, "Outcome");
			selectItemFromList(eleOutcome, eleOutcomeDropdown, outcomeOption, "Covered with Restrictions");
			LoggingInfo("Verified to select covered with Restriction option on Outcome field");

			setTimeOut(1000);
			click(eleOutcomeReason);
			selectItemFromDropDown(eleOutcomeReason, eleOutcomeReasonDropdown, outcomeReasonOption);
			LoggingInfo("Verified PA Required option on Outcome Reason field");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Select Covered with Restriction Picklist on Outcome Field" + e.getMessage());
			Assert.fail("Failed to Select Covered with Restriction Picklist on Outcome Field" + ". Error - "
					+ e.getMessage());

		}
	}

	public void verifyToSaveDetails(String outcomeOption, String outcomeReasonOption) {

		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleSaveOutcome1);
			scrollToElement(eleSaveOutcome1);
			click(eleSaveOutcome1);
			setTimeOut(4000);
			LoggingInfo("Verified Save button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to save details" + e.getMessage());
			Assert.fail("Failed to save details" + ". Error - " + e.getMessage());

		}

	}

	public void checkStateOfMemeberPlan(String memberPlan) {
		try {

			By pharmacyChecBox = getDynamicElement(checkBox, memberPlan);
			waitAndVerifyElement(pharmacyChecBox);
			scrollToElement(pharmacyChecBox);
			setTimeOut(3000);
			String checkBoxStatus = getAttributeValue(pharmacyChecBox, "checked");

			if (checkBoxStatus == null) {
				selectCheckbox(pharmacyChecBox, "TRUE", "Pharmacy Checkbox");
				waitAndVerifyElement(showDetails);
				click(showDetails);
				setTimeOut(2000);
			}

		} catch (Exception e) {
			Log.error("Failed to check status of member plan " + e.getMessage());
			Assert.fail("Failed to check status of member plan  " + e.getMessage());
		}
	}

	public void clickOnBV() {
		try {
			waitForPageLoaded();
			setTimeOut(3000);
			By bvButton = getDynamicElement(eleButton, "Benefits Verification");
			waitAndVerifyElement(bvButton);
			scrollToElement(bvButton);
			click(bvButton);
			setTimeOut(5000);
		} catch (Exception e) {
			Log.error("Failed to Click on quick start button " + e.getMessage());
			Assert.fail("Failed to Click on quick start button " + e.getMessage());
		}
	}

	public void verifyToCompleteRecord() {

		try {
			waitForPageLoaded();
			setTimeOut(5000);
			LoggingInfo("verify to Save Button ");
			waitAndVerifyElement(eleCompleteRecord);
			scrollToElement(eleCompleteRecord);
			click(eleCompleteRecord);
			setTimeOut(8000);
			LoggingInfo("Verified to complete record");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Complete Record" + e.getMessage());
			Assert.fail("Failed to verify Complete Record" + ". Error - " + e.getMessage());

		}

	}

	public void verifyHCPPreferredSPIsBlank() {
		try {
			Log.info("Verify HCP Preferred Specialty Pharmacy field");
			By hcpSP = getDynamicElement(strInputBpx, "HCP Preferred Specialty Pharmacy");
			waitAndVerifyElement(hcpSP);
			scrollToElement(hcpSP);
			String hcpName = getAttributeValue(hcpSP, "value");
			Assert.assertEquals(hcpName, "", "HCP Preferred Specialty Pharmacy");
			LoggingInfo("Verified HCP Preferred Specialty Pharmacy is null");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify HCP Preferred Specialty Pharmacy field" + e.getMessage());
			Assert.fail("Failed to verify HCP Preferred Specialty Pharmacy field" + ". Error - " + e.getMessage());

		}
	}

	public void verifyHCPPreferredSP(String sp) {
		try {
			Log.info("Verify HCP Preferred Specialty Pharmacy field");
			By hcpSP = getDynamicElement(strInputBpx, "HCP Preferred Specialty Pharmacy");
			waitAndVerifyElement(hcpSP);
			scrollToElement(hcpSP);
			String hcpName = getAttributeValue(hcpSP, "value");
			Assert.assertEquals(hcpName, sp, "HCP Preferred Specialty Pharmacy");
			LoggingInfo("Verified HCP Preferred Specialty Pharmacy is not null");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify HCP Preferred Specialty Pharmacy field" + e.getMessage());
			Assert.fail("Failed to verify HCP Preferred Specialty Pharmacy field" + ". Error - " + e.getMessage());

		}
	}

	public void verifyPayerPharamcyInfoIsNull() {
		try {
			Log.info("Verify Pharamcy field");
			// Payer Collected Pharmacy 1
			waitAndVerifyElement(elePayerPharamcy1);
			scrollToElement(elePayerPharamcy1);
			verifyDetails(elePayerPharamcy1, "", "Payer Collected Pharmacy 1");

			// Payer Collected Pharmacy 2
			waitAndVerifyElement(elePayerPharamcy2);
			verifyDetails(elePayerPharamcy2, "", "Payer Collected Pharmacy 2");

			// Payer Collected Pharmacy 3
			waitAndVerifyElement(elePayerPharamcy3);
			verifyDetails(elePayerPharamcy3, "", "Payer Collected Pharmacy 3");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Pharamcy field" + e.getMessage());
			Assert.fail("Failed to verify Pharamcy field" + ". Error - " + e.getMessage());

		}
	}

	public void enterPharmacy1Details(String pharmcy1) {
		try {
			Log.info("Enter Pharamcy details");
			// Payer Collected Pharmacy 1
			waitAndVerifyElement(elePayerPharamcy1);
			inputText(elePayerPharamcy1, pharmcy1);

			searchAndSelectPharmcy("iccPayerPharamacySearchIP1", pharmcy1);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select Pharamcy " + e.getMessage());
			Assert.fail("Failed to select Pharamcy" + ". Error - " + e.getMessage());

		}
	}

	public void enterPharmacy2Details(String pharmcy2) {
		try {
			Log.info("Enter Pharamcy details");
			// Payer Collected Pharmacy 2
			waitAndVerifyElement(elePayerPharamcy2);
			inputText(elePayerPharamcy2, pharmcy2);

			searchAndSelectPharmcy("iccPayerPharamacySearchIP2", pharmcy2);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select Pharamcy " + e.getMessage());
			Assert.fail("Failed to select Pharamcy" + ". Error - " + e.getMessage());

		}
	}

	public void enterPharmacy3Details(String pharmcy3) {
		try {
			Log.info("Enter Pharamcy details");
			// Payer Collected Pharmacy 3
			waitAndVerifyElement(elePayerPharamcy3);
			inputText(elePayerPharamcy3, pharmcy3);

			searchAndSelectPharmcy("iccPayerPharamacySearchIP3", pharmcy3);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select Pharamcy " + e.getMessage());
			Assert.fail("Failed to select Pharamcy" + ". Error - " + e.getMessage());

		}
	}

	public void searchAndSelectPharmcy(String omniKey, String pharmacyName) {
		try {

			By pharmcySearchBtn1 = getDynamicElement(strPharmcySearch, omniKey);
			waitAndVerifyElement(pharmcySearchBtn1);
			scrollToElement(pharmcySearchBtn1);
			click(pharmcySearchBtn1);
			setTimeOut(2000);
			By payerRadiobutton = getDynamicElement(payerPharmacy1Select, pharmacyName);
			waitAndVerifyElement(payerRadiobutton);
			scrollToElement(payerRadiobutton);
			click(payerRadiobutton);
			// clickByJavascript(payerRadiobutton);

			LoggingInfo("Selected Pharmacy as- " + pharmacyName);
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select Pharmacy information " + ". Error - " + e.getMessage());
		}
	}

	public void enterCoverageBenefitMandatoryFieldsForQuickStart() {

		try {
			setTimeOut(3000);
			By eleCoverageStatus = getDynamicElement(strCoverageBenefitFieldsText, "Coverage Status");
			click(eleCoverageStatus);
			By eleCoverageStatuslist = getDynamicElement(strCoverageBenefitFieldList, "Coverage Status");
			selectItemFromList(eleCoverageStatus, eleCoverageStatuslist, "Covered", "Coverage Status");
			setTimeOut(2000);
			By elePharmacyDeductible = getDynamicElement(strCoverageBenefitFieldsText, "* Pharmacy Deductible");
			waitAndVerifyElement(elePharmacyDeductible);
			click(elePharmacyDeductible);
			By elePharmacyDeductiblelist = getDynamicElement(strCoverageBenefitFieldList, "* Pharmacy Deductible");
			selectItemFromList(elePharmacyDeductible, elePharmacyDeductiblelist, "Yes", "Pharmacy Deductible");
			LoggingInfo("verified Pharmacy Deductible ");
			setTimeOut(2000);
			By elepatientHasMedicarePartD = getDynamicElement(strCoverageBenefitFieldsText,
					"* Patient has Medicare Part D? (Y/N)");
			scrollToElement(elepatientHasMedicarePartD);
			waitAndVerifyElement(elepatientHasMedicarePartD);
			click(elepatientHasMedicarePartD);
			By elepatientHasMedicarePartDlist = getDynamicElement(strCoverageBenefitFieldList,
					"* Patient has Medicare Part D? (Y/N)");
			selectItemFromList(elepatientHasMedicarePartD, elepatientHasMedicarePartDlist, "NO",
					"Patient has Medicare Part D? (Y/N)");
			LoggingInfo("verified Patient has medicare part D");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify coverage benefit mandatory fields" + e.getMessage());
			Assert.fail("Failed to verify coverage benefit mandatory fields" + ". Error - " + e.getMessage());

		}

	}

	public void checkBVTaskCompletion() {
		try {

			By BVButton = getDynamicElement(eleButton, "Benefits Verification");
			waitAndVerifyElement(BVButton);
			scrollToElement(BVButton);
			click(BVButton);
			setTimeOut(3000);

			By eleTaskButton = getDynamicElement(taskButton, "BV Capture");
			scrollToElement(eleTaskButton);
			click(eleTaskButton);
			LoggingInfo("Clicked on BV Capture task");
			setTimeOut(1000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, "Review and Finalize Benefit");
			waitAndVerifyElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Completed", "Enrollment sub task completed successfully");
			LoggingInfo("BV Capture sub task completed successfully");

			By eleTaskButton2 = getDynamicElement(taskButton, "BV Summary");
			click(eleTaskButton2);
			LoggingInfo("Clicked on BV Summary task");
			setTimeOut(1000);

			By subTaskStatus2 = getDynamicElement(strSubTaskStatus, "Review and Send Summary of Benefits");
			waitAndVerifyElement(subTaskStatus2);
			String statuss = getText(subTaskStatus2);
			// Assert the status of subtask
			Assert.assertEquals(statuss, "Completed", "Enrollment sub task completed successfully");
			LoggingInfo("BV Summary sub task completed successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to check Quick Start Task Complition " + e.getMessage());
			Assert.fail("Failed to check Quick Start Task Complition " + e.getMessage());
		}
	}

	/**
	 * Function: Verify HCP Preferred SP In Benifit Task
	 * 
	 * @author Trupti
	 **/

	public void verifyHCPPreferredSPInBenifitTask(String pharmacy) {
		try {
			Log.info("Verify HCP Preferred Specialty Pharmacy field");
			By hcpSP = getDynamicElement(strInputBpx, "HCP Preferred Specialty Pharmacy");
			waitAndVerifyElement(hcpSP);
			scrollToElement(hcpSP);
			String hcpName = getAttributeValue(hcpSP, "value");
			Assert.assertEquals(hcpName, pharmacy, "HCP Preferred Specialty Pharmacy");
			if (hcpName.isBlank()) {
				LoggingInfo("Verified HCP Preferred Specialty Pharmacy is null");
			} else {
				LoggingInfo("Verified HCP Preferred Specialty Pharmacy is " + hcpName);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify HCP Preferred Specialty Pharmacy field" + e.getMessage());
			Assert.fail("Failed to verify HCP Preferred Specialty Pharmacy field" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Verify HCP Preferred SP In Benifit Task
	 * 
	 * @author Samarth
	 **/

	public void VerifyPARequiredAndPending(String pending) {

		try {
			LoggingInfo("verify to select PA ROutcome option as  Not on File ");

			setTimeOut(4000);
			By elePAOutcome = getDynamicElement(strCoverageBenefitFieldsText, "* PA Outcome");
			waitAndVerifyElement(elePAOutcome);
			By elePAOutcomelist = getDynamicElement(strCoverageBenefitFieldList, "* PA Outcome");

			click(elePAOutcome);
			selectItemFromList(elePAOutcome, elePAOutcomelist, pending, "PA Outcome");
			setTimeOut(4000);

			LoggingInfo("Verified PA Required Not on File section ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify PA Required Not on File" + e.getMessage());
			Assert.fail("Failed to verify PA Required Not on File" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Click on search button of pharamcy1
	 * 
	 * @author Trupti
	 **/
	public void clickOnSearchButton() {
		try {
			By pharmcySearchBtn1 = getDynamicElement(strPharmcySearch, "iccPayerPharamacySearchIP1");
			waitAndVerifyElement(pharmcySearchBtn1);
			scrollToElement(pharmcySearchBtn1);
			click(pharmcySearchBtn1);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on search button" + e.getMessage());
			Assert.fail("Failed to click on search button" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Enter Call Information section
	 * 
	 * @author Trupti zure
	 */
	public void enterCallInformationSection() {

		try {
			By eleCallReferenceNumber = getDynamicElement(strTextBoxesInput, "Call Reference Number");
			waitAndVerifyElement(eleCallReferenceNumber);
			scrollToElement(eleCallReferenceNumber);
			int number = 10000 + random.nextInt(999999);
			String callReferenceNumber = String.valueOf(number);
			inputText(eleCallReferenceNumber, callReferenceNumber);
			LoggingInfo("Entered Call Reference Number Field");
			setTimeOut(2000);

			String payerRepName = fullName;
			By elePayerRepName = getDynamicElement(strTextBoxesInput, "Payer Rep Name");
			waitAndVerifyElement(elePayerRepName);
			inputText(elePayerRepName, payerRepName);
			LoggingInfo("verified Payer Rep Name Field");
			setTimeOut(2000);
			LoggingInfo("verified Call Information section Fields");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Call Information section Fields " + e.getMessage());
			Assert.fail("Failed to verify Call Information section Fields" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Click on Review and finalize benefit link in timeline
	 *
	 * @Author Navita
	 */

	public void clickOnReviewAndFinalizeBenefit() {
		try {
			setTimeOut(2000);
			scrollToElement(reviewAndFinalizeBenefitTimeline);
			click(reviewAndFinalizeBenefitTimeline);
			LoggingInfo("Clicked on Review and finalize benefit");
		} catch (Exception e) {
			Log.error("Failed to click on Review and finalize benefit: " + e.getMessage());
			Assert.fail("Error clicking on Review and finalize benefit " + e.getMessage());
		}
	}

	/**
	 * Function: Enter Call Information section
	 *
	 * @author Navita
	 */
	public String enterCallNoCallInformationSectionBV() {
		String CRNo = "";
		String payername = "";
		try {
			By eleCallReferenceNumber = getDynamicElement(strTextBoxesInput, "Call Reference Number");
			waitAndVerifyElement(eleCallReferenceNumber);
			scrollToElement(eleCallReferenceNumber);
			int number = 10000 + random.nextInt(999999);
			CRNo = String.valueOf(number);
			inputText(eleCallReferenceNumber, CRNo);
			LoggingInfo("Entered Call Reference Number Field");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Call Information section Fields " + e.getMessage());
			Assert.fail("Failed to verify Call Information section Fields" + ". Error - " + e.getMessage());

		}
		return CRNo;
	}

	/**
	 * Function: Enter Call Information section
	 *
	 * @author Navita
	 */
	public String enterPayerNameCallInformationSectionBV() {
		String payername = "";
		try {

			String payerRepName = fullName;
			By elePayerRepName = getDynamicElement(strTextBoxesInput, "Payer Rep Name");
			waitAndVerifyElement(elePayerRepName);
			inputText(elePayerRepName, payerRepName);
			LoggingInfo("verified Payer Rep Name Field");
			setTimeOut(2000);
			LoggingInfo("verified Call Information section Fields");
			payername = payerRepName;

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Call Information section Fields " + e.getMessage());
			Assert.fail("Failed to verify Call Information section Fields" + ". Error - " + e.getMessage());

		}
		return payername;
	}

	// Navita
	public void validateFieldsInReviewAndFinalizeBenefit(String callNo, String payerName) {

		// Email Address
		By callReferenceNo = getDynamicElement(patientCardFields, "Call Reference Number");
		setTimeOut(2000);
		String ActualcallReferenceNo = getText(callReferenceNo);
		Assert.assertEquals(ActualcallReferenceNo, callNo, "call reference number matched as per input data");
		LoggingInfo("Successfully Verified text in email field as " + ActualcallReferenceNo);

		By elepayerName = getDynamicElement(patientCardFields, "Payer Rep name");
		setTimeOut(2000);
		String ActualpayerName = getText(elepayerName);
		Assert.assertEquals(ActualpayerName, payerName, "Payer Rep Name matched as per input data");
		LoggingInfo("Successfully Verified text in Payer Rep Name field as " + ActualpayerName);
	}

	/**
	 * Function: Click on attemptOutreachForConsentsChkbx
	 *
	 * @author Navita J
	 **/

	public void clickOnAttemptOutreachForConsents() {
		try {
			setTimeOut(2000);
			waitAndVerifyElement(attemptOutreachForConsentsChkbx);
			scrollToElement(attemptOutreachForConsentsChkbx);
			click(attemptOutreachForConsentsChkbx);
			setTimeOut(5000);
			LoggingInfo("Clicked on attemptOutreachForConsentsChkbx button");

		} catch (Exception e) {
			Log.error("Failed to click on attemptOutreachForConsentsChkbx  " + e.getMessage());
			Assert.fail("Failed to click on attemptOutreachForConsentsChkbx" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Verify and enter pharmacy details
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyAndEnterPharmacyDetails(String payerName, String patientName, String rxBIN, String insurancePhone,
			String rxPCN, String planType, String rxGroup) {

		try {
			setTimeOut(4000);
			// checkStateOfMemeberPlan(payerName); - only pharmacy member plan will be
			// present as per new change

			// Insurance Type
//			By eleInsuranceField = getDynamicElement(strInputBox, "Insurance Type");
//			waitAndVerifyElement(eleInsuranceField);
//			verifyHardAssertDropDown(eleInsuranceField, "Pharmacy", "Insurance Type");
//			setTimeOut(2000);

			// // Payer
			// By elepayerName = getDynamicElement(strDropDownInputBox, "* Payer");
			// waitAndVerifyElement(elepayerName);
			// verifyHardAssertDropDown(elepayerName, payerName, "Rx Payer Name");
			// setTimeOut(2000);

			// Member
			By eleMemberDropDownBox = getDynamicElement(strDropDownInputBox, "*Policy Card Holder Name");
			waitAndVerifyElement(eleMemberDropDownBox);
			scrollToElement(eleMemberDropDownBox);
			click(eleMemberDropDownBox);
			By eleMemberDropDownOptions = getDynamicElement(searchDropDownOptions, "*Policy Card Holder Name");
			waitAndVerifyElement(eleMemberDropDownOptions);
			setTimeOut(1000);
			selectItemFromList(eleMemberDropDownBox, eleMemberDropDownOptions, patientName, "*Policy Card Holder Name");

			// Rx BIN #
			By eleRxBINInputBox = getDynamicElement(strInputBox, "*Rx BIN #");
			waitAndVerifyElement(eleRxBINInputBox);
			scrollToElement(eleRxBINInputBox);
			verifyHardAssertInputFieldBox(eleRxBINInputBox, rxBIN, "*Rx BIN");
			setTimeOut(2000);

			// Insurance Phone
			By eleInsuranceInputBox = getDynamicElement(strInputBox, "*Insurance Phone");
			waitAndVerifyElement(eleInsuranceInputBox);
			scrollToElement(eleInsuranceInputBox);
			verifyHardAssertInputFieldBox(eleInsuranceInputBox, insurancePhone, "*Insurance Phone");
			setTimeOut(2000);

			// Primary/Secondary/Tertiary
			By elephoneType = getDynamicElement(strInputBox, "Primary/Secondary/Tertiary");
			waitAndVerifyElement(elephoneType);
			verifyHardAssertDropDown(elephoneType, "Primary", "Primary/Secondary/Tertiary");
			setTimeOut(2000);

			// Rx PCN #
			By eleRxPCN = getDynamicElement(strInputBox, "*Rx PCN #");
			waitAndVerifyElement(eleRxPCN);
			scrollToElement(eleRxPCN);
			verifyHardAssertInputFieldBox(eleRxPCN, rxPCN, "*Rx PCN");
			setTimeOut(2000);

			// Group member
			By eleRxPolicyID = getDynamicElement(strInputBox, "*Group Number");
			waitAndVerifyElement(eleRxPolicyID);
			scrollToElement(eleRxPolicyID);
			verifyHardAssertInputFieldBox(eleRxPolicyID, rxGroup, "*Group Number");
			setTimeOut(2000);

			// Plant type
			By elePlanType = getDynamicElement(strDropDownInputBox, "Plan Type");
			waitAndVerifyElement(elePlanType);
			scrollToElement(elePlanType);
			By elePlanTypeOptions = getDynamicElement(strDropDownOptions, "Plan Type");
			waitAndVerifyElement(elePlanType);
			click(elePlanType);
			selectItemFromList(elePlanType, elePlanTypeOptions, planType, "Plan Type");
			setTimeOut(2000);
			LoggingInfo("verified Pharmacy Record section Fields");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify and enter Pharmacy Record section Fields " + e.getMessage());
			Assert.fail("Failed to verify and enter Pharmacy Record  section Fields" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Click on save button on pharmacy section
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnSavePharmacy() {
		try {
			setTimeOut(2000);
			waitAndVerifyElement(elePharmacySave);
			scrollToElement(elePharmacySave);
			click(elePharmacySave);
			setTimeOut(2000);
			LoggingInfo("Clicked on save button");

		} catch (Exception e) {
			Log.error("Failed to click on save pharamcy details " + e.getMessage());
			Assert.fail("Failed to click on save pharamcy details" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Enter mandatory details on coverage benefit section
	 * 
	 * @author Trupti Zure
	 **/
	public void enterMandatoryDetailsOnCoverageBenefit(String coverage, String phramacyDeductible, String madicarePartD,
			String paRequired, String paOutcome) {
		try {

			// Member Plan
			By eleMemberPlanDropDownBox = getDynamicElement(strDropDownInputBox, "* Member Plan");
			waitAndVerifyElement(eleMemberPlanDropDownBox);
			scrollToElement(eleMemberPlanDropDownBox);
			click(eleMemberPlanDropDownBox);
			Actions actMemberPlan = new Actions(getWebDriver());
			actMemberPlan.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
			LoggingInfo("Selected Member plan");
			setTimeOut(1000);

			// * Coverage Status
			By eleCoverageStatus = getDynamicElement(strDropDownInputBox, "* Coverage Status");
			waitAndVerifyElement(eleCoverageStatus);
			scrollToElement(eleCoverageStatus);
			clickByJavascript(eleCoverageStatus);
			By eleCoverageStatusOptions = getDynamicElement(strDropDownOptions, "* Coverage Status");
			waitAndVerifyElement(eleCoverageStatusOptions);
			selectItemFromList(eleCoverageStatus, eleCoverageStatusOptions, coverage, "Coverage Status");
			setTimeOut(1000);

			// Pharmacy Deductible
			By elePharmacyDeductible = getDynamicElement(strDropDownInputBox, "Pharmacy Deductible");
			waitAndVerifyElement(elePharmacyDeductible);
			scrollToElement(elePharmacyDeductible);
			click(elePharmacyDeductible);
			By elePharmacyDeductibleOptions = getDynamicElement(strDropDownOptions, "Pharmacy Deductible");
			waitAndVerifyElement(elePharmacyDeductibleOptions);
			selectItemFromList(elePharmacyDeductible, elePharmacyDeductibleOptions, phramacyDeductible,
					"Pharmacy Deductible");
			setTimeOut(1000);

			// * Patient has Medicare Part D? (Y/N)
			By eleMedicarePartD = getDynamicElement(strDropDownInputBox, "* Patient has Medicare Part D? (Y/N)");
			waitAndVerifyElement(eleMedicarePartD);
			scrollToElement(eleMedicarePartD);
			click(eleMedicarePartD);
			By eleMedicarePartDOptions = getDynamicElement(strDropDownOptions, "* Patient has Medicare Part D? (Y/N)");
			waitAndVerifyElement(eleMedicarePartDOptions);
			selectItemFromList(eleMedicarePartD, eleMedicarePartDOptions, madicarePartD,
					"Patient has Medicare Part D?");
			setTimeOut(1000);

			if (coverage.equals("PA required")) {
				By elePriorAuthorization = getDynamicElement(strSubHeadingText, "Prior Authorization");
				scrollToElement(elePriorAuthorization);
				click(elePriorAuthorization);

				// * PA Outcome
				By elePAOutcome = getDynamicElement(strDropDownInputBox, "* PA Outcome");
				waitAndVerifyElement(elePAOutcome);
				scrollToElement(elePAOutcome);
				click(elePAOutcome);
				By eleelePAOutcome = getDynamicElement(strDropDownOptions, "* PA Outcome");
				waitAndVerifyElement(eleelePAOutcome);
				selectItemFromList(elePAOutcome, eleelePAOutcome, paOutcome, "PA Outcome");
				setTimeOut(1000);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on save pharamcy details " + e.getMessage());
			Assert.fail("Failed to click on save pharamcy details" + ". Error - " + e.getMessage());

		}
	}

	// Anand P
	public void enterPAOutcomeDeniedDetails(String denialReason, String appealNeeded, String appealLevel) {
		try {
			setTimeOut(2000);
			By elePADenied = getDynamicElement(strSubHeadingText, "PA Required & on File as Denied");
			scrollToElement(elePADenied);
			click(elePADenied);

			// Denial reason
			By elePAOutcome = getDynamicElement(strDropDownInputBox, "Reason for Denial");
			waitAndVerifyElement(elePAOutcome);
			scrollToElement(elePAOutcome);
			click(elePAOutcome);
			By eleelePAOutcome = getDynamicElement(strDropDownOptions, "Reason for Denial");
			waitAndVerifyElement(eleelePAOutcome);
			selectItemFromList(elePAOutcome, eleelePAOutcome, denialReason, "Reason for Denial");
			setTimeOut(1000);

//			// Appeal needed
//			By eleAppeal = getDynamicElement(strDropDownInputBox, "Appeal needed?");
//			waitAndVerifyElement(eleAppeal);
//			scrollToElement(eleAppeal);
//			click(eleAppeal);
//			By eleAppealoption = getDynamicElement(strDropDownOptions, "Appeal needed?");
//			waitAndVerifyElement(eleAppealoption);
//			selectItemFromList(eleAppeal, eleAppealoption, appealNeeded, "Appeal needed?");
//			setTimeOut(1000);

			// Level of appeal allowed
			By eleAppealLevel = getDynamicElement(strDropDownInputBox, "Level of Appeal allowed?");
			waitAndVerifyElement(eleAppealLevel);
			scrollToElement(eleAppealLevel);
			click(eleAppealLevel);
			By eleAppealLeveloption = getDynamicElement(strDropDownOptions, "Level of Appeal allowed?");
			waitAndVerifyElement(eleAppealLeveloption);
			selectItemFromList(eleAppealLevel, eleAppealLeveloption, appealLevel, "Level of Appeal allowed?");
			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to enter PA Denied details " + e.getMessage());
			Assert.fail("Failed to enter PA Denied details" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Click on save button of coverage benefit
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnCoverageBenefitSave() {
		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleCoverageBenefit);
			scrollToElement(eleCoverageBenefit);
			click(eleCoverageBenefit);
			setTimeOut(5000);
			LoggingInfo("Clicked on save button");

		} catch (Exception e) {
			Log.error("Failed to click on save coverage benift details " + e.getMessage());
			Assert.fail("Failed to click on save coverage benift" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Click on complete button
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnCompleteButton() {
		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleCompleteButton);
			scrollToElement(eleCompleteButton);
			setTimeOut(2000);
			click(eleCompleteButton);
			setTimeOut(5000);
			LoggingInfo("Clicked on complete button");

		} catch (Exception e) {
			Log.error("Failed to click on complete button " + e.getMessage());
			Assert.fail("Failed to click on complete button" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Enter data in BV outcome section
	 * 
	 * @author Trupti Zure
	 **/

	public void enterDetailsOnBVOutcome(String outcome, String outcomeReason) {
		try {
			// Outcome
			setTimeOut(5000);
			waitForPageLoaded();
			By eleoutcomeDropDownBox = getDynamicElement(strSearchBarDropdown, "Outcome");
			waitAndVerifyElement(eleoutcomeDropDownBox);
			click(eleoutcomeDropDownBox);
			By eleOutComeDropDownOptions = getDynamicElement(searchDropDownOptions, "Outcome");
			waitAndVerifyElement(eleOutComeDropDownOptions);
			selectItemFromList(eleoutcomeDropDownBox, eleOutComeDropDownOptions, outcome, "Outcome");
			setTimeOut(3000);
			if (!outcome.equalsIgnoreCase("Uninsured")) {
				// Outcome Reason
				By eleoutcomeReasonDropDownBox = getDynamicElement(strDropDownInputBox, "Outcome Reason");
				waitAndVerifyElement(eleoutcomeReasonDropDownBox);
				click(eleoutcomeReasonDropDownBox);
				By eleoutcomeReasonDropDownOptions = getDynamicElement(searchDropDownOptions, "Outcome Reason");
				waitAndVerifyElement(eleoutcomeReasonDropDownOptions);
				selectItemFromList(eleoutcomeReasonDropDownBox, eleoutcomeReasonDropDownOptions, outcomeReason,
						"Outcome Reason");
			}
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to enter details on BV outcome " + e.getMessage());
			Assert.fail("Failed to enter details on BV outcome " + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Open section
	 * 
	 * @author Trupti Zure
	 **/

	public void openSection(String sectionName) {
		try {
			By eleSectionName = getDynamicElement(strSection, sectionName);
			waitAndVerifyElement(eleSectionName);
			click(eleSectionName);
			LoggingInfo("Clicked on- " + sectionName);
		} catch (Exception e) {
			Log.error("Failed to enter details on BV outcome " + e.getMessage());
			Assert.fail("Failed to enter details on BV outcome " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Enter data in PA required fields when PA required is pending
	 * 
	 * @author Trupti Zure
	 **/
	public void enterDataInPARequiredPending(String processor, String authorization, String electronicSite,
			String phoneNum, String fax, String pendingReason, String additionalDoc) {

		try {
			// PA/Appeal processor
			inputTextBox("PARequiredPending", "PA/Appeal processor", processor);

			// PA authorization #
			By elepaAutherization = getDynamicElement(strInputBox, "PA authorization #");
			waitAndVerifyElement(elepaAutherization);
			inputText(elepaAutherization, authorization);

			// PA/Appeal electronic site
			inputTextBox("PARequiredPending", "PA/Appeal electronic site", electronicSite);

			// Pending Reason
			By elePendingReason = getDynamicElement(strDropDownInputBox, "Pending Reason");
			waitAndVerifyElement(elePendingReason);
			click(elePendingReason);
			By elePendingReasonOptions = getDynamicElement(strDropDownOptions, "Pending Reason");
			waitAndVerifyElement(elePendingReasonOptions);
			selectItemFromList(elePendingReason, elePendingReasonOptions, pendingReason, "Pending Reason");

			// PA/Appeal processor's phone number
			inputTextWithRobotClass("PARequiredPending", "PA/Appeal processor's phone number", phoneNum);

			// Additional documents req. for PA/Appeal
			selectDropdownOption("PARequiredPending", "Additional documents req. for PA/Appeal", additionalDoc);

			// PA/Appeal processor's phone number
			inputTextWithRobotClass("PARequiredPending", "PA/Appeal processor's fax number", fax);

		} catch (Exception e) {
			Log.error("Failed to enter data in PA Required Pending" + e.getMessage());
			Assert.fail("Failed to enter data in PA Required Pending " + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Select drop down value
	 * 
	 * @author Trupti Zure
	 **/

	public void selectDropdownValue(String label, String value) {
		try {
			By dropDown = getDynamicElement(strDropDownInputBox, label);
			waitAndVerifyElement(dropDown);
			scrollToElement(dropDown);
			click(dropDown);
			By dropDownOptions = getDynamicElement(strDropDownOptions, label);
			waitAndVerifyElement(dropDownOptions);
			selectItemFromList(dropDown, dropDownOptions, value, label);
		} catch (Exception e) {
			Log.error("Failed to select dropdown value " + e.getMessage());
			Assert.fail("Failed to select dropdown value-  " + e.getMessage());
		}
	}

	/**
	 * Function: Input text with omni key
	 * 
	 * @author Trupti Zure
	 **/

	public void inputTextBox(String omnikey, String label, String value) {
		try {
			String xpath = "//*[contains(@class,'active lafPageHost')]//runtime_omnistudio_omniscript-omniscript-block[@data-omni-key=\""
					+ omnikey + "\"]" + "//*[text()=\"" + label
					+ "\"]//parent::label//parent::div//following-sibling::div//input";
			By inputBox = By.xpath(xpath);
			waitAndVerifyElement(inputBox);
			scrollToElement(inputBox);
			inputText(inputBox, value);
			LoggingInfo("Entered value in " + label + ": " + value);
		} catch (Exception e) {
			Log.error("Failed to enter data " + e.getMessage());
			Assert.fail("Failed to enter data " + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Select checkbox with omnikey
	 * 
	 * @author Trupti Zure
	 **/
	public void selectCheckBox(String omnikey, String label, String value) {
		try {
			String xpath = "//*[contains(@class,'active lafPageHost')]//runtime_omnistudio_omniscript-omniscript-block[@data-omni-key=\""
					+ omnikey + "\"]" + "//*[text()=\"" + label
					+ "\"]//parent::label//parent::div//following-sibling::div//input";
			By inputBox = By.xpath(xpath);
			waitAndVerifyElement(inputBox);
			scrollToElement(inputBox);
			inputText(inputBox, value);
			LoggingInfo("Entered value in " + label + ": " + value);
		} catch (Exception e) {
			Log.error("Failed to enter data " + e.getMessage());
			Assert.fail("Failed to enter data " + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Input text using robot class with omnikey
	 * 
	 * @author Trupti Zure
	 **/

	public void inputTextWithRobotClass(String omnikey, String label, String value) {
		try {
			String xpath = "//*[contains(@class,'active lafPageHost')]//runtime_omnistudio_omniscript-omniscript-block[@data-omni-key=\""
					+ omnikey + "\"]" + "//*[text()=\"" + label
					+ "\"]//parent::label//parent::div//following-sibling::div//input";
			By inputBox = By.xpath(xpath);
			waitAndVerifyElement(inputBox);
			scrollToElement(inputBox);
			click(inputBox);
			sendKeysWithRobotClass(value);
			LoggingInfo("Entered value in " + label + ": " + value);
		} catch (Exception e) {
			Log.error("Failed to enter data " + e.getMessage());
			Assert.fail("Failed to enter data " + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Select drop down options with omnikey
	 * 
	 * @author Trupti Zure
	 **/
	public void selectDropdownOption(String omniKey, String label, String option) {
		try {

			String xpath = String.format(
					"//*[contains(@class,'active lafPageHost')]//runtime_omnistudio_omniscript-omniscript-block[@data-omni-key=\"%s\"]//*[text()='%s']//parent::label//parent::div//following-sibling::div//input",
					omniKey, label.replace("'", "&apos;"));
			By dropdown = By.xpath(xpath);
			waitAndVerifyElement(dropdown);
			scrollToElement(dropdown);
			click(dropdown);

			String dropDownOptionsXpath = String.format(
					"//*[contains(@class,'active lafPageHost')]//runtime_omnistudio_omniscript-omniscript-block[@data-omni-key='%s']//*[contains(@class,'slds-combobox')]//*[text()='%s']//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,'option-text')]",
					omniKey, label);
			By dropdownOptions = By.xpath(dropDownOptionsXpath);
			waitAndVerifyElement(dropdownOptions);
			selectItemFromList(dropdown, dropdownOptions, option, label);

		} catch (Exception e) {
			Log.error("Failed to select option:" + e.getMessage());
			Assert.fail("Failed to select option:" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Enter data for PA required fields when PA required in not on file
	 * 
	 * @author Trupti Zure
	 **/
	public void enterDataInPARequiredNotOnFile(String processor, String method, String electronicSite, String channel,
			String phoneNum, String faxedToMDO, String fax, String turnAroundTime, String additionalDoc,
			String paOutcomeChannel) {

		try {
			// PA/Appeal processor
			inputTextBox("PARequiredNotonFile", "PA/Appeal processor", processor);

			// Method for obtaining PA form
			selectDropdownValue("Method for obtaining PA form", method);

			// PA/Appeal electronic site
			inputTextBox("PARequiredNotonFile", "PA/Appeal electronic site", electronicSite);

			// PA appeal submission channel checkbox
			By submissionChannel = getDynamicElement(checkBoxSubmissionChannel, channel);
			waitAndVerifyElement(submissionChannel);
			click(submissionChannel);

			// PA/Appeal processor's phone number
			inputTextWithRobotClass("PARequiredNotonFile", "PA/Appeal processor's phone number", phoneNum);

			// PA form able to faxed to MDO
			selectDropdownValue("PA form able to faxed to MDO", faxedToMDO);

			// PA/Appeal processor's fax number
			inputTextWithRobotClass("PARequiredNotonFile", "PA/Appeal processor's fax number", fax);

			// Payer PA turn-around Time
			inputValue("Payer PA turn-around Time", turnAroundTime);

			// Additional documents req. for PA/Appeal
			selectDropdownOption("PARequiredNotonFile", "Additional documents req. for PA/Appeal", additionalDoc);

			// PA Outcome Channel
			By outcomeChannel = getDynamicElement(checkBoxPAOutcomeChannel, paOutcomeChannel);
			waitAndVerifyElement(outcomeChannel);
			scrollToElement(outcomeChannel);
			click(outcomeChannel);
		} catch (Exception e) {
			Log.error("Failed to enter data in PA Required Pending" + e.getMessage());
			Assert.fail("Failed to enter data in PA Required Pending " + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Input value
	 * 
	 * @author Trupti Zure
	 **/

	public void inputValue(String label, String value) {
		try {
			By input = getDynamicElement(strInputBox, label);
			waitAndVerifyElement(input);
			scrollToElement(input);
			inputText(input, value);
		} catch (Exception e) {
			Log.error("Failed to select dropdown value " + e.getMessage());
			Assert.fail("Failed to select dropdown value-  " + e.getMessage());
		}
	}

	/**
	 * Function: This method Valdiates the pharmacy values for(Pharmacy#1,2,3 and
	 * Specialty Pharmacy in Patient EF) For both Alliance and Non-Alliances SPs
	 * allianceType - pass "Alliance" or "Non-Alliance" pharmacyNo - pass fields
	 * name (like Payer Collected Pharmacy #1,2,3 or Specialty Pharmacy) payerName -
	 * pass the SP name to be searched in the table For Alliance SPs, the search
	 * result should be 1 and for Non-Alliance SPs, it can be more than 1.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void veridyPharmacyValues(String allianceType, String pharmacyNo, String payerName) throws Exception {
		String strPharmacyField = "//c-icc_data-table-component[@data-omni-key=\"{0}\"]//tbody//tr";
		String strPharmacyFieldAttri = "//c-icc_data-table-component[@data-omni-key=\"{0}\"]//tbody//tr//td[@data-label=\"Account Name\"]";

		By elePayerSearchInput = null;
		By eleSearchBtn = null;
		String SearchTableComponentKey = null;
		if (pharmacyNo.contains("Payer Collected Pharmacy #1")) {
			elePayerSearchInput = getDynamicElement(strPayerSearch, "iccPayerPharmacy1");
			eleSearchBtn = getDynamicElement(strPharmcySearch, "iccPayerPharamacySearchIP1");
			SearchTableComponentKey = "iccSPAccountSearchComponent";

		} else if (pharmacyNo.contains("Payer Collected Pharmacy #2")) {
			elePayerSearchInput = getDynamicElement(strPayerSearch, "iccPayerPharmacy2");
			eleSearchBtn = getDynamicElement(strPharmcySearch, "iccPayerPharamacySearchIP2");
			SearchTableComponentKey = "iccSPAccountSearchComponent1";
		} else if (pharmacyNo.contains("Payer Collected Pharmacy #3")) {
			elePayerSearchInput = getDynamicElement(strPayerSearch, "iccPayerPharmacy3");
			eleSearchBtn = getDynamicElement(strPharmcySearch, "iccPayerPharamacySearchIP3");
			SearchTableComponentKey = "iccSPAccountSearchComponent2";
		} else if (pharmacyNo.contains("Specialty Pharmacy")) {
			elePayerSearchInput = getDynamicElement(strPayerSearch, "iccSPName");
			eleSearchBtn = getDynamicElement(strPayerSearch1, "iccSPName");
			SearchTableComponentKey = "iccSPAccountSearchComponent";

		}
		waitAndVerifyElement(elePayerSearchInput);
		scrollToElement(elePayerSearchInput);
		clearInputFieldText(elePayerSearchInput);
		setTimeOut(3000);
		inputText(elePayerSearchInput, payerName);

		waitAndVerifyElement(eleSearchBtn);
		scrollToElement(eleSearchBtn);
		click(eleSearchBtn);

		List<WebElement> ele = getWebDriver().findElements(
				By.xpath("//c-icc_data-table-component[@data-omni-key='" + SearchTableComponentKey + "']//tbody//tr"));
		By eleAttribute = getDynamicElement(strPharmacyFieldAttri, SearchTableComponentKey);

		if (ele.size() == 1) {
			String value = getAttributeValue(eleAttribute, "data-cell-value");
			if (value.contains(payerName)) {
				LoggingInfo(
						"The search results display only the matching record available in the Care Program Specialty Pharmacy Network object for: "
								+ payerName);
				Assert.assertTrue(true,
						"The search results display only the matching record available in the Care Program Specialty Pharmacy Network object ");
			}

		} else if (ele.size() > 1) {
			if (allianceType.equals("Non-Alliance")) {
				for (WebElement element : ele) {
					String value = getAttributeValue(eleAttribute, "data-cell-value");
					if (value.contains(payerName)) {
						LoggingInfo(
								"The matching search results are coming for SPs from Account Specialty Pharmacies for: "
										+ payerName);
						break;
					}
				}
			} else if (allianceType.equals("Alliance")) {
				LoggingInfo(
						"The search results display multiple records available in the Care Program Specialty Pharmacy Network object for: "
								+ payerName);
				Assert.fail();
				Assert.assertFalse(false,
						"The search results display multiple records available in the Care Program Specialty Pharmacy Network object");
			}

		} else {
			LoggingInfo(
					"The search results display no records available in the Care Program Specialty Pharmacy Network object for: "
							+ payerName);
			Assert.assertFalse(false,
					"The search results display no records available in the Care Program Specialty Pharmacy Network object for: "
							+ payerName);
		}

	}

	public void validateSSPField() {
		try {
			setTimeOut(2000);

			List<String> expectedPharmacies = Arrays.asList("Teds Village Pharmacy", "Senderra Rx Pharmacy",
					"Optum Pharmacy 705");

			boolean pharmacyFound = false;

			for (String pharmacy : expectedPharmacies) {
				String dynamicXPath = "//*[contains(@class,'active lafPageHost')]//a[.//span[contains(text(),'"
						+ pharmacy + "')]]";
				By pharmacyLocator = By.xpath(dynamicXPath);

				if (isElementPresent(pharmacyLocator)) {
					WebElement pharmacyElement = getWebDriver().findElement(pharmacyLocator);
					// scrollToElement(pharmacyElement);
					String selectedPharmacy = pharmacyElement.getText().trim();
					LoggingInfo("Selected Specialty Pharmacy is: " + selectedPharmacy);
					pharmacyFound = true;
					break;
				}
			}

			if (!pharmacyFound) {
				Assert.fail("None of the expected specialty pharmacies were found in the SSP field.");
			}

		} catch (Exception e) {
			Log.error("Failed to validate Selected Specialty Pharmacy field: " + e.getMessage());
			Assert.fail("Validation failed for SSP field. Error - " + e.getMessage());
		}
	}

	
	public void validateSSPField2() {
		try {
			setTimeOut(2000);

			List<String> expectedPharmacies = Arrays.asList("CVS Specialty Pharmacy", "Amber Specialty Pharmacy",
					"Bioplus Specialty Pharmacy Services, Llc");

			boolean pharmacyFound = false;

			for (String pharmacy : expectedPharmacies) {
				String dynamicXPath = "//*[contains(@class,'active lafPageHost')]//a[.//span[contains(text(),'"
						+ pharmacy + "')]]";
				By pharmacyLocator = By.xpath(dynamicXPath);

				if (isElementPresent(pharmacyLocator)) {
					WebElement pharmacyElement = getWebDriver().findElement(pharmacyLocator);
					// scrollToElement(pharmacyElement);
					String selectedPharmacy = pharmacyElement.getText().trim();
					LoggingInfo("Selected Specialty Pharmacy is: " + selectedPharmacy);
					pharmacyFound = true;
					break;
				}
			}

			if (!pharmacyFound) {
				Assert.fail("None of the expected specialty pharmacies were found in the SSP field.");
			}

		} catch (Exception e) {
			Log.error("Failed to validate Selected Specialty Pharmacy field: " + e.getMessage());
			Assert.fail("Validation failed for SSP field. Error - " + e.getMessage());
		}
	}

	public void checkShowDetailsButton() {
		boolean found;
		try {
			scrollToHalfPage();
			By showDetailsButton = By.xpath(
					"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Show Details\"]//parent::button)[1]");
			found = isElementPresent(showDetailsButton);
			Assert.assertTrue(found, "Show details button is not present");
			LoggingInfo("Show details button is present");

		} catch (Exception e) {
			Log.error("Failed to check status of member plan " + e.getMessage());
			Assert.fail("Failed to check status of member plan  " + e.getMessage());
		}
	}

	/**
	 * Click on PA denied section
	 *
	 * @Author Trupti Zure
	 */

	public void clickOnPADeniedSection() {
		try {
			setTimeOut(2000);
			By elePADenied = getDynamicElement(strSubHeadingText, "PA Required & on File as Denied");
			scrollToElement(elePADenied);
			click(elePADenied);
			LoggingInfo("Clicked on 'PA Required & on File as Denied' section.");
		} catch (Exception e) {
			Log.error("Failed to click on 'PA Required & on File as Denied': " + e.getMessage());
			Assert.fail("Error clicking on 'PA Required & on File as Denied'. Error: " + e.getMessage());
		}
	}

	/**
	 * Click on PA pending section
	 *
	 * @Author Trupti Zure
	 */

	public void clickOnPAPendingSection() {
		try {
			setTimeOut(2000);
			By elePADenied = getDynamicElement(strSubHeadingText, "PA Required & Pending");
			scrollToElement(elePADenied);
			click(elePADenied);
			LoggingInfo("Clicked on 'PA Required & Pending' section.");
		} catch (Exception e) {
			Log.error("Failed to click on 'PA Required & Pending': " + e.getMessage());
			Assert.fail("Error clicking on 'PA Required & Pending'. Error: " + e.getMessage());
		}
	}

	/**
	 * Verifies that a given drop down options are present
	 *
	 * @Author Trupti Zure
	 */

	public void verifyDropdownOptionsArePresent(String fieldLabel, List<String> expectedValues) throws Exception {
		try {
			String dropDown = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input)[3]";
			By elefieldLabel = getDynamicElement(dropDown, fieldLabel);
			waitAndVerifyElement(elefieldLabel);
			scrollToElement(elefieldLabel);
			click(elefieldLabel);

			String optionXpath = "//*[contains(@class,'active lafPageHost')]//*[text()='" + fieldLabel + "']"
					+ "//parent::label//parent::div//following-sibling::div//li";

			List<WebElement> dropdownOptions = getWebDriver().findElements(By.xpath(optionXpath));

			List<String> actualOptions = dropdownOptions.stream().map(WebElement::getText).map(String::trim)
					.collect(Collectors.toList());

			for (String expectedValue : expectedValues) {
				if (!actualOptions.contains(expectedValue)) {
					throw new AssertionError("Expected dropdown value '" + expectedValue + "' is NOT present in field '"
							+ fieldLabel + "'");
				}
				LoggingInfo("PASS: Dropdown value '" + expectedValue + "' is present in '" + fieldLabel + "'");
			}

			click(elefieldLabel);

		} catch (Exception e) {
			LoggingInfo("FAIL: Error while verifying dropdown values for '" + fieldLabel + "': " + e.getMessage());
			throw e;
		}
	}

	/**
	 * Function:Check Attempt Outreach for consents checkbox
	 *
	 * @author Trupti D
	 **/
	public void checkAttemptOutreachforconsents() {
		try {
			setTimeOut(1000);
			scrollToElement(eleattemptOutreachconsents);
			if (verifyElement(eleattemptOutreachconsents)) {
				clickByJavascript(eleattemptOutreachconsents);
				LoggingInfo("Attempt Outreach for consents selected");
			} else {
				LoggingInfo("Attempt Outreach for consents not present");
			}

//			missingInformatioPage.clickNextButton();

		} catch (Exception e) {
			Log.error("Failed to check Attempt Outreach for consents " + e.getMessage());
			Assert.fail("Failed to check Attempt Outreach for consents " + e.getMessage());
		}
	}

	public void verifyCoulumns(List<String> expectedColumns) {

		try {

			WebElement section = getWebDriver().findElement(By
					.xpath("//*[contains(@class,\"active lafPageHost\")]//tr//th[@role=\"columnheader\"]//a//span[2]"));
			JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
			js.executeScript("arguments[0].scrollTop = arguments[0].scrollHeight;", section);

			List<WebElement> labelElements = getWebDriver().findElements(By
					.xpath("//*[contains(@class,\"active lafPageHost\")]//tr//th[@role=\"columnheader\"]//a//span[2]"));

			List<String> actualLabels = new ArrayList<>();
			for (WebElement element : labelElements) {
				String text = element.getText().trim();
				if (!text.isEmpty()) {
					actualLabels.add(text);
				}
			}

			Log.info("Actual column found:");
			actualLabels.forEach(label -> Log.info(" - " + label));

			List<String> missingLabels = new ArrayList<>();

			for (String expected : expectedColumns) {
				boolean found = actualLabels.stream().anyMatch(actual -> actual.equalsIgnoreCase(expected.trim()));
				if (found) {
					Log.info("Found column: " + expected);
				} else {
					Log.info("Missing label: " + expected);
					missingLabels.add(expected);
				}
			}

			if (!missingLabels.isEmpty()) {
				Assert.fail("Missing expected columns: " + missingLabels);
			}

			LoggingInfo("Columns verified ");

		} catch (Exception e) {

			Log.error("Failed to verify columns " + e.getMessage());
			Assert.fail("Failed to verify columns " + e.getMessage());
		}
	}

	public void verifyTaskName(List<String> expectedTaskNames) {
		try {
			By taskelement = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[@data-label=\"Assessment Task Name\"]//lightning-formatted-rich-text//span");

			List<WebElement> taskElements = getWebDriver().findElements(taskelement);

			for (WebElement taskElement : taskElements) {
				String taskName = taskElement.getText().trim();
				if (expectedTaskNames.contains(taskName)) {
					Log.info("Task name verified: " + taskName);
				} else {
					Assert.fail("Unexpected task name found: " + taskName);
				}
			}

			LoggingInfo("Verified all task names successfully.");
		} catch (Exception e) {
			Log.error("Failed to verify task name: " + e.getMessage());
			Assert.fail("Failed to verify task name: " + e.getMessage());
		}
	}

	public void verifyMyAssessmentTaskListView() {
		try {
			Log.info("Verifying navigation to 'My Assessment Task List' view...");
			waitForPageLoaded();

			By myAssessmentTaskListLocator = getDynamicElement(strDocumentPageTitle, "My Assessment Tasks");

			waitAndVerifyElement(myAssessmentTaskListLocator);
			waitForPresenceOfElementLocated(myAssessmentTaskListLocator);

			Log.info("Successfully navigated to 'My Assessment Task List' view.");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify navigation to 'My Assessment Task List'. Error - " + e.getMessage());
		}
	}

	public void navigateToAllPAOrAppealWorklist() {
		try {
			Log.info("Navigate to All PA/Appeal Worklist");
			click(assessmentlistViewButton);

			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, "All PA/Appeal Worklist");
			setTimeOut(3000);

			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

			waitForPageLoaded();
			LoggingInfo("Navigated to All PA/Appeal Worklist");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to All PA/Appeal Worklist: " + e.getMessage());
			Assert.fail("Failed to navigate to All PA/Appeal Worklist: " + e.getMessage());
		}
	}

	public void selectMemberPlan(String patientName) {
		try {
			String label = "*Policy Card Holder Name";

			By eleMemberDropDownBox = getDynamicElement(strDropDownInputBox, label);
			waitAndVerifyElement(eleMemberDropDownBox);
			scrollToElement(eleMemberDropDownBox);
			click(eleMemberDropDownBox);

			By eleMemberDropDownOptions = getDynamicElement(searchDropDownOptions, label);
			waitAndVerifyElement(eleMemberDropDownOptions);

			setTimeOut(1000); // brief wait if needed before selection

			selectItemFromList(eleMemberDropDownBox, eleMemberDropDownOptions, patientName, label);

			Log.info("Successfully selected member plan for patient: " + patientName);

		} catch (Exception e) {
			Log.error("Failed to select member plan for patient '" + patientName + "': " + e.getMessage());
			Assert.fail("Failed to select member plan for patient '" + patientName + "': " + e.getMessage());
		}
	}

}
