package com.sanofi.selenium.constants;

public interface UpdateExcelDataConstants {

	String removeColumnData_TestCase02[] = { "State", "Text Messaging Consent", "Voicemail", "Text",
			"Best Timing AM", "Best Timing Afternoon", "Best Timing PM", "Patient has NO Insurance", "Rx Payer Name",
			"Rx Phone", "Rx Policy ID", "Rx Group", "Rx BIN", "Rx PCN", "Medical Payer Name", "Medical Phone",
			"Medical Policy ID", "Medical Group", "Policyholder Name", "Relationship To Patient",
			"Preferred Specialty Pharmacy", "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax",
			"DUPIXENT MyWay", "Prescriber Name", "Specialty", "Prescriber Address", "Prescriber City",
			"Prescriber State", "Prescriber Zip", "Prescriber NPI", "Site/facility name", "Office Contact Name",
			"Office Contact Email", "Office Phone", "Office Fax", "Tax ID", "Date Of Diagnosis", "Diagnosis Code",
			"Prescriber State License", "Prescription 5A Sample Provided", "Prescription 5A Sample Provided Date",
			"Prescription 5A Prefilled Syringe", "Prescription 5A Prefilled Pen", "Prescription-5A RefillCaptured",
			"Prescription-5A Dose", "Prescription 5A Known Drug Allergies", "Prescription 5A Weight",
			"Prescription 5B Date", "Prescription-B RefillCaptured", "Prescription-5B Dose",
			"Prescription 5B Known Drug Allergies", "Prescription 5B Weight", "Prescriber Signature Date",
			"Substitutions Date", "Collaborating MD Name", "Nurse Practitioner NPI" };

	String removeColumnData_TestCase03[] = { "State", "Legal Representative Name", "Relationship", "Rx Payer Name",
			"Rx Phone", "Rx Policy ID", "Rx Group", "Rx BIN", "Rx PCN", "Medical Payer Name", "Medical Phone",
			"Medical Policy ID", "Medical Group", "Policyholder Name", "Relationship To Patient",
			"Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax", "Office Contact Email", "Office Phone",
			"Tax ID", "Date Of Diagnosis", "Prescriber State License", "Prescription 5A Sample Provided",
			"Prescription 5A Sample Provided Date", "Substitutions Date" };

	String removeColumnData_TestCase04[] = { "Patient Authorization Date", "Patient Certifications Date",
			"Rx Payer Name", "Medical Payer Name", "Specialty Pharmacy Name", "Prescriber Name", "Specialty",
			"Prescriber Address", "Prescriber City", "Prescriber State", "Prescriber Zip", "Prescriber NPI",
			"Site/facility name", "Office Contact Name", "Office Contact Email", "Office Phone", "Office Fax", "Tax ID",
			"Prescriber State License", "Prescription 5A Sample Provided", "Prescription 5A Sample Provided Date",
			"Prescription 5A Prefilled Syringe", "Prescription 5A Prefilled Pen", "Prescription-5A RefillCaptured",
			"Prescription-5A Dose", "Prescription 5A Known Drug Allergies", "Prescription 5A Weight",
			"Prescription 5A Initial And Maintenance Doses", "Prescription 5B Quick Start",
			"Prescription 5B Sample Provided", "Prescription 5B Date", "Prescription 5B Prefilled Syringe",
			"Prescription 5B Prefilled Pen", "Prescription-B RefillCaptured", "Prescription-5B Dose",
			"Prescription 5B Known Drug Allergies", "Prescription 5B Weight",
			"Prescription 5B Initial And Maintenance Doses", "Substitutions Date", "Collaborating MD Name",
			"Nurse Practitioner NPI" };

	String removeColumnData_TestCase05[] = { "Rx Payer Name", "Rx Phone", "Rx Policy ID", "Rx Group", "Rx BIN",
			"Rx PCN", "Medical Payer Name", "Medical Phone", "Medical Policy ID", "Medical Group", "Policyholder Name",
			"Relationship To Patient", "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax", "Prescriber Name",
			"Specialty", "Prescriber Address", "Prescriber City", "Prescriber State", "Prescriber Zip",
			"Prescriber NPI", "Site/facility name", "Office Contact Name", "Office Contact Email", "Office Phone",
			"Office Fax", "Tax ID", "Prescriber State License", "Prescription 5A Sample Provided Date",
			"Prescription-5A RefillCaptured", "Prescription-5A Dose", "Prescription 5A Known Drug Allergies",
			"Prescription 5A Weight", "Prescription 5B Date", "Prescription-B RefillCaptured", "Prescription-5B Dose",
			"Prescription 5B Known Drug Allergies", "Prescription 5B Weight", "Prescriber Signature Date",
			"Substitutions Date", "Collaborating MD Name", "Nurse Practitioner NPI" };

	String removeColumnData_TestCase08[] = { "Rx Payer Name", "Rx Phone", "Rx Policy ID", "Rx Group", "Rx BIN",
			"Rx PCN", "Medical Payer Name", "Medical Phone", "Medical Policy ID", "Medical Group", "Policyholder Name",
			"Relationship To Patient", "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax", "Prescriber Name",
			"Specialty", "Prescriber Address", "Prescriber City", "Prescriber State", "Prescriber Zip",
			"Prescriber NPI", "Site/facility name", "Office Contact Name", "Office Contact Email", "Office Phone",
			"Office Fax", "Tax ID", "Prescriber State License", "Prescription 5A Sample Provided Date",
			"Prescription-5A RefillCaptured", "Prescription-5A Dose", "Prescription 5A Known Drug Allergies",
			"Prescription 5A Weight", "Prescription 5B Date", "Prescription-B RefillCaptured", "Prescription-5B Dose",
			"Prescription 5B Known Drug Allergies", "Prescription 5B Weight", "Prescriber Signature Date",
			"Substitutions Date", "Collaborating MD Name", "Nurse Practitioner NPI" };

	String removeColumnData_Consent[] = { "Patient Authorization Date", "Patient Certifications Date", "Rx Payer Name",
			"Rx Phone", "Rx Policy ID", "Rx Group", "Rx BIN", "Rx PCN", "Medical Payer Name", "Medical Phone",
			"Medical Policy ID", "Medical Group", "Policyholder Name", "Relationship To Patient",
			"Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax", "Office Contact Email", "Office Phone",
			"Tax ID", "Prescriber Signature Date" };

	String removeColumnDataCareProgram[] = { "Patient Authorization Date", "Patient Certifications Date",
			"Rx Payer Name", "Legal Representative Name", "Relationship", "Rx Phone", "Rx Policy ID", "Rx Group",
			"Rx BIN", "Rx PCN", "Medical Payer Name", "Medical Phone", "Medical Policy ID", "Medical Group",
			"Policyholder Name", "Relationship To Patient", "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax",
			"Office Contact Email", "Office Phone", "Tax ID", "Prescriber Signature Date", "Office Contact Name",
			"Office Contact Email", "Office Phone", "Office Fax", "Tax ID", "Date Of Diagnosis", "Diagnosis Code",
			"Prescriber State License", "Prescription 5A Sample Provided Date", "Prescription-5A RefillCaptured",
			"Prescription-5A Dose", "Prescription 5A Known Drug Allergies", "Prescription 5A Weight",
			"Prescription 5B Date", "Prescription-B RefillCaptured", "Prescription-5B Dose",
			"Prescription 5B Known Drug Allergies", "Prescription 5B Weight", "Prescriber Signature Date",
			"Substitutions Date", "Collaborating MD Name", "Nurse Practitioner NPI" };

	String removeColumnDataIAP[] = { "Medical Payer Name", "Medical Phone", "Medical Policy ID", "Medical Group",
			"Policyholder Name", "Relationship To Patient", "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax",
			"Date Of Diagnosis", "Diagnosis Code" };

	String removeColumnData_ConsentPref[] = { "Address", "City", "State", "Zip", "Rx Payer Name", "Rx Phone",
			"Rx Policy ID", "Rx Group", "Rx BIN", "Rx PCN", "Medical Payer Name", "Medical Phone", "Medical Policy ID",
			"Medical Group", "Policyholder Name", "Relationship To Patient", "Specialty Pharmacy Name",
			"Pharmacy Phone", "Pharmacy Fax", "Prescriber Name", "Specialty", "Prescriber Address", "Prescriber City",
			"Prescriber State", "Prescriber Zip", "Prescriber NPI", "Site/facility name", "Office Contact Name",
			"Office Contact Email", "Office Phone", "Office Fax", "Tax ID", "Prescriber State License",
			"Prescription 5A Sample Provided Date", "Prescription-5A RefillCaptured", "Prescription-5A Dose",
			"Prescription 5A Known Drug Allergies", "Prescription 5A Weight", "Prescription 5B Date",
			"Prescription-B RefillCaptured", "Prescription-5B Dose", "Prescription 5B Known Drug Allergies",
			"Prescription 5B Weight", "Prescriber Signature Date", "Substitutions Date", "Collaborating MD Name",
			"Nurse Practitioner NPI" };

	String removeColumnData_MI[] = { "Zip" };

	String removeColumnData_MDFax[] = { "Rx Payer Name", "Rx Phone", "Rx Policy ID", "Rx Group", "Rx BIN", "Rx PCN",
			"Medical Payer Name", "Medical Phone", "Medical Policy ID", "Medical Group", "Policyholder Name",
			"Relationship To Patient", "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax" };

	String removeColumnData_fuzzySearch[] = { "Address", "City", "State", "Patient Secondary phone",
			"Legal Representative Name", "Patient Authorization Date", "Patient Certifications Date", "Rx Payer Name",
			"Medical Payer Name", "Specialty Pharmacy Name", "Prescriber Name", "Specialty", "Prescriber Address",
			"Prescriber City", "Prescriber State", "Prescriber Zip", "Prescriber NPI", "Site/facility name",
			"Office Contact Name", "Office Contact Email", "Office Phone", "Office Fax", "Tax ID",
			"Prescriber State License", "Prescription 5A Sample Provided", "Prescription 5A Sample Provided Date",
			"Prescription 5A Prefilled Syringe", "Prescription 5A Prefilled Pen", "Prescription-5A RefillCaptured",
			"Prescription-5A Dose", "Prescription 5A Known Drug Allergies", "Prescription 5A Weight",
			"Prescription 5A Initial And Maintenance Doses", "Prescription 5B Quick Start",
			"Prescription 5B Sample Provided", "Prescription 5B Date", "Prescription 5B Prefilled Syringe",
			"Prescription 5B Prefilled Pen", "Prescription-B RefillCaptured", "Prescription-5B Dose",
			"Prescription 5B Known Drug Allergies", "Prescription 5B Weight",
			"Prescription 5B Initial And Maintenance Doses", "Substitutions Date", "Collaborating MD Name",
			"Nurse Practitioner NPI" };

	String removeColumnData_MICases[] = { "Patient DOB", "Patient Primary phone", "Patient Secondary phone",
			"Legal Representative Name", "Relationship", "Rx Payer Name", "Rx Phone", "Rx Policy ID", "Rx Group",
			"Rx BIN", "Rx PCN", "Medical Payer Name", "Medical Phone", "Medical Policy ID", "Medical Group",
			"Policyholder Name", "Relationship To Patient", "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax",
			"Prescriber Name", "Specialty", "Prescriber Address", "Prescriber City", "Prescriber State",
			"Prescriber Zip", "Prescriber NPI", "Site/facility name", "Office Contact Name", "Office Contact Email",
			"Office Phone", "Office Fax", "Tax ID", "Date Of Diagnosis", "Diagnosis Code", "Prescriber State License",
			"Prescription 5A Sample Provided", "Prescription 5A Sample Provided Date",
			"Prescription 5A Prefilled Syringe", "Prescription 5A Prefilled Pen", "Prescription-5A RefillCaptured",
			"Prescription-5A Dose", "Prescription 5A Known Drug Allergies", "Prescription 5A Weight",
			"Prescription 5A Initial And Maintenance Doses", "Prescription 5B Quick Start",
			"Prescription 5B Sample Provided", "Prescription 5B Date", "Prescription 5B Prefilled Syringe",
			"Prescription 5B Prefilled Pen", "Prescription-B RefillCaptured", "Prescription-5B Dose",
			"Prescription 5B Known Drug Allergies", "Prescription 5B Weight",
			"Prescription 5B Initial And Maintenance Doses", "Substitutions Date", "Collaborating MD Name",
			"Nurse Practitioner NPI" };

	String removeColumnData_PE[] = { "Legal Representative Name", "Relationship", "Rx Payer Name", "Rx Phone",
			"Rx Policy ID", "Rx Group", "Rx BIN", "Rx PCN", "Medical Payer Name", "Medical Phone", "Medical Policy ID",
			"Medical Group", "Policyholder Name", "Relationship To Patient", "Specialty Pharmacy Name",
			"Pharmacy Phone", "Pharmacy Fax" };

	String removeColumnData_CareTeam[] = { "Legal Representative Name", "Relationship", "Specialty Pharmacy Name",
			"Pharmacy Phone", "Pharmacy Fax", "Prescriber Name", "Specialty", "Prescriber Address", "Prescriber City",
			"Prescriber State", "Prescriber Zip", "Prescriber NPI", "Site/facility name", "Office Contact Name",
			"Office Contact Email", "Office Phone", "Office Fax", "Tax ID", "Substitutions Date",
			"Collaborating MD Name", "Nurse Practitioner NPI" };

	String removeColumnData_adminSetup[] = { "Legal Representative Name", "Relationship", "Rx Payer Name", "Rx Phone",
			"Rx Policy ID", "Rx Group", "Rx BIN", "Rx PCN", "Medical Payer Name", "Medical Phone", "Medical Policy ID",
			"Medical Group", "Policyholder Name", "Relationship To Patient", "Prescriber Name", "Specialty", "Prescriber Address", "Prescriber City",
			"Prescriber State", "Prescriber Name", "Specialty", "Prescriber Address", "Prescriber City", "Prescriber State",
			"Prescriber Zip", "Prescriber NPI", "Site/facility name", "Office Contact Name", "Office Contact Email",
			"Office Phone", "Office Fax", "Tax ID", "Date Of Diagnosis", "Diagnosis Code", "Prescriber State License",
			"Prescription 5A Sample Provided", "Prescription 5A Sample Provided Date",
			"Prescription 5A Prefilled Syringe", "Prescription 5A Prefilled Pen", "Prescription-5A RefillCaptured",
			"Prescription-5A Dose", "Prescription 5A Known Drug Allergies", "Prescription 5A Weight",
			"Prescription 5A Initial And Maintenance Doses", "Prescription 5B Quick Start",
			"Prescription 5B Sample Provided", "Prescription 5B Date", "Prescription 5B Prefilled Syringe",
			"Prescription 5B Prefilled Pen", "Prescription-B RefillCaptured", "Prescription-5B Dose",
			"Prescription 5B Known Drug Allergies", "Prescription 5B Weight",
			"Prescription 5B Initial And Maintenance Doses", "Substitutions Date", "Collaborating MD Name",
			"Nurse Practitioner NPI"};
	
	String removeColumnData_adminSetup2[] = { "Legal Representative Name", "Relationship", "Rx Payer Name", "Rx Phone",
			"Rx Policy ID", "Rx Group", "Rx BIN", "Rx PCN", "Medical Payer Name", "Medical Phone", "Medical Policy ID",
			"Medical Group", "Policyholder Name", "Relationship To Patient","Site/facility name", "Office Contact Name", "Office Contact Email",
			"Office Phone", "Office Fax", "Tax ID", "Date Of Diagnosis", "Diagnosis Code", "Prescriber State License",
			"Prescription 5A Sample Provided", "Prescription 5A Sample Provided Date",
			"Prescription 5A Prefilled Syringe", "Prescription 5A Prefilled Pen", "Prescription-5A RefillCaptured",
			"Prescription-5A Dose", "Prescription 5A Known Drug Allergies", "Prescription 5A Weight",
			"Prescription 5A Initial And Maintenance Doses", "Prescription 5B Quick Start",
			"Prescription 5B Sample Provided", "Prescription 5B Date", "Prescription 5B Prefilled Syringe",
			"Prescription 5B Prefilled Pen", "Prescription-B RefillCaptured", "Prescription-5B Dose",
			"Prescription 5B Known Drug Allergies", "Prescription 5B Weight",
			"Prescription 5B Initial And Maintenance Doses", "Substitutions Date", "Collaborating MD Name",
			"Nurse Practitioner NPI"};
}
