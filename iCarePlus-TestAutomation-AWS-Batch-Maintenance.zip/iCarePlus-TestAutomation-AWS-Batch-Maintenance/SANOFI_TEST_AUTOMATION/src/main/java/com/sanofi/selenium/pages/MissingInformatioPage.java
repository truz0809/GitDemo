package com.sanofi.selenium.pages;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;

import com.sanofi.selenium.constants.TestData;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class MissingInformatioPage extends Utility_Function implements TestData {

	Random random = new Random();
	String fieldName, status, careProgramMI, subject, category, patientJourney, accountName, channel, collectedDate;

	public MissingInformatioPage(WebDriver driver) {
		super(driver);
	}

	/************************
	 * Elements
	 **************************************************/
	public static By eleNameList = By.xpath("//*[@data-label=\"Name\"]//a");
	public static By miRecords = By.xpath(
			"//div[contains(@class,\"searchScroller\")]//table[contains(@class,\"forceRecordLayout\")]//td//a[contains(@class,\"outputLookupLink\")]");
	public static By searchDocInput = By.xpath("//*[@placeholder=\"Search this list...\"]");
	public static By eleCareProgramEnrolleeName = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//slot[@name=\"primaryField\"]//lightning-formatted-text");

	public static By eleNewCaseTitle = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"New Case: Missing Information\"]");
	public static By newCareProgramMIButton = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"test-id\")]//*[text()=\"Care Program MI\"]//following-sibling::div//span[text()=\"New Care Program Missing Information\"]");
	public static By showMoreResultsButton = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Care Program MI\"]//ancestor::div[contains(@class,\"test-id\")]//span[contains(@class,\"slds-truncate\")])[1]");

	public static By saveMIButton = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Save\"]//parent::button)[2]");

	public static By eleAvailableBox = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Available\"]//parent::div");

	public static By eleAvialbleBoxOptions = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Available\"]//parent::div//li//span[@class=\"slds-truncate\"]");
	public static By eleMoveButton = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//button[@title=\"Move selection to Chosen\"]");

	public static By eleAccountName = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Account Name\"]//ancestor::div[contains(@class,\"test-id\")]//li//span[contains(@class,\"slds-media__body\")]");

	public static By eleCaseName = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"fade-text\")]//lightning-formatted-text");
	public static By eleCollectedChennel = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Collected Channel\"]");
	public static By eleCollectedDate = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Collected Date\"]//ancestor::div[contains(@class,\"slds-form\")]//input)[1]");

	public static By eleMissingInfoTable = By.xpath("//*[@aria-label='Open Cases']//tbody//tr");
	public static By eleMissingInfoClosedTable = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Closed Cases\"]//tbody//tr");

	public static By eleActionButton = By.xpath("//*[contains(@class,\"active lafPageHost\")]//tbody//tr//td//button");
	public static By eleEditButton = By.xpath("//a[@title=\"Edit\"]");
	public static By eleEditBtn = By.xpath("//span[text()=\"Show Actions\"]//parent::button");
	public static By eleNavigateToCPE = By.xpath(
			"(//div[contains(@class,\"wsTabset oneConsoleTabset\")]//ul[contains(@class,\"tabBarItems\")]//li//a)[2]");
	public static By eleCareProgramMI = By.xpath("//*[contains(@class,\"active lafPageHost\")]//input");
	public static By activeCell = By.xpath("(//tbody//tr//th//following-sibling::td[@class=\" dataCell  \"])[1]");
	public static By inactiveCell = By.xpath("(//tbody//tr//th//following-sibling::td[@class=\" dataCell  \"])[4]");
	public static By eleCpeTeamMem = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//span[contains(@title, 'Care Program Enrollee Team Members')]");
	public static By eleNewBtnCPE = By.xpath("//button[text()='New']");
	public static By eleMember = By.xpath("//label[text()='Member']");
	public static By eleStartDate = By.xpath("(//input[@name='StartDate_ICC__c'])[1]");
	public static By eleStartTime = By.xpath("(//input[@name='StartDate_ICC__c'])[2]");
	public static By eleSaveBtn = By.xpath("//button[@name='SaveEdit']");
	public static By eleCTM = By.xpath("(//lightning-formatted-text[contains(text(), 'CTM-')])[1]");
	public static By elecareProgramMI = By
			.xpath("//span[text()='Care Program MI']//parent::label//parent::div//following-sibling::div//input");
	public static By eleSaveDetails = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//span[text()=\"Save\"]//parent::button)[2]");
	public static By eleQSTriage = By.xpath("//span[contains(text(), 'QuickStart;SP Triage;')]");
	// //public static By eleClose = By.xpath("(//button[@class='slds-button
	// slds-button_icon slds-button_icon-x-small
	// slds-button_icon-container']//child::lightning-primitive-icon)[2]");
	public static By eleWelcome = By.xpath("//span[text()='Welcome Message']");
	public static By eleIFrame = By.xpath("//iframe[@title='accessibility title']");
	public static By eleOpenStatus = By.xpath("//span[@title='Open']");
	public static By eleOpenCasesLink = By.xpath("//span[@title='Open Cases']//parent::a");
	public static By eleCaseNumber = By.xpath("//span[starts-with(text(), '0123')]");
	public static By eleStatusField = By.xpath("//label[text()='Status']");
	public static By eleErrorMsg = By
			.xpath("//li[text()='Please select respective button to Close/Cancel the MI Case.']");
	public static By eleSelectAll = By.xpath("(//span[text()='Select All']//parent::label)[2]");
	public static By eleBulkClose = By.xpath("//button[text()='Bulk Close']");
	public static By eleClose = By.xpath(
			"(//button[@class='slds-button slds-button_icon slds-button_icon-x-small slds-button_icon-container'])[2]");
	public static By eleSubmit = By.xpath("(//*[text()=\"Submit\"]//parent::button)[1]");
	public static By eleAttemptError = By.xpath("//span[text()='Please select a choice.']");
	public static By eleCancelandClose = By.xpath("//button[@title='Cancel and close']");
	public static By eleStatus = By.xpath("(//span[text()='Status'])[4]");
	public static By eleMIRecord = By
			.xpath("((//*[text()='Subject'])[1]//ancestor::thead//following-sibling::tbody//td[3]//a)[1]");
	public static By eleCancel = By.xpath("//button[text()='Cancel']");
	public static By eleopenStatus = By
			.xpath("//span[text()='Status']//parent::div//parent::dt//following-sibling::dd//*[text()='Open']");
	public static By eleCancelledStatus = By
			.xpath("//span[text()='Status']//parent::div//parent::dt//following-sibling::dd//*[text()='Cancelled']");
	public static By eleCancelMessage = By
			.xpath("//*[text()='Are you sure to Cancel the MI Case, because of Order  Triaged to SP ?']");
	public static By eleeditButton = By.xpath("//button[@title='Edit Status']");
	public static By cpeTab = By.xpath(
			"(//div[contains(@class,\"wsTabset oneConsoleTabset\")]//ul[contains(@class,\"tabBarItems\")]//li//a)[1]");
	public static By eleCloseCorrespondence = By.xpath("//button[@title='Close correspondenceMultiIcc']");
	public static By eleMITableName = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Open Cases\"]");
	public static By eleStatusState = By
			.xpath("//th[@aria-label=\"Status\"]//a//following-sibling::span[@class=\"slds-assistive-text\"]");
	public static By eleCollectedDateState = By.xpath(
			"(//th[@aria-label=\"Collected Date\"]//a//following-sibling::span[@class=\"slds-assistive-text\"])[2]");
	public static By listViewButton = By.xpath("//button[@title=\"Select a List View: Cases\"]");

	/************************
	 * Dynamic Elements
	 **************************************************/
	public static String strRecordName = "//*[contains(@class,\"active lafPageHost\")]//th[@data-label=\"Name\"]//a[contains(@title,\"{0}\")]";
	public static String serachDropDownListBox = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"test-id\")]//*[text()=\"{0}\"]//following-sibling::div//input";
	public static String dropDownNewButton = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"test-id\")]//*[text()=\"{0}\"]//following-sibling::div//span[contains(@title,\"New\")]";
	public static String eleButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";
	public static String pageTitle = "//*[contains(@class,\"active lafPageHost\")]//h2[text()=\"{0}\"]";
	public static String strInputBox = "//*[contains(@class,\"active lafPageHost\")]//label[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strSearchDropDownOptions1 = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"test-id\")]//li//span[contains(@class,\"option-text\")]//lightning-base-combobox-formatted-text";
	public static String strDropDownBox = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"field_textarea\")]//*[text()=\"{0}\"]//parent::div//button";
	public static String strDropDownBoxOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//div[contains(@class,\"slds-listbox\")]//span[@class=\"slds-media__body\"]//span";
	public static String caseRadioButton = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-form\")]//*[text()=\"{0}\"]//parent::label//span[contains(@class,\"slds-radio\")]";
	public static String strHeaderTextFields = "//*[contains(@class,\"active lafPageHost\")]//*[@title=\"{0}\"]//parent::div//child::lightning-formatted-text";
	public static String caseTextDetails = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-text";
	public static String strInformationLinkField = "(//*[text()=\"{0}\"]//parent::div//following-sibling::div//a/span//span)[2]";
	public static String strChannelInformation = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"slds-form-element\")]//lightning-formatted-text";
	public static String strColumnTextData = "//*[contains(@class,\"active lafPageHost\")]//tbody//tr//td[@data-label=\"{0}\"]//lst-formatted-text//span";
	public static String strHeaderTextFeilds = "//*[contains(@class,\"active lafPageHost\")]//*[@name=\"{0}\"]//lightning-formatted-text";
	public static String strCPERecord = "(//div[contains(@class,\"wsTabset oneConsoleTabset\")]//*[contains(@class,\"tabBarItems\")]//*[contains(@title,\"{0}\")])[1]";
	public static String strNewCaseFields = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strNewCaseButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::a";
	public static String strNewCaseCM = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String elestrDropDownBox = "//*[contains(@name,\"{0}\") and @part=\"select\"]";
	public static String elestrDropDownList = "//*[@name=\"{0}\"]//option";
	public static String strMIFields = "//span[text()=\"{0}\" and @class='test-id__field-label']//parent::div//parent::dt//following-sibling::dd//span";

	public static String strDataList = "//*[contains(@class,\"active lafPageHost\")]//ul//li//a[@data-list=\"{0}\"]";
	public static String strLabelName = "//*[contains(@class,\"active lafPageHost\")]//tbody//tr//a//span[text()=\"{0}\"]";
	public static String strCaseFields = "//*[contains(@class,\"active lafPageHost\")]//div//*[text()=\"{0}\"]";

	public static String strAccountName = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strOpenCases = "//span[@title=\"{0}\"]";
	public static String strRelatedTab = "//a[text()=\"{0}\"]";
	public static String strDropDownProgramRole = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]";
	public static String strDropDownMember = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[@title=\"{0}\"]";
	public static String caseType = "//span[text()=\"{0}\"]//preceding-sibling::span";
	public static String caseTypeCM = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]";
	public static String eleField = "//span[text()=\"{0}\"]//parent::lightning-formatted-rich-text";
	public static String strDropDownStatus = "//*[contains(@class,\"active lafPageHost\")]//span[@title=\"{0}\"]";
	public static String strEditBtn = "//button[@name=\"{0}\"]";
	public static By eleProgramRole = By.xpath("//label[text()='Program Role']//following-sibling::div//button");
	public static String strReasonField = "//*[@name=\"{0}\"]";
	public static String strReasondropdown = "//select[@name=\"{0}\"]";
	public static String strAttemptFields = "//span[text()=\"{0}\"]";
	public static String strCancelRadioButton = "//input[@value=\"{0}\"]//parent::span";
	public static String streditdropdown = "//label[text()=\"{0}\"]//following-sibling::div//button";
	public static String streditdropdownlist = "//div[@aria-label=\"{0}\"]//lightning-base-combobox-item";
	public static String eleCaseHistory = "//*[contains(@class,\"active lafPageHost\")]//td[@data-label=\"Field\"]//lst-formatted-text//span[text()=\"{0}\"]";
	public static String eleSelectDropDown = "//*[contains(@class, \"active lafPageHost\")]//select[contains(@name, \"{0}\")]";
	public static String compactLayoutLinkField = "//*[contains(@class,\"active lafPageHost\")]//*[@title=\"{0}\"]//ancestor::records-highlights-details-item[@slot=\"secondaryFields\"]//span[@class=\"slds-truncate\"]//slot";

	/**
	 * Function: Search and open random record
	 * 
	 * @author Trupti Zure
	 **/

	public String searchAndOpenRecord() {
		String name = null;
		try {
			Random random = new Random();
			waitAndVerifyElement(eleNameList);
			List<WebElement> listOptions = getWebDriver().findElements(eleNameList);
			List<String> nameTextList = new ArrayList<>();

			for (int i = 0; i < listOptions.size(); i++) {
				nameTextList.add(listOptions.get(i).getAttribute("title"));
			}

			String[] names = new String[nameTextList.size()];
			for (int j = 0; j < names.length; j++) {
				names[j] = nameTextList.get(j);
			}
			name = names[random.nextInt(names.length)];
			patientJourney = name;
			searchRecord(name);
			setTimeOut(2000);
			LoggingInfo("Search record on care program enrollees list-" + name);
			setTimeOut(2000);
			clickOnRecord(name);
			setTimeOut(2000);
			LoggingInfo("Clicked on record-" + name);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Search record on care program enrollees list " + e.getMessage());
			Assert.fail("Failed to Search record on care program enrollees list " + e.getMessage());
		}
		return name;

	}

	/**
	 * Function: Search record
	 * 
	 * @author Trupti Zure
	 **/

	public void searchRecord(String record) {
		try {
			click(searchDocInput);
			inputText(searchDocInput, record);
			genericKeyPress(searchDocInput, "Enter");
			waitForPageLoaded();
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed search record" + e.getMessage());
			Assert.fail("Failed search record" + e.getMessage());

		}
	}

	/**
	 * Function: validate no opencases
	 * 
	 * @author anand
	 **/

	public void validateNoOpenCases() {
		try {
			By eleOpenCases = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Open Cases\"]");
			scrollToElement(eleOpenCases);
			highLightElement(eleOpenCases);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate" + e.getMessage());
			Assert.fail("Failed " + e.getMessage());

		}
	}

	/**
	 * Function: click on record
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnRecord(String name) {
		try {
			By record = getDynamicElement(strRecordName, name);
			waitAndVerifyElement(record);
			clickByJavascript(record);
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed click on record" + e.getMessage());
			Assert.fail("Failed click on record" + e.getMessage());

		}
	}

	/**
	 * Function: click on new button
	 * 
	 * @author Trupti Zure
	 **/

	public void clickNewButton() {
		try {
			Log.info("Verify user is able to click on new button");
			By eleNewButton = getDynamicElement(eleButton, "New");
			waitAndVerifyElement(eleNewButton);
			scrollToElement(eleNewButton);
			click(eleNewButton);
			setTimeOut(2000);
			LoggingInfo("User clicks on new button");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify and click on new button " + e.getMessage());
			Assert.fail("Failed to verify and click on new button " + e.getMessage());
		}
	}

	/**
	 * Function: Verify CPE record
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyCareProgramEnrollee(String name) {
		try {
			waitForPageLoaded();
			setTimeOut(2000);
			waitAndVerifyElement(eleCareProgramEnrolleeName);
			verifyDetails(eleCareProgramEnrolleeName, name, "Care Progarm Enrolle Record");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify care program enrollee record " + e.getMessage());
			Assert.fail("Failed to verify care program enrollee record " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Missing information page
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyMissingInformationPageTitle() {
		try {
			waitForPageLoaded();
			setTimeOut(2000);
			waitAndVerifyElement(eleNewCaseTitle);
			LoggingInfo("User is able to view New case:Missing information page");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Missing Information Page Title " + e.getMessage());
			Assert.fail("Failed to Missing Information Page Title  " + e.getMessage());
		}
	}

	/**
	 * Function: search Missing Field On MI Layout
	 * 
	 * @author Trupti Zure
	 **/
	public void searchMissingFieldOnMILayout(String careProgramEnrollee) {
		try {
			By careProgramMIDropDown = getDynamicElement(serachDropDownListBox, "Care Program MI");
			waitAndVerifyElement(careProgramMIDropDown);
			click(careProgramMIDropDown);
			LoggingInfo("Clicked on Care Program MI dropdown box");
			String miRecord = careProgramEnrollee.split("- ")[1];
			if (miRecord.equalsIgnoreCase("DMW Prurigo Nodularis"))
				miRecord = "DMW PN";
			else if (miRecord.equalsIgnoreCase("DMW Nasal Polyposis"))
				miRecord = "DMW CRSwNP";
			inputText(careProgramMIDropDown, miRecord);
			setTimeOut(2000);
			waitAndVerifyElement(showMoreResultsButton);
			click(showMoreResultsButton);
			setTimeOut(2000);
			LoggingInfo("Clicked on Show more results button");
			setTimeOut(3000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to search Missing Field On MI Layout " + e.getMessage());
			Assert.fail("Failed to search Missing Field On MI Layout  " + e.getMessage());
		}
	}

	/**
	 * Function: Select Missing Field On MI Layout
	 * 
	 * @author Trupti Zure
	 **/

	public void selectMissingFieldOnMILayout() {
		try {
			Random random = new Random();
			waitAndVerifyElement(miRecords);
			List<WebElement> listOptions = getWebDriver().findElements(miRecords);

			List<String> miNameTextList = new ArrayList<>();

			for (int i = 0; i < listOptions.size(); i++) {
				miNameTextList.add(listOptions.get(i).getAttribute("title"));
			}

			int randomNum = random.nextInt(listOptions.size());
			WebElement randomElement = listOptions.get(randomNum);
			((JavascriptExecutor) getWebDriver()).executeScript(
					"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
					randomElement);
			randomElement.click();
			careProgramMI = miNameTextList.get(randomNum);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select missing information " + e.getMessage());
			Assert.fail("Failed to select missing information  " + e.getMessage());
		}
	}

	/**
	 * Function: Enter MI On MI Layout
	 * 
	 * @author Trupti Zure
	 **/

	public void enterMissingInformation(String careProgramEnrollee) {
		try {

			// Patient Journey
			By patientJourneySearchBox = getDynamicElement(serachDropDownListBox, "Patient Journey");
			waitAndVerifyElement(patientJourneySearchBox);
			scrollToElement(patientJourneySearchBox);
			verifyHardAssertInputFieldBox(patientJourneySearchBox, careProgramEnrollee, "Patient Journey");

			// Account name
			accountName = careProgramEnrollee.split(" -")[0];
			By accountSearchBox = getDynamicElement(serachDropDownListBox, "Account Name");
			waitAndVerifyElement(accountSearchBox);
			click(accountSearchBox);
			inputText(accountSearchBox, accountName);

			waitAndVerifyElement(eleAccountName);
			setTimeOut(2000);
			click(eleAccountName);
			LoggingInfo("Selected Account Name as- " + accountName);
			setTimeOut(3000);

			// Status
			By statusDropDown = getDynamicElement(strDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(4000);
			By statusDropDownList = getDynamicElement(strDropDownBoxOptions, "Status");
			waitAndVerifyElement(statusDropDownList);
			String[] statusOptions = { "Collected", "Not Collected", "Closed" };
			status = statusOptions[random.nextInt(statusOptions.length)];
			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
			System.out.println("Selected Status as- " + status);
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(8000);

			if (status.equalsIgnoreCase("Collected")) {
				// Collected Channel
				By channelDropDown = getDynamicElement(strDropDownBox, "Collected Channel");
				waitAndVerifyElement(channelDropDown);
				scrollToElement(channelDropDown);
				click(channelDropDown);
				setTimeOut(1000);
				By channelDropDownList = getDynamicElement(strDropDownBoxOptions, "Collected Channel");
				waitAndVerifyElement(channelDropDownList);
				String[] channelOptions = { "Phone", "Document" };
				channel = channelOptions[random.nextInt(channelOptions.length)];
				selectItemFromList(channelDropDown, channelDropDownList, channel, "Collected Channel");
				LoggingInfo("Selected Collected Channel as- " + channel);
				setTimeOut(3000);

				// Collected Date

				int year = 2000 + random.nextInt(23);
				int month = 1 + random.nextInt(12);
				int day = 1 + random.nextInt(28);
				collectedDate = String.format("%02d/%02d/%02d", month, day, year);

				waitAndVerifyElement(eleCollectedDate);
				inputText(eleCollectedDate, collectedDate);
				setTimeOut(2000);
				LoggingInfo("Selected collected date as-" + collectedDate);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter New Case: Missing Information " + e.getMessage());
			Assert.fail("Failed to enter New Case: Missing Information  " + e.getMessage());
		}
	}

	/**
	 * Function:Click on save button
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnSaveButton() {
		try {
			Log.info("Verify user is able to click on Save button");
			By eleSaveButton = getDynamicElement(eleButton, "Save");
			scrollToElement(eleSaveButton);
			waitAndVerifyElement(eleSaveButton);
			clickByJavascript(eleSaveButton);
			setTimeOut(7000);
			LoggingInfo("Clicked on Save");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on save button " + e.getMessage());
			Assert.fail("Failed to click on save button  " + e.getMessage());
		}
	}

	/**
	 * Function:Click on Close button
	 * 
	 * @author Anand Pawar
	 **/

	public void clickOnCloseButton() {
		try {
			Log.info("Verify user is able to click on Close button");
			By eleSaveButton = getDynamicElement(eleButton, "Close");
			scrollToElement(eleSaveButton);
			waitAndVerifyElement(eleSaveButton);
			clickByJavascript(eleSaveButton);
			setTimeOut(3000);
			LoggingInfo("Clicked on Close");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on close button " + e.getMessage());
			Assert.fail("Failed to click on close button  " + e.getMessage());
		}
	}

	/**
	 * Function:Verify status and inactivation Reason
	 * 
	 * @author Anand Pawar
	 **/

	public void verifyCPEStatusInactivationReason(String status) {
		try {
			By eleStatus = getDynamicElement(caseTextDetails, "Status");
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			highLightElement(eleStatus);
			String actualStatus = getText(eleStatus);
			Assert.assertEquals(actualStatus, status, "Active Status is Present");
			setTimeOut(2000);

			By eleReason = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Inactivation Reason\"]//parent::div//following-sibling::div//slot[@name=\"outputField\"]");
			scrollToElement(eleReason);
			highLightElement(eleReason);

			LoggingInfo("Verified Status and Inactivation reason");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on close button " + e.getMessage());
			Assert.fail("Failed to click on close button  " + e.getMessage());
		}
	}

	/**
	 * Function: Click on Save & New button
	 * 
	 * @author Anand P
	 **/

	public void clickOnSaveAndNewButton() {
		try {
			Log.info("Verify user is able to click on Save button");
			By eleSaveButton = getDynamicElement(eleButton, "Save & New");
			scrollToElement(eleSaveButton);
			waitAndVerifyElement(eleSaveButton);
			clickByJavascript(eleSaveButton);
			setTimeOut(4000);
			LoggingInfo("Clicked on Save & New Button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Save & New Button " + e.getMessage());
			Assert.fail("Failed to click on Save & New Button  " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate To Member plans tab
	 * 
	 * @author Anand P
	 **/

	public void navigateToMemPlans() {
		try {
			Log.info("Verify user is able navigate to member plans tab");
			By eleSaveButton = By.xpath("//*[text()=\"Member Plans\"]//ancestor::a[@title=\"Member Plans\"]");
			scrollToElement(eleSaveButton);
			waitAndVerifyElement(eleSaveButton);
			clickByJavascript(eleSaveButton);
			setTimeOut(4000);
			LoggingInfo("navigation done");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click  " + e.getMessage());
			Assert.fail("Failed to click   " + e.getMessage());
		}
	}

	/**
	 * Function:Click On Submit button
	 * 
	 * @author Anand Pawar
	 **/
	public void clickOnSubmitButton() {
		try {
			Log.info("Verify user is able to click on Submit button");
			By eleSaveButton = By.xpath("(//*[text()=\"Submit\"]//parent::button)[1]");
			setTimeOut(3000);
			scrollToElement(eleSaveButton);
			waitAndVerifyElement(eleSaveButton);
			clickByJavascript(eleSaveButton);
			setTimeOut(4000);
			LoggingInfo("Clicked on Submit");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on submit button " + e.getMessage());
			Assert.fail("Failed to click on submit button  " + e.getMessage());
		}
	}

	/**
	 * Function:Click On Previous button
	 * 
	 * @author Anand Pawar
	 **/
	public void clickOnPreviousButton() {
		try {
			Log.info("Verify user is able to click on Previous button");
			By eleSaveButton = By.xpath("(//*[text()=\"Previous\"]//parent::button)[1]");
			setTimeOut(3000);
			scrollToElement(eleSaveButton);
			waitAndVerifyElement(eleSaveButton);
			clickByJavascript(eleSaveButton);
			setTimeOut(4000);
			LoggingInfo("Clicked on Previous");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on previous button " + e.getMessage());
			Assert.fail("Failed to click on previous button  " + e.getMessage());
		}
	}

	/**
	 * Function:Click On Cancel button
	 * 
	 * @author Anand Pawar
	 **/
	public void clickOnCancelButton() {
		try {
			Log.info("Verify user is able to click on Cancel button");
			By eleSaveButton = getDynamicElement(eleButton, "Cancel");
			setTimeOut(3000);
			scrollToElement(eleSaveButton);
			waitAndVerifyElement(eleSaveButton);
			clickByJavascript(eleSaveButton);
			setTimeOut(4000);
			LoggingInfo("Clicked on Cancel");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Cancel button " + e.getMessage());
			Assert.fail("Failed to click on Cancel button  " + e.getMessage());
		}
	}

	/**
	 * Function:verify error message
	 * 
	 * @author Anand Pawar
	 **/
	public void verifyErrorStatusNotCollected() {
		try {
			waitForPageLoaded();
			Log.info("Verify user is able to verify error message");
			By eleError = By.xpath(
					"//span[@part=\"formatted-rich-text\"]//p[contains(text(),\"Status\")]//ancestor::lightning-formatted-rich-text[@class=\"slds-rich-text-editor__output\"]");
			waitAndVerifyElement(eleError);
			setTimeOut(3000);
			scrollToElement(eleError);
			highLightElement(eleError);
			setTimeOut(4000);
			LoggingInfo("Verified error message");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
			Assert.fail("Failed to verify " + e.getMessage());
		}
	}

	/**
	 * Function:verify error message
	 * 
	 * @author Anand Pawar
	 **/
	public void verifyErrorStatusCollected() {
		try {
			waitForPageLoaded();
			Log.info("Verify user is able to verify error message");
			By eleError = By.xpath("//span[contains(text(),'Please enter some valid input.')]");
			waitAndVerifyElement(eleError);
			setTimeOut(3000);
			scrollToElement(eleError);
			highLightElement(eleError);
			setTimeOut(4000);
			LoggingInfo("Verified error message");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
			Assert.fail("Failed to verify " + e.getMessage());
		}
	}

	/**
	 * Function:Select new case
	 * 
	 * @author Trupti Zure
	 **/

	public void selectNewCase() {

		if (!verifyObjectPresentOrNot(eleNewCaseTitle)) {
			By missingInfoRadioButton = getDynamicElement(caseRadioButton, "Missing Information");
			waitAndVerifyElement(missingInfoRadioButton);
			click(missingInfoRadioButton);
			setTimeOut(4000);
			LoggingInfo("Selected New Case as - Missing information");
			setTimeOut(4000);
			clickNextButton();
		} else {
			LoggingInfo("Selected New Case as - Missing information");
		}

	}
	
	/**
	 * Function: Validate Correspondence Page is displayed
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateCorrespondencePageDisplayed() {	
		setTimeOut(8000);
		By eleCorspPage = By.xpath("//*[@role='tab'  and @title='Correspondence']");

		boolean displayed = getWebDriver().findElement(eleCorspPage).isDisplayed();
		if (displayed) {
			LoggingInfo("Correspondence page is displayed");
		}else{
			Log.error("Correspondence page not displayed");
			Assert.fail("Correspondence page not displayed");
		}

	}

	/**
	 * Function:Click on next button
	 * 
	 * @author Trupti Zure
	 **/
	public void clickNextButton() {
		try {

			Log.info("Verify user is able to click on Next button");
			By eleNextButton = getDynamicElement(eleButton, "Next");
			waitAndVerifyElement(eleNextButton);
			scrollToElement(eleNextButton);
			clickByJavascript(eleNextButton);
			setTimeOut(2000);
			LoggingInfo("User clicks on Next button");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Next Button " + e.getMessage());
			Assert.fail("Failed to click on Next Button " + e.getMessage());
		}
	}

//	By attestCheck=By.xpath("//input[@name=\"cbAttestation\"]//parent::span");
//	waitAndVerifyElement(attestCheck);
//	clickByJavascript(attestCheck);
//	LoggingInfo("Attestation checkbox selected");

	/**
	 * Function:Verify MI case information
	 * 
	 * @author Trupti Zure
	 **/

	public String verifyCaseInformation() {
		try {

			refresh();
			waitForPageLoaded();
			setTimeOut(5000);
			// Case name
			fieldName = careProgramMI.split(": ")[1];
			waitAndVerifyElement(eleCaseName);
			verifyDetails(eleCaseName, fieldName, "Case");

			// status
			By statusField = getDynamicElement(strHeaderTextFields, "Status");
			waitAndVerifyElement(statusField);
			verifyDetails(statusField, status, "Status");

			// care program MI,Patient Journey,Account Name
			patientJourney = correctSpaces(patientJourney);
			accountName = correctSpacesAccount(accountName);
			ArrayList<String> textFieldLinksValues = new ArrayList<>(
					Arrays.asList(careProgramMI, patientJourney, accountName));
			ArrayList<String> textFieldsLinks = new ArrayList<>(
					Arrays.asList("Care Program MI", "Patient Journey", "Account Name"));

			for (int i = 0; i < textFieldLinksValues.size(); i++) {
				if (textFieldLinksValues.get(i) != "") {
					By elementField = getDynamicElement(strInformationLinkField, textFieldsLinks.get(i));
					waitAndVerifyElement(elementField);
					scrollToElement(elementField);
					verifyDetails(elementField, textFieldLinksValues.get(i), textFieldsLinks.get(i));
				}
			}

			// Subject,status,category

			String categoryName = selectCategory();
			ArrayList<String> textFieldValues = new ArrayList<>(Arrays.asList(fieldName, categoryName, status));
			ArrayList<String> textFields = new ArrayList<>(Arrays.asList("Subject", "Category", "Status"));

			for (int i = 0; i < textFieldValues.size(); i++) {
				if (textFieldValues.get(i) != "") {
					By elementTextField = getDynamicElement(caseTextDetails, textFields.get(i));
					waitAndVerifyElement(elementTextField);
					scrollToElement(elementTextField);
					verifyDetails(elementTextField, textFieldValues.get(i), textFields.get(i));
				}
			}
			if (status.equalsIgnoreCase("Collected")) {
				// collected channel, collected date
				if (collectedDate != null) {
					collectedDate = collectedDate + ", 12:00 PM";
				}
				waitAndVerifyElement(eleCollectedChennel);
				scrollToElement(eleCollectedChennel);

				By collectedChannelField = getDynamicElement(strChannelInformation, "Collected Channel");
				waitAndVerifyElement(collectedChannelField);
				verifyDetails(collectedChannelField, channel, "Collected Channel");

				By collecteDateField = getDynamicElement(strChannelInformation, "Collected Date");
				waitAndVerifyElement(collecteDateField);
				verifyDetails(collecteDateField, collectedDate, "Collected Date");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verified case information " + e.getMessage());
			Assert.fail("Failed to verified case information  " + e.getMessage());
		}
		return accountName;
	}

	/**
	 * Function:Select MI category
	 * 
	 * @author Trupti Zure
	 **/

	public String selectCategory() {

		String categoryName = null;
		String[] patientDomographic = { "Patient First Name", "Patient Last Name", "Patient DOB", "Patient Gender", };
		String[] contactInfo = { "Patient Phone Number", "Patient Email", "Patient State", "Patient Address Street",
				"Patient City", "State", "Patient Zip Code" };
		String[] consent = { "Patient Program Consent", "Patient HIPAA Consent", "Patient Text Messaging Consent" };
		String[] patientDiagnosis = { "Diagnosis Code", "Primary Indication", "Diagnosis Missing" };
		String[] prescriptionInformation = { "Prescribed Dosing", "NDC", "Refill Info", "Prescription Date",
				"QS Prescription Missing", "Prescription Missing", "QS Prescription Date", "QS Prescribed Dosing",
				"QS Refill Info" };
		String[] caregiver = { "Caregiver First Name", "Caregiver Last Name", "Caregiver Phone Number",
				"Caregiver Email Address", "Caregiver Missing" };
		String[] insuranceMedical = { "Primary Payer Name", "Policy Number", "Insurance Missing" };
		String[] insurancePharamcy = { "Primary PBM Name", "Primary PBM Policy Number", "Primary PBM Group Number",
				"Primary PBM PCN", "Primary PBM Phone Number" };
		String[] hcpDemographic = { "HCP First Name", "HCP Last Name", "HCP NPI", "HCP Title", "Prescriber Missing" };
		String[] hcpContactInfo = { "HCP Address Street", "HCP City", "HCP State", "HCP Zip", "HCP Phone Number",
				"HCP Fax Number", "HCO Missing" };
		String[] spPharamcy = { "Specialty Pharmacy Name" };
		String[] enrollment = { "Incorrect Enrollment Form Version", "Incorrect Enrollment Form Indication" };

		String category = getCategoryName(fieldName, patientDomographic, contactInfo, consent, patientDiagnosis,
				prescriptionInformation, caregiver, insuranceMedical, insurancePharamcy, hcpDemographic, hcpContactInfo,
				spPharamcy, enrollment);

		if (category != null)
			categoryName = category;
		else
			categoryName = "--None--";

		return categoryName;

	}

	/**
	 * Function:Compare name
	 * 
	 * @author Trupti Zure
	 **/

	public boolean compareWithName(String name, String[] array) {
		for (String element : array) {
			if (element.equals(name)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Function:Get category name
	 * 
	 * @author Trupti Zure
	 **/

	public String getCategoryName(String fieldName, String[]... arrays) {
		String[] categoryNames = { "Patient Demographics", "Patient Contact Information", "Consent",
				"Patient Diagnosis", "Prescription Information", "Caregiver Contact Info",
				"Insurance Information (Medical)", "Insurance Information (Pharmacy)", "HCP Demographics",
				"HCP Contact Information", "Specialty Pharmacy", "Enrollment Form" };

		for (int i = 0; i < arrays.length; i++) {
			if (compareWithName(fieldName, arrays[i])) {
				return categoryNames[i];
			}
		}
		return null;
	}

	/**
	 * Function:Correct spaces
	 * 
	 * @author Trupti Zure
	 **/
	public String correctSpaces(String input) {
		return input.replaceAll("(?<=\\S)\\s+", " ");
	}

	/**
	 * Function:Correct spaces
	 * 
	 * @author Trupti Zure
	 **/
	public String correctSpacesAccount(String input) {
		// single space
		return input.replaceAll("(?<=\\w)\\s+", " ");
	}

	// Anand P
	public void clickOnMICase() {
		try {
			By caseNumber = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Open Cases\"]//tbody//tr//th//span//ancestor::a");
			waitAndVerifyElement(caseNumber);
			scrollToElement(caseNumber);
			clickByJavascript(caseNumber);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on case number" + e.getMessage());
			Assert.fail("Failed to click on case number  " + e.getMessage());
		}

	}

	public void verifyNewCaseTitle() {
		try {
			setTimeOut(2000);
			// getWebDriver().switchTo().frame(0);
			// getWebDriver().switchTo().frame(0);
			By eleAccName = By.xpath("//span[text()=\"New Case\"]");
			waitAndVerifyElement(eleAccName);
			scrollToElement(eleAccName);
			highLightElement(eleAccName);
			LoggingInfo("Verified New Case title");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Verify New Case title " + e.getMessage());
			Assert.fail("Failed to Verify New Case title " + e.getMessage());
		}

	}

	public void verifyNewCaseMITitle() {
		try {
			setTimeOut(2000);
			By eleAccName = By.xpath("//h2[text()=\"New Case: Missing Information\"]");
			waitAndVerifyElement(eleAccName);
			scrollToElement(eleAccName);
			highLightElement(eleAccName);
			LoggingInfo("Verified New Case title");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Verify New Case title " + e.getMessage());
			Assert.fail("Failed to Verify New Case title " + e.getMessage());
		}

	}

	public void verifyNewCaseWMTitle() {
		try {
			setTimeOut(10000);
			By eleAccName = By.xpath("//h2[text()=\"New Case: Welcome Message\"]");
			waitAndVerifyElement(eleAccName);
			scrollToElement(eleAccName);
			highLightElement(eleAccName);
			LoggingInfo("Verified New Case title");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Verify New Case title " + e.getMessage());
			Assert.fail("Failed to Verify New Case title " + e.getMessage());
		}

	}

	public void verifyNewCaseOrderFollupTitle() {
		try {
			setTimeOut(2000);
			By eleAccName = By.xpath("//h2[text()=\"New Case: Order Follow up\"]");
			waitAndVerifyElement(eleAccName);
			scrollToElement(eleAccName);
			highLightElement(eleAccName);
			LoggingInfo("Verified New Case title");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Verify New Case title " + e.getMessage());
			Assert.fail("Failed to Verify New Case title " + e.getMessage());
		}

	}

	public void navigateToCasesTab() {
		try {
			setTimeOut(2000);
			By eleAccName = By.xpath("//*[text()=\"Recently Viewed | Cases\"]");
			waitAndVerifyElement(eleAccName);
			click(eleAccName);
			LoggingInfo("Clicked on tab");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Clicked on tab " + e.getMessage());
			Assert.fail("Failed to Clicked on tab " + e.getMessage());
		}

	}

	public void navigateToCaseTab() {
		try {
			setTimeOut(2000);
			// By eleAccName = By.xpath("//a[@title=\"Cases\"]");
			By eleCloseCase = By.xpath("//button[@title='Close New Case Record Creation']");
			waitAndVerifyElement(eleCloseCase);
			clickByJavascript(eleCloseCase);
			LoggingInfo("Clicked on close case");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Clicked on tab " + e.getMessage());
			Assert.fail("Failed to Clicked on tab " + e.getMessage());
		}

	}

	public void clickCaseType(String ctype) {
		try {
			setTimeOut(2000);
			By eleAccName = getDynamicElement(caseTypeCM, ctype);
			waitAndVerifyElement(eleAccName);
			scrollToElement(eleAccName);
			highLightElement(eleAccName);
			clickByJavascript(eleAccName);
			LoggingInfo("Clicked on " + ctype + " Successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click  " + e.getMessage());
			Assert.fail("Failed to click  " + e.getMessage());
		}

	}

	public void clickCasesType(String ctype) {
		try {
			setTimeOut(2000);
			// By eleAccName = getDynamicElement(caseType,ctype);
			waitAndVerifyElement(eleWelcome);
			scrollToElement(eleWelcome);
			highLightElement(eleWelcome);
			click(eleWelcome);
			LoggingInfo("Clicked on " + ctype + " Successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click  " + e.getMessage());
			Assert.fail("Failed to click  " + e.getMessage());
		}

	}

	// Anand P
	public void clickonAccount(String AccName) {
		try {
			setTimeOut(2000);

			By eleAccName = getDynamicElement(strAccountName, AccName);
			scrollToElement(eleAccName);
			click(eleAccName);

			LoggingInfo("clicked on Account Name successfuly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Account Name " + e.getMessage());
			Assert.fail("Failed to click on Account Name " + e.getMessage());
		}

	}

	/**
	 * Function:Check MI record is present
	 * 
	 * @author Anand Pawar
	 **/
	public void checkMIRecord(String miTitle) {
		try {
			setTimeOut(2000);

			if (verifytable("Open Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
				boolean allCollected = true;

				for (WebElement row : rows) {
					WebElement subjectElement = row.findElement(By.xpath(".//td[@data-label=\"Subject\"]//slot//span"));
					String subject = subjectElement.getText();
					if (subject.equalsIgnoreCase(miTitle)) {
						LoggingInfo("Related MI is present in MI tab section");
					}
				}

			} else {
				LoggingInfo("Related MI is not present in MI tab section");

			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate MI Record" + e.getMessage());
			Assert.fail("Failed to validate MI Record " + e.getMessage());
		}

	}

	/**
	 * Function:Change status of MI cases to collected
	 * 
	 * @author Trupti Zure
	 **/
	public void changeStatusOfMICases() {
		try {
			if (verifytable("Open Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
				boolean allCollected = true;

				for (WebElement row : rows) {
					WebElement statusElement = row
							.findElement(By.xpath(".//*[@data-label=\"Status\"]//lst-formatted-text//span"));
					String status = statusElement.getText().trim();

					if (status.equalsIgnoreCase("Open") || status.equalsIgnoreCase("Not Collected")
							|| status.equalsIgnoreCase("Closed")) {
						allCollected = false;
						break;
					}
				}

				if (!allCollected) {
					Log.info("Selecting all Open Cases for Bulk Close");
					WebElement actionButton = rows.get(0).findElement(By.xpath(".//td//button"));
					((JavascriptExecutor) getWebDriver()).executeScript(
							"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
							actionButton);

					By eleSelect = By.xpath(
							"//*[text()=\"Case Number\"]//ancestor::th//preceding-sibling::th//span[@class=\"slds-checkbox\"]");
					scrollToElement(eleSelect);
					waitAndVerifyElement(eleSelect);
					click(eleSelect);
					setTimeOut(2000);

					By eleBulkCloseButton = getDynamicElement(eleButton, "Bulk Close");
					scrollToElement(eleBulkCloseButton);
					waitAndVerifyElement(eleBulkCloseButton);
					clickByJavascript(eleBulkCloseButton);
					setTimeOut(4000);
					Log.info("Clicked on Bulk Close");

					By frame = By.xpath("(//*[@title='Salesforce - Unlimited Edition'])[1]");
					Utility_Function.switchToFrame2(frame);

					By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
					waitAndVerifyElement(statusDropDown);
					scrollToElement(statusDropDown);
					click(statusDropDown);
					setTimeOut(1000);

					By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
					waitAndVerifyElement(statusDropDownList);
					String status = "Collected";
					// Select "Collected" from dropdown
					selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
					LoggingInfo("Selected Status as- " + status);
					setTimeOut(2000);

					// Select Collected Channel
					By statusDropDown2 = getDynamicElement(elestrDropDownBox, "Collected_Channel");
					waitAndVerifyElement(statusDropDown2);
					scrollToElement(statusDropDown2);
					click(statusDropDown2);
					setTimeOut(1000);
					By statusDropDownList2 = getDynamicElement(elestrDropDownList, "Collected_Channel");
					waitAndVerifyElement(statusDropDownList2);
					String channel = "Phone";
					// Select "Phone" from dropdown
					selectItemFromList(statusDropDown2, statusDropDownList2, channel, "Collected_Channel");
					Log.info("Selected Channel as- " + channel);
					setTimeOut(1000);

					By statusDropDown3 = getDynamicElement(elestrDropDownBox, "Closure_Attempt");
					waitAndVerifyElement(statusDropDown3);
					scrollToElement(statusDropDown3);
					click(statusDropDown3);
					setTimeOut(1000);
					By statusDropDownList3 = getDynamicElement(elestrDropDownList, "Closure_Attempt");
					waitAndVerifyElement(statusDropDownList3);
					String attempt = "Fax";

					// Select "Fax" from dropdown
					selectItemFromList(statusDropDown3, statusDropDownList3, attempt, "Closure_Attempt");
					Log.info("Selected attempt as- " + attempt);
					setTimeOut(1000);

					By inputDate = By.xpath("(//*[@name=\"Closure_Attempt_Date\"])[1]");
					String date = Utility_Function.rearrangeDateFormat();
					inputText(inputDate, date);
					setTimeOut(4000);

					By inputTime = By.xpath("(//*[@name=\"Closure_Attempt_Date\"])[2]");
					click(inputTime);

					clickOnSubmitButton();
					setTimeOut(2000);

					By radioBtn = By.xpath("(//span[@class=\"slds-radio_faux\"])[1]");
					click(radioBtn);
					setTimeOut(1000);

					By nextBtn = By.xpath("//*[text()=\"Next\"]//parent::button");
					click(nextBtn);
					setTimeOut(4000);

					scrollToTopOfPage();
					LoggingInfo("Bulk close applied and submitted.");

					Log.info("Rechecking the status of all cases to ensure they are all collected.");
					rows = getWebDriver().findElements(eleMissingInfoTable);
					boolean allCollectedAfterBulkClose = true;

					for (WebElement row : rows) {
						WebElement statusElement = row
								.findElement(By.xpath(".//*[@data-label=\"Status\"]//lst-formatted-text//span"));
						status = statusElement.getText().trim();
						if (!status.equalsIgnoreCase("Collected")) {
							allCollectedAfterBulkClose = false;
							break;
						}
					}

					if (allCollectedAfterBulkClose) {
						LoggingInfo("All cases are now collected.");
					} else {
						LoggingInfo("Some cases still need to be updated.");
					}
				} else {
					LoggingInfo("All cases are already collected. No action needed.");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify case information: " + e.getMessage());
			Assert.fail("Failed to verify case information: " + e.getMessage());
			LoggingInfo("Collected all open MI cases ");
		}
	}

	/**
	 * Function:select multiple MI Cases Checkbox
	 * 
	 * @author Anand Pawar
	 **/
	public void selectMultipleMICasesCheckbox() {
		try {

			By eleSelect = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Case Number\"]//ancestor::th//preceding-sibling::th//span[@class=\"slds-checkbox\"]");
			scrollToElement(eleSelect);
			waitAndVerifyElement(eleSelect);
			click(eleSelect);
			setTimeOut(2000);

			LoggingInfo("Successfully checked mutiple MI Cases checkbox");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select" + e.getMessage());
			Assert.fail("Failed to select  " + e.getMessage());
		}

	}

	/**
	 * Function:verify Validation Rule For Status Not Collected
	 * 
	 * @author Anand Pawar
	 **/
	public void verifyMICaseSaveErrorAttemptBlank() {
		try {

			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
			waitAndVerifyElement(statusDropDownList);
			String status = "Collected";
			// Select "Collected" from dropdown
			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(2000);

			By statusDropDown2 = getDynamicElement(elestrDropDownBox, "Collected Channel");
			waitAndVerifyElement(statusDropDown2);
			scrollToElement(statusDropDown2);
			click(statusDropDown2);
			setTimeOut(1000);
			By statusDropDownList2 = getDynamicElement(elestrDropDownList, "Collected_Channel");
			waitAndVerifyElement(statusDropDownList2);
			String channel = "Phone";
			// Select "Phone" from dropdown
			selectItemFromList(statusDropDown2, statusDropDownList2, channel, "Collected_Channel");
			LoggingInfo("Selected Channel as- " + channel);
			setTimeOut(1000);

			By inputDate = By.xpath("(//input[@name=\"X1st_Attempt_Date\"])[1]");
			// String date = Utility_Function.rearrangeDateFormat();
			clearText(inputDate);
			setTimeOut(4000);

			clickOnSubmitButton();

			verifyErrorStatusCollected();
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click" + e.getMessage());
			Assert.fail("Failed to click  " + e.getMessage());
		}

	}

	/**
	 * Function:verify Validation Rule For Status Not Collected
	 * 
	 * @author Anand Pawar
	 **/
	public void verifyValidationRuleForStatusNotCollected() {
		try {

			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
			waitAndVerifyElement(statusDropDownList);
			String status = "Not Collected";
			// Select "Collected" from dropdown
			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(2000);

			// Select attempt
			By statusDropDown3 = getDynamicElement(elestrDropDownBox, "1st Attempt");
			waitAndVerifyElement(statusDropDown3);
			scrollToElement(statusDropDown3);
			click(statusDropDown3);
			setTimeOut(1000);
			By statusDropDownList3 = getDynamicElement(elestrDropDownList, "X1st_Attempt");
			waitAndVerifyElement(statusDropDownList3);
			String attempt = "Fax";

			// Select "Fax" from dropdown
			selectItemFromList(statusDropDown3, statusDropDownList3, attempt, "X1st_Attempt");
			LoggingInfo("Selected attempt as- " + attempt);
			setTimeOut(1000);

			// Enter attempt date
			By inputDate = By.xpath("(//input[@name=\"X1st_Attempt_Date\"])[1]");
			String date = Utility_Function.rearrangeDateFormat();
			inputText(inputDate, date);
			setTimeOut(4000);

			By inputTime = By.xpath("(//input[@name=\"X1st_Attempt_Date\"])[2]");
			click(inputTime);

			clickOnSubmitButton();

			verifyErrorStatusNotCollected();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify" + e.getMessage());
			Assert.fail("Failed to verify  " + e.getMessage());
		}

	}

	/**
	 * Function:click Bulk Close Button
	 * 
	 * @author Anand Pawar
	 **/
	public void clickBulkCloseButton() {
		try {

			By eleBulkCloseButton = getDynamicElement(eleButton, "Bulk Close");
			scrollToElement(eleBulkCloseButton);
			waitAndVerifyElement(eleBulkCloseButton);
			clickByJavascript(eleBulkCloseButton);

			LoggingInfo("Clicked on bulk close button");

			By frame = By.xpath("(//iframe[@title='Salesforce - Unlimited Edition'])[1]");
			Utility_Function.switchToFrame2(frame);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click" + e.getMessage());
			Assert.fail("Failed to click  " + e.getMessage());
		}

	}

	/**
	 * Function:Validate reason picklist values
	 * 
	 * @author Anand Pawar
	 **/
	public void validateReasonPickListValues() {
		try {
			String reason1 = "Enrollment Oversight";
			String reason2 = "Triaged to SP";

			// Select reason
			By statusDropDown3 = getDynamicElement(elestrDropDownBox, "Reason");
			waitAndVerifyElement(statusDropDown3);
			scrollToElement(statusDropDown3);
			click(statusDropDown3);
			setTimeOut(1000);
			By statusDropDownList3 = getDynamicElement(elestrDropDownList, "Reason1");
			waitAndVerifyElement(statusDropDownList3);

			selectItemFromList(statusDropDown3, statusDropDownList3, reason1, "Reason1");
			LoggingInfo("Selected reason as- " + reason1);
			setTimeOut(1000);

			click(statusDropDown3);
			waitAndVerifyElement(statusDropDownList3);
			selectItemFromList(statusDropDown3, statusDropDownList3, reason2, "Reason1");

			LoggingInfo("Both picklist values " + reason1 + " And " + reason2 + "present");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate" + e.getMessage());
			Assert.fail("Failed to validate  " + e.getMessage());
		}

	}

	/**
	 * Function:Validate Reason dependent field
	 * 
	 * @author Anand Pawar
	 **/
	public void validateReasonDependentField() {
		try {

			String attempt = "Not Applicable";

			// Select attempt
			By statusDropDown3 = getDynamicElement(elestrDropDownBox, "1st Attempt");
			waitAndVerifyElement(statusDropDown3);
			scrollToElement(statusDropDown3);
			click(statusDropDown3);
			setTimeOut(1000);
			By statusDropDownList3 = getDynamicElement(elestrDropDownList, "X1st_Attempt");
			waitAndVerifyElement(statusDropDownList3);

			selectItemFromList(statusDropDown3, statusDropDownList3, attempt, "X1st_Attempt");
			LoggingInfo("Selected attempt as- " + attempt);
			setTimeOut(1000);

			By eleFie = getDynamicElement(eleField, "Reason");
			waitAndVerifyElement(eleFie);
			highLightElement(eleFie);
			LoggingInfo("Reason field visible when attempt selected as " + attempt);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click" + e.getMessage());
			Assert.fail("Failed to click  " + e.getMessage());
		}

	}

	/**
	 * Function:save Status as not collected with filling all values
	 * 
	 * @author Anand Pawar
	 **/

	public void saveStatusNotCollcted() {
		try {
			String attempt = "Fax";
			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Copy_1_of_Status");
			waitAndVerifyElement(statusDropDownList);
			String status = "Not Collected";
			selectItemFromList(statusDropDown, statusDropDownList, status, "Copy_1_of_Status");
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(2000);

			By statusDropDown3 = getDynamicElement(elestrDropDownBox, "1st_Attempt");
			waitAndVerifyElement(statusDropDown3);
			scrollToElement(statusDropDown3);
			click(statusDropDown3);
			setTimeOut(1000);
			By statusDropDownList3 = getDynamicElement(elestrDropDownList, "1st_Attempt");
			waitAndVerifyElement(statusDropDownList3);

			selectItemFromList(statusDropDown3, statusDropDownList3, attempt, "1st_Attempt");
			LoggingInfo("Selected attempt as Fax ");
			setTimeOut(1000);

			// Enter attempt date
			By inputDate = By.xpath("(//input[@name=\"Copy_1_of_X1st_Attempt_Date\"])[1]");
			String date = Utility_Function.rearrangeDateFormat();
			inputText(inputDate, date);
			setTimeOut(4000);

			By inputTime = By.xpath("(//input[@name=\"Copy_1_of_X1st_Attempt_Date\"])[2]");
			click(inputTime);
			setTimeOut(1000);

			By statusDropDown4 = getDynamicElement(elestrDropDownBox, "2nd_Attempt");
			waitAndVerifyElement(statusDropDown4);
			scrollToElement(statusDropDown4);
			click(statusDropDown4);
			setTimeOut(1000);
			By statusDropDownList4 = getDynamicElement(elestrDropDownList, "2nd_Attempt");
			waitAndVerifyElement(statusDropDownList4);

			selectItemFromList(statusDropDown4, statusDropDownList4, attempt, "2nd_Attempt");
			LoggingInfo("Selected attempt as- " + attempt);
			setTimeOut(1000);

			By inputDate2 = By.xpath("(//input[@name=\"Copy_1_of_X2nd_Attempt_Date\"])[1]");
			inputText(inputDate2, date);
			setTimeOut(4000);

			By inputTime2 = By.xpath("(//input[@name=\"Copy_1_of_X2nd_Attempt_Date\"])[2]");
			click(inputTime2);
			setTimeOut(1000);

			By statusDropDown5 = getDynamicElement(elestrDropDownBox, "3rd_Attempt");
			waitAndVerifyElement(statusDropDown5);
			scrollToElement(statusDropDown5);
			click(statusDropDown5);
			setTimeOut(1000);
			By statusDropDownList5 = getDynamicElement(elestrDropDownList, "3rd_Attempt");
			waitAndVerifyElement(statusDropDownList5);

			selectItemFromList(statusDropDown5, statusDropDownList5, attempt, "3rd_Attempt");
			LoggingInfo("Selected attempt as- " + attempt);
			setTimeOut(1000);

			By inputDate3 = By.xpath("(//input[@name=\"Copy_1_of_X3rd_Attempt_Date\"])[1]");
			inputText(inputDate3, date);
			setTimeOut(4000);

			By inputTime3 = By.xpath("(//input[@name=\"Copy_1_of_X3rd_Attempt_Date\"])[2]");
			click(inputTime3);
			setTimeOut(1000);

			clickOnSubmitButton();

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	/**
	 * Function:validate attempt picklist values
	 * 
	 * @author Anand Pawar
	 **/
	public void validateAttemptPicklistValue() {
		try {

			String attempt = "Not Applicable";

			// Select attempt
			By statusDropDown3 = getDynamicElement(elestrDropDownBox, "1st Attempt");
			waitAndVerifyElement(statusDropDown3);
			scrollToElement(statusDropDown3);
			click(statusDropDown3);
			setTimeOut(1000);
			By statusDropDownList3 = getDynamicElement(elestrDropDownList, "X1st_Attempt");
			waitAndVerifyElement(statusDropDownList3);

			selectItemFromList(statusDropDown3, statusDropDownList3, attempt, "X1st_Attempt");
			LoggingInfo("Selected attempt as- " + attempt);
			setTimeOut(1000);

			By statusDropDown4 = getDynamicElement(elestrDropDownBox, "2nd Attempt");
			waitAndVerifyElement(statusDropDown4);
			scrollToElement(statusDropDown4);
			click(statusDropDown4);
			setTimeOut(1000);
			By statusDropDownList4 = getDynamicElement(elestrDropDownList, "X2nd_Attempt");
			waitAndVerifyElement(statusDropDownList4);

			selectItemFromList(statusDropDown4, statusDropDownList4, attempt, "X2nd_Attempt");
			LoggingInfo("Selected attempt as- " + attempt);
			setTimeOut(1000);

			By statusDropDown5 = getDynamicElement(elestrDropDownBox, "3rd Attempt");
			waitAndVerifyElement(statusDropDown5);
			scrollToElement(statusDropDown5);
			click(statusDropDown5);
			setTimeOut(1000);
			By statusDropDownList5 = getDynamicElement(elestrDropDownList, "X3rd_Attempt");
			waitAndVerifyElement(statusDropDownList5);

			selectItemFromList(statusDropDown5, statusDropDownList5, attempt, "X3rd_Attempt");
			LoggingInfo("Selected attempt as- " + attempt);
			setTimeOut(1000);

			LoggingInfo("Validated Attempt pick list values " + attempt + " present in attempt options");

			// set attempt 1,2 & 3 back to None
			click(statusDropDown5);
			waitAndVerifyElement(statusDropDownList5);
			selectItemFromList(statusDropDown5, statusDropDownList5, "--None--", "X3rd_Attempt");

			click(statusDropDown4);
			waitAndVerifyElement(statusDropDownList4);
			selectItemFromList(statusDropDown4, statusDropDownList4, "--None--", "X2nd_Attempt");

			click(statusDropDown3);
			waitAndVerifyElement(statusDropDownList3);
			selectItemFromList(statusDropDown3, statusDropDownList3, "--None--", "X1st_Attempt");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate" + e.getMessage());
			Assert.fail("Failed to validate  " + e.getMessage());
		}

	}

	/**
	 * Function:validate status picklist values
	 * 
	 * @author Anand Pawar
	 **/
	public void validateStatusPicklistValue() {
		try {
			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
			waitAndVerifyElement(statusDropDownList);
			String status = "Collected";
			// Select "Collected" from dropdown
			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
			setTimeOut(2000);

			// Not collected option is removed in new layout
			// click(statusDropDown);
			// waitAndVerifyElement(statusDropDownList);
			// String status2 = "Not Collected";
			// // Select "Collected" from dropdown
			// selectItemFromList(statusDropDown, statusDropDownList, status2, "Status");
			// setTimeOut(2000);

			LoggingInfo("validated status pick list values");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate" + e.getMessage());
			Assert.fail("Failed to validate  " + e.getMessage());
		}

	}

	/**
	 * Function:validate Cancelled picklist values
	 * 
	 * @author Anand Pawar
	 **/

	public void verifyCanceledPicklistValue(String subjectName) {

		try {

			if (verifytable("Closed Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoClosedTable);
				scrollToElement(eleMissingInfoClosedTable);

				for (WebElement row : rows) {

					WebElement subjectElement = row.findElement(By.xpath(".//td//div[@class=\"slds-grid\"]//a"));
					String miSubject = subjectElement.getAttribute("title");
					System.out.println(miSubject);

					if (miSubject.equalsIgnoreCase(subjectName)) {

						setTimeOut(2000);
						waitAndVerifyElement(eleEditBtn);
						scrollToElement(eleEditBtn);
						click(eleEditBtn);
						setTimeOut(2000);

						By btn = By.xpath("//a[@title='Edit']");
						click(btn);

						By statusDropDown = getDynamicElement(strDropDownBox, "Status");
						waitAndVerifyElement(statusDropDown);
						scrollToElement(statusDropDown);
						click(statusDropDown);
						setTimeOut(1000);

						By statusDropDownList = getDynamicElement(strDropDownBoxOptions, "Status");
						waitAndVerifyElement(statusDropDownList);
						String status = "Cancelled";
						// Select "Collected" from dropdown
						selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
						LoggingInfo(" Status as- " + status + " is present");
						setTimeOut(2000);

						clickOnCancelButton();

					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Function:validate Page Layout
	 * 
	 * @author Anand Pawar
	 **/
	public void validateOmniScriptLayout() {
		try {

			ArrayList<String> pageFields = new ArrayList<>(
					Arrays.asList("Status", "Collected Channel", "Closure Attempt", "Closure Attempt Date"));

			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
			waitAndVerifyElement(statusDropDownList);
			String status = "Collected";
			// Select "Collected" from dropdown
			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
			setTimeOut(2000);

			for (String field : pageFields) {
				By eleFie = getDynamicElement(eleField, field);
				waitAndVerifyElement(eleFie);
				highLightElement(eleFie);
				System.out.println("Field" + field + " is present on Omniscript Layout");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate" + e.getMessage());
			Assert.fail("Failed to validate " + e.getMessage());
		}

	}

	/**
	 * Function:Get case number
	 * 
	 * @author Trupti Zure
	 **/
	public String getCaseNumber() {
		String miCaseNumber = null;
		try {
			By caseNumber = getDynamicElement(strHeaderTextFeilds, "primaryField");
			waitAndVerifyElement(caseNumber);
			scrollToElement(caseNumber);
			miCaseNumber = getText(caseNumber);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get case number" + e.getMessage());
			Assert.fail("Failed to get case number  " + e.getMessage());
		}
		return miCaseNumber;

	}

	/**
	 * Function:Navigate to CPE record from correspondence screen after task
	 * completion It is intermittent, sometimes it generated sometimes don't , so to
	 * avoid failure.
	 * 
	 * @author Anand Pawar
	 **/

	public void navigateToCPERecordFrmCorrespondence(String patientName) {
		try {
			By cpeRecord = getDynamicElement(strCPERecord, patientName);
			setTimeOut(4000);
			Wait<WebDriver> wait = new FluentWait<WebDriver>(getWebDriver()).withTimeout(Duration.ofSeconds(250))
					.pollingEvery(Duration.ofSeconds(5)).ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.visibilityOfElementLocated(cpeRecord));
			getWebDriver().findElement(cpeRecord).click();
			setTimeOut(2000);
			LoggingInfo("Navigated to Care program enrollee record from correspondence");
			setTimeOut(3000);
		} catch (Exception e) {
			LoggingInfo("Correspondence screen not generated continue to next step...");

		}
	}

	/**
	 * Function:Navigate to CPE record
	 * 
	 * @author Trupti Zure
	 **/

	public void navigateToCPERecord(String patientName) {
		try {
			By cpeRecord = getDynamicElement(strCPERecord, patientName);
			waitAndVerifyElement(cpeRecord);
			scrollToElement(cpeRecord);
			click(cpeRecord);
			setTimeOut(2000);
			LoggingInfo("Navigated to Care program enrollee record");
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to CPE record-" + e.getMessage());
			Assert.fail("Failed to navigate to CPE record-" + e.getMessage());
		}
	}

	public void navigateToCorrespondenceTab() {
		try {
			setTimeOut(2000);
			By corrTab = By.xpath("//a[@title=\"correspondenceMultiIcc\"]");
			click(corrTab);
			setTimeOut(2000);
			LoggingInfo("Navigated to Correspondence tab");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to Correspondence tab" + e.getMessage());
			Assert.fail("Failed to navigate to Correspondence tab" + e.getMessage());
		}
	}

	/**
	 * Function:Verify Correspondence tab not generated
	 * 
	 * @author Anand Pawar
	 **/

	public void verifyCorrespondenceTabNotGenerated() {
		try {
			setTimeOut(2000);
			WebElement tab = getWebDriver().findElement(By.xpath("//a[@title='correspondenceMultiIcc']"));
			Assert.assertFalse(tab.isDisplayed(), "Correspondence tab should not be visible");
			setTimeOut(2000);
		} catch (Exception e) {
			System.out.println("Correspondence tab not generated as expected.");
			LoggingInfo("Correspondence tab not generated as expected.");
		}

	}

	/**
	 * Function:Verify Case History
	 * 
	 * @author Anand Pawar
	 **/

	public void verifyCaseHistory() {

		ArrayList<String> fieldValues = new ArrayList<>(Arrays.asList("Created.", "3rd Attempt Date",
				"2nd Attempt Date", "1st Attempt Date", "1st Attempt", "2nd Attempt", "3rd Attempt", "Status"));
		try {
			setTimeOut(2000);
			for (String field : fieldValues) {
				By fieldName = getDynamicElement(eleCaseHistory, field);
				waitAndVerifyElement(fieldName);
				highLightElement(fieldName);
			}

			LoggingInfo("Successfully verified all case history details");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify case history details" + e.getMessage());
			Assert.fail("Failed to verify case history details" + e.getMessage());

		}

	}

	/**
	 * Function:Close the correspondence record
	 * 
	 * @author Sonica P
	 **/

	public void closeCorrespondence() {
		try {

			click(eleCloseCorrespondence);
			setTimeOut(2000);
			LoggingInfo("Close Correspondence record");
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to close correspondence page" + e.getMessage());
			Assert.fail("Failed to close correspondence page" + e.getMessage());
		}
	}

	/**
	 * Function:Navigate to CPE record
	 * 
	 * @author Anand Pawar
	 **/

	public void navigateToCPETab() {
		try {

			waitAndVerifyElement(cpeTab);
			scrollToElement(cpeTab);
			clickByJavascript(cpeTab);
			setTimeOut(2000);
			LoggingInfo("Navigated to Care program enrollee record");
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to CPE record-" + e.getMessage());
			Assert.fail("Failed to navigate to CPE record-" + e.getMessage());
		}
	}

	public void closeAccChildObj() {
		try {
			refresh();
			click(eleClose);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to CPE record-" + e.getMessage());
			Assert.fail("Failed to navigate to CPE record-" + e.getMessage());
		}
	}

	/**
	 * Function:verify not collected status
	 * 
	 * @author Anand Pawar
	 **/

	public void verifyNotCollectedStatus() {
		try {
			By eleTable = By.xpath("//span[text()=\"Closed Cases\"]//parent::a");
			scrollToElement(eleTable);
			// clickByJavascript(eleTable);

			List<WebElement> rows = getWebDriver().findElements(eleMissingInfoClosedTable);
			rows = getWebDriver().findElements(eleMissingInfoClosedTable);

			for (WebElement row : rows) {
				WebElement statusElement = row
						.findElement(By.xpath(".//td[@data-label=\"Status\"]//lst-formatted-text//span"));
				status = statusElement.getText().trim();

				if (status.equalsIgnoreCase("Not Collected")) {
					System.out.println("Status is not collected as expected for all MI Cases");
					LoggingInfo("Status is Not Collected");
				} else {
					System.out.println("Status is other than not collected ");
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify" + e.getMessage());
			Assert.fail("Failed to verify" + e.getMessage());
		}
	}

	/**
	 * Function:Verify Bulk Close button
	 * 
	 * @author Anand Pawar
	 **/
	public void verifyBulkCloseButton(String tableName) {
		try {
			if (verifytable("Open Cases")) {
				By eleBulkCloseButton = getDynamicElement(eleButton, "Bulk Close");
				scrollToElement(eleBulkCloseButton);
				waitAndVerifyElement(eleBulkCloseButton);
				highLightElement(eleBulkCloseButton);
				setTimeOut(4000);
				LoggingInfo("Verified Bulk Close button exist on Open Cases list view");
			} else if (verifytable("Closed Cases")) {
				try {
					By eleTable = By.xpath("//span[text()=\"Closed Cases\"]//parent::a");
					scrollToElement(eleTable);
					clickByJavascript(eleTable);

					By eleBulkCloseButton = getDynamicElement(eleButton, "Bulk Close");
					waitAndVerifyElement(eleBulkCloseButton);

				} catch (Exception e) {
					LoggingInfo("Verified Bulk Close button does not exist on Closed Cases list view");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify-" + e.getMessage());
			Assert.fail("Failed to verify " + e.getMessage());
		}
	}

	// anand p
	public void navigateToChildRecord() {
		try {
			By cpeRecord = By.xpath(
					"(//div[contains(@class,\"wsTabset oneConsoleTabset\")]//*[contains(@class,\"tabBarItems\")]//*[contains(@title,\"Automation\")])[4]");
			waitAndVerifyElement(cpeRecord);
			scrollToElement(cpeRecord);
			click(cpeRecord);
			setTimeOut(2000);
			LoggingInfo("Navigated child record");
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to Child record-" + e.getMessage());
			Assert.fail("Failed to navigate to Child record-" + e.getMessage());
		}

	}

	/**
	 * Function:Verify MI record in cases table
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyMIRecord(String number) {
		try {
			boolean numberFound = false;
			if (verifytable("Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
				scrollToElement(eleMissingInfoTable);
				for (WebElement row : rows) {
					WebElement statusElement = row
							.findElement(By.xpath(".//th//a//span[@class=\"slds-truncate\"]//slot"));
					String caseNumber = statusElement.getText().trim();
					if (caseNumber.equals(number)) {
						numberFound = true;
						break;
					}

				}
				Assert.assertTrue(numberFound, "Case Number '" + number + "' not found in the Cases table.");
				LoggingInfo("Verification completed for case number: " + number);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify case number-" + e.getMessage());
			Assert.fail("Failed to verify case number" + e.getMessage());
		}
	}

	/**
	 * Function:Verify MI record is created in cases table with subject name
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyMIRecordCreated(String expectedSubject, String expectedstatus) {
		try {
			boolean subjectFound = false;
			boolean statusIsOpen = false;

			if (verifytable("Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
				scrollToElement(eleMissingInfoTable);

				for (WebElement row : rows) {
					WebElement subjectElement = row.findElement(By.xpath(".//td//div[@class=\"slds-grid\"]//a"));
					String actualSubject = subjectElement.getAttribute("title");

					if (actualSubject.equals(expectedSubject)) {
						subjectFound = true;

						WebElement statusElement = row
								.findElement(By.xpath(".//td[@data-label=\"Status\"]//lst-formatted-text//span"));
						String status = statusElement.getText().trim();

						if (status.equalsIgnoreCase(expectedstatus)) {
							statusIsOpen = true;
						}
						break;
					}
				}

				Assert.assertTrue(subjectFound,
						"MI case with subject '" + expectedSubject + "' not found in the Cases table.");
				Assert.assertTrue(statusIsOpen, "MI case '" + expectedSubject + "' is not in 'Open' status.");

				LoggingInfo("Successfully verified MI case: " + expectedSubject + " with status 'Open'");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify MI case subject - " + e.getMessage());
			Assert.fail("Failed to verify MI case subject: " + e.getMessage());
		}
	}

	/**
	 * Function:Change status of created MI cases with subject name
	 * 
	 * @author Trupti Zure
	 **/

	public String changeStatusOfCreatedMICase(String subjectName) {
		String caseNumber = null;

		try {
			if (verifytable("Open Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
				scrollToElement(eleMissingInfoTable);
				for (WebElement row : rows) {

					WebElement subjectElement = row.findElement(By.xpath(".//td//div[@class=\"slds-grid\"]//a"));
					String miSubject = subjectElement.getAttribute("title");

					if (miSubject.equalsIgnoreCase(subjectName)) {
						WebElement elCaseNumber = row.findElement(
								By.xpath(".//th[@data-label='Case Number']//a//span[@class='slds-truncate']//span"));
						caseNumber = elCaseNumber.getText();

						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								elCaseNumber);

						Log.info(caseNumber);
						elCaseNumber.click();

						// click on close
						By closeButton = getDynamicElement(strEditBtn, "Case.CAS_Close_ICC");
						waitAndVerifyElement(closeButton);
						click(closeButton);

						// Update status to "Collected"
						By statusDropDown = getDynamicElement(eleSelectDropDown, "Status");
						waitAndVerifyElement(statusDropDown);
						String status = "Collected";
						selectItemFromList(statusDropDown, status);

						// Select Collected Channel
						By channelDropDown = getDynamicElement(eleSelectDropDown, "Collected_Channel");
						waitAndVerifyElement(channelDropDown);
						scrollToElement(channelDropDown);
						String channel = "Phone";
						// Select "Phone" from dropdown
						selectItemFromList(channelDropDown, channel);
						LoggingInfo("Selected Channel as- " + channel);
						setTimeOut(1000);

						// Attempts
						By fstAttempt = getDynamicElement(eleSelectDropDown, "X1st_Attempt");
						waitAndVerifyElement(fstAttempt);
						scrollToElement(fstAttempt);
						String attempt = "SMS";
						selectItemFromList(fstAttempt, attempt);

						// Enter attempt date
						By inputDate = By.xpath("(//input[contains(@name, \"X1st_Attempt_Date\")])[1]");
						String date = Utility_Function.rearrangeDateFormat();
						inputText(inputDate, date);
						setTimeOut(4000);

						// save
						click(eleSubmit);
						setTimeOut(2000);
						break;
					} else {
						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								subjectElement);
						LoggingInfo("Status is collected MI case");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to change sttaus of MI case " + e.getMessage());
			Assert.fail("Failed to change sttaus of MI case  " + e.getMessage());
		}
		return caseNumber;

	}

	/**
	 * Function:Verify steps blocked due to MI
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyStepblocked() {
		try {

			By stepBlockTextField = getDynamicElement(caseTextDetails, "Step blocked due to MI");
			waitAndVerifyElement(stepBlockTextField);
			scrollToElement(stepBlockTextField);
			verifyDetails(stepBlockTextField, "BV;QuickStart;SP Triage;Copay", "Step blocked due to MI");
			LoggingInfo("Validated 'Step blocked due to MI' Information");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Step blocked due to MI " + e.getMessage());
			Assert.fail("Failed to verify Step blocked due to MI  " + e.getMessage());
		}

	}

	/**
	 * Function:Verify HCP account name
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyHCPAccountName(String hcpName) {
		try {

			By hcpAccField = getDynamicElement(strInformationLinkField, "HCP Account Name");
			waitAndVerifyElement(hcpAccField);
			verifyDetails(hcpAccField, hcpName, "HCP Account Name");
			highLightElement(hcpAccField);
			LoggingInfo("Validated 'HCP Account Name' Information");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify HCP Account Name " + e.getMessage());
			Assert.fail("Failed to verify HCP Account Name  " + e.getMessage());
		}

	}

	/**
	 * Function:Search missing field on MI layout
	 * 
	 * @author Trupti Zure
	 **/

	public void searchMissingField(String careProgramEnrollee) {
		try {
			By careProgramMIDropDown = getDynamicElement(serachDropDownListBox, "Care Program MI");
			waitAndVerifyElement(careProgramMIDropDown);
			click(careProgramMIDropDown);
			LoggingInfo("Clicked on Care Program MI dropdown box");
			String miRecord = careProgramEnrollee.split("- ")[1];
			if (miRecord.equalsIgnoreCase("DMW Prurigo Nodularis"))
				miRecord = "DMW PN";
			else if (miRecord.equalsIgnoreCase("DMW Nasal Polyposis"))
				miRecord = "DMW CRSwNP";

			careProgramMI = miRecord + " : Caregiver Missing";
			inputText(careProgramMIDropDown, careProgramMI);
			setTimeOut(2000);
			waitAndVerifyElement(showMoreResultsButton);
			click(showMoreResultsButton);
			setTimeOut(2000);
			LoggingInfo("Clicked on Show more results button");
			waitAndVerifyElement(miRecords);
			click(miRecords);
			LoggingInfo("Selected MI record");
			setTimeOut(3000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Clicked on Show more results button " + e.getMessage());
			Assert.fail("Failed to Clicked on Show more results button  " + e.getMessage());
		}
	}

	/**
	 * Function:Verify MI case information
	 * 
	 * @author Trupti Zure
	 **/

	public String verifyMICaseInformation(String cpeName) {
		try {

			refresh();
			waitForPageLoaded();
			setTimeOut(5000);
			// Case name
			fieldName = careProgramMI.split(": ")[1];
			waitAndVerifyElement(eleCaseName);
			verifyDetails(eleCaseName, fieldName, "Case");

			// status
			By statusField = getDynamicElement(strHeaderTextFields, "Status");
			waitAndVerifyElement(statusField);
			verifyDetails(statusField, status, "Status");

			// care program MI,Patient Journey,Account Name
			cpeName = correctSpaces(cpeName);
			accountName = cpeName.split(" -")[0];
			accountName = correctSpacesAccount(accountName);
			patientJourney = cpeName;
			ArrayList<String> textFieldLinksValues = new ArrayList<>(
					Arrays.asList(careProgramMI, patientJourney, accountName));
			ArrayList<String> textFieldsLinks = new ArrayList<>(
					Arrays.asList("Care Program MI", "Patient Journey", "Account Name"));

			for (int i = 0; i < textFieldLinksValues.size(); i++) {
				if (textFieldLinksValues.get(i) != "") {
					By elementField = getDynamicElement(strInformationLinkField, textFieldsLinks.get(i));
					waitAndVerifyElement(elementField);
					scrollToElement(elementField);
					verifyDetails(elementField, textFieldLinksValues.get(i), textFieldsLinks.get(i));
				}
			}

			// Subject,status,category

			String categoryName = selectCategory();
			ArrayList<String> textFieldValues = new ArrayList<>(Arrays.asList(fieldName, categoryName, status));
			ArrayList<String> textFields = new ArrayList<>(Arrays.asList("Subject", "Category", "Status"));

			for (int i = 0; i < textFieldValues.size(); i++) {
				if (textFieldValues.get(i) != "") {
					By elementTextField = getDynamicElement(caseTextDetails, textFields.get(i));
					waitAndVerifyElement(elementTextField);
					scrollToElement(elementTextField);
					verifyDetails(elementTextField, textFieldValues.get(i), textFields.get(i));
				}
			}
			if (status.equalsIgnoreCase("Collected")) {
				// collected channel, collected date
				if (collectedDate != null) {
					collectedDate = changeDateFormatdmyyyy(collectedDate);
					collectedDate = collectedDate + ", 12:00 PM";
				}
				waitAndVerifyElement(eleCollectedChennel);
				scrollToElement(eleCollectedChennel);

				By collectedChannelField = getDynamicElement(strChannelInformation, "Collected Channel");
				waitAndVerifyElement(collectedChannelField);
				verifyDetails(collectedChannelField, channel, "Collected Channel");

				By collecteDateField = getDynamicElement(strChannelInformation, "Collected Date");
				waitAndVerifyElement(collecteDateField);
				verifyDetails(collecteDateField, collectedDate, "Collected Date");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verified case information " + e.getMessage());
			Assert.fail("Failed to verified case information  " + e.getMessage());
		}
		return accountName;
	}

	/**
	 * Function:Verify Steps blocked due to MI
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyStepsBlockedDutToMI(String number) {
		try {
			boolean numberFound = false;
			if (verifytable("Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
				scrollToElement(eleMissingInfoTable);
				for (WebElement row : rows) {
					WebElement statusElement = row
							.findElement(By.xpath(".//th//a//span[@class=\"slds-truncate\"]//slot"));
					String caseNumber = statusElement.getText().trim();
					if (caseNumber.equals(number)) {
						WebElement stepsBlocked = row.findElement(By.xpath(
								".//td[@data-label=\"Step blocked due to MI\"]//div[@class=\"slds-truncate\"]//span"));
						String stepsBlockeddueToMI = stepsBlocked.getText().trim();
						Assert.assertEquals("BV;QuickStart;SP Triage;Copay", stepsBlockeddueToMI,
								"Steps Blocked due to MI section is populated");
						numberFound = true;
						break;
					}

				}
				Assert.assertTrue(numberFound, "Case Number '" + number + "' not found in the Cases table.");
				LoggingInfo("Verification completed: " + number);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify MI case details-" + e.getMessage());
			Assert.fail("Failed to verify MI case details-" + e.getMessage());
		}
	}

	/**
	 * Function:Verify MI record fields
	 * 
	 * @author Kavyashree
	 **/
	public void validateMIRecordFields() {
		try {
			By eleAccountName = getDynamicElement(strNewCaseFields, "Account Name");
			waitAndVerifyElement(eleAccountName);
			setTimeOut(2000);
			LoggingInfo("Verified Account Name Field");
			By eleHCPAccountName = getDynamicElement(strNewCaseFields, "HCP Account Name");
			waitAndVerifyElement(eleHCPAccountName);
			setTimeOut(2000);
			LoggingInfo("Verified  HCP Account Name Field");
			By elePatientJourney = getDynamicElement(strNewCaseFields, "Patient Journey");
			waitAndVerifyElement(elePatientJourney);
			setTimeOut(2000);
			LoggingInfo("Verified Patient Journey Field");
			By eleCollectedDate = getDynamicElement(strNewCaseFields, "Collected Date");
			waitAndVerifyElement(eleCollectedDate);
			setTimeOut(2000);
			LoggingInfo("Verified  Collected Date  Field");
			By eleCollectedChannel = getDynamicElement(strNewCaseFields, "Collected Channel");
			waitAndVerifyElement(eleCollectedChannel);
			setTimeOut(2000);
			LoggingInfo("Verified  Collected channel Field");
			By eleStatus = getDynamicElement(strNewCaseFields, "Status");
			waitAndVerifyElement(eleStatus);
			setTimeOut(2000);
			LoggingInfo("Verified Status Field");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify MI Record Fields" + e.getMessage());
			Assert.fail("Failed to verify MI Record Fields" + e.getMessage());
		}
	}

	/**
	 * Function:Verify MI record Visibility
	 * 
	 * @author Kavyashree
	 **/
	public void verifyOpenMIRecordsVisibility() {
		try {
			if (verifytable("Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
				for (WebElement row : rows) {

					WebElement statusElement = row
							.findElement(By.xpath(".//td[@data-label=\"Status\"]//lst-formatted-text//span"));
					String status = statusElement.getText().trim();
					if (status.equalsIgnoreCase("Open") || status.equalsIgnoreCase("Not Collected")
							|| status.equalsIgnoreCase("Closed")) {

						WebElement actionButton = row.findElement(By.xpath(".//td//button"));
						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								actionButton);

						actionButton.click();
						setTimeOut(2000);
						waitAndVerifyElement(eleEditButton);
						click(eleEditButton);
						setTimeOut(2000);

						// Update status to "Collected"
						By statusDropDown = getDynamicElement(strDropDownBox, "Status");
						waitAndVerifyElement(statusDropDown);
						scrollToElement(statusDropDown);
						click(statusDropDown);
						setTimeOut(1000);
						By statusDropDownList = getDynamicElement(strDropDownBoxOptions, "Status");
						waitAndVerifyElement(statusDropDownList);
						status = "Collected";
						// Select "Collected" from dropdown
						selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
						LoggingInfo("Selected Status as- " + status);
						setTimeOut(2000);
						clickOnSaveButton();
						setTimeOut(2000);
					} else {
						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								statusElement);
						LoggingInfo("Status is collected for all MI cases");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verified case information " + e.getMessage());
			Assert.fail("Failed to verified case information  " + e.getMessage());
		}
	}

	/**
	 * Function:Click on new button
	 * 
	 * @author Kavyashree
	 **/
	public void clickOnNewButton() {
		try {
			By eleNewCase = getDynamicElement(strNewCaseButton, "New");
			waitAndVerifyElement(eleNewCase);
			click(eleNewCase);
			setTimeOut(2000);
			LoggingInfo("Verified to click on New Case Button");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on New button" + e.getMessage());
			Assert.fail("Failed to click on New button" + e.getMessage());
		}
	}

	/**
	 * Function:Click on new button in Cases section
	 * 
	 * @author Sonica
	 **/
	public void clickOnNewButtonInCase() {
		try {
			By eleNewCaseBtn = getDynamicElement(strNewCaseCM, "New");
			waitAndVerifyElement(eleNewCaseBtn);
			click(eleNewCaseBtn);
			setTimeOut(2000);
			LoggingInfo("Verified to click on New Case Button");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on New button" + e.getMessage());
			Assert.fail("Failed to click on New button" + e.getMessage());
		}
	}

	/**
	 * Function:Click on new relationship button
	 * 
	 * @author Anand
	 **/
	public void clickOnNewRelationshipButton() {
		try {
			By eleNewCase = getDynamicElement(strNewCaseButton, "New Relationship");
			waitAndVerifyElement(eleNewCase);
			clickByJavascript(eleNewCase);
			setTimeOut(2000);
			LoggingInfo("Verified to click on New relationship Button");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on New button" + e.getMessage());
			Assert.fail("Failed to click on New button" + e.getMessage());
		}
	}

	/**
	 * Function: Select care program MI
	 * 
	 * @author Trupti Zure
	 **/

	public void selectCareProgramMI(String miCaseName) {
		try {
			waitAndVerifyElement(eleCareProgramMI);
			inputText(eleCareProgramMI, miCaseName);
			setTimeOut(2000);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
			setTimeOut(2000);
			LoggingInfo("Selected MI case- " + miCaseName);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select care program MI" + e.getMessage());
			Assert.fail("Failed to select care program MI" + e.getMessage());
		}
	}

	/**
	 * Function: Verify case is created
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyCaseIsCreated(String expectedMI) {
		try {

			By eleCareProgramMi = getDynamicElement(strInformationLinkField, "Care Program MI");
			waitAndVerifyElement(eleCareProgramMi);
			verifyDetails(eleCareProgramMi, expectedMI, "Care Program MI");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify MI case is created " + e.getMessage());
			Assert.fail("Failed to verify MI case is created" + e.getMessage());
		}
	}

	/**
	 * Function: Verify case is created
	 * 
	 * @author Trupti Zure
	 **/

	public void navigateToDataList(String dataList) {
		try {

			By eleDataList = getDynamicElement(strDataList, dataList);
			waitAndVerifyElement(eleDataList);
			scrollToElement(eleDataList);
			click(eleDataList);
			setTimeOut(2000);
			LoggingInfo("Navigated to: " + dataList);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate To DataList" + e.getMessage());
			Assert.fail("Failed to navigate To DataList" + e.getMessage());
		}
	}

	/**
	 * Function: Click on field label
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnFieldLabel(String labelName) {
		try {

			By eleLabelName = getDynamicElement(strLabelName, labelName);
			waitAndVerifyElement(eleLabelName);
			scrollToElement(eleLabelName);
			click(eleLabelName);
			setTimeOut(2000);
			LoggingInfo("Clicked on " + labelName);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click On Field Label " + e.getMessage());
			Assert.fail("Failed to to click On Field Label" + e.getMessage());
		}
	}

	/**
	 * Function: Verify pick list value in status field
	 * 
	 * @author Trupti Zure
	 **/

	public void validatePicklistValue() {
		try {
			By frame = By.xpath(
					"//iframe[@title='Care Program Missing Information Custom Field: Status ~ Salesforce - Unlimited Edition']");
			switchToFrame(frame);

			scrollToBottomOfPage();
			waitAndVerifyElement(activeCell);
			scrollToElement(activeCell);
			verifyDetails(activeCell, "Active", "Picklist Value");

			waitAndVerifyElement(inactiveCell);
			verifyDetails(inactiveCell, "Inactive", "Picklist Value");
			getWebDriver().switchTo().defaultContent();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify picklist value" + e.getMessage());
			Assert.fail("Failed to verify picklist value" + e.getMessage());
		}
	}

	/**
	 * Function: Verify categories value
	 * 
	 * @author Trupti Zure
	 **/

	public void validateCategoriesValue() {
		try {
			By frame = By.xpath(
					"//iframe[@title='Care Program Missing Information Custom Field: Categories ~ Salesforce - Unlimited Edition']");
			switchToFrame(frame);

			scrollToBottomOfPage();
			String[] expectedListValues = { "Patient Demographics", "Patient Contact Information", "Consent",
					"Patient Diagnosis", "Prescription Information", "Caregiver Contact Info",
					"Insurance Information (Medical)", "Insurance Information (Pharmacy)", "HCP Demographics",
					"HCP Contact Information", "Specialty Pharmacy", "Enrollment Form", "Financial Documentation" };

			List<WebElement> listValue = getWebDriver().findElements(By.xpath("//tr//th[@scope=\"row\"][1]"));
			boolean isValid = false;
			for (int i = 0; i < listValue.size(); i++) {
				String actualPickListValue = listValue.get(i).getText();
				for (String expectedValue : expectedListValues) {
					if (actualPickListValue.equalsIgnoreCase(expectedValue)) {
						isValid = true;
						break;
					}
				}

				Assert.assertTrue(isValid, "Invalid category value: " + actualPickListValue);
			}
			getWebDriver().switchTo().defaultContent();
			LoggingInfo("Categories values verified");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Categories Value " + e.getMessage());
			Assert.fail("Failed to verify Categories Value" + e.getMessage());
		}
	}

	/**
	 * Function: Verify field label value
	 * 
	 * @author Trupti Zure
	 **/

	public void validateFieldLabelValue() {
		try {

			scrollToBottomOfPage();
			String[] expectedListValues = { "Care Program", "Care Program Missing Information Name", "Categories",
					"Created By", "Field API Name", "Last Modified By", "Legacy Id", "Map Key TECH", "Object API Name",
					"Owner", "Query Field TECH", "Query Object TECH", "Query Where Condition  TECH",
					"Related to Entity", "Services Critical to", "Status", "Therapeutic Area" };

			List<WebElement> listValue = getWebDriver().findElements(By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//tbody//tr//a//span[@class=\"uiOutputText\"]"));
			boolean isValid = false;
			for (int i = 0; i < listValue.size(); i++) {
				String actualPickListValue = listValue.get(i).getText();
				for (String expectedValue : expectedListValues) {
					if (actualPickListValue.equalsIgnoreCase(expectedValue)) {
						isValid = true;
						break;
					}
				}

				Assert.assertTrue(isValid, "Invalid Field label value: " + actualPickListValue);

			}
			LoggingInfo("Field label values verified");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Field Label Value " + e.getMessage());
			Assert.fail("Failed to verify Field Label Value" + e.getMessage());
		}
	}

	/**
	 * Function: Verify steps blocked due to MI
	 * 
	 * @author Shanavaz Nishani
	 **/

	public void verifyStepblockedDueToMI() {
		try {

			By stepBlockTextField = getDynamicElement(caseTextDetails, "Critical for");
			waitAndVerifyElement(stepBlockTextField);
			scrollToElement(stepBlockTextField);
			String stepsBlockeddueToMI = getText(stepBlockTextField);
			if (!stepsBlockeddueToMI.isEmpty()) {
				LoggingInfo("Step blocked due to MI is displayed : " + stepsBlockeddueToMI);
			} else {
				LoggingInfo("Step blocked due to MI is not displayed : " + stepsBlockeddueToMI);
			}
			LoggingInfo("Validated 'Step blocked due to MI' Information");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Step blocked due to MI " + e.getMessage());
			Assert.fail("Failed to verify Step blocked due to MI  " + e.getMessage());
		}

	}

	/**
	 * Function: Verify Layout/fields.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyFieldPresentOnLayout(String fieldLabel) throws Exception {
		try {

			By fieldName = getDynamicElement(strCaseFields, fieldLabel);
			scrollToElement(fieldName);
			boolean found = isElementPresent(fieldName);
			highLightElement(fieldName);
			Assert.assertTrue(found);
			LoggingInfo("Field is present on page layout- " + fieldLabel);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Field " + e.getMessage());
			Assert.fail("Failed to verify Field " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Steps blocked due to MI with casename
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyStepsBlockedDueToMI(List<String> caseNames, List<String> expectedStepsBlocked) {
		try {

			if (verifytable("Open Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
				scrollToElement(eleMissingInfoTable);

				Map<String, String> caseToBlockedStep = new HashMap<>();

				for (WebElement row : rows) {
					WebElement subjectElement = row.findElement(By.xpath(".//td[@data-label=\"Subject\"]//a"));
					String caseNumber = subjectElement.getAttribute("title").trim();
					WebElement stepsBlocked = row.findElement(
							By.xpath(".//td[@data-label=\"Critical for\"]//div[@class=\"slds-truncate\"]//span"));
					String stepsBlockedDueToMI = stepsBlocked.getText().trim();

					caseToBlockedStep.put(caseNumber, stepsBlockedDueToMI);
				}

				for (int i = 0; i < caseNames.size(); i++) {
					String caseName = caseNames.get(i);
					String expectedBlockedStep = expectedStepsBlocked.get(i);
					String actualBlockedStep = caseToBlockedStep.get(caseName);
					if (actualBlockedStep != null) {
						Assert.assertEquals(actualBlockedStep, expectedBlockedStep,
								"Steps Blocked due to MI mismatch for case: " + caseName);
						LoggingInfo("Verification completed: " + caseName);
					} else {
						Assert.fail("Case Name '" + caseName + "' not found in the Cases table.");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify MI case details-" + e.getMessage());
			Assert.fail("Failed to verify MI case details-" + e.getMessage());
		}
	}

	/**
	 * Function:Validate MI Columns
	 * 
	 * @author Trupti Zure
	 **/
	public void validateMIColumns() {
		try {
			String[] columnNames = { "Case Number", "Subject", "Category", "Critical for", "Status", "Collected Date" };

			for (String column : columnNames) {
				By columnLocator = getDynamicElement(strOpenCases, column);
				scrollToElement(columnLocator);
				boolean isDisplayed = isElementDisplayed(columnLocator);
				Assert.assertTrue(isDisplayed, column + " column is not displayed");
				Log.info("Verified '" + column + "' column is present");

			}
			LoggingInfo("Columns are visible on Cases Related List of MI tab on CPE:");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Field Label columns: " + e.getMessage());
			Assert.fail("Failed to verify Field Label columns: " + e.getMessage());
		}
	}

	/**
	 * Function:Validate Case Manager added
	 * 
	 * @author Sonica P
	 **/
	public void validateCaseManagerAdded() {
		try {
			By relatedTab = getDynamicElement(strRelatedTab, "Related");
			click(relatedTab);
			setTimeOut(2000);
			LoggingInfo("Clicked on Related Tab on CPE");
			scrollToElement(eleCpeTeamMem);
			// click(eleCpeTeamMem);
			iapPage.navigateClickToCPETeamMemberTable();
			setTimeOut(2000);
			LoggingInfo("Clicked on Care Program Enrollee Team Members");

			waitAndVerifyElement(eleNewBtnCPE);
			click(eleNewBtnCPE);
			setTimeOut(2000);
			LoggingInfo("Clicked on New button in Care Program Enrollee Team Members");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to create new Case manager " + e.getMessage());
			Assert.fail("Failed to create new Case manager" + e.getMessage());
		}
	}

	/**
	 * Function:Verify New Care Program Team Member
	 * 
	 * @author Sonica P
	 **/
	public void verifyNewCareProgramTeamMember(String dateCareProgram) {
		try {
			String memberName = "SR-0467";

			scrollToElement(eleProgramRole);
			click(eleProgramRole);

			By programRole = getDynamicElement(strDropDownProgramRole, "Case Manager");
			click(programRole);
			setTimeOut(2000);
			LoggingInfo("Click on Program Role and select the Case Manager from the drop down");

			scrollToElement(eleMember);
			click(eleMember);
			inputText(eleMember, memberName);
			setTimeOut(2000);
			LoggingInfo("Click on Program Role and select the Case Manager from the drop down");
			By member = getDynamicElement(strDropDownMember, memberName);
			click(member);
			setTimeOut(2000);
			LoggingInfo("Click on Member name and select from the drop down");

			click(eleStartDate);
			setTimeOut(2000);
			LoggingInfo("Click on Member name and select from the drop down");
			SimpleDateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy");
			Date date = inputFormat.parse(dateCareProgram);
			SimpleDateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy");
			String actualdDate = outputFormat.format(date);
			System.out.println(actualdDate);
			inputText(eleStartDate, actualdDate);

			click(eleSaveBtn);
			setTimeOut(2000);
			LoggingInfo("Clicks on Save button");

			waitAndVerifyElement(eleCTM);
			LoggingInfo("CTM is verified");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to add Case Manager " + e.getMessage());
			Assert.fail("Failed to add Case Manager" + e.getMessage());
		}
	}

	/**
	 * Function:Verify MI Cases created and in open status
	 * 
	 * @author Sonica P
	 **/
	public void validateMICasesCreated() throws Exception {
		try {
			refresh();
			setTimeOut(2000);
			By MItab = getDynamicElement(strRelatedTab, "MI");
			click(MItab);
			setTimeOut(2000);
			LoggingInfo("Click on MI tab on CPE");

			scrollToElement(eleOpenStatus);
			waitAndVerifyElement(eleOpenStatus);
			setTimeOut(2000);
			LoggingInfo("Verify MI case is created and in Open Status");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify MI Case creation in open status " + e.getMessage());
			Assert.fail("Failed to verify MI Case creation in open status" + e.getMessage());
		}
	}

	public void enterCareProgramMI(String miCaseName) {
		try {
			Log.info("Verify user is able to click on new button");
			waitAndVerifyElement(elecareProgramMI);
			click(elecareProgramMI);
			inputText(eleCareProgramMI, miCaseName);
			setTimeOut(5000);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
			setTimeOut(2000);
			LoggingInfo("User enters care program MI");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter care program MI " + e.getMessage());
			Assert.fail("Failed to enter care program MI  " + e.getMessage());
		}
	}

	public void verifyNewMIFields() {

		try {
			setTimeOut(2000);
			By eleSubject = getDynamicElement(strMIFields, "Subject");
			scrollToElement(eleSubject);
			waitAndVerifyElement(eleSubject);

			By eleCategory = getDynamicElement(strMIFields, "Category");
			scrollToElement(eleCategory);
			waitAndVerifyElement(eleCategory);

			By eleStepBlockedDueToMI = getDynamicElement(strMIFields, "Step blocked due to MI");
			scrollToElement(eleStepBlockedDueToMI);
			waitAndVerifyElement(eleStepBlockedDueToMI);

			By eleStatus = getDynamicElement(strMIFields, "Status");
			scrollToElement(eleStatus);
			waitAndVerifyElement(eleStatus);

			LoggingInfo("Verified MI Fields successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify MI Fields " + e.getMessage());
			Assert.fail("Failed to verify MI Fields " + ". Error - " + e.getMessage());

		}

	}

	public void verifyPAPInStepBlocked() {

		try {

			By eleStepBlockedDueToMI = getDynamicElement(strMIFields, "Step blocked due to MI");
			scrollToElement(eleStepBlockedDueToMI);
			waitAndVerifyElement(eleStepBlockedDueToMI);
			String value = getText(eleStepBlockedDueToMI);
			if (value.contains("PAP")) {
				LoggingInfo("Stepped blocked due to MI conatins PAP");
				LoggingInfo("Verified Step blocked due to MI successfully");
			} else {
				LoggingInfo("Stepped blocked due to MI doesnot conatins PAP");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify MI Fields " + e.getMessage());
			Assert.fail("Failed to verify MI Fields " + ". Error - " + e.getMessage());

		}

	}

	public void verifyInProgressStatus(String status) {
		try {
			click(eleOpenCasesLink);
			setTimeOut(2000);
			LoggingInfo("User clicks on Open Cases link ");

			refresh();
			// click(eleCaseNumber);
			clickOnMICase();
			LoggingInfo("User click on the case number present in the Open Cases column");
			setTimeOut(2000);

			By editBtn = getDynamicElement(strEditBtn, "Edit");
			click(editBtn);
			setTimeOut(2000);
			LoggingInfo("User clicks on Edit button");

			scrollToElement(eleStatusField);
			click(eleStatusField);
			setTimeOut(2000);
			By inProgressStatus = getDynamicElement(strDropDownStatus, "In Progress");
			click(inProgressStatus);
			By saveBtn = getDynamicElement(strEditBtn, "SaveEdit");
			click(saveBtn);
			setTimeOut(2000);
			LoggingInfo("User clicks on Save button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify In Progress status " + e.getMessage());
			Assert.fail("Failed to verify In Progress status " + ". Error - " + e.getMessage());

		}
	}

	public void verifyOtherThanInProgressStatus(String status) {
		try {
			By editBtn = getDynamicElement(strEditBtn, "Edit");
			click(editBtn);
			setTimeOut(2000);
			LoggingInfo("User clicks on Edit button");

			scrollToElement(eleStatusField);
			click(eleStatusField);
			setTimeOut(2000);
			LoggingInfo("User clicks on status field");

			By inProgressStatus = getDynamicElement(strDropDownStatus, "Not Collected");
			click(inProgressStatus);
			By saveBtn = getDynamicElement(strEditBtn, "SaveEdit");
			click(saveBtn);
			setTimeOut(2000);
			LoggingInfo("User selects Collected as status and clicks on Save button");

			waitAndVerifyElement(eleErrorMsg);
			By cancelBtn = getDynamicElement(strEditBtn, "CancelEdit");
			click(cancelBtn);
			setTimeOut(2000);
			LoggingInfo("User clicks on Cancel button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Collected status " + e.getMessage());
			Assert.fail("Failed to verify Collected status " + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function:Verify To click on bulk close
	 * 
	 * @author Kavyashree
	 **/
	public void clickOnBulkClose() {

		try {
			By eleSelect = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Case Number\"]//ancestor::th//preceding-sibling::th//span[@class=\"slds-checkbox\"]");
			scrollToElement(eleSelect);
			waitAndVerifyElement(eleSelect);
			click(eleSelect);
			setTimeOut(2000);

			By eleBulkCloseButton = getDynamicElement(eleButton, "Bulk Close");
			scrollToElement(eleBulkCloseButton);
			waitAndVerifyElement(eleBulkCloseButton);
			clickByJavascript(eleBulkCloseButton);
			setTimeOut(8000);
			LoggingInfo("Clicked on Bulk Close");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on bulk close " + e.getMessage());
			Assert.fail("Failed to click on bulk close " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify to select status as collected
	 * 
	 * @author Kavyashree
	 **/

	public void verifyStatusCollected() {

		try {
			setTimeOut(10000);
			By frame = By.xpath("(//iframe[@title='Salesforce - Unlimited Edition'])[1]");
			Utility_Function.switchToFrame2(frame);

			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
			waitAndVerifyElement(statusDropDownList);
			String status = "Collected";
			// Select "Collected" from dropdown
			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(2000);

			By statusDropDown3 = getDynamicElement(elestrDropDownBox, "1st Attempt");
			waitAndVerifyElement(statusDropDown3);
			LoggingInfo("verified 1st attempt field");

			By inputTime = By.xpath("(//input[@name=\"X1st_Attempt_Date\"])[2]");
			waitAndVerifyElement(inputTime);
			LoggingInfo("verified 1st attempt field date amd time");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify status as collected and 1st Attempt and Attempt Date " + e.getMessage());
			Assert.fail("Failed to verify status as collected and 1st Attempt and Attempt Date " + ". Error - "
					+ e.getMessage());

		}

	}

	/**
	 * Function:Verify Not Applicable option under 1st,2nd and 3rd attempt
	 * 
	 * @author Kavyashree
	 **/

	public void verifyNotApplicable() {

		try {

			// 1st Attempt
			By statusDropDown2 = getDynamicElement(elestrDropDownBox, "Collected Channel");
			By statusDropDown3 = getDynamicElement(elestrDropDownBox, "1st Attempt");
			waitAndVerifyElement(statusDropDown3);
			scrollToElement(statusDropDown3);
			click(statusDropDown3);
			setTimeOut(1000);
			By statusDropDownList3 = getDynamicElement(elestrDropDownList, "X1st_Attempt");
			waitAndVerifyElement(statusDropDownList3);
			String attempt = "Not Applicable";

			selectItemFromList(statusDropDown2, statusDropDownList3, attempt, "X1st_Attempt");
			LoggingInfo("Selected attempt as- " + status);
			setTimeOut(1000);

			// 2nd Attempt

			By statusDropDown4 = getDynamicElement(elestrDropDownBox, "2nd Attempt");
			waitAndVerifyElement(statusDropDown4);
			scrollToElement(statusDropDown4);
			click(statusDropDown4);
			setTimeOut(1000);
			By statusDropDownList4 = getDynamicElement(elestrDropDownList, "X2nd_Attempt");
			waitAndVerifyElement(statusDropDownList4);

			selectItemFromList(statusDropDown2, statusDropDownList4, attempt, "X2nd_Attempt");
			LoggingInfo("Selected attempt as- " + status);
			setTimeOut(1000);

			// 3rd Attempt

			By statusDropDown5 = getDynamicElement(elestrDropDownBox, "3rd Attempt");
			waitAndVerifyElement(statusDropDown5);
			scrollToElement(statusDropDown5);
			click(statusDropDown5);
			setTimeOut(1000);
			By statusDropDownList5 = getDynamicElement(elestrDropDownList, "X3rd_Attempt");
			waitAndVerifyElement(statusDropDownList5);

			selectItemFromList(statusDropDown2, statusDropDownList5, attempt, "X3rd_Attempt");
			LoggingInfo("Selected attempt as- " + status);
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select not applicable option " + e.getMessage());
			Assert.fail("Failed to select not applicable option " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify Reason dependent field
	 * 
	 * @author Kavyashree
	 **/

	public void verifyReasonField() {

		try {

			By reason1 = getDynamicElement(strReasonField, "Reason1");
			waitAndVerifyElement(reason1);
			setTimeOut(1000);
			LoggingInfo("Verified Reason1 field");
			setTimeOut(1000);

			By reason2 = getDynamicElement(strReasonField, "Reason2");
			waitAndVerifyElement(reason2);
			setTimeOut(1000);
			LoggingInfo("Verified Reason2 field");
			setTimeOut(1000);

			By reason3 = getDynamicElement(strReasonField, "Reason3");
			waitAndVerifyElement(reason3);
			setTimeOut(1000);
			LoggingInfo("Verified Reason3 field");
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify reason field" + e.getMessage());
			Assert.fail("Failed to verify reason field " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify To select enrollment oversight under reason dropdown
	 * 
	 * @author Kavyashree
	 **/

	public void selectReason() {

		try {
			By statusDropDown3 = getDynamicElement(elestrDropDownBox, "1st Attempt");
			By reasondropdown1 = getDynamicElement(strReasondropdown, "Reason1");
			waitAndVerifyElement(reasondropdown1);

			scrollToElement(reasondropdown1);
			click(reasondropdown1);
			setTimeOut(1000);
			By reasonDropDownList3 = getDynamicElement(elestrDropDownList, "Reason1");
			waitAndVerifyElement(reasonDropDownList3);
			String reason = "Enrollment Oversight";

			selectItemFromList(statusDropDown3, reasonDropDownList3, reason, "Reason1");
			LoggingInfo("Selected attempt as- " + status);
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify reason field" + e.getMessage());
			Assert.fail("Failed to verify reason field " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify To close MI
	 * 
	 * @author Kavyashree
	 **/

	public void verifyToCloseMI() {

		try {
			setTimeOut(1000);
			waitAndVerifyElement(eleMIRecord);
			setTimeOut(2000);
			click(eleClose);
			setTimeOut(2000);
			LoggingInfo("Verified close button");
			setTimeOut(1000);

			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
			waitAndVerifyElement(statusDropDownList);
			String status = "Not Collected";
			// Select "Collected" from dropdown
			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(2000);

			click(eleSubmit);
			setTimeOut(1000);
			waitAndVerifyElement(eleAttemptError);
			click(eleCancelandClose);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify error message for 1st attempt field" + e.getMessage());
			Assert.fail("Failed to verify error message for 1st attempt field  " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify cancelled status
	 * 
	 * @author Kavyashree
	 **/

	public void verifyCancelledStatus() {

		try {
			setTimeOut(1000);
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			LoggingInfo("Status verified");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify status" + e.getMessage());
			Assert.fail("Failed to verify status " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify Open Status for created MI
	 * 
	 * @author Kavyashree
	 **/
	public void verifyMIOpenStatus() {
		try {
			if (verifytable("Open Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
				boolean allCollected = true;

				for (WebElement row : rows) {
					WebElement statusElement = row
							.findElement(By.xpath(".//td[@data-label=\"Status\"]//lst-formatted-text//span"));
					String status = statusElement.getText().trim();

					if (status.equalsIgnoreCase("Open")) {
						allCollected = false;
						break;
					}
				}

				if (!allCollected) {
					Log.info(" Open Status verified for created MI");

				} else {
					LoggingInfo("Failed to verify Open Status  for created MI");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Open Status verified for created MI " + e.getMessage());
			Assert.fail("Failed to verify Open Status verified for created MI " + e.getMessage());

		}
	}

	/**
	 * Function:Verify Attempt type and date field
	 * 
	 * @author Kavyashree
	 **/

	public void verifyMIAttemptFields() {

		try {
			By eleFirstAttempt = getDynamicElement(strAttemptFields, "1st Attempt");
			waitAndVerifyElement(eleFirstAttempt);

			By eleSecondAttempt = getDynamicElement(strAttemptFields, "2nd Attempt");
			waitAndVerifyElement(eleSecondAttempt);

			By eleThirdAttempt = getDynamicElement(strAttemptFields, "3rd Attempt");
			waitAndVerifyElement(eleThirdAttempt);

			By ele1stAttemptdate = getDynamicElement(strAttemptFields, "1st Attempt Date");
			waitAndVerifyElement(ele1stAttemptdate);

			By ele2ndAttemptdate = getDynamicElement(strAttemptFields, "2nd Attempt Date");
			waitAndVerifyElement(ele2ndAttemptdate);

			By ele3rdAttemptdate = getDynamicElement(strAttemptFields, "2nd Attempt Date");
			waitAndVerifyElement(ele3rdAttemptdate);

			LoggingInfo("verified attempt type and date field");
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Attempt type and date field" + e.getMessage());
			Assert.fail("Failed to verify Attempt type and date field " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify MI Close button
	 * 
	 * @author Kavyashree
	 **/

	public void verifyCloseButton() {

		try {
			waitAndVerifyElement(eleCloseButton);
			click(eleCloseButton);

			LoggingInfo("verified close button");
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify close button" + e.getMessage());
			Assert.fail("Failed to verify close button" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify MI Status Fields in close pop-up
	 * 
	 * @author Kavyashree
	 **/

	public void verifyStatusFields() {

		try {

			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
			waitAndVerifyElement(statusDropDownList);
			String status = "Collected";
			// Select "Collected" from dropdown
			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(2000);

			LoggingInfo("verified Status Fields");
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify status Field" + e.getMessage());
			Assert.fail("Failed to verify status Field" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify Not Applicable Value in close pop-up
	 * 
	 * @author Kavyashree
	 **/

	public void verifyNotApplicableValue() {

		try {

			By statusDropDown2 = getDynamicElement(elestrDropDownBox, "Collected Channel");
			By statusDropDown3 = getDynamicElement(elestrDropDownBox, "1st Attempt");
			waitAndVerifyElement(statusDropDown3);
			scrollToElement(statusDropDown3);
			click(statusDropDown3);
			setTimeOut(1000);
			By statusDropDownList3 = getDynamicElement(elestrDropDownList, "X1st_Attempt");
			waitAndVerifyElement(statusDropDownList3);
			String attempt = "Not Applicable";

			selectItemFromList(statusDropDown2, statusDropDownList3, attempt, "X1st_Attempt");
			LoggingInfo("Selected attempt as- " + status);
			setTimeOut(1000);

			// 2nd Attempt

			By statusDropDown4 = getDynamicElement(elestrDropDownBox, "2nd Attempt");
			waitAndVerifyElement(statusDropDown4);
			scrollToElement(statusDropDown4);
			click(statusDropDown4);
			setTimeOut(1000);
			By statusDropDownList4 = getDynamicElement(elestrDropDownList, "X2nd_Attempt");
			waitAndVerifyElement(statusDropDownList4);

			selectItemFromList(statusDropDown2, statusDropDownList4, attempt, "X2nd_Attempt");
			LoggingInfo("Selected attempt as- " + status);
			setTimeOut(1000);

			// 3rd Attempt

			By statusDropDown5 = getDynamicElement(elestrDropDownBox, "3rd Attempt");
			waitAndVerifyElement(statusDropDown5);
			scrollToElement(statusDropDown5);
			click(statusDropDown5);
			setTimeOut(1000);
			By statusDropDownList5 = getDynamicElement(elestrDropDownList, "X3rd_Attempt");
			waitAndVerifyElement(statusDropDownList5);

			selectItemFromList(statusDropDown2, statusDropDownList5, attempt, "X3rd_Attempt");
			LoggingInfo("Selected attempt as- " + status);
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select not applicable option " + e.getMessage());
			Assert.fail("Failed to select not applicable option " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify Reason field in close pop-up
	 * 
	 * @author Kavyashree
	 **/

	public void verifyReason() {

		try {

			By reason1 = getDynamicElement(strReasonField, "Reason1");
			waitAndVerifyElement(reason1);
			setTimeOut(1000);
			LoggingInfo("Verified Reason1 field");
			setTimeOut(1000);

			By reason2 = getDynamicElement(strReasonField, "Reason2");
			waitAndVerifyElement(reason2);
			setTimeOut(1000);
			LoggingInfo("Verified Reason2 field");
			setTimeOut(1000);

			By reason3 = getDynamicElement(strReasonField, "Reason3");
			waitAndVerifyElement(reason3);
			setTimeOut(1000);
			LoggingInfo("Verified Reason3 field");
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify reason field" + e.getMessage());
			Assert.fail("Failed to verify reason field " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify validation rule for not collected status
	 * 
	 * @author Kavyashree
	 **/

	public void verifyValidationForNotCollected() {

		try {

			setTimeOut(2000);

			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
			waitAndVerifyElement(statusDropDownList);
			String status = "Not Collected";
			// Select "Collected" from dropdown
			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(2000);

			click(eleSubmit);
			setTimeOut(1000);
			waitAndVerifyElement(eleAttemptError);
			click(eleCancelandClose);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify error message for 1st attempt field" + e.getMessage());
			Assert.fail("Failed to verify error message for 1st attempt field  " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify cancel button
	 * 
	 * @author Kavyashree
	 **/

	public void verifyCancelButton() {

		try {

			setTimeOut(2000);
			waitAndVerifyElement(eleCancel);
			click(eleCancel);
			LoggingInfo("Verified Cancel Button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Cancel Button" + e.getMessage());
			Assert.fail("Failed to verify Cancel Button  " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify cancel Message
	 * 
	 * @author Kavyashree
	 **/

	public void verifyCancelMessage() {

		try {

			setTimeOut(2000);
			waitAndVerifyElement(eleCancelMessage);
			LoggingInfo("Verified Cancel Message");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Cancel Message" + e.getMessage());
			Assert.fail("Failed to verify Cancel Message  " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify cancel Yes and No button
	 * 
	 * @author Kavyashree
	 **/

	public void verifyButtons() {

		try {
			By eleYesButton = getDynamicElement(strCancelRadioButton, "Yes");
			By eleNoButton = getDynamicElement(strCancelRadioButton, "No");

			setTimeOut(2000);
			waitAndVerifyElement(eleYesButton);
			waitAndVerifyElement(eleNoButton);
			LoggingInfo("Verified Yes and No Button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Yes and No Button" + e.getMessage());
			Assert.fail("Failed to verify Yes and No Button  " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify to select No when user clicks on cancel button
	 * 
	 * @author Kavyashree
	 **/

	public void selectNo() {

		try {
			By eleNoButton = getDynamicElement(strCancelRadioButton, "Yes_No.No");
			click(eleNoButton);
			click(eleSubmit);
			LoggingInfo("Verified to select No");
			setTimeOut(2000);
			waitAndVerifyElement(eleOpenStatus);
			LoggingInfo("Verified Open status");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select No" + e.getMessage());
			Assert.fail("Failed to select No  " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify to select Yes when user clicks on cancel button
	 * 
	 * @author Kavyashree
	 **/

	public void selectYes() {

		try {

			By eleYesButton = getDynamicElement(strCancelRadioButton, "Yes_No.Yes");
			click(eleYesButton);
			click(eleSubmit);
			LoggingInfo("Verified to select Yes");
			setTimeOut(2000);
			waitAndVerifyElement(eleCancelledStatus);
			LoggingInfo("Verified Cancelled status");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Cancelled Status" + e.getMessage());
			Assert.fail("Failed to verify Cancelled Status  " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify to Select the Status as Not Collected on the status field and
	 * fill all the fields on the page layout and Click on Submit Button
	 * 
	 * @author Kavyashree
	 **/

	public void selectNotCollected() {

		try {

			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
			waitAndVerifyElement(statusDropDownList);
			String status = "Not Collected";
			// Select "Collected" from dropdown
			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(2000);

			// Select attempt
			By statusDropDown3 = getDynamicElement(elestrDropDownBox, "1st Attempt");
			waitAndVerifyElement(statusDropDown3);
			scrollToElement(statusDropDown3);
			click(statusDropDown3);
			setTimeOut(1000);
			By statusDropDownList3 = getDynamicElement(elestrDropDownList, "X1st_Attempt");
			waitAndVerifyElement(statusDropDownList3);
			String attempt = "Fax";
			By statusDropDown2 = getDynamicElement(elestrDropDownBox, "Collected Channel");
			// Select "Fax" from dropdown
			selectItemFromList(statusDropDown2, statusDropDownList3, attempt, "X1st_Attempt");
			LoggingInfo("Selected attempt as- " + status);
			setTimeOut(1000);

			// Enter attempt date
			By inputDate = By.xpath("(//input[@name=\"X1st_Attempt_Date\"])[1]");
			String date = Utility_Function.rearrangeDateFormat();
			inputText(inputDate, date);
			setTimeOut(4000);

			By inputTime = By.xpath("(//input[@name=\"X1st_Attempt_Date\"])[2]");
			click(inputTime);

			clickOnSubmitButton();
			setTimeOut(4000);

			LoggingInfo(
					"Verified  to Select the Status as Not Collected on the status field and fill all the fields on the page layout and Click on Submit Button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error(
					"Failed  Verify to Select the Status as Not Collected on the status field and fill all the fields on the page layout and Click on Submit Button"
							+ e.getMessage());
			Assert.fail(
					"Failed Verify to Select the Status as Not Collected on the status field and fill all the fields on the page layout and Click on Submit Button "
							+ ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify to Select the Status as Collected on the status field and
	 * fill all the fields on the page layout and Click on Next Button
	 * 
	 * @author Kavyashree
	 **/

	public void selectCollected() {

		try {

			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
			waitAndVerifyElement(statusDropDownList);
			String status = "Collected";
			// Select "Collected" from dropdown
			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(2000);

			// Select attempt
			By statusDropDown3 = getDynamicElement(elestrDropDownBox, "1st Attempt");
			waitAndVerifyElement(statusDropDown3);
			scrollToElement(statusDropDown3);
			click(statusDropDown3);
			setTimeOut(1000);
			By statusDropDownList3 = getDynamicElement(elestrDropDownList, "X1st_Attempt");
			waitAndVerifyElement(statusDropDownList3);
			String attempt = "Fax";
			By statusDropDown2 = getDynamicElement(elestrDropDownBox, "Collected Channel");
			// Select "Fax" from dropdown
			selectItemFromList(statusDropDown2, statusDropDownList3, attempt, "X1st_Attempt");
			LoggingInfo("Selected attempt as- " + status);
			setTimeOut(1000);

			// Enter attempt date
			By inputDate = By.xpath("(//input[@name=\"X1st_Attempt_Date\"])[1]");
			String date = Utility_Function.rearrangeDateFormat();
			inputText(inputDate, date);
			setTimeOut(4000);

			By inputTime = By.xpath("(//input[@name=\"X1st_Attempt_Date\"])[2]");
			click(inputTime);

			clickOnSubmitButton();
			setTimeOut(4000);

			LoggingInfo(
					"Verified  to Select the Status as Collected on the status field and fill all the fields on the page layout and Click on Submit Button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error(
					"Failed  Verify to Select the Status as Collected on the status field and fill all the fields on the page layout and Click on Submit Button"
							+ e.getMessage());
			Assert.fail(
					"Failed Verify to Select the Status as Collected on the status field and fill all the fields on the page layout and Click on Submit Button "
							+ ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify validation rule for collected status
	 * 
	 * @author Kavyashree
	 **/

	public void verifyValidationForCollected() {

		try {

			setTimeOut(2000);

			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
			waitAndVerifyElement(statusDropDownList);
			String status = "Collected";
			// Select "Collected" from dropdown
			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(2000);

			click(eleSubmit);
			setTimeOut(1000);
			waitAndVerifyElement(eleAttemptError);
			click(eleCancelandClose);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify error message for 1st attempt field" + e.getMessage());
			Assert.fail("Failed to verify error message for 1st attempt field  " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify to edit and change MI Status
	 * 
	 * @author Kavyashree
	 **/

	public void changeMIStatus(String Status) {

		try {
			setTimeOut(2000);
			scrollToElement(eleeditButton);
			click(eleeditButton);
			setTimeOut(1000);

			By statusDropDown = getDynamicElement(streditdropdown, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(streditdropdownlist, "Status");
			waitAndVerifyElement(statusDropDownList);

			// Select "Collected" from dropdown
			selectItemFromList(statusDropDown, statusDropDownList, "In Progress", "Status");
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(2000);
			click(eleSaveBtn);
			setTimeOut(4000);
			LoggingInfo("Changed status to collected ");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to change status" + e.getMessage());
			Assert.fail("Failed to change status  " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify to click on record based on Case number
	 * 
	 * @author Kavyashree
	 **/

	public void clickOnRecordBasedOnCaseNo(String casenumber) {

		try {
			setTimeOut(2000);
			By elecase = getDynamicElement(strAttemptFields, casenumber);
			waitAndVerifyElement(elecase);
			scrollToElement(elecase);
			click(elecase);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on record " + e.getMessage());
			Assert.fail("Failed to click on record  " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Verify MI record in closed cases table
	 * 
	 * @author kavyashree MB
	 **/

	public void verifyRecordInClosedCaseList(String number) {
		try {
			boolean numberFound = false;
			if (verifytable("Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoClosedTable);
				scrollToElement(eleMissingInfoClosedTable);
				for (WebElement row : rows) {
					WebElement statusElement = row
							.findElement(By.xpath(".//th//a//span[@class=\"slds-truncate\"]//slot"));
					String caseNumber = statusElement.getText().trim();
					if (caseNumber.equals(number)) {
						numberFound = true;
						break;
					}

				}
				Assert.assertTrue(numberFound, "Case Number '" + number + "' not found in the Cases table.");
				LoggingInfo("Verification completed for case number: " + number);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify case number-" + e.getMessage());
			Assert.fail("Failed to verify case number" + e.getMessage());
		}
	}

	/**
	 * Function: Verify Layout/fields.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyFieldPresenceOnLayout(String fieldLabel) throws Exception {
		try {
			scrollToHalfPage();
			String strField = "//*[contains(@class,\"active lafPageHost\")]//record_flexipage-record-field//*[text()=\"{0}\"]";
			By fieldName = getDynamicElement(strField, fieldLabel);
			scrollToElement(fieldName);
			boolean found = isElementPresent(fieldName);
			highLightElement(fieldName);
			Assert.assertTrue(found);
			LoggingInfo("Field is present on page layout- " + fieldLabel);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Field " + e.getMessage());
			Assert.fail("Failed to verify Field " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Field Label Values for Object Manager(In Field and
	 * relationships).
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateFieldLabelValueforObjectManager(String FieldLabel) {
		List<WebElement> listValues = getWebDriver().findElements(
				By.xpath("//*[contains(@class,\"active lafPageHost\")]//tbody//tr//a//span[@class=\"uiOutputText\"]"));
		boolean isValid = false;
		for (WebElement listValue : listValues) {
			String actualFieldValue = listValue.getText();
			if (actualFieldValue.equalsIgnoreCase(FieldLabel)) {
				isValid = true;
				Assert.assertTrue(isValid, actualFieldValue + " is present in the list of field labels");
				break;
			}
		}
		LoggingInfo("Field label values verified");
	}

	/**
	 * Function: Verify table name
	 * 
	 * @author Trupti Zure
	 **/

	public void validateMITableName() {
		try {
			boolean tablename = false;
			Log.info("Validate Table name is changed to 'Open Cases'");
			tablename = isElementDisplayed(eleMITableName);
			Assert.assertTrue(tablename, "Table name is open case");
			LoggingInfo("MI cases under MI tab are in Open status and visible in Open Cases related list");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Field name" + e.getMessage());
			Assert.fail("Failed to verify Field name" + e.getMessage());
		}
	}

	/**
	 * Function: Update status of MI case
	 * 
	 * @author Trupti Zure
	 **/

	public String updateStatusOfCreatedMICase(String actualstatus, String tableName, String expectedStatus) {
		String caseNumber = null;
		try {

			String eleRowXPath = String.format(
					"//*[contains(@class,'active lafPageHost')]//table[@aria-label='%s']//tbody//tr", tableName);

			By tableRowLocator = By.xpath(eleRowXPath);

			if (verifytable(tableName)) {
				List<WebElement> rows = getWebDriver().findElements(tableRowLocator);
				scrollToElement(tableRowLocator);

				for (WebElement row : rows) {
					WebElement eleStatus = row
							.findElement(By.xpath(".//td[@data-label='Status']//lst-formatted-text//span"));
					String miStatus = eleStatus.getAttribute("title");

					if (actualstatus.equalsIgnoreCase(miStatus)) {

						// Get case number from the current row

						WebElement elCaseNumber = row.findElement(By.xpath(".//th[@data-label='Case Number']//a"));
						JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
						caseNumber = (String) js.executeScript("return arguments[0].innerText;", elCaseNumber);

						LoggingInfo("Case number - " + caseNumber);

						WebElement actionButton = row.findElement(By.xpath(".//td//button"));
						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								actionButton);
						actionButton.click();
						setTimeOut(2000);

						waitAndVerifyElement(eleEditButton);
						click(eleEditButton);
						setTimeOut(2000);

						// Update status
						By statusDropDown = getDynamicElement(strDropDownBox, "Status");
						waitAndVerifyElement(statusDropDown);
						scrollToElement(statusDropDown);
						click(statusDropDown);
						setTimeOut(1000);

						By statusDropDownList = getDynamicElement(strDropDownBoxOptions, "Status");
						waitAndVerifyElement(statusDropDownList);
						selectItemFromList(statusDropDown, statusDropDownList, expectedStatus, "Status");

						LoggingInfo("Selected Status as - " + expectedStatus);
						setTimeOut(2000);
						clickOnSaveButton();
						setTimeOut(2000);

						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to change status of MI case: " + e.getMessage());
			Assert.fail("Failed to change status of MI case: " + e.getMessage());
		}

		return caseNumber;
	}

	/**
	 * Function: Verify case presences in MI table with case number
	 * 
	 * @author Trupti Zure
	 **/

	public void validateCasePresence(String caseNumber, String table) {
		try {
			scrollToHalfPage();

			String eleRowXPath = String
					.format("//*[contains(@class,'active lafPageHost')]//table[@aria-label='%s']//tbody//tr", table);

			By tableRowLocator = By.xpath(eleRowXPath);

			if (verifytable(table)) {
				waitForvisiblityOfElementLocated(tableRowLocator);

				List<WebElement> rows = getWebDriver().findElements(tableRowLocator);
				scrollToElement(tableRowLocator);

				LoggingInfo("Checking case numbers in table: " + table);
				LoggingInfo("Total rows found: " + rows.size());

				for (WebElement row : rows) {
					try {
						WebElement caseCell = row.findElement(By.xpath(".//th//a"));

						JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
						String caseNumberInRow = (String) js.executeScript("return arguments[0].innerText;", caseCell);

						caseNumberInRow = caseNumberInRow.trim();
						LoggingInfo("Found in row: " + caseNumberInRow);

						if (caseNumberInRow.equalsIgnoreCase(caseNumber.trim())) {
							LoggingInfo("Case number matched: " + caseNumber);
							return;
						}
					} catch (Exception inner) {
						LoggingInfo("Skipping row due to error: " + inner.getMessage());
					}
				}

				// Case not found after checking all rows
				Log.error("Case number NOT found in table: " + caseNumber);
				Assert.fail("Case number not found in table: " + caseNumber);
			} else {
				Log.error("Table not found: " + table);
				Assert.fail("Table not found: " + table);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Error while verifying case number: " + e.getMessage());
			Assert.fail("Error while verifying case number: " + e.getMessage());
		}
	}

	/**
	 * Function: Verify status column state
	 * 
	 * @author Trupti Zure
	 **/
	public void validateStatusColumnState() {
		try {

			waitAndVerifyElement(eleStatusState);
			scrollToElement(eleStatusState);
			String state = getText(eleStatusState);
			Assert.assertEquals(state, "Sorted Descending", "Status State verified");
			LoggingInfo("Status column is sorted in Descending order");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Error while verifying case number: " + e.getMessage());
			Assert.fail("Error while verifying case number: " + e.getMessage());
		}
	}

	/**
	 * Function: Verify collected date column state
	 * 
	 * @author Trupti Zure
	 **/
	public void validateCollectedDateColumnState() {
		try {

			waitAndVerifyElement(eleCollectedDateState);
			scrollToElement(eleCollectedDateState);
			String state = getText(eleCollectedDateState);
			Assert.assertEquals(state, "Sorted Descending", "Collected date State verified");
			LoggingInfo("Collected date column is sorted in Descending order");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Error while verifying case number: " + e.getMessage());
			Assert.fail("Error while verifying case number: " + e.getMessage());
		}
	}

	/**
	 * Function: update MI case status
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void MIcasesStatusUpdate(String tableName, String status) throws Exception {
		String strCaserec = "//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"{0}\"]//tbody//tr//th//a//ancestor::lightning-primitive-custom-cell";
		By eleCaserec = getDynamicElement(strCaserec, tableName);
		click(eleCaserec);

		By closebtn = By.xpath("//button[text()='Close']");
		click(closebtn);

		By statusDropDown = getDynamicElement(elestrDropDownBox, "Copy_1_of_Status");
		waitAndVerifyElement(statusDropDown);
		scrollToElement(statusDropDown);
		click(statusDropDown);
		setTimeOut(1000);

		By statusDropDownList = getDynamicElement(elestrDropDownList, "Copy_1_of_Status");
		waitAndVerifyElement(statusDropDownList);

		// Select "Collected" from dropdown
		selectItemFromList(statusDropDown, statusDropDownList, status, "Copy_1_of_Status");
		LoggingInfo("Selected Status as- " + status);
		setTimeOut(2000);

		// Select Collected Channel
		if (status.equalsIgnoreCase("Collected")) {
			By statusDropDown2 = getDynamicElement(elestrDropDownBox, "Copy_1_of_Collected_Channel");
			waitAndVerifyElement(statusDropDown2);
			scrollToElement(statusDropDown2);
			click(statusDropDown2);
			setTimeOut(1000);
			By statusDropDownList2 = getDynamicElement(elestrDropDownList, "Copy_1_of_Collected_Channel");
			waitAndVerifyElement(statusDropDownList2);
			String channel = "Phone";
			// Select "Phone" from dropdown
			selectItemFromList(statusDropDown2, statusDropDownList2, channel, "Copy_1_of_Collected_Channel");
			LoggingInfo("Selected Channel as- " + channel);
			setTimeOut(1000);
		}

		ArrayList<String> eleAttemptField = new ArrayList<String>(
				Arrays.asList("1st Attempt", "2nd Attempt", "3rd Attempt"));
		ArrayList<String> eleAttempt = new ArrayList<String>(
				Arrays.asList("Copy_1_of_X1st_Attempt", "Copy_1_of_X2nd_Attempt", "Copy_1_of_X3rd_Attempt"));
		ArrayList<String> eleAttemptDate = new ArrayList<String>(Arrays.asList("Copy_1_of_X1st_Attempt_Date",
				"Copy_1_of_X2nd_Attempt_Date", "Copy_1_of_X3rd_Attempt_Date"));
		for (int i = 0; i < eleAttemptDate.size(); i++) {
			String attepmtDate = eleAttemptDate.get(i);
			String attemptNo = eleAttempt.get(i);
			String attemptField = eleAttempt.get(i);
			By statusDropDown3 = getDynamicElement(elestrDropDownBox, attemptField);
			waitAndVerifyElement(statusDropDown3);
			scrollToElement(statusDropDown3);
			click(statusDropDown3);
			setTimeOut(1000);
			By statusDropDownList3 = getDynamicElement(elestrDropDownList, attemptNo);
			waitAndVerifyElement(statusDropDownList3);
			String attempt = "Fax";

			// Select "Fax" from dropdown
			selectItemFromList(statusDropDown3, statusDropDownList3, attempt, attemptNo);
			LoggingInfo("Selected attempt as- " + attempt);
			setTimeOut(1000);
			// String attepmtTime = eleAttemptTime.get(i);

			By inputDate = By.xpath("(//input[@name='" + attepmtDate + "'])[1]");
			String date = Utility_Function.rearrangeDateFormat();
			inputText(inputDate, date);
			setTimeOut(4000);

			By inputTime = By.xpath("(//input[@name='" + attepmtDate + "'])[2]");
			click(inputTime);
		}

		clickOnSubmitButton();
		setTimeOut(2000);
	}

	public void validateCaseOwner(String caseOwner) {
		try {
			waitForPageLoaded();
			By eleowner = getDynamicElement(compactLayoutLinkField, "Case Owner");
			waitAndVerifyElement(eleowner);
			scrollToElement(eleowner);
			verifyDetails(eleowner, caseOwner, "Case Owner");
			LoggingInfo("Verified Case owner");
		} catch (Exception e) {
			Log.error("Failed to verify Case owner " + e.getMessage());
			Assert.fail("Failed to verify case owner " + e.getMessage());
		}

	}

	public void verifyMIIconIsDisplayed() {
		try {
			scrollToTopOfPage();
			boolean iconFound = false;
			By icon = By.xpath("//img[contains(@src,\"BlockedbyMI\")]");
			iconFound = isElementDisplayed(icon);
			Assert.assertTrue(iconFound, "Image is not displayed");
			LoggingInfo("A warning symbol is visible on highlight panel 'MI' field");
		} catch (Exception e) {
			Log.error("Failed to verify warning sign " + e.getMessage());
			Assert.fail("Failed to verify warning sign " + e.getMessage());
		}
	}

	public void verifyOpenMIRecords() {
		try {
			if (verifytable("Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
				for (WebElement row : rows) {
					WebElement statusElement = row
							.findElement(By.xpath(".//td[@data-label=\"Status\"]//lst-formatted-text//span"));
					String status = statusElement.getText().trim();

					if (status.equalsIgnoreCase("Open")) {
						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								statusElement);
						LoggingInfo("Status is OPEN for a case.");
					} else {
						LoggingInfo("Status is NOT OPEN for this case: " + status);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify case statuses: " + e.getMessage());
			Assert.fail("Failed to verify case statuses: " + e.getMessage());
		}
		try {
			if (verifytable("Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
				for (WebElement row : rows) {
					WebElement statusElement = row
							.findElement(By.xpath(".//td[@data-label=\"Status\"]//lst-formatted-text//span"));
					String status = statusElement.getText().trim();

					if (status.equalsIgnoreCase("Open")) {
						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								statusElement);
						LoggingInfo("Status is OPEN for a case.");
					} else {
						LoggingInfo("Status is NOT OPEN for this case: " + status);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify case statuses: " + e.getMessage());
			Assert.fail("Failed to verify case statuses: " + e.getMessage());
		}
	}

	public void changeToInProgressStatus(String status) {
		try {
			By prescriberMissingCase = By
					.xpath("//*[contains(@class,'active lafPageHost')]//span[text()='HCP Consent']");
			click(prescriberMissingCase);
			setTimeOut(2000);
			LoggingInfo("User clicks on 'Prescriber Missing' case");
			// By prescriberMissingCase = By.xpath("//*[contains(@class,'active
			// lafPageHost')]//span[text()='HCP Consent']");
			click(prescriberMissingCase);
			setTimeOut(2000);
			LoggingInfo("User clicks on 'Prescriber Missing' case");

			By editBtn = getDynamicElement(strEditBtn, "Edit");
			click(editBtn);
			setTimeOut(2000);
			LoggingInfo("User clicks on Edit button");
			scrollToElement(eleStatusField);
			click(eleStatusField);
			setTimeOut(2000);
			By inProgressStatus = getDynamicElement(strDropDownStatus, "In Progress");
			scrollToElement(inProgressStatus);
			click(inProgressStatus);
			By saveBtn = getDynamicElement(strEditBtn, "SaveEdit");
			click(saveBtn);
			setTimeOut(2000);
			LoggingInfo("User clicks on Save button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify In Progress status " + e.getMessage());
			Assert.fail("Failed to verify In Progress status " + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Verify Steps blocked due to and category MI with casename
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyCategoryAndStepsBlocked(List<String> caseNames, List<String> expectedStepsBlocked,
			List<String> expectedCategory) {
		try {
			if (verifytable("Open Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
				scrollToElement(eleMissingInfoTable);

				// Store both steps blocked and category for each case
				Map<String, String> caseToBlockedStep = new HashMap<>();
				Map<String, String> caseToCategory = new HashMap<>();

				for (WebElement row : rows) {
					WebElement subjectElement = row.findElement(By.xpath(".//td[@data-label=\"Subject\"]//a"));
					String caseNumber = subjectElement.getAttribute("title").trim();

					WebElement stepsBlocked = row.findElement(By.xpath(".//td[@data-label=\"Critical for\"]//span"));
					String stepsBlockedDueToMI = stepsBlocked.getText().trim();

					WebElement categoryElement = row.findElement(By.xpath(".//td[@data-label=\"Category\"]//span"));
					String categoryValue = categoryElement.getText().trim();

					caseToBlockedStep.put(caseNumber, stepsBlockedDueToMI);
					caseToCategory.put(caseNumber, categoryValue);
				}

				for (int i = 0; i < caseNames.size(); i++) {
					String caseName = caseNames.get(i);
					String expectedBlockedStep = expectedStepsBlocked.get(i);
					String expectedCat = expectedCategory.get(i);

					String actualBlockedStep = caseToBlockedStep.get(caseName);
					String actualCategory = caseToCategory.get(caseName);

					if (actualBlockedStep != null && actualCategory != null) {
						Assert.assertEquals(actualBlockedStep, expectedBlockedStep,
								"Steps Blocked due to MI mismatch for case: " + caseName);
						Assert.assertEquals(actualCategory, expectedCat, "Category mismatch for case: " + caseName);
						LoggingInfo("Verification completed for case: " + caseName);
					} else {
						Assert.fail("Case Name '" + caseName + "' not found in the Cases table.");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify MI case details - " + e.getMessage());
			Assert.fail("Failed to verify MI case details - " + e.getMessage());
		}
	}

	/**
	 * Function: Verify MI status with casename
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyStatusOfMICase(List<String> caseNumbers, String expectedStatus) {
		try {
			if (verifytable("Open Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
				scrollToElement(eleMissingInfoTable);

				Map<String, String> caseStatusMap = new HashMap<>();

				for (WebElement row : rows) {
					try {
						List<WebElement> subjectElements = row
								.findElements(By.xpath(".//td[@data-label='Subject']//a"));
						List<WebElement> statusElements = row
								.findElements(By.xpath(".//td[@data-label='Status']//span"));

						if (!subjectElements.isEmpty() && !statusElements.isEmpty()) {
							String caseNumber = subjectElements.get(0).getAttribute("title").trim();
							String actualStatus = statusElements.get(0).getText().trim();
							caseStatusMap.put(caseNumber, actualStatus);
						}
					} catch (Exception e) {
						Log.warn("Error while processing a row: " + e.getMessage());
					}
				}

				for (String caseNumber : caseNumbers) {
					if (caseStatusMap.containsKey(caseNumber)) {
						String actualStatus = caseStatusMap.get(caseNumber);
						Assert.assertEquals(actualStatus, expectedStatus, "Status mismatch for case '" + caseNumber
								+ "': Expected '" + expectedStatus + "', but got '" + actualStatus + "'");
						LoggingInfo("Status verified for case: " + caseNumber + " → " + actualStatus);
					} else {
						Assert.fail("Case number '" + caseNumber + "' not found in the Cases table.");
					}
				}
			} else {
				Assert.fail("Open Cases table not present or visible.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify MI case details - " + e.getMessage());
			Assert.fail("Failed to verify MI case details - " + e.getMessage());
		}
	}

	/**
	 * Function: Get MI cases names from the table(open or closed cases)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public ArrayList getMICasesNames(String tableName) throws Exception {
		String str = String.format(
				"//*[contains(@class,'active lafPageHost')]//table[@aria-label='%s']//tbody//tr//td[@data-label='Subject']//a//span",
				tableName);
		List<WebElement> eleCases = getWebDriver().findElements(By.xpath(str));

		int CasesCount = eleCases.size();
		Log.info("Total " + tableName + " : " + CasesCount);
		ArrayList<String> caseDetails = new ArrayList<String>();
		for (WebElement eleCase : eleCases) {
			String caseName = eleCase.getText().trim();
			Log.info("Case Name: " + caseName);
			caseDetails.add(caseName);
		}
		return caseDetails;

	}

	/**
	 * Function: Select MI cases from the table by subject(Case Name)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void selectMICases(String caseName) throws Exception {

		if (caseName.contains("All")) {
			By xpath = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Case Number\"]//ancestor::th//preceding-sibling::th//span[@class=\"slds-checkbox\"]");
			waitAndVerifyElement(xpath);
			click(xpath);
		} else {
			String strCase = "//*[contains(@class,\"active lafPageHost\")]//table//tbody//tr//td//a[@title=\"{0}\"]//ancestor::td//preceding-sibling::td//span[@part=\"input-checkbox\"]";
			By eleCase = getDynamicElement(strCase, caseName);
			waitAndVerifyElement(eleCase);
			scrollToElement(eleCase);
			clickByJavascript(eleCase);
		}
	}

	/**
	 * Function: Verify error message for bulk MI cases
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateBulkMICasesErrorMsg(String expectedErrorMsg) {
		try {
			By eleError = By.xpath("//span[@part='formatted-rich-text']//p");
			String actualErrorMsg = getText(eleError).trim();
			Assert.assertEquals(actualErrorMsg, expectedErrorMsg,
					"Error message mismatch. Expected: '" + expectedErrorMsg + "', but got: '" + actualErrorMsg + "'");
			LoggingInfo("Error message validated successfully");

			docMgmt.clickOnResendFinishBtn();
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Error Message for Bulk Close " + e.getMessage());
			Assert.fail("Failed to verify Error Message for Bulk Close " + e.getMessage());
		}

	}

	/**
	 * Function: Fill details and collect MI case
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void collectMICase() throws Exception {

		try {
			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
			waitAndVerifyElement(statusDropDownList);
			String status = "Collected";
			// Select "Collected" from dropdown
			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(2000);

			// Select Collected Channel
			By statusDropDown2 = getDynamicElement(elestrDropDownBox, "Collected Channel");
			waitAndVerifyElement(statusDropDown2);
			scrollToElement(statusDropDown2);
			click(statusDropDown2);
			setTimeOut(1000);
			By statusDropDownList2 = getDynamicElement(elestrDropDownList, "Collected_Channel");
			waitAndVerifyElement(statusDropDownList2);
			String channel = "Phone";
			// Select "Phone" from dropdown
			selectItemFromList(statusDropDown2, statusDropDownList2, channel, "Collected_Channel");
			LoggingInfo("Selected Channel as- " + channel);
			setTimeOut(1000);

			By statusDropDown3 = getDynamicElement(elestrDropDownBox, "Closure Attempt");
			waitAndVerifyElement(statusDropDown3);
			scrollToElement(statusDropDown3);
			click(statusDropDown3);
			setTimeOut(1000);
			By statusDropDownList3 = getDynamicElement(elestrDropDownList, "Closure_Attempt");
			waitAndVerifyElement(statusDropDownList3);
			String attempt = "Fax";

			// Select "Fax" from dropdown
			selectItemFromList(statusDropDown3, statusDropDownList3, attempt, "Closure_Attempt");
			LoggingInfo("Selected attempt as- " + attempt);
			setTimeOut(1000);

			By inputDate = By.xpath("(//input[@name=\"Closure_Attempt_Date\"])[1]");
			String date = Utility_Function.rearrangeDateFormat();
			inputText(inputDate, date);
			setTimeOut(4000);

			By inputTime = By.xpath("(//input[@name=\"Closure_Attempt_Date\"])[2]");
			click(inputTime);

			clickOnSubmitButton();
			setTimeOut(2000);

			By radioBtn = By.xpath("(//span[@class=\"slds-radio_faux\"])[1]");
			click(radioBtn);
			setTimeOut(1000);

			By nextBtn = By.xpath("//*[text()=\"Next\"]//parent::button");
			click(nextBtn);
			setTimeOut(4000);

			LoggingInfo("MI case collected successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Collect MI cases " + e.getMessage());
			Assert.fail("Failed to Collect MI cases " + e.getMessage());
		}
	}

	/**
	 * Function: validate MI case category with case name(Subject)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateMICaseCategory(String CaseName, String Expectedcategory) throws Exception {

		String strCategory = "//*[contains(@class,\"active lafPageHost\")]//table//tbody//tr//td//a[@title=\"{0}\"]//following::td[@data-label=\"Category\"]//lst-formatted-text//span";
		By eleCategory = getDynamicElement(strCategory, CaseName);
		waitAndVerifyElement(eleCategory);
		scrollToElement(eleCategory);
		String category = getText(eleCategory).trim();
		Assert.assertEquals(category, Expectedcategory, "Category is as expected. Expected: " + category);
		LoggingInfo("Category is: " + category);
	}

	/**
	 * Function: validate MI case steps blocked with case name(Subject)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateStepBlocked(String CaseName, String stepsBlockeddueToMI) throws Exception {

		String strBlockedSteps = "//*[contains(@class,\"active lafPageHost\")]//table//tbody//tr//td//a[@title=\"{0}\"]//following::td[@data-label=\"Critical for\"]//lst-formatted-text//span";
		By eleBlockedSteps = getDynamicElement(strBlockedSteps, CaseName);
		waitAndVerifyElement(eleBlockedSteps);
		scrollToElement(eleBlockedSteps);
		String stepsBlocked = getText(eleBlockedSteps);
		Assert.assertEquals(stepsBlocked, stepsBlockeddueToMI,
				"Steps Blocked is as expected. Expected: " + stepsBlockeddueToMI);
		if (stepsBlocked.isEmpty()) {
			stepsBlocked = "None";
		}

		LoggingInfo("Steps Blocked due to MI: " + stepsBlocked);

	}

	/**
	 * Function: validate Category and Steps Blocked on details page
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateCatandStepsBlockedOnDetailsPage(String catgory, String stepsBlocked) {
		String ele = "//*[contains(@class,'active lafPageHost')]//*[contains(@class,'slds-grid')]//*[text()='%s']//parent::div//following-sibling::div//lightning-formatted-text";
		String eleCatogry = String.format(ele, "Category");
		WebElement eleCat = getWebDriver().findElement(By.xpath(eleCatogry));
		String strCat = eleCat.getText();
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].style.border='2px solid red'", eleCat);
		Assert.assertEquals(strCat, catgory, "Category is as expected");

		String strStepsBlocked = String.format(ele, "Critical for");
		WebElement eleStepsBlocked = getWebDriver().findElement(By.xpath(strStepsBlocked));
		String strStepsblocked = eleStepsBlocked.getText();
		Assert.assertEquals(strStepsblocked, stepsBlocked, "Steps Blocked is as expected");
		if (strStepsblocked.isEmpty()) {
			strStepsblocked = "None";
		}
		LoggingInfo("Category is: " + strCat + " and Steps Blocked due to MI: " + strStepsblocked);

	}

	/**
	 * Function:Click on MI case with subject name
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnMICase(String subjectName) {
		String caseNumber = null;

		try {
			if (verifytable("Open Cases")) {
				List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
				scrollToElement(eleMissingInfoTable);
				for (WebElement row : rows) {

					WebElement subjectElement = row.findElement(By.xpath(".//td//div[@class=\"slds-grid\"]//a"));
					String miSubject = subjectElement.getAttribute("title");

					if (miSubject.equalsIgnoreCase(subjectName)) {
						WebElement elCaseNumber = row.findElement(
								By.xpath(".//th[@data-label='Case Number']//a//span[@class='slds-truncate']//span"));
						caseNumber = elCaseNumber.getText();

						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								elCaseNumber);

						Log.info(caseNumber);
						elCaseNumber.click();

						// click on close
						By closeButton = getDynamicElement(strEditBtn, "Case.CAS_Close_ICC");
						waitAndVerifyElement(closeButton);
						click(closeButton);
						break;
					} else {
						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								subjectElement);
						LoggingInfo("Status is collected MI case");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to change sttaus of MI case " + e.getMessage());
			Assert.fail("Failed to change sttaus of MI case  " + e.getMessage());
		}

	}

	/**
	 * Function:Verify field presence on layout
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyFieldPresenceOnLayout2(String fieldLabel) throws Exception {
		try {
			String strField = "//*[contains(@class,\"active lafPageHost\")]//div//*[text()=\"{0}\"]";
			By fieldName = getDynamicElement(strField, fieldLabel);
			scrollToElement(fieldName);
			boolean found = isElementPresent(fieldName);
			highLightElement(fieldName);
			Assert.assertTrue(found);
			LoggingInfo("Field is present on page layout- " + fieldLabel);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Field " + e.getMessage());
			Assert.fail("Failed to verify Field " + e.getMessage());
		}
	}

	/**
	 * Function:Verify field presence on layout
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyFieldPresenceOnLayout3(String fieldLabel) throws Exception {
		try {
			String strField = "//*[contains(@class,\"active lafPageHost\")]//records-record-layout-item//*[text()=\"{0}\"]";
			By fieldName = getDynamicElement(strField, fieldLabel);
			scrollToElement(fieldName);
			boolean found = isElementPresent(fieldName);
			highLightElement(fieldName);
			Assert.assertTrue(found);
			LoggingInfo("Field is present on page layout- " + fieldLabel);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Field " + e.getMessage());
			Assert.fail("Failed to verify Field " + e.getMessage());
		}
	}

	/**
	 * Function: Enter details on 1st attempt field and 1st attempt date
	 * 
	 * @param attempt picklist value
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void populateFirstAttempt(String attemptValue) throws Exception {

		try {
			By attemptDropDown = getDynamicElement(strDropDownBox, "1st Attempt");
			waitAndVerifyElement(attemptDropDown);
			scrollToElement(attemptDropDown);
			click(attemptDropDown);
			setTimeOut(4000);
			By statusDropDownList = getDynamicElement(strDropDownBoxOptions, "1st Attempt");
			waitAndVerifyElement(statusDropDownList);
			selectItemFromList(attemptDropDown, statusDropDownList, attemptValue, "1st Attempt");

			By inputDate = By.xpath("(//input[@name=\"Attempt1Date_ICC__c\"])[1]");
			String formattedDate = Utility_Function.getNthPastDayFromToday(2);
			inputText(inputDate, formattedDate);
			setTimeOut(4000);

			By inputTime = By.xpath("(//input[@name=\"Attempt1Date_ICC__c\"])[2]");
			click(inputTime);

			LoggingInfo("1st Attempt details are popualted successfully");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			Log.error("Failed to Populate 1st Ateempt details" + e.getMessage());
			Assert.fail("Failed to Populate 1st Ateempt details" + e.getMessage());
		}

	}

	/**
	 * Function: Enter details on 2nd attempt field and 2nd attempt date
	 * 
	 * @param attempt picklist value
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void populateSecondAttempt(String attemptValue) throws Exception {

		try {
			By attemptDropDown = getDynamicElement(strDropDownBox, "2nd Attempt");
			waitAndVerifyElement(attemptDropDown);
			scrollToElement(attemptDropDown);
			click(attemptDropDown);
			setTimeOut(4000);
			By statusDropDownList = getDynamicElement(strDropDownBoxOptions, "2nd Attempt");
			waitAndVerifyElement(statusDropDownList);
			selectItemFromList(attemptDropDown, statusDropDownList, attemptValue, "2nd Attempt");

			By inputDate = By.xpath("(//input[@name=\"Attempt2Date_ICC__c\"])[1]");
			// String date = Utility_Function.rearrangeDateFormat();
			String formattedDate = Utility_Function.getNthPastDayFromToday(2);
			inputText(inputDate, formattedDate);
			setTimeOut(4000);

			By inputTime = By.xpath("(//input[@name=\"Attempt2Date_ICC__c\"])[2]");
			click(inputTime);

			LoggingInfo("2nd Attempt details are popualted successfully");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			Log.error("Failed to Populate 2nd Ateempt details" + e.getMessage());
			Assert.fail("Failed to Populate 2nd Ateempt details" + e.getMessage());
		}

	}

	/**
	 * Function: Enter details on 3rd attempt field and 3rd attempt date
	 * 
	 * @param attempt picklist value
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void populateThirdAttempt(String attemptValue) throws Exception {

		try {
			By attemptDropDown = getDynamicElement(strDropDownBox, "3rd Attempt");
			waitAndVerifyElement(attemptDropDown);
			scrollToElement(attemptDropDown);
			click(attemptDropDown);
			setTimeOut(4000);
			By statusDropDownList = getDynamicElement(strDropDownBoxOptions, "3rd Attempt");
			waitAndVerifyElement(statusDropDownList);
			selectItemFromList(attemptDropDown, statusDropDownList, attemptValue, "3rd Attempt");

			By inputDate = By.xpath("(//input[@name=\"Attempt3Date_ICC__c\"])[1]");
			String date = Utility_Function.getNthPastDayFromToday(2);
			inputText(inputDate, date);
			setTimeOut(4000);

			By inputTime = By.xpath("(//input[@name=\"Attempt3Date_ICC__c\"])[2]");
			click(inputTime);

			LoggingInfo("3rd Attempt details are popualted successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Populate 3rd Ateempt details" + e.getMessage());
			Assert.fail("Failed to Populate 3rd Ateempt details" + e.getMessage());
		}

	}

	/**
	 * Function: Verify if a Field on Bulk screen field is Mandatory(Required)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void checkMandatoryField(String fieldName) {
		try {

			String strmanField = "//span[@part=\"formatted-rich-text\" and text()=\"{0}\"]//parent::lightning-formatted-rich-text//parent::div//abbr";
			By eleMandatoryField = getDynamicElement(strmanField, fieldName);

			String attValue = getAttributeValue(eleMandatoryField, "title");
			if (attValue.equalsIgnoreCase("required")) {
				Log.info(fieldName + "field is marked as mandatory");
			} else {
				Log.info(fieldName + " field is not marked as mandatory");
				Assert.fail();
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			Log.error("Failed to verify Mandatory Field" + e.getMessage());
			Assert.fail("Failed to verify Mandatory Field" + e.getMessage());
		}
	}

	/**
	 * Function: Verify Picklist values for Closure Attempt
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateClosureAttemptPicklistVal() throws Exception {

		By statusDropDown3 = getDynamicElement(elestrDropDownBox, "Closure Attempt");
		waitAndVerifyElement(statusDropDown3);
		scrollToElement(statusDropDown3);
		click(statusDropDown3);
		setTimeOut(1000);

		List<String> expectedOptions = List.of("Voice Call", "Fax", "Email", "SMS", "Patient Letter", "Not Applicable");
		By eleClosureDropdownOptions = By.xpath("//select[@name=\"Closure_Attempt\"]//option");

		List<WebElement> options = getWebDriver().findElements(eleClosureDropdownOptions);

		boolean allValuesPresent = true;
		for (String expectedOption : expectedOptions) {
			boolean isPresent = false;

			for (WebElement option : options) {
				String optionName = getText(eleClosureDropdownOptions).trim();
				if (optionName.equalsIgnoreCase(expectedOption)) {
					// highLightElement(option);
					isPresent = true;
					Log.info(expectedOption + " :Option is present");
					break;
				}

			}
			if (!isPresent) {
				allValuesPresent = false;
				LoggingInfo("Option Not Found: " + expectedOption);
			}
		}
		if (allValuesPresent) {
			LoggingInfo("All Expected Options are present");
		}

	}

	/**
	 * Function: Verify Status Picklist contains only COllected and Not collected is
	 * removed
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateStatusFieldValues() {
		try {
			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
			List<WebElement> statusOptions = getWebDriver().findElements(statusDropDownList);

			String expectedOption = "Collected";

			boolean isExpectedOptionPresent = false;
			boolean isNotCollectedOptnPresent = false;

			for (WebElement option : statusOptions) {
				String optionText = option.getText();

				// Check if the expected option is present
				if (optionText.equals(expectedOption)) {
					isExpectedOptionPresent = true;
				}

				// Check if "NotCollect" is present
				if (optionText.equals("Not Collected")) {
					isNotCollectedOptnPresent = true;
				}
			}

			// Validate if expected option is present and "NotCollect" is absent
			if (isExpectedOptionPresent && !isNotCollectedOptnPresent) {
				System.out.println("Dropdown contains the expected option and does not contain 'Not Collected'.");
			} else if (isNotCollectedOptnPresent) {
				System.out.println("Error: 'NotCollect' option is present in the dropdown.");
			} else {
				System.out.println("Error: Expected option is missing in the dropdown.");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate" + e.getMessage());
			Assert.fail("Failed to validate  " + e.getMessage());
		}

	}

	/**
	 * Function: Verify Fields on Bulk Close Screen
	 * 
	 * @param fieldName - field name to be verified
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateMICasePageFields(String fieldName) {
		try {
			By frame = By.xpath("(//iframe[@title='Salesforce - Unlimited Edition'])[1]");
			Utility_Function.switchToFrame2(frame);
			String strPageField = "//span[@part=\"formatted-rich-text\" and text()=\"{0}\"]";

			By elePageFiled = getDynamicElement(strPageField, fieldName);
			if (isElementPresent(elePageFiled)) {
				LoggingInfo(fieldName + " : is Present");
			} else {
				Assert.fail("Filed No present on the page: " + fieldName);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate" + e.getMessage());
			Assert.fail("Failed to validate  " + e.getMessage());
		}

	}

	/**
	 * Function: Verify Dependent field(Collected Channel) is enabled when Status is
	 * selected as Collected
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateCollectedChannel() throws Exception {
		By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
		waitAndVerifyElement(statusDropDown);
		scrollToElement(statusDropDown);
		click(statusDropDown);
		setTimeOut(1000);

		By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
		waitAndVerifyElement(statusDropDownList);
		String status = "Collected";
		selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
		setTimeOut(2000);

		validateMICasePageFields("Collected Channel");
		LoggingInfo("Dependent field visible when Status = Collected");

	}

	/**
	 * Function: Fill details and collect MI case by passing all the values
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void collectMICase(String status, String Channel, String attempt, String closureDate) throws Exception {

		try {
			By statusDropDown = getDynamicElement(elestrDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Status");
			waitAndVerifyElement(statusDropDownList);

			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(2000);

			// Select Collected Channel
			By statusDropDown2 = getDynamicElement(elestrDropDownBox, "Collected Channel");
			waitAndVerifyElement(statusDropDown2);
			scrollToElement(statusDropDown2);
			click(statusDropDown2);
			setTimeOut(1000);
			By statusDropDownList2 = getDynamicElement(elestrDropDownList, "Collected_Channel");
			waitAndVerifyElement(statusDropDownList2);

			selectItemFromList(statusDropDown2, statusDropDownList2, Channel, "Collected_Channel");
			LoggingInfo("Selected Channel as- " + channel);
			setTimeOut(1000);

			By statusDropDown3 = getDynamicElement(elestrDropDownBox, "Closure Attempt");
			waitAndVerifyElement(statusDropDown3);
			scrollToElement(statusDropDown3);
			click(statusDropDown3);
			setTimeOut(1000);
			By statusDropDownList3 = getDynamicElement(elestrDropDownList, "Closure_Attempt");
			waitAndVerifyElement(statusDropDownList3);

			selectItemFromList(statusDropDown3, statusDropDownList3, attempt, "Closure_Attempt");
			LoggingInfo("Selected attempt as- " + attempt);
			setTimeOut(1000);

			By inputDate = By.xpath("(//input[@name=\"Closure_Attempt_Date\"])[1]");
			inputText(inputDate, closureDate);
			setTimeOut(4000);

			By inputTime = By.xpath("(//input[@name=\"Closure_Attempt_Date\"])[2]");
			click(inputTime);

			clickOnSubmitButton();
			setTimeOut(2000);

			LoggingInfo("MI case collected successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Collect MI cases " + e.getMessage());
			Assert.fail("Failed to Collect MI cases " + e.getMessage());
		}
	}

	/**
	 * Function: Validate Bulk Close Screen is displayed with Yes/No options
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateBulkCloseConfirmMsgScreen() {
		String msg = "Are you sure you want to Bulk Close all the selected MI Cases with selected Attempt values?";
		By eleBulkCloseScreen = By.xpath("//legend//span[@part='formatted-rich-text']");
		String actualMsg = getText(eleBulkCloseScreen).trim();
		if (actualMsg.contains(msg)) {
			String strConfirmationOption = "//span[@class=\"slds-radio_faux\"]//parent::label//following-sibling::span[text()=\"{0}\"]";
			By eleoptionYes = getDynamicElement(strConfirmationOption, "Yes");
			By eleoptionNo = getDynamicElement(strConfirmationOption, "No");

			if (isElementPresent(eleoptionNo) && isElementPresent(eleoptionYes)) {
				LoggingInfo("Confirmation message is visible with Yes and No option to select");
			} else {
				Assert.fail("Bulk Close Confirmation Screen is not visible");
			}
		}
	}

	/**
	 * Function: Select Bulk Close confirmation option Yes/No
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void selectBulkCloseConfirmOption(String optionToSelect) {
		try {
			String strOptiontoSelect = "//span[text()=\"{0}\"]//ancestor::span[@class=\"slds-form-element__label\"]//parent::label//span[@class=\"slds-radio_faux\"]";
			By eleOptionToSelect = getDynamicElement(strOptiontoSelect, optionToSelect);
			click(eleOptionToSelect);
			LoggingInfo("Option Selected: " + optionToSelect);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Select Option " + e.getMessage());
			Assert.fail("Failed to Select Option " + e.getMessage());
		}

	}

	/**
	 * Function: Open MI case that is Open/Closed
	 * 
	 * @param tableName   (Open/Closed)
	 * @param subjectName (Case Name)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void openMiCase(String tableName, String subjectName) {
		String caseNumber = null;

		try {
			if (verifytable(tableName)) {
				List<WebElement> rows = null;
				if (tableName.equalsIgnoreCase("Open Cases")) {
					rows = getWebDriver().findElements(eleMissingInfoTable);
					scrollToElement(eleMissingInfoTable);
				} else if (tableName.equalsIgnoreCase("Closed Cases")) {
					rows = getWebDriver().findElements(eleMissingInfoClosedTable);
					scrollToElement(eleMissingInfoClosedTable);
				}

				for (WebElement row : rows) {

					WebElement subjectElement = row.findElement(By.xpath(".//td//div[@class=\"slds-grid\"]//a"));
					String miSubject = subjectElement.getAttribute("title");

					if (miSubject.equalsIgnoreCase(subjectName)) {
						WebElement elCaseNumber = row.findElement(
								By.xpath(".//th[@data-label='Case Number']//a//span[@class='slds-truncate']//span"));
						caseNumber = elCaseNumber.getText();

						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								elCaseNumber);

						Log.info(caseNumber);
						elCaseNumber.click();
					}
				}
			}
		} catch (Exception e) {

		}
	}

	/**
	 * Function: Verify Dependent Field Reason is enabled when Closure attempt = Not
	 * Applicable
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateReasonFieldDependentonClosureAttmpt() throws Exception {
		String attempt = "Not Applicable";
		By statusDropDown3 = getDynamicElement(elestrDropDownBox, "Closure Attempt");
		waitAndVerifyElement(statusDropDown3);
		scrollToElement(statusDropDown3);
		click(statusDropDown3);
		setTimeOut(1000);
		By statusDropDownList3 = getDynamicElement(elestrDropDownList, "Closure_Attempt");
		waitAndVerifyElement(statusDropDownList3);

		selectItemFromList(statusDropDown3, statusDropDownList3, attempt, "Closure_Attempt");
		LoggingInfo("Selected attempt as- " + attempt);
		setTimeOut(1000);

		validateMICasePageFields("Reason");

		LoggingInfo("Reason Field is visible when Closure Attempt = Not Applicable");

	}

	/**
	 * Function: validate details of Attempt value and Attempt date that entered
	 * while Bulk Close
	 * 
	 * @param attemptNum      - Field Name(1st/2nd/3rd Attempt)
	 * @param attemptDateNum- Field Name(1st/2nd/3rd Attempt Date)
	 * @param attemptVal      - Attempt filed value to be verified
	 * @param attemptDateVal  - Attempt Date value to be verified
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateAttemptDetailsonMICase(String attemptNum, String attemptDateNum, String attemptVal,
			String attemptDateVal) {

		String strAttempt = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-text";
		DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("MMM dd, yyyy", Locale.ENGLISH);

		LocalDate date = LocalDate.parse(attemptDateVal, inputFormatter);
		DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("M/d/yyyy");
		String formattedDate = date.format(outputFormatter);

		By eleAttempt = getDynamicElement(strAttempt, attemptNum);
		String ActualattemptVal = getText(eleAttempt).trim();

		By eleDate = getDynamicElement(strAttempt, attemptDateNum);
		String datetext = getText(eleDate).trim();
		String[] parts = datetext.split(",");
		String datePart = parts[0].trim();

		if (ActualattemptVal.equalsIgnoreCase(attemptVal) && formattedDate.equalsIgnoreCase(datePart)) {
			LoggingInfo("Values are as Expected");

		} else {
			LoggingInfo("Values are not as expected");
			Assert.fail("Values are not as Expected");
		}
	}

	/**
	 * Function: Verify status field value as Collected
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyStatusField() {
		String strAttempt = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-text";
		By eleStatus = getDynamicElement(strAttempt, "Status");

		String text = getText(eleStatus).trim();
		if (text.equalsIgnoreCase("Collected")) {
			Log.info("Status Field is updated as Collected");
		} else {
			Assert.fail("Status field is not updated as expected");
		}

	}

	/**
	 * Function: Verify Picklist values for Reason dropdown
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateReasonDropdownValues() throws Exception {
		// Select reason
		By statusDropDown3 = getDynamicElement(elestrDropDownBox, "Reason");
		waitAndVerifyElement(statusDropDown3);
		scrollToElement(statusDropDown3);
		click(statusDropDown3);
		setTimeOut(1000);

		List<String> expectedOptions = List.of("Enrollment Oversight", "Triaged to SP");
		By eleClosureDropdownOptions = By.xpath("//select[@name=\"Reason_Closure\"]//option");

		List<WebElement> options = getWebDriver().findElements(eleClosureDropdownOptions);

		boolean allValuesPresent = true;
		for (String expectedOption : expectedOptions) {
			boolean isPresent = false;

			for (WebElement option : options) {
				String optionName = getText(eleClosureDropdownOptions).trim();
				if (optionName.equalsIgnoreCase(expectedOption)) {
					// highLightElement(option);
					isPresent = true;
					Log.info(expectedOption + " :Option is present");
					break;
				}

			}
			if (!isPresent) {
				allValuesPresent = false;
				LoggingInfo("Option Not Found: " + expectedOption);
			}
		}
		if (allValuesPresent) {
			LoggingInfo("All Expected Options are present");
		}

	}

	/**
	 * Function: Validate error message
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateDateErrorMessage(String expectedErrorMsg) {
		try {
			By xp = By.xpath("//span[@part='formatted-rich-text']//p//span");
			waitAndVerifyElement(xp);
			String actualErrorMsg = getText(xp);
			Assert.assertEquals(actualErrorMsg, expectedErrorMsg,
					"Error message mismatch. Expected: '" + expectedErrorMsg + "', but got: '" + actualErrorMsg + "'");
			LoggingInfo("Error message validated successfully");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate error message " + e.getMessage());
			Assert.fail("Failed to validate error message " + e.getMessage());
		}
	}
	
	/**
	 * Function:save Status as not collected with filling all values
	 * 
	 * @author Navita J
	 **/

	public void selectStatusNotCollcted() {
		try {
			String attempt = "Fax";
			By statusDropDown = getDynamicElement(elestrDropDownBox, "Copy_1_of_Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(1000);

			By statusDropDownList = getDynamicElement(elestrDropDownList, "Copy_1_of_Status");
			waitAndVerifyElement(statusDropDownList);
			String status = "Not Collected";
			selectItemFromList(statusDropDown, statusDropDownList, status, "Copy_1_of_Status");
			LoggingInfo("Selected Status as- " + status);
			setTimeOut(2000);

			By statusDropDown3 = getDynamicElement(elestrDropDownBox, "Copy_1_of_X1st_Attempt");
			waitAndVerifyElement(statusDropDown3);
			scrollToElement(statusDropDown3);
			click(statusDropDown3);
			setTimeOut(1000);
			By statusDropDownList3 = getDynamicElement(elestrDropDownList, "Copy_1_of_X1st_Attempt");
			waitAndVerifyElement(statusDropDownList3);

			selectItemFromList(statusDropDown3, statusDropDownList3, attempt, "Copy_1_of_X1st_Attempt");
			LoggingInfo("Selected attempt as Fax ");
			setTimeOut(1000);

			// Enter attempt date
			By inputDate = By.xpath("(//input[@name=\"Copy_1_of_X1st_Attempt_Date\"])[1]");
			String date = Utility_Function.rearrangeDateFormat();
			inputText(inputDate, date);
			setTimeOut(4000);

			By inputTime = By.xpath("(//input[@name=\"Copy_1_of_X1st_Attempt_Date\"])[2]");
			click(inputTime);
			setTimeOut(1000);

			By statusDropDown4 = getDynamicElement(elestrDropDownBox, "Copy_1_of_X2nd_Attempt");
			waitAndVerifyElement(statusDropDown4);
			scrollToElement(statusDropDown4);
			click(statusDropDown4);
			setTimeOut(1000);
			By statusDropDownList4 = getDynamicElement(elestrDropDownList, "Copy_1_of_X2nd_Attempt");
			waitAndVerifyElement(statusDropDownList4);

			selectItemFromList(statusDropDown4, statusDropDownList4, attempt, "Copy_1_of_X2nd_Attempt");
			LoggingInfo("Selected attempt as- " + attempt);
			setTimeOut(1000);

			By inputDate2 = By.xpath("(//input[@name=\"Copy_1_of_X2nd_Attempt_Date\"])[1]");
			inputText(inputDate2, date);
			setTimeOut(4000);

			By inputTime2 = By.xpath("(//input[@name=\"Copy_1_of_X2nd_Attempt_Date\"])[2]");
			click(inputTime2);
			setTimeOut(1000);

			By statusDropDown5 = getDynamicElement(elestrDropDownBox, "Copy_1_of_X3rd_Attempt");
			waitAndVerifyElement(statusDropDown5);
			scrollToElement(statusDropDown5);
			click(statusDropDown5);
			setTimeOut(1000);
			By statusDropDownList5 = getDynamicElement(elestrDropDownList, "Copy_1_of_X3rd_Attempt");
			waitAndVerifyElement(statusDropDownList5);

			selectItemFromList(statusDropDown5, statusDropDownList5, attempt, "Copy_1_of_X3rd_Attempt");
			LoggingInfo("Selected attempt as- " + attempt);
			setTimeOut(1000);

			By inputDate3 = By.xpath("(//input[@name=\"Copy_1_of_X3rd_Attempt_Date\"])[1]");
			inputText(inputDate3, date);
			setTimeOut(4000);

			By inputTime3 = By.xpath("(//input[@name=\"Copy_1_of_X3rd_Attempt_Date\"])[2]");
			click(inputTime3);
			setTimeOut(1000);

			clickOnSubmitButton();

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	/**
	 * Function: validate MI case steps blocked with case name(Subject)
	 * 
	 * @author Trupti Zure
	 **/
	public void validateStepBlockedMI(String CaseName, String stepsBlockeddueToMI) throws Exception {

		String strBlockedSteps = "//*[contains(@class,\"active lafPageHost\")]//table//tbody//tr//td//a[@title=\"{0}\"]//following::td[@data-label=\"Critical for\"]//lst-formatted-text//span";
		By eleBlockedSteps = getDynamicElement(strBlockedSteps, CaseName);
		waitAndVerifyElement(eleBlockedSteps);
		scrollToElement(eleBlockedSteps);
		String stepsBlocked = getText(eleBlockedSteps);
		Assert.assertTrue(stepsBlocked.contains(stepsBlockeddueToMI), "Steps Blocked is as expected. Expected: ");
		if (stepsBlocked.isEmpty()) {
			stepsBlocked = "None";
		}

		LoggingInfo("Steps Blocked due to MI: " + stepsBlocked);

	}

}