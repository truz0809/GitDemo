package com.sanofi.selenium.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class QuickStartPage extends Utility_Function {
	public QuickStartPage(WebDriver driver) {
		super(driver);
	}

	String orderNumber;

	/************************
	 * Elements
	 **************************************************/
	public static By elePrescription = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"MR\")]//ancestor::tbody//span[contains(@class,\"slds-grid slds-grid_align-spread\")])[1]");
	public static By eleMainTaskStatus = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//span[contains(@class,\"status-text\")]");
	public static By eleCPETable = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[@aria-label=\"Care Program Enrollee Products\"]//tbody//tr");
	public static By eleCPEWorkOrderTable = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-grid\")]//*[text()=\"Care Program Enrollee Work Order\"]");
	public static By eleTaskLoading = By.xpath("*//h2//span[text()=\"Task is loading\"]");
	public static By eleCloseButton = By.xpath("(//button[@title=\"Close this window\"]//span)[1]");
	public static By StartNewService = By
			.xpath("//*[text()='Start New Service' or @name='CareProgramEnrollee.CPE_StartNewService_ICC']");
	public static By ServicePath = By.xpath("//*[text()='Service']/following::select[1]");
	public static By ServiceOptionPath = By.xpath("//*[text()='Service']/following::select[1]//option[text()='PAP']");
	public static By ServiceNextBtn = By.xpath("//*[text()='Next']");
	public static By ServiceReason = By.xpath("//*[text()='Reason']/following::select[1]");

	public static String strQSFields = "(//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//following::lightning-formatted-text)[1]";
	public static By ServiceReasonOptionPath = By
			.xpath("//*[text()='Reason']/following::select[1]//option[text()='PA Appeal Denied']");
	public static By ServiceSaveBtn = By.xpath("//*[text()='Save']");
	public static By eleOderNumber = By.xpath("//th[@data-label=\"Order Number\"]//a//slot//slot");
	public static By eleOderTitle = By.xpath("//span[@title=\"Orders\"]");
	public static By searchDocInput = By.xpath("//*[@placeholder=\"Search this list...\"]");
	public static By attachCheckbox = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//span[contains(@class,\"slds-checkbox_faux\")])[1]");

	public static By eleOrderTable = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@aria-label=\"Orders\"]//tbody//tr");

	public static By eleStartDate = By
			.xpath("(//*[text()=\"Enrollment Start Date\"]//parent::div//parent::dt//following-sibling::dd//span)[1]");
	public static By eleEndDate = By
			.xpath("(//*[text()=\"Enrollment End Date\"]//parent::div//parent::dt//following-sibling::dd//span)[1]");

	public static By eleEditStatus = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()='Status']//parent::div//parent::div//button[@title='Edit Status']");
	/************************
	 * Dynamic Elements
	 **************************************************/

	public static String eleButton = "//*[contains(@class,\"active lafPageHost\")]//*[@title=\"{0}\"]";
	public static String strTaskName = "//*[contains(@class,\"active lafPageHost\")]//*[@class=\"slds-section__title\"]//span[text()=\"{0}\"]";
	public static String strSubtaskName = "//*[@class=\"card\"]//*[text()=\"{0}\"]";
	public static String taskButton = "(//*[@class=\"slds-section__title\"]//span[text()=\"{0}\"]//parent::div//span)[1]";
	public static String strSubTaskStatus = "(//*[@class=\"card\"]//h2[text()=\"{0}\"]//parent::div//li)[2]";
	public static String subTaskButton = "//*[contains(@class,\"active lafPageHost\")]//div[@class=\"card\"]//h2[text()=\"{0}\"]//parent::div";
	public static String strTaskTitle = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strDropDownInputBox = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]";
	public static String strInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::input";
	public static String strInputDateBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//input";
	public static String searchDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//span[contains(@class,\"option-text\")]";
	public static String button = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";
	public static String strAccount = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::a)[1]";
	public static String strCPE = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::a";
	public static String strQuickStartCPE = "//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"{0}\")]//ancestor::a//parent::div";
	public static String strRecordName = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[@title=\"{0}\"]";
	public static String strQuickStartFields = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-text";
	public static String strOrderRadio = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"])[2]//ancestor::th//parent::tr//parent::thead//following-sibling::tbody//span//child::div//child::button[@title=\"Select\"]";
	public static String strDropDownBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//button";
	public static String strDropDownBoxOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//div[contains(@class,\"slds-listbox\")]//span[@class=\"slds-media__body\"]//span";
	public static String editButton = "//*[contains(@class,\"active lafPageHost\")]//button[@title=\"{0}\"]";
	public static String editFieldList = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//button//span[@class=\"slds-truncate\"]";
	public static String editFieldListOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//lightning-base-combobox-item";
	public static String inputField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//input";
	public static String labelsField = "//*[contains(@class,\"active lafPageHost\")]//div//span[text()=\"{0}\"]";
	public static String strOrderFields = "(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//a//span//span//span)[1]";

	/**
	 * Function:Check quick start initiation
	 * 
	 * @author Trupti
	 **/

	public void checkQuickStartIntiation() {
		try {
			setTimeOut(10000);
			By quickStartButton = getDynamicElement(eleButton, "Quick Start");
			waitAndVerifyElement(quickStartButton);
			click(quickStartButton);
			String buttonState = getAttributeValue(quickStartButton, "aria-pressed");
			// Assert the state of the button
			Assert.assertEquals(buttonState, "true", "Quick Start flow is initialized");
			LoggingInfo("Quick Start flow is initialized");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to check the status of quick start intiation " + e.getMessage());
			Assert.fail("Failed to check the status of quick start intiation " + e.getMessage());
		}
	}

	/**
	 * Function:Click on quick start
	 * 
	 * @author Trupti
	 **/

	public void clickOnQuickStart() {
		try {
			setTimeOut(10000);
			By quickStartButton = getDynamicElement(eleButton, "Quick Start");
			scrollToElement(quickStartButton);
			waitAndVerifyElement(quickStartButton);
			click(quickStartButton);
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to Click on quick start button " + e.getMessage());
			Assert.fail("Failed to Click on quick start button " + e.getMessage());
		}
	}

	/**
	 * Function:Check quick start initiation
	 * 
	 * @author Trupti
	 **/

	public void checkQuickStartTaskInitiation() {
		try {
			By taskName = getDynamicElement(strTaskName, "QS Summary");
			waitAndVerifyElement(taskName);
			LoggingInfo("QS Summary task has been initialized");
			setTimeOut(2000);

			By eleTaskButton = getDynamicElement(taskButton, "QS Summary");
			scrollToElement(eleTaskButton);
			click(eleTaskButton);
			LoggingInfo("Clicked on QS summary task");
			setTimeOut(1000);

			By subTaskName = getDynamicElement(strSubtaskName, "Enrollment");
			waitAndVerifyElement(subTaskName);
			LoggingInfo("QS Summary sub task-Enrollment has been initialized");
			setTimeOut(2000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, "Enrollment");
			waitAndVerifyElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Not Started", "Enrollment task status verified");

		} catch (Exception e) {
			Log.error("Failed to Check Quick Start Task Initiation " + e.getMessage());
			Assert.fail("Failed to Check Quick Start Task Initiation " + e.getMessage());
		}
	}

	/**
	 * Function:click On Task
	 * 
	 * @author Trupti
	 **/
	public void clickOnTask() {
		try {
			By eleSubTaskButton = getDynamicElement(subTaskButton, "Enrollment");
			waitAndVerifyElement(eleSubTaskButton);
			scrollToElement(eleSubTaskButton);
			click(eleSubTaskButton);
			// closeTaskLoadingWindowIfVisible();
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click on task " + e.getMessage());
			Assert.fail("Failed to click on task " + e.getMessage());
		}
	}

	public void verifyAndenterEligibilityCriteria() {
		String[] dropdownLabels = { "Private commercial insurance?", "Patient resides in US/PR?", "HCP in US/PR?",
				"FDA approved indication?", "PA Required?", "No previous commercial fill?" };

		try {
			for (String dropdownLabel : dropdownLabels) {
				By dropdownInputBox = getDynamicElement(strDropDownInputBox, dropdownLabel);
				waitAndVerifyElement(dropdownInputBox);
				click(dropdownInputBox);
				By dropdownOptions = getDynamicElement(strDropDownOptions, dropdownLabel);
				waitAndVerifyElement(dropdownOptions);

				if (dropdownLabel.equals("No previous commercial fill?")) {

					selectItemFromList(dropdownInputBox, dropdownOptions, "Yes", dropdownLabel);
					LoggingInfo("Manually selected 'Yes' for: " + dropdownLabel);
				} else {

					selectItemFromList(dropdownInputBox, dropdownOptions, "Yes", dropdownLabel);
					LoggingInfo("Verified auto-populated value 'Yes' for: " + dropdownLabel);
				}

				setTimeOut(1000);
			}
		} catch (Exception e) {
			Log.error("Failed to process Eligibility Criteria - " + e.getMessage());
			Assert.fail("Failed to process Eligibility Criteria - " + e.getMessage());
		}
	}

	/**
	 * Function:Verify task is loaded
	 * 
	 * @author Trupti
	 **/

	public void verifyTaskIsLoaded(String taskTitle) {
		try {
			waitForPageLoaded();
			By tasktitle = getDynamicElement(strTaskTitle, taskTitle);
			waitForvisiblityOfElementLocated(tasktitle);
			LoggingInfo(taskTitle + "-task is loaded");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to check if task is loaded- " + e.getMessage());
			Assert.fail("Failed to check if task is loaded- " + e.getMessage());
		}
	}

	// Anand P
	public void verifyTaskIsNotLoaded(String taskTitle) {
		try {
			waitForPageLoaded();
			By tasktitle = getDynamicElement(strTaskTitle, taskTitle);
			waitForvisiblityOfElementLocated(tasktitle);

			setTimeOut(2000);

		} catch (Exception e) {

			LoggingInfo(taskTitle + "Not present as expected");

		}
	}

	/**
	 * Function:enter Eligibility Criteria
	 * 
	 * @author Trupti
	 **/
	public void enterEligibilityCriteria() {
		String[] dropdownLabels = { "Private commercial insurance?", "Patient resides in US/PR?", "HCP in US/PR?",
				"FDA approved indication?", "PA Required?", "No previous commercial fill?" };
		try {
			for (String dropdownLabel : dropdownLabels) {
				By dropdownInputBox = getDynamicElement(strDropDownInputBox, dropdownLabel);
				waitAndVerifyElement(dropdownInputBox);
				click(dropdownInputBox);
				By dropdownOptions = getDynamicElement(strDropDownOptions, dropdownLabel);
				waitAndVerifyElement(dropdownOptions);
				selectItemFromList(dropdownInputBox, dropdownOptions, "Yes", dropdownLabel);
				LoggingInfo("Selected " + dropdownLabel + " as- Yes");
				setTimeOut(1000);
			}
		} catch (Exception e) {
			Log.error("Failed enter Eligibility Criteria- " + e.getMessage());
			Assert.fail("Failed enter Eligibility Criteria- " + e.getMessage());
		}
	}

	/**
	 * Function:enter Eligibility Outcome
	 * 
	 * @author Trupti
	 **/
	public void verifyAndEntereligibilityOutcome(String outcomeOption) {
		try {
			scrollToTopOfPage();
			// Eligibility Outcome
			By eleEligOutcomeInputBox = getDynamicElement(strInputBox, "Eligibility Outcome");
			scrollToElement(eleEligOutcomeInputBox);
			String outCome = "Eligible";
			verifyHardAssertInputFieldBox(eleEligOutcomeInputBox, outCome, "Eligibility Outcome");

			// Outcome
			By eleOutcome = getDynamicElement(strDropDownInputBox, "Outcome");
			waitAndVerifyElement(eleOutcome);
			scrollToElement(eleOutcome);
			click(eleOutcome);

			By eleOutcomeOptions = getDynamicElement(searchDropDownOptions, "Outcome");
			waitAndVerifyElement(eleOutcomeOptions);
			selectItemFromList(eleOutcome, eleOutcomeOptions, outcomeOption, "Outcome");
			LoggingInfo("Selected outcome as-" + outcomeOption);

		} catch (Exception e) {
			Log.error("Failed verify And Enter eligibility Outcome- " + e.getMessage());
			Assert.fail("Failed verify And Enter eligibility Outcome- " + e.getMessage());
		}
	}

	/**
	 * Function:Select Prescription on order details
	 * 
	 * @author Trupti
	 **/
	public void enterOrderDetails() {
		try {
			waitAndVerifyElement(elePrescription);
			click(elePrescription);
			LoggingInfo("Selected Prescription on Order Details");
			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to enter order details - " + e.getMessage());
			Assert.fail("Failed to enter order details- " + e.getMessage());
		}
	}

	// Anand P
	public void verifyNoRecordMsg() {
		try {
			setTimeOut(1000);
			By noRecordMsg = By.xpath("//*[text()=\"No records to display\"]");
			waitAndVerifyElement(noRecordMsg);
			LoggingInfo("Successfully verified the message");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to verify no records msg - " + e.getMessage());
			Assert.fail("Failed to verify no records msg- " + e.getMessage());

		}

	}

	/**
	 * Function:Attachment checkbox
	 * 
	 * @author Anand P
	 **/

	public void checkAttachCheckbox() {
		try {
			setTimeOut(10000);
			waitAndVerifyElement(attachCheckbox);
			scrollToElement(attachCheckbox);
			click(attachCheckbox);
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to Click on checkbox button " + e.getMessage());
			Assert.fail("Failed to Click on checkbox button " + e.getMessage());
		}
	}

	/**
	 * Function:Click on submit button
	 * 
	 * @author Trupti
	 **/
	public void clickOnSubmitButton() {
		try {
			Log.info("Verify user is able to click on Submit button");
			By eleSubmitButton = getDynamicElement(button, "Submit");
			waitAndVerifyElement(eleSubmitButton);
			scrollToElement(eleSubmitButton);
			click(eleSubmitButton);
			setTimeOut(8000);
			LoggingInfo("User clicks on Submit button");
			setTimeOut(8000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Submit Button " + e.getMessage());
			Assert.fail("Failed to click on Submit Button " + e.getMessage());
		}
	}

	public void selectOrderDetails() {
		try {
			By eleOrderName = getDynamicElement(strOrderRadio, "Name");
			waitAndVerifyElement(eleOrderName);
			clickByJavascript(eleOrderName);

			LoggingInfo("Selected Order Details");
			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to select order details - " + e.getMessage());
			Assert.fail("Failed to select order details- " + e.getMessage());
		}
	}

	/**
	 * Function:Check Quick start task completion
	 * 
	 * @author Trupti
	 **/
	public void checkQuickStartTaskComplition() {
		try {
			waitAndVerifyElement(eleMainTaskStatus);
			String mainTaskStatus = getText(eleMainTaskStatus);
			Assert.assertEquals(mainTaskStatus, "Done", "QS Summary task completed successfully");
			LoggingInfo("QS Summary task completed successfully");

			By eleTaskButton = getDynamicElement(taskButton, "QS Summary");
			scrollToElement(eleTaskButton);
			click(eleTaskButton);
			LoggingInfo("Clicked on QS summary task");
			setTimeOut(1000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, "Enrollment");
			waitAndVerifyElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Completed", "Enrollment sub task completed successfully");
			LoggingInfo("Enrollment sub task completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to check Quick Start Task Complition " + e.getMessage());
			Assert.fail("Failed to check Quick Start Task Complition " + e.getMessage());
		}
	}

	/**
	 * Function:Check check CPE Product Record
	 * 
	 * @author Trupti
	 **/
	public void checkCPEProductRecord(String cpeRecord) {
		try {
			waitForPageLoaded();
			boolean recordFound = false;
			if (verifytable("Care Program Enrollee Products")) {
				List<WebElement> rows = getWebDriver().findElements(eleCPETable);
				scrollToElement(eleCPETable);
				for (WebElement row : rows) {
					WebElement nameElement = row.findElement(By.xpath(".//*[@data-label=\"Care Program Product\"]//a"));
					String cpeName = nameElement.getAttribute("title");
					if (cpeName.equals(cpeRecord)) {
						recordFound = true;
						System.out.println(cpeName);
						break;
					}

				}
				Assert.assertTrue(recordFound,
						"CPE Record '" + cpeRecord + "' not found in the Care program enrollee product table.");
				LoggingInfo("Verification completed for CPE Record: " + cpeRecord);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to CPE product record " + e.getMessage());
			Assert.fail("Failed to CPE product record " + e.getMessage());
		}
	}

	public String getOrderNumber() {
		try {
			setTimeOut(2000);
			scrollToElement(eleOderTitle);
			setTimeOut(4000);
			waitAndVerifyElement(eleOderNumber);
			orderNumber = getText(eleOderNumber);
			System.out.print(orderNumber);
			LoggingInfo("Order Number retuned successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to return order number " + e.getMessage());
			Assert.fail("Failed to return order number " + e.getMessage());
		}
		return orderNumber;
	}

	public void searchOrder(String orderNumber) {
		try {
			click(searchDocInput);
			inputText(searchDocInput, orderNumber);
			genericKeyPress(searchDocInput, "Enter");
			waitForPageLoaded();
			LoggingInfo("Order Number searched successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to search order number" + e.getMessage());
			Assert.fail("Failed to search order number" + e.getMessage());

		}
	}

	public void clickOnRecord(String orderNumber) {
		try {
			By record = getDynamicElement(strRecordName, orderNumber);
			waitAndVerifyElement(record);
			clickByJavascript(record);
			setTimeOut(5000);
			LoggingInfo("clicked on order number successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on order number" + e.getMessage());
			Assert.fail("Failed to click on order number" + e.getMessage());

		}
	}

	public void navigateToAccount(String accountName) {
		try {
			By eleAccount = getDynamicElement(strAccount, accountName);
			waitAndVerifyElement(eleAccount);
			clickByJavascript(eleAccount);
			setTimeOut(2000);
			LoggingInfo("clicked on Account successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Account" + e.getMessage());
			Assert.fail("Failed to  click on Account" + e.getMessage());

		}
	}

	public void navigateToCPERecord(String cpeName) {
		try {
			By eleCPE = getDynamicElement(strCPE, cpeName);
			waitAndVerifyElement(eleCPE);
			clickByJavascript(eleCPE);
			setTimeOut(2000);
			LoggingInfo("clicked on CPE successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to  click on CPE" + e.getMessage());
			Assert.fail("Failed to  click on CPE" + e.getMessage());

		}
	}

	public void navigateToQuickStartCPE(String quickStartCPE) {
		try {
			By eleQuickStartCPE = getDynamicElement(strQuickStartCPE, quickStartCPE);
			waitAndVerifyElement(eleQuickStartCPE);
			clickByJavascript(eleQuickStartCPE);
			setTimeOut(2000);
			LoggingInfo("clicked on Quick Start CPE successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to  click on Quick Start CPE" + e.getMessage());
			Assert.fail("Failed to click on Quick Start CPE" + e.getMessage());

		}
	}

	// Anand P
	public void validateEnrollmentStartEndDate() {
		try {
			// Enrollment Start Date
			By startDate = getDynamicElement(strQuickStartFields, "Enrollment Start Date");
			waitAndVerifyElement(startDate);
			scrollToElement(startDate);
			highLightElement(startDate);
			String expectedStartDate = Utility_Function.getNthDayFromTodayFormatted(0);
			String actualStartDate = getWebDriver().findElement(startDate).getText();
			Assert.assertEquals(actualStartDate, expectedStartDate, "Enrollment start date matches");
			LoggingInfo("Enrollment start date is current date ");
			setTimeOut(2000);

			// Enrollment End Date
			By endDate = getDynamicElement(strQuickStartFields, "Enrollment End Date");
			waitAndVerifyElement(endDate);
			scrollToElement(endDate);
			highLightElement(endDate);
			String expectedEndDate = Utility_Function.getNthDayFromTodayFormatted(365);

			String actualEndDate = getWebDriver().findElement(endDate).getText();
			Assert.assertEquals(actualEndDate, expectedEndDate, "Enrollment end date matches");
			LoggingInfo("Enrollment end date is current date + 365");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate enrollment start and end date " + e.getMessage());
		}
	}

	/**
	 * Function:Verify order details in in order table
	 * 
	 * @author Trupti
	 **/

	public void verifyOrderDetails(String patientName) {
		try {
			LoggingInfo(
					"After Triage is completed, navigate to the Order object and validate that Order details are generated on Patient's name. ");
			boolean nameFound = false;
			if (verifytable("Orders")) {
				List<WebElement> rows = getWebDriver().findElements(eleOrderTable);
				scrollToElement(eleOrderTable);
				for (WebElement row : rows) {
					WebElement woElement = row.findElement(By.xpath(".//*[@data-label=\"CPE Work Order\"]//a"));

					((JavascriptExecutor) getWebDriver()).executeScript(
							"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
							woElement);
					String workOrderName = woElement.getAttribute("Title");
					if (workOrderName.equals("Quick Start")) {
						WebElement nameElement = row.findElement(By.xpath(".//*[@data-label=\"Account Name\"]//a"));

						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								nameElement);
						String name = nameElement.getAttribute("Title");
						Assert.assertEquals(patientName, name, "Work order generated");
						nameFound = true;
						break;
					}

				}
				Assert.assertTrue(nameFound, "Name not found in the Order table.");
				LoggingInfo("Verification completed: ");
			}
		} catch (Exception e) {
			Log.error("Failed to navigate to orders table  " + e.getMessage());
			Assert.fail("Failed to navigate to orders table  " + e.getMessage());
		}
	}

	// Anand P
	public void clickOnQSOrderPrescription() {

		try {
			By linkQS = By.xpath("(.//*[@data-label=\"Prescription\"]//a)[1]");
			waitAndVerifyElement(linkQS);
			scrollToElement(linkQS);
			click(linkQS);
			setTimeOut(3000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Quick Start Prescription    " + e.getMessage());
			Assert.fail("Failed to click on Quick Start Prescription  " + e.getMessage());

		}
	}

	// Anand P
	public void editPrescriptionStatus(String status) {
		try {

			waitAndVerifyElement(eleEditStatus);
			scrollToElement(eleEditStatus);
			clickByJavascript(eleEditStatus);
			setTimeOut(3000);

			By statusDropDown = getDynamicElement(strDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);
			setTimeOut(4000);
			By statusDropDownList = getDynamicElement(strDropDownBoxOptions, "Status");
			waitAndVerifyElement(statusDropDownList);
			selectItemFromList(statusDropDown, statusDropDownList, status, "Status");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Quick Start Prescription    " + e.getMessage());
			Assert.fail("Failed to click on Quick Start Prescription  " + e.getMessage());

		}
	}

	/**
	 * Function:Click on Next button
	 * 
	 * @author Anand P
	 **/
	public void clickOnNextButton() {
		try {
			Log.info("Verify user is able to click on Next button");
			By eleSubmitButton = getDynamicElement(button, "Next");
			waitAndVerifyElement(eleSubmitButton);
			scrollToElement(eleSubmitButton);
			click(eleSubmitButton);
			setTimeOut(2000);
			LoggingInfo("User clicks on Submit button");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Next Button " + e.getMessage());
			Assert.fail("Failed to click on Next Button " + e.getMessage());
		}
	}

	/**
	 * Function:Click on Next button
	 * 
	 * @author Anand P
	 **/
	public void clickOnEditButton() {
		try {
			Log.info("Verify user is able to click on Edit button");
			By eleSubmitButton = getDynamicElement(button, "Edit");
			waitAndVerifyElement(eleSubmitButton);
			scrollToElement(eleSubmitButton);
			clickByJavascript(eleSubmitButton);
			setTimeOut(2000);
			LoggingInfo("User clicks on Edit button");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Edit Button " + e.getMessage());
			Assert.fail("Failed to click on Edit Button " + e.getMessage());
		}
	}

	/**
	 * Function:Click on Next button
	 * 
	 * @author Anand P
	 **/
	public void clickOnCancelButton() {
		try {
			Log.info("Verify user is able to click on Cancel button");
			By eleSubmitButton = getDynamicElement(button, "Cancel");
			waitAndVerifyElement(eleSubmitButton);
			scrollToElement(eleSubmitButton);
			clickByJavascript(eleSubmitButton);
			setTimeOut(2000);
			LoggingInfo("User clicks on Cancel button");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Cancel Button " + e.getMessage());
			Assert.fail("Failed to click on Cancel Button " + e.getMessage());
		}
	}

	/**
	 * Function:Click on Create New button
	 * 
	 * @author Anand P
	 **/
	public void clickOnCreateNewButton() {
		try {
			Log.info("Verify user is able to click on Create New button");
			By eleNewButton = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Create New\"]");
			waitAndVerifyElement(eleNewButton);
			scrollToElement(eleNewButton);
			clickByJavascript(eleNewButton);
			setTimeOut(2000);
			LoggingInfo("User clicks on Create New button");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Create New Button " + e.getMessage());
			Assert.fail("Failed to click on Create New Button " + e.getMessage());
		}
	}

	// Anand P
	public void clickOnPreviousButton() {
		try {
			Log.info("Verify user is able to click on Next button");
			By eleSubmitButton = getDynamicElement(button, "Previous");
			waitAndVerifyElement(eleSubmitButton);
			scrollToElement(eleSubmitButton);
			click(eleSubmitButton);
			setTimeOut(2000);
			LoggingInfo("User clicks on Previous button");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Previous Button " + e.getMessage());
			Assert.fail("Failed to click on Previous Button " + e.getMessage());
		}
	}

	/**
	 * Function:Edit CPEP details
	 * 
	 * @author Trupti Zure
	 **/
	public void editCPEPDetails(String status, String reason) {
		try {
			// Status
			By editStatus = getDynamicElement(editButton, "Edit Status");
			waitAndVerifyElement(editStatus);
			scrollToElement(editStatus);
			setTimeOut(2000);
			click(editStatus);
			By statusList = getDynamicElement(editFieldList, "Status");
			waitAndVerifyElement(statusList);
			click(statusList);
			By statusListDropDownOptions = getDynamicElement(editFieldListOptions, "Status");
			waitAndVerifyElement(statusListDropDownOptions);
			selectItemFromList(statusList, statusListDropDownOptions, status, "Status");

			// Discontinuation Reason
			By reasonList = getDynamicElement(editFieldList, "Discontinuation Reason");
			waitAndVerifyElement(reasonList);
			scrollToElement(reasonList);
			click(reasonList);
			By reasonListDropDownOptions = getDynamicElement(editFieldListOptions, "Discontinuation Reason");
			selectItemFromList(reasonList, reasonListDropDownOptions, reason, "Discontinuation Reason");

			if (status.equalsIgnoreCase("Discontinued")) {
				// Discontinuation Date
				By discontinuationDate = getDynamicElement(inputField, "Discontinuation Date");
				waitAndVerifyElement(discontinuationDate);
				scrollToElement(discontinuationDate);
				String date = getDateNDaysFromToday(0);
				inputText(discontinuationDate, date);
				setTimeOut(2000);
				click(reasonList);

			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to update CPEP details " + e.getMessage());
			Assert.fail("Failed to update CPEP details " + e.getMessage());
		}
	}

	/**
	 * Function:Verify Field is present
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyFieldIsPresent(String label) {
		try {
			By fieldName = getDynamicElement(labelsField, label);
			boolean found = isElementPresent(fieldName);
			Assert.assertTrue(found);
			scrollToElement(fieldName);
			LoggingInfo("Field is present on layout- " + label);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Next Button " + e.getMessage());
			Assert.fail("Failed to click on Next Button " + e.getMessage());
		}
	}

	/**
	 * Function:Verify outcome field as approved
	 * 
	 * @author Kavyashree
	 **/
	public void validateOutcome(String expectedOutCome) {
		try {

			By eleactualOutcome = getDynamicElement(strQSFields, "Outcome");
			waitAndVerifyElement(eleactualOutcome);
			scrollToElement(eleactualOutcome);
			String actualOutcome = getWebDriver().findElement(eleactualOutcome).getText();
			Assert.assertEquals(actualOutcome, expectedOutCome, "Outcome");
			LoggingInfo("Outcome is displayed as Approved");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate Outcome field " + e.getMessage());
		}
	}

	/**
	 * Function:Verify Patient/Account Name
	 * 
	 * @author Kavyashree
	 **/
	public void verifyPatientName(String accountName) {
		try {

			LoggingInfo("Verify Account Name");
			setTimeOut(2000);
			By eleaccName = getDynamicElement(strOrderFields, "Account Name");
			waitAndVerifyElement(eleaccName);
			verifyDetails(eleaccName, accountName, "Account Name");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Account Name" + e.getMessage());
			Assert.fail("Failed to verify Account Name" + e.getMessage());
		}

	}

	/**
	 * Function:Verify to Navigate to PAP CPE
	 * 
	 * @author Kavyashree MB
	 **/

	public void navigateToPAPCPE(String PAPCPE) {
		try {
			By elePAPCPE = getDynamicElement(strQuickStartCPE, PAPCPE);
			waitAndVerifyElement(elePAPCPE);
			clickByJavascript(elePAPCPE);
			setTimeOut(2000);
			LoggingInfo("clicked on PAP CPE successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to  click on PAP CPE" + e.getMessage());
			Assert.fail("Failed to click on PAP CPE" + e.getMessage());

		}
	}

	/**
	 * Function:Select Prescription on order details
	 * 
	 * @author Kavyashree
	 **/
	public void verifyOrderDetails() {
		try {
			waitAndVerifyElement(elePrescription);
			click(elePrescription);
			LoggingInfo("Selected Prescription on Order Details");
			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to enter order details - " + e.getMessage());
			Assert.fail("Failed to enter order details- " + e.getMessage());
		}
	}

}
