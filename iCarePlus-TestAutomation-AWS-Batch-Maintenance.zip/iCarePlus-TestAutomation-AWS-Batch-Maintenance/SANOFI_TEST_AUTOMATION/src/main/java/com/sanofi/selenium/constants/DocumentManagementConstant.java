package com.sanofi.selenium.constants;

import java.util.ArrayList;
import java.util.Arrays;

public interface DocumentManagementConstant {

	// Success and error messages
	public static final String papApproval = "The Correspondence DMW PAP Approval Medicare Enrollee - MD Fax has been successfully generated.";
	public static final String papRenewal = "The Correspondence DMW PAP Renewal - MD Fax has been successfully generated.";

	public static final String welcomeCorrespondenceErrorMSG = "The correspondence cannot be generated because the Email information is either missing or incomplete.";
	public static final String welcomeCorrespondenceSuccessMSG = "The Correspondence DMW Checkbox Welcome has been successfully generated.";
	public static final String summaryofBenefitPTLetterErrorMSG = "The correspondence cannot be generated because the Mailing Address information is either missing or incomplete.";
	public static final String summaryofBenefitPTLetterSuccessMSG = "The Correspondence DMW Summary of Benefits - PT Letter has been successfully generated.";
	public static final String summaryofBenefitMDFAXSuccessMSG = "The Correspondence DMW Summary of Benefits - MD Fax has been successfully generated.";
	public static final String welcomeSMSsuccessMSG = "The Correspondence Welcome SMS has been successfully generated.";
	public static final String summaryofBenefitsPASuccessMSG = "The Correspondence DMW Summary of Benefits (PA) - MD Fax has been successfully generated.";
	public static final String summaryofBenefitMDFAXErrorMSG = "Patient do not have any member plan";
	public static final String QSSuccessMSG = "The Correspondence Quick Start Program Notification of Program End Date – MD Fax has been successfully generated.";
	public static final String consentSuccessMSG = "Selected Consent has been successfully created.";

	public static final String statusFailed = "Failed";

	public static final ArrayList<String> processName = new ArrayList<>(
			Arrays.asList("Welcome Correspondence", "BV", "PA", "Med D PAP Re-enrollment", "Fulfillment",
					"PAP Re-Enrollment", "PAP", "IAP", "QuickStart", "Copay", "SP Triage", "Enrollment","DMW PAP Approval Medicare Enrollee - Payer Fax"));
	public static final ArrayList<String> itemsToSend = new ArrayList<>(Arrays.asList("DMW Checkbox Welcome",
			"DMW Summary of Benefits - PT Letter", "DMW Med D PAP Annual Re-Enrollment - HCP Fax",
			"DMW PAP Renewal - MD Fax", "Welcome SMS", "DMW PAP Approval Medicare Enrollee - MD Fax",
			"Quick Start Program Notification of Program End Date – MD Fax", "DMW Welcome (AD)", "DMW Enrollment Form Confirmation - MD Fax",
			"DMW SP Enrollment Form Confirmation - MD Fax","DMW Quick Start Program Approval - PT Letter","DMW Non - Checkbox Welcome"));
	
	public static final ArrayList<String> selectProcessName = new ArrayList<>(Arrays.asList("BV", "PA", "QuickStart","Copay","SP Triage","DMW PAP Approval Medicare Enrollee - Payer Fax"));
	public static final ArrayList<String> itemToSend = new ArrayList<>(Arrays.asList("DMW Summary of Benefits - MD Fax",
			"DMW Summary of Benefits (PA) - PT Letter", "DMW Summary of Benefits (PA) - MD Fax",
			"DMW PAP Discontinuation - MD Fax", "Quick Start Program Notification of Program End Date – MD Fax","DMW Copay Card Information - MD Fax"));;

	public static final ArrayList<String> quickStartItemsToSend = new ArrayList<>(
			Arrays.asList("DMW Quick Start Discontinuation (Obtained Coverage) - MD Fax",
					"DMW Quick Start Program Enrolled - MD Fax", "DMW Quick Start Program Ineligible - MD Fax"));
	public static final ArrayList<String> papItemsToSend = new ArrayList<>(
			Arrays.asList("DMW PAP Alternate Insurance App - MD Fax", "DMW PAP Denial - MD Fax",
					"DMW PAP Approval Medicare Enrollee - Payer Fax","DMW Non - Checkbox Welcome"));
	
	public static final ArrayList<String> iapItemsToSend = new ArrayList<>(
			Arrays.asList("DMW IAP Approval - MD Fax",
					"DMW IAP Discontinuation - MD Fax", "DMW IAP Discontinuation Obtained Coverage - MD Fax", "DMW Lash MD Fax - Interim Access Denial"));
	

	public static final ArrayList<String> bvitemsToSend = new ArrayList<>(
			Arrays.asList("DMW Insurance Coverage Status - PT Email", "DMW Summary of Benefits - PT Letter",
					"DMW Summary of Benefits - MD Fax", "DMW Prescription Transfer Letter"));
	public static final ArrayList<String> channel = new ArrayList<>(Arrays.asList("Fax"));
	public static final ArrayList<String> recipientType = new ArrayList<>(Arrays.asList("HCP"));
	public static final ArrayList<String> serviceArea = new ArrayList<>(Arrays.asList("BV"));
	public static final ArrayList<String> correspondencestatus = new ArrayList<>(Arrays.asList("Sent"));

	// Med D
	public static final ArrayList<String> PeopleInHousehold = new ArrayList<>(Arrays.asList("4"));
	public static final ArrayList<String> AnnualIncome = new ArrayList<>(Arrays.asList("70000"));

	// Secondary member plan
	public static final ArrayList<String> medicalMember = new ArrayList<>(
			Arrays.asList("TestAutomation Payer Medical", "23421", "17184"));
	public static final ArrayList<String> pharamcyMember = new ArrayList<>(
			Arrays.asList("TestAutomation Payer Pharmacy", "1271817190", "65271", "90617", "TestAutomation Payer Pharmacy","9082037482","TestAutomation Payer Medical"));

	// Mi Table names
	public static final ArrayList<String> tableNames = new ArrayList<>(Arrays.asList("Open Cases", "Closed Cases"));
	public static final ArrayList<String> TriageitemToSend = new ArrayList<>(
			Arrays.asList("DMW Notification of Prescription Triage - MD Fax", "DMW Non-Network Referral - SP Fax"));
	
	public static final ArrayList<String> CoresspondenceItemsToSend= new ArrayList<>(Arrays.asList("Free Good Shipment Set Up - SMS","Specialty Pharmacy Shipment Set Up - SMS", "Travel Kit", "Training Device Kit","Dupixent PreFilled Pen Support Kit","Patient Starter Kit - Spanish","Patient Brochure",
			"Sharps Kit","Package Insert","Dupixent Patient Journal","Patient Starter Kit"));

	public static final ArrayList<String> textToValidate = new ArrayList<>(Arrays.asList(
			"Please note that Regeneron Pharmaceuticals, Inc. and Sanofi reserve the right to make eligibility determinations, monitor participation, ensure equitable product availability, and modify or discontinue the DUPIXENT MyWay® Quick Start at any time without notice",
			"US.DUP.24.12.0076", "US.DUP.24.11.0111",
			"Please note that Regeneron Pharmaceuticals, Inc. and Sanofi reserve the right to make eligibility determinations, monitor participation, ensure equitable product availability, and modify or discontinue the DUPIXENT MyWay Patient Assistance Program at any time without notice",
			"Please note that Regeneron Pharmaceuticals, Inc. and Sanofi reserve the right to make eligibility determinations, monitor participation, and modify or discontinue the DUPIXENT Quick Start Program at any time.",
			"As a reminder, you must continue to actively seek coverage through the patient’s commercial insurer to remain eligible for the DUPIXENT Quick Start Program. If you would like your patient's Quick Start eligibility to continue, please take the necessary steps to pursue coverage through your patient's insurer and report coverage updates to DUPIXENT MyWay. If you decline to do so, your patient's enrollment in the DUPIXENT Quick Start Program will end 45 business days from the date of this notification.",
			"DUPIXENT® (dupilumab) Quick Start Program—Notification of Program End Date", "DUP.24.11.0259"));

	public static final ArrayList<String> nursingOutValues = new ArrayList<>(
			Arrays.asList("Completed", "Not Completed"));
	// span[@title='Not Completed']

	public static final ArrayList<String> nursingOutcomeReasonValues = new ArrayList<>(
			Arrays.asList("Training Completed"));

	public static final ArrayList<String> DUPCode = new ArrayList<>(Arrays.asList("DUP.24.11.0259", "US.DUP.24.11.0113",
			"US.DUP.24.11.0114", "US.DUP.24.11.0111", "US.DUP.24.12.0076","US.DUP.25.05.0073"));

	public static final ArrayList<String> MDfax = new ArrayList<>(Arrays.asList("1-844-387-9370"));

}
