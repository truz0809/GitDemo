package com.sanofi.selenium.apiutils;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
//import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.Configuration;
import com.sanofi.selenium.core.Utility_Function;

import io.restassured.path.json.JsonPath;

public class Auth extends BaseTest {

	private static String baseUri;
	private static Header oauthHeader;

	public static String[] getLoginAccessToken() {

		HttpClient httpclient = HttpClientBuilder.create().build();
		String loginURL = null;
		String env;

		try {
			env = Configuration.readApplicationFile("API_ENV");
			loginURL = LOGINURL + GRANTSERVICE + "&client_id=" + CLIENTID + "&client_secret=" + CLIENTSECRET
					+ "&username=" + USERNAME + "&password=" + PASSWORD;

		} catch (Exception e) {

			e.printStackTrace();
		}

		HttpPost httpPost = new HttpPost(loginURL);
		HttpResponse response = null;

		try {
			response = httpclient.execute(httpPost);
		} catch (ClientProtocolException cpException) {
			cpException.printStackTrace();
		} catch (IOException ioException) {
			ioException.printStackTrace();
		}

		final int statusCode = response.getStatusLine().getStatusCode();
		if (statusCode != HttpStatus.SC_OK) {
			System.out.println("Error authenticating to Force.com: " + statusCode);
		}

		String getResult = null;
		try {
			getResult = EntityUtils.toString(response.getEntity());
		} catch (IOException ioException) {
			ioException.printStackTrace();
		}

		JSONObject jsonObject = null;
		String loginAccessToken = null;
		String loginInstanceUrl = null;

		try {
			jsonObject = (JSONObject) new JSONTokener(getResult).nextValue();
			loginAccessToken = jsonObject.getString("access_token");
			loginInstanceUrl = jsonObject.getString("instance_url");
		} catch (JSONException jsonException) {
			jsonException.printStackTrace();
		}

		baseUri = loginInstanceUrl + REST_ENDPOINT + API_VERSION;
		oauthHeader = new BasicHeader("Authorization", "OAuth " + loginAccessToken);
		System.out.println("Successful login");

		String[] vals = { baseUri, loginAccessToken };

		return vals;
	}


	public static String getMcKAuthToken() throws InterruptedException {

		String response = null;
		String accessToken = null;
		String errMessage = null;
		try {
			response = given()
					 .urlEncodingEnabled(false)
              .queryParams("client_id", mCK_ClientId)
              .queryParams("client_secret", mCK_ClientSecrete).queryParams("grant_type", mCK_GrantType)
             .queryParam("scope", mCK_Scope)
             .when().log().all()
             .post(mCK_Token_URL).asString();

			System.out.println(response);

			JsonPath jsonPath = new JsonPath(response);

			accessToken = jsonPath.getString("access_token");
			errMessage = jsonPath.getString("error");
			if (accessToken != null && accessToken != "") {
				System.out.println("Successfully get the McKesson Access Token-" + accessToken);
			} else if (errMessage != null && errMessage != "") {
				System.out.println("Failed to get MCKesson API access Token.This is the error message-" + errMessage);

			}
		} catch (Exception e) {
			System.out.println("Failed to get MCKesson API access Token.This is the error message-" + errMessage);
		}
		return accessToken;
	}
	
}
