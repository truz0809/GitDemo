package com.sanofi.selenium.core;

import org.openqa.selenium.WebDriver;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.formula.functions.T;
import org.apache.poi.ss.usermodel.Cell;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.joda.time.DateTime;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.sanofi.selenium.apiutils.Payload;
import com.sanofi.selenium.apiutils.Queries;
import com.itextpdf.forms.PdfAcroForm;
import com.itextpdf.forms.fields.PdfFormField;
import com.itextpdf.forms.fields.properties.CheckBoxType;
import com.sanofi.selenium.apiutils.Auth;
import com.sanofi.selenium.utils.Listeners;
import com.sanofi.selenium.utils.Log;
import com.sanofi.selenium.utils.ReadExcel;
import com.sanofi.selenium.xpaths.casesPageXpaths;
import io.restassured.path.json.JsonPath;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.coordinates.WebDriverCoordsProvider;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.time.Year;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Utility_Function extends BaseTest {

	// protected static WebDriver driver;
	// public static ArrayList<String> cellValues;

	public Utility_Function(WebDriver driver) {
		// this.driver = driver;
	}

	public static SimpleDateFormat format;
	public static Calendar calendar;

	public static By elePreviewModelCloseBTN = By.xpath("//button[@title='Close this window']");
	public static final By eleNoResults = By.xpath("//div[contains(text(),\"No results for\")]");
	public static final By eleSelectDropdown = By.xpath("//*[contains(@class,\"active lafPageHost\")]//select");
	public static final By toAccountInputBox = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"To Account\"]/../div//input");
	// Dynamic Locators
	public static String strFooterButtonXpath = "//button//span[text()=\"{0}\"]";
	public static String eleShowAllResults = "//span[contains(text(),\"Show All\") and contains(@title,\"{0}\")]/parent::span";
	private static String strDropDownButtonXpath = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::*//following-sibling::div//button";

	private static String strDropdownOptionsXpath = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-dropdown-trigger_click slds-is-open\")]//*[@title=\"{0}\"]";
	public static String strSearchInputXpath = "//*[contains(@class,\"active lafPageHost\")]//input[@placeholder=\"{0}\"]";
	private static String strSearchOptionsListXpath = "//*[contains(@class,\"active lafPageHost\")]//*[@role=\"listbox\"]//*[contains(@class,\"slds-has-focus\")]//parent::*//*[@title=\"{0}\"]";
	public static String strLightningTextXpath = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"card\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*//lightning-formatted-text";
	private static String strLinkithStatusAndOutcomeXpath = "//*[contains(@class,\"active lafPageHost\")]//*[@title=\"{0}\"]//ancestor::tr//*[text()=\"{1}\"]//ancestor::tr//th//a";
	private static String assertError = "//div[contains(@class, \"uiContainerManager\")]//div[@role=\"dialog\"]//li[contains(text(),\"{0}\")]";
	public static String assertError1 = "//div//*[contains(text(),\"{0}\")]";
	public static String strButton = "//button[@title=\"{0}\"]";
	public static String strFooterButton = "//*[contains(@class,\"modal-footer\")]//button[@title=\"{0}\"]";
	public static String dropDownValue = "//*[contains(@class,\"active lafPageHost\")]//*[@title=\"{0}\"]/parent::span";
	public static String selectField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::*//following-sibling::div//button";

	public static String lightningText = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::div//following-sibling::div//lightning-formatted-text";
	public static String strLinkText = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*//span//a//span";
	public static String strLinkTextAchorTag = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"card\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*//span//a";
	public static String strTypeText = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::*/parent::*//following-sibling::*//*[contains(@class,'recordTypeName')]/span";

	public static String strFieldsXpath = "//*[contains(@class,\"active lafPageHost\")]//*[@field-label=\"{0}\"]";
	public static String strCheckBoxElement = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::*/parent::*//following-sibling::*/*//input";
	public static String strFieldsSpanXpath = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"field-label-container\")]//span[text()=\"{0}\"]";
	public static String fieldSearchBoxSelectionXpath = "//*[contains(@class,\"active lafPageHost\")]//span//*[@title=\"{0}\"]";
	private static String fieldsUnderSection = "//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"{0}\")]/ancestor::records-record-layout-section//*[text()=\"{1}\"]";
	public static By strPopUpCommentContainerTextArea = By.xpath("//*[@class=\"commentContainer\"]//textarea");
	public static String commonH2TextElement = "//*[contains(@class,\"active lafPageHost\")]//h2//span[contains(text(),\"{0}\")]";
	public static String commonH2TextElement1 = "//*[contains(@class,\"active lafPageHost\")]//h2//span[contains(text(),\"{0}\")]/parent::a/span[@title=\"({1})\"]";
	public static String strRxDoseReadOnlyField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*//span[contains(@class,\"is-read-only\")]";
	public static By commentMessage = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Comments\"]//parent::*/parent::*//following-sibling::*//*//span[@class=\"uiOutputTextArea\"]");
	public static final By eleUploadFileInput = By.xpath("//input[@type='file']");
	public static String strGenericBtn = "//*[text()=\"{0}\"]";
	public static String strChecboxValueXpath = "//input[@value=\"{0}\"]";
	public static String eleFieldDate = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::fieldset//label[text()=\"{1}\"]/following-sibling::div//input";
	public static String lightningTextAge = "//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*/div//lightning-formatted-text";
	public static By eleFieldLevelError = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//ul[contains(@class,'has-error uiInputDefaultError uiInput')]//li");
	public static By eleSnagErrorMessageText = By
			.xpath("//*[text()='We hit a snag.']//ancestor::div[@class='container']//div//*//li");
	public static String strColoumnName = "//span[@title=\"{0}\"]";
	public static String dropDownListOption = "//*[text()=\"{0}\"]//following-sibling::div//*//lightning-base-combobox-item//*//span[@class='slds-truncate']";
	public static String dateField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label/following-sibling::div//input";
	public static String strAccountNameInputBoxXpath = "//*[text()=\"Account Name\"]/following-sibling::div//input[@placeholder=\"{0}\"]";
	public static String linkText = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*/div//a//span";
	public static String EditTaskFields = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*//button";
	public static String taskFieldText = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"card\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*//span//span";
	public static By eleLastOfferedDate = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Alternate Resources Information\"]//ancestor::*[contains(@class,\"card\")]//*[text()=\"Last Offered Alternative Resources Date\"]//ancestor::dt//following-sibling::*//span//lightning-formatted-text");
	public static String strCheckBoxXpath = "//input[@name=\"{0}\"]";
	public static String eleQuickActionsPanel = "//div[@class=\"quick-actions-panel\"]//p";
	public static By uploadDoc = By.xpath("//div[@title='Upload Documents']");
	public static By Done = By.xpath("//span[text()='Done']");

	public static final By eleCloseTabButton = By
			.xpath("//ul[contains(@class,'tabBarItems slds-grid')]//*[contains(@title,'Close') and @type='button']");

	public static By eleCloseButton = By.xpath("(//button[@title=\"Close this window\"]//span)[1]");

	// Object repository for Utility_Functions class

	// *********************************************************************************************************
	// Function name: deleteExistingDirectory()
	// Description: To delete the existing directory while capturing the screenshot

	// *********************************************************************************************************
	public static void deleteExistingDirectory(File file) throws IOException {
		try {
			if (file.isDirectory()) {

				/* Delete the directory if empty */
				if (file.list().length == 0) {

					file.delete();

				} else {

					/* List all the directory contents */
					String files[] = file.list();

					for (String temp : files) {
						/* Construct the file structure */
						File fileDelete = new File(file, temp);

						/* Recursive delete */
						deleteExistingDirectory(fileDelete);
					}

					/* Check the directory again, if empty then delete it */
					if (file.list().length == 0) {
						file.delete();
					}
				}

			} else {
				file.delete();
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Error - " + e.getMessage());
			Assert.fail("Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Select Radio Button
	 * 
	 * @param
	 * 
	 * @author Yuti Shah
	 */
	public void selectRadioButton(String xPath, String type) {

		try {
			Log.info("Selecting " + type);
			By radioBTNElement = getDynamicElement(xPath, type);
			waitAndVerifyElement(radioBTNElement);
			clickByJavascript(radioBTNElement);
			LoggingInfo("Selected " + type);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Selecting radio button failed" + ". Error - " + e.getMessage());
		}

	}

	// *********************************************************************************************************
	// Function name: getSeleniumScreenshot()
	// Description: To capture the full page screenshot at any particular step

	// *********************************************************************************************************
	public void getSeleniumScreenshot(String testCaseName, String actual_result, String screenshotName)
			throws Exception {
		try {
			waitFor(1000);
			File file = new File("Screenshots");
			deleteExistingDirectory(file);
			File scrFile = ((TakesScreenshot) getWebDriver()).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("Screenshots/" + testCaseName + "/" + screenshotName + ".jpeg"), true);

			Log.info("Screenshot taken successfully - " + actual_result);
			Assert.assertTrue(true, "Screenshot taken successfully - " + actual_result);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Screenshot taking activity failed. Error - " + e.getMessage());
			Assert.fail("Screenshot taking activity failed. Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: getscreenshot()
	// Description: To capture the full page screenshot at any particular step

	// *********************************************************************************************************
	public void getSpecificElementcreenshot(WebElement webElement, String strTestCaseName, String strActualResult,
			String strScreenshotName) throws Exception {
		try {
			waitFor(1000);
			File file = new File("Screenshots");
			deleteExistingDirectory(file);

			File outputfile = new File("image.jpeg");

			// For headless browser execution
			WebElement element = webElement;
			element.click();
			Screenshot screenshot = new AShot().coordsProvider(new WebDriverCoordsProvider())
					.shootingStrategy(ShootingStrategies.viewportPasting(100)).takeScreenshot(getWebDriver(), element);

			// For local browser execution
			/*
			 * Screenshot screenshot = new AShot()
			 * .shootingStrategy(ShootingStrategies.viewportRetina(1000, 0, 0, (float) 1.5))
			 * .takeScreenshot(getWebDriver());
			 */

			// Take the screenshot of the entire home page and save it to a png file
			// Screenshot screenshot = new
			// AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(getWebDriver());

			File srcFile = outputfile;
			FileUtils.copyFile(srcFile, new File("Screenshots/" + strTestCaseName + "/" + strScreenshotName + ".jpeg"),
					true);

			Log.info(strActualResult);
			Assert.assertTrue(true, "Screenshot taken successfully - " + strActualResult);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Screenshot taking activity failed. Error - " + e.getMessage());
			Assert.fail("Screenshot taking activity failed. Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: compareHashMap()
	// Description: To compare any two strings

	// *********************************************************************************************************
	public boolean compareHashMap(HashMap<String, String> strMap1, HashMap<String, String> strMap2) {
		try {
			if (!strMap1.equals(strMap2)) {
				HashMap<String, String> result = new HashMap<String, String>();
				Set<Map.Entry<String, String>> set = strMap1.entrySet();
				for (Map.Entry<String, String> entry : strMap2.entrySet()) {
					if (!set.contains(entry)) {
						result.put(entry.getKey(), entry.getValue());
					}
				}
				for (String s : result.keySet()) {
					System.out
							.println(" Key = " + s + ",Value = " + result.get(s) + " of map1 are not present in map2");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Error - " + e.getMessage());
			Assert.fail("Error - " + e.getMessage());
		}
		return (strMap1.equals(strMap2));
	}

	// *********************************************************************************************************
	// Function name: click()
	// Description: To click on any object
	// Prerequisite:

	// *********************************************************************************************************
	public void click(By objToBeClicked) {
		try {
			waitAndVerifyElement(objToBeClicked);
			setTimeOut(1000);
			getWebDriver().findElement(objToBeClicked).click();
			Log.info("Click on object successful - " + objToBeClicked);
			Assert.assertTrue(true, "Click on object successful - " + objToBeClicked);
			setTimeOut(1000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Click on object unsuccessful - " + objToBeClicked + ". Error - " + e.getMessage());
			Assert.fail("Click on object unsuccessful - " + objToBeClicked + ". Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: inputText()
	// Description: TO enter values in any input textbox element on the page
	// *********************************************************************************************************
	public void inputText(By objToInputTextInto, String strTextToInput) {
		try {
			waitAndVerifyElement(objToInputTextInto);
			clearText(objToInputTextInto);
			waitFor(2000);
			getWebDriver().findElement(objToInputTextInto).sendKeys(strTextToInput);
			Log.info("Text input successful in -  " + objToInputTextInto);
			Assert.assertTrue(true, "Text input successful in -  " + objToInputTextInto);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text input unsuccessful in - " + objToInputTextInto + ". Error - " + e.getMessage());
			Assert.fail("Text input unsuccessful in - " + objToInputTextInto + ". Error - " + e.getMessage());
		}
	}

	public void enterText(By objToInputTextInto, String strTextToInput, String fieldName) {
		try {
			waitAndVerifyElement(objToInputTextInto);
			clearText(objToInputTextInto);
			waitFor(2000);
			getWebDriver().findElement(objToInputTextInto).sendKeys(strTextToInput);
			Log.info("Text input successful in -  " + objToInputTextInto);
			LoggingInfo("Text input successful in -  " + fieldName);
			setTimeOut(1000);
			Assert.assertTrue(true, "Text input successful in -  " + objToInputTextInto);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text input unsuccessful in - " + objToInputTextInto + ". Error - " + e.getMessage());
			Assert.fail("Text input unsuccessful in - " + objToInputTextInto + ". Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: Refresh()
	// Description: To Refresh to current URL page

	// *********************************************************************************************************
	public void refresh() {
		getWebDriver().navigate().refresh();
		setTimeOut(500);

	}
	// *********************************************************************************************************
	// Function name: navigate()
	// Description: To navigate to any URL mentioned

	// *********************************************************************************************************
	public void navigate(String strUrlToNavigate) {
		try {
			getWebDriver().get(strUrlToNavigate);
			getWebDriver().manage().window().maximize();
			Log.info("Navigated to URL - " + strUrlToNavigate);

			Assert.assertTrue(getWebDriver().getCurrentUrl().contains(strUrlToNavigate),
					"Navigated to URL - " + strUrlToNavigate);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Navigation to url failed- " + strUrlToNavigate + ". Error - " + e.getMessage());
			Assert.fail("Navigation to url failed- " + strUrlToNavigate + ". Error - " + e.getMessage());
		}
	}

	// Function name: selectItemFromList()
	// Description: To select a value from any Dropdown list using Select class
	// Prerequisite:
	// *********************************************************************************************************
	public static void selectItemFromList(By objToSelectValueFrom, String strValueToBeSelected) {
		try {
			if (methodToAvoidStaleElementReferenceErrorElement(objToSelectValueFrom)) {
				waitAndVerifyElement(objToSelectValueFrom);
				WebElement element = getWebDriver().findElement(objToSelectValueFrom);
				Select se = new Select(element);
				se.selectByVisibleText(strValueToBeSelected);
				Log.info(strValueToBeSelected + " option selected in picklist - " + objToSelectValueFrom);
				Assert.assertTrue(true,
						strValueToBeSelected + " option selected in picklist - " + objToSelectValueFrom);
			} else {
				Log.error("Not able to select " + strValueToBeSelected + " in " + objToSelectValueFrom);
				Assert.fail("Not able to select " + strValueToBeSelected + " in " + objToSelectValueFrom);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Not able to select " + strValueToBeSelected + " in " + objToSelectValueFrom + ". " + " Error - "
					+ e.getMessage());
			Assert.fail("Not able to select " + strValueToBeSelected + " in " + objToSelectValueFrom + ". "
					+ " Error - " + e.getMessage());
		}
	}

//	public void selectItemFromList(By objToSelect, By objSelectListText, String strValueToBeSelected,
//	        String excelconstant) {
//	    try {
//	        if (methodToAvoidStaleElementReferenceErrorElement(objToSelect)) {
//	            waitAndVerifyElement(objSelectListText);
// 
//	            List<WebElement> listOptions = getWebDriver().findElements(objSelectListText);
//	            WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(10));
// 
//	            boolean found = false;
// 
//	            for (WebElement option : listOptions) {
//	                String optionText = option.getText().trim();
// 
//	                if (optionText.equalsIgnoreCase(strValueToBeSelected)) {
//	                    ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].scrollIntoView(true);", option);
// 
//	                    wait.until(ExpectedConditions.elementToBeClickable(option));
// 
//	                    try {
//	                        option.click();
//	                    } catch (ElementClickInterceptedException e) {
//	                        Log.info("Standard click failed, trying JavaScript click: " + e.getMessage());
//	                        ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", option);
//	                    }
// 
//	                    found = true;
//	                    Log.info(strValueToBeSelected + " option selected in picklist - " + excelconstant);
//	                    Assert.assertTrue(true, strValueToBeSelected + " option selected in picklist - " + excelconstant);
//	                    break;
//	                }
//	            }
// 
//	            if (!found) {
//	                Log.error("Value '" + strValueToBeSelected + "' not found in list for " + excelconstant);
//	                Assert.fail("Value '" + strValueToBeSelected + "' not found in list for " + excelconstant);
//	            }
//	        } else {
//	            Log.error("Dropdown not available for selection in " + excelconstant);
//	            Assert.fail("Dropdown not available for selection in " + excelconstant);
//	        }
//	    } catch (Exception e) {
//	        e.printStackTrace();
//	        Log.error("Error selecting " + strValueToBeSelected + " in " + excelconstant + ". Error: " + e.getMessage());
//	        Assert.fail("Error selecting " + strValueToBeSelected + " in " + excelconstant + ". Error: " + e.getMessage());
//	    }
//	}  

	/*
	 * @Author - Anand Pawar
	 */
	public void selectItemFromList(By objToSelect, By objSelectListText, String strValueToBeSelected,
			String excelconstant) {
		try {
			if (methodToAvoidStaleElementReferenceErrorElement(objToSelect)) {
				waitAndVerifyElement(objSelectListText);

				List<WebElement> listOptions = getWebDriver().findElements(objSelectListText);
				WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(10));

				boolean found = false;

				for (WebElement option : listOptions) {
					String optionText = option.getText().trim();

					if (optionText.equalsIgnoreCase(strValueToBeSelected)) {
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].scrollIntoView(true);",
								option);

						wait.until(ExpectedConditions.elementToBeClickable(option));

						try {
							option.click();
						} catch (ElementClickInterceptedException e) {
							Log.info("Standard click failed, trying JavaScript click: " + e.getMessage());
							((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", option);
						}

						found = true;
						Log.info(strValueToBeSelected + " option selected in picklist - " + excelconstant);
						Assert.assertTrue(true,
								strValueToBeSelected + " option selected in picklist - " + excelconstant);
						break;
					}
				}

				if (!found) {
					Log.error("Value '" + strValueToBeSelected + "' not found in list for " + excelconstant);
					Assert.fail("Value '" + strValueToBeSelected + "' not found in list for " + excelconstant);
				}
			} else {
				Log.error("Dropdown not available for selection in " + excelconstant);
				Assert.fail("Dropdown not available for selection in " + excelconstant);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error(
					"Error selecting " + strValueToBeSelected + " in " + excelconstant + ". Error: " + e.getMessage());
			Assert.fail(
					"Error selecting " + strValueToBeSelected + " in " + excelconstant + ". Error: " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: selectItemFromMultiList()
	// Description: To select a value from any Dropdown list using Actions class
	// Prerequisite:
	// Test Script Author: Yogesh Jadhav
	// Date: 3/15/2018
	// Reviewed By: Swetha Jadhav
	// *********************************************************************************************************

	public void selectItemFromMultiList(By objToSelectValueFrom, String strValueToBeSelected) {
		try {
			String[] exp = strValueToBeSelected.split(",");
			waitAndVerifyElement(objToSelectValueFrom);
			WebElement element = getWebDriver().findElement(objToSelectValueFrom);
			Select select = new Select(element);
			Actions ac = new Actions(getWebDriver());
			ac.keyDown(Keys.CONTROL);
			for (int i = 0; i < exp.length; i++) {
				select.selectByVisibleText(exp[i]);
			}
			ac.keyUp(Keys.CONTROL);
			List<WebElement> elements = getWebDriver().findElements(By.xpath("//img[@class='picklistArrowRight']"));
			for (WebElement ele : elements) {
				ele.click();
			}
			Log.info("Multi options selected - " + strValueToBeSelected);
			Assert.assertTrue(true, "Multi options selected - " + strValueToBeSelected);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Not able to select - " + strValueToBeSelected + " in " + objToSelectValueFrom + ". "
					+ " Error - " + e.getMessage());
			Assert.fail("Not able to select - " + strValueToBeSelected + " in " + objToSelectValueFrom + ". "
					+ " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: selectItemFromDropdown()
	// Description: To select a value from any Dropdown list - Button type
	// *********************************************************************************************************
	public void selectItemFromDropdown(String objFieldXpath, String objListItemXpath, String fieldName,
			String strValueToBeSelected) {
		try {
			By Dropdown = getDynamicElement(objFieldXpath, fieldName);
			clickByJavascript(Dropdown);
			setTimeOut(1000);
			By listItem = getDynamicElement(objListItemXpath, fieldName, strValueToBeSelected);
			clickByJavascript(listItem);
			setTimeOut(1000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Not able to select - " + strValueToBeSelected + " in " + fieldName + ". " + " Error - "
					+ e.getMessage());
			Assert.fail("Not able to select - " + strValueToBeSelected + " in " + fieldName + ". " + " Error - "
					+ e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: verifyTextPresent()
	// Description: To verify the presence of any test present at a step

	// *********************************************************************************************************
	public void verifyTextPresent(By objForTextVerification, String strTextToVerify) {
		String ActualText = getText(objForTextVerification);
		try {
			Assert.assertTrue(ActualText.contains(strTextToVerify), "Expected Text is present - " + strTextToVerify
					+ "But not matching with the Actual Text -  " + ActualText);
			Log.info("Text is present - " + strTextToVerify);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text is not present - " + strTextToVerify + " Error - " + e.getMessage());
			Assert.fail("ActualText Text is not present - " + strTextToVerify + " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: switchToFrame()
	// Description: To switch to a new frame

	// *********************************************************************************************************
	public void switchToFrame(By strFrameNameToSwitch) {
		try {
			Thread.sleep(3000);
			getWebDriver().switchTo().defaultContent();
			getWebDriver().switchTo().frame(getWebDriver().findElement(strFrameNameToSwitch)); // switching to frame
			Log.info("Switched to frame - " + strFrameNameToSwitch);
			Assert.assertTrue(true, "Switched to frame - " + strFrameNameToSwitch);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Switching to frame - " + strFrameNameToSwitch + " - Failed. " + " Error - " + e.getMessage());
			Assert.fail("Switching to frame - " + strFrameNameToSwitch + " - Failed. " + " Error - " + e.getMessage());
		}
	}

	public static void switchToFrame2(By strFrameNameToSwitch) {
		try {
			Thread.sleep(3000);
			getWebDriver().switchTo().defaultContent();
			getWebDriver().switchTo().frame(getWebDriver().findElement(strFrameNameToSwitch)); // switching to frame
			Log.info("Switched to frame - " + strFrameNameToSwitch);
			Assert.assertTrue(true, "Switched to frame - " + strFrameNameToSwitch);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Switching to frame - " + strFrameNameToSwitch + " - Failed. " + " Error - " + e.getMessage());
			Assert.fail("Switching to frame - " + strFrameNameToSwitch + " - Failed. " + " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: waitAndVerifyElement()

	// *********************************************************************************************************
	public static void waitAndVerifyElement(By objToWaitFor) {
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(getWebDriver()).withTimeout(Duration.ofSeconds(250))
					.pollingEvery(Duration.ofSeconds(5)).ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.visibilityOfElementLocated(objToWaitFor));
			Assert.assertTrue(getWebDriver().findElement(objToWaitFor).isDisplayed(),
					objToWaitFor + " - Element is not present ");
			Log.info("Element is present - " + objToWaitFor);
		} catch (StaleElementReferenceException exp) {
			for (int i = 0; i <= 5; i++) {
				Wait<WebDriver> wait = new FluentWait<WebDriver>(getWebDriver()).withTimeout(Duration.ofSeconds(100))
						.pollingEvery(Duration.ofSeconds(5)).ignoring(NoSuchElementException.class);
				wait.until(ExpectedConditions.visibilityOfElementLocated(objToWaitFor));
			}
		} catch (Exception e) {
			e.printStackTrace();
			LogInfo("Element not present - " + objToWaitFor);
			setTimeOut(2000);
			Log.error("Element not present - " + objToWaitFor + " Error - " + e.getMessage());
			Assert.fail("Element not present - " + objToWaitFor + " Error - " + e.getMessage());
			Listeners.ReportFail("Element not present - " + objToWaitFor + " Error - " + e.getMessage());
		}
	}
	// *********************************************************************************************************
	// Function name: waitForPresenceOfElementLocated()
	// @author : Pratiksha Dixit

	// *********************************************************************************************************
	public static void waitForPresenceOfElementLocated(By objToWaitFor) {
		try {

			WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(180));
			wait.until(ExpectedConditions.presenceOfElementLocated(objToWaitFor));
			Log.info("Element is present on DOM- " + objToWaitFor);
		} catch (StaleElementReferenceException exp) {
			for (int i = 0; i <= 5; i++) {
				Wait<WebDriver> wait = new FluentWait<WebDriver>(getWebDriver()).withTimeout(Duration.ofSeconds(130))
						.pollingEvery(Duration.ofSeconds(5)).ignoring(NoSuchElementException.class);
				wait.until(ExpectedConditions.presenceOfElementLocated(objToWaitFor));
			}
		} catch (Exception e) {
			e.printStackTrace();
			LogInfo("Element not present on DOM - " + objToWaitFor);
			setTimeOut(2000);
			Log.error("Element not present on DOM - " + objToWaitFor + " Error - " + e.getMessage());
			Assert.fail("Element not present On DOM - " + objToWaitFor + " Error - " + e.getMessage());
			Listeners.ReportFail("Element not present on DOM - " + objToWaitFor + " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: switchToNextWindow()
	// Description: To switch to a new window

	// *********************************************************************************************************
	public static void switchToNextWindow() {
		try {
			Thread.sleep(5000);
			Set<String> whandles = getWebDriver().getWindowHandles();
			Iterator<String> itr = whandles.iterator();
			System.out.println("Window size is- " + whandles.size());
			if (whandles.size() > 1) {
				String parent = itr.next();
				String child = itr.next();
				getWebDriver().switchTo().window(child);
			} else {
				String parent = itr.next();
				System.out.println(parent);
				getWebDriver().switchTo().window(parent);
			}
			Log.info("Switched to next window - " + getWebDriver().getTitle());
			Assert.assertTrue(true, "Switched to next window - " + getWebDriver().getTitle());

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Switching to next window failed. " + " Error - " + e.getMessage());
			Assert.fail("Switching to next window failed. " + " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: switchToWindowByIndex()
	// Description: To switch to any specified window based on the window index

	// *********************************************************************************************************
	public static void switchToWindowByIndex(int intWindowNumber) {
		try {
			Thread.sleep(2000);
			Set<String> windowHandles = getWebDriver().getWindowHandles();
			System.out.println("Count of windows:" + windowHandles.size());

			int counter = 0;
			for (String w : windowHandles) {
				if (counter == intWindowNumber) {
					getWebDriver().switchTo().window(w);
					break;
				}
				counter++;
			}
			Log.info("Switched to " + intWindowNumber);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Switching to the" + intWindowNumber + "window failed. " + " Error - " + e.getMessage());
			Assert.fail("Switching to the" + intWindowNumber + "window failed. " + " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: closeAllChildWindows()
	// Description: To close all thw child windows

	// *********************************************************************************************************
	public void closeAllChildWindows() {
		try {
			Thread.sleep(2000);
			String parentWindow = getWebDriver().getWindowHandle();
			Set<String> windowHandles = getWebDriver().getWindowHandles();
			System.out.println("Count of windows:" + windowHandles.size());

			Iterator<String> I1 = windowHandles.iterator();

			while (I1.hasNext()) {
				String child_window = I1.next();

				if (!parentWindow.equals(child_window)) {
					getWebDriver().switchTo().window(child_window);
					System.out.println(getWebDriver().switchTo().window(child_window).getTitle());
					getWebDriver().close();
				}
			}
			getWebDriver().switchTo().window(parentWindow);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Closing the window failed. " + " Error - " + e.getMessage());
			Assert.fail("Closing the window failed. " + " Error - " + e.getMessage());
		}

	}

	/**
	 * Function: Generate Past date
	 * 
	 * @author Anand P
	 **/

	public static String getNthPastDayFromToday(int n) {
		String nthPastDateString = "";
		try {
			LocalDate today = LocalDate.now();
			LocalDate nthDate = today.minusDays(n);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
			nthPastDateString = nthDate.format(formatter);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return nthPastDateString;
	}

	// *********************************************************************************************************
	// Function name: closeWindow()
	// Description: To close the current window

	// *********************************************************************************************************
	public void closeWindow() {
		try {
			getWebDriver().close();
			Log.info("Window is closed");
			Assert.assertTrue(true, "Window is closed");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Window closing failed. " + " Error - " + e.getMessage());
			Assert.fail("Window closing failed. " + " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: closeWindowByIndex()
	// Description: To close the windows by specifying the window index

	// *********************************************************************************************************
	public void closeWindowByIndex(int intWindowNumber) {
		try {
			Thread.sleep(2000);
			Set<String> windowHandles = getWebDriver().getWindowHandles();
			System.out.println("Count of windows:" + windowHandles.size());

			int counter = 0;
			for (String w : windowHandles) {
				System.out.println("Title: " + getWebDriver().getTitle());

				if (counter == intWindowNumber) {
					getWebDriver().switchTo().window(w);
					getWebDriver().close();
					break;
				}
				counter++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Switching to the" + intWindowNumber + "window failed. " + " Error - " + e.getMessage());
			Assert.fail("Switching to the" + intWindowNumber + "window failed. " + " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: verifyAndAcceptAlert()
	// Description: TO verify any alert displayed and accept it

	// *********************************************************************************************************
	public void verifyAndAcceptAlert(String strTextToVerifyTheAlert) {
		try {
			Thread.sleep(3000);
			Assert.assertTrue(strTextToVerifyTheAlert.equals(getWebDriver().switchTo().alert().getText()),
					"Alert text verified");
			getWebDriver().switchTo().alert().accept();
			;
			Log.info("Alert text verified");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Alert message not found. " + " Error - " + e.getMessage());
			Assert.fail("Alert message not found. " + " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: selectCheckbox()
	// Description: To select any checkbox element

	// *********************************************************************************************************
	public void selectCheckbox(By objCheckboxToBeSelected) {
		try {

			if (getWebDriver().findElement(objCheckboxToBeSelected).isSelected()) {
				Assert.assertTrue(true, "Checkbox is default selected - " + objCheckboxToBeSelected);
				Log.info("Checkbox is default selected - " + objCheckboxToBeSelected);
			} else {
				clickByJavascript(objCheckboxToBeSelected);
				Assert.assertTrue(true, "Checkbox is selected - " + objCheckboxToBeSelected);
				Log.info("Checkbox is selected - " + objCheckboxToBeSelected);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error(
					"Failed to check the checkbox - " + objCheckboxToBeSelected + " . " + " Error - " + e.getMessage());
			Assert.fail(
					"Failed to check the checkbox - " + objCheckboxToBeSelected + " . " + " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: waitFor()
	// Description: TO wait for a specified duration

	// *********************************************************************************************************
	public void waitFor(int intMiliseconds) throws Exception {
		try {
			Thread.sleep(intMiliseconds);
			Log.info("Wait for " + intMiliseconds + " miliseconds");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Not able to Wait. Error -" + e.getMessage());
			Assert.fail("Not able to Wait. Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: getText()
	// Description: To obtain the value of the element

	// *********************************************************************************************************
	public static String getText(By objToGetText) {
		String text = null;
		try {
			waitAndVerifyElement(objToGetText);
			text = getWebDriver().findElement(objToGetText).getText();
			Assert.assertTrue(true, "Get text operation successful - " + text);
			Log.info("Get text operation successful - " + text);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Get text operation unsuccessful. " + " Error - " + e.getMessage());
			Assert.fail("Get text operation unsuccessful. " + " Error - " + e.getMessage());
		}
		return text;
	}

	// *********************************************************************************************************
	// Function name: clearText()
	// Description: To clear the values in the input textbox before entering any new
	// values
	// *********************************************************************************************************
	public void clearText(By objToClearText) {
		try {
			getWebDriver().findElement(objToClearText).clear();
			Assert.assertTrue(true, "Clear text operation successful - " + objToClearText);
			Log.info("Clear text operation successful - " + objToClearText);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Clear text operation unsuccessful. " + " Error - " + e.getMessage());
			Assert.fail("Clear text operation unsuccessful. " + " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: clickOnLink()
	// Description: To click on any link using the String values of the link

	// *********************************************************************************************************
	public void clickOnLink(String strLinkText) {
		try {
			getWebDriver().findElement(By.partialLinkText(strLinkText)).click();
			Assert.assertTrue(true, "Click on link operation successful - " + strLinkText);
			Log.info("Click on link operation successful - " + strLinkText);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Click on link operation unsuccessful. " + " Error - " + e.getMessage());
			Assert.fail("Click on link operation unsuccessful. " + " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: getDefaultItemFromList()
	// Description: To get the default value from the List

	// *********************************************************************************************************
	public String getDefaultItemFromList(By objToSelectValueFrom) {
		Select se = null;
		try {
			WebElement element = getWebDriver().findElement(objToSelectValueFrom);
			se = new Select(element);
			System.out.println(se.getFirstSelectedOption().getAttribute("value"));
			Log.info(se.getFirstSelectedOption().getText() + " option selected in picklist - " + objToSelectValueFrom);
			Assert.assertTrue(true, " option selected in picklist - " + objToSelectValueFrom);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Not able to select " + objToSelectValueFrom + ". " + " Error - " + e.getMessage());
			Assert.fail("Not able to select " + " in " + objToSelectValueFrom + ". " + " Error - " + e.getMessage());
		}
		return se.getFirstSelectedOption().getAttribute("value");
	}

	// *********************************************************************************************************
	// Function name: getDefaultItemFromList()
	// Description: To get the default value from the List

	// *********************************************************************************************************
	public String getSelectedItemFromList(By objToSelectValueFrom) {
		String selectedOption = null;
		try {
			WebElement element = getWebDriver().findElement(objToSelectValueFrom);
			selectedOption = element.findElement(By.xpath("//option[@selected='selected']")).getText();
			System.out.println(selectedOption);
			Log.info(selectedOption + " option selected in picklist - " + selectedOption);
			Assert.assertTrue(true, " option selected in picklist - " + selectedOption);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Not able to select " + selectedOption + ". " + " Error - " + e.getMessage());
			Assert.fail("Not able to select " + " in " + selectedOption + ". " + " Error - " + e.getMessage());
		}
		return selectedOption;
	}

	// *********************************************************************************************************
	// Function name: verifyImageDisplayed()
	// Description: To verify for any image displayed on the page

	// *********************************************************************************************************
	public void verifyImageDisplayed(By objImageObject) {
		try {
			WebElement ImageFile = getWebDriver().findElement(objImageObject);
			Boolean ImagePresent = (Boolean) ((JavascriptExecutor) getWebDriver()).executeScript(
					"return arguments[0].complete && typeof arguments[0].naturalWidth != \"undefined\" && arguments[0].naturalWidth > 0",
					ImageFile);
			if (!ImagePresent) {
				Log.info("Image displayed - " + objImageObject);
				Assert.assertTrue(true, "Image displayed - " + objImageObject);
			} else {
				Log.error("Image not displayed - " + objImageObject);
				Assert.fail("Image not displayed - " + objImageObject);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Image not displayed - " + objImageObject + " Error - " + e.getMessage());
			Assert.fail("Image not displayed - " + objImageObject + ". " + " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: verifyObjectPresentOrNot()
	// Description: To verfiy if any object is present or not on the page

	// *********************************************************************************************************
	public static boolean verifyObjectPresentOrNot(By obj) {
		try {
			if (getWebDriver().findElements(obj).size() != 0) {
				Assert.assertTrue(true, "Object is present - " + obj);
				Log.info("Object is present - " + obj);
				return true;
			} else {
				Assert.assertTrue(true, "Object is not present " + obj);
				Log.info("Object is not present " + obj);
				return false;
			}
		} catch (Exception e) {
			Log.error("Failed to create Case record. " + " Error - " + e.getMessage());
			Assert.fail("Failed to create Case record. " + " Error - " + e.getMessage());
		}
		return false;
	}
	// *********************************************************************************************************
	// Function name: verifyDataPresentOnTableOrNot()
	// Description: To verfiy Data present on table or not

	// *********************************************************************************************************

	public static boolean verifyDataPresentOnTableOrNot() {
		By eleRow = By.xpath("//*[contains(@class,'active lafPageHost')]//table//tbody//tr");
		try {
			if (getWebDriver().findElements(eleRow).size() != 0) {
				Assert.assertTrue(true, "Object is present - ");
				Log.info("Object is present - ");
				return true;
			} else {
				Assert.assertTrue(true, "Object is not present ");
				Log.info("Object is not present ");
				return false;
			}
		} catch (Exception e) {
			Log.error("Failed to create Case record. " + " Error - " + e.getMessage());
			Assert.fail("Failed to create Case record. " + " Error - " + e.getMessage());
		}
		return false;
	}

	// *********************************************************************************************************
	// Function name: getCurrentURL()
	// Description: To get the current page URL

	// *********************************************************************************************************
	public String getCurrentURL() {
		String currentURL = null;
		try {
			currentURL = getWebDriver().getCurrentUrl();
			Assert.assertTrue(true, "Successfully retrieved Current page URL -  " + currentURL);
			Log.info("Successfully retrieved Current page URL -  " + currentURL);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error(" Not able to retrieve Current page URL" + ". Error - " + e.getMessage());
			Assert.fail("Not able to retrieve Current page URL" + ". Error - " + e.getMessage());
		}
		return currentURL;
	}

	// *********************************************************************************************************
	// Function name: getSalesforceIDFromURL()
	// Description: To extract the sales force ID from any URL

	// *********************************************************************************************************
	public String getSalesforceIDFromURL() {
		String salesforceID = null;
		try {
			String currentURL = null;
			currentURL = getWebDriver().getCurrentUrl();
			int index = currentURL.lastIndexOf('/');
			System.out.println(currentURL.substring(index + 1, currentURL.length()));
			salesforceID = currentURL.substring(index + 1, currentURL.length());
			Assert.assertTrue(true, "Successfully retrieved salesforce ID from URL -  " + salesforceID);
			Log.info("Successfully retrieved salesforce ID from URL -  " + salesforceID);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error(" Not able to retrieve salesforce ID from URL" + ". Error - " + e.getMessage());
			Assert.fail("Not able to retrieve salesforce ID from URL" + ". Error - " + e.getMessage());
		}
		return salesforceID;
	}

	// *********************************************************************************************************
	// Function name: hoverOverElement()
	// Description: To hover over any element
	// @author : pdixit

	// *********************************************************************************************************
	public void hoverOverElement(By element) {
		try {
			Actions action = new Actions(getWebDriver());
			action.moveToElement(getWebDriver().findElement(element)).build().perform();
			Assert.assertTrue(true, "Hover successful on element -  " + element);
			Log.info("Hover successful on element -  " + element);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Hover unsuccessful on element -  " + element + ". Error - " + e.getMessage());
			Assert.fail("Hover unsuccessful on element -  " + element + ". Error - " + e.getMessage());
		}

	}

	// *********************************************************************************************************
	// Function name: clickByJavascript()
	// Description: To click on any element on the page using Java script executor

	// *********************************************************************************************************

	public void clickByJavascript(By objToBeClicked) {
		try {
			if (methodToAvoidStaleElementReferenceErrorElement(objToBeClicked)) {
				waitForPageLoaded();
				WebElement element = getWebDriver().findElement(objToBeClicked);
				JavascriptExecutor executor = (JavascriptExecutor) getWebDriver();
				executor.executeScript("arguments[0].click();", element);
				Log.info("Click on object successful - " + element);
				Assert.assertTrue(true, "Click On object successful - " + element);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Click on object unsuccessful - " + objToBeClicked + ". Error - " + e.getMessage());
			Assert.fail("Click on object unsuccessful - " + objToBeClicked + ". Error - " + e.getMessage());
		}
	}
	// *********************************************************************************************************
	// Function name: hoverOverElement()
	// Description: To hover over any element
	// @author : Dipali Yadav

	// *********************************************************************************************************

	public void doubleClickByJavascript(WebElement objToBeClicked) {
		try {
			((JavascriptExecutor) getWebDriver()).executeScript("var evt = document.createEvent('MouseEvents');"
					+ "evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);"
					+ "arguments[0].dispatchEvent(evt);", objToBeClicked);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Double Click on object unsuccessful - " + objToBeClicked + ". Error - " + e.getMessage());
			Assert.fail("Double Click on object unsuccessful - " + objToBeClicked + ". Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: clickByJavascript()
	// Description: To click on any element on the page using Java script executor

	// *********************************************************************************************************

	public void clickByJavascriptWithoutStaleCheck(By objToBeClicked) {
		try {
			WebElement element = getWebDriver().findElement(objToBeClicked);
			JavascriptExecutor executor = (JavascriptExecutor) getWebDriver();
			executor.executeScript("arguments[0].click();", element);
			Log.info("Click on object successful - " + element);
			Assert.assertTrue(true, "Click On object successful - " + element);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Click on object unsuccessful - " + objToBeClicked + ". Error - " + e.getMessage());
			Assert.fail("Click on object unsuccessful - " + objToBeClicked + ". Error - " + e.getMessage());
		}
	}

	public void clickExpandedButton(By objToElement) {
		Log.info("click on Button.");
		waitAndVerifyElement(objToElement);
		String Attrubutevalue = getWebDriver().findElement(objToElement).getAttribute("aria-expanded");
		if (Attrubutevalue == "false") {
			getWebDriver().findElement(objToElement).click();
		}

	}

	// *********************************************************************************************************
	// Function name: generateRandomNumber()
	// Description: To generate any random numbers

	// *********************************************************************************************************

	public static int generateRandomNumber() {
		int randomInt = 0;
		try {
			Random rand = new Random();
			randomInt = rand.nextInt(90) + 10;
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Generating a random number is unsuccessful - " + randomInt + ". Error - " + e.getMessage());
			Assert.fail("Generating a random number is unsuccessful - " + randomInt + ". Error - " + e.getMessage());
		}

		return randomInt;
	}

	// *********************************************************************************************************
	// Function name: generateRandomChar()
	// Description: To generate any random char

	// *********************************************************************************************************

	public static String generateRandomChar() {
		String randomChar = null;
		try {
			randomChar = RandomStringUtils.random(2, true, false);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Generating a random Charater is unsuccessful - " + randomChar + ". Error - " + e.getMessage());
			Assert.fail("Generating a random Charater is unsuccessful - " + randomChar + ". Error - " + e.getMessage());
		}

		return randomChar;
	}
	// *********************************************************************************************************
	// Function name: acceptAlert()
	// Description: To accept an alert without verifying the alert text

	// *********************************************************************************************************

	public void acceptAlert() {
		try {
			Thread.sleep(3000);
			WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(180));
			wait.until(ExpectedConditions.alertIsPresent());
			String text = getWebDriver().switchTo().alert().getText();
			getWebDriver().switchTo().alert().accept();
			Assert.assertTrue(true, "Alert accepted - " + text);
			Log.info("Alert accepted - " + text);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Alert message not found. " + " Error - " + e.getMessage());
			Assert.fail("Alert message not found. " + " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: deselectItemFromMultiList()
	// Description: To deselect any items from a List using the text of the item

	// *********************************************************************************************************

	public void deselectItemFromMultiList(By objToSelectValueFrom, String strValueToBeSelected) {
		try {
			String[] exp = strValueToBeSelected.split(",");
			WebElement element = getWebDriver().findElement(objToSelectValueFrom);
			Select select = new Select(element);
			Actions ac = new Actions(getWebDriver());
			ac.keyDown(Keys.CONTROL);
			for (int i = 0; i < exp.length; i++) {
				select.selectByVisibleText(exp[i]);
			}
			ac.keyUp(Keys.CONTROL);
			List<WebElement> elements = getWebDriver().findElements(By.xpath("//img[@class='picklistArrowLeft']"));
			for (WebElement ele : elements) {
				ele.click();
			}
			Log.info("Multi options deselected - " + strValueToBeSelected);
			Assert.assertTrue(true, "Multi options deselected - " + strValueToBeSelected);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Not able to deselect - " + strValueToBeSelected + " in " + objToSelectValueFrom + ". "
					+ " Error - " + e.getMessage());
			Assert.fail("Not able to deselect - " + strValueToBeSelected + " in " + objToSelectValueFrom + ". "
					+ " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: scrollToElement()
	// Description: To scroll to a particular object on the page

	// *********************************************************************************************************

	public void scrollToElement(By objElement) throws InterruptedException {
		try {
			WebElement elementToScroll = getWebDriver().findElement(objElement);

			((JavascriptExecutor) getWebDriver()).executeScript(
					"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
					elementToScroll);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Not able to scroll to element " + objElement + " Error - " + e.getMessage());
			Assert.fail("Not able to scroll to element " + objElement + " Error - " + e.getMessage());
		}
	}

	public void scrollToWebElement(WebElement strElement) throws InterruptedException {
		try {
			// WebElement elementToScroll = getWebDriver().findElement(objElement);

			((JavascriptExecutor) getWebDriver()).executeScript(
					"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
					strElement);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Not able to scroll to element " + strElement + " Error - " + e.getMessage());
			Assert.fail("Not able to scroll to element " + strElement + " Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: readExcelSpreadsheetAndPopulateCredential()
	// Description: To read and extract the values from the excel sheet available in
	// the path given in the method

	// *********************************************************************************************************
	public String readExcelSpreadsheetAndPopulateCredential(String strSpreadSheetName, String strUserName)
			throws EncryptedDocumentException, InvalidFormatException, IOException {

		/*
		 * This map will contain user's credentials in Key(email) and value(password)
		 * format
		 */
		Map<String, String> userCredMap = new HashMap<String, String>();

		/* Creating a Workbook from an Excel file (.xls or .xlsx) */
		Workbook workbook = WorkbookFactory.create(new File(strSpreadSheetName));

		/* Retrieving the number of sheets in the Workbook */
		Iterator<Sheet> sheetIterator = workbook.sheetIterator();
		System.out.println("Retrieving Sheets using Iterator");
		while (sheetIterator.hasNext()) {
			Sheet sheet = sheetIterator.next();
		}

		/* Getting the Sheet as per the sheet name */
		Sheet sheet = workbook.getSheetAt(0);

		/* Create a DataFormatter to format and get each cell's value as String */
		DataFormatter dataFormatter = new DataFormatter();

		Iterator<Row> rowIterator = sheet.rowIterator();
		int intCounter = 0;
		rowIterator.next();

		List<String> userList = new ArrayList<String>();
		StringBuffer sb = new StringBuffer();
		String password = null;

		while (rowIterator.hasNext()) {

			Row row = rowIterator.next();

			/* Iterate over the columns of the current row */
			Iterator<Cell> cellIterator = row.cellIterator();
			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				String cellValue = dataFormatter.formatCellValue(cell);

				String[] cellValueArr = cellValue.split("\\s");

				for (String cellContent : cellValueArr) {
					sb.append(cellContent + " ");
					userList.add(cellContent);
				}
				sb = new StringBuffer();
			}

			if (userList.size() > 0) {
				String user = null;

				if (userList.size() > 3) {
					if (userList.get(2).equalsIgnoreCase("All")) {
						// System.out.println("User Name 1 : " + userList.get(3));
						user = userList.get(3);
						if (null != user && user.trim().equalsIgnoreCase(strUserName.trim())) {
							password = userList.get(4);
							// System.out.println("Password : " + password);
						}
					} else {
						// System.out.println("User Name 1 : " + userList.get(2));
						user = userList.get(2);
						if (null != user && user.trim().equalsIgnoreCase(strUserName.trim())) {
							password = userList.get(3);
							// System.out.println("Password : " + password);
						}
					}

				} else if (userList.size() > 2) {
					// System.out.println("User Name 2 : " + userList.get(1));
					user = userList.get(1);
					if (null != user && user.trim().equalsIgnoreCase(strUserName.trim())) {
						password = userList.get(2);
						// System.out.println("Password : " + password);
					}
				} else {
					// System.out.println("User Name 3 : " + userList.get(0));
					user = userList.get(0);
					if (null != user && user.trim().equalsIgnoreCase(strUserName.trim())) {
						password = userList.get(1);
						// System.out.println("Password : " + password);
					}
				}

			}
			userList = new ArrayList<String>();
			intCounter++;
		}
		// workbook.close();
		return password;
	}

	// *********************************************************************************************************
	// Function name: getLocalTime()
	// Description: To access a document from the View dropdown on the Documents
	// Return to List page

	// *********************************************************************************************************
	public String getLocalTime() throws Exception {
		String getTime = null;
		try {
			LocalTime time = LocalTime.now();
			System.out.println(time);

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm");
			getTime = time.format(formatter);
			Log.info("Local Time retrived = " + getTime);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get Local Time  = " + e.getMessage());
		}
		return getTime;

	}

	// *********************************************************************************************************
	// Function name: getTime12Hour()
	// Description: To access a document from the View dropdown on the Documents
	// Return to List page

	// *********************************************************************************************************
	public void getCurrentDateAndTime() throws Exception {
		try {

			// getting current date and time using Date class
			DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
			Date dateobj = new Date();
			System.out.println(df.format(dateobj));

			/*
			 * getting current date time using calendar class An Alternative of above
			 */
			Calendar calobj = Calendar.getInstance();
			System.out.println(df.format(calobj.getTime()));

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get current date and Time  = " + e.getMessage());

		}
	}

	// *********************************************************************************************************
	// Function name: rearrangeDateFormat()
	// Description: To access a document from the View dropdown on the Documents
	// Return to List page

	// *********************************************************************************************************
	public String rearrangeDateFormat_yyyyMMddToMdyyyy(String date) {
		String formatted = "";
		try {

			SimpleDateFormat sm = new SimpleDateFormat("M/d/yyyy");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			Date newdate = format.parse(date);
			// Date formatedDate =
			// Date.from(newdate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
			System.out.println(newdate);
			formatted = sm.format(newdate);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get current date and Time  = " + e.getMessage());

		}
		return formatted;
	}

	// Anand P, date format Jan 31, 2025
	public static String rearrangeDateFormat() {
		String formattedDate = "";
		try {
			Date date2 = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
			formattedDate = sdf.format(date2);
			System.out.println(formattedDate);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to arrange date format  = " + e.getMessage());

		}
		return formattedDate;
	}

	// Anand P, date format mm/dd/yy
	public static String rearrangeDateFormat2(String date) {
		String formattedDate = "";
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
			Date date2 = sdf.parse(date);
			formattedDate = sdf.format(date2);
			System.out.println(formattedDate);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to arrange date format  = " + e.getMessage());

		}
		return formattedDate;
	}

	// *********************************************************************************************************
	// Function name: rearrangeDateFormat()
	// Description: To access a document from the View dropdown on the Documents
	// Return to List page

	// *********************************************************************************************************
	public String rearrangeDateFormat_yyyyMMddToDotFormat(String date) throws Exception {
		String formatted = "";
		try {

			SimpleDateFormat sm = new SimpleDateFormat("dd..MM.yyyy");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			Date newdate = format.parse(date);
			// Date formatedDate =
			// Date.from(newdate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
			System.out.println(newdate);
			formatted = sm.format(newdate);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get current date and Time  = " + e.getMessage());

		}
		return formatted;
	}

	// *********************************************************************************************************
	// Function name: rearrangeDateFormatToMMddyyyy()
	// Description: To access a document from the View dropdown on the Documents
	// Return to List page

	// *********************************************************************************************************
	public String rearrangeDateFormatToMMddyyyy(String date) throws Exception {
		String formatted = "";
		try {

			SimpleDateFormat sm = new SimpleDateFormat("MM/dd/yyyy");

			Date newdate = sm.parse(date);
			// Date formatedDate =
			// Date.from(newdate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
			System.out.println(newdate);
			formatted = sm.format(newdate);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get current date and Time  = " + e.getMessage());

		}
		return formatted;
	}

	// *********************************************************************************************************
	// Function name: readJSON()
	// Description: To access a document from the View dropdown on the Documents
	// Return to List page

	// *********************************************************************************************************

	public String getKeyFromJson(JSONObject JsonMain, String jsonArrayToFind, String key, String recordTypeIdValue,
			String recordSubType) {
		String keyValue = "";
		try {

			if (JsonMain.get(jsonArrayToFind) instanceof JSONArray && !"".equalsIgnoreCase(recordTypeIdValue)
					&& !" ".equalsIgnoreCase(recordTypeIdValue)) {
				System.out.println("entering if condition");
				JSONArray jsonArray = JsonMain.getJSONArray(jsonArrayToFind);
				for (int i = 0; i < jsonArray.length(); i++) {
					try {

						String jsonArrayString = jsonArray.get(i).toString();
						JSONObject innerJson = new JSONObject(jsonArrayString);
						String recordType = (String) innerJson.get("RecordTypeId");
						if (recordType.equalsIgnoreCase(recordTypeIdValue)) {

							if (!"".equalsIgnoreCase(recordSubType) && !" ".equalsIgnoreCase(recordSubType)) {

								String subRecordType = (String) innerJson.get("DTPC_Type__c");
								if (subRecordType.equalsIgnoreCase(recordSubType)) {
									keyValue = (String) innerJson.get(key);

									System.out.println(recordType + "," + subRecordType + "=" + keyValue);
									break;
								}

							} else {
								keyValue = (String) innerJson.get(key);
								System.out.println(recordType + "=" + keyValue);
								break;
							}
						}
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			} else if (JsonMain.get(jsonArrayToFind) instanceof JSONArray) {

				System.out.println("entering else condition");
				JSONArray jsonObjArray = JsonMain.getJSONArray(jsonArrayToFind);
				for (int i = 0; i < jsonObjArray.length(); i++) {
					String jsonArrayString = jsonObjArray.get(i).toString();
					JSONObject innerJson = new JSONObject(jsonArrayString);
					keyValue = (String) innerJson.get(key);
					System.out.println("From else condition =" + keyValue);

				}

			} else if (JsonMain.getJSONObject(jsonArrayToFind) instanceof JSONObject) {
				JSONObject jsonSub = JsonMain.getJSONObject(jsonArrayToFind);

				System.out.println("entering else if condition");
				try {
					if ((boolean) jsonSub.get(key)) {
						boolean keyVal = (boolean) jsonSub.get(key);
						System.out.println("From else if condition =" + keyValue);
						keyValue = Boolean.toString(keyVal);
					} else if (false == (boolean) jsonSub.get(key)) {
						boolean keyVal = (boolean) jsonSub.get(key);
						System.out.println("From else if condition =" + keyValue);
						keyValue = Boolean.toString(keyVal);
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
				try {
					keyValue = (String) jsonSub.get(key);
					System.out.println("From else condition =" + keyValue);
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		} catch (Exception e) {
			// TODO: handle exception
		}
		return keyValue;
	}

	/**
	 * Function: Get page class instances.
	 * 
	 * @param Page class.
	 * @return
	 */
	public static <TPage> TPage GetInstance(Class<TPage> page) {
		return PageFactory.initElements(getWebDriver(), page);
	}

	/**
	 * Function: Get driver object
	 * 
	 * 
	 * @return driver object
	 */
	public static WebDriver getWebDriver() {
		return driver.get();

	}

	/**
	 * Function: Get Dynamic locator
	 * 
	 * @author pratidixit
	 * 
	 * @return locator
	 * @throws InterruptedException
	 */
	public static By getDynamicElement(String dynamicPath, Object... locatorName) {
		By dynamicXpath = By.xpath(MessageFormat.format(dynamicPath, locatorName));
		try {
			Thread.sleep(2000);
			waitForPresenceOfElementLocated(dynamicXpath);
			Wait<WebDriver> wait = new FluentWait<WebDriver>(getWebDriver()).withTimeout(Duration.ofSeconds(130))
					.pollingEvery(Duration.ofSeconds(5)).ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.presenceOfElementLocated(dynamicXpath));
			Log.info("Dynamic locator extracted - " + dynamicXpath);
			Assert.assertTrue(true, "Dynamic Locator found - " + dynamicXpath);
		} catch (StaleElementReferenceException e) {
			boolean result = methodToAvoidStaleElementReferenceErrorElement(dynamicXpath);
			if (result == true) {
				dynamicXpath = By.xpath(MessageFormat.format(dynamicPath, locatorName));
				Log.info("Dynamic locator extracted - " + dynamicXpath);
				Assert.assertTrue(true, "Dynamic Locator found - " + dynamicXpath);
			}

		} catch (NoSuchElementException e) {
			e.printStackTrace();

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dynamicXpath;
	}

	/**
	 * Function: Verify Element is present
	 * 
	 * @return locator
	 */
	public boolean verifyElement(By element) {
		boolean result = false;
		try {
			waitAndVerifyElement(element);
			result = true;
			Assert.assertTrue(result, "Locator found - ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("locator not found - " + ". Error - " + e.getMessage());
			Assert.fail(" locator not found - " + ". Error - " + e.getMessage());
		}
		return result;
	}

	public void LoggingInfo(String message) {
		Listeners.ReportPass(message);
		Log.info(message);
	}

	public static void LogInfo(String message) {
		Listeners.ReportPass(message);
		Log.info(message);
	}

	public static void setTimeOut(int timeout) {
		try {
			Thread.sleep(timeout);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Function:get comma seperated values in Array List
	 *
	 * @param String
	 * @author Dipali yadav
	 */
	public List<String> getCommaSeperataedValuesInArray(String string) {
		String[] myArray = string.split(",");
		List<String> myList = Arrays.asList(myArray);
		return myList;
	}

	public static ArrayList<String> getTableData(String tagName, int cellIndex, int nextCellIndex) {
		ArrayList<String> cellValues = new ArrayList<String>();
		String ss;
		try {

			List<WebElement> rows = getWebDriver()
					.findElements(By.xpath("//*[contains(@class,'active lafPageHost')]//table//tbody//tr"));

			for (int i = 0; i < rows.size(); i++) {
				List<WebElement> cell = rows.get(i).findElements(By.tagName(tagName));
				for (int j = cellIndex; j < cell.size(); j++) {
					String Record = cell.get(j).getText();
					cellValues.add(Record);
					System.out.println(Record);
					j += nextCellIndex;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed" + ". Error - " + e.getMessage());

		}
		return cellValues;
	}

	/**
	 * Function: Dynamic method to Get the table(Present In all page for an example:
	 * Program Coverage table,Program Service Permissions table, Cases Table,Open
	 * Activities table etc. data based on the col name
	 *
	 * @param colName
	 * @author pdixit
	 */
	public static ArrayList<String> getTabledataWithColname(String colName, String... header) {
		ArrayList<String> cellValues = new ArrayList<String>();
		try {
			ArrayList<String> dateFieldsList = new ArrayList<>(
					Arrays.asList("Dispensed Date", "New Value", "End Date"));
			List<WebElement> rows = getWebDriver().findElements(By.xpath(
					"//*[contains(@class,'active lafPageHost')]//table[@aria-label=\"Contact Contact Relationships\"]//tbody//tr"));
			WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(180));
			wait.until(ExpectedConditions.visibilityOfAllElements(rows));
			List<WebElement> headerList = getWebDriver()
					.findElements(By.xpath("//*[contains(@class,'active lafPageHost')]//table/thead/tr/th"));
			boolean flag = false;
			for (int columnNameIndex = 0; columnNameIndex < headerList.size(); columnNameIndex++) {
				int columnNameIndex1;
				WebElement colHeader = headerList.get(columnNameIndex);
				String headerName;
				try {
					headerName = headerList.get(columnNameIndex).getAttribute("aria-label");

				} catch (Exception e) {
					headerName = headerList.get(columnNameIndex).getAttribute("class");
				}
				if (headerName != null) {
					if (headerName.trim().equalsIgnoreCase(colName)) {
						columnNameIndex1 = columnNameIndex;
						for (int rowValue = 0; rowValue < rows.size(); rowValue++) {
							try {
								if (header.length != 0) {
									String value = rows.get(rowValue).findElement(By.xpath(".//th//a//span")).getText()
											.trim();
									flag = true;
									cellValues.add(value);
									Assert.assertTrue(flag);
								} else {
									String value = rows.get(rowValue)
											.findElement(
													By.xpath(".//td[" + columnNameIndex1 + "]//lst-formatted-text"))
											.getText().trim();
									flag = true;
									cellValues.add(value);
									Assert.assertTrue(flag);
								}
							} catch (Exception e) {
								if (dateFieldsList.contains(colName)) {
									String value = rows.get(rowValue)
											.findElement(By.xpath(
													".//td[" + columnNameIndex1 + "]//lightning-formatted-date-time"))
											.getText().trim();
									flag = true;
									cellValues.add(value);
									Assert.assertTrue(flag);
								} else {
									String value = rows.get(rowValue)
											.findElement(By.xpath(".//td[" + columnNameIndex1 + "]//a"))
											.getAttribute("title").trim();
									flag = true;
									cellValues.add(value);
									Assert.assertTrue(flag);
								}

							}
						}
						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cellValues;
	}

	/**
	 * Function: Dynamic method to get the task subject list
	 *
	 * @param colName
	 * @author pdixit
	 */
	public static ArrayList<String> verifyTaskSubject() {
		ArrayList<String> cellValues = new ArrayList<String>();
		List<WebElement> rows = getWebDriver()
				.findElements(By.xpath("//*[contains(@class,'active lafPageHost')]//table//tbody//tr"));
		try {
			for (int rowValue = 0; rowValue < rows.size(); rowValue++) {
				try {
					String value = rows.get(rowValue).findElement(By.xpath("./th//a")).getText().trim();
					cellValues.add(value);

				} catch (Exception e) {
					e.printStackTrace();

				}

			}
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return cellValues;
	}

	/**
	 * Function: Get the table header names list
	 *
	 * @param colName
	 * @author pdixit
	 */
	public static ArrayList<String> getTableHeaderNames() {
		ArrayList<String> valuesHeaderList = new ArrayList<String>();
		List<WebElement> headerList = getWebDriver().findElements(By
				.xpath("//*[contains(@class,'active lafPageHost')]//table/thead/tr/th//span[@class='slds-truncate']"));
		try {
			for (int headerCol = 1; headerCol < headerList.size(); headerCol++) {
				try {
					String value = headerList.get(headerCol).getText().trim();
					valuesHeaderList.add(value);
				} catch (Exception e) {
					e.printStackTrace();

				}

			}
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return valuesHeaderList;
	}

	/**
	 * Function:Select the Dropdown values using dropdown labels
	 *
	 * @param labelName
	 * @author pdixit
	 */
	public void selectDropDownValues(String labelName, String optionName) {
		try {
			Log.info("Click on the dropdown and select the option");
			waitAndVerifyElement(By.xpath(
					// "//*[contains(@class,\"icon_right\")]//button[contains(@aria-label,\"" +
					// labelName + "\")]"));
					"//*[contains(@class,'active lafPageHost')]//label[text()=\"" + labelName
							+ "\"]//following-sibling::div//*//button[contains(@aria-label,\"" + labelName + "\")]"));
			clickByJavascript(By.xpath("//*[contains(@class,'active lafPageHost')]//label[text()=\"" + labelName
					+ "\"]//following-sibling::div//*//button[contains(@aria-label,\"" + labelName + "\")]"));
			By dropDownOption = By.xpath("//*[text()=\"" + labelName
					+ "\"]/following-sibling::div//*[contains(@class,\"slds-is-open\")]//*[@role=\"listbox\"]//span[@title=\""
					+ optionName + "\"]");
			clickByJavascript(dropDownOption);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Selection Failed" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: To click on new , save button
	 *
	 * @author Pratiksha
	 * @param New, Save etc
	 */
	public void clickOnButton(String value) {
		setTimeOut(1000);
		By button = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"" + value + "\"]");
		try {
			waitForPageLoaded();
			Wait<WebDriver> wait = new FluentWait<WebDriver>(getWebDriver()).withTimeout(Duration.ofSeconds(30))
					.pollingEvery(Duration.ofSeconds(5)).ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.visibilityOfElementLocated(button));
			clickByJavascript(button);
			LoggingInfo("Clicked on Button:" + value);
			// setTimeOut(5000);
		} catch (StaleElementReferenceException e) {
			boolean result = methodToAvoidStaleElementReferenceErrorElement(button);
			if (result == true) {
				clickByJavascript(button);
				setTimeOut(4000);
			}
		}
		setTimeOut(5000);
	}

	/**
	 * Function: Wait For invisibilty of button
	 *
	 * @author Pratiksha
	 * @param New, Save etc
	 */
	public void waitForInvisibityOfButton(String value) {
		setTimeOut(1000);
		By button = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"" + value + "\"]");
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(getWebDriver()).withTimeout(Duration.ofSeconds(100))
					.pollingEvery(Duration.ofSeconds(5)).ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(button));
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	/**
	 * Function: Validate error on clicking Button
	 *
	 * @author Yuti Shah
	 * @param
	 */
	public void toastMessageValidationOnButtonClick(String buttonName, String expectedMessage) {

		try {
			Log.info("Validate error on clicking " + buttonName + "Button");
			waitForPageLoaded();
			setTimeOut(3000);
			waitForPresenceOfElementLocated(
					By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"" + buttonName + "\"]"));
			clickOnButton(buttonName);
			// setTimeOut(1000);
			String actualMessage = getToastMessage();
			Assert.assertEquals(actualMessage, expectedMessage);
			LoggingInfo("Error on clicking " + buttonName + " Button is " + actualMessage);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail(". Error - " + e.getMessage());
		}

	}

	/**
	 * Function:Click on Pen icon to edit field
	 * 
	 * @param Element name ie. start date, end date ,product etc
	 *
	 * @author Pratiksha Dixit
	 */
	public void clickOnEditPenIcon(String elementName) {

		try {

			By elePenIcon = By
					.xpath("//*[contains(@class,\"active lafPageHost\")]//button[@title=\"" + elementName + "\"]");
			LoggingInfo("Click On Pen Icon");
			waitAndVerifyElement(elePenIcon);
			clickByJavascript(elePenIcon);
			setTimeOut(200);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("failed to click" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function:Click on Pen icon to edit field
	 * 
	 * @param Element name ie. start date, end date ,product etc
	 *
	 * @author Pratiksha Dixit
	 */
	public boolean validateEditPenIconPresent(String elementName) {

		boolean result = false;
		try {

			By elePenIcon = By
					.xpath("//*[contains(@class,\"active lafPageHost\")]//button[@title=\"" + elementName + "\"]");
			LoggingInfo("Click On Pen Icon");
			if (getWebDriver().findElements(elePenIcon).size() != 0) {
				result = true;
			} else {
				result = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("failed to Validate" + ". Error - " + e.getMessage());
		}
		return result;
	}

	/**
	 * Function: To Get the Warning message
	 * 
	 * @author Pratiksha Dixit
	 */
	public ArrayList<String> getWarningMessageText() {
		ArrayList<String> warningMessageList = new ArrayList<String>();
		try {
			List<WebElement> warningMsgActualList = getWebDriver()
					.findElements(By.xpath("//*[contains(@class,'modal__content')]/div/div"));
			for (WebElement ele : warningMsgActualList) {
				warningMessageList.add(ele.getText());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Logger("Warning Present on page: " + warningMessageList);
		return warningMessageList;

	}

	/*
	 * * Function: To check or uncheck active checkbox
	 * 
	 * @param activate true or false
	 * 
	 * @author Pratiksha Dixit
	 */
	public void checkAndUncheckActiveCheckbox(boolean activate) {
		try {
			By activeCheckbox = By.xpath(
					"//div[contains(@class,'slds-modal__container')]//span[text()='Active']//parent::label//following-sibling::div//input");
			if (activate == true) {
				if (isCheckboxSelected(activeCheckbox) == false) {
					actionClick(activeCheckbox);
				}
				LoggingInfo("activated Checkbox");
			} else if (activate == false) {
				if (isCheckboxSelected(activeCheckbox) == true) {
					actionClick(activeCheckbox);
					LoggingInfo("Inactivated Checkbox");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Function: To click using action class
	 *
	 * @author Pratiksha Dixit
	 * @param Locator
	 * @return
	 */
	public void actionClick(By objLocator) {
		WebElement element = getWebDriver().findElement(objLocator);
		Actions actions = new Actions(getWebDriver());
		setTimeOut(3000);
		actions.moveToElement(element).pause(30).click().build().perform();
		setTimeOut(2000);
	}

	/**
	 * Function: To click on new , save button
	 *
	 * @author Dipali Yadav
	 * @param New, Save etc
	 * @return
	 */
	public <T> T clickOnButtonToNavigatePage(String value, Class<T> className) {
		By button = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"" + value + "\"]");
		try {
			Wait<WebDriver> wait = new FluentWait<WebDriver>(getWebDriver()).withTimeout(Duration.ofSeconds(30))
					.pollingEvery(Duration.ofSeconds(5)).ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.visibilityOfElementLocated(button));
			clickByJavascript(button);
			setTimeOut(2000);
		} catch (StaleElementReferenceException e) {
			setTimeOut(3000);
			boolean result = methodToAvoidStaleElementReferenceErrorElement(button);
			if (result == true) {
				clickByJavascript(button);
				setTimeOut(2000);
			}
		}
		return GetInstance(className);
	}

	/**
	 * Function: Fetch Field detail from respective page
	 *
	 * @param: Field name
	 * @author Harika Mudumby Modified Pratikshadixit
	 */
	public static String fetchFieldText(String fieldName) {

		setTimeOut(5000);
		String fieldTextValue = "";
		By fieldText = getDynamicElement(strLightningTextXpath, fieldName);
		waitAndVerifyElement(fieldText);
		Wait<WebDriver> wait = new FluentWait<WebDriver>(getWebDriver()).withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(5)).ignoring(NoSuchElementException.class);
		wait.until(ExpectedConditions.visibilityOfElementLocated(fieldText));

		try {
			fieldTextValue = getText(fieldText);
		} catch (StaleElementReferenceException exp) {
			boolean result = methodToAvoidStaleElementReferenceErrorElement(fieldText);
			if (result == true) {
				fieldTextValue = getText(fieldText);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return fieldTextValue;
	}

	public static boolean methodToAvoidStaleElementReferenceErrorWebElement(String path) {
		int attempts = 0;
		boolean result = true;
		while (attempts < 6) {
			try {
				WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(180));
				wait.until(ExpectedConditions.elementToBeClickable(getWebDriver().findElement(By.xpath(path))));
				break;
			} catch (StaleElementReferenceException e) {
				System.out.println("Attempt - " + attempts + ". Stale Element reference on element - "
						+ ". Error caught - " + e.getMessage());
			}
			attempts++;
		}
		return result;
	}

	// *********************************************************************************************************
	// Function name: methodToAvoidStaleElementReferenceError()
	// Description:To capture and handle the Stale Element Reference Error
	// Prerequisite:
	// Test Script Author: Yogesh Jadhav
	// Date: 3/15/2018
	// Reviewed By: Swetha Jadhav
	// *********************************************************************************************************
	public static boolean methodToAvoidStaleElementReferenceErrorElement(By by) {
		boolean result = false;
		int attempts = 0;
		while (attempts < 5) {
			try {
				WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(180));
				wait.until(ExpectedConditions.elementToBeClickable(getWebDriver().findElement(by)));
				getWebDriver().findElement(by);
				result = true;
				break;
			} catch (StaleElementReferenceException e) {
				System.out.println("Attempt - " + attempts + ". Stale Element reference on element - " + by
						+ ". Error caught - " + e.getMessage());
			}
			attempts++;
		}
		return result;
	}

	/**
	 * Function: To get the SFDC ID
	 *
	 * @author Pratiksha Dixit
	 * @param object
	 */
	public String getSfdcID(String object) {

		String sfdcID = "";
		try {
			setTimeOut(9000);
			waitForPageLoaded();
			String url = getWebDriver().getCurrentUrl();
			String[] id = url.split(object + "/");
			String[] haldUrl = id[1].split("/");
			sfdcID = haldUrl[0];

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sfdcID;
	}

	/**
	 * Function: To Navigate directly to the specific Id
	 *
	 * @author Pratiksha Dixit
	 * @param object
	 */
	public void navigateToUrl(String sfdcID) {
		try {
			setTimeOut(5000);
			String baseUrl = Configuration.readApplicationFile("BaseUrl");
			getWebDriver().navigate().to(baseUrl + sfdcID);
			waitForPageLoaded();
			setTimeOut(4000);
		} catch (UnhandledAlertException e) {
			// TODO Auto-generated catch block
			String baseUrl = Configuration.readApplicationFile("BaseUrl");
			getWebDriver().navigate().to(baseUrl + sfdcID);
			waitForPageLoaded();
			setTimeOut(4000);
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Function: Global Search any object
	 *
	 * @author Yuti Shah
	 * @param object
	 */
	public void globalSearch(String name, String Object) {
		try {

			setTimeOut(4000);
			String globalSearch = "//*[@aria-label='Search']";
			getWebDriver().findElement(By.xpath(globalSearch)).click();

			String globalSearchInput = "//div[contains(@class,\"Search\")]//*[@type='search' and @class='slds-input']";
			waitAndVerifyElement(By.xpath(globalSearchInput));

			getWebDriver().findElement(By.xpath(globalSearchInput)).sendKeys(name);
			getWebDriver().findElement(By.xpath(globalSearchInput)).sendKeys(Keys.ENTER);
			setTimeOut(4000);
			waitForPageLoaded();
			if (Object != "") {
				String searchedLink = "//a[text()='" + Object + "']/following::a[text()='" + name + "']";
				waitAndVerifyElement(By.xpath(searchedLink));
				getWebDriver().findElement(By.xpath(searchedLink)).click();
				setTimeOut(2000);
				waitForPageLoaded();
			}
			setTimeOut(1000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Function: Wait For page to load
	 * 
	 * @author pratidixit
	 * @param driver
	 */
	public void waitForPageLoaded() {
		Wait<WebDriver> wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(200));
		wait.until(driver -> ((JavascriptExecutor) getWebDriver()).executeScript("return document.readyState")
				.equals("complete"));
	}

	/**
	 * Function: Scroll to end of the page
	 * 
	 * @author pratidixit
	 *
	 */
	public void scrollToDocumentHeight() {
		JavascriptExecutor jse = (JavascriptExecutor) getWebDriver();
		jse.executeScript("window.scrollBy(0,document.body.scrollHeight || document.documentElement.scrollHeight)", "");
	}

	public static void scrollToTopOfPage() {
		JavascriptExecutor jse = (JavascriptExecutor) getWebDriver();
		jse.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
	}

	/**
	 * Function: Scroll to some pixels
	 * 
	 * @author pratidixit
	 *
	 */
	public void scrollToPixel() {
		JavascriptExecutor jse = (JavascriptExecutor) getWebDriver();
		jse.executeScript("window.scrollBy(0,250)", "");
	}

	/**
	 * Function: Scroll to some pixels
	 * 
	 * @author pratidixit
	 *
	 */
	public void scrollToHalfPage() {
		JavascriptExecutor jse = (JavascriptExecutor) getWebDriver();
		jse.executeScript("window.scrollBy(0,900)", "");
	}

	/**
	 * Function: Validate the success message
	 * 
	 * @author pratidixit
	 *
	 */
	public void validateToastMessage() {
		try {
			LoggingInfo("Succes Toast message verification");
			// boolean result =
			// getWebDriver().findElement(By.xpath("//*[contains(@class,'toastContent')]//span"))
			// .isDisplayed();
			// Assert.assertTrue(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Function: Return toast message
	 * 
	 * @author Yuti Shah
	 *
	 */
	public String getToastMessage() {
		String message = null;
		try {
			Log.info("Get Toast message text");
			By toastMessage = By.xpath("//*[contains(@class,'toastContent')]//span");
			boolean result;
			for (int i = 0; i < 10; i++) {
				result = getWebDriver().findElement(toastMessage).isDisplayed();
				if (result) {
					message = getWebDriver().findElement(toastMessage).getText();
					break;
				}
			}
			LoggingInfo("Toast Mesaage is " + message);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return message;
	}

	/**
	 * Function: Validate the Toast Message Text
	 * 
	 * @param textMessage
	 * 
	 * @author pratidixit
	 *
	 */
	public void validateToastMessageText(String text) {
		try {
			// LoggingInfo("Toast message verification");

			String toastElement = "//*[contains(@class,'toastContent')]//span[contains(text(),'" + text + "')]";
			waitForPresenceOfElementLocated(By.xpath(toastElement));

			LoggingInfo("Toast message verification Successfully completed");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Function: Check for the alert
	 * 
	 * @author pratidixit
	 *
	 */
	public boolean isAlertPresent() {
		boolean presentFlag = false;
		try {

			// Check the presence of alert
			Alert alert = getWebDriver().switchTo().alert();
			// Alert present; set the flag
			presentFlag = true;
			// if present consume the alert
			alert.accept();
			// ( Now, click on ok or cancel button )
		} catch (NoAlertPresentException ex) {
			// Alert not present
			ex.printStackTrace();
		}

		return presentFlag;
	}

	/**
	 * Function:Return the date after number of days due
	 *
	 * @param dueDate - Number of days due
	 * @author Siddhant Sahu
	 */
	public static String getDueDate(int dueDate) {

		try {
			DateFormat df = new SimpleDateFormat("MMM d, yyyy");
			Date dateobj = new Date();
			// TimeZone.setDefault(TimeZone.getTimeZone("EST"));
			TimeZone.setDefault(TimeZone.getTimeZone("New_York"));
			format = new SimpleDateFormat("MMM d, yyyy");
			String curDate = df.format(dateobj);
			final Date date = format.parse(curDate);
			calendar = Calendar.getInstance();
			calendar.add(Calendar.DAY_OF_YEAR, dueDate);
			// LocalDate dateBefore30Days =
			// LocalDate.now(ZoneId.of("Europe/Paris")).minusYears(65);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Selection Failed" + ". Error - " + e.getMessage());
		}
		return format.format(calendar.getTime());
	}

	/**
	 * Function:Return the date after number of days due
	 *
	 * @param dueDate - Number of days due
	 * @author Siddhant Sahu
	 */
	public static String getDueDateInNumbericFormat(int dueDate) {

		try {
			DateFormat df = new SimpleDateFormat("M/d/yyyy");
			Date dateobj = new Date();
			// TimeZone.setDefault(TimeZone.getTimeZone("EST"));
			TimeZone.setDefault(TimeZone.getTimeZone("New_York"));
			format = new SimpleDateFormat("M/d/yyyy");
			String curDate = df.format(dateobj);
			final Date date = format.parse(curDate);
			calendar = Calendar.getInstance();
			calendar.add(Calendar.DAY_OF_YEAR, dueDate);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Selection Failed" + ". Error - " + e.getMessage());
		}
		return format.format(calendar.getTime());
	}

	/**
	 * Function:Return the Todays Date
	 */
	public static String getTodaysDate() {

		try {
			DateFormat df = new SimpleDateFormat("yyyy-M-d");
			Date dateobj = new Date();
			// TimeZone.setDefault(TimeZone.getTimeZone("EST"));
			TimeZone.setDefault(TimeZone.getTimeZone("New_York"));
			format = new SimpleDateFormat("yyyy-M-d");
			String curDate = df.format(dateobj);
			final Date date = format.parse(curDate);
			calendar = Calendar.getInstance();
			calendar.add(Calendar.DAY_OF_YEAR, 0);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Selection Failed" + ". Error - " + e.getMessage());
		}
		return format.format(calendar.getTime());
	}

	/**
	 * Function:Return the date after adding number of days
	 *
	 * @param dueDate - Number of days to be added, given date - Date to be sent
	 * @author Harika Mudumby
	 * @throws ParseException
	 */
	public static String addDaysToGivenDate(int dueDate, String givenDate) throws ParseException {

		DateFormat sdf = new SimpleDateFormat("M/d/yyyy");
		Date inputDate = sdf.parse(givenDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(inputDate);
		cal.add(Calendar.DATE, dueDate);
		Date result = cal.getTime();
		String s = sdf.format(result);
		TimeZone.setDefault(TimeZone.getTimeZone("New_York"));
		return s;
	}

	/**
	 * Function:Return x years back date from the given date
	 *
	 * @param given date, years
	 * @author Pratiksha Dixit
	 * @throws ParseException
	 */
	public static String getXyearsBackDateFromGivenDate(int years, String givenDate) throws ParseException {

		DateFormat sdf = new SimpleDateFormat("M/d/yyyy");
		Date inputDate = sdf.parse(givenDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(inputDate);
		cal.add(Calendar.YEAR, -years);
		Date result = cal.getTime();
		String backDateYears = sdf.format(result);
		TimeZone.setDefault(TimeZone.getTimeZone("New_York"));
		return backDateYears;
	}

	/**
	 * Function:Return x years future date from the given date
	 *
	 * @param given date, years
	 * @author Yuti Shah
	 * @throws ParseException
	 */
	public static String getXyearsFutureDateFromGivenDate(int years, String givenDate) throws ParseException {

		DateFormat sdf = new SimpleDateFormat("M/d/yyyy");
		Date inputDate = sdf.parse(givenDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(inputDate);
		cal.add(Calendar.YEAR, +years);
		Date result = cal.getTime();
		String futureDateYears = sdf.format(result);
		TimeZone.setDefault(TimeZone.getTimeZone("New_York"));
		return futureDateYears;
	}

	/**
	 * Scroll page down pixel
	 * 
	 * @author pratidixit
	 * @param pixel pixel to scroll down
	 */
	public void scrollDown(String pixel) {
		JavascriptExecutor jse = (JavascriptExecutor) getWebDriver();
		jse.executeScript("window.scrollBy(0," + pixel + ")", "");
	}

	/**
	 * Scroll page up pixel
	 * 
	 * @author pratidixit
	 * @param pixel pixel to scroll Up
	 */
	public void scrollUp(String pixel) {
		JavascriptExecutor jse = (JavascriptExecutor) getWebDriver();
		jse.executeScript("window.scrollBy(" + pixel + ", 0)", "");
	}

	/**
	 * Wait for invisibility of Spinner
	 *
	 * @author pratidixit
	 *
	 */
	public void waitForInvisiblityOfSpinner(By objlocator) {
		setTimeOut(30);
		if (verifyObjectPresentOrNot(objlocator) == true) {
			WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(100));
			wait.until(ExpectedConditions.invisibilityOf(getWebDriver().findElement(objlocator)));
		}
	}

	/**
	 * Wait for invisibility of Element
	 * 
	 * @author pratidixit
	 *
	 */
	public void waitForInvisiblityOfElementLocated(By locator) {
		setTimeOut(30);
		WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(10));
		wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
	}

	/**
	 * Wait for visibility of Element
	 * 
	 * @author Harika Mudumby
	 *
	 */
	public void waitForvisiblityOfElementLocated(By locator) {
		setTimeOut(30);
		WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	/*
	 * Function to Click on the Record present in the table based on the record type
	 * 
	 * @param recordType i.e. Program/Adverse Event etc
	 * 
	 * @author pratiksha dixit
	 * 
	 */
	public void clickOnRecordBasedOnRecordTypeAndRecordValue(String recordType, String recordValue) {
		try {
			LoggingInfo("Click on the Record");

			By recordEle = By.xpath("//*[contains(@class,\"maximized active lafPageHost\")]//*[@title=\"" + recordType
					+ "\"]//ancestor::tr//th//a//span");
			waitAndVerifyElement(recordEle);
			List<WebElement> recordList = getWebDriver().findElements(recordEle);
			for (WebElement element : recordList) {
				if (element.getText().equalsIgnoreCase(recordValue)) {
					element.click();
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click" + ". Error - " + e.getMessage());
		}

	}

	/*
	 * Function to Get the record number from the table based on the record type
	 * 
	 * @param recordType i.e. Copay Withdrawal Medicare Enrollment - Nearing Age 65,
	 * Adverse events,ptc etc
	 * 
	 * @author pratiksha dixit
	 * 
	 */
	public ArrayList<String> getRecordListBasedOnRecordType(String recordType) {
		ArrayList<String> recordList = new ArrayList<String>();
		try {
			LoggingInfo("Get on the Record Number based on the record type");
			By recordEle = By.xpath("//*[contains(@class,\"maximized active lafPageHost\")]//*[@title=\"" + recordType
					+ "\"]//../../parent::tr/th//a");
			waitAndVerifyElement(recordEle);
			List<WebElement> numberList = getWebDriver().findElements(recordEle);
			for (WebElement element : numberList) {
				recordList.add(element.getText());
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to get the text from the record" + ". Error - " + e.getMessage());
		}
		return recordList;

	}

	/**
	 * Function: To click on various tabs on Program case page
	 *
	 * @author Harika Mudumby
	 */

	public <T> T ClickOnRelatedTab(String tabName, Class<T> className) {
		try {

			setTimeOut(100);
			waitForPageLoaded();
			String LightningTabBar = "//*[contains(@class,\"active lafPageHost\")]//ul[@role=\"tablist\"]//li//*[text()=\"{0}\"]";
			By tabElement = Utility_Function.getDynamicElement(LightningTabBar, tabName);
			scrollToElement(tabElement);
			clickByJavascript(tabElement);
			setTimeOut(1000);
			Log.info("Click on LightningTabValue - " + tabElement);
			Assert.assertTrue(true, "Click on object successful - " + tabElement);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Click on object unsuccessful - " + tabName + ". Error - " + e.getMessage());
			Assert.fail("Click on object unsuccessful - " + tabName + ". Error - " + e.getMessage());
		}
		return GetInstance(className);
	}

	/**
	 * Function: To click on ViewAll after switching to various tabs on Program case
	 * page and to click on viewAll under activities section on task page
	 *
	 * @author Harika Mudumby
	 * @param Cases, HealthPlan, Treatment summary ID etc
	 * @throws InterruptedException
	 */

	public <T> T ClickOnViewAll(String Subject_Name, Class<T> className) {
		int attempts = 0;
		setTimeOut(1000);
		boolean result;
		String viewAllLinks = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"View All\"]/span[text()=\"{0}\"]//../../parent::a";
		waitForPageLoaded();
		setTimeOut(4000);
		while (attempts < 15) {
			try {
				setTimeOut(5000);
				By eleBottom = By.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='View All']/span[text()='"
						+ Subject_Name + "']//../../parent::a");
				WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(2));
				wait.until(ExpectedConditions.presenceOfElementLocated(eleBottom));
				result = true;
			} catch (Exception e) {
				result = false;
				scrollToHalfPage();
				attempts++;
			}
			if (result == true) {
				break;
			}
		}
		LoggingInfo("Click on the View All button");
		By ViewAll_button = Utility_Function.getDynamicElement(viewAllLinks, Subject_Name);
		try {
			scrollToElement(ViewAll_button);
			clickByJavascript(ViewAll_button);
		} catch (StaleElementReferenceException exp) {
			methodToAvoidStaleElementReferenceErrorElement(ViewAll_button);
			GetInstance(className);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		return GetInstance(className);
	}

	/**
	 * Function: To click on header links present on various pages
	 *
	 * @author Pratiksha Dixit
	 * @param Cases, HealthPlan, Treatment summary,Files,Email's etc
	 * @throws InterruptedException
	 */

	public <T> T ClickOnLinks(String Subject_Name, Class<T> className) throws InterruptedException {
		setTimeOut(1000);
		boolean result;
		int attempts = 0;
		String headerLink = "//*[contains(@class,\"active lafPageHost\")]//*[@class=\"slds-card__header-title\"]//a/span[@title=\"{0}\"]";
		waitForPageLoaded();
		setTimeOut(4000);
		while (attempts < 15) {
			try {
				setTimeOut(5000);
				By eleBottom = By.xpath(
						"//*[contains(@class,'active lafPageHost')]//*[@class='slds-card__header-title']//a/span[@title='"
								+ Subject_Name + "']");
				WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(2));
				wait.until(ExpectedConditions.presenceOfElementLocated(eleBottom));
				result = true;
			} catch (Exception e) {
				scrollToHalfPage();
				result = false;
				attempts++;
			}
			if (result == true) {
				break;
			}
		}
		By header_button = Utility_Function.getDynamicElement(headerLink, Subject_Name);
		try {
			scrollToElement(header_button);
			clickByJavascript(header_button);
			LoggingInfo("Successfully clicked on the Link " + Subject_Name);
		} catch (StaleElementReferenceException exp) {
			GetInstance(className);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return GetInstance(className);
	}

	/**
	 * This method will wait until the folder is having any downloads
	 * 
	 * @author dipyadav
	 * @throws InterruptedException
	 */
	public static void waitUntilFileToDownload(String fileLocation) throws InterruptedException {
		Thread.sleep(60000);
		WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(300));
		File files = new File(fileLocation);
		wait.until((ExpectedCondition<Boolean>) webDriver -> files.exists());

	}

	/**
	 * This method will wait until the folder contain .crdownload extension
	 * 
	 * @author dipyadav
	 * @throws InterruptedException
	 */
	public static void waitUntilFileToload(String folderLocation) throws InterruptedException {
		Thread.sleep(5000);
		File directory = new File(folderLocation);

		boolean downloadinFilePresence = false;
		File[] filesList = null;
		LOOP: while (true) {
			filesList = directory.listFiles();
			if (filesList.length != 0 || filesList != null) {
				for (File file : filesList) {
					downloadinFilePresence = file.getName().contains(".crdownload");
				}
			}
			if (downloadinFilePresence) {
				for (; downloadinFilePresence;) {
					Thread.sleep(500);
					continue LOOP;
				}
			} else {
				break;
			}
		}
	}

	/**
	 * Read pdfcontent using pdfbox
	 * 
	 * @author dipyadav
	 * @param Pdf file name
	 * @throws IOException
	 * @throws InvalidPasswordException
	 * @throws InterruptedException
	 */
	public static String readPdfContent(String Filename) throws InvalidPasswordException, IOException {
		String pdfContent = "";

		if (executionOn.equals("Remote")) {
			((RemoteWebDriver) getWebDriver()).setFileDetector(new LocalFileDetector());
		}
		String Folderpath = System.getProperty("user.dir") + File.separator + "Documents" + File.separator;
		String FilePath = Folderpath + Filename;
		File pdfFile = new File(FilePath);
		File[] files = new File(Folderpath).listFiles();
		try {
			for (File file : files) {
				if (!(file.getName().equalsIgnoreCase(Filename))) {
					file.delete();
					System.out.println("Deleted filename :" + file.getName());
				}
			}
			waitUntilFileToDownload(FilePath);
			PDDocument document = PDDocument.load(pdfFile);// Instantiate PDFTextStripper
			PDFTextStripper pdfStripper = new PDFTextStripper();// Retrieving text
			pdfContent = pdfStripper.getText(document);
			document.close();// Closing the document
			System.out.println(pdfContent);

			for (File file : files) {
				if (!(file.getName().equalsIgnoreCase(Filename))) {
					file.delete();
					System.out.println("Deleted filename :" + file.getName());
				}
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("some issue while Read PDF content :");
			for (File file : files) {
				file.delete();
			}
		}
		return pdfContent;

	}

	/**
	 * check for checkbox checked or not
	 * 
	 * @author dipyadav
	 * 
	 */
	public boolean isCheckboxSelected(By objCheckboxToCheck) {
		boolean isSelected = false;
		try {
			isSelected = getWebDriver().findElement(objCheckboxToCheck).isSelected();
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to check the checkbox - " + objCheckboxToCheck + " . " + " Error - " + e.getMessage());

		}
		return isSelected;
	}

	/**
	 * Check webElement is displayed/not displayed
	 * 
	 * @author Kruti
	 * 
	 */
	public boolean isElementDisplayed(By objElementToCheck) {
		boolean isDisp = false;
		try {
			int count = getWebDriver().findElements(objElementToCheck).size();
			if (count != 0) {
				isDisp = getWebDriver().findElement(objElementToCheck).isDisplayed();
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Issue with isElementDisplayed()" + " Error - " + e.getMessage());
		}
		return isDisp;
	}

	/**
	 * Function:Return Age
	 *
	 * @param DOB
	 * @author Dipali Yadav
	 */
	public static int calculateAge(String birthDate) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("M/dd/yyyy");
		Date date = formatter.parse(birthDate);
		// Converting obtained Date object to LocalDate object
		Instant instant = date.toInstant();
		ZonedDateTime zone = instant.atZone(ZoneId.systemDefault());
		LocalDate givenDate = zone.toLocalDate();
		// Calculating the difference between given date to current date.
		Period period = Period.between(givenDate, LocalDate.now());
		System.out.println(period.getYears());
		return period.getYears();
	}

	/**
	 * Function: To Verify Document present on document logs table
	 *
	 * @author Pratiksha
	 * @param documentList i.e Document Id's
	 */
	public void verifyDocumentPresentOnDocumentLogsTable(ArrayList<String> documentList, String expDocColName) {
		List<String> adverseDocList = getTabledataWithColname(expDocColName);
		System.out.println(adverseDocList);
		System.out.println(documentList);
		try {
			if (adverseDocList.equals(documentList)) {
				Assert.assertTrue(true);
			} else {
				Assert.fail("Document verification failed");
			}
			LoggingInfo("Document present under Document Logs Table- " + adverseDocList);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Document verification failed" + ". Error - " + e.getMessage());
		}

	}

	/**
	 * Function:Return the given date in a particular format eg : 1/23/2000
	 * 
	 * @param dueDate -given date - Date to be sent
	 * @author Harika Mudumby
	 * @throws ParseException
	 */
	public static String convertdateformat(String givenDate) throws ParseException {

		SimpleDateFormat sdfmt = new SimpleDateFormat("yyyy-MM-d");
		SimpleDateFormat sdfmt1 = new SimpleDateFormat("M/d/yyyy");
		Date curDate = sdfmt.parse(givenDate);
		String strOutput = sdfmt1.format(curDate);
		return strOutput;

	}

	/**
	 * Function:Return the given date in a particular format eg : 2000/01/23
	 * 
	 * @param dueDate -given date - Date to be sent
	 * @author Dipali Yadav
	 * @throws ParseException
	 */
	public static String convertdateformatWithDoubleDigit(String givenDate) throws ParseException {
		String strOutput = null;
		try {
			SimpleDateFormat sdfmt = new SimpleDateFormat("M/d/yyyy");
			SimpleDateFormat sdfmt1 = new SimpleDateFormat("yyyy-MM-dd");
			Date curDate = sdfmt.parse(givenDate);
			strOutput = sdfmt1.format(curDate);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Date conversion Failed" + ". Error - " + e.getMessage());
		}
		return strOutput;
	}

	/**
	 * Function: To Get the supply chain account id and Name
	 * 
	 * @author Pratiksha Dixit
	 */
	public ArrayList<String> getSupplyChainAccount() {
		ArrayList<String> accountValue = new ArrayList<String>();
		try {
			String[] authVals = Auth.getLoginAccessToken();
			String queryStatement = Queries.getScaAccount();
			String soqlResponseAcc = Payload.queryExecution(authVals[0], authVals[1], queryStatement);
			JsonPath js = new JsonPath(soqlResponseAcc);
			List<String> idList = js.getList("records.Id");
			List<String> idName = js.getList("records.Name");
			accountValue.add(idList.get(0));
			accountValue.add(idName.get(0));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return accountValue;
	}

	/**
	 * Function:Function to get active product Name,part Number,strength based on
	 * the product family
	 * 
	 * @param Product family
	 *
	 * @author Pratiksha Dixit
	 */
	public Map<String, Map<String, String>> getProductDetailsBasedOnFamilyUsingAPI(String productFamily) {
		Map<String, Map<String, String>> productDetails = new HashMap<>();
		final Map<String, String> productDetails1 = new HashMap<>();
		final Map<String, String> productDetails2 = new HashMap<>();
		Map<String, Map<String, String>> finalProducts = new HashMap<>();
		try {

			String[] authVals = Auth.getLoginAccessToken();
			String queryStatement = Queries.getActiveProductsDetails(productFamily);
			setTimeOut(1000);
			String soqlResponseAcc = Payload.queryExecution(authVals[0], authVals[1], queryStatement);
			JsonPath js = new JsonPath(soqlResponseAcc);
			List<String> idList = js.getList("records.Id");
			List<String> nameList = js.getList("records.Name");
			List<String> partNumberList = js.getList("records.iCC_ERP_Part_Number__c");
			List<String> strengthList = js.getList("records.PatientConnect__PC_Strength__c");
			List<String> orderPrefrenceList = js.getList("records.iCC_Part_Description_Order_Preference__c");

			int recordSize = js.get("records.size()");
			if (recordSize > 1) {
				productDetails2.put("Id", idList.get(1));
				productDetails2.put("Name", nameList.get(1));
				productDetails2.put("Part Number", partNumberList.get(1));
				productDetails2.put("Strength", strengthList.get(1));
				productDetails2.put("Order Prefrence", orderPrefrenceList.get(1));
			}
			productDetails1.put("Id", idList.get(0));
			productDetails1.put("Name", nameList.get(0));
			productDetails1.put("Part Number", partNumberList.get(0));
			productDetails1.put("Strength", strengthList.get(0));
			productDetails1.put("Order Prefrence", orderPrefrenceList.get(0));

			// Adding products in main map
			productDetails.put("product1", productDetails1);
			productDetails.put("product2", productDetails2);
			Iterator<Map.Entry<String, Map<String, String>>> parent = productDetails.entrySet().iterator();
			while (parent.hasNext()) {
				Map.Entry<String, Map<String, String>> parentPair = parent.next();
				Iterator<Map.Entry<String, String>> child = (parentPair.getValue()).entrySet().iterator();
				while (child.hasNext()) {
					Map.Entry childPair = child.next();
					if (childPair.getKey().equals("Order Prefrence") && childPair.getValue().equals("1")) {
						Map<String, String> parentValue = parentPair.getValue();
						finalProducts.put("ProductA", parentValue);
					} else if (childPair.getKey().equals("Order Prefrence") && childPair.getValue().equals("2")) {
						Map<String, String> parentValue = parentPair.getValue();
						finalProducts.put("ProductB", parentValue);
					}
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail("failed to get details" + ". Error - " + e.getMessage());
		}

		return finalProducts;

	}

	/**
	 * Function:Get Product A,B from active products map
	 * 
	 * @param map
	 * @author Pratiksha Dixit
	 */
	public Map<String, String> getProduct(Map<String, Map<String, String>> map, String productName) {
		Map<String, String> ExcelHashMapata = new HashMap<String, String>();
		try {
			LoggingInfo("Get Product Details");
			Iterator<Map.Entry<String, Map<String, String>>> parent = map.entrySet().iterator();
			while (parent.hasNext()) {
				Map.Entry<String, Map<String, String>> parentPair = parent.next();
				if (parentPair.getKey().equalsIgnoreCase(productName)) {
					Iterator<Map.Entry<String, String>> child = (parentPair.getValue()).entrySet().iterator();
					while (child.hasNext()) {
						Map.Entry childPair = child.next();
						ExcelHashMapata.put(childPair.getKey().toString(), childPair.getValue().toString());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("failed to Get" + ". Error - " + e.getMessage());
		}
		return ExcelHashMapata;
	}

	/**
	 * Function: Dynamic method to Get the order Select Patients and Dosage table
	 * data
	 * 
	 * @param cell values
	 * @author Dipali Yadav
	 */
	public static ArrayList<String> getTabledataWithHeaderAndRowCellValue(String expCellValue) {
		ArrayList<String> cellValues = new ArrayList<String>();

		try {
			List<WebElement> rows = getWebDriver()
					.findElements(By.xpath("//*[contains(@class,'active lafPageHost')]//table//tbody//tr"));
			List<WebElement> headerList = getWebDriver()
					.findElements(By.xpath("//*[contains(@class,'active lafPageHost')]//table/thead/tr/th//div"));
			boolean flag = false;

			for (int headerIndex = 0; headerIndex < headerList.size(); headerIndex++) {
				int rowCellIndex;
				String headerName;
				List<WebElement> value1;
				String value;
				headerName = headerList.get(headerIndex).getAttribute("title");

				if (headerName != null) {
					if (headerName.trim().equalsIgnoreCase("Patient Name")) {
						rowCellIndex = headerIndex - 4;
						for (int rowValue = 0; rowValue < rows.size(); rowValue++) {

							value = rows.get(rowValue)
									.findElement(
											By.xpath(".//*[contains(@class,'slds-truncate')][" + rowCellIndex + "]"))
									.getText().trim();
							if (value.equals(expCellValue)) {

								value1 = rows.get(rowValue).findElements(
										By.xpath(".//*[contains(@class,'slds-truncate')][" + rowCellIndex + "]"));

								for (int i = 0; i < value1.size(); i++) {

									cellValues.add(value1.get(i).getText());
								}
								flag = true;

								Assert.assertTrue(flag);
							}

						}
						break;
					}

				}
			}
		} catch (Exception e) {

		}
		return cellValues;

	}

	/**
	 * Function: Verify Review Errors pop up message
	 *
	 * @author Pratiksha Dixit
	 * @param Error message
	 */
	public void verifyReviewErrorMessaagePopup(String expErrorMrssage) {
		try {
			By reviewError = By
					.xpath("//*[contains(text(),'Review the')]//ancestor::div[@class='container']//div//*//li");
			waitAndVerifyElement(reviewError);
			verifyTextPresent(reviewError, expErrorMrssage);
			LoggingInfo("Error message verified successfully - " + expErrorMrssage);

		}

		catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify Error message" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * This method will click on login as the user on User details page
	 * 
	 * @author skumarsahu
	 */
	public void loginFromUserDetail(String nameOfUser) {
		waitForPageLoaded();
		try {
			getWebDriver().switchTo()
					.frame(getWebDriver().findElement(By.xpath("//div[@class='content iframe-parent']/iframe")));
			By loginButton = By.xpath("//td[@id='topButtonRow']//input[@title='Login']");
			waitAndVerifyElement(loginButton);
			clickByJavascript(loginButton);
			setTimeOut(2000);
			By loggedInAsHeader = By.xpath("//header//div[@data-message-id='loginAsSystemMessage']//span");
			setTimeOut(5000);
			waitAndVerifyElement(loggedInAsHeader);
			LoggingInfo("Sucessfully logged in form user detail");
			// verifyTextPresent(loggedInAsHeader, nameOfUser);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("failed to Login" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function:Return the date after number of days due
	 *
	 * @param dueDate
	 * @author Dipali Yadav
	 */
	public static String getDateInNumbericFormatWithDoubleDigit(int dueDate) {

		try {
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			Date dateobj = new Date();
			// TimeZone.setDefault(TimeZone.getTimeZone("EST"));
			TimeZone.setDefault(TimeZone.getTimeZone("New_York"));
			format = new SimpleDateFormat("MM/dd/yyyy");
			String curDate = df.format(dateobj);
			final Date date = format.parse(curDate);
			calendar = Calendar.getInstance();
			calendar.add(Calendar.DAY_OF_YEAR, dueDate);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Selection Failed" + ". Error - " + e.getMessage());
		}
		return format.format(calendar.getTime());
	}

	/**
	 * Function: Verify Snag pop up error message
	 *
	 * @author Dipali Yadav
	 * @param Error message
	 */
	public void verifyErrorMessaage_SnagPopup(String expErrorMrssage) {
		try {
			waitAndVerifyElement(eleSnagErrorMessageText);
			verifyTextPresent(eleSnagErrorMessageText, expErrorMrssage);
			LoggingInfo("Error message verified successfully - " + expErrorMrssage);

		}

		catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify Error message" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Close Snag pop up error message
	 *
	 * @author Dipali Yadav
	 *
	 */
	public void closeErrorMessaage_SnagPopup() {
		try {
			By eleErrorMessageButton = By.xpath("//*[@role='dialog']//*[text()='Close error dialog']");
			waitAndVerifyElement(eleErrorMessageButton);
			clickByJavascript(eleErrorMessageButton);
			LoggingInfo("Error message closed Successfully.");

		}

		catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify Error message" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: To click on App Launcher and search for Objects i.e.Products,Guides
	 * etc.
	 *
	 * @author Dipali Yadav
	 * @param objects name
	 * @throws InterruptedException
	 */
	public void clickOnAppLauncherAndSearchForObject(String Object) throws InterruptedException {
		Log.info("Click on App Launcher");
		By eleAppLauncher = By.xpath("//span[text()='App Launcher']//ancestor::button");
		By eleAppLauncherSearch = By.xpath("//input[@placeholder='Search apps and items...']");
		String strAppLauncherSearchComboList = "//input[@role=\"combobox\"]/ancestor::div[contains(@class,\"Menu\")]//*[text()=\"{0}\"]";
		waitForPageLoaded();
		waitAndVerifyElement(eleAppLauncher);
		setTimeOut(5000);
		clickByJavascript(eleAppLauncher);
		setTimeOut(5000);
		if (!isElementDisplayed(eleAppLauncherSearch))
			clickByJavascript(eleAppLauncher);

		waitAndVerifyElement(eleAppLauncherSearch);
		inputText(eleAppLauncherSearch, Object);
		By objcetText = getDynamicElement(strAppLauncherSearchComboList, Object);
		waitForPresenceOfElementLocated(eleAppLauncherSearch);
		waitAndVerifyElement(eleAppLauncherSearch);
		click(objcetText);
		setTimeOut(1000);
		Assert.assertTrue(true, "search object operation completed");
		LoggingInfo("search object operation completed");
	}

	/**
	 * Function: Generic function to Search and select the option after selecting
	 * the objects from the app launcher
	 * 
	 * @param searchOptionValue
	 * @author Pratiksha Dixit
	 * 
	 */
	public void searchAndSelectAfterOpeningtheObjectFromAppLauncher(String searchOptionValue) {
		try {
			Log.info("Select Option");

			String optionsList = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
			By textBox = By
					.xpath("//*[contains(@class,'active lafPageHost')]//input[@placeholder=\"Search this list...\"]");
			waitAndVerifyElement(textBox);
			click(textBox);
			inputText(textBox, searchOptionValue);
			getWebDriver().findElement(textBox).sendKeys(Keys.ENTER);
			setTimeOut(1000);
			By eleOptionLink = getDynamicElement(optionsList, searchOptionValue);
			waitAndVerifyElement(eleOptionLink);
			clickByJavascript(eleOptionLink);
			Assert.assertTrue(true, "Select Operation completed");
			LoggingInfo("Select operation completed");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Select operation Failed" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Select Filter list.
	 * 
	 * @param Listoption
	 * @author Dipali Yadav
	 * 
	 */

	public <T> T selectObjectFiltertList(String ListOption, Class<T> className) {
		String strTextElement = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@title,\"{0}\")]";
		By strDropDownList = By.xpath("//li[contains(@role,'presentation')]//a[@role='option']/span");

		try {
			Log.info("Select product List ");
			By ListButton = getDynamicElement(strTextElement, "Select a List View");
			waitAndVerifyElement(ListButton);
			clickByJavascript(ListButton);
			setTimeOut(5000);

			List<WebElement> listElements = getWebDriver().findElements(strDropDownList);
			for (WebElement elements : listElements) {
				if (elements.getText().equalsIgnoreCase(ListOption)) {
					setTimeOut(3000);
					WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(180));
					wait.until(ExpectedConditions.visibilityOf(elements));
					JavascriptExecutor executor = (JavascriptExecutor) getWebDriver();
					executor.executeScript("arguments[0].click();", elements);
					break;
				}
			}

			Assert.assertTrue(true);
			LoggingInfo("List option selected successfully." + ListOption);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed" + ". Error - " + e.getMessage());

		}
		return GetInstance(className);
	}

	/**
	 * Function: Filter list view
	 *
	 * @author Yuti Shah
	 * @return
	 * @throws InterruptedException
	 */
	public void addfilterToListView(String filterField, String filterValue) throws InterruptedException {
		Log.info("Filtering list view");

		By filterButton = By.xpath("//*[contains(@class,'active lafPageHost')]//button[@title=\"Show filters\"]");
		String linkAndButton = "//*[text()=\"{0}\"]";
		By saveButton = By.xpath("//*[text()=\"Save\" and @type=\"button\"]");
		By fieldFilter = By.xpath("//*[text()='Field']//following::button[1]");
		By filterValueXpath = By.xpath("//span[text()=\"Value\"]//following::input[1]");
		String fieldFilterOptionValue = "//span[text()=\"{0}\"]//ancestor::lightning-base-combobox-item";

		waitForPageLoaded();
		setTimeOut(8000);
		waitAndVerifyElement(filterButton);
		click(filterButton);
		click(getDynamicElement(linkAndButton, "Remove All"));
		if (isElementDisplayed(saveButton))
			click(saveButton);
		click(getDynamicElement(linkAndButton, "Add Filter"));
		click(fieldFilter);
		setTimeOut(2000);
		waitAndVerifyElement(fieldFilter);
		getWebDriver().findElement(fieldFilter).sendKeys(Keys.PAGE_DOWN);
		setTimeOut(2000);
		getWebDriver().findElement(fieldFilter).sendKeys(Keys.PAGE_DOWN);
		setTimeOut(2000);
		By fieldOptionValue = getDynamicElement(fieldFilterOptionValue, filterField);
		click(fieldOptionValue);
		inputText(filterValueXpath, filterValue);

		click(getDynamicElement(linkAndButton, "Done"));
		setTimeOut(2000);
		waitAndVerifyElement(saveButton);
		click(saveButton);
		setTimeOut(2000);
		LoggingInfo("Regions records filtered succesfully");
		System.out.println("Filter done ");

	}

	/**
	 * Function: Fetch Link text Field detail from respective page
	 *
	 * @param: Field name
	 * @author Dipali Yadav.
	 */
	public String fetchLinkTextValue(String fieldName) {

		setTimeOut(3000);
		String linkTextValue = "";
		By linkText = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"" + fieldName
				+ "\"]/parent::div/parent::*//following-sibling::*//a//span");
		waitAndVerifyElement(linkText);
		linkTextValue = getText(linkText);

		return linkTextValue;

	}

	/**
	 * Function:Return current EST Time with date
	 * 
	 * @author Dipali Yadav
	 */
	public static String getCurrentESTTimeWithDate() {

		DateTimeFormatter globalFormat = DateTimeFormatter.ofPattern("M/d/yyyy', 'h:m a");
		ZonedDateTime currentISTime = ZonedDateTime.now();
		ZonedDateTime currentETime = currentISTime.withZoneSameInstant(ZoneId.of("America/New_York")); // EST Time

		System.out.println(globalFormat.format(currentETime));
		String Value = globalFormat.format(currentETime);
		return Value;
	}

	/**
	 * Function: Fetch the all List option present under dropdownList
	 *
	 * @param: DropDown Field name
	 * @author Dipali Yadav.
	 */

	public List<String> getAllDropDownListOption(String DropDownName, boolean IsEditNeeded) {

		ArrayList<String> listValues = new ArrayList<String>();
		By dropDownListOption = By.xpath("//*[text()=\"" + DropDownName
				+ "\"]//following-sibling::div//*//lightning-base-combobox-item//*//span[@class='slds-truncate']");
		By TaskUpdate = By.xpath("//*[contains(@class,'active lafPageHost')]//*[text()=\"" + DropDownName
				+ "\"]/parent::div/parent::*//following-sibling::*//button");
		By SelectFieldButton = By.xpath("//*[contains(@class,'active lafPageHost')]//*[text()=\"" + DropDownName
				+ "\"]/ancestor::lightning-combobox//following-sibling::div//button");
		String s;
		try {

			if (IsEditNeeded) {
				waitAndVerifyElement(TaskUpdate);
				clickByJavascript(TaskUpdate);
			}
			waitAndVerifyElement(SelectFieldButton);
			clickByJavascript(SelectFieldButton);
			setTimeOut(5000);
			Log.info("Get Dropdown List options");
			waitAndVerifyElement(dropDownListOption);
			List<WebElement> epElements = getWebDriver().findElements(dropDownListOption);
			for (WebElement elements : epElements) {
				listValues.add(elements.getText().toString());
			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed" + ". Error - " + e.getMessage());

		}
		return listValues;

	}

	/**
	 * Function: Fetch the all List option present under dropdownList
	 *
	 * @param: DropDown Field name
	 * @author Pratiksha Dixit .
	 */

	public List<String> getAllDropDownListOptionForAnchorButton(String DropDownName, boolean IsEditNeeded) {

		ArrayList<String> listValues = new ArrayList<String>();
		By dropDownListOption = By.xpath("//div[contains(@class,\"short visible positioned\")]//a");
		By TaskUpdate = By.xpath("//*[contains(@class,'active lafPageHost')]//*[text()=\"" + DropDownName
				+ "\"]/parent::div//following-sibling::div//button");
		By SelectFieldButton = By.xpath("//*[contains(@class,\"active lafPageHost\")]//span[text()=\"" + DropDownName
				+ "\"]//parent::span/parent::div[contains(@class,\"uiInputSelect\")]//following-sibling::div//a");
		String s;
		try {

			if (IsEditNeeded) {
				waitAndVerifyElement(TaskUpdate);
				clickByJavascript(TaskUpdate);
			}
			waitAndVerifyElement(SelectFieldButton);
			clickByJavascript(SelectFieldButton);
			setTimeOut(5000);
			Log.info("Get Dropdown List options");
			waitAndVerifyElement(dropDownListOption);
			List<WebElement> epElements = getWebDriver().findElements(dropDownListOption);
			for (WebElement elements : epElements) {
				listValues.add(elements.getAttribute("title").toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed" + ". Error - " + e.getMessage());

		}
		return listValues;

	}

	/*
	 * Function name: genericKeyPress Description: To press generic keys like TAB,
	 * ENTER, etc
	 * 
	 * @param: Key Name
	 * 
	 * @author skumarsahu
	 */
	public void genericKeyPress(By objToPressKeyAt, String strKeyToPress) {
		try {
			waitAndVerifyElement(objToPressKeyAt);
			waitFor(2000);
			if (strKeyToPress.equalsIgnoreCase("Tab")) {
				getWebDriver().findElement(objToPressKeyAt).sendKeys(Keys.TAB);
			}
			if (strKeyToPress.equalsIgnoreCase("Enter")) {
				getWebDriver().findElement(objToPressKeyAt).sendKeys(Keys.ENTER);
			}
			if (strKeyToPress.equalsIgnoreCase("BackSpace")) {
				getWebDriver().findElement(objToPressKeyAt).sendKeys(Keys.BACK_SPACE);
			}
			Log.info(strKeyToPress + " key press successful in -  " + objToPressKeyAt);
			Assert.assertTrue(true, strKeyToPress + " key press successful in -  " + objToPressKeyAt);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error(strKeyToPress + "Key Press unsuccessful in - " + objToPressKeyAt + ". Error - " + e.getMessage());
			Assert.fail(
					strKeyToPress + "Key Press unsuccessful in - " + objToPressKeyAt + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Click On Related Nav Tab button
	 *
	 * @author skumarsahu
	 */
	public void clickOnRelated() {
		Log.info("Click On related button ");
		try {
			setTimeOut(2000);
			By navButton = By.xpath("//*[contains(@class,'active lafPageHost')]//a[text()='Related']");
			waitAndVerifyElement(navButton);
			clickByJavascript(navButton);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Assert.fail("Failed to click" + ". Error - " + e.getMessage());
		}

	}

	/**
	 * Function: Verify Review Errors message
	 *
	 * @author Dipali Yadav
	 * @param Error message
	 */
	public void verifyReviewErrorMessaageEnrollmentWizard(String expErrorMrssage) {
		try {
			By reviewError = By.xpath(
					"//*[contains(text(),'Review the')]//ancestor::div[@class='pageLevelErrors PatientConnectPC_ErrorPanel cICC_Patient_Info']//div//*//li");
			waitAndVerifyElement(reviewError);
			verifyTextPresent(reviewError, expErrorMrssage);
			LoggingInfo("Error message verified successfully - " + expErrorMrssage);

		}

		catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify Error message" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Review Errors messages
	 *
	 * @author Pratiksha Dixit
	 * @param Error messages List
	 */
	public void verifyReviewErrorsOnMessaageEnrollmentWizard(ArrayList<String> expectedErrorsList) {
		try {
			By reviewError = By.xpath(
					"//*[contains(text(),'Review the')]//ancestor::div[@class='pageLevelErrors PatientConnectPC_ErrorPanel cICC_Patient_Info']//div//*//li");
			waitAndVerifyElement(reviewError);
			List<WebElement> actualErrorList = getWebDriver().findElements(reviewError);
			if (actualErrorList.size() > 1) {
				for (int i = 0; i < expectedErrorsList.size(); i++) {

					Assert.assertTrue(actualErrorList.get(i).getText().equalsIgnoreCase(expectedErrorsList.get(i)));
				}
			}
			LoggingInfo("Error message verified successfully - " + expectedErrorsList);

		}

		catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify Error message" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Review Errors messages on Any page
	 *
	 * @author Pratiksha Dixit
	 * @param Error messages List
	 */
	public void verifyReviewErrorsOnMessaageOnAnyPage(ArrayList<String> expectedErrorsList) {
		try {
			By reviewError = By.xpath("//*[contains(text(),'Review the')]//parent::div//following-sibling::ul//li");
			waitAndVerifyElement(reviewError);
			List<WebElement> actualErrorList = getWebDriver().findElements(reviewError);
			for (int i = 0; i < expectedErrorsList.size(); i++) {
				String text = actualErrorList.get(i).getText();
				Assert.assertTrue(actualErrorList.get(i).getText().equalsIgnoreCase(expectedErrorsList.get(i)));
			}
			LoggingInfo("Error message verified successfully - " + expectedErrorsList);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify Error message" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Review Errors messages on case page
	 *
	 * @author Chaithanya
	 * @param Error messages List
	 */
	public void verifyReviewErrorsOnMessaageOnCasePage(ArrayList<String> expectedErrorsList) {
		try {
			By reviewError = By.xpath(eleQuickActionsPanel);
			waitAndVerifyElement(reviewError);
			List<WebElement> actualErrorList = getWebDriver().findElements(reviewError);
			for (int i = 0; i < expectedErrorsList.size(); i++) {
				String text = actualErrorList.get(i).getText();
				Assert.assertTrue(actualErrorList.get(i).getText().equalsIgnoreCase(expectedErrorsList.get(i)));
			}
			LoggingInfo("Error message verified successfully - " + expectedErrorsList);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify Error message" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Review Errors message
	 *
	 * @author Dipali Yadav
	 * @param Error message
	 */
	public void verifyReviewErrorMessaageConsentedContacts(String expErrorMrssage) {
		try {
			By reviewError = By.xpath("//*[contains(text(),'Review the')]//parent::div//following-sibling::ul//li");
			waitAndVerifyElement(reviewError);
			verifyTextPresent(reviewError, expErrorMrssage);
			LoggingInfo("Error message verified successfully - " + expErrorMrssage);

		}

		catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify Error message" + ". Error - " + e.getMessage());
		}
	}

	// *********************************************************************************************************
	// Function name: getText() without checking is weblement is present on page
	// Description: To obtain the value of the element

	// *********************************************************************************************************
	public String getTextWithoutVisbility(By objToGetText) {
		String text = null;
		try {
			text = getWebDriver().findElement(objToGetText).getText();
			Assert.assertTrue(true, "Get text operation successful - " + text);
			Log.info("Get text operation successful - " + text);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Get text operation unsuccessful. " + " Error - " + e.getMessage());
			Assert.fail("Get text operation unsuccessful. " + " Error - " + e.getMessage());
		}
		return text;
	}

	/**
	 * Function: Validation of Original and New Value in History name(original Value
	 * or New Value)
	 * 
	 * @param colValue,position Of col
	 * @author PratikshaDixit
	 */
	public ArrayList<String> historyValidation(String colValue, int postionValue, String objName) {
		ArrayList<String> finalList = new ArrayList<>();
		String eleHistoryValueList = "//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"{2}\"]//*[text()=\"{0}\"]//ancestor::tr//td[{1}]//lightning-formatted-text";
		try {
			By eleHistoryNewList = getDynamicElement(eleHistoryValueList, colValue, postionValue, objName);
			List<WebElement> newValueList = getWebDriver().findElements(eleHistoryNewList);
			setTimeOut(1000);
			LoggingInfo("Validation of updation values");
			for (WebElement element : newValueList) {
				finalList.add(element.getText());
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed" + ". Error - " + e.getMessage());
		}
		Logger("List Expected values" + finalList);
		return finalList;
	}

	/**
	 * Function:Return the Todays Date
	 */
	public static String getTodaysDate(int dueDate, String... formatUnderscore) {
		String curDate;
		try {
			if (formatUnderscore.length != 0) {
				DateFormat df = new SimpleDateFormat("MM_dd_yyyy");
				Date dateobj = new Date();
				// TimeZone.setDefault(TimeZone.getTimeZone("EST"));
				TimeZone.setDefault(TimeZone.getTimeZone("New_York"));
				format = new SimpleDateFormat("MM_dd_yyyy");
				curDate = df.format(dateobj);
			} else {
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				Date dateobj = new Date();
				// TimeZone.setDefault(TimeZone.getTimeZone("EST"));
				TimeZone.setDefault(TimeZone.getTimeZone("New_York"));
				format = new SimpleDateFormat("yyyy-MM-dd");
				curDate = df.format(dateobj);
			}
			final Date date = format.parse(curDate);
			calendar = Calendar.getInstance();
			calendar.add(Calendar.DAY_OF_YEAR, dueDate);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Selection Failed" + ". Error - " + e.getMessage());
		}
		return format.format(calendar.getTime());
	}

	/**
	 * Function:Return the Dates
	 */
	public static String getDateBasedOnTheNumberProvided(int dueDate, String... formatDate) {
		String curDate;
		Date dateobj;
		DateFormat df;
		Date date;
		try {
			df = new SimpleDateFormat("yyyy-MM-dd");
			dateobj = new Date();
			// TimeZone.setDefault(TimeZone.getTimeZone("EST"));
			TimeZone.setDefault(TimeZone.getTimeZone("New_York"));
			format = new SimpleDateFormat("yyyy-MM-dd");
			curDate = df.format(dateobj);
			date = format.parse(curDate);
			calendar = Calendar.getInstance();
			calendar.add(Calendar.DAY_OF_YEAR, dueDate);

			if (formatDate.length != 0) {
				if (formatDate[0].equalsIgnoreCase("slash")) {
					df = new SimpleDateFormat("MM/d/yyyy");
					dateobj = new Date();
					// TimeZone.setDefault(TimeZone.getTimeZone("EST"));
					TimeZone.setDefault(TimeZone.getTimeZone("New_York"));
					format = new SimpleDateFormat("MM/d/yyyy");
					curDate = df.format(dateobj);
					date = format.parse(curDate);
					calendar = Calendar.getInstance();
					calendar.add(Calendar.DAY_OF_YEAR, dueDate);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Selection Failed" + ". Error - " + e.getMessage());
		}
		return format.format(calendar.getTime());
	}

	/**
	 * Function: Verify Error Message on Field
	 * 
	 * @author skumarsahu param: Expected Error Message
	 */

	public void verifyErrorMessageOnField(String expErrorMsg) {
		try {
			String strFieldErrorMsg = "//*[contains(@class,\"active lafPageHost\")]//li[text()=\"{0}\"]";
			Log.info("Verifying error message on field");
			setTimeOut(2000);
			By actualErrorMessage = getDynamicElement(strFieldErrorMsg, expErrorMsg);
			waitAndVerifyElement(actualErrorMessage);
			scrollToElement(actualErrorMessage);
			LoggingInfo("Verified Error Message");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail(" Failed to verify error message" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Generic Function to Search any option and select/ or clear any selected
	 * option and select new options(This function first clear the selected option
	 * if any existing selection present and then search and select the options)
	 * 
	 * @param fieldName i.e product,account etc ,search Input i.e Search
	 *                  Product...,Search Account... etc opyion value i.e value to
	 *                  be selected
	 * @author pratidixit
	 */
	public void searchOptionAndSelectOrClearAndSelectNew(String fieldName, String searchInput, String optionValue,
			String... backSpaceRequired) {

		try {

			Log.info("Select dropdown option");
			String eleclearSelection = "//*[contains(@class,'active lafPageHost')]//*[text()=\"" + fieldName
					+ "\"]//following-sibling::div//*[@title='Clear Selection']";
			if (getWebDriver().findElements(By.xpath(eleclearSelection)).size() != 0) {
				clickByJavascript(By.xpath(eleclearSelection));

			}
			By eleSearchInput = getDynamicElement(strSearchInputXpath, searchInput);
			waitAndVerifyElement(eleSearchInput);
			inputText(eleSearchInput, optionValue);

			if (backSpaceRequired.length != 0) {
				genericKeyPress(eleSearchInput, "BackSpace");
			}
			By selectTypeOption = getDynamicElement(strDropdownOptionsXpath, optionValue);
			waitAndVerifyElement(selectTypeOption);
			clickByJavascript(selectTypeOption);

			LoggingInfo("Option selected successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Generic Function to Search any option and select/ or clear any selected
	 * option
	 * 
	 * @param fieldName i.e product,account etc ,search Input i.e Search
	 *                  Product...,Search Account... etc opyion value i.e value to
	 *                  be selected
	 * @author pratidixit
	 */
	public void searchOptionAndSelectOrClearAndNoOptionPresentInList(String fieldName, String searchInput,
			String optionValue, String... backSpaceRequired) {

		try {

			Log.info("Select dropdown option");
			String eleclearSelection = "//*[contains(@class,'active lafPageHost')]//*[text()=\"" + fieldName
					+ "\"]//following-sibling::div//*[@title='Clear Selection']";
			if (getWebDriver().findElements(By.xpath(eleclearSelection)).size() != 0) {
				clickByJavascript(By.xpath(eleclearSelection));

			}
			By eleSearchInput = getDynamicElement(strSearchInputXpath, searchInput);
			waitAndVerifyElement(eleSearchInput);
			inputText(eleSearchInput, optionValue);

			if (backSpaceRequired.length != 0) {
				genericKeyPress(eleSearchInput, "BackSpace");
			}
			By eleShowAll = getDynamicElement(eleShowAllResults, optionValue);
			waitAndVerifyElement(eleShowAll);
			clickByJavascript(eleShowAll);
			setTimeOut(10000);
			waitAndVerifyElement(eleNoResults);
			LoggingInfo("No Search Result present");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Generic Function to Validate all the lightning text values present on page
	 * based on the field name
	 * 
	 * @param fieldList,Value List(fieldNamesList is list of field names and
	 *                        fieldValueList is list of values to be selected with
	 *                        respective fields)
	 * @author pratidixit
	 */
	public void validateLightingTextPresentOnPageBasedOnFieldlabel(String xpath, List<String> fieldNamesList,
			List<String> fieldValueList, boolean string, String fieldName, String fieldValue) {
		try {
			By eleText;
			setTimeOut(50000);
			LoggingInfo("Validate Lightning Text");
			if (string) {
				if (xpath != "") {
					eleText = getDynamicElement(xpath, fieldName);
				} else {
					eleText = getDynamicElement(strLightningTextXpath, fieldName);
				}
				waitAndVerifyElement(eleText);
				verifyTextPresent(eleText, fieldValue);
			}

			else {
				for (int i = 0; i < fieldNamesList.size(); i++) {
					if (fieldValueList.get(i) != "") {
						if (xpath != "") {
							eleText = getDynamicElement(xpath, fieldNamesList.get(i));
						} else {
							eleText = getDynamicElement(strLightningTextXpath, fieldNamesList.get(i));
						}
						verifyTextPresent(eleText, fieldValueList.get(i));
					}
				}
			}

			LoggingInfo("Validation successfull");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Generic Function to Validate all the Link text values present on page based
	 * on the field name
	 * 
	 * @param fieldList,Value List(fieldNamesList is list of field names and
	 *                        fieldValueList is list of values to be selected with
	 *                        respective fields)
	 * @author pratidixit
	 */
	public void validateLinkText(String xpath, List<String> fieldNamesList, List<String> fieldValueList) {
		By eleText;
		try {
			for (int i = 0; i < fieldNamesList.size(); i++) {
				if (fieldValueList.get(i) != "") {
					if (xpath != "") {
						eleText = getDynamicElement(xpath, fieldNamesList.get(i));
					} else {
						eleText = getDynamicElement(strLinkText, fieldNamesList.get(i));
					}
					verifyTextPresent(eleText, fieldValueList.get(i));
				}
			}
			LoggingInfo("Validation successfull");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Generic Function to Input field values
	 * 
	 * @param fieldList,Value List(fieldNamesList is list of field names and
	 *                        fieldValueList is list of values to be filled in each
	 *                        respective fields)
	 * @author pratidixit
	 */
	public void genericFunctionOnFillInputText(String eleInput, ArrayList<String> fieldNamesList,
			ArrayList<String> fieldValueList) {
		try {
			LoggingInfo("Fill input text present on any page");
			for (int i = 0; i < fieldNamesList.size(); i++) {
				if (fieldValueList.get(i) != "") {
					By eleInputBox = getDynamicElement(eleInput, fieldNamesList.get(i));
					inputText(eleInputBox, fieldValueList.get(i));
					genericKeyPress(eleInputBox, "Tab");

				}
			}
			LoggingInfo("Input successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed" + ". Error - " + e.getMessage());

		}
	}

	// Function name: getallItemFromList()
	// Description: To get all a value from any Dropdown list using Select class
	// Prerequisite:
	// *********************************************************************************************************
	public List<String> getAllSelectItemFromList(By objToSelectValueFrom) {
		ArrayList<String> AllListOptions = new ArrayList<String>();
		try {
			if (methodToAvoidStaleElementReferenceErrorElement(objToSelectValueFrom)) {
				waitAndVerifyElement(objToSelectValueFrom);
				WebElement element = getWebDriver().findElement(objToSelectValueFrom);
				Select select = new Select(element);
				List<WebElement> listElement = select.getOptions();
				for (WebElement option : listElement) {
					AllListOptions.add(option.getText());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Not able to select values in " + objToSelectValueFrom + ". " + " Error - " + e.getMessage());

		}
		return AllListOptions;
	}

	/**
	 * Function: Wait For visibilty of button
	 *
	 * @author Pratiksha
	 * @param New, Save etc
	 */
	public void waitForVisibityOfButton(String value) {
		setTimeOut(1000);
		By button = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"" + value + "\"]");
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(getWebDriver()).withTimeout(Duration.ofSeconds(100))
					.pollingEvery(Duration.ofSeconds(5)).ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.visibilityOfElementLocated(button));
			// setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	/**
	 * Function: To Click Any record link
	 *
	 * @author Pratiksha Dixit
	 * @param Record Name,Status,Outcome
	 */
	public void clickOnRecordBasedOnNameStatusAndOutcome(String name, String status, String... outcome) {
		try {
			if (status != "") {
				waitForPageLoaded();
				By option = getDynamicElement(strLinkithStatusAndOutcomeXpath, name, status);
				waitAndVerifyElement(option);
				clickByJavascript(option);
				Log.info("Click on record - " + option);
				Assert.assertTrue(true, "Click on object successful - " + option);
				setTimeOut(3000);
			}
			if (outcome.length != 0) {
				waitForPageLoaded();
				By option1 = getDynamicElement(strLinkithStatusAndOutcomeXpath, name, outcome[0]);
				waitAndVerifyElement(option1);
				clickByJavascript(option1);
				Log.info("Click on record - " + option1);
				Assert.assertTrue(true, "Click on object successful - " + option1);
				setTimeOut(3000);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Click on object unsuccessful - " + name + ". Error - " + e.getMessage());
			Assert.fail("Click on object unsuccessful - " + name + ". Error - " + e.getMessage());
		}
		LoggingInfo(name + " Record is opened");
	}

	public void errorValidation(String error) {

		try {

			Log.info("Error Validation");

			By assertValidation = getDynamicElement(assertError1, error);
			waitAndVerifyElement(assertValidation);
			Assert.assertTrue(getWebDriver().findElement(assertValidation).isDisplayed());
			LoggingInfo("Captured error");
			By closeAssert = getDynamicElement(strButton, "Close error dialog");
			waitAndVerifyElement(closeAssert);
			clickByJavascript(closeAssert);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed" + ". Error - " + e.getMessage());
		}
	}

	// Function: close the pop-up window [x] button

	public void closePopUpWindow() {
		click(elePreviewModelCloseBTN);
	}

	/**
	 * Function: To compare HashMap key with List
	 */
	public boolean compareHashMapKeywithList(Map<String, String> map, List<String> list) {
		boolean flag = false;
		for (String key : list) {
			if (map.containsKey(key)) {
				flag = true;
			} else {
				flag = false;
			}
		}
		return flag;

	}

	/**
	 * Function: To getExcel data using sheetName and returning hashMap values
	 * 
	 * @param SheetName
	 * @author varsrinivasan
	 * @throws IOException
	 * 
	 */
	public ReadExcel excel;

	public HashMap<String, String> readExcelData(String sheetName) throws IOException {
		HashMap<String, String> ExcelHashMapata = new HashMap<String, String>();
		XSSFSheet sheet;
		String ss;
		excel = new ReadExcel(sheetName);
		sheet = excel.getSheet();

		for (Row row : sheet) {
			Cell keyCell = row.getCell(0);
			Cell valueCell = row.getCell(1);

			String key = keyCell.toString();
			String value = valueCell.toString();
			ExcelHashMapata.put(key, value);
		}

		return ExcelHashMapata;

	}

	/**
	 * Function: To Verify Button is not displayed on UI
	 *
	 * @author Pratiksha
	 * @param value i.e preview and send, edit etc
	 */
	public boolean verifyButtonIsNotDisplayed(String value) {
		setTimeOut(200);
		boolean flag = false;
		By button = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"" + value + "\"]");
		try {
			List<WebElement> butLIst = getWebDriver().findElements(button);
			if (butLIst.size() == 0) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			LoggingInfo(button + " Button is Present");
		}
		return flag;

	}

	public void SelectDropDownOptionWithXPath(String buttonXpath, String OptionXpath, List<String> fieldNamesList,
			List<String> fieldValues) {
		try {
			Log.info("Select dropdown option");
			for (int i = 0; i < fieldValues.size(); i++) {
				if (fieldValues.get(i) != "") {
					By Dropdown = getDynamicElement(buttonXpath, fieldNamesList.get(i));
					waitAndVerifyElement(Dropdown);
					clickByJavascript(Dropdown);
					By fieldOption = getDynamicElement(OptionXpath, fieldValues.get(i));
					waitAndVerifyElement(fieldOption);
					clickByJavascript(fieldOption);
				}
			}
			LoggingInfo("Option selected successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed" + ". Error - " + e.getMessage());

		}
	}

	public void SelectDropDownOptionWithXPath(String buttonXpath, String OptionXpath, String fieldDropdownButton,
			String fieldDropdownValue) {

		try {
			Log.info("Select dropdown option");
			By Dropdown = getDynamicElement(buttonXpath, fieldDropdownButton);
			waitAndVerifyElement(Dropdown);
			clickByJavascript(Dropdown);
			By fieldOption = getDynamicElement(OptionXpath, fieldDropdownValue);
			waitAndVerifyElement(fieldOption);
			clickByJavascript(fieldOption);
			LoggingInfo("Option selected successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Validation Method to verify field values
	 * 
	 * @param
	 * @author Chaithanya
	 * 
	 */
	public void validateFieldDetails(ArrayList<String> fieldNamesList, ArrayList<String> fieldsValueListEP) {

		ArrayList<String> linkFieldsList = new ArrayList<>(
				Arrays.asList("Account Name", "Engagement Program", "Consent Form Version", "Signed Request Form",

						"Patient", "Program", "Source Case", "Target Pharmacy", "Case Manager", "Care Team Member",
						"User", "Product"));

		ArrayList<String> typeFieldsList = new ArrayList<>(
				Arrays.asList("Case Record Type", "Account Record Type", "Task Record Type"));
		ArrayList<String> anchorTagFieldsList = new ArrayList<>(Arrays.asList("Email", "Program Service Permission",
				"Related To", "Case", "Address", "Home Phone", "HCPCS Code", "CPT Code", "ICD-10 Diagnosis Code"));
		ArrayList<String> spanTextFiledList = new ArrayList<>(
				Arrays.asList("Due Date", "Priority", "Channel", "Interaction With", "Planned Attempt", "Category",
						"Sub-Category", "Direction", "Fulfillment Item", "Program Case", "Initiative Name", "Topic",
						"Key Conversations", "Product", "Program Coverage", "Record Type", "NDC", "Order", "SCA"));

		ArrayList<String> lightningFormattedNumber = new ArrayList<>(
				Arrays.asList("Order Quantity A", "Order Quantity B"));
		ArrayList<String> roleList = new ArrayList<>(Arrays.asList("Assigned To", "Assign to Role"));
		ArrayList<String> textContainsList = new ArrayList<>(
				Arrays.asList("Status", "Subject", "Account", "Engagement Program Name"));
		try {
			for (int i = 0; i < fieldsValueListEP.size(); i++) {
				if (fieldsValueListEP.get(i) != "") {
					Log.info("Verification for fields value " + fieldNamesList.get(i));
					if (linkFieldsList.contains(fieldNamesList.get(i))) {
						By elementField = getDynamicElement(strLinkText, fieldNamesList.get(i));
						verifyTextPresent(elementField, fieldsValueListEP.get(i));
						Log.info("Verified link text field " + fieldNamesList.get(i) + ", value - "
								+ fieldsValueListEP.get(i));
					} else if (typeFieldsList.contains(fieldNamesList.get(i))) {
						By elementField = getDynamicElement(strTypeText, fieldNamesList.get(i));
						verifyTextPresent(elementField, fieldsValueListEP.get(i));
						Log.info("Verified type field " + fieldNamesList.get(i) + ", value - "
								+ fieldsValueListEP.get(i));
					} else if (anchorTagFieldsList.contains(fieldNamesList.get(i))) {
						By elementField = getDynamicElement(strLinkTextAchorTag, fieldNamesList.get(i));
						verifyTextPresent(elementField, fieldsValueListEP.get(i));
						Log.info("Verified link field " + fieldNamesList.get(i) + ", value - "
								+ fieldsValueListEP.get(i));
					} else if (spanTextFiledList.contains(fieldNamesList.get(i))) {
						By dueDateTextValue = getDynamicElement(taskFieldText, fieldNamesList.get(i));
						waitAndVerifyElement(dueDateTextValue);
						verifyTextPresent(dueDateTextValue, fieldsValueListEP.get(i));
						Log.info("Verified text field " + fieldNamesList.get(i) + ", value - "
								+ fieldsValueListEP.get(i));
					} else if (textContainsList.contains(fieldNamesList.get(i))) {
						By dueDateTextValue = getDynamicElement(casesPageXpaths.statusTextContains,
								fieldNamesList.get(i), fieldsValueListEP.get(i));
						Assert.assertTrue(isElementDisplayed(dueDateTextValue));
						Log.info("Verified text field " + fieldNamesList.get(i) + ", value - "
								+ fieldsValueListEP.get(i));
					} else if (lightningFormattedNumber.contains(fieldNamesList.get(i))) {
						By elementField = getDynamicElement(casesPageXpaths.LightningNumberText, fieldNamesList.get(i),
								fieldsValueListEP.get(i));
						Assert.assertTrue(isElementDisplayed(elementField));
						Log.info("Verified text field " + fieldNamesList.get(i) + ", value - "
								+ fieldsValueListEP.get(i));
					} else if (roleList.contains(fieldNamesList.get(i))) {
						By assignedToTextValue;
						if ((fieldNamesList.get(i).equals("Assign to Role"))) {
							assignedToTextValue = By.xpath(MessageFormat.format(taskFieldText, fieldNamesList.get(i)));
						} else {
							assignedToTextValue = By
									.xpath(MessageFormat.format(casesPageXpaths.taskLink, fieldNamesList.get(i)));
						}
						int Size = getWebDriver().findElements(assignedToTextValue).size();
						if (Size != 0) {
							waitAndVerifyElement(assignedToTextValue);
							String value = getText(assignedToTextValue);
							Assert.assertTrue(!value.isEmpty());
							Log.info("Verified " + fieldNamesList.get(i) + " field value is not null");
						}
					} else if (fieldNamesList.get(i).equals("System Generated Task")) {
						waitAndVerifyElement(casesPageXpaths.systemGeneratedTaskCheckBox);
						Log.info("Verified " + fieldNamesList.get(i) + " field value is checked");
					} else {
						By elementField = getDynamicElement(strLightningTextXpath, fieldNamesList.get(i));
						verifyTextPresent(elementField, fieldsValueListEP.get(i));
						Log.info("Verified field " + fieldNamesList.get(i) + ", value - " + fieldsValueListEP.get(i));
					}
				}
			}
			LoggingInfo("Verified all fields successfully");
		} catch (

		Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify fields values" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: To verify Default Expiration Days for service
	 *
	 * @author Dipali Yadav
	 * @param
	 */
	public void verify_ServicePermissionLightningText(String expField, String expValue) {
		By serveiceTextValue = getDynamicElement(strLightningTextXpath, expField);
		waitAndVerifyElement(serveiceTextValue);
		verifyTextPresent(serveiceTextValue, expValue);

	}

	/**
	 * Function: Code to create zip file
	 * 
	 * @param Send files list
	 * @author Pratiksha Dixit
	 */
	public static File zip(List<File> files, String filename) {
		File zipfile = new File(filename);
		// Create a buffer for reading the files
		byte[] buf = new byte[1024];
		try {
			// create the ZIP file
			ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipfile));
			// compress the files
			for (int i = 0; i < files.size(); i++) {
				FileInputStream in = new FileInputStream(files.get(i).getCanonicalFile());
				// add ZIP entry to output stream
				out.putNextEntry(new ZipEntry(files.get(i).getName()));
				// transfer bytes from the file to the ZIP file
				int len;
				byte[] b = new byte[1024];
				while ((len = in.read(b, 0, 1024)) > 0) {
					out.write(buf, 0, len);
				}
				// complete the entry
				out.closeEntry();
				in.close();
			}
			// complete the ZIP file
			out.close();
			System.out.println("Done");
			return zipfile;
		} catch (IOException ex) {
			System.err.println(ex.getMessage());
		}
		return null;

	}

	/**
	 *
	 * @param file
	 * @return
	 */
	public static String getFilesName(String file) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss");
		Calendar cal = Calendar.getInstance();
		String fileName = file + dateFormat.format(cal.getTime());
		return fileName;
	}

	/**
	 * Function: Get Attribute Value
	 * 
	 * @param field xpath, attribute name
	 * @author Chaithanya
	 * @return
	 */
	public String getAttributeValue(By eleLinkTextField, String attributeName) {
		String text = null;
		try {
			waitAndVerifyElement(eleLinkTextField);
			text = getWebDriver().findElement(eleLinkTextField).getAttribute(attributeName);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get attribute value. " + " Error - " + e.getMessage());
			Assert.fail("Failed to get attribute value. " + " Error - " + e.getMessage());
		}
		return text;
	}

	/**
	 * Function: switch To Window
	 * 
	 * @param window title
	 * @author Chaithanya
	 * @return
	 */
	public static WebDriver switchToWindow(String title) {
		WebDriver popup = null;
		try {
			Set<String> windowIterator = getWebDriver().getWindowHandles();
			for (String s : windowIterator) {
				String windowHandle = s;
				popup = getWebDriver().switchTo().window(windowHandle);
				if (popup.getTitle().contains(title)) {
					return popup;
				}
			}
		} catch (Exception e) {
			Log.error("User has failed to switch to window:: Error - " + e.getMessage());
			Assert.fail("User has failed to switch to window:: Error - " + e.getMessage());
		}
		return popup;
	}

	/**
	 * Function: verify checkbox checked or un-checked
	 * 
	 * @param field, value
	 * @author Chaithanya
	 */
	public void verifyIsActiveCheckBox(String field, boolean IsChecked) {
		try {
			By elePrimaryAddressesCheck = Utility_Function.getDynamicElement(strCheckBoxElement, field);
			waitAndVerifyElement(elePrimaryAddressesCheck);
			Assert.assertEquals(isCheckboxSelected(elePrimaryAddressesCheck), IsChecked);
			LoggingInfo("Verify checkbox is verified for - " + field);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify checkbox check" + field + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: To validate fields are present or not in layout
	 *
	 * @author Pratiksha Dixit
	 * @param Field List
	 */
	public void validateFieldsArePresentInLayout(List<String> fieldList, String... fieldSpan) {

		try {
			if (fieldSpan.length != 0) {
				for (int i = 0; i < fieldList.size(); i++) {
					By eleField = getDynamicElement(strFieldsSpanXpath, fieldList.get(i));
					waitAndVerifyElement(eleField);
					LoggingInfo("Field successfully verified.");
				}
			} else {
				for (int i = 0; i < fieldList.size(); i++) {
					By eleField = getDynamicElement(strFieldsXpath, fieldList.get(i));
					waitAndVerifyElement(eleField);
					LoggingInfo("Field successfully verified.");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Function: Validate APP Laucher Filter Values
	 * 
	 * @param Listoption
	 * @author Pratiksha Dixit
	 * 
	 */

	public ArrayList<String> validateFilterValues() {
		String strTextElement = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@title,\"{0}\")]";
		By strDropDownList = By.xpath("//li[contains(@role,'presentation')]//a[@role='option']/span");
		ArrayList<String> filterValues = new ArrayList<String>();
		try {
			Log.info("Select product List ");
			By ListButton = getDynamicElement(strTextElement, "Select a List View");
			waitAndVerifyElement(ListButton);
			clickByJavascript(ListButton);
			setTimeOut(5000);

			List<WebElement> listElements = getWebDriver().findElements(strDropDownList);
			for (WebElement elements : listElements) {
				filterValues.add(elements.getText());
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed" + ". Error - " + e.getMessage());

		}
		return filterValues;
	}

	/**
	 * Function: verify field Is Not Null
	 *
	 * @author Chaithanya
	 * @param
	 */
	public void verifyFieldValueIsNotNull(String field) {
		try {
			By elementField = getDynamicElement(strLightningTextXpath, field);
			String value = getText(elementField);
			Assert.assertTrue(!value.isEmpty());
			Log.info("Verified field " + field + ", value is not null");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify field " + field + ", value is not null" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Verify LookUp Field Value
	 *
	 * @author Chaithanya
	 * @param comment
	 */
	public void verifyLookUpFieldValue(String field, boolean value) {
		try {
			Log.info("Verify LookUp Field Value" + field);
			By serviceCaseSelection = By.xpath(MessageFormat.format(fieldSearchBoxSelectionXpath, field));
			setTimeOut(5000);
			if (value) {
				Assert.assertTrue(isElementDisplayed(serviceCaseSelection));
			} else {
				Assert.assertTrue(!isElementDisplayed(serviceCaseSelection));
			}
			LoggingInfo(" fields validated successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed fields Verification Failed to Completed" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: verify Fields Under Section
	 * 
	 * @param fields array list
	 * @author Chaithanya
	 */
	public void verifyFieldsUnderSection(String Section, ArrayList<String> fieldNamesList) {
		try {
			Log.info("Verification for " + Section + " fields");
			for (int i = 0; i < fieldNamesList.size(); i++) {
				By elementField = getDynamicElement(fieldsUnderSection, Section, fieldNamesList.get(i));
				waitAndVerifyElement(elementField);
			}
			LoggingInfo(Section + " fields validated successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail(Section + " fields Verification Failed to Completed" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Fill Text in popUp container textarea box
	 *
	 * @author Pratiksha Dixit
	 * @param textValue
	 */
	public void fillTextInCommentContainerPopUP(String textValue) {
		try {
			inputText(strPopUpCommentContainerTextArea, textValue);
			LoggingInfo("Field Filled successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to input text field" + e.getMessage());
		}
	}

	/**
	 * Function: Click Pop up container Footer buttons
	 *
	 * @author Pratiksha Dixit
	 * @param Button Name i.e Submit,Cancel etc
	 */
	public void clickOnPopUpFooterButton(String buttonName) {
		try {
			LoggingInfo("Clikc On Footer button- " + buttonName);
			By btnNameEle = getDynamicElement(strFooterButtonXpath, buttonName);
			clickByJavascript(btnNameEle);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on  Button" + e.getMessage());
		}
	}

	/**
	 * Function: Wait For invisibilty of Footer button
	 *
	 * @author Pratiksha
	 * @param Submit, Cancel
	 */
	public void waitForInvisibilityOfFooterButton(String buttonName) {
		setTimeOut(1000);

		By btnNameEle = By.xpath("//button//span[text()=\"" + buttonName + "\"]");
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(getWebDriver()).withTimeout(Duration.ofSeconds(100))
					.pollingEvery(Duration.ofSeconds(5)).ignoring(NoSuchElementException.class);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(btnNameEle));
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	/**
	 * Function: verify Program Benefit under value
	 * 
	 * @param count
	 * @author Chaithanya
	 */
	public void verifyProgramCategoryCount(String category, String count) {
		try {
			By eleHeadtingProgramCases = Utility_Function.getDynamicElement(commonH2TextElement1, category, count);
			waitAndVerifyElement(eleHeadtingProgramCases);
			LoggingInfo("Verified " + category + " case count - " + count);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify " + category + " count " + count + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: verify program cases count
	 * 
	 * @param count
	 * @author Chaithanya
	 */
	public void verifyRecordCount(String category, String count) {
		try {
			By eleHeadtingProgramCases = Utility_Function.getDynamicElement(commonH2TextElement, category);
			waitAndVerifyElement(eleHeadtingProgramCases);
			Assert.assertTrue((getText(eleHeadtingProgramCases)).contains(count));
			LoggingInfo("Verified " + category + " count - " + count);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify " + category + " count " + count + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Task comment field area text message.
	 * 
	 * @author Dipali Yadav
	 * 
	 */
	public void verifyTaskComment(String expComment) {
		try {
			if (expComment != "") {
				setTimeOut(2000);
				waitAndVerifyElement(commentMessage);
				verifyTextPresent(commentMessage, expComment);
			} else {
				Assert.assertEquals(getTextWithoutVisbility(commentMessage), "");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("comment verify operation Failed" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function:Verify read only fields dose
	 *
	 * @author Vaisnavi
	 */
	public void verifyReadOnlyFields(ArrayList<String> fieldNamesList) {
		try {
			LoggingInfo("Verify Read only fields");
			for (int i = 0; i < fieldNamesList.size(); i++) {
				LoggingInfo("Verifying " + fieldNamesList.get(i) + " Field");
				By eleReadOnly = getDynamicElement(strRxDoseReadOnlyField, fieldNamesList.get(i));
				verifyElement(eleReadOnly);
			}
			setTimeOut(200);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("failed to click" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: To upload a document
	 *
	 * @author Kruti Unnithan
	 * @param strFileName - file name with extension
	 */
	public void uploadDocument(String strFileName) {
		try {
			Log.info("Uploading document");
			setTimeOut(3000);
			waitForPresenceOfElementLocated(eleUploadFileInput);
			if (executionOn.equals("Remote")) {
				((RemoteWebDriver) getWebDriver()).setFileDetector(new LocalFileDetector());
			}
			String strPath = "Documents_Test/" + strFileName;
			File filePathName = new File(strPath);
			String path = filePathName.getAbsolutePath();
			getWebDriver().findElement(eleUploadFileInput).sendKeys(path);

			Thread.sleep(9000);
			By Button = Utility_Function.getDynamicElement(strGenericBtn, "Done");
			clickByJavascript(Button);
			LoggingInfo("Doc uploaded successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Issue in function uploadDocument" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Update Date
	 * 
	 * @param field , value
	 * @author Chaithanya
	 */
	public void updateDate(String field, int value) {
		try {
			By deliveryDateTextbox = getDynamicElement(eleFieldDate, field, "Date");
			waitAndVerifyElement(deliveryDateTextbox);
			String dDate = getDueDateInNumbericFormat(value);
			inputText(deliveryDateTextbox, dDate);
			getWebDriver().findElement(deliveryDateTextbox).sendKeys(Keys.TAB);
			LoggingInfo("Entered create order supply details");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Fail to enter create order supply details " + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Verify error Message on page
	 *
	 * @author Dipali Yadav
	 * @param Error messages
	 */
	public void verifyFiledlevelErrorMessage(String errorMessage) {
		try {
			waitAndVerifyElement(eleFieldLevelError);
			String actualError = getWebDriver().findElement(eleFieldLevelError).getText();
			Assert.assertTrue(actualError.equalsIgnoreCase(errorMessage));
			LoggingInfo("Error message verified successfully - " + errorMessage);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify Error message" + ". Error - " + e.getMessage());
		}

	}

	/**
	 * Function: To Get the Snag hit Error Messages
	 * 
	 * @author Dipali Yadav.
	 */
	public ArrayList<String> getSnagErrorMessages() {
		ArrayList<String> errorMessageList = new ArrayList<String>();
		try {
			List<WebElement> errorElementList = getWebDriver().findElements(eleSnagErrorMessageText);
			for (WebElement ele : errorElementList) {
				errorMessageList.add(ele.getText());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		LoggingInfo("Errors Present on page: " + errorMessageList);
		return errorMessageList;

	}

	/**
	 * Function: Global Search any object
	 *
	 * @author skumarsahu
	 * @param object
	 */
	public void globalSearchNotFound(String name, String Object) {
		try {

			setTimeOut(4000);
			String globalSearch = "//*[@aria-label='Search']";
			getWebDriver().findElement(By.xpath(globalSearch)).click();

			String globalSearchInput = "//div[contains(@class,\"Search\")]//*[@type='search' and @class='slds-input']";
			waitAndVerifyElement(By.xpath(globalSearchInput));

			getWebDriver().findElement(By.xpath(globalSearchInput)).sendKeys(name);
			getWebDriver().findElement(By.xpath(globalSearchInput)).sendKeys(Keys.ENTER);
			setTimeOut(4000);
			waitForPageLoaded();
			String searchedLink = "//span[contains(text(),\"We searched the objects you use most and didn't find any matches for\")]";
			waitAndVerifyElement(By.xpath(searchedLink));
			setTimeOut(3000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Function: To verify Field is Disabled or Enabled
	 *
	 * @author Uttam Kumar
	 * @param xPath, value, isTrue
	 */
	public void verifyAnyFieldIsDisabledOrEnabled(String xPath, String Value, boolean isTrue) {
		try {
			if (isTrue) {
				LoggingInfo("Verify weather field Enabled");
				By fieldLocator = getDynamicElement(xPath, Value);
				verifyElement(fieldLocator);
				Assert.assertTrue(getWebDriver().findElement(fieldLocator).isDisplayed());
			} else {
				LoggingInfo("Verify weather field Disable");
				By fieldLocator = getDynamicElement(xPath, Value);
				verifyElement(fieldLocator);
				String value = getAttributeValue(fieldLocator, "disabled");
				Assert.assertEquals(value, "true");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Button" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Clear Selection
	 * 
	 * @param field
	 * @author Chaithanya
	 */
	public void clearSelection(String fieldName) {
		try {
			LoggingInfo("Clear Selection " + fieldName);
			String eleclearSelection = "//*[contains(@class,'active lafPageHost')]//*[text()=\"" + fieldName
					+ "\"]//following-sibling::div//*[@title='Clear Selection']";
			if (getWebDriver().findElements(By.xpath(eleclearSelection)).size() != 0) {
				clickByJavascript(By.xpath(eleclearSelection));
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to clear selection " + fieldName + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: To verify Error message validation
	 *
	 * @author Uttam Kumar
	 * @param errorMessage
	 */
	public void errorMessageValidation(String error) {
		try {
			Log.info("Error Validation");
			By assertValidation = getDynamicElement(assertError1, error);
			waitAndVerifyElement(assertValidation);
			// scrollToElement(assertValidation);
			Assert.assertTrue(getWebDriver().findElement(assertValidation).isDisplayed());
			LoggingInfo("Error message is present.");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed Not able to validate" + ". Error - " + e.getMessage());
		}
	}

	/*
	 * Function: verify columns
	 * 
	 * @author Chaithanya
	 * 
	 * @param ArrayList containing section titles
	 */
	public void verifyColumns(ArrayList<String> coloumnNames) {
		scrollToDocumentHeight();
		scrollToTopOfPage();
		try {
			for (String coloumnName : coloumnNames) {
				By sectionLink = getDynamicElement(strColoumnName, coloumnName);
				scrollToElement(sectionLink);
				waitAndVerifyElement(sectionLink);
			}
			LoggingInfo("Columns verified");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify coloumns. Error - " + e.getMessage());
			Assert.fail("Failed to verify coloumns. Error - " + e.getMessage());
		}
	}

	/**
	 * Function: To Validate blank field
	 * 
	 * @author Dipali Yadav.
	 */
	public void verifyBlankFieldsText(String fieldXpath, String filedName) {
		try {
			LoggingInfo("Verify blank field Values");
			By fieldLocator = getDynamicElement(fieldXpath, filedName);
			if (isElementDisplayed(fieldLocator)) {
				Assert.assertEquals(getWebDriver().findElement(fieldLocator).getText(), "");

			} else {
				Assert.assertFalse(isElementDisplayed(fieldLocator));
			}

		} catch (Exception e) {

			e.printStackTrace();

			Assert.fail("Failed to verify blank values" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: to create new affiliation in SCA account.
	 * 
	 * @author Uttam Kumar
	 * @throws InterruptedException
	 */
	public void createNewAffiliation(String status, String toAccount, String startDate, String endDate) {
		try {
			Log.info("Creation of Affiliation");
			waitAndVerifyElement(toAccountInputBox);
			selectDropDownValues(constStatus, status);
			searchOptionAndSelectOrClearAndSelectNew("To Account", "Search Accounts...", toAccount);

			By startDateField = getDynamicElement(dateField, "Start Date");
			waitAndVerifyElement(startDateField);
			inputText(startDateField, startDate);
			getWebDriver().findElement(startDateField).sendKeys(Keys.TAB);

			By endDateField = getDynamicElement(dateField, "End Date");
			waitAndVerifyElement(endDateField);
			inputText(endDateField, endDate);
			getWebDriver().findElement(endDateField).sendKeys(Keys.TAB);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to create affiliation" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: verify tooptip value
	 * 
	 * @param field
	 * @author Chaithanya
	 */
	public void verifyTooltipValue(String fieldName, String Value) {
		try {
			LoggingInfo("Verify tooltip Value " + fieldName);
			waitForPageLoaded();
			String eleclearSelection = "//*[text()=\"" + fieldName + "\"]/..//following-sibling::*//button//*";
			Actions actions = new Actions(getWebDriver());
			WebElement toolTip = getWebDriver().findElement(By.xpath(eleclearSelection));
			actions.moveToElement(toolTip).perform();
			By eleRxDoseText = By.xpath(MessageFormat.format(strLightningTextXpath, "Rx/Dose Number"));
			if (isElementDisplayed(eleRxDoseText)) {
				scrollDown("100");
			}
			actions.moveToElement(toolTip).perform();
			actions.click().build().perform();
			boolean after = isElementDisplayed(By.xpath("//*[contains(text(),\"" + Value + "\")]"));
			Assert.assertTrue(after);
			LoggingInfo("Verified tooltip Value " + fieldName);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed Verify tooltip Value " + fieldName + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function:Return the next weekv day
	 *
	 * @param dueDate - Number of days due
	 * @author Chaithanya
	 */
	public static int getNextWeekDay(int dueDate) {
		int nextWeek = dueDate;
		try {
			DateFormat df = new SimpleDateFormat("M/d/yyyy");
			Date dateobj = new Date();
			TimeZone.setDefault(TimeZone.getTimeZone("New_York"));
			format = new SimpleDateFormat("M/d/yyyy");
			String curDate = df.format(dateobj);
			final Date date = format.parse(curDate);
			calendar = Calendar.getInstance();
			calendar.add(Calendar.DAY_OF_YEAR, dueDate);
			int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
			if (dayOfWeek == Calendar.SATURDAY) {
				nextWeek = dueDate + 2;
			} else if (dayOfWeek == Calendar.SUNDAY) {
				nextWeek = dueDate + 1;
			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Selection Failed" + ". Error - " + e.getMessage());
		}
		return nextWeek;
	}

	public void back() {
		getWebDriver().navigate().back();
		setTimeOut(500);
	}

	public void drawBorder(WebElement element) {
		JavascriptExecutor js = ((JavascriptExecutor) getWebDriver());
		js.executeScript("arguments[0].style.border='3px solid red'", element);
	}

	public String copyInputFieldText(By objTextToBecopy) {

		String copiedtext = null;
		try {
			waitAndVerifyElement(objTextToBecopy);
			click(objTextToBecopy);
			setTimeOut(2000);
			WebElement element = getWebDriver().findElement(objTextToBecopy);

			StringSelection stringSelection = new StringSelection("");
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);

			element.sendKeys(Keys.chord(Keys.CONTROL + "a" + "c"));
			copiedtext = (String) Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Copying text of object unsuccessful - " + objTextToBecopy + ". Error - " + e.getMessage());
			Assert.fail("Copying text of object unsuccessful - " + objTextToBecopy + ". Error - " + e.getMessage());
		}
		return copiedtext;
	}

	public String copyDropDownText(By objDropDWNTextToBecopy) {
		String copiedtext = null;
		try {
			waitAndVerifyElement(objDropDWNTextToBecopy);
			WebElement element = getWebDriver().findElement(objDropDWNTextToBecopy);
			setTimeOut(2000);
			element.sendKeys(Keys.chord(Keys.CONTROL + "a" + "c"));
			copiedtext = (String) Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
			Log.info("Dropdown text-" + copiedtext);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error(
					"Copying text of object unsuccessful - " + objDropDWNTextToBecopy + ". Error - " + e.getMessage());
			Assert.fail(
					"Copying text of object unsuccessful - " + objDropDWNTextToBecopy + ". Error - " + e.getMessage());
		}
		return copiedtext;
	}

	// public static void selectItemFromList(By objToSelect, By objSelectListText,
	// String strValueToBeSelected,
	// String excelconstant) {
	// try {
	// if (methodToAvoidStaleElementReferenceErrorElement(objToSelect)) {
	// waitAndVerifyElement(objSelectListText);
	// setTimeOut(1000);
	// List<WebElement> listOptions =
	// getWebDriver().findElements(objSelectListText);
	// WebDriverWait wait = new WebDriverWait(getWebDriver(),
	// Duration.ofSeconds(10));
	//
	// for (int i = 0; i < listOptions.size(); i++) {
	//
	// String selectOption = listOptions.get(i).getText();
	// setTimeOut(1000);
	//
	// if (selectOption.equalsIgnoreCase(strValueToBeSelected)) {
	// wait.until(ExpectedConditions.elementToBeClickable(listOptions.get(i)));
	// listOptions.get(i).click();
	// break;
	// }
	//
	// }
	//
	// Log.info(strValueToBeSelected + " option selected in picklist - " +
	// excelconstant);
	// Assert.assertTrue(true, strValueToBeSelected + " option selected in picklist
	// - " + excelconstant);
	// } else {
	// Log.error("Not able to select " + strValueToBeSelected + " in " +
	// excelconstant);
	// Assert.fail("Not able to select " + strValueToBeSelected + " in " +
	// excelconstant);
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// Log.error("Not able to select " + strValueToBeSelected + " in " +
	// excelconstant + ". " + " Error - "
	// + e.getMessage());
	// Assert.fail("Not able to select " + strValueToBeSelected + " in " +
	// excelconstant + ". " + " Error - "
	// + e.getMessage());
	// }
	// }
	// public static void selectItemFromList(By objToSelect, By objSelectListText,
	// String strValueToBeSelected,
	// String excelconstant) {
	// try {
	// if (methodToAvoidStaleElementReferenceErrorElement(objToSelect)) {
	// waitAndVerifyElement(objSelectListText);
	// setTimeOut(1000);
	// List<WebElement> listOptions =
	// getWebDriver().findElements(objSelectListText);
	// WebDriverWait wait = new WebDriverWait(getWebDriver(),
	// Duration.ofSeconds(10));
	//
	// for (int i = 0; i < listOptions.size(); i++) {
	//
	// String selectOption = listOptions.get(i).getText();
	// setTimeOut(1000);
	//
	// if (selectOption.equalsIgnoreCase(strValueToBeSelected)) {
	// wait.until(ExpectedConditions.elementToBeClickable(listOptions.get(i)));
	// listOptions.get(i).click();
	// break;
	// }
	//
	// }
	//
	// Log.info(strValueToBeSelected + " option selected in picklist - " +
	// excelconstant);
	// Assert.assertTrue(true, strValueToBeSelected + " option selected in picklist
	// - " + excelconstant);
	// } else {
	// Log.error("Not able to select " + strValueToBeSelected + " in " +
	// excelconstant);
	// Assert.fail("Not able to select " + strValueToBeSelected + " in " +
	// excelconstant);
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// Log.error("Not able to select " + strValueToBeSelected + " in " +
	// excelconstant + ". " + " Error - "
	// + e.getMessage());
	// Assert.fail("Not able to select " + strValueToBeSelected + " in " +
	// excelconstant + ". " + " Error - "
	// + e.getMessage());
	// }
	// }

	public String formatPhoneNumber(String phoneNumber) {
		String formattedNumber = null;
		try {
			if (phoneNumber != null && !phoneNumber.isEmpty()) {
				String strippedNumber = phoneNumber.replaceAll("[^\\d]", "");
				// Check if the strippedNumber has at least 10 digits before extracting area
				// code, prefix, and line number
				if (strippedNumber.length() >= 10) {
					String areaCode = strippedNumber.substring(0, 3);
					String prefix = strippedNumber.substring(3, 6);
					String lineNumber = strippedNumber.substring(6);
					formattedNumber = String.format("%s-%s-%s", areaCode, prefix, lineNumber);
				} else {
					// Handle cases where the phone number does not have enough digits
					Log.error("Phone number does not have enough digits: " + phoneNumber);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Phone number is not formatted" + " Error - " + e.getMessage());
		}
		return formattedNumber;
	}

	public void Dropdown(By label, By input, String Exceldata) {
		try {
			waitForPageLoaded();
			waitAndVerifyElement(label);
			String UI_data = copyDropDownText(input);

			System.out.println("method" + UI_data);
			System.out.println("Excel" + Exceldata);
			if (UI_data == null) {
				LoggingInfo(UI_data + "Field is empty");
				Log.info(UI_data + "Fieldis empty");
				inputText(input, Exceldata);

			} else {
				stringEquals(Exceldata, UI_data);
				LoggingInfo("successfully verified" + UI_data);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify data" + e.getMessage());
			Assert.fail("Patient verify data " + e.getMessage());
		}
	}
	
	//new select method for Enrollment form 
	
	public void selectItemFromListNew(By objToSelect, By objSelectListText, String strValueToBeSelected,
	        String excelconstant) {
	    try {
	        if (methodToAvoidStaleElementReferenceErrorElement(objToSelect)) {
	            waitAndVerifyElement(objSelectListText);
 
	            List<WebElement> listOptions = getWebDriver().findElements(objSelectListText);
	            WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(10));
 
	            boolean found = false;
 
	            for (WebElement option : listOptions) {
	                String optionText = option.getText().trim();
 
	                if (optionText.equalsIgnoreCase(strValueToBeSelected)) {
	                    ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].scrollIntoView(true);", option);
 
	                    wait.until(ExpectedConditions.elementToBeClickable(option));
 
	                    try {
	                        option.click();
	                    } catch (ElementClickInterceptedException e) {
	                        Log.info("Standard click failed, trying JavaScript click: " + e.getMessage());
	                        ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", option);
	                    }
 
	                    found = true;
	                    Log.info(strValueToBeSelected + " option selected in picklist - " + excelconstant);
	                    Assert.assertTrue(true, strValueToBeSelected + " option selected in picklist - " + excelconstant);
	                    break;
	                }
	            }
 
	            if (!found) {
	                Log.error("Value '" + strValueToBeSelected + "' not found in list for " + excelconstant);
	                Assert.fail("Value '" + strValueToBeSelected + "' not found in list for " + excelconstant);
	            }
	        } else {
	            Log.error("Dropdown not available for selection in " + excelconstant);
	            Assert.fail("Dropdown not available for selection in " + excelconstant);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        Log.error("Error selecting " + strValueToBeSelected + " in " + excelconstant + ". Error: " + e.getMessage());
	        Assert.fail("Error selecting " + strValueToBeSelected + " in " + excelconstant + ". Error: " + e.getMessage());
	    }
	}  

	public void verifyAndEnterInfoDropDownField(By objTextToBeVerified, By objToSelectList, String textToVerifyAndEnter,
			String excelConstant) {
		try {
			String currentValue = getAttributeValue(objTextToBeVerified, "value");

			if (currentValue == null || !currentValue.trim().equalsIgnoreCase(textToVerifyAndEnter.trim())) {
				// click(objTextToBeVerified);
				waitAndVerifyElement(objToSelectList);
				selectItemFromListNew(objTextToBeVerified, objToSelectList, textToVerifyAndEnter, excelConstant);
			} else {
				Log.info("Value already set to: " + currentValue);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}
	
	/**
	 * Returns a random DOB that is less than 18years from today
	 *
	 * @author Shanavaz Nishani
	 */
	public static String generateDOBUnder18() {
        // Get today's date and calculate the date 18 years ago
        LocalDate today = LocalDate.now();
        LocalDate eighteenYearsAgo = today.minusYears(18);

        // Generate a random date before 18 years ago
        Random random = new Random();
        int year = random.nextInt(18) + 2004;  // Random year between 2004 and 2022 (18 years ago)
        int month = random.nextInt(12) + 1;    // Random month between 1 and 12
        int day = random.nextInt(28) + 1;      // Random day between 1 and 28 (to avoid invalid days)

        // Create the random date
        LocalDate dob = LocalDate.of(year, month, day);

        // Format the date as MM-dd-yyyy
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
        return dob.format(formatter);
    }
	
	public static String changeFormatDateMMddYY(String inputDate) {
		try {

			SimpleDateFormat inputFormat = new SimpleDateFormat("M/dd/yyyy");
			Date date = inputFormat.parse(inputDate);

			SimpleDateFormat outputFormat = new SimpleDateFormat("MM-dd-yy");
			return outputFormat.format(date);

		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	public void selectItemFromDropDownList(By objToSelect, By objSelectListText, String strValueToBeSelected) {
		try {
			if (methodToAvoidStaleElementReferenceErrorElement(objToSelect)) {
				waitAndVerifyElement(objSelectListText);
				setTimeOut(1000);
				List<WebElement> listOptions = getWebDriver().findElements(objSelectListText);
				for (int i = 0; i < listOptions.size(); i++) {

					String selectOption = listOptions.get(i).getText();
					setTimeOut(1000);

					if (selectOption.equalsIgnoreCase(strValueToBeSelected)) {
						listOptions.get(i).click();
						break;
					}

				}

				Log.info(strValueToBeSelected + " option selected in picklist - " + strValueToBeSelected);
				Assert.assertTrue(true,
						strValueToBeSelected + " option selected in picklist - " + strValueToBeSelected);
			} else {
				Log.error("Not able to select " + strValueToBeSelected + " in " + strValueToBeSelected);
				Assert.fail("Not able to select " + strValueToBeSelected + " in " + strValueToBeSelected);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Not able to select " + strValueToBeSelected + " in " + strValueToBeSelected + ". " + " Error - "
					+ e.getMessage());
			Assert.fail("Not able to select " + strValueToBeSelected + " in " + strValueToBeSelected + ". "
					+ " Error - " + e.getMessage());
		}
	}

	public void verifyAndEnterInfoInputField(By objTextToBeVerified, String textToVerifyAndEnter,
			String excelconstant) {
		try {
			String elementtext = getAttributeValue(objTextToBeVerified, "value");

			if (elementtext != null) {
				boolean result = EqualStrings(elementtext, textToVerifyAndEnter);

				if (result) {
					highLightElement(objTextToBeVerified);
					Log.info("Actual text " + textToVerifyAndEnter + " matches with expected text " + elementtext);
				} else {
					Log.info("Actual text in " + excelconstant + " is " + elementtext);
					clearText(objTextToBeVerified);
					inputText(objTextToBeVerified, textToVerifyAndEnter);
					highLightElement(objTextToBeVerified);
					Log.info("Expected text entered in " + excelconstant + " is " + textToVerifyAndEnter);
				}
			} else {
				Log.info("Field is null - " + excelconstant);
				inputText(objTextToBeVerified, textToVerifyAndEnter);
				highLightElement(objTextToBeVerified);
				Log.info("Text entered in " + excelconstant);
			}
		} catch (Exception e) {
			Log.error("Text Verification in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}

	public boolean EqualStrings(String actualText, String expectedText) {
		if (actualText.equalsIgnoreCase(expectedText)) {
			Log.info("Verification Passed: Actual text '" + actualText + "' matches expected text '" + expectedText
					+ "'");
			return true;
		} else {
			Log.info("Verification Failed: Actual text '" + actualText + "' does not match expected text '"
					+ expectedText + "'");
			return false;
		}
	}

	public void clearInputFieldText(By objTextToBeclear) {
		try {
			click(objTextToBeclear);
			setTimeOut(1000);
			WebElement element = getWebDriver().findElement(objTextToBeclear);
			new Actions(getWebDriver()).click(element).keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL)
					.sendKeys(Keys.DELETE).perform();
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Clearing text of object unsuccessful - " + objTextToBeclear + ". Error - " + e.getMessage());
			Assert.fail("Clearing text of object unsuccessful - " + objTextToBeclear + ". Error - " + e.getMessage());
		}
	}

	public boolean stringEquals(String actualText, String expectedText) {
		if (actualText.equalsIgnoreCase(expectedText)) {
			Log.info("Verification Passed: Actual text '" + actualText + "' matches expected text '" + expectedText
					+ "'");
			return true;
		} else {
			Log.info("Verification Failed: Actual text '" + actualText + "' does not match expected text '"
					+ expectedText + "'");
			return false;
		}
	}

	/**
	 * Function: Verification of Mandatory Calendar Date Field
	 * 
	 * @param Input field Box element, Text to verify(Excel test data), Excel Test
	 *              constant(Field Name)
	 * @author Samarth Sahu
	 */
	public void verifyHardAssertCalendarDate(By objTextToBeVerified, String textToVerify, String excelConstant) {
		try {

			String elementText = getAttributeValue(objTextToBeVerified, "value");
			if (elementText.equals("") || elementText == null || elementText.isEmpty() || elementText.isBlank()) {
				if (textToVerify.isEmpty()) {
					Log.info(excelConstant + " Field Verification Passed: Actual data '" + elementText
							+ "' matches expected data '" + textToVerify + "'");
					Assert.assertTrue(true);
				} else {
					LoggingInfo("Field is null - " + excelConstant);
					Assert.fail("Field is null - " + excelConstant);
				}
			} else {
				boolean result = stringEquals(elementText, textToVerify);
				if (result) {
					LoggingInfo(excelConstant + " Field Verification Passed: Actual data '" + elementText
							+ "' matches expected data '" + textToVerify + "'");
					Assert.assertTrue(result);
				} else {
					LoggingInfo(excelConstant + " Field Verification Failed: Actual data '" + elementText
							+ "' does not match expected data '" + textToVerify + "'");
					Assert.fail(excelConstant + " Field Verification Failed");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}

	public void verifySoftAssertCalendarDate(By objTextToBeVerified, String textToVerify, String excelConstant) {
		try {

			String elementText = getAttributeValue(objTextToBeVerified, "value");
			SoftAssert softAssert = new SoftAssert();
			if (elementText == null || elementText.isEmpty() || elementText.isBlank()) {
				if (textToVerify.isEmpty()) {
					LoggingInfo(excelConstant + " Field Verification Passed: Actual data '" + elementText
							+ "' matches expected data '" + textToVerify + "'");
					softAssert.assertTrue(true);
				} else {
					LoggingInfo("Field is null - " + excelConstant);
					softAssert.fail("Field is null - " + excelConstant);
				}
			} else {
				boolean result = stringEquals(elementText, textToVerify);
				if (result) {
					LoggingInfo(excelConstant + " Field Verification Passed: Actual data '" + elementText
							+ "' matches expected data '" + textToVerify + "'");
					softAssert.assertTrue(result);
				} else {
					LoggingInfo(excelConstant + " Field Verification Failed: Actual data '" + elementText
							+ "' does not match expected data '" + textToVerify + "'");
					softAssert.fail(excelConstant + " Field Verification Failed: Actual data '" + elementText
							+ "' does not match expected data '" + textToVerify + "'");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}

	public void verifyAndEnterInfoDropDownField(By objTextToBeVerified, String textToVerifyAndEnter,
			String excelConstant) {
		click(objTextToBeVerified);
		String elementtext = getAttributeValue(objTextToBeVerified, "value");

		try {
			if (elementtext != null) {
				boolean result = stringEquals(elementtext, textToVerifyAndEnter);
				if (result == false) {
					LoggingInfo("Data is wrong");
				}
				Log.info("Text Verification Completed");
			}
			if (elementtext == "-- Clear --") {
				LoggingInfo("Field is null");
				Assert.fail("Field is null");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Verification of NON-Mandatory Input Box Field
	 *
	 * @param Input field Box element, Text to verify(Excel test data), Excel Test
	 *              constant(Field Name)
	 * @author Trupti Zure
	 * @throws InterruptedException
	 */

	public void verifySoftAssertInputFieldBox(By objTextToBeVerified, String textToVerify, String excelConstant)
			throws InterruptedException {

		scrollToElement(objTextToBeVerified);
		click(objTextToBeVerified);
		String elementText = getAttributeValue(objTextToBeVerified, "value");
		SoftAssert softAssert = new SoftAssert();
		try {
			if (textToVerify != null) {
				if (elementText.equals("") || elementText == null || elementText.isEmpty()
						|| elementText.equals("__________") || elementText.equals("(___) ___-____")) {
					if (textToVerify.isEmpty()) {
						LoggingInfo(excelConstant
								+ " Field Verification Passed: Actual data is null, Expected data is empty");
						softAssert.assertTrue(true);
					} else {
						softAssert.fail("Field is null - " + excelConstant);
					}
				} else {
					boolean result = stringEquals(elementText, textToVerify);
					if (result) {
						LoggingInfo(excelConstant + " Field Verification Passed: Actual data '" + elementText
								+ "' matches expected data '" + textToVerify + "'");
						softAssert.assertTrue(result);
					} else {
						LoggingInfo(excelConstant + " Field Verification Failed: Actual data '" + elementText
								+ "' does not match expected data '" + textToVerify + "'");
						softAssert.fail(excelConstant + " Field Verification Failed: Actual data '" + elementText
								+ "' does not match expected data '" + textToVerify + "'");
					}
				}
			} else {
				LoggingInfo("Field is null - " + excelConstant);
				LoggingInfo(excelConstant + " Field Verification Passed: Actual data is null, Expected data is null");
				softAssert.assertTrue(true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Verification of List Item in Mandatory Search Bar DropDown
	 *
	 * @param Search Bar dropdown element,List Items, Text to verify(Excel test
	 *               data), Excel Test constant(Field Name)
	 * @author Trupti Zure
	 */

	public void verifyHardAssertSearchBarDropDown(By objToBeVerified, By objListItems, String textToVerify,
			String excelconstant) {
		String highlightStyle = "background-color: yellow; border: 3px solid red;";
		try {
			waitAndVerifyElement(objToBeVerified);
			setTimeOut(1000);
			List<WebElement> listOptions = getWebDriver().findElements(objListItems);
			boolean found = false;
			for (int i = 0; i < listOptions.size(); i++) {
				String selectOption = listOptions.get(i).getText();
				setTimeOut(1000);

				if (selectOption.equalsIgnoreCase(textToVerify)) {
					JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
					WebElement element = listOptions.get(i);
					js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, highlightStyle);
					setTimeOut(1000);
					LoggingInfo(excelconstant + " Field Verification Passed: Option '" + textToVerify + "' present in "
							+ excelconstant);
					Assert.assertTrue(true, "Data verified successfully");
					element.click();
					found = true;
					break;
				}
			}

			if (!found) {
				LoggingInfo(excelconstant + " Field Verification Failed: Option '" + textToVerify + "' not present in "
						+ excelconstant);
				Assert.fail(excelconstant + "-Data verification Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification failed in - " + objToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification failed in - " + objToBeVerified + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Verification of List Item in Non Mandatory Search Bar DropDown
	 *
	 * @param Search Bar dropdown element,List Items, Text to verify(Excel test
	 *               data), Excel Test constant(Field Name)
	 * @author Trupti Zure
	 */

	public void verifySoftAssertSearchBarDropDown(By objToBeVerified, By objListItems, String textToVerify,
			String excelconstant) {
		String highlightStyle = "background-color: yellow; border: 3px solid red;";
		SoftAssert softAssert = new SoftAssert();
		try {
			waitAndVerifyElement(objToBeVerified);
			setTimeOut(1000);
			List<WebElement> listOptions = getWebDriver().findElements(objListItems);
			boolean found = false;
			for (int i = 0; i < listOptions.size(); i++) {
				String selectOption = listOptions.get(i).getText();
				setTimeOut(1000);

				if (selectOption.equalsIgnoreCase(textToVerify)) {
					JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
					WebElement element = listOptions.get(i);
					js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, highlightStyle);
					setTimeOut(1000);
					LoggingInfo(excelconstant + " Field Verification Passed:" + textToVerify + "' present in "
							+ excelconstant);
					softAssert.assertTrue(true, "Data verified successfully");
					element.click();
					found = true;
					break;
				}
			}

			if (!found) {
				LoggingInfo(excelconstant + " Field Verification Failed: Option '" + textToVerify + "' not present in "
						+ excelconstant);
				softAssert.fail(excelconstant + "-Data verification Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification failed in - " + objToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification failed in - " + objToBeVerified + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Verification of List Item in Mandatory DropDown
	 *
	 * @param Search Bar dropdown element,List Items, Text to verify(Excel test
	 *               data), Excel Test constant(Field Name)
	 * @author Trupti Zure
	 */
	public void verifyHardAssertDropDown(By objTextToBeVerified, String textToVerify, String excelConstant) {

		String elementText = getAttributeValue(objTextToBeVerified, "value");
		try {
			if (elementText.equals("") || elementText == null || elementText.isEmpty() || elementText.isBlank()
					|| elementText.equalsIgnoreCase("-- Clear --")) {
				if (textToVerify.isEmpty()) {
					LoggingInfo(excelConstant + " Field Verification Passed: Actual data '" + elementText
							+ "' matches expected data '" + textToVerify + "'");
					Assert.assertTrue(true);
				} else {
					LoggingInfo("Field is null - " + excelConstant);
					Assert.fail("Field is null - " + excelConstant);
				}
			} else {
				boolean result = stringEquals(elementText, textToVerify);
				if (result) {
					LoggingInfo(excelConstant + " Field Verification Passed: Actual data '" + elementText
							+ "' matches expected data '" + textToVerify + "'");
					Assert.assertTrue(result);
				} else {
					LoggingInfo(excelConstant + " Field Verification Failed: Actual data '" + elementText
							+ "' does not match expected data '" + textToVerify + "'");
					Assert.fail(excelConstant + " Field Verification Failed: Actual data '" + elementText
							+ "' does not match expected data '" + textToVerify + "'");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Verification of List Item in Non Mandatory DropDown
	 *
	 * @param Dropdown element, Text to verify(Excel test data), Excel Test
	 *                 constant(Field Name)
	 * @author Trupti Zure
	 */

	public void verifySoftAssertDropDown(By objTextToBeVerified, String textToVerify, String excelConstant) {

		String elementText = getAttributeValue(objTextToBeVerified, "value");
		SoftAssert softAssert = new SoftAssert();
		try {
			if (elementText.equals("") || elementText == null || elementText.isEmpty() || elementText.isBlank()
					|| elementText.equalsIgnoreCase("-- Clear --")) {
				if (textToVerify.isEmpty()) {
					LoggingInfo(excelConstant + " Field Verification Passed: Actual data '" + elementText
							+ "' matches expected data '" + textToVerify + "'");
					softAssert.assertTrue(true);
				} else {
					LoggingInfo("Field is null - " + excelConstant);
					softAssert.fail("Field is null - " + excelConstant);
				}
			} else {
				boolean result = stringEquals(elementText, textToVerify);
				if (result) {
					LoggingInfo(excelConstant + " Field Verification Passed: Actual data '" + elementText
							+ "' matches expected data '" + textToVerify + "'");
					softAssert.assertTrue(result);
				} else {
					LoggingInfo(excelConstant + " Field Verification Failed: Actual data '" + elementText
							+ "' does not match expected data '" + textToVerify + "'");
					softAssert.fail(excelConstant + " Field Verification Failed: Actual data '" + elementText
							+ "' does not match expected data '" + textToVerify + "'");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Verification of Mandatory Input Box Field
	 *
	 * @param Input field Box element, Text to verify(Excel test data), Excel Test
	 *              constant(Field Name)
	 * @author Trupti Zure
	 */

	public void verifyHardAssertInputFieldBox(By objTextToBeVerified, String textToVerify, String excelConstant) {
		click(objTextToBeVerified);
		String elementText = getAttributeValue(objTextToBeVerified, "value");

		try {
			if (textToVerify != null) {
				if (elementText.equals("") || elementText == null || elementText.isEmpty()
						|| elementText.equals("__________") || elementText.equals("(___) ___-____")) {
					if (textToVerify.isEmpty()) {
						LoggingInfo(excelConstant
								+ " Field Verification Passed: Actual data is null, Expected data is empty");
						Assert.assertTrue(true);
					} else {
						Assert.fail("Field is null - " + excelConstant);
					}
				} else {
					boolean result = stringEquals(elementText, textToVerify);
					if (result) {
						LoggingInfo(excelConstant + " Field Verification Passed: Actual data '" + elementText
								+ "' matches expected data '" + textToVerify + "'");
						Assert.assertTrue(result);
					} else {
						LoggingInfo(excelConstant + " Field Verification Failed: Actual data '" + elementText
								+ "' does not match expected data '" + textToVerify + "'");
						Assert.fail(excelConstant + " Field Verification Failed: Actual data '" + elementText
								+ "' does not match expected data '" + textToVerify + "'");
					}
				}
			} else {
				LoggingInfo("Field is null - " + excelConstant);
				LoggingInfo(excelConstant + " Field Verification Passed: Actual data is null, Expected data is null");
				Assert.assertTrue(true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}

	public void verifyDetails(By locator, String expectedValue, String field) {
		try {
			String actualValue = getText(locator);
			System.out.println(actualValue + " " + field);
			if (actualValue.equalsIgnoreCase(expectedValue)) {
				String successMessage = field + " - Field verified successfully: " + expectedValue;
				Assert.assertTrue(true, successMessage);
				Log.info(successMessage);
				LoggingInfo(successMessage);
			} else {
				String errorMessage = "Failed to verify " + field + " field. Expected: " + expectedValue + ", Actual: "
						+ actualValue;
				Assert.fail(errorMessage);
				Log.info(errorMessage);
			}
		} catch (Exception e) {
			String exceptionMessage = "Exception occurred while verifying " + field + " field: " + e.getMessage();
			Log.error(exceptionMessage);
			Assert.fail(exceptionMessage);
		}
	}

	public static boolean isElementPresent(By objToCheck) {
		try {
			// Check if the element is displayed
			// waitAndVerifyElement(objToCheck);
			setTimeOut(5000);

			boolean isDisplayed = getWebDriver().findElement(objToCheck).isDisplayed();
			Log.info("Element is present - " + objToCheck);
			return isDisplayed;
		} catch (NoSuchElementException | StaleElementReferenceException e) {
			// Log the exception and return false if the element is not present
			Log.error("Element not present - " + objToCheck + " Error - " + e.getMessage());
			return false;
		}
	}

	public static String changeDateFormat(String inputDate) {
		try {

			SimpleDateFormat inputFormat = new SimpleDateFormat("mm-dd-yyyy");
			Date date = inputFormat.parse(inputDate);

			SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-mm-dd");
			return outputFormat.format(date);

		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String changeFormatDate(String inputDate) {
		try {

			SimpleDateFormat inputFormat = new SimpleDateFormat("M/dd/yyyy");
			Date date = inputFormat.parse(inputDate);

			SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-M-dd");
			return outputFormat.format(date);

		} catch (ParseException e) {
			e.printStackTrace();
			return null; // Handle parse exception
		}
	}

	public static String changeFormatDate2(String inputDate) {
		try {

			SimpleDateFormat inputFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date date = inputFormat.parse(inputDate);

			SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
			return outputFormat.format(date);

		} catch (ParseException e) {
			e.printStackTrace();
			return null; // Handle parse exception
		}
	}

	public void highLightElement(By objToHighLight) {
		try {
			JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
			WebElement element = getWebDriver().findElement(objToHighLight);
			String originalStyle = element.getAttribute("style");
			String highlightStyle = "background-color: yellow; border: 2px solid red;";
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, highlightStyle);
			setTimeOut(300);
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, originalStyle);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to highlight");
			Assert.fail("Failed to highlight");
		}

	}

	public String getWindowTitle() {
		String windowTitle = null;
		try {
			windowTitle = getWebDriver().getTitle();
			Log.info("Get title operation successful-" + windowTitle);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get Title of window" + "Error - " + e.getMessage());
			Assert.fail("Failed to get Title of window" + "Error - " + e.getMessage());
		}
		return windowTitle;
	}

	public void verifyOCRstatus(By ocrLocator, String orcStatus) throws InterruptedException {
		Wait<WebDriver> wait = new FluentWait<WebDriver>(getWebDriver()).withTimeout(Duration.ofSeconds(10))
				.pollingEvery(Duration.ofSeconds(5)).ignoring(NoSuchElementException.class);

		if (orcStatus.equalsIgnoreCase("Draft")) {
			try {
				scrollToElement(ocrLocator);
				wait.until(ExpectedConditions.textToBePresentInElementLocated(ocrLocator, "Draft"));
				Log.info("Draft status found.");
				LoggingInfo("OCR Draft Status verified");
			} catch (Exception e) {
				Log.info("Draft status not found.");
			}
		}

		boolean successFound = false;
		for (int i = 0; i < 3; i++) {
			setTimeOut(2000);
			refresh();

			try {
				scrollToElement(ocrLocator);
				if (wait.until(ExpectedConditions.textToBePresentInElementLocated(ocrLocator, "Success"))) {
					Log.info("Success status found.");
					LoggingInfo("OCR Success Status verified");
					successFound = true;
					return;
				}
			} catch (Exception e) {
				Log.info("Success status not found on attempt " + (i + 1));
			}

			try {
				scrollToElement(ocrLocator);
				wait.until(ExpectedConditions.textToBePresentInElementLocated(ocrLocator, "OCR In Progress"));
				Log.info("OCR In Progress status found.");
				LoggingInfo("OCR In Progress Status verified");
			} catch (Exception e) {
				Log.info("OCR In Progress status not found on attempt " + (i + 1));
			}
		}

		if (!successFound) {
			for (int i = 0; i < 3; i++) {
				setTimeOut(2000);
				refresh();

				try {
					scrollToElement(ocrLocator);
					if (wait.until(ExpectedConditions.textToBePresentInElementLocated(ocrLocator, "Success"))) {
						Log.info("Success status found on retry.");
						LoggingInfo("OCR Success Status verified on retry");
						return;
					}
				} catch (Exception e) {
					Log.info("Success status not found on retry attempt " + (i + 1));
				}
			}
		}

		try {
			By manualEnrollment = By.xpath(
					"//*[contains(text(),'Manual Enrollment')]/ancestor::span[contains(@class,'slds-radio_button')]");
			WebElement manualEnrollElement = wait
					.until(ExpectedConditions.visibilityOfElementLocated(manualEnrollment));
			scrollToElement(manualEnrollment);
			manualEnrollElement.click();
			LoggingInfo("Clicked on Manual Enrollment.");
		} catch (Exception e) {
			Log.info("Manual Enrollment button not found or not clickable.");
			throw e;
		}
	}

	public static void selectItemFromDropDown(By objToSelect, By objSelectListText, String strValueToBeSelected) {
		try {
			if (methodToAvoidStaleElementReferenceErrorElement(objToSelect)) {
				waitAndVerifyElement(objSelectListText);
				setTimeOut(1000);
				List<WebElement> listOptions = getWebDriver().findElements(objSelectListText);
				WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(10));
				for (int i = 0; i < listOptions.size(); i++) {

					String selectOption = listOptions.get(i).getText();
					setTimeOut(1000);

					if (selectOption.equalsIgnoreCase(strValueToBeSelected)) {
						listOptions.get(i).click();
						break;
					}

				}

				Log.info(strValueToBeSelected + " option selected in picklist - " + strValueToBeSelected);
				Assert.assertTrue(true,
						strValueToBeSelected + " option selected in picklist - " + strValueToBeSelected);
			} else {
				Log.error("Not able to select " + strValueToBeSelected + " in " + strValueToBeSelected);
				Assert.fail("Not able to select " + strValueToBeSelected + " in " + strValueToBeSelected);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Not able to select " + strValueToBeSelected + " in " + strValueToBeSelected + ". " + " Error - "
					+ e.getMessage());
			Assert.fail("Not able to select " + strValueToBeSelected + " in " + strValueToBeSelected + ". "
					+ " Error - " + e.getMessage());
		}
	}
	
	public void closeTabs() {
		try {
			int maxAttempts = 10; // Maximum number of attempts to close tabs

			for (int attempt = 1; attempt <= maxAttempts; attempt++) {
				try {
					List<WebElement> tabs = getWebDriver().findElements(eleCloseTabButton);

					// If no tabs are found, exit the loop
					if (tabs.isEmpty()) {
						break;
					}

					for (WebElement tab : tabs) {
						setTimeOut(1000);

						// Check if the tab is enabled (visible and clickable) before clicking
						if (tab.isEnabled()) {
							setTimeOut(1000);
							tab.click();
						} else {
							LoggingInfo("Close button is hidden, trying another one ...");
						}
					}
				} catch (StaleElementReferenceException e) {
					LoggingInfo("Stale element reference exception occurred, retrying...");
				} catch (NoSuchElementException e) {
					LoggingInfo("Close button element not found, retrying...");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to close the tabs");
			Assert.fail("Failed to close the tabs ");
		}
	}

	public String receivedDocumentId() {
		String recievedDocID = null;
		try {
			String currentURL = getWebDriver().getCurrentUrl();
			String array[] = currentURL.split("ReceivedDocument/");
			String nextArr[] = array[1].split("/");
			recievedDocID = nextArr[0];
			LoggingInfo("Successfully retrieved Salesforce ID from URL: " + recievedDocID);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to retrieved Salesforce ID from URL");
			Assert.fail("Failed to retrieved Salesforce ID from URL");

		}
		return recievedDocID;
	}

	public String getFileName(String FilePath) {
		String fileName = null;
		try {
			File file = new File(FilePath);
			fileName = file.getName();
			Log.info("File Name returned" + fileName);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to return file Name" + "Error - " + e.getMessage());
			Assert.fail("Failed to return file Name" + "Error - " + e.getMessage());

		}
		return fileName;
	}

	public void verifyAndEnterDataInputField(By objTextToBeVerified, String textToVerifyAndEnter,
			String excelConstant) {
		String elementText = getAttributeValue(objTextToBeVerified, "value");
		try {
			if (elementText == null || elementText.isEmpty() || elementText.isBlank()) {
				Log.info("Field is null - " + excelConstant);
				if (textToVerifyAndEnter != null && !textToVerifyAndEnter.isEmpty()) {
					inputText(objTextToBeVerified, textToVerifyAndEnter);
					setTimeOut(2000);
					Log.info("Text entered in " + excelConstant + ": " + textToVerifyAndEnter);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}

	public void verifyEmptyInputFieldBox(By objTextToBeVerified, String textToVerify, String excelconstant) {
		String elementText = getAttributeValue(objTextToBeVerified, "value");
		try {
			if (elementText == "" || elementText.isEmpty()) {
				LoggingInfo("Field is null- " + excelconstant);
				boolean result = stringEquals(elementText, textToVerify);
				if (result == true) {
					LoggingInfo(excelconstant + " Field Verification Passed: Actual data is null "
							+ "Expected data is null");
					Assert.assertTrue(result);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}

	public String[] splitFullName(String name) {
		String firstName = null;
		String middleName = null;
		String lastName = null;
		try {
			String fullName = name.trim(); // Trim to remove leading and trailing whitespaces
			String[] parts = fullName.split("\\s+");

			firstName = parts[0];
			lastName = parts[parts.length - 1];
			middleName = "";

			// If there's a middle name, combine all parts between first and last names
			if (parts.length > 2) {
				StringBuilder middleNameBuilder = new StringBuilder();
				for (int i = 1; i < parts.length - 1; i++) {
					middleNameBuilder.append(parts[i]);
					if (i < parts.length - 2) {
						middleNameBuilder.append(" ");
					}
				}
				middleName = middleNameBuilder.toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Faild to split name" + ". Error - " + e.getMessage());
			Assert.fail("Faild to split name" + ". Error - " + e.getMessage());
		}

		// Return an array containing first name, middle name (if any), and last name
		return new String[] { firstName, middleName, lastName };
	}

	public String[] splitDate(String date) {
		String day = null;
		String month = null;
		String year = null;
		try {
			if (date != null) {
				// Split the date string using the "-" delimiter
				String[] dateComponents = date.split("-");

				if (dateComponents.length < 3) {
					throw new IllegalArgumentException("Invalid date format: " + date);
				}

				// Extract day, month, and year
				day = dateComponents[0];
				month = dateComponents[1];
				year = dateComponents[2];
			} else {
				throw new IllegalArgumentException("Date is null");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to split date: " + e.getMessage());
			Assert.fail("Failed to split date: " + e.getMessage());
		}

		return new String[] { day, month, year };
	}

	public void setFieldValues(PdfAcroForm form, List<String> fieldNames, String[] values) {
		for (int i = 0; i < values.length; i++) {
			form.getField(fieldNames.get(i)).setValue(values[i]);

		}
	}

	public String[] splitPhoneNumber(String phoneNumber) {
		// Split the phone number string using the "-" delimiter
		String[] phoneComponents = phoneNumber.split("-");

		// Check if the array has enough components
		if (phoneComponents.length != 3) {
			throw new IllegalArgumentException("Invalid phone number format: " + phoneNumber);
		}

		return phoneComponents;
	}

	public void setCheckBoxValues(PdfAcroForm form, List<String> fieldNames, List<String> values) {
		for (int i = 0; i < values.size(); i++) {
			PdfFormField checkField = form.getField(fieldNames.get(i));
			checkField.setCheckType(CheckBoxType.CHECK);
			checkField.setValue(fieldNames.get(i), true);
		}
	}

	public void setCheckBoxValue(PdfAcroForm form, String fieldName) {
		try {
			if (fieldName != null) {
				PdfFormField field = form.getField(fieldName);
				if (field != null) {
					field.setCheckType(CheckBoxType.CHECK);
					field.setValue(fieldName, true);
				} else {
					Log.info("Checkbox field not found: " + fieldName);
				}
			} else {
				Log.info("Checkbox field name is null");
			}
		} catch (Exception e) {
			Log.info("Failed to set checkbox value for field: " + fieldName + " - " + e.getMessage());
		}
	}

	public void setFieldValue(PdfAcroForm form, String fieldName, String value) {
		form.getField(fieldName).setValue(value);
	}

	public void VerifySaveLater() {
		try {
			By Headerpath = By.xpath("//*[@title='iCare Connect']");
			By SaveLaterBtn = By.xpath("(//*[text()='Save for later'])[1]");
			By OkBtn = By.xpath("//*[text()='OK']");
			By VerifyMessage = By.xpath("//*[text()='Your OmniScript is saved for later']");
			By VerifyLink = By.xpath("//*[text()='Your OmniScript is saved for later']/following::a[1]");

			setTimeOut(3000);
			scrollToElement(SaveLaterBtn);
			setTimeOut(2000);
			click(SaveLaterBtn);
			LoggingInfo("Click on Save Button");
			waitAndVerifyElement(OkBtn);
			click(OkBtn);
			LoggingInfo("Click on Ok Button");
			waitAndVerifyElement(VerifyMessage);
			scrollToElement(VerifyMessage);
			LoggingInfo("Verfiy Message" + VerifyMessage);
			waitAndVerifyElement(VerifyLink);
			LoggingInfo("Verify Link");
			clickByJavascript(VerifyLink);
			LoggingInfo("Click on Link");
			setTimeOut(10000);

			getWebDriver().close();
			Set<String> Browsercount = getWebDriver().getWindowHandles();
			for (String count : Browsercount) {
				getWebDriver().switchTo().window(count);
			}
			waitAndVerifyElement(Headerpath);
			clickByJavascript(Headerpath);
			LoggingInfo("Click on Header iCare Connect");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to save-" + "Error - " + e.getMessage());
		}
	}

	public String formatDatemddyyyy(String inputDateStr) {
		String outputDateFormat = "M/dd/yyyy";

		try {
			SimpleDateFormat inputDateFormat = new SimpleDateFormat("MM-dd-yyyy");
			Date inputDate = inputDateFormat.parse(inputDateStr);

			// Format output date
			SimpleDateFormat outputDateFormatObj = new SimpleDateFormat(outputDateFormat);
			return outputDateFormatObj.format(inputDate);
		} catch (ParseException e) {
			Log.error("Error occurred while parsing the date: " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	public String formatDatemmdyyyy(String inputDateStr) {
		String outputDateFormat = "yyyy-mm-dd";

		try {
			SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-mm-dd");
			Date inputDate = inputDateFormat.parse(inputDateStr);

			// Format output date
			SimpleDateFormat outputDateFormatObj = new SimpleDateFormat(outputDateFormat);
			return outputDateFormatObj.format(inputDate);
		} catch (ParseException e) {
			Log.error("Error occurred while parsing the date: " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	public String formatAddress(String inputAddress) {
		String formattedAddress = null;
		try {
			// Replace line breaks with spaces
			formattedAddress = inputAddress.replaceAll("\\r?\\n", " ");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to format adddress-" + "Error - " + e.getMessage());
		}

		return formattedAddress;
	}

	public void verifyField(String fieldName, String actualValue, String expectedValue) {
		if (actualValue.equalsIgnoreCase(expectedValue)) {
			Log.info(fieldName + " - Field verified successfully: " + actualValue);
			LoggingInfo(
					fieldName + " - Field verified successfully: " + actualValue + " matches with " + expectedValue);
			Assert.assertTrue(true, fieldName + " - Field verified successfully");
		} else {
			Log.info("Failed to verify field: " + fieldName);
			LoggingInfo(fieldName + " - Field verification failed: " + actualValue + " does not match with "
					+ expectedValue);
			Assert.fail("Failed to verify field: " + fieldName);
		}
	}

	public static boolean verifytable(String tableName) {

		String eleRowXPath = String
				.format("//*[contains(@class,'active lafPageHost')]//table[@aria-label='%s']//tbody//tr", tableName);
		By tableRowLocator = By.xpath(eleRowXPath);

		try {
			int rowCount = getWebDriver().findElements(tableRowLocator).size();
			if (rowCount != 0) {
				Log.info("Table contains data.");
				return true;
			} else {
				Log.info("Table is empty.");
				return false;
			}
		} catch (NoSuchElementException e) {
			Log.error("Table '" + tableName + "' could not be found. Error - " + e.getMessage());
			Assert.fail("Table '" + tableName + "' could not be found. Error - " + e.getMessage());
			return false;
		} catch (Exception e) {
			Log.error("Failed to check table data. Error - " + e.getMessage());
			Assert.fail("Failed to check table data. Error - " + e.getMessage());
			return false;
		}
	}

	public static List<List<String>> getTableData(String tableName) {
		List<List<String>> tableData = new ArrayList<>();
		String eleRow = "//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"{0}\"]//tbody//tr";
		By tableEleRow = getDynamicElement(eleRow, tableName);

		String cellData = "//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"{0}\"]//tbody//tr//td//a";
		By tableCellData = getDynamicElement(cellData, tableName);

		try {
			List<WebElement> rows = getWebDriver().findElements(tableEleRow);
			for (WebElement row : rows) {
				List<WebElement> cells = row.findElements(tableCellData);
				List<String> rowData = new ArrayList<>();
				for (WebElement cell : cells) {
					// Extract text from the cell
					String cellText = cell.getAttribute("title");

					// Append the extracted text to rowData
					rowData.add(cellText);
				}
				tableData.add(rowData);
			}
		} catch (Exception e) {
			Log.error("Failed to get table data. Error - " + e.getMessage());
			Assert.fail("Failed to get table data. Error - " + e.getMessage());
		}
		return tableData;
	}

	public static ArrayList<String> getAllTableData(String tableName, String... headers) {
		ArrayList<String> allData = new ArrayList<>();
		try {
			String tableRows = "//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"" + tableName
					+ "\"]//tbody//tr";
			By eleTableRows = getDynamicElement(tableRows, tableName);
			waitAndVerifyElement(eleTableRows);

			List<WebElement> rows = getWebDriver().findElements(eleTableRows);

			for (WebElement row : rows) {
				StringBuilder rowData = new StringBuilder();
				for (String header : headers) {
					List<WebElement> headerList = getWebDriver()
							.findElements(By.xpath("//*[contains(@class,'active lafPageHost')]//table[@aria-label='"
									+ tableName + "']//tr[@data-row-key-value=\"HEADER\"]//th"));

					boolean flag = false;
					int columnIndex = -1;
					for (int i = 0; i < headerList.size(); i++) {
						WebElement colHeader = headerList.get(i);
						String headerName = colHeader.getAttribute("aria-label");
						if (headerName.equalsIgnoreCase(header)) {
							columnIndex = i + 1;
							break;
						}
					}
					if (columnIndex == -1) {
						System.out.println("Column header '" + header + "' not found.");
						continue;
					}

					try {
						String value;
						if (columnIndex == 1) {
							WebElement cellElement = row.findElement(
									By.xpath(".//th[" + columnIndex + "]//span[@class=\"slds-truncate\"]//slot"));
							value = cellElement.getText().trim();
						} else {
							try {
								WebElement cellElement = row.findElement(
										By.xpath("//*[contains(@class,\"active lafPageHost\")]//table[@aria-label='"
												+ tableName + "']//tbody//tr//td[" + (columnIndex - 1) + "]//a"));
								value = cellElement.getAttribute("title").trim();
								flag = true;

							} catch (NoSuchElementException e) {
								WebElement cellElement = row.findElement(By.xpath(".//td[" + (columnIndex - 1) + "]"));
								value = cellElement.getText().trim();
								flag = true;

							}
						}
						rowData.append(value).append(", ");
					} catch (NoSuchElementException e) {
						rowData.append(", "); // Add empty string if cell not found
					}
				}
				// Remove the extra comma and space at the end of the row data
				if (rowData.length() > 0) {
					rowData.setLength(rowData.length() - 2);
				}
				allData.add(rowData.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return allData;
	}

	public boolean compareArrayLists(ArrayList<String> list1, ArrayList<String> list2) {

		if (list1.size() != list2.size()) {
			return false;
		}

		Collections.sort(list1);
		Collections.sort(list2);

		return list1.equals(list2);
	}

	public void verifySoftAssertCheckBox(By objTextToBeVerified, String textToVerify, String excelConstant) {

		String elementText = getAttributeValue(objTextToBeVerified, "checked");
		SoftAssert softAssert = new SoftAssert();
		try {
			if ((elementText != null && elementText.equalsIgnoreCase("true") && textToVerify.equalsIgnoreCase("TRUE"))
					|| (elementText == null && textToVerify.equalsIgnoreCase("FALSE"))) {
				LoggingInfo(excelConstant + " Field Verification Passed: Actual data '" + elementText
						+ "' matches expected data '" + textToVerify + "'");
			} else {
				String errorMessage = excelConstant + " Field Verification failed: Actual data '" + elementText
						+ "' does not match expected data '" + textToVerify + "'";
				LoggingInfo(errorMessage);
				softAssert.fail(errorMessage);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}

	public static ArrayList<String> getConsentTableData(String... headers) {
		String value = null;
		ArrayList<String> allData = new ArrayList<>();
		try {
			String tableRows = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"data-table-row tableRow\")]";
			By eleTableRows = getDynamicElement(tableRows);
			waitAndVerifyElement(eleTableRows);

			List<WebElement> rows = getWebDriver().findElements(eleTableRows);

			for (WebElement row : rows) {
				StringBuilder rowData = new StringBuilder();
				List<WebElement> cells = row
						.findElements(By.xpath(".//runtime_omnistudio_common-data-table-cell[@data-field-name]"));
				for (WebElement cell : cells) {
					String fieldName = cell.getAttribute("data-field-name");
					for (String header : headers) {
						if (fieldName != null && fieldName.equalsIgnoreCase(header)
								&& !fieldName.equals("ConsentCapturedDateTime")) {
							value = cell.findElement(By.xpath(".//span[@class=\"field-value\"]")).getText().trim();
							rowData.append(value).append(", ");
						}
					}
					// Check if the fieldName matches "ConsentCapturedDateTime"
					if (fieldName != null && fieldName.equals("ConsentCapturedDateTime")) {
						String dateTimeValue = cell.findElement(By.xpath(".//span[@class=\"field-value\"]")).getText()
								.trim();
						String dateValue = dateTimeValue.split(" ")[0];
						if (!rowData.toString().contains(dateValue)) {
							rowData.append(dateValue).append(", ");
						}
					}
				}
				// Remove the extra comma and space at the end of the row data
				if (rowData.length() > 0) {
					rowData.setLength(rowData.length() - 2);
				}
				allData.add(rowData.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return allData;
	}

	public void verifyHardAssertReadOnlyField(By objTextToBeVerified, String integrationFieldName) {

		String elementText = getAttributeValue(objTextToBeVerified, "aria-readonly");

		try {
			if (elementText.equals("true")) {
				LoggingInfo("Verified Read only state for " + integrationFieldName);
			} else {
				Log.error("Failed to verify Read only state for " + integrationFieldName);
				Assert.fail("Failed to verify Read only state for " + integrationFieldName);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error(
					"Read only state Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail(
					"Read only state Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}

	public void verifyHardAssertForDisabledInputFieldBox(By objTextToBeVerified, String textToVerify,
			String excelConstant) {
		String elementText = getAttributeValue(objTextToBeVerified, "value");

		try {
			if (textToVerify != null) {
				if (elementText == null || elementText.isEmpty() || elementText.equals("__________")
						|| elementText.equals("(___) ___-____")) {
					if (textToVerify.isEmpty()) {
						LoggingInfo(excelConstant
								+ " Field Verification Passed: Actual data is null, Expected data is empty");
						Assert.assertTrue(true);
					} else {
						Assert.fail("Field is null - " + excelConstant);
					}
				} else {
					boolean result = elementText.contains(textToVerify);
					// stringEquals(elementText, textToVerify);
					if (result) {
						LoggingInfo(excelConstant + " Field Verification Passed: Actual data '" + elementText
								+ "' matches expected data '" + textToVerify + "'");
						Assert.assertTrue(result);
					} else {
						LoggingInfo(excelConstant + " Field Verification Failed: Actual data '" + elementText
								+ "' does not match expected data '" + textToVerify + "'");
						Assert.fail(excelConstant + " Field Verification Failed: Actual data '" + elementText
								+ "' does not match expected data '" + textToVerify + "'");
					}
				}
			} else {
				LoggingInfo("Field is null - " + excelConstant);
				LoggingInfo(excelConstant + " Field Verification Passed: Actual data is null, Expected data is null");
				Assert.assertTrue(true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}

	public void selectCheckbox(By objCheckboxToBeSelected, String value, String excelConst) {
		try {
			boolean isChecked = isCheckboxChecked(objCheckboxToBeSelected);

			if (value.equalsIgnoreCase("TRUE") && !isChecked) {
				clickByJavascript(objCheckboxToBeSelected);
				Log.info("Checkbox is selected - " + excelConst);
				LoggingInfo("Checkbox is selected - " + excelConst);
			} else if (value.equalsIgnoreCase("FALSE") && isChecked) {
				clickByJavascript(objCheckboxToBeSelected);
				Log.info("Checkbox is unselected - " + excelConst);
				LoggingInfo("Checkbox is unselected - " + excelConst);
			} else {
				if (isChecked) {
					Log.info("Checkbox is already selected - " + excelConst);
					LoggingInfo("Checkbox is already selected - " + excelConst);
				} else {
					Log.info("Checkbox is already unselected - " + excelConst);
					LoggingInfo("Checkbox is already unselected - " + excelConst);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to check/uncheck the checkbox - " + objCheckboxToBeSelected + ". Error - "
					+ e.getMessage());
			Assert.fail("Failed to check/uncheck the checkbox - " + objCheckboxToBeSelected + ". Error - "
					+ e.getMessage());
		}
	}

	public void sendKeysWithRobotClass(String text) {
		try {
			Robot robot = new Robot();
			for (int i = 0; i < text.length(); i++) {
				char c = text.charAt(i);
				int keyCode = KeyEvent.getExtendedKeyCodeForChar(c);
				if (Character.isDigit(c)) {
					robot.keyPress(keyCode);
					robot.keyRelease(keyCode);
					Thread.sleep(50);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void closeTaskLoadingWindowIfVisible() {
		WebElement closeButton = null;
		try {
			closeButton = getWebDriver().findElement(eleCloseButton);
		} catch (org.openqa.selenium.NoSuchElementException
				| org.openqa.selenium.StaleElementReferenceException ignored) {
		}
		if (closeButton != null && closeButton.isDisplayed()) {
			closeButton.click();
		}
	}

	public void verifyAnyFieldIsEnabledOrDisabled(By locator, String field, boolean shouldBeEnabled) {
		try {
			verifyElement(locator); // Verify that the element exists
			scrollToElement(locator);
			if (shouldBeEnabled) {
				LoggingInfo("Verify whether field is enabled-" + field);
				Assert.assertTrue(getWebDriver().findElement(locator).isEnabled(), "Field is enabled as expected");
			} else {
				LoggingInfo("Verify whether field is disabled-" + field);
				String disabledValue = getAttributeValue(locator, "disabled");
				Assert.assertEquals(disabledValue, "true", "Field is disabled as expected");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Assert.fail("Element not found: " + locator + ". Error - " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to check status of field " + locator + ". Error - " + e.getMessage());
		}
	}

	public void verifyFieldIsEnabledOrDisabled(By locator, String field, boolean shouldBeEnabled) {
		try {
			verifyElement(locator); // Verify that the element exists
			scrollToElement(locator);
			if (shouldBeEnabled) {
				LoggingInfo("Verify whether field is enabled-" + field);
				Assert.assertTrue(getWebDriver().findElement(locator).isEnabled(), "Field is enabled as expected");
			} else {
				LoggingInfo("Verify whether field is disabled " + field);
				String disabledValue = getAttributeValue(locator, "readonly");
				Assert.assertEquals(disabledValue, "true", "Field is disabled as expected");
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
			Assert.fail("Element not found: " + locator + ". Error - " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to check status of field " + locator + ". Error - " + e.getMessage());
		}
	}

	public void logData(String message, ArrayList<String> data) {
		System.out.println(message);
		for (String row : data) {
			System.out.println(row);
			System.out.println("len" + row.length());
		}
	}

	public void verifyAndsendKeysWithRobotClass(By objTextToBeVerified, String textToVerifyAndEnter) {
		try {
			String elementText = getAttributeValue(objTextToBeVerified, "value");

			if (elementText != null) {
				boolean result = elementText.equals(textToVerifyAndEnter);

				if (result) {
					highLightElement(objTextToBeVerified);
					LoggingInfo("Actual text matches with expected text: " + elementText);
				} else {
					LoggingInfo("Actual text does not match with expected text: " + elementText);
					scrollToElement(objTextToBeVerified);
					clearText(objTextToBeVerified);
					scrollToElement(objTextToBeVerified);
					click(objTextToBeVerified);
					Robot robot = new Robot();
					for (int i = 0; i < textToVerifyAndEnter.length(); i++) {
						char c = textToVerifyAndEnter.charAt(i);
						int keyCode = KeyEvent.getExtendedKeyCodeForChar(c);
						if (Character.isDigit(c)) {
							robot.keyPress(keyCode);
							robot.keyRelease(keyCode);
							Thread.sleep(50);
						}
					}
					highLightElement(objTextToBeVerified);
					LoggingInfo("Actual text entered: " + elementText);
				}
			} else {

				LoggingInfo("Field is null");
				Robot robot = new Robot();
				click(objTextToBeVerified);
				for (int i = 0; i < textToVerifyAndEnter.length(); i++) {
					char c = textToVerifyAndEnter.charAt(i);
					int keyCode = KeyEvent.getExtendedKeyCodeForChar(c);
					if (Character.isDigit(c)) {
						robot.keyPress(keyCode);
						robot.keyRelease(keyCode);
						Thread.sleep(50);
					}
				}
				highLightElement(objTextToBeVerified);
				LoggingInfo("Text entered");

			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Error in verifyAndsendKeysWithRobotClass: " + e.getMessage());
			Assert.fail("Error in verifyAndsendKeysWithRobotClass: " + e.getMessage());
		}
	}

	public void verifyandSelectCheckBox(By objTextToBeVerified, String textToVerify, String excelConstant) {
		try {
			String elementText = getAttributeValue(objTextToBeVerified, "checked");

			if ((elementText != null && elementText.equalsIgnoreCase("true") && textToVerify.equalsIgnoreCase("TRUE"))
					|| (elementText == null && textToVerify.equalsIgnoreCase("FALSE"))) {
				LoggingInfo(excelConstant + " Field Verification Passed: Actual data '" + elementText
						+ "' matches expected data '" + textToVerify + "'");
			} else if (elementText != null && elementText.equalsIgnoreCase("true")
					&& textToVerify.equalsIgnoreCase("FALSE")) {

				selectCheckbox(objTextToBeVerified, textToVerify, excelConstant);
			} else {
				String errorMessage = excelConstant + " Field Verification failed: Actual data '" + elementText
						+ "' does not match expected data '" + textToVerify + "'";
				LoggingInfo(errorMessage);
				selectCheckbox(objTextToBeVerified, textToVerify, excelConstant);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
			Assert.fail("Text Verification failed in - " + objTextToBeVerified + ". Error - " + e.getMessage());
		}
	}

	public boolean isCheckboxChecked(By checkboxLocator) {
		try {
			WebElement checkbox = getWebDriver().findElement(checkboxLocator);
			String checkedAttr = checkbox.getAttribute("checked");
			return checkedAttr != null && checkedAttr.equalsIgnoreCase("true");
		} catch (NoSuchElementException | StaleElementReferenceException e) {
			Log.error("Checkbox element not found or stale - " + checkboxLocator + ". Error - " + e.getMessage());
			throw e;
		}
	}

	public String changeDateFormatdmyyyy(String inputDate) {
		try {

			SimpleDateFormat inputFormat = new SimpleDateFormat("dd/mm/yyyy");
			Date date = inputFormat.parse(inputDate);

			SimpleDateFormat outputFormat = new SimpleDateFormat("d/m/yyyy");
			return outputFormat.format(date);

		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String getDateNDaysFromToday(int days) {

		String date = null;
		try {

			LocalDate today = LocalDate.now();
			LocalDate futureDate = today.plusDays(days);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
			date = futureDate.format(formatter);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return date;
	}

	public static String getDateNDaysFromTodayFormatted(int days) {

		String date = null;
		try {

			LocalDate today = LocalDate.now();
			LocalDate futureDate = today.plusDays(days);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("YYYY-MM-dd");
			date = futureDate.format(formatter);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return date;
	}

	public static ArrayList<String> getWorkTableData(By eleTableRows, String... headers) {
		String value = null;
		ArrayList<String> allData = new ArrayList<>();
		try {
			waitAndVerifyElement(eleTableRows);

			List<WebElement> rows = getWebDriver().findElements(eleTableRows);

			for (WebElement row : rows) {
				StringBuilder rowData = new StringBuilder();
				List<WebElement> cells = row
						.findElements(By.xpath(".//runtime_omnistudio_common-data-table-cell[@data-field-name]"));
				for (WebElement cell : cells) {
					String fieldName = cell.getAttribute("data-field-name");
					for (String header : headers) {
						if (fieldName != null && fieldName.equalsIgnoreCase(header)) {
							value = cell.findElement(By.xpath(".//span[@class=\"field-value\"]")).getText().trim();
							rowData.append(value).append(", ");
						}
					}
				}
				// Remove the extra comma and space at the end of the row data
				if (rowData.length() > 0) {
					rowData.setLength(rowData.length() - 2);
				}
				allData.add(rowData.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return allData;
	}

	/**
	 * Function: Wait for element to be clickable
	 * 
	 * @author Trupti
	 **/
	public void waitForelementToBeClickable(By locator) {
		try {
			setTimeOut(30);
			WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(30));
			wait.until(ExpectedConditions.elementToBeClickable(locator));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Function: Generate random phone number
	 * 
	 * @author Trupti
	 **/
	public String generatePhoneNumber() {
		String formattedPhoneNumber = null;
		try {
			Random random = new Random();
			StringBuilder phoneNumber = new StringBuilder();
			phoneNumber.append(random.nextInt(9) + 1);
			for (int i = 1; i < 10; i++) {
				phoneNumber.append(random.nextInt(10));
			}
			formattedPhoneNumber = phoneNumber.toString();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return formattedPhoneNumber;
	}

	/**
	 * Function: Generate future date
	 * 
	 * @author Trupti
	 **/

	public static String getNthDayFromToday(int n) {
		String nthDateString = "";
		try {
			LocalDate today = LocalDate.now();
			LocalDate nthDate = today.plusDays(n);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
			nthDateString = nthDate.format(formatter);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return nthDateString;
	}

	public static String getNthDayFromTodayFormat(int n) {
		String nthDateString = "";
		try {
			LocalDate today = LocalDate.now();
			LocalDate nthDate = today.plusDays(n);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
			nthDateString = nthDate.format(formatter);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return nthDateString;
	}

	// Anand P
	public static String getNthDayFromTodayFormatted(int n) {
		String nthDateString = "";
		try {
			LocalDate today = LocalDate.now();
			LocalDate nthDate = today.plusDays(n);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
			nthDateString = nthDate.format(formatter);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return nthDateString;
	}

	/**
	 * Function: Generate 10 digit random number
	 * 
	 * @author Trupti
	 **/
	public static String generateRandom10DigitNumber() {
		String uuidPart = String.valueOf(Math.abs(UUID.randomUUID().toString().hashCode()));

		if (uuidPart.length() < 10) {
			uuidPart = String.format("%010d", Long.parseLong(uuidPart));
		} else if (uuidPart.length() > 10) {
			uuidPart = uuidPart.substring(0, 10);
		}

		return uuidPart;
	}

	/**
	 * Function: Navigate to Dupixent url
	 *
	 * @author Trupti
	 */
	public void navigateToDupxientUrl() {
		try {
			setTimeOut(3000);
			String baseUrl = Configuration.readApplicationFile("DupixentMyWayPortalURL");
			getWebDriver().navigate().to(baseUrl);
			waitForPageLoaded();
			setTimeOut(2000);
		} catch (UnhandledAlertException e) {
			String baseUrl = Configuration.readApplicationFile("DupixentMyWayPortalURL");
			getWebDriver().navigate().to(baseUrl);
			waitForPageLoaded();
			setTimeOut(4000);
			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	/**
	 * Function: Scroll to bottom of page
	 *
	 * @author Trupti
	 */
	public static void scrollToBottomOfPage() {
		JavascriptExecutor jse = (JavascriptExecutor) getWebDriver();
		jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}

	/**
	 * Function: Get nth day from today in yyyy-mm-dd format
	 *
	 * @author Trupti
	 */
	public static String getNthDayFromTodayFormatyyyyMMdd(int n) {
		String nthDateString = "";
		try {
			LocalDate today = LocalDate.now();
			LocalDate nthDate = today.plusDays(n);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			nthDateString = nthDate.format(formatter);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return nthDateString;
	}

	/**
	 * Function: Change date format yyyy-MM-dd format
	 *
	 * @author Trupti
	 */
	public static String changeDateFormatyyyyMMdd(String inputDate) {
		try {

			SimpleDateFormat inputFormat = new SimpleDateFormat("MM-dd-yyyy");
			Date date = inputFormat.parse(inputDate);

			SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
			return outputFormat.format(date);

		} catch (ParseException e) {
			e.printStackTrace();
			return null; // Handle parse exception
		}
	}

	public static String formatNumber(String num) {
		String number = null;
		try {
			number = num.replaceAll("[^\\d]", "");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return number;
	}

	public static String changeFormatDateMMddYYYY(String inputDate) {
		try {

			SimpleDateFormat inputFormat = new SimpleDateFormat("M/dd/yyyy");
			Date date = inputFormat.parse(inputDate);

			SimpleDateFormat outputFormat = new SimpleDateFormat("MM-dd-yyyy");
			return outputFormat.format(date);

		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String removeQueryString(String url) {

		int queryIndex = url.indexOf("?ws=");
		if (queryIndex != -1) {

			return url.substring(0, queryIndex);
		}

		return url;
	}

	public static void scrollToPixel(int x, int y) {
		JavascriptExecutor jse = (JavascriptExecutor) getWebDriver();
		jse.executeScript("window.scrollTo(arguments[0], arguments[1]);", x, y);
	}

	/**
	 * Function: Get InnerText from a field using javascript.
	 *
	 * @author Shanavaz Nishani
	 */
	public String getInnerTextByJavascript(By objToGetText) throws Exception {
		String innerText = null;
		try {
			String xpathExpression = objToGetText.toString().replace("By.xpath: ", "");
			scrollToElement(objToGetText);
			JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
			innerText = (String) js.executeScript(
					"return document.evaluate(arguments[0], document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.textContent;",
					xpathExpression);
			Assert.assertTrue(true, "Get text operation successful - " + text);
			Log.info("Get text operation successful - " + text);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Get text operation unsuccessful. " + " Error - " + e.getMessage());
			Assert.fail("Get text operation unsuccessful. " + " Error - " + e.getMessage());
		}
		return innerText;
	}

	/**
	 * Function: Get last day of the year
	 *
	 * @author Trupti
	 */

	public static String getLastDayOfYear() {
		String lastDay = null;
		try {

			LocalDate today = LocalDate.now();
			LocalDate lastDayOfYear = today.with(TemporalAdjusters.lastDayOfYear());
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
			lastDay = lastDayOfYear.format(formatter);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lastDay;
	}

	public static ArrayList<String> getDataByHeaders(String tableName, String... headers) {
		ArrayList<String> allData = new ArrayList<>();
		try {

			String tableRowsXpath = "//*[contains(@class, 'active lafPageHost')]//table[@aria-label='" + tableName
					+ "']//tbody//tr";
			System.out.println("Table Rows XPath: " + tableRowsXpath);

			By tableRows = By.xpath(tableRowsXpath);
			List<WebElement> rows = getWebDriver().findElements(tableRows);

			for (WebElement row : rows) {
				StringBuilder rowData = new StringBuilder();

				for (String header : headers) {
					List<WebElement> headerList = getWebDriver()
							.findElements(By.xpath("//*[contains(@class, 'active lafPageHost')]//table[@aria-label='"
									+ tableName + "']//thead//th[@aria-label]"));

					boolean flag = false;
					int columnIndex = -1;

					for (int i = 0; i < headerList.size(); i++) {
						WebElement colHeader = headerList.get(i);
						String headerName = colHeader.getAttribute("aria-label");
						if (headerName.equalsIgnoreCase(header)) {
							columnIndex = i + 1;
							break;
						}
					}
					if (columnIndex == -1) {
						System.out.println("Column header '" + header + "' not found.");
						continue;
					}

					try {
						String value = "";
						if (columnIndex == 1) {
							WebElement cellElement = row.findElement(
									By.xpath(".//th[" + columnIndex + "]//span[@class='slds-truncate']//slot"));
							value = cellElement.getText().trim();
						} else {
							try {
								WebElement cellElement = row.findElement(By.xpath(".//td[" + (columnIndex) + "]//a"));
								value = cellElement.getAttribute("title").trim();
								flag = true;
							} catch (NoSuchElementException e) {
								WebElement cellElement = row.findElement(By.xpath(".//td[" + columnIndex + "]"));
								value = cellElement.getText().trim();
								flag = true;
							}
						}
						rowData.append(value).append(", ");
					} catch (NoSuchElementException e) {
						rowData.append(", ");
					}
				}

				if (rowData.length() > 0) {
					rowData.setLength(rowData.length() - 2);
				}
				allData.add(rowData.toString());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return allData;
	}

	/**
	 * Function: Write CPE url in text file
	 *
	 * @author Trupti Zure
	 */
	public static void writeURL(String url) {
		try {
			String cpeUrl = url;
			String fileName = "cpe_url.txt";
			String filePath = System.getProperty("user.dir") + "/TestData/" + fileName;
			FileWriter writer = new FileWriter(filePath, false);
			writer.write(cpeUrl);
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("An error occurred while writing to the file." + " Error - " + e.getMessage());
			Assert.fail("An error occurred while writing to the file." + " Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Read url from text file
	 *
	 * @author Trupti Zure
	 */
	public static String readURL() {
		String fileName = "cpe_url.txt";
		String filePath = System.getProperty("user.dir") + "/TestData/" + fileName;
		File file = new File(filePath);

		if (!file.exists()) {
			Log.error("URL file does not exist.");
			Assert.fail("cpe_url.txt does not exist.");
		}

		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String url = reader.readLine();
			if (url == null || url.trim().isEmpty()) {
				Assert.fail("URL file is empty.");
			}
			return url.trim();
		} catch (IOException e) {
			e.printStackTrace();
			Log.error("Error reading the URL file: " + e.getMessage());
			Assert.fail("An error occurred while reading the file: " + e.getMessage());
			return null;
		}
	}

	/**
	 * Function: Check if url exist in file
	 *
	 * @author Trupti Zure
	 */
	public static boolean checkURLinFile() {
		String fileName = "cpe_url.txt";
		String filePath = System.getProperty("user.dir") + "/TestData/" + fileName;
		File file = new File(filePath);

		if (!file.exists()) {
			return false;
		}

		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = reader.readLine()) != null) {
				if (!line.trim().isEmpty()) {
					return true;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * Function: Delete existing text file
	 *
	 * @author Trupti Zure
	 */

	public void deleteExistingTextFile() {

		String fileName = "cpe_url.txt";
		String filePath = System.getProperty("user.dir") + "/TestData/" + fileName;
		File file = new File(filePath);
		if (file.exists()) {
			if (file.delete()) {
				System.out.println("File deleted successfully!");
			} else {
				System.out.println("Failed to delete the file.");
			}
		} else {
			System.out.println("The file does not exist.");
		}
	}

	public static String changeDateFormatmmddyyyy(String inputDate) {
		try {

			SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date date = inputFormat.parse(inputDate);

			SimpleDateFormat outputFormat = new SimpleDateFormat("M/d/yyyy");
			return outputFormat.format(date);

		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	// Trupti
	public static String getNthDayFromTodaymmddyy(int n) {
		String nthDateString = "";
		try {
			LocalDate today = LocalDate.now();
			LocalDate nthDate = today.plusDays(n);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yy");
			nthDateString = nthDate.format(formatter);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return nthDateString;
	}

	/**
	 * Function: Search and open Required Record by providing Search Filter using
	 * GlobalSearch SearchFilter: Account, Cases,Care Program Enrollee....
	 * SearchValue: Record/Account/Case name to be searched....
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void globalSearchAcc(String SearchFilter, String SearchValue) {
		try {
			setTimeOut(5000);
			By btnGlobalSearch = By.xpath("//button[@aria-label='Search']");
			waitAndVerifyElement(btnGlobalSearch);
			click(btnGlobalSearch);
			setTimeOut(3000);

			By eleSearchFilter = By.xpath("//div[@part='input-text']//input[contains(@data-value,'Search:')]");
			waitAndVerifyElement(eleSearchFilter);
			click(eleSearchFilter);
			setTimeOut(3000);

			String strFilterValue = "//ul[@aria-label='All Searchable Items']//li//span[@title='%s']//ancestor::lightning-base-combobox-item";
			String xp = String.format(strFilterValue, SearchFilter);
			By eleSearchFilterValue = By.xpath(xp);
			scrollToElement(eleSearchFilterValue);
			highLightElement(eleSearchFilterValue);
			setTimeOut(4000);
			click(eleSearchFilterValue);
			setTimeOut(4000);

			Actions act = new Actions(getWebDriver());
			By eleSearchInput = By.xpath(
					"//lightning-input[@class='saInput slds-grow slds-form-element']//div[@part='input-text']//label[contains(text(),'Search')]//following-sibling::div//input");
			act.sendKeys(Keys.TAB).perform();
			setTimeOut(3000);
			inputText(eleSearchInput, SearchValue);
			setTimeOut(4000);

			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();

			LoggingInfo("Opened " + SearchValue + " successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to search " + SearchValue + " " + e.getMessage());
		}
	}

	/**
	 * Function: Verify and enter Text using Action class
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyAndInputTextWithActionClass(By objTextToBeVerified, String textToVerifyAndEnter) {
		try {
			WebElement element = getWebDriver().findElement(objTextToBeVerified);
			String elementText = getAttributeValue(objTextToBeVerified, "value");

			if (elementText != null) {
				boolean result = elementText.equals(textToVerifyAndEnter);

				if (result) {
					highLightElement(objTextToBeVerified);
					Log.info("Actual text matches with expected text: " + elementText);
				} else {
					Log.info("Actual text does not match with expected text: " + elementText);
					scrollToElement(objTextToBeVerified);
					clearText(objTextToBeVerified);
					JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
					String script = "arguments[0].focus();" + "arguments[0].value = arguments[1];"
							+ "arguments[0].dispatchEvent(new Event('input', { bubbles: true }));"
							+ "arguments[0].dispatchEvent(new Event('change', { bubbles: true }));"
							+ "arguments[0].blur();";
					js.executeScript(script, element, textToVerifyAndEnter);
//					Actions actions = new Actions(getWebDriver());
//					for (char c : textToVerifyAndEnter.toCharArray()) {
//						actions.moveToElement(element).click().sendKeys(String.valueOf(c)).build().perform();
//                     }
					Log.info("Actual text entered: " + textToVerifyAndEnter);
				}
			} else {
				String script = "arguments[0].focus();" + "arguments[0].value = arguments[1];"
						+ "arguments[0].dispatchEvent(new Event('input', { bubbles: true }));"
						+ "arguments[0].dispatchEvent(new Event('change', { bubbles: true }));"
						+ "arguments[0].blur();";
				// Handle case when elementText is null
				JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
				js.executeScript(script, element, textToVerifyAndEnter);
//				Actions actions = new Actions(getWebDriver());
//				for (char c : textToVerifyAndEnter.toCharArray()) {
//					actions.moveToElement(element).click().sendKeys(String.valueOf(c)).build().perform();
//		        }
				Log.info("Text entered: " + textToVerifyAndEnter);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Function: Get current/Local date in required format
	 *
	 * @author Shanavaz Nishani
	 */
	public String getCurrentDateInFormat(String dateFormat) {
		String updateDate = null;
		try {

			LocalDate date = LocalDate.now();
			int month = date.getMonthValue();
			int day = date.getDayOfMonth();
			int year = date.getYear();
			updateDate = month + "/" + day + "/" + year;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return updateDate;
	}

	/**
	 * Function: Send keys with action class
	 *
	 * @author Trupti
	 */

	public void sendKeysWithActionClass(By objToInputTextInto, String strTextToInput) {
		try {
			WebElement element = getWebDriver().findElement(objToInputTextInto);
			Actions actions = new Actions(getWebDriver());
			for (char c : strTextToInput.toCharArray()) {
				actions.moveToElement(element).click().sendKeys(String.valueOf(c)).build().perform();
			}
			Log.info("Actual text entered: " + strTextToInput);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Function: Get back date
	 *
	 * @author Trupti
	 */
	public static String getBackDateNDaysFromToday(int days) {

		String date = null;
		try {

			LocalDate today = LocalDate.now();
			LocalDate futureDate = today.minusDays(days);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
			date = futureDate.format(formatter);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return date;
	}

	public void clearInputText(By objTextToBeclear) {
		try {
			WebDriver driver = getWebDriver();
			WebElement element = driver.findElement(objTextToBeclear);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
			((JavascriptExecutor) driver).executeScript("arguments[0].value = '';", element);

			LoggingInfo("Cleared date field value using JavaScript: " + objTextToBeclear);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Clearing text of object unsuccessful - " + objTextToBeclear + ". Error - " + e.getMessage());
			Assert.fail("Clearing text of object unsuccessful - " + objTextToBeclear + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Get 1st jan of next year
	 *
	 * @author Sonica
	 */

	public static String getFirstDayofNextYear() {
		String firstDayofNexyYr = null;
		try {

			LocalDate today = LocalDate.now();
			// Calculate the first day of the next year
			LocalDate firstJanNextYear = LocalDate.of(today.getYear() + 1, 1, 1);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
			firstDayofNexyYr = firstJanNextYear.format(formatter);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return firstDayofNexyYr;
	}

	/**
	 * Function: Get last day of next year
	 *
	 * @author Sonica
	 */

	public static String getLastDayofNextYear() {
		String lastDayNext = null;

		try {

			// Get the current year
			int currentYear = Year.now().getValue();

			// Get the next year
			int nextYear = currentYear + 1;

			// Get the last day of the next year (December 31st)
			LocalDate lastDayOfNextYear = LocalDate.of(nextYear, 12, 31);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
			lastDayNext = lastDayOfNextYear.format(formatter);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lastDayNext;
	}

	/**
	 * Returns a date offset by days from today, formatted as specified.
	 *
	 * @param dayOffset Number of days from today (negative for past, positive for
	 *                  future)
	 * @param format    Desired date format (e.g. "M/d/yyyy", "MMM dd, yyyy")
	 * @return Formatted date string
	 * @author Shanavaz Nishani
	 */
	public static String getDateByOffsetDays(int dayOffset, String format) {
		LocalDate date = LocalDate.now().plusDays(dayOffset);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format, Locale.ENGLISH);
		return date.format(formatter);
	}

	/**
	 * Function: Get DOB from age
	 *
	 * @author shraddha
	 */
	public static String getBirthDate(int age) {

	    String date = null;
	    try {
	        Random random = new Random();
	        LocalDate today = LocalDate.now();
	        LocalDate latestBirthDate = today.minusYears(age);           
	        LocalDate earliestBirthDate = latestBirthDate.minusYears(1).plusDays(1); 

	        long daysBetween = java.time.temporal.ChronoUnit.DAYS.between(earliestBirthDate, latestBirthDate);

	        long randomDays = (long) (random.nextDouble() * daysBetween);

	        LocalDate birthDate = earliestBirthDate.plusDays(randomDays);

	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
	        date = birthDate.format(formatter);

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return date;
	}

}
