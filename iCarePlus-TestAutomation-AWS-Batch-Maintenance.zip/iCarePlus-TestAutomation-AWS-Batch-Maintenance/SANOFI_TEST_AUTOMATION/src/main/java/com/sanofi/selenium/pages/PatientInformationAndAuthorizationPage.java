package com.sanofi.selenium.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.sanofi.selenium.constants.ExcelTestDataConstants;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class PatientInformationAndAuthorizationPage extends Utility_Function {
	public PatientInformationAndAuthorizationPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	/************************* Elements *************************/

	public static By elePageTitle = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()='Patient Information & Authorizations' and contains(@class,'slds-page-header__title')]");
	public static By elesignatureDate = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()='Signature Date']//parent::label//parent::div//following-sibling::div//input)[1]");
	public static By elepatientSignatureDate = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()='Signature Date']//parent::label//parent::div//following-sibling::div//input)[2]");
	public static By eledob = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()='DOB']//parent::label//parent::div//following-sibling::div//input)[1]");
	public static By eleSigned = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()='Signed']//parent::label//parent::div//following-sibling::div//input)[1]");
	public static By elePatientSigned = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()='Signed']//parent::label//parent::div//following-sibling::div//input)[2]");

	public static By eleCertSigned = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()='Signature Date']//parent::label//parent::div//following-sibling::div//input)[2]");
	public static By eleLegalRepFNInput = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"First Name\"]//parent::label//parent::div//following-sibling::div//input)[2]");
	public static By eleLegalRepLNInput = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Last Name\"]//parent::label//parent::div//following-sibling::div//input)[2]");

	public static By eleAuthorizationSigned = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()='Signed']//parent::label//parent::div//following-sibling::div//input)[1]");
	public static By eleAuthorizationList = By.xpath(
			"//*[@data-omni-key=\"iccSigned\"]//*[text()='Signed']//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,'option-text')]");

	public static By elePatientAuthorizationSigned = By.xpath(
			"(//*[text()='Signed']//parent::label//parent::div//following-sibling::div//input)[2]");
	public static By elePatientAuthorizationList = By.xpath(
			"//*[@data-omni-key=\"iccPatientSigned\"]//*[text()='Signed']//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,'option-text')]");

	public static By eleAMChkBox = By.xpath("(//*[@data-omni-key='iccBestTiming']//input)[1]");
	public static By eleNoonChkBox = By.xpath("(//*[@data-omni-key='iccBestTiming']//input)[2]");
	public static By elePMChkBox = By.xpath("(//*[@data-omni-key='iccBestTiming']//input)[3]");

	/************************* Dynamic Elements *************************/
	public static String strTextBoxesInput = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String elePrevNextButtons = "//*[contains(@class,\"omniscript-button-position\")]//*[text()=\"{0}\"]";
	public static String checkBox = "//*[@data-omni-key=\"{0}\"]//input";
	public static By DiagnosisDateInputField = By.xpath(
			"//*[contains(text(),'Date of Diagnosis')]//parent::label//parent::div//following-sibling::div//child::input");
	public static By PrescriptionDateFieldInput = By.xpath(
			"//*[contains(text(),'Prescribed Date')]//parent::label//parent::div//following-sibling::div//child::input");
	public static String strDropDownXpath = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String dropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]";

	public void verifyPatientAuthorizationPageTitle() {

		try {
			setTimeOut(20000);
			Log.info("Verify Patient information and Authorization Page Present");
			waitAndVerifyElement(elePageTitle);
			LoggingInfo("Patient information and Authorization Page is loaded");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Page load failed " + e.getMessage());
			Assert.fail("Page load has Failed" + ". Error - " + e.getMessage());

		}

	}

	public void verifyDemographicInfo(String firstName, String middleName, String lastName, String date, String pGender,
			String language, String pAddress, String city, String state, String Zip) {
		try {
			setTimeOut(4000);
			// First Name
			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "First Name");
			waitAndVerifyElement(elepatientFNameInput);

			verifyHardAssertInputFieldBox(elepatientFNameInput, firstName, "Patient First Name");

			// Middle Name
			By elepatientMNameInput = getDynamicElement(strTextBoxesInput, "Middle Name");
			waitAndVerifyElement(elepatientMNameInput);
			verifyHardAssertInputFieldBox(elepatientMNameInput, middleName, "Patient Middle Name");

			// Last Name
			By elepatientLNameInput = getDynamicElement(strTextBoxesInput, "Last Name");
			waitAndVerifyElement(elepatientLNameInput);
			verifyHardAssertInputFieldBox(elepatientLNameInput, lastName, "Patient Last Name");

			// DOB
			waitAndVerifyElement(eledob);
			verifyHardAssertCalendarDate(eledob, date, patientDOB);

			// Gender
			By elepatientGenderDropdown = getDynamicElement(strDropDownXpath, "Gender");
			waitAndVerifyElement(elepatientGenderDropdown);
			verifyHardAssertDropDown(elepatientGenderDropdown, pGender, "Gender");

			// Language
			By eleLanguageInput = getDynamicElement(strTextBoxesInput, "Language");
			waitAndVerifyElement(eleLanguageInput);
			verifySoftAssertDropDown(eleLanguageInput, language, language);

			// Address
			By eleAddressInput = getDynamicElement(strTextBoxesInput, "Address");
			waitAndVerifyElement(eleAddressInput);
			verifySoftAssertInputFieldBox(eleAddressInput, pAddress, ExcelTestDataConstants.patientAddress);

			// City
			By eleCityInput = getDynamicElement(strTextBoxesInput, "City");
			waitAndVerifyElement(eleCityInput);
			verifySoftAssertInputFieldBox(eleCityInput, city, ExcelTestDataConstants.city);

			// state
			By eleStateDropdown = getDynamicElement(strDropDownXpath, "State");
			waitAndVerifyElement(eleStateDropdown);
			verifySoftAssertDropDown(eleStateDropdown, state, ExcelTestDataConstants.state);

			// zip
			By eleZipInput = getDynamicElement(strTextBoxesInput, "Zip");
			waitAndVerifyElement(eleZipInput);
			verifySoftAssertInputFieldBox(eleZipInput, Zip, zip);

			LoggingInfo("Demographic data information has been entered correctly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify patient demographic information" + e.getMessage());
			Assert.fail("Failed to verify patient demographic information " + e.getMessage());
		}
	}

	public void patientAutherization(String signed, String signaturedate, String patientSigned, String signedDate,
			String textMsg) {
		try {
			// Authorization sign
			waitAndVerifyElement(eleAuthorizationSigned);
			scrollToElement(eleAuthorizationSigned);
			click(eleAuthorizationSigned);

			verifyAndEnterInfoDropDownField(eleAuthorizationSigned, eleAuthorizationList, signed,
					"Patient Authorization Signed");

			// Authorization Signature date
			waitAndVerifyElement(elesignatureDate);
			inputText(elesignatureDate, signaturedate);

			// Patient certification signed
			waitAndVerifyElement(elePatientAuthorizationSigned);
			scrollToElement(elePatientAuthorizationSigned);
			click(elePatientAuthorizationSigned);
			verifyAndEnterInfoDropDownField(elePatientAuthorizationSigned, elePatientAuthorizationList, patientSigned,
					"Patient Certifications Signed");

			// Patient certification date
			waitAndVerifyElement(elePatientSigned);
			inputText(eleCertSigned, signedDate);

			// Text Messaging
			By eleTextMessageDropdown = getDynamicElement(strDropDownXpath, "Text Messaging Consent");
			waitAndVerifyElement(eleTextMessageDropdown);
			verifySoftAssertDropDown(eleTextMessageDropdown, textMsg, "Text Messaging Consent");

			LoggingInfo("Patient Autherization data has been entered/verified correctly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify patient Autherization" + e.getMessage());
			Assert.fail("Failed to verify patient Autherization " + e.getMessage());
		}
	}

	public void verifyContactInformation(String pEmail, String pPhone, String voiceMail, String textCheck, String am,
			String noon, String pm, String sPhone) {
		try {
			// Email
			By eleEmailInput = getDynamicElement(strTextBoxesInput, "Email");
			waitAndVerifyElement(eleEmailInput);
			scrollToElement(eleEmailInput);
			verifySoftAssertInputFieldBox(eleEmailInput, pEmail, patientEmail);

			// Phone
			By elePhoneInput = getDynamicElement(strTextBoxesInput, "Phone");
			waitAndVerifyElement(elePhoneInput);
			verifySoftAssertInputFieldBox(elePhoneInput, pPhone, ExcelTestDataConstants.patientPrimaryphone);

			// voiceMail
			By voiceMailCheckbox = getDynamicElement(checkBox, "iccVoicemail");
			waitAndVerifyElement(voiceMailCheckbox);
			verifySoftAssertCheckBox(voiceMailCheckbox, voiceMail, "voiceMail Checkbox");

			// Text
			By textCheckbox = getDynamicElement(checkBox, "iccText");
			waitAndVerifyElement(textCheckbox);
			verifySoftAssertCheckBox(textCheckbox, textCheck, "Text Checkbox");

			// AM
			waitAndVerifyElement(eleAMChkBox);
			verifySoftAssertCheckBox(eleAMChkBox, am, "AM Checkbox");

			// Afternoon
			waitAndVerifyElement(eleNoonChkBox);
			verifySoftAssertCheckBox(eleNoonChkBox, noon, "Afternoon Checkbox");

			// PM
			waitAndVerifyElement(elePMChkBox);
			verifySoftAssertCheckBox(elePMChkBox, pm, "PM Checkbox");

			// secondary Phone
			By eleSecPhoneInput = getDynamicElement(strTextBoxesInput, "Secondary Phone");
			waitAndVerifyElement(eleSecPhoneInput);
			verifySoftAssertInputFieldBox(eleSecPhoneInput, sPhone, ExcelTestDataConstants.patientSecondaryphone);

			LoggingInfo("Contact Information data has been entered/verified correctly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify patient contact information-" + e.getMessage());
			Assert.fail("Failed to verify patient contact information-" + e.getMessage());
		}
	}

	public void verifyLegalRepDetails(String legalFN, String legalLN, String type) {
		try {
			// Legal Representative first name
			waitAndVerifyElement(eleLegalRepFNInput);
			verifySoftAssertInputFieldBox(eleLegalRepFNInput, legalFN, "Legal Representative First Name");

			// Legal Representative Last name
			waitAndVerifyElement(eleLegalRepLNInput);
			verifySoftAssertInputFieldBox(eleLegalRepLNInput, legalLN, "Legal Representative Last Name");

			// RelationshipDropdown
			By eleLegalRepTypeInput = getDynamicElement(strDropDownXpath, "Relationship");
			waitAndVerifyElement(eleLegalRepTypeInput);
			verifySoftAssertDropDown(eleLegalRepTypeInput, type, legalrelationship);

			LoggingInfo("Legal Representative details has been entered/verified correctly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify legal representative information-" + e.getMessage());
			Assert.fail("Failed to verify legal representative information-" + e.getMessage());
		}
	}

	public void verifyPrevious() {
		try {
			By previousButton = getDynamicElement(elePrevNextButtons, "Previous");
			waitAndVerifyElement(previousButton);
			setTimeOut(1000);
			LoggingInfo("Successfully verified Previous button on Patient info and authorization page");
			Assert.assertTrue(true, "Successfully verified Previous button on Patient info and authorization page");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on Previous Button-" + "Error - " + e.getMessage());
		}
	}

	public void enterDemographicInfo(String firstName, String middleName, String lastName, String date, String pGender,
			String language, String pAddress, String city, String state, String Zip) {
		try {
			setTimeOut(4000);
			// First Name
			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "First Name");
			scrollToElement(elepatientFNameInput);
			waitAndVerifyElement(elepatientFNameInput);
			verifyAndEnterInfoInputField(elepatientFNameInput, firstName, "First Name");

			// Middle Name
			By elepatientMNameInput = getDynamicElement(strTextBoxesInput, "Middle Name");
			waitAndVerifyElement(elepatientMNameInput);
			verifyAndEnterInfoInputField(elepatientMNameInput, middleName, "Patient Middle Name");

			// Last Name
			By elepatientLNameInput = getDynamicElement(strTextBoxesInput, "Last Name");
			waitAndVerifyElement(elepatientLNameInput);
			verifyAndEnterInfoInputField(elepatientLNameInput, lastName, "Patient Last Name");

			// DOB
			waitAndVerifyElement(eledob);
			verifyAndEnterInfoInputField(eledob, date, "Patient DOB");

			// Gender
			By genderDropdown = getDynamicElement(strDropDownXpath, "Gender");
			waitAndVerifyElement(genderDropdown);
			String currentGender = getAttributeValue(genderDropdown, "value");

			if (!currentGender.equalsIgnoreCase(pGender)) {
				click(genderDropdown);
				By genderOptions = getDynamicElement(dropDownOptions, "Gender");
				waitAndVerifyElement(genderOptions);
				verifyAndEnterInfoDropDownField(genderDropdown, genderOptions, pGender, "Gender");
				Log.info("Gender updated from '" + currentGender + "' to '" + pGender + "'");
			} else {

				highLightElement(genderDropdown);
				Log.info("Gender already set correctly to: " + pGender);
			}
			// Language
			By eleLanguageInput = getDynamicElement(strTextBoxesInput, "Language");
			waitAndVerifyElement(eleLanguageInput);
			String currentLanguage = getAttributeValue(eleLanguageInput, "value");

			if (!currentLanguage.equalsIgnoreCase(language)) {
				clickByJavascript(eleLanguageInput);
				By eleLanguageInputOptions = getDynamicElement(dropDownOptions, "Language");
				waitAndVerifyElement(eleLanguageInputOptions);
				verifyAndEnterInfoDropDownField(eleLanguageInput, eleLanguageInputOptions, language, "Language");
				Log.info("Language updated from '" + currentLanguage + "' to '" + language + "'");
			} else {
				highLightElement(eleLanguageInput);
				Log.info("Language already set correctly to: " + language);
			}

			// Address
			By eleAddressInput = getDynamicElement(strTextBoxesInput, "Address");
			waitAndVerifyElement(eleAddressInput);
			scrollToElement(eleAddressInput);
			verifyAndEnterInfoInputField(eleAddressInput, pAddress, ExcelTestDataConstants.patientAddress);

			// City
			By eleCityInput = getDynamicElement(strTextBoxesInput, "City");
			waitAndVerifyElement(eleCityInput);
			verifyAndEnterInfoInputField(eleCityInput, city, ExcelTestDataConstants.city);

			// State
			By eleStateDropdown = getDynamicElement(strDropDownXpath, "State");
			waitAndVerifyElement(eleStateDropdown);
			String currentState = getAttributeValue(eleStateDropdown, "value");

			if (!currentState.equalsIgnoreCase(state)) {
				click(eleStateDropdown);
				By eleStateDropdownOptions = getDynamicElement(dropDownOptions, "State");
				waitAndVerifyElement(eleStateDropdownOptions);
				verifyAndEnterInfoDropDownField(eleStateDropdown, eleStateDropdownOptions, state, "State");
				Log.info("State updated from '" + currentState + "' to '" + state + "'");
			} else {
				highLightElement(eleStateDropdown);
				Log.info("State already set correctly to: " + state);

			}

			// zip
			By eleZipInput = getDynamicElement(strTextBoxesInput, "Zip");
			waitAndVerifyElement(eleZipInput);
			verifyAndEnterInfoInputField(eleZipInput, Zip, zip);

			LoggingInfo("Demographic Information data has been entered/verified correctly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter patient demographic information" + e.getMessage());
			Assert.fail("Failed to enter patient demographic information " + e.getMessage());
		}
	}

	public void enterAutherization(String signed, String signaturedate, String patientSigned, String signedDate,
			String textMsg) {
		try {
			// Authorization sign
			waitAndVerifyElement(eleAuthorizationSigned);
			scrollToElement(eleAuthorizationSigned);
			highLightElement(eleAuthorizationSigned);
			click(eleAuthorizationSigned);
			selectItemFromList(eleAuthorizationSigned, eleAuthorizationList, signed, "Patient Authorization Signed");

			// Authorization Signature date
			waitAndVerifyElement(elesignatureDate);
			verifyAndEnterInfoInputField(elesignatureDate, signaturedate, "Autherization signature date");

			// Patient certification signed
			waitAndVerifyElement(elePatientAuthorizationSigned);
			scrollToElement(elePatientAuthorizationSigned);
			highLightElement(elePatientAuthorizationSigned);
			click(elePatientAuthorizationSigned);
			selectItemFromList(elePatientAuthorizationSigned, elePatientAuthorizationList, patientSigned,
					"Patient Certifications Signed");

			// Patient certification date
			waitAndVerifyElement(elePatientSigned);
			verifyAndEnterInfoInputField(eleCertSigned, signedDate, "Patient Certifications date");

			// "Text Messaging Consent"
			By textMsgDropdownLocator = getDynamicElement(strDropDownXpath, "Text Messaging Consent");
			waitAndVerifyElement(textMsgDropdownLocator);
			scrollToElement(textMsgDropdownLocator);

			String currentValue = getAttributeValue(textMsgDropdownLocator, "value");
			String expectedValue = (textMsg != null && textMsg.equalsIgnoreCase("True")) ? "Yes" : "No";

			if (currentValue == null || !currentValue.equalsIgnoreCase(expectedValue)) {
				click(textMsgDropdownLocator);
				By dropdownOptionsLocator = getDynamicElement(dropDownOptions, "Text Messaging Consent");
				waitAndVerifyElement(dropdownOptionsLocator);
				verifyAndEnterInfoDropDownField(textMsgDropdownLocator, dropdownOptionsLocator, expectedValue,
						"Text Messaging Consent");
				Log.info("Text Messaging Consent updated to '" + expectedValue + "'");
			} else {
				Log.info("Text Messaging Consent is already set to '" + expectedValue + "'");
			}

			LoggingInfo("Autherization data has been entered correctly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter patient Autherization" + e.getMessage());
			Assert.fail("Failed to enter patient Autherization " + e.getMessage());
		}
	}

	public void enterContactInformation(String pEmail, String pPhone, String voiceMail, String textCheck, String am,
			String noon, String pm, String sPhone) {
		try {
			// Email
			By eleEmailInput = getDynamicElement(strTextBoxesInput, "Email");
			waitAndVerifyElement(eleEmailInput);
			scrollToElement(eleEmailInput);
			verifyAndEnterInfoInputField(eleEmailInput, pEmail, "Email");

			// Phone
			By elePhoneInput = getDynamicElement(strTextBoxesInput, "Phone");
			waitAndVerifyElement(elePhoneInput);
			// click(elePhoneInput);
			verifyAndInputTextWithActionClass(elePhoneInput, pPhone);

			// voiceMail
			By voiceMailCheckbox = getDynamicElement(checkBox, "iccVoicemail");
			waitAndVerifyElement(voiceMailCheckbox);
			verifyandSelectCheckBox(voiceMailCheckbox, voiceMail, "voiceMail Checkbox");

			// Text
			By textCheckbox = getDynamicElement(checkBox, "iccText");
			waitAndVerifyElement(textCheckbox);
			verifyandSelectCheckBox(textCheckbox, textCheck, "Text Checkbox");

			// AM
			waitAndVerifyElement(eleAMChkBox);
			verifyandSelectCheckBox(eleAMChkBox, am, "AM Checkbox");

			// Afternoon
			waitAndVerifyElement(eleNoonChkBox);
			verifyandSelectCheckBox(eleNoonChkBox, noon, "Afternoon Checkbox");

			// PM
			waitAndVerifyElement(elePMChkBox);
			verifyandSelectCheckBox(elePMChkBox, pm, "PM Checkbox");

			// secondary Phone
			By eleSecPhoneInput = getDynamicElement(strTextBoxesInput, "Secondary Phone");
			waitAndVerifyElement(eleSecPhoneInput);
			// click(eleSecPhoneInput);
			verifyAndInputTextWithActionClass(eleSecPhoneInput, sPhone);

			LoggingInfo("Contact information data has been entered correctly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter patient contact information-" + e.getMessage());
			Assert.fail("Failed to enter patient contact information-" + e.getMessage());
		}
	}

	public void enterLegalRepDetails(String legalFN, String legalLN, String type) {
		try {
			// Legal Representative first name
			waitAndVerifyElement(eleLegalRepFNInput);
			scrollToElement(eleLegalRepFNInput);
			verifyAndEnterInfoInputField(eleLegalRepFNInput, legalFN, "Legal Representative First Name");

			// Legal Representative Last name
			waitAndVerifyElement(eleLegalRepLNInput);
			verifyAndEnterInfoInputField(eleLegalRepLNInput, legalLN, "Legal Representative Last Name");

			// Relationship Dropdown
			By eleLegalRepTypeInput = getDynamicElement(strDropDownXpath, "Relationship");
			waitAndVerifyElement(eleLegalRepTypeInput);
			String relation = getAttributeValue(eleLegalRepTypeInput, "value");

			if (relation == null || !relation.equalsIgnoreCase(type)) {
				scrollToElement(eleLegalRepTypeInput);
				click(eleLegalRepTypeInput);
				By eleLegalRepTypeInputOptions = getDynamicElement(dropDownOptions, "Relationship");
				waitAndVerifyElement(eleLegalRepTypeInputOptions);
				verifyAndEnterInfoDropDownField(eleLegalRepTypeInput, eleLegalRepTypeInputOptions, type,
						"Relationship");
			} else {
				highLightElement(eleLegalRepTypeInput);
				Log.info("Actual text '" + relation + "' matches expected text '" + type + "'");
			}

			LoggingInfo("Legal Representative information has been entered/verified correctly");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify legal representative information-" + e.getMessage());
			Assert.fail("Failed to verify legal representative information-" + e.getMessage());
		}
	}

	public void clickOnNextButton() {
		try {
			By nextButton = getDynamicElement(elePrevNextButtons, "Next");
			waitAndVerifyElement(nextButton);
			scrollToElement(nextButton);
			click(nextButton);
			Log.info("Clicked on Next Button");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on Previous Button-" + "Error - " + e.getMessage());
		}
	}
	
	/**
	 * Function: Verfy if Alert message on DOB field is displayed
	 *
	 * @author Shanavaz Nishani
	 */
	public void checkDOBerrorMsg() {
		try {
			WebElement eleError = getWebDriver()
					.findElement(By.xpath("//*[contains(@class,\"active lafPageHost\")]//div[@role=\"alert\"]//p"));
			if (eleError.isDisplayed()) {
				Log.info(eleError.getText());
			} else {
				Log.info("Valid DOB is entered, hence Error is not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify DOB Alert Msg " + "Error - " + e.getMessage());
		}

	}

	/**
	 * Function: Verify Patient Name
	 *
	 * @author Trupti
	 */

	public void verifyPatientName(String firstName, String middleName, String lastName) {
		try {
			setTimeOut(4000);
			// First Name
			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "First Name");
			waitAndVerifyElement(elepatientFNameInput);

			verifyHardAssertInputFieldBox(elepatientFNameInput, firstName, "Patient First Name");

			// Middle Name
			By elepatientMNameInput = getDynamicElement(strTextBoxesInput, "Middle Name");
			waitAndVerifyElement(elepatientMNameInput);
			verifyHardAssertInputFieldBox(elepatientMNameInput, middleName, "Patient Middle Name");

			// Last Name
			By elepatientLNameInput = getDynamicElement(strTextBoxesInput, "Last Name");
			waitAndVerifyElement(elepatientLNameInput);
			verifyHardAssertInputFieldBox(elepatientLNameInput, lastName, "Patient Last Name");

			LoggingInfo("Patient Name has been entered/verified correctly");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify patient name-" + "Error - " + e.getMessage());
		}
	}

	public void validateFutureDateDisabled() {

		try {
			// LocalDate tomorrow = LocalDate.now();
			// DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-DD-YYYY");
			String formattedDate = Utility_Function.getNthDayFromToday(0);
			String errorText = "This date has been disabled. Please select a date on or before " + formattedDate;
			errorMessageValidation(errorText);
			LoggingInfo("User is not able to Select Future Date and error message dispalyed is : " + errorText);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			Assert.fail("Failed to verify that Future Date is disabled" + "Error - " + e.getMessage());
		}

	}

	public void enterfutureDate(String strField) throws Exception {

		// LocalDate tomorrow = LocalDate.now().plusDays(1);
		// DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-DD-YYYY");
		String formattedDate = Utility_Function.getNthDayFromToday(1);
		System.out.println("Tomorrow's date in MM-dd-yyyy format: " + formattedDate);

		if (strField.equalsIgnoreCase("Authroziation Signature Date")) {
			waitAndVerifyElement(elesignatureDate);
			scrollToElement(elesignatureDate);
			click(elesignatureDate);
			inputText(elesignatureDate,formattedDate);
		//	verifyAndEnterInfoInputField(elesignatureDate, formattedDate, "Autherization signature date");
		//	genericKeyPress(elesignatureDate, "Enter");
			clickByJavascript(eleAuthorizationSigned);
			// click(elesignatureDate);
			setTimeOut(5000);

		} else if (strField.equalsIgnoreCase("Patient Certification Date")) {
			waitAndVerifyElement(eleCertSigned);
			scrollToElement(eleCertSigned);
			verifyAndEnterInfoInputField(eleCertSigned, formattedDate, "Patient Certifications date");
			genericKeyPress(eleCertSigned, "Enter");
			clickByJavascript(eleAuthorizationSigned);
			setTimeOut(5000);

		} else if (strField.equalsIgnoreCase("DOB")) {
			waitAndVerifyElement(eledob);
			scrollToElement(eledob);
			verifyAndEnterInfoInputField(eledob, formattedDate, patientDOB);
			genericKeyPress(eledob, "Enter");
			clickByJavascript(eleAuthorizationSigned);//elePageTitle
			// click(eledob);
			setTimeOut(5000);

		} else if (strField.equalsIgnoreCase("Diagnosis Date")) {
			waitAndVerifyElement(DiagnosisDateInputField);
			scrollToElement(DiagnosisDateInputField);
			verifyAndEnterInfoInputField(DiagnosisDateInputField, formattedDate, dateOfDiagnosis);
			genericKeyPress(DiagnosisDateInputField, "Enter");
			// clickByJavascript(elePageTitle);
			setTimeOut(5000);

		} else if (strField.equalsIgnoreCase("Prescriber Date")) {
			waitAndVerifyElement(PrescriptionDateFieldInput);
			verifyAndEnterDataInputField(PrescriptionDateFieldInput, formattedDate, prescriberState);
			genericKeyPress(PrescriptionDateFieldInput, "Enter");
			// clickByJavascript(elePageTitle);
			setTimeOut(5000);

		}

	}

	/**
	 * Function: Verify relationship drop down values
	 *
	 * @author Trupti
	 */

	public void validateRelationshipDropDownValues() {
		try {
			String[] expectedPickListValues = { "-- Clear --", "Caregiver", "Spouse/Partner", "Parent", "Guardian",
					"Child", "Other" };
			// RelationshipDropdown
			By eleLegalRepTypeInput = getDynamicElement(strDropDownXpath, "Relationship");
			waitAndVerifyElement(eleLegalRepTypeInput);
			scrollToElement(eleLegalRepTypeInput);
			click(eleLegalRepTypeInput);
			List<WebElement> picklistValue = getWebDriver().findElements(By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"Relationship\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]"));
			boolean isValid = false;
			for (int i = 0; i < picklistValue.size(); i++) {
				String actualPickListValue = picklistValue.get(i).getText();
				for (String expectedValue : expectedPickListValues) {
					if (actualPickListValue.equalsIgnoreCase(expectedValue)) {
						isValid = true;
						break;
					}
				}

				Assert.assertTrue(isValid, "Invalid picklist value: " + actualPickListValue);
			}
			click(eleLegalRepTypeInput);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify relationship drop down values" + "Error - " + e.getMessage());
		}
	}

	public void clearTextFromDateField() {
		try {
			waitAndVerifyElement(eledob);
			scrollToElement(eledob);
			clearInputText(eledob);
		} catch (Exception e) {
			Assert.fail("Failed to clear date field" + "Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Validate Picklist Value Removed (Patient Authorization Page)
	 *
	 * @author Shanavaz Nishani
	 */
	public void validatePicklistValueRemoved(String Val, String DropdownName) throws Exception {
		boolean optionFound = false;
		By eleDropdown = null;
		if (DropdownName.equals("Text Messaging Consent")) {
			By textMsgDropdownLocator = getDynamicElement(strDropDownXpath, "Text Messaging Consent");
			waitAndVerifyElement(textMsgDropdownLocator);
			scrollToElement(textMsgDropdownLocator);
			click(textMsgDropdownLocator);
			eleDropdown = getDynamicElement(dropDownOptions, "Text Messaging Consent");
		} else if (DropdownName.equals("Patient Authorization Signed")) {

			scrollToElement(eleAuthorizationSigned);
			highLightElement(eleAuthorizationSigned);
			click(eleAuthorizationSigned);
			eleDropdown = eleAuthorizationList;
		} else if (DropdownName.equals("Patient Certifications Signed")) {
			scrollToElement(elePatientAuthorizationSigned);
			highLightElement(elePatientAuthorizationSigned);
			click(elePatientAuthorizationSigned);
			eleDropdown = elePatientAuthorizationList;
		}

		List<WebElement> authSignedList = getWebDriver().findElements(eleDropdown);
		for (WebElement option : authSignedList) {
			if (option.getText().equalsIgnoreCase(Val)) {
				optionFound = true;
			}
		}
		if (!optionFound) {
			LoggingInfo("Option '" + Val + "' is removed from the '" + DropdownName + "' dropdown.");

		} else {
			Log.error("Option '" + Val + "' is still present in the '" + DropdownName + "' dropdown.");
			Assert.fail("Option '" + Val + "' is still present in the '" + DropdownName + "' dropdown.");

		}
		scrollToElement(eleAuthorizationSigned);
		click(eleAuthorizationSigned);

	}


/**
	 * Function: To put incorrect address
	 *
	 * @author Tejal
	 */
	
	public void updatePatientAddressOnly(String newAddress) {
	    try {
	     

	        // Address
	        By eleAddressInput = getDynamicElement(strTextBoxesInput, "Address");
	        waitAndVerifyElement(eleAddressInput);
	        scrollToElement(eleAddressInput);
	        verifyAndEnterInfoInputField(eleAddressInput, newAddress, "Patient Address");

	        Log.info("Patient address has been updated to: " + newAddress);
	    } catch (Exception e) {
	        e.printStackTrace();
	        Log.error("Failed to update patient address: " + e.getMessage());
	        Assert.fail("Failed to update patient address: " + e.getMessage());
	    }
	}

}
