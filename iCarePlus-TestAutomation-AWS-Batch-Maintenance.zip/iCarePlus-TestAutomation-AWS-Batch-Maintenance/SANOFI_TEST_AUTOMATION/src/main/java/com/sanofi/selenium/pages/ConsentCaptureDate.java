package com.sanofi.selenium.pages;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.WebDriver;

import com.sanofi.selenium.core.Utility_Function;

public class ConsentCaptureDate extends Utility_Function {

	public ConsentCaptureDate(WebDriver driver) {
		super(driver);
	}
	
	/**
	 * Function: Get PPA consent capture date
	 * @author Trupti Zure
	 * @throws ParseException 
	 **/
	public String getPPAConsentCaptureDate(String patientCertDate) {
				
				LocalDate patientCertficationDate = LocalDate.parse(patientCertDate, DateTimeFormatter.ofPattern("MM-dd-yyyy"));
		
				LocalDate consentCapturedDate = patientCertficationDate;
		
				// Format the date
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");//M/d/yy
				return formatter.format(consentCapturedDate.atStartOfDay());
			}

	/**
	 * Function: Get hippa Consent CaptureDate
	 * @author Trupti Zure
	 **/
	
	public String hippaConsentCaptureDate(String patientAuthDate) {
		LocalDate patientCertficationDate = LocalDate.parse(patientAuthDate, DateTimeFormatter.ofPattern("MM-dd-yyyy"));

		LocalDate consentCapturedDate = patientCertficationDate;

		// Format the date
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yy");
		return formatter.format(consentCapturedDate.atStartOfDay());
	}

	/**
	 * Function: Get Consent capture date and time
	 * @author Trupti Zure
	 **/
	
	public String getConsentCapturedDateTime(String patientCertificationDate) {
		LocalDate today = LocalDate.now();
		if (patientCertificationDate != null && !patientCertificationDate.trim().isEmpty()) {
			LocalDate patientCertficationDate = LocalDate.parse(patientCertificationDate,
					DateTimeFormatter.ofPattern("MM-dd-yyyy"));
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");//M/d/yy
			LocalDate consentCapturedDate = patientCertficationDate;
			return formatter.format(consentCapturedDate.atStartOfDay());
		} else {
			LocalDate consentCapturedDate = today.minusDays(1);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yy");
			return formatter.format(consentCapturedDate.atStartOfDay());
		}
	}
	
	/**
	 * Function: Get HCP Consent capture date 
	 * @author Trupti Zure
	 **/

	public String hcpConsentCapturedDateTime(String prescriberSignatureDate) {
		LocalDate today = LocalDate.now();
		if (prescriberSignatureDate != null && !prescriberSignatureDate.trim().isEmpty()) {
			LocalDate patientCertficationDate = LocalDate.parse(prescriberSignatureDate,
					DateTimeFormatter.ofPattern("MM-dd-yyyy"));
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");//M/d/yy
			LocalDate consentCapturedDate = patientCertficationDate;
			return formatter.format(consentCapturedDate.atStartOfDay());
		} else {
			LocalDate consentCapturedDate = today.minusDays(1);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yy");
			return formatter.format(consentCapturedDate.atStartOfDay());
		}
	}
	
	/**
	 * Function: Get Consent capture date and time
	 * @author Trupti Zure
	 **/
	
	public String getConsentCapturedDateTimemdyyyy(String patientCertificationDate) {
		LocalDate today = LocalDate.now();
		if (patientCertificationDate != null && !patientCertificationDate.trim().isEmpty()) {
			LocalDate patientCertficationDate = LocalDate.parse(patientCertificationDate,
					DateTimeFormatter.ofPattern("MM-dd-yyyy"));
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
			LocalDate consentCapturedDate = patientCertficationDate;
			return formatter.format(consentCapturedDate.atStartOfDay());
		} else {
			LocalDate consentCapturedDate = today.minusDays(1);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
			return formatter.format(consentCapturedDate.atStartOfDay());
		}
	}

}