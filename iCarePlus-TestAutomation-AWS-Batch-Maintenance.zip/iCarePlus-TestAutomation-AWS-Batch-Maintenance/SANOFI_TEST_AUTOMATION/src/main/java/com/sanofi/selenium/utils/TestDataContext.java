package com.sanofi.selenium.utils;

public class TestDataContext {
	private static final ThreadLocal<String> threadExcelPath = new ThreadLocal<>();

	public static void setExcelPath(String path) {
		threadExcelPath.set(path);
	}

	public static String getExcelPath() {
		return threadExcelPath.get();
	}

	public static void clear() {
		threadExcelPath.remove();
	}
}
