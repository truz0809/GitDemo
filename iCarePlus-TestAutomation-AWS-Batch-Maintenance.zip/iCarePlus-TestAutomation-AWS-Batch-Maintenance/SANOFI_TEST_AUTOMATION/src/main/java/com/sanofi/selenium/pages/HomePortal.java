package com.sanofi.selenium.pages;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeoutException;

import org.apache.poi.ss.formula.functions.T;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;
import com.sanofi.selenium.xpaths.casesPageXpaths;

public class HomePortal extends Utility_Function {

	/************************
	 * Elements
	 *************************************************/

	public static final By icareLogoTextElement = By.xpath("//*[@title='iCare Connect']");
	public static final By closeAppLauncher = By.xpath("//button[@title=\"Cancel and close\"]");
	public static final By firstName = By.xpath("//input[@name='FirstName']");
	public static final By eleCloseTabButton = By
			.xpath("//li[@data-aura-class='navexConsoleTabItem']//button[contains(@title,'Close')]");
	public static final By eleAppLauncher = By.xpath("//*[@class='appLauncher slds-context-bar__icon-action']//button");
	public static final By eleViewAllLink = By.xpath("//button[contains(text(),'View')]");
	public static final By eleAppLauncherSearch = By.xpath("//*[contains(@placeholder,'Search apps')]");
	public static final String eleClickObjectValue = "(//mark[text()='0'])[1]";
	public static final By spinner = By.xpath("//lightning-spinner[contains(@class,'slds-spinner_container')]");

	/****************** Dynamic Locators *****************************************/
	public static String menuList = "//*[text()=\"{0}\"]/../parent::a";

	private static String strAvailableOptions = "//*[text()=\"{0}\"]//parent::div/parent::*//following-sibling::*//li//span[text()=\"{1}\"]";
	private static String strMoveSelectionButton = "//button[contains(@title,\"{0}\")]";

	public HomePortal(WebDriver driver) {
		super(driver);
	}

	public <T> T selectItemFromAppLauncher(String ObjectValue, Class<T> className) {
		int maxRetries = 3;
		int retryCount = 0;

		while (retryCount < maxRetries) {
			try {
				Log.info("Attempt #" + (retryCount + 1) + ": Click on App Launcher");
				waitForPageLoaded();
				openICareConnectApp(className);
				WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(10));
				WebElement launcher = wait.until(ExpectedConditions.elementToBeClickable(eleAppLauncher));
				launcher.click();

				wait.until(ExpectedConditions.presenceOfElementLocated(eleViewAllLink)).click();
				inputText(eleAppLauncherSearch, ObjectValue);

				String newClickObjectValue = eleClickObjectValue.replace("0", ObjectValue);
				By ClickObjectValue1 = By.xpath(newClickObjectValue);

				if (!isElementPresent(ClickObjectValue1)) {
					Log.info("Object is not present. Retrying...");
					closeAppLauncher();
					retryCount++;
					continue;
				}

				if (ObjectValue.equals("Products")) {
					By eleClickObjectValue = By.xpath("(//mark[text()='Products'])[3]");
					click(eleClickObjectValue);
				} else {
					click(ClickObjectValue1);
				}

				Log.info("Navigated on object successful - " + ObjectValue);
				Assert.assertTrue(true, "Navigated on object successful - " + ObjectValue);
				setTimeOut(1000);
				return GetInstance(className);

			} catch (Exception e) {
				e.printStackTrace();
				Log.error("Navigation failed on object: " + ObjectValue + ". Error: " + e.getMessage());
				closeAppLauncher();
				retryCount++;
			}
		}

		throw new RuntimeException("Failed to select item from App Launcher after " + maxRetries + " retries.");
	}

	public boolean spinnerIsDisplayed() {
		try {
			waitAndVerifyElement(spinner);
			return true;

		} catch (NoSuchElementException | StaleElementReferenceException e) {
			// Spinner element not found or not displayed
			return false;
		}
	}

	public void closeAppLauncher() {
		try {
			waitAndVerifyElement(closeAppLauncher);
			click(closeAppLauncher);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to close App Launcher: " + e.getMessage());
		}
	}

	public <T> T selectObjectFromAppLauncher(String ObjectValue, Class<T> className) {
		int maxRetries = 3;
		int retryCount = 0;

		while (retryCount < maxRetries) {
			try {
				Log.info("Attempt #" + (retryCount + 1) + ": Click on App Launcher");
				waitForPageLoaded();
				WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(10));
				WebElement launcher = wait.until(ExpectedConditions.elementToBeClickable(eleAppLauncher));
				launcher.click();

				wait.until(ExpectedConditions.presenceOfElementLocated(eleViewAllLink)).click();
				inputText(eleAppLauncherSearch, ObjectValue);

				String newClickObjectValue = eleClickObjectValue.replace("0", ObjectValue);
				By ClickObjectValue1 = By.xpath(newClickObjectValue);

				if (!isElementPresent(ClickObjectValue1)) {
					Log.info("Object is not present. Retrying...");
					closeAppLauncher();
					retryCount++;
					continue;
				}

				if (ObjectValue.equals("Products")) {
					By eleClickObjectValue = By.xpath("(//mark[text()='Products'])[3]");
					click(eleClickObjectValue);
				} else {
					click(ClickObjectValue1);
				}

				Log.info("Navigated on object successful - " + ObjectValue);
				Assert.assertTrue(true, "Navigated on object successful - " + ObjectValue);
				setTimeOut(1000);
				return GetInstance(className);

			} catch (Exception e) {
				e.printStackTrace();
				Log.error("Navigation failed on object: " + ObjectValue + ". Error: " + e.getMessage());
				closeAppLauncher();
				retryCount++;
			}
		}

		throw new RuntimeException("Failed to select item from App Launcher after " + maxRetries + " retries.");
	}
	
	public <T> T openICareConnectApp(Class<T> className) {
	    String appTitleXpath = "//*[@title='iCare Connect']";
	    By appLogo = By.xpath(appTitleXpath);
	    String appName = "iCare Connect";

	    int maxRetries = 3;
	    int retryCount = 0;

	    while (retryCount < maxRetries) {
	        try {
	            waitForPageLoaded();
	            WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(10));

	            if (isElementPresent(appLogo)) {
	                Log.info(appName + " logo is visible. Already on the correct app.");
	                return GetInstance(className);
	            }

	            Log.info(appName + " logo not visible. Opening App Launcher...");
	            WebElement launcher = wait.until(ExpectedConditions.elementToBeClickable(eleAppLauncher));
	            launcher.click();

	            wait.until(ExpectedConditions.elementToBeClickable(eleViewAllLink)).click();

	            
	            Log.info("Searching for app: " + appName);
	            inputText(eleAppLauncherSearch, appName);

	            By appTileInLauncher = By.xpath("//one-app-launcher-app-tile[@data-name='" + appName + "']");
	            wait.until(ExpectedConditions.elementToBeClickable(appTileInLauncher)).click();

	            Log.info("Successfully opened " + appName + " app.");
	            return GetInstance(className);

	        } catch (Exception e) {
	            Log.error("Attempt #" + (retryCount + 1) + " failed to open " + appName + ": " + e.getMessage());
	            closeAppLauncher();
	            retryCount++;
	        }
	    }

	    throw new RuntimeException("Failed to open " + appName + " after " + maxRetries + " retries.");
	}


}
