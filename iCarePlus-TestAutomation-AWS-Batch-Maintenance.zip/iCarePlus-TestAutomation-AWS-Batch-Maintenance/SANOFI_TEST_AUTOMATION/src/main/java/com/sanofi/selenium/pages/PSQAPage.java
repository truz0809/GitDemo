package com.sanofi.selenium.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class PSQAPage extends Utility_Function {

	public PSQAPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	/************* Static Elements ******************************************/
	
	public static By elePageTitle = By.xpath(
			"//div[contains(@class,\"omniscript-body\")]//*[text()='PSQA Review']");
	public static By eleReviewOutcome = By.xpath(
			"//*[text()=\"Other\"]//parent::label//span");
	public static By elebutton = By.xpath("//*[text()='Submit']//parent::button");
	public static By arCHKBox = By.xpath(
			"//*[contains(@class,'active lafPageHost')]//span[text()=\"AR in Progress\"]//ancestor::span[@class=\"slds-checkbox\"]//input");
	
	/************* Dynamic Elements ******************************************/
	public static String strtextfield = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strReadOnlyFields="//*[text()=\"AR Specialist\"]//parent::div//following-sibling::div//span[contains(@class,'is-read-only')]";
	public static By submitButton = By.xpath("(//button[@ type='button']/span[text() = 'Submit'])[1]");
	public static By UpdatedCaseManagerAllignmentTextBox = By.xpath("//span[text() = 'Updated Case Manager Alignment']/../..//following-sibling::div//input[@ type = 'text']");

	public void verifyPSQAReviewPageTitle() 
	{
		try 
		{
			setTimeOut(10000);
			waitForPageLoaded();
			Log.info("Verify Prescription Information Page Present");
			waitAndVerifyElement(elePageTitle);
			LoggingInfo("Prescription Information Page is loaded");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail("Page load has Failed" + ". Error - " + e.getMessage());
		}
	}

	public void selectPSQAReviewCheckbox(String psqaReviewOutCome)
	{
		try
		{
		//By ProductTechincalComplaintCheckBox = By.xpath("//div[@ class = 'slds-has-error']//span[contains (text(), '"+psqaReviewOutCome+"')]//parent::label/span[@ class = 'slds-checkbox_faux']");
		By ProductTechincalComplaintCheckBox = By.xpath("//span[contains (text(), '"+psqaReviewOutCome+"')]//parent::label/span[@ class = 'slds-checkbox_faux']");
		waitAndVerifyElement(ProductTechincalComplaintCheckBox);
		selectCheckbox(ProductTechincalComplaintCheckBox);
		LoggingInfo("PSQA Review OutCome Checkox is checked");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail("PSQA Review OutCome Checkox is not checked"+ e.getMessage());
		}
	}
	

	public void enterCaseManagerName(String caseManagerName)
	{
		try
		{
			waitAndVerifyElement(UpdatedCaseManagerAllignmentTextBox); 
			scrollToElement(UpdatedCaseManagerAllignmentTextBox);
			inputText( UpdatedCaseManagerAllignmentTextBox ,  caseManagerName);			
			//click(UpdatedCaseManagerAllignmentTextBox);
			LoggingInfo("CaseManagerName is entered"); 
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
//			act.sendKeys(Keys.ENTER).perform();
//			setTimeOut(2000);
			 List<WebElement> dropDownOptions = getWebDriver().findElements(By.xpath("//div[contains(@ id, 'listboxId-')]/ul/li[@ role = 'presentation']/div/span/span"));
   			 System.out.println("Count :" +dropDownOptions.size());
   			 for(WebElement element : dropDownOptions)
   			 {
   				 String documentTypeName = element.getText();
   				 System.out.println(documentTypeName);
   				// scrollToWebElement(element);
   				 scrollToHalfPage();
   				 if(documentTypeName.contains(caseManagerName))
   				 {
   				  getWebDriver().findElement(By.xpath("//div[contains(@ id, 'listboxId-')]/ul/li[@ role = 'presentation']/div/span/span[contains(@ title, '"+caseManagerName+"')]")).click(); 
   				  break; 
   				 }
   			 }
   				LoggingInfo("The "+caseManagerName+" is selected from the drop-down");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Assert.fail("CaseManagerName is not entered"+ e.getMessage());
		}
	}


	public void clickOnSubmitButton() 
	{
		try 
		{
			waitAndVerifyElement(submitButton);
			scrollToElement(submitButton);
			clickByJavascript(submitButton);
			setTimeOut(4000);
			Log.info("Clicked on Submit Button");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Assert.fail("Failed to click on Submit Button-" + "Error - " + e.getMessage());
		}
	}



	public void verifyPSQAPageTitle() {
		try {

			setTimeOut(2000);
			waitForPageLoaded();
			Log.info("Verify PSQA Review Present");
			waitAndVerifyElement(elePageTitle);
			LoggingInfo("PSQA Review is loaded");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Page load has Failed" + ". Error - " + e.getMessage());

		}
	}


	 
	public void selectReviewOutcome() {
		try {

			setTimeOut(2000);
			waitForPageLoaded();
			waitAndVerifyElement(eleReviewOutcome);
			click(eleReviewOutcome);
			LoggingInfo("Review Outcome is selected");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Selection has Failed" + ". Error - " + e.getMessage());

		}
		
		
	}
	
	public void selectUpdatedCaseManager() {
	    try {

	    setTimeOut(3000);
		By eleUpdatedCaseManager = getDynamicElement(strtextfield, "Updated Case Manager Alignment");
		waitAndVerifyElement(eleUpdatedCaseManager);
		scrollToElement(eleUpdatedCaseManager);
		click(eleUpdatedCaseManager);
		
		inputText(eleUpdatedCaseManager, "Case");
		setTimeOut(5000);
		Actions actMemberPlan = new Actions(getWebDriver());
		actMemberPlan.sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
		// genericKeyPress(searchUserInput, "Enter");
		setTimeOut(3000);
		waitForPageLoaded();
		
		
	    } catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to enter Updated Case Manager"
					+ "Error - " + e.getMessage());
		}
	}
	
	public void clickSubmit() {
		try {

			setTimeOut(2000);
			waitForPageLoaded();
			waitAndVerifyElement(elebutton);
			scrollToElement(elebutton);
			click(elebutton);
			waitForPageLoaded();
			LoggingInfo("Submit is clicked");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Click Failed" + ". Error - " + e.getMessage());

		}
		
		
	}
	
	public void validateAR() {
		try {
			// AR in Progress?
			waitAndVerifyElement(arCHKBox);
			scrollToElement(arCHKBox);
			String checkBoxValue = getAttributeValue(arCHKBox, "checked");
			
		} catch (Exception e) {
			Log.error("Failed to validate DSR request" + e.getMessage());
			Assert.fail("Failed to validate DSR request " + e.getMessage());
		}
	}
	
	
	public void validateARSpecialistReadOnlyField() {

		
		try {
			setTimeOut(3000);

			By elearSpecialist = getDynamicElement(strReadOnlyFields, "AR Specialist");
			waitAndVerifyElement(elearSpecialist);
			scrollToElement(elearSpecialist);
			Assert.assertTrue(getAttributeValue(elearSpecialist, "class").contains("is-read-only"), "Field is  marked as read-only.");
			setTimeOut(2000);
				LoggingInfo("Care Program Product field is Read only field");
			
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify AR Specialist field is Read only field " + e.getMessage());
			Assert.fail("Failed to verify AR Specialist field is Read only field " + e.getMessage());
		}
	}
	
	public int verifyMedCases() {
		int numberOfMedCases = 0;
		try {
			List<WebElement> MedCases = getWebDriver().findElements(By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Cases\"]//tbody//tr//td//span[contains(text(),\"Med D AR\")]"));
			numberOfMedCases = MedCases.size();
			Log.info("Number of MedCases cases: " + numberOfMedCases);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Med cases " + e.getMessage());
			Assert.fail("Failed to verify Med cases " + e.getMessage());
		}
		return numberOfMedCases;
	}
	
	
}