package com.sanofi.selenium.pages;

import java.util.List;

import org.apache.commons.collections4.functors.CatchAndRethrowClosure;
import org.apache.groovy.parser.antlr4.GroovyParser.CatchClauseContext;
//import org.apache.http.util.Asserts;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.itextpdf.styledxmlparser.jsoup.select.Evaluator.IsEmpty;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class CareTeamAssignment extends Utility_Function {
	Actions act = new Actions(getWebDriver());

	public CareTeamAssignment(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	/************************
	 * Elements
	 **************************************************/
	public static By eleCareTeamMembers = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@title=\"Care Program Enrollee Team Members\"]");
	public static By logTitle = By.xpath("(//*[contains(@class,\"active lafPageHost\")]//lightning-formatted-text)[1]");
	public static By newCPETeamMember = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"New\"]//parent::a)[2]");

	public static By searchMember = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@placeholder=\"Search Service Resources...\"]");

	public static By startDate = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Date\"]//parent::label//parent::div//following-sibling::div//input)[1]");
	public static By eleShowMoreResult = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"Show more results for\")]");
	public static By eleSelectFirstCM = By
			.xpath("//*[text()=\"Select Item 1\"]//parent::label//*[@class=\"slds-radio_faux\"]");
	public static By eleSelectButton = By.xpath("//*[text()=\"Select\"]");
	public static By firstCMRecord = By.xpath("(//*[@data-label=\"Name\"]//lightning-base-formatted-text)[1]");
	/************************
	 * Dynamic Elements
	 **************************************************/
	public static String struserFields = "//*[text()=\"Case Manager\"]//parent::div//following-sibling::div//span//child::slot//span//span";
	public static String eleUserFields = "//*[text()=\"{0}\"]";
	public static String eleFRMCM = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::dt//following-sibling::dd";
	public static String eleLOG = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//ancestor::dt//following-sibling::dd//div[@class=\"slds-grid\"]//div";
	public static String logElements = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//child::lightning-formatted-text";
	public static String cpeLabel = "//*[contains(@class,\"active lafPageHost\")]*[text()=\"{0}\"]";
	public static String detailTabField = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::records-record-layout-item//a//span)[3]";
	public static String eleCPETables = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strDropDownBoxOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::*[@part=\"combobox\"]//*[@class=\"slds-media__body\"]//span";
	public static String strDropDownBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//button";
	public static String eleDetailsPageEditFields = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::*[contains(@class,\"slds-form-element\")]//button[contains(@class,\"test-id\")]";
	public static String eleClearSelectionButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::*[contains(@class,\"label-stacked\")]//*[@title=\"Clear Selection\"]";
	public static String elePrescriberFields = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::lightning-grouped-combobox//input";
	public static String elePrescriberDropdown = "//lightning-base-combobox-formatted-text[@title=\"{0}\"]//parent::span";
	public static String strAuthorizationieldButtons = "//button[text()=\"{0}\"]";
	public static String strManagerFields = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::records-record-layout-item//a//span)[3]";
	public static String eleSearchButton = "//*[contains(@class,\"active lafPageHost\")]//*[@data-omni-key=\"{0}\"]//button";
	public static String strHCPname = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::td//preceding-sibling::th//span)[1]";
	public static String strFacility = "(//*[contains(@class,\"active lafPageHost\")]//th[@data-cell-value=\"{0}\"]//ancestor::tr//span[contains(@class,\"slds-radio_faux\")])[1]";
	public static String eleAssignmentField = "(//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//ancestor::records-record-layout-item//span)[3]";
	public static String strCaseManager = "//*[text()=\"{0}\"]//ancestor::td//following-sibling::td[3]";
	public static String strFieldManager = "//table//tr//td//a[text()=\"{0}\"]//ancestor::td//following-sibling::td[4]";
	public static String strTextBoxesInput = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//following-sibling::div//input";

	// @Author - Anand P
	public void validateCMFRM() {
		try {

			By eleFRM = getDynamicElement(eleFRMCM, "Field Reimbursement Manager");
			waitAndVerifyElement(eleFRM);
			scrollToElement(eleFRM);
			highLightElement(eleFRM);
			setTimeOut(2000);
			LoggingInfo("User verifies Field Reimbursement Manager not assigned ");

			setTimeOut(2000);

			By eleCM = getDynamicElement(eleFRMCM, "Case Manager");
			waitAndVerifyElement(eleCM);
			scrollToElement(eleCM);
			highLightElement(eleCM);
			setTimeOut(2000);
			LoggingInfo("User verifies Case Manager/CM not assigned ");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to  verify CM/FRM " + e.getMessage());
			Assert.fail("Failed to verify  CM/FRM  " + e.getMessage());
		}
	}

	// @Author - Anand P
	public void validateLogRecordDetails() {
		try {
			setTimeOut(2000);
			By eleLog = getDynamicElement(detailTabField, "Assignment Details");
			waitAndVerifyElement(eleLog);
			scrollToElement(eleLog);
			clickByJavascript(eleLog);
			LoggingInfo("Validated and clicked on log record ");

			waitAndVerifyElement(logTitle);
			highLightElement(logTitle);
			setTimeOut(2000);

			By msg = getDynamicElement(logElements, "Exception Message");
			waitAndVerifyElement(msg);
			scrollToElement(msg);
			highLightElement(msg);
			setTimeOut(2000);

			By type = getDynamicElement(logElements, "Origin Type");
			waitAndVerifyElement(type);
			scrollToElement(type);
			highLightElement(type);
			setTimeOut(2000);

			By user = getDynamicElement(logElements, "User Profile");
			waitAndVerifyElement(user);
			scrollToElement(user);
			highLightElement(user);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate LOG record details " + e.getMessage());
			Assert.fail("Failed to validate LOG record details " + e.getMessage());
		}
	}

	/**
	 * Function: Validate CM user field (FRM User is decommisioned)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateCMFields() throws Exception {
		try {
			LoggingInfo("Validate CaseManager is not assigned");

			By strfieldCM = getDynamicElement(struserFields, "Case Manager");
			By elefieldCM = getDynamicElement(eleUserFields, "Case Manager");

			scrollToElement(elefieldCM);
			String fieldTextCM = getText(strfieldCM).trim();
			if (fieldTextCM.isEmpty()) {
				LoggingInfo("CaseManager is not assigned");
			} else {
				LoggingInfo(fieldTextCM + " User has been assigned");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate CM Field " + e.getMessage());
			Assert.fail("Failed to validate CM Field " + e.getMessage());
		}
	}

	/**
	 * Function: Validate assignment details are populated
	 * 
	 * @author Trupti
	 **/
	public void verifyASGNDetailsField() {
		try {
			Log.info("Verifying if Assignment Details field is present");
			scrollToHalfPage();
			By assignmentField = getDynamicElement(cpeLabel, "Assignment Details");
			boolean isFieldPresent = isElementPresent(assignmentField);
			Assert.assertTrue(isFieldPresent, "Assignment Details field is present");
			LoggingInfo("Assignment Details field is present");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify field presence: " + e.getMessage());
			Assert.fail("Failed to verify field presence: " + e.getMessage());
		}
	}

	/**
	 * Function: Get log number
	 * 
	 * @author Trupti
	 **/
	public String getLogNumber() {
		String logNumber = null;
		try {
			By eleLogNumber = getDynamicElement(detailTabField, "Assignment Details");
			waitAndVerifyElement(eleLogNumber);
			scrollToElement(eleLogNumber);
			logNumber = getText(eleLogNumber);
			Assert.assertTrue(!logNumber.isEmpty(), "Assignment details are not present");
			LoggingInfo("Assignment details- " + logNumber);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to retrieve log number: " + e.getMessage());
			Assert.fail("Failed to retrieve log number: " + e.getMessage());
		}
		return logNumber;
	}

	/**
	 * Function: Verify FRM is not assigned FRM user decomissioned - no need to
	 * verify
	 * 
	 * @author Trupti
	 **/
	public void verifyNoFRMIsAssigned() {
		try {
			scrollToPixel(0, 500);
			By frm = By.xpath(
					"//*[contains(@class,'active lafPageHost')]//*[contains(@class,'slds-grid')]//*[text()='Field Reimbursement Manager']//ancestor::dt//following-sibling::dd//a");
			boolean frmFound = isElementPresent(frm);
			Assert.assertFalse(frmFound, "Field Reimbursement Manager is assigned");
			LoggingInfo("FRM is not assigned to CPE");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify if FRM is assigned: " + e.getMessage());
			Assert.fail("Failed to verify if FRM is assigned: " + e.getMessage());
		}
	}

	/**
	 * Function: Verify CM is assigned
	 * 
	 * @author Trupti
	 **/
	public void verifyCMIsAssigned() {
		try {
			scrollToPixel(0, 700);
			By cm = By.xpath(
					"(//*[contains(@class,'active lafPageHost')]//*[contains(@class,'slds-grid')]//*[text()='Case Manager']//ancestor::records-record-layout-item//a//span)[3]");
			scrollToElement(cm);
			boolean cmFound = isElementPresent(cm);
			Assert.assertTrue(cmFound, "Case Manager");
			LoggingInfo("CM is assigned to CPE");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify if CM is assigned: " + e.getMessage());
			Assert.fail("Failed to verify if CM is assigned: " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to CPE team members
	 * 
	 * @author Trupti
	 **/
	public void navigateToCPETeamMembers() {
		try {
			Log.info("Navigate to CPE team members Table");
			By cpeTeamMembersTable = getDynamicElement(eleCPETables, "Care Program Enrollee Team Members");
			waitAndVerifyElement(cpeTeamMembersTable);
			scrollToElement(cpeTeamMembersTable);
			LoggingInfo("Navigated to CPE team members table");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify field presence: " + e.getMessage());
			Assert.fail("Failed to verify field presence: " + e.getMessage());
		}
	}

	/**
	 * Function:Click on new button
	 * 
	 * @author Trupti
	 **/
	public void clickOnNewButton() {
		try {
			waitAndVerifyElement(newCPETeamMember);
			scrollToElement(newCPETeamMember);
			clickByJavascript(newCPETeamMember);
			LoggingInfo("Clicked on new button");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify field presence: " + e.getMessage());
			Assert.fail("Failed to verify field presence: " + e.getMessage());
		}
	}

	/**
	 * Function:Enroll team member
	 * 
	 * @author Trupti
	 **/
	public String enrollTeamMember(String role) {
		String caseManager = null;
		try {

			// Member
			waitForPageLoaded();
			waitAndVerifyElement(searchMember);
			inputText(searchMember, "SR");
			waitAndVerifyElement(eleShowMoreResult);
			clickByJavascript(eleShowMoreResult);
			waitAndVerifyElement(eleSelectFirstCM);
			click(eleSelectFirstCM);

			// get cm name
			waitAndVerifyElement(firstCMRecord);
			caseManager = getText(firstCMRecord);

			scrollToElement(eleSelectButton);
			click(eleSelectButton);
			setTimeOut(2000);
			LoggingInfo("Successfully added Member");

			// select Program Role
			By programRoleDropDown = getDynamicElement(strDropDownBox, "Program Role");
			waitAndVerifyElement(programRoleDropDown);
			scrollToElement(programRoleDropDown);
			click(programRoleDropDown);
			By programRoleDropDownOptions = getDynamicElement(strDropDownBoxOptions, "Program Role");
			waitAndVerifyElement(programRoleDropDownOptions);
			selectItemFromList(programRoleDropDown, programRoleDropDownOptions, role, "Program Role");

			// StartDate
			waitAndVerifyElement(startDate);
			scrollToElement(startDate);
			String startdate = getDateNDaysFromToday(0);
			inputText(startDate, startdate);

			By saveBtn = getDynamicElement(strAuthorizationieldButtons, "Save");
			click(saveBtn);
			setTimeOut(5000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enroll team memebers: " + e.getMessage());
			Assert.fail("Failed to enroll team memebers: " + e.getMessage());
		}
		return caseManager;
	}

	/**
	 * Function:Compare logs
	 * 
	 * @author Trupti
	 **/

	public void compareLogs(String existingLog, String newlog) {
		try {

			String existingAssLog = existingLog.split("-")[1];
			String newAssLog = newlog.split("-")[1];
			boolean isNewLogGreater = Integer.parseInt(newAssLog) > Integer.parseInt(existingAssLog);
			if (isNewLogGreater) {
				Log.info("New log id is created " + newlog + " is created.");
			} else {
				Log.info("New log id is created " + newlog + " is not created.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to compare logs: " + e.getMessage());
			Assert.fail("Failed to compare logs: " + e.getMessage());
		}
	}

	/**
	 * Function:Update HCP details
	 * 
	 * @author Trupti
	 **/

	public void updateHCPRecord() {
		try {

			By hcpRecord = getDynamicElement(eleDetailsPageEditFields, "Prescriber");
			waitAndVerifyElement(hcpRecord);
			scrollToElement(hcpRecord);
			click(hcpRecord);
			setTimeOut(1000);

			By hcpClearSelection = getDynamicElement(eleClearSelectionButton, "Prescriber");
			waitAndVerifyElement(hcpClearSelection);
			click(hcpClearSelection);
			act.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
			setTimeOut(2000);
			waitForPageLoaded();
			LoggingInfo("Successfully added HCP details");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to compare logs: " + e.getMessage());
			Assert.fail("Failed to compare logs: " + e.getMessage());
		}
	}

	/**
	 * Function:Validate CaseManager/FieldManager fields.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public String validateManagerField(String requiredManagerField) throws Exception {
		try {
			By strfield = getDynamicElement(strManagerFields, requiredManagerField);
			String fieldManagerText = getInnerTextByJavascript(strfield);

			if (!fieldManagerText.isEmpty()) {
				LoggingInfo(requiredManagerField + "  is assigned");
			} else {
				LoggingInfo(" User has not been assigned");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate CM and FRM Field " + e.getMessage());
			Assert.fail("Failed to validate CM and FRM Field " + e.getMessage());
		}
		return requiredManagerField;

	}

	/**
	 * Function:Validate CaseManager
	 * 
	 * @author Anand Pawar
	 **/
	public String validateCMField(String requiredManagerField) throws Exception {

		String fieldManagerText = "";
		try {
			By strfield = getDynamicElement(strManagerFields, requiredManagerField);
			By elefield = getDynamicElement(eleUserFields, requiredManagerField);

			scrollToElement(elefield);
			fieldManagerText = getText(strfield);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate CM and FRM Field " + e.getMessage());
			Assert.fail("Failed to validate CM and FRM Field " + e.getMessage());
		}
		return fieldManagerText;

	}

	/**
	 * Function:Validate Assignment Field has no Logs Created
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateNoLogIsCreated() throws Exception {
		try {

			setTimeOut(2000);
			By eleLog = getDynamicElement(eleAssignmentField, "Assignment Details");
			waitAndVerifyElement(eleLog);
			scrollToElement(eleLog);
			boolean logDetails = getInnerTextByJavascript(eleLog).isEmpty();
			Assert.assertTrue(logDetails, "No Log is created in Assigmnet Details Field");
			LoggingInfo("Validated Log details in Assignment Field is empty");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Assignment Field Log details " + e.getMessage());
			Assert.fail("Failed to validate Assignment Field Log details " + e.getMessage());
		}

	}

	/**
	 * Function: Update Prescriber name and site details.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void updatePrescriberAndSiteDetails(String prescriberSite) throws Exception {
		try {

			By siteRecord = getDynamicElement(eleDetailsPageEditFields, "Site");
			waitAndVerifyElement(siteRecord);
			scrollToElement(siteRecord);
			click(siteRecord);
			setTimeOut(1000);

			By hcpClearSelectionSIte = getDynamicElement(eleClearSelectionButton, "Site");
			waitAndVerifyElement(hcpClearSelectionSIte);
			click(hcpClearSelectionSIte);

			By prescriberSiteField = getDynamicElement(elePrescriberFields, "Site");
			inputText(prescriberSiteField, prescriberSite);
			By prescriberSiteDropdown = getDynamicElement(elePrescriberDropdown, prescriberSite);
			setTimeOut(2000);
			click(prescriberSiteDropdown);

			By saveBtn = getDynamicElement(strAuthorizationieldButtons, "Save");
			click(saveBtn);
			setTimeOut(5000);

			Log.info("Prescrier Site details updated successfully.");
			refresh();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to update HCP and HCO details " + e.getMessage());
			Assert.fail("Failed to update HCP and HCO details " + e.getMessage());
		}

	}

	/**
	 * Function:
	 * 
	 * @author Anand Pawar
	 **/
	public void editSiteName(String site) throws Exception {
		try {

			By siteRecord = By
					.xpath("//*[contains(@class,\"active lafPageHost\")]//button[@title=\"Edit Account Name\"]");
			waitAndVerifyElement(siteRecord);
			scrollToElement(siteRecord);
			clickByJavascript(siteRecord);
			setTimeOut(1000);

			By eleSite = getDynamicElement(strTextBoxesInput, "Account Name");
			scrollToElement(eleSite);
			waitAndVerifyElement(eleSite);
			inputText(eleSite, site);
			setTimeOut(2000);

			By eleTaxId = getDynamicElement(strTextBoxesInput, "Tax id");
			click(eleTaxId);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on CareTeamEnrollee Table " + e.getMessage());
			Assert.fail("Failed to click on CareTeamEnrollee Table " + e.getMessage());
		}

	}

	/**
	 * Function: Update site details.
	 * 
	 * @author Anand Pawar
	 **/
	public void updateSiteDetails(String siteName) throws Exception {
		try {

			By siteRecord = By.xpath("//*[contains(@class,\"active lafPageHost\")]//button[@title=\"Edit Site\"]");
			waitAndVerifyElement(siteRecord);
			scrollToElement(siteRecord);
			clickByJavascript(siteRecord);
			setTimeOut(1000);

//			By hcpClearSelectionSIte = getDynamicElement(eleClearSelectionButton, "Site");
//			waitAndVerifyElement(hcpClearSelectionSIte);
//			clickByJavascript(hcpClearSelectionSIte);
//			setTimeOut(1000);

			Actions act = new Actions(getWebDriver());
			By prescriberSiteField = getDynamicElement(elePrescriberFields, "Site");
			setTimeOut(3000);
			inputText(prescriberSiteField, siteName);
			setTimeOut(4000);

			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(4000);

			By saveBtn = getDynamicElement(strAuthorizationieldButtons, "Save");
			click(saveBtn);
			setTimeOut(5000);

			LoggingInfo("Site Details Updated");

			Log.info("Prescrier Site details updated successfully.");
			refresh();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to update Site details " + e.getMessage());
			Assert.fail("Failed to update Site details " + e.getMessage());
		}

	}

	/**
	 * Function: compare the previous and active CM and FRM owners.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void compareManagerNames(String managerName, String updatedManagerName) {
		LoggingInfo("Validate If New Case Manager and Field Manager is assigned");
		try {
			if (!managerName.equals(updatedManagerName)) {
				if (managerName.contains("Case")) {
					Log.info("New Case Manager Has been assigned");
				} else if (managerName.contains("Field")) {
					Log.info("New Field Manager Has been assigned");
				}
			} else {
				Log.info("CM/FM  Fields are not been updated");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Manager Field text " + e.getMessage());
			Assert.fail("Failed to validate Manager Field text " + e.getMessage());

		}

	}

	/**
	 * Function: click on CareTeamEnrolleeMembers table.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void clickOnCareTeamMemberEnrolle() throws Exception {
		try {

			scrollToElement(eleCareTeamMembers);
			setTimeOut(2000);
			clickByJavascript(eleCareTeamMembers);
			setTimeOut(3000);
			Log.info("Care Team Enrollee Table opened");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on CareTeamEnrollee Table " + e.getMessage());
			Assert.fail("Failed to click on CareTeamEnrollee Table " + e.getMessage());
		}

	}

	/**
	 * Function: click on CareTeamEnrolleeMembers table.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void clickOnCareTeamMember() throws Exception {
		try {
			By eleCTM = By
					.xpath("//*[contains(@class,\"active lafPageHost\")]//span[contains(text(), 'CTM-')]//ancestor::a");
			scrollToElement(eleCTM);
			setTimeOut(2000);
			clickByJavascript(eleCTM);
			setTimeOut(3000);
			Log.info("Care Team Enrollee Table opened");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on CareTeamEnrollee Table " + e.getMessage());
			Assert.fail("Failed to click on CareTeamEnrollee Table " + e.getMessage());
		}

	}

	/**
	 * Function: Validate Previous CM and FRM owners deactivated.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateExistingCMandFRMDeactivated(String searchMemberName) throws Exception {
		try {
			By checkboxActive = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//table[@aria-label ='Care Program Enrollee Team Members' and@role='grid']//tr/td[@data-col-key-value='MemberName_ICC__c-formulaOutputFormulaHtml-4']//lightning-formatted-rich-text/span[text()='"
							+ searchMemberName
							+ "']//ancestor::td//following-sibling::td[@data-col-key-value='Active_ICC__c-lstCheckbox-6']//span[@part='input-checkbox']/input");
			boolean isExistingOwnerDeactivated = isCheckboxSelected(checkboxActive);
			Assert.assertTrue(isExistingOwnerDeactivated, "Existing Owners Deactivated");
			LoggingInfo("Previously assigned " + searchMemberName + "is Deactivated");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Active Checkbox " + e.getMessage());
			Assert.fail("Failed to validate Active Checkbox " + e.getMessage());
		}

	}

	/**
	 * Function: Verify MI case Owner name.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void checkMICaseOwner(String caseOwnerName) throws Exception {
		By eleMissingInfoTable = By
				.xpath("//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Cases\"]//tbody//tr");

		if (verifytable("Cases")) {
			List<WebElement> rows = getWebDriver().findElements(eleMissingInfoTable);
			if (rows.size() > 0) {
				for (WebElement row : rows) {
					WebElement statusElement = row.findElement(By.xpath("//td[@data-label='Subject']"));
					statusElement.click();
					By ele = By.xpath(
							"//div/p[@title='Case Owner']//following-sibling::p//span[@class='slds-truncate']/slot");
					String onwer = getInnerTextByJavascript(ele);
					if (onwer.contains(caseOwnerName)) {
						LoggingInfo("MI Case Owner name is updated as Current/Active Case Manager.");
					}
					break;
				}
			} else {
				Log.info("No MI Cases Found.");
			}
		}
	}

	/**
	 * Function: validate CPE work order owner names( CM and FRM). FRM is
	 * decomissioned
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateCPEownerName(String recordName, String caseManager) throws Exception {
		try {

			By eleCPECaseManager = getDynamicElement(strCaseManager, recordName);
			String CPECaseManagerName = getInnerTextByJavascript(eleCPECaseManager);
			if (CPECaseManagerName.contains(caseManager)) {
				Log.info("Active Case Manager has been assigned");
			}

//			By eleCPEFieldManager = getDynamicElement(strFieldManager, recordName);
//			String CPEFieldManagerName = getInnerTextByJavascript(eleCPEFieldManager);
//			if (CPEFieldManagerName.contains(fieldManager)) {
//				Log.info("Active Field Manager has been assigned");
//			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate CPE Owner" + e.getMessage());
			Assert.fail("Failed to validate CPE Owner: " + e.getMessage());
		}

	}

	/**
	 * Function: Search and select HCP and HCO patient record in Enrollement form.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void selectHCPrecord(String hcpName, String hcoOfficeContactName) throws Exception {

		try {
			By btnHCPsearch = getDynamicElement(eleSearchButton, "iccHCPSearch");
			scrollToElement(btnHCPsearch);
			clickByJavascript(btnHCPsearch);
			setTimeOut(3000);
			By rcrdHCP = getDynamicElement(strHCPname, hcpName);
			click(rcrdHCP);

			By btnFacilitySerach = getDynamicElement(eleSearchButton, "FacilityContactSearchIP");
			scrollToElement(btnFacilitySerach);
			clickByJavascript(btnFacilitySerach);
			setTimeOut(3000);
			By rcrdFacility = getDynamicElement(strHCPname, hcoOfficeContactName);
			click(rcrdFacility);

			Log.info("HCP and HCO Patient record selected.");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select HCP records " + e.getMessage());
			Assert.fail("Failed to select HCP records " + e.getMessage());
		}

	}

	// Trupti
	public void clickOnSaveButton() {
		try {
			By saveBtn = getDynamicElement(strAuthorizationieldButtons, "Save");
			click(saveBtn);
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on save button " + e.getMessage());
			Assert.fail("Failed to click on save button " + e.getMessage());
		}
	}

	/**
	 * Function: Update HCP(Prescriber) and HCO(Site) details on CPE details page.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void updateHCPandHCO(String prescriberName, String prescriberSite) {
		try {

			By hcpRecord = getDynamicElement(eleDetailsPageEditFields, "Prescriber");
			waitAndVerifyElement(hcpRecord);
			scrollToElement(hcpRecord);
			click(hcpRecord);
			setTimeOut(1000);

			By prescriberNameField = getDynamicElement(elePrescriberFields, "Prescriber");
			inputText(prescriberNameField, prescriberName);
			setTimeOut(2000);
			By prescriberNameDropdown = getDynamicElement(elePrescriberDropdown, prescriberName);
			click(prescriberNameDropdown);

			By prescriberSiteField = getDynamicElement(elePrescriberFields, "Site");
			inputText(prescriberSiteField, prescriberSite);
			By prescriberSiteDropdown = getDynamicElement(elePrescriberDropdown, prescriberSite);
			setTimeOut(2000);
			click(prescriberSiteDropdown);

			By saveBtn = getDynamicElement(strAuthorizationieldButtons, "Save");
			click(saveBtn);
			setTimeOut(5000);

			LoggingInfo("HCP and HCO related details updated successfully.");
			refresh();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to update HCP and HCO details " + e.getMessage());
			Assert.fail("Failed to update HCP and HCO details " + e.getMessage());
		}
	}

}
