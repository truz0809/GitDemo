package com.sanofi.selenium.pages;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.sanofi.selenium.constants.TestData;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class CareProgramEnrolleePage extends Utility_Function implements TestData {
	public CareProgramEnrolleePage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	Actions act = new Actions(getWebDriver());
	String memberPlanText;
	Random random = new Random();
	String[] firstNames = TestData.firstNames;
	String[] lastNames = TestData.lastNames;
	String firstName = firstNames[random.nextInt(firstNames.length)];
	String lastName = lastNames[random.nextInt(lastNames.length)];
	String fullName = firstName + " " + lastName;

	/************************* Elements *************************/

	// public static By eleCareProgramDropdown = By.xpath("//button[@title='Select a
	// List View: Care Program Enrollees']");
	public static By eleCareProgramDropdown = By.xpath("//*[@title='Select a List View: Care Program Enrollees']");

	public static By eleSearchDocInput = By.xpath("//*[@placeholder=\"Search this list...\"]");
	// public static By eleCareProgramEnrolleefield =
	// By.xpath("//input[contains(@placeholder,'Search Care Program Enrollee')]");
	public static By eleCareProgramEnrolleefield = By
			.xpath("//*[contains(@placeholder,'Search Care Program Enrollee')]");

	// public static By eleCaseManagerfield =
	// By.xpath("//input[contains(@placeholder,'Search People')]");
	public static By eleCaseManagerfield = By.xpath("//*[contains(@placeholder,'Search People')]");

	// public static By eleReviewoption = By.xpath("//button[@aria-label='Reviewed
	// by CM']");
	public static By eleReviewoption = By.xpath("//*[@aria-label='Reviewed by CM']");

	// public static By eleSavebutton = By.xpath("//button[@name='SaveEdit']");
	public static By eleSavebutton = By.xpath("//*[@name='SaveEdit']");

	public static By eleBVCaptureStatus = By.xpath(
			"//*[text()='Review and Finalize Benefit']//parent::div//following-sibling::ul//span[text()='Not Started']");
	// public static By eleRequiredStatus = By.xpath("//span[text()='Required']");
	public static By eleRequiredStatus = By.xpath("//*[text()='Required']");

	// public static By eleReviewandFinalizeBenefit = By.xpath("//h2[text()='Review
	// and Finalize Benefit']");
	public static By eleReviewandFinalizeBenefit = By.xpath("//*[text()='Review and Finalize Benefit']");

	public static String eleBVIcon = "(//*[local-name()='svg' and @class='slds-icon' and @data-key='work_type'])[1]";
	public static By eleErrorMessage = By.xpath(
			"//*[text()='Select a task related to a care program enrollee work order step that’s in progress.']");
	// public static By eleSaveButton = By.xpath("(//span[text()='Save'])[2]");
	public static By eleSaveButton = By.xpath("//*[@ data-omni-key='SaveCoverageBenefit']//span[text() = 'Save']");
	// public static By eleCompleteRecord =
	// By.xpath("(//span[text()='Complete'])[1]");
	public static By eleCompleteRecord = By.xpath("(//*[text()='Complete'])[1]");

	// public static By eleReviewAndSummaryOfBenefits =
	// By.xpath("//h2[text()='Review and Send Summary of Benefits']");
	public static By eleReviewAndSummaryOfBenefits = By.xpath("//*[text()='Review and Send Summary of Benefits']");

	// public static By eleReviewAndSummaryOfBenefitsRequired =
	// By.xpath("(//span[text()='Required'])[2]");
	public static By eleReviewAndSummaryOfBenefitsRequired = By.xpath("(//*[text()='Required'])[2]");

	public static By eleOutcomeReason = By.xpath(
			"//*[contains(@class,\"slds-combobox\")]//*[text()='Outcome Reason']//parent::label//parent::div//following-sibling::div");
	public static By eleOutcomeReasonDropdown = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"Outcome Reason\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]");
	// public static By eleSaveOutcome = By.xpath("(//span[text()='Save'])[1]");
	public static By eleSaveOutcome = By.xpath("//*[@ data-omni-key='SaveMemberPlan']//span[text() = 'Save']");

	// public static By eleBVSummaryState = By.xpath("(//span[text()='Done'])[4]");
	public static By eleBVSummaryState = By.xpath("//*[text()='Done']");

	// public static By eleBVSummaryCompletedState =
	// By.xpath("(//span[text()='Completed'])[2]");
	public static By eleBVSummaryCompletedState = By.xpath("//*[text()='Completed']");

	public static By eleCPEWorkOrder = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Care Program Enrollee Work Order\"]");
	public static By eleStatus = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[@title=\"Status\"]//parent::div//lightning-formatted-text");
	// public static By listViewButton = By.xpath("//button[@title=\"Select a List
	// View: Care Program Enrollees\"]");
	public static By listViewButton = By.xpath("//*[@title=\"Select a List View: Care Program Enrollees\"]");

	// public static By listViewButtonCorres = By.xpath("//button[@title=\"Select a
	// List View: Master Correspondence Sets\"]");
	public static By listViewButtonCorres = By.xpath("//*[@title=\"Select a List View: Master Correspondence Sets\"]");

	// public static By listViewButtonCases = By.xpath("//button[@title=\"Select a
	// List View: Cases\"]");
	public static By listViewButtonCases = By.xpath("//*[@title=\"Select a List View: Cases\"]");

	public static By refreshButton = By.xpath("//*[contains(@class,'active lafPageHost')]//button[text()='Refresh']");

	public static String listViewOptions = "//*[text()=\"{0}\"]//parent::a";
	public static By eleNameList = By.xpath("//*[contains(@class,\"active lafPageHost\")]//td[3]//a");
	// public static By searchDocInput = By.xpath("//input[@placeholder=\"Search
	// this list...\"]");
	public static By searchDocInput = By.xpath("//*[@placeholder=\"Search this list...\"]");

	// public static By eleSaveDetails = By
	// .xpath("(//*[contains(@class,\"active
	// lafPageHost\")]//span[text()=\"Save\"]//parent::button)[1]");
	public static By eleSaveDetails = By.xpath("//*[contains(@class, 'active lafPageHost')]//button[@name='SaveEdit']");
	public static By eleSaveDetails1 = By.xpath("//*[text()='Save']//parent::button");
	public static By createdDateColumn = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Created Date\"]//parent::a");
	public static By lastModifiedColumn = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::a");
	public static By createdDateSortState = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Created Date\"]//parent::a//following-sibling::span[@class=\"slds-assistive-text\"]");
	public static By lastModifiedDateSortState = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")//*[text()=\"Last Modified Date\"]//parent::a//following-sibling::span[@class=\"slds-assistive-text\"]");
	public static By createdDateColumnLink = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Created Date\"]//parent::a");
	public static By LastModifiedDateSortState = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Last Modified Date\"]//parent::a//following-sibling::span)[2]");
	public static By LastModifiedDateColumn = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Last Modified Date\"]//parent::a");
	// public static By listViewButtonCorres = By.xpath("//button[@title=\"Select a
	// List View: Master Correspondence Sets\"]");
	// public static String orderNumberButton
	// ="(//table//tr[td[normalize-space()=\"{0}\"]]//th[@data-label=\"Order
	// Number\"]//a)[1]";
	public static String orderNumberButton = "(//*//tr[td[normalize-space()=\"{0}\"]]//th[@data-label=\"Order Number\"]//a)[1]";

	public static By patientList = By.xpath("//*[contains(@class,\"active lafPageHost\")]//td[4]//a");
	// public static By medlistViewButton = By.xpath("//button[@title=\"Select a
	// List View: Medication Dispenses\"]");
	public static By medlistViewButton = By.xpath("//*[@title=\"Select a List View: Medication Dispenses\"]");

	// public static By orderlistViewButton = By.xpath("//button[@title=\"Select a
	// List View: Orders\"]");
	public static By orderlistViewButton = By.xpath("//*[@title=\"Select a List View: Orders\"]");

	public static By dsrAccount = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Account\"]/ancestor::div[contains(@class,\"slds-form-element\")]//a//span//slot//span//slot//span");

	// public static By onHoldCHKbox =
	// By.xpath("//input[@name=\"OnHold_ICC__c\"]//following-sibling::span");
	public static By onHoldCHKbox = By.xpath("//*[@name=\"OnHold_ICC__c\"]//following-sibling::span");

	// public static By onHoldCheckBox =
	// By.xpath("//input[@name=\"OnHold_ICC__c\"]");
	public static By onHoldCheckBox = By.xpath("//*[@name=\"OnHold_ICC__c\"]");

	public static By bvCap = By.xpath("//span[@title='BV Capture']");
	
			/************************* Dynamic Elements *************************/
	public static String strNewCaseButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";
	// public static String strBVStatus = "//div[text()=\"{0}\"]";
	public static String strBVStatus = "//*[text()=\"{0}\"]";

	// public static String strReviewAndFinalizeBenefitSection =
	// "//h3[text()=\"{0}\"]";
	public static String strReviewAndFinalizeBenefitSection = "//*[text()=\"{0}\"]";

	// public static String strTextBoxesInput =
	// "//span[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strTextBoxesInput = "//*[contains (text(),\"{0}\")]//parent::label//parent::div//following-sibling::div//input";

	// public static String strMemberPlans =
	// "(//span[contains(text(),\"{0}\")])[1]";
	public static String strMemberPlans = "//*[@aria-label='* Member Plan']/div[@role = 'listbox']//div//span[contains(text(),\"{0}\")]";

	public static By eleMemberPlanDropdown = By.xpath(
			"((//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Member Plan\"])[2]//ancestor::runtime_omnistudio_omniscript-omniscript-lookup//following-sibling::runtime_omnistudio_omniscript-omniscript-select)[1]//child::input");
	public static String strSubHeadingText = "//*[contains(text(),\"{0}\") and @class = 'slds-truncate']";
	public static String strCoverageBenefitFieldList = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[contains(text(),\"{0}\")]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]";
	public static String strCoverageBenefitFieldsText = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[contains(text(),\"{0}\")]//parent::label//parent::div//following-sibling::div//child::input";
	public static String strBVHeading = "//*[text()=\"{0}\"]";
	public static String strOutcomeDropdown = "//*[contains(text(),\"{0}\")]//parent::label//parent::div//following-sibling::div//child::div//child::div//following-sibling::div//ul/li//div//span//span";
	public static String strSearchBarDropdown = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[contains(text(),\"{0}\")]//parent::label//parent::div//following-sibling::div[contains(@class,\"slds-form-element__control\")]//input";
	public static String eleButton = "//*[contains(@class,\"active lafPageHost\")]//button[@title=\"{0}\"]";
	public static String strDocumentPageTitle = "//*[text()=\"{0}\"]";
	public static String viewAllButton = "//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"{0}\")]//parent::span[text()=\"View All\"]";
	// public static String strRecordName = "//*[contains(@class,\"active
	// lafPageHost\")]//*[contains(@class,\"slds-cell-edit
	// cellContainer\")]//*[text()=\"{0}\"]";
	public static String strRecordName = "//*[@ role='row']//th[@ data-label='Name']/span/div//a[contains(@title ,\"{0}\")]";

	public static String taskButton = "//*[contains(@class,\"slds-section__title\")]//*[text()=\"{0}\"]//parent::div//*[@part=\"boundary\"]";
	public static String subTaskButton = "//*[@class=\"card\"]//h2[text()=\"{0}\"]//parent::div";
	public static String strDropDownBoxOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//div[contains(@class,\"slds-listbox\")]//span[@ class = 'slds-media__body']/span";
	public static String strDropDownBox = "//*[contains(@class,\"active lafPageHost\")]//lightning-combobox//*[text()=\"{0}\"]//parent::div//button[contains(@class,\"slds-combobox\")]";
	public static String strAccountObjectDetailsLink = "(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::lightning-helptext//following-sibling::div//child::span//child::slot//child::span[contains(text(), 'DMW ')])[1]";
	public static String eleDetailsPageEditFields = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//ancestor::div[contains(@class,\"slds-form-element\")]//button[contains(@class,\"test-id\")]";
	public static String eleButton2 = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";
	public static String fieldBtn = "//button[@aria-label=\"{0}\"]";
	public static String dropDownValues = "//button[@aria-label=\"{0}\"]//parent::div//following-sibling::div//lightning-base-combobox-item[@role=\"option\"]//span[@class=\"slds-media__body\"]//child::span";
	public static String eleCM = "//table//td[@data-label=\"Member Name\"]//span//child::span[text()=\"{0}\"]";
	public static String strTaskName = "//*[contains(@class,\"active lafPageHost\")]//h3[@class=\"slds-section__title\"]//span[text()=\"{0}\"]";
	public static String strSubtaskName = "//*[contains(@class,\"active lafPageHost\")]//div[@class=\"card\"]//h2[text()=\"{0}\"]";
	public static String strSubTaskStatus = "(//*[contains(@class,\"active lafPageHost\")]//div[@class=\"card\"]//h2[text()=\"{0}\"]//parent::div//li)[2]";
	public static String payerRecord = "(//*[contains(@class,\"active lafPageHost\")]//td//*[contains(text(),\"{0}\")])[1]";
	public static String eleField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strDetailsTabTextField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//parent::dt//following-sibling::dd//lightning-formatted-text";
	public static String strInputBpx = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static By quickActionsButton = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//lightning-button-menu[contains(@class,\"menu-button\")]//button");
	public static String eleDetails = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-text";
	public static String strReadOnlyFields = "(//*[text()=\"Care Program Product\"]//parent::div//following-sibling::div//span[contains(@class,'is-read-only')])[2]";
	public static String editbutton = "//*[@title=\"{0}\"]";
	// public static String correspondanceRecord = "//td[@data-label=\"Business
	// Process/ Functional
	// Name\"]//span[text()=\"{0}\"]//ancestor::td//preceding-sibling::th//a";
	public static String correspondanceRecord = "//*[@data-label='Correspondence Name']//span[contains (text(),\"{0}\")]//ancestor::div/a";

	public static String strActionLocator = "//*[contains(@class,\"active lafPageHost\")]//lightning-button-menu//span[text()=\"{0}\"]//parent::a ";
	public static String strDropDownInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li";
	public static By moreActions = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[contains(@title,\"more actions\")]");
	
		public static By nameColumn = By.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='Name']//parent::a");
	public static By nameSortState = By.xpath("//*[contains(@class, 'active lafPageHost')]//*[text()='Name']//parent::a//following-sibling::span[@class='slds-assistive-text']");

	/**
	 * Function: Verify BV Capture State
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyBVCaptureState() {

		try {
			setTimeOut(2000);
			By eleBVCapture = getDynamicElement(strBVStatus, "BV Capture");
			clickByJavascript(eleBVCapture);
			setTimeOut(2000);
			waitAndVerifyElement(eleReviewandFinalizeBenefit);
			waitAndVerifyElement(eleRequiredStatus);
			waitAndVerifyElement(eleBVCaptureStatus);
			setTimeOut(2000);

			LoggingInfo("verified ‘Review and Finalize Benefit’  section and is in Not Started state initially");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify ‘Review and Finalize Benefit’  section and its initially state  "
					+ e.getMessage());
			Assert.fail("Failed to verify ‘Review and Finalize Benefit’  section and its initially state" + ". Error - "
					+ e.getMessage());
		}
	}

		/**
	 * Function: Check Name column sorting
	 * 
	 * @author a.a.rajendra.chandak
	 **/

	public void checkNameColumnSorting() 
	{
		try 
		{
			waitAndVerifyElement(nameColumn);
			String sortingState;
			sortingState = getText(nameSortState);
			if(sortingState.isBlank())
			{
				click(nameColumn);
			}
			setTimeOut(1000);
			//String sortingState;
			//sortingState = getText(nameSortState);
			//while (sortingState != null && !sortingState.contains("Sorted Descending")) {
			while (sortingState != null && sortingState.contains("Sorted Descending")) 
			{
				clickByJavascript(nameSortState);
				setTimeOut(1000);
				sortingState = getText(nameSortState);
			}

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Log.error("Failed to check column sorting. Error -" + e.getMessage());
			Assert.fail("Failed to check column sorting. Error - " + e.getMessage());
		}
	}




	/**
	 * Function : Sort any column 
	 * 
	 * @author a.a.rajendra.chandak
	 */
	public void sortTheRespectiveColumn(String columnName) 
	{

		try 
		{
		waitForPageLoaded();
		setTimeOut(2000);
		//By columnNameElement = By.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='"+columnName+"']//parent::a");
		By columnNameElement = By.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='"+columnName+"']//parent::a/../span");
		waitAndVerifyElement(columnNameElement);
		String sortingState;
		sortingState = getText(columnNameElement);
		if(sortingState.isBlank())
		{
		click(columnNameElement);
		}
			//click(nameColumn);
		setTimeOut(1000);
			//String sortingState;

			//sortingState = getText(nameSortState);

			//while (sortingState != null && !sortingState.contains("Sorted Descending")) {
			while (sortingState != null && sortingState.contains("Sorted Ascending")) 
			{
				clickByJavascript(nameSortState);
				setTimeOut(1000);
				sortingState = getText(nameSortState);
			}					
			}
		catch (Exception e) 
		{
			e.printStackTrace();
			Log.error("Failed to check column sorting. Error -" + e.getMessage());
			Assert.fail("Failed to check column sorting. Error - " + e.getMessage());
		}
		}





	/**
	 * Function: Verify Member plan section
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyMemberPlanSection(String pharmacypayerName, String medicalPayerName) { // check this again

		try {
			setTimeOut(4000);
			By elepharmacypayerName = getDynamicElement(strMemberPlans, pharmacypayerName);
			memberPlanText = getAttributeValue(elepharmacypayerName, "value");
			waitAndVerifyElement(elepharmacypayerName);
			LoggingInfo("verified Pharmacy Payer Name Field");
			setTimeOut(4000);
			By elemedicalPayerName = getDynamicElement(strMemberPlans, medicalPayerName);
			waitAndVerifyElement(elemedicalPayerName);
			LoggingInfo("verified Medical Payer Name Field");
			setTimeOut(4000);
			LoggingInfo("verified Member Plan section Fields");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Member Plan section Fields " + e.getMessage());
			Assert.fail("Failed to verify Member Plan section Fields" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Verify Medicare Part D section
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyMedicarePartDSection() {

		try {
			LoggingInfo("verify to edit Medicare PartD Section");
			setTimeOut(4000);
			By eleMedicarePartD = getDynamicElement(strSubHeadingText, "Medicare Part D");
			setTimeOut(2000);
			waitAndVerifyElement(eleMedicarePartD);
			click(eleMedicarePartD);
			setTimeOut(2000);
			LoggingInfo("Verified Medicare PartD Section");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Medicare PartD Section " + e.getMessage());
			Assert.fail("Failed to verify Medicare PartD Section" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Verify PA Required
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyThePARequired(String paOptionYes, String paOptionNo) {

		try {
			LoggingInfo("verify to select PA Required option as  Yes and Prior authorization section is displayed");
			setTimeOut(4000);

			// waitAndVerifyElement(elePriorAuthorization);

			setTimeOut(4000);
			By elePARequired = getDynamicElement(strCoverageBenefitFieldsText, "PA required?");
			waitAndVerifyElement(elePARequired);
			By elePARequiredlist = getDynamicElement(strCoverageBenefitFieldList, "PA required?");
			click(elePARequired);
			selectItemFromList(elePARequired, elePARequiredlist, paOptionNo, "PA required?");
			LoggingInfo("verified to select PA Required as NO");
			setTimeOut(4000);
			click(elePARequired);
			selectItemFromList(elePARequired, elePARequiredlist, paOptionYes, "PA required?");
			setTimeOut(4000);
			By elePriorAuthorization = getDynamicElement(strSubHeadingText, "Prior Authorization");
			setTimeOut(2000);
			click(elePriorAuthorization);
			setTimeOut(4000);
			By elePAOutcome = getDynamicElement(strTextBoxesInput, "PA Outcome");
			waitAndVerifyElement(elePAOutcome);
			setTimeOut(4000);

			LoggingInfo("Verified PA Required section ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify PA Required section" + e.getMessage());
			Assert.fail("Failed to verify PA Required section" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Verify PA Required and not on File
	 * 
	 * @author Kavyashree MB
	 */

	public void VerifyPARequiredAndNotonFile(String notOnFile) {

		try {
			LoggingInfo("verify to select PA ROutcome option as  Not on File ");

			setTimeOut(4000);
			By elePAOutcome = getDynamicElement(strCoverageBenefitFieldsText, "PA Outcome");
			waitAndVerifyElement(elePAOutcome);
			By elePAOutcomelist = getDynamicElement(strCoverageBenefitFieldList, "PA Outcome");

			click(elePAOutcome);
			selectItemFromList(elePAOutcome, elePAOutcomelist, notOnFile, "PA Outcome");
			setTimeOut(4000);
			By elePARequiredAndNotOnFile = getDynamicElement(strSubHeadingText, "PA Required & Not on File");
			waitAndVerifyElement(elePARequiredAndNotOnFile);
			setTimeOut(4000);

			LoggingInfo("Verified PA Required Not on File section ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify PA Required Not on File" + e.getMessage());
			Assert.fail("Failed to verify PA Required Not on File" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Navigate too all Correspondences
	 * 
	 * @author Anand Pawar
	 **/

	public void navigateToAllCorrespondences() {

		try {
			Log.info("Navigate to all correspondences");
			click(listViewButtonCorres);

			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, "All");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

			LoggingInfo("Navigated to all correspondences");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to All Care Program Enrollees " + e.getMessage());
			Assert.fail("Failed to navigate to All Care Program Enrollees " + e.getMessage());
		}

	}

	/**
	 * Function: Verify Save Button
	 * 
	 * @author Kavyashree MB
	 */

	public void verifySaveButton() {

		try {
			LoggingInfo("verify to Save Button ");
			waitAndVerifyElement(eleSaveButton);
			click(eleSaveButton);
			LoggingInfo("Verified Save Button ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Save Button" + e.getMessage());
			Assert.fail("Failed to verify Save Button" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Verify Complete Record
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyToCompleteRecord() {

		try {
			LoggingInfo("verify to complete Record ");

			LoggingInfo("verify to Save Button ");
			waitAndVerifyElement(eleCompleteRecord);
			click(eleCompleteRecord);
			setTimeOut(8000);
			LoggingInfo("Verified to complete record");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Complete Record" + e.getMessage());
			Assert.fail("Failed to verify Complete Record" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Navigate to Correspondence Tab
	 * 
	 * @author Anand Pawar
	 *
	 * 
	 *         public void navigateToAllCorresTab() { try { By
	 *         tab=By.xpath("//span[text()=\"All | Master Correspondence
	 *         Sets\"]//parent::a"); waitAndVerifyElement(tab);
	 *         scrollToElement(tab); clickByJavascript(tab); setTimeOut(2000);
	 *         LoggingInfo("Navigated to All Correspondence tab"); setTimeOut(5000);
	 *         } catch (Exception e) { e.printStackTrace(); Log.error("Failed to
	 *         navigate" + e.getMessage()); Assert.fail("Failed to navigate " +
	 *         e.getMessage()); } }
	 */

	/**
	 * Function: Click on first Correspondence record
	 * 
	 * @author Anand Pawar
	 *
	 * 
	 *         public void clickOnFirstCorresRecord() { try { setTimeOut(2000); By
	 *         record= By.xpath("(//th[@data-label=\"Master Correspondence Set
	 *         Number\"]//a)[1]"); waitAndVerifyElement(record); setTimeOut(1000);
	 *         clickByJavascript(record); setTimeOut(2000); }catch(Exception e) {
	 *         e.printStackTrace(); Log.error("Failed to click: " + e.getMessage());
	 *         Assert.fail("Failed to click: " + e.getMessage()); }
	 * 
	 *         }
	 */

	/**
	 * Function: Verify navigate to BV Summary section
	 * 
	 * @author Kavyashree MB
	 */

	public void navigateToBVSummarySection() {

		try {
			setTimeOut(3000);
			Actions act = new Actions(getWebDriver());
			WebElement BVIcon = getWebDriver().findElement(By.xpath(eleBVIcon));
			act.moveToElement(BVIcon).click(BVIcon).perform();
			setTimeOut(4000);
			setTimeOut(2000);
			By eleBVCapture = getDynamicElement(strBVStatus, "BV Capture");
			clickByJavascript(eleBVCapture);
			setTimeOut(2000);
			By eleCompletedState = getDynamicElement(strBVStatus, "Completed");
			waitAndVerifyElement(eleCompletedState);
			setTimeOut(2000);
			LoggingInfo("Verified BV Captured as completed");
			setTimeOut(2000);
			By eleBVSummary = getDynamicElement(strBVStatus, "BV Summary");
			setTimeOut(2000);
			waitAndVerifyElement(eleBVSummary);
			LoggingInfo("Verified BV Summary section");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify BV Summary section" + e.getMessage());
			Assert.fail("Failed to verify BV Summary section" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Verify Review and send summary section
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyReviewAndSendSummarySection() {

		try {
			setTimeOut(2000);
			By eleBVSummary = getDynamicElement(strBVStatus, "BV Summary");
			waitAndVerifyElement(eleBVSummary);
			scrollToElement(eleBVSummary);
			clickByJavascript(eleBVSummary);
			setTimeOut(3000);
			LoggingInfo("Verified BV Summary");
			setTimeOut(3000);
			waitAndVerifyElement(eleReviewAndSummaryOfBenefits);
			setTimeOut(3000);
			waitAndVerifyElement(eleReviewAndSummaryOfBenefitsRequired);
			clickByJavascript(eleReviewAndSummaryOfBenefitsRequired);
			setTimeOut(4000);
			LoggingInfo("Verified BV Review and Summary Benefits section");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify BV Review and send summary section" + e.getMessage());
			Assert.fail("Failed to verify BV Review and send summary section" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Verify BV Outcome section
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyBVOutcomeSection() {

		try {
			setTimeOut(3000);
			By eleReviewAndSummaryOfBenefitsHeading = getDynamicElement(strBVHeading,
					"Review and Send Summary of Benefits");
			waitAndVerifyElement(eleReviewAndSummaryOfBenefitsHeading);
			scrollToElement(eleReviewAndSummaryOfBenefitsHeading);
			setTimeOut(3000);
			LoggingInfo("Verified BV Review and Summary of Benefits heading");
			setTimeOut(3000);
			By eleOutcomeHeading = getDynamicElement(strBVStatus, "Outcome");
			waitAndVerifyElement(eleOutcomeHeading);
			setTimeOut(3000);
			LoggingInfo("Verified Outcome Field");
			setTimeOut(3000);
			By eleOutcomReasonHeading = getDynamicElement(strBVStatus, "Outcome Reason");
			waitAndVerifyElement(eleOutcomReasonHeading);
			setTimeOut(3000);
			LoggingInfo("Verified Outcome Reason Field");
			setTimeOut(3000);

			LoggingInfo("Verified BV Outcome section");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify  BV Outcome section" + e.getMessage());
			Assert.fail("Failed to verify BV Outcome  section" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Verify to Select Covered Picklist on Outcome Field and User should
	 * be able to view and select No Restrictions value for Covered picklist on
	 * Outcome Reason field.
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyToSelectCovered(String outcomeOption, String outcomeReasonOption) {

		try {
			setTimeOut(6000);
			By eleOutcome = getDynamicElement(strSearchBarDropdown, "Outcome");
			setTimeOut(4000);
			click(eleOutcome);
			setTimeOut(4000);
			By eleOutcomeDropdown = getDynamicElement(strOutcomeDropdown, "Outcome");
			setTimeOut(4000);
			selectItemFromList(eleOutcome, eleOutcomeDropdown, outcomeOption, "Covered");
			setTimeOut(4000);
			LoggingInfo("Verified to select covered option on Outcome field");
			setTimeOut(4000);
			click(eleOutcomeReason);
			setTimeOut(4000);
			selectItemFromDropDown(eleOutcomeReason, eleOutcomeReasonDropdown, outcomeReasonOption);
			setTimeOut(6000);

			LoggingInfo("Verified No Restriction option on Outcome Reason field");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Select Covered Picklist on Outcome Field" + e.getMessage());
			Assert.fail("Failed to Select Covered Picklist on Outcome Field" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Verify to Select Covered with Restrictions Picklist on Outcome
	 * Field and User should be able to view and select PA Required value for
	 * Covered picklist on Outcome Reason field.
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyToSelectCoveredWithRestrictions(String outcomeOption, String outcomeReasonOption) {

		try {
			setTimeOut(6000);
			By eleOutcome = getDynamicElement(strSearchBarDropdown, "Outcome");
			setTimeOut(4000);
			click(eleOutcome);
			setTimeOut(4000);
			By eleOutcomeDropdown = getDynamicElement(strOutcomeDropdown, "Outcome");
			setTimeOut(4000);
			selectItemFromList(eleOutcome, eleOutcomeDropdown, outcomeOption, "Covered with Restrictions");
			setTimeOut(4000);
			LoggingInfo("Verified to select covered with Restriction option on Outcome field");
			setTimeOut(4000);
			click(eleOutcomeReason);
			setTimeOut(4000);
			selectItemFromDropDown(eleOutcomeReason, eleOutcomeReasonDropdown, outcomeReasonOption);
			setTimeOut(6000);

			LoggingInfo("Verified PA Required option on Outcome Reason field");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Select Covered with Restriction Picklist on Outcome Field" + e.getMessage());
			Assert.fail("Failed to Select Covered with Restriction Picklist on Outcome Field" + ". Error - "
					+ e.getMessage());

		}

	}

	/**
	 * Function: Verify to Select Not Covered Picklist on Outcome Field and User
	 * should be able to view and select Underinsured value for covered picklist on
	 * Outcome Reason field.
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyToSelectNotCovered(String outcomeOption, String outcomeReasonOption) {

		try {
			setTimeOut(6000);
			By eleOutcome = getDynamicElement(strSearchBarDropdown, "Outcome");
			setTimeOut(4000);
			click(eleOutcome);
			setTimeOut(4000);
			By eleOutcomeDropdown = getDynamicElement(strOutcomeDropdown, "Outcome");
			setTimeOut(4000);
			selectItemFromList(eleOutcome, eleOutcomeDropdown, outcomeOption, "Not Covered");
			setTimeOut(4000);
			LoggingInfo("Verified to select Not Covered with Restriction option on Outcome field");
			setTimeOut(4000);
			click(eleOutcomeReason);
			setTimeOut(4000);
			selectItemFromDropDown(eleOutcomeReason, eleOutcomeReasonDropdown, outcomeReasonOption);
			setTimeOut(6000);

			LoggingInfo("Verified Underinsured option on Outcome Reason field");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Select Not Covered  Picklist on Outcome Field" + e.getMessage());
			Assert.fail("Failed to Select Not Covered Picklist on Outcome Field" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Verify to Select Unable to Complete Picklist on Outcome Field and
	 * User should be able to view and select Third Party Restriction value for
	 * Covered picklist on Outcome Reason field.
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyToSelectUnabletoComplete(String outcomeOption, String outcomeReasonOption) {

		try {
			setTimeOut(6000);
			By eleOutcome = getDynamicElement(strSearchBarDropdown, "Outcome");
			setTimeOut(4000);
			click(eleOutcome);
			setTimeOut(4000);
			By eleOutcomeDropdown = getDynamicElement(strOutcomeDropdown, "Outcome");
			setTimeOut(4000);
			selectItemFromList(eleOutcome, eleOutcomeDropdown, outcomeOption, "Unable to Complete");
			setTimeOut(4000);
			LoggingInfo("Verified to select Unable to Complete option on Outcome field");
			setTimeOut(4000);
			click(eleOutcomeReason);
			setTimeOut(4000);
			selectItemFromDropDown(eleOutcomeReason, eleOutcomeReasonDropdown, outcomeReasonOption);
			setTimeOut(6000);

			LoggingInfo("Verified Third Party Restriction option on Outcome Reason field");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Select Unable to Complete  Picklist on Outcome Field" + e.getMessage());
			Assert.fail(
					"Failed to Select Unable to Complete Picklist on Outcome Field" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: STEP 13: Verify to Select Uninsured Picklist on Outcome Field then
	 * Outcome Reason field hides from UI.
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyToSelectUninsured(String outcomeOption) {

		try {
			setTimeOut(3000);
			By eleOutcome = getDynamicElement(strSearchBarDropdown, "Outcome");
			setTimeOut(3000);
			click(eleOutcome);
			setTimeOut(3000);
			By eleOutcomeDropdown = getDynamicElement(strOutcomeDropdown, "Outcome");
			setTimeOut(3000);
			selectItemFromList(eleOutcome, eleOutcomeDropdown, outcomeOption, "Uninsured");
			setTimeOut(3000);
			LoggingInfo("Verified to select Not Covered with Restriction option on Outcome field");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Select Not Covered  Picklist on Outcome Field" + e.getMessage());
			Assert.fail("Failed to Select Not Covered Picklist on Outcome Field" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Verify to Select Covered with Restrictions Picklist on Outcome
	 * Field and User should be able to view and select PA Required value for
	 * Covered picklist on Outcome Reason field.
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyToSaveDetails(String outcomeOption, String outcomeReasonOption) {

		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleSaveOutcome);
			scrollToElement(eleSaveOutcome);
			click(eleSaveOutcome);
			setTimeOut(4000);
			LoggingInfo("Verified Save button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to save details" + e.getMessage());
			Assert.fail("Failed to save details" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Verify BV Summary section is marked as DONE after the record is
	 * saved, and upon expanding it should be in Completed state.
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyToBVSummaryStatusAsDone() {

		try {
			setTimeOut(8000);
			Actions act = new Actions(getWebDriver());
			WebElement BVIcon = getWebDriver().findElement(By.xpath(eleBVIcon));
			act.moveToElement(BVIcon).click(BVIcon).perform();
			setTimeOut(6000);
			waitAndVerifyElement(eleBVSummaryState);
			setTimeOut(4000);
			LoggingInfo("Verified BV summary Done state");
			setTimeOut(4000);
			By eleBVSummary = getDynamicElement(strBVStatus, "BV Summary");
			waitAndVerifyElement(eleBVSummary);
			clickByJavascript(eleBVSummary);
			setTimeOut(4000);
			waitAndVerifyElement(eleBVSummaryCompletedState);
			setTimeOut(4000);
			LoggingInfo("Verified BV Summary done status ");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify BV Summary done status " + e.getMessage());
			Assert.fail("Failed to verify BV Summary done status" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Verify Back Navigation
	 * 
	 * @author Kavyashree MB
	 */

	public void verifyToBVSummaryNavigateBack() {

		try {
			setTimeOut(4000);
			LoggingInfo("verify to Navigate Back");
			clickByJavascript(eleBVSummaryCompletedState);
			setTimeOut(4000);
			waitAndVerifyElement(eleErrorMessage);
			setTimeOut(8000);
			LoggingInfo("Verified to Navigate Back");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to  Navigate Back" + e.getMessage());
			Assert.fail("Failed to Navigate Back" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Check whether cpe record is active
	 * 
	 * @author Trupti Zure
	 **/
	public void checkStatusOfCPERecord(String status) {
		try {
			scrollToHalfPage();
			;
			scrollToPixel(0, 250);
			setTimeOut(2000);
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			verifyDetails(eleStatus, status, "Care program enrollee status");
			LoggingInfo("Verified care program enrollee status");
		} catch (Exception e) {
			Log.error("Failed to verify CPE record status  " + e.getMessage());
			Assert.fail("Failed to verify CPE record status  " + e.getMessage());
		}

	}

	/**
	 * Function: Navigate too all Correspondences
	 * 
	 * @author Anand Pawar
	 *
	 * 
	 *         public void navigateToAllCorrespondences() {
	 * 
	 *         try { Log.info("Navigate to all correspondences");
	 *         click(listViewButtonCorres);
	 * 
	 *         By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
	 *         waitAndVerifyElement(eleSearch); clickByJavascript(eleSearch);
	 *         inputText(eleSearch, "All"); Actions act = new
	 *         Actions(getWebDriver()); act.sendKeys(Keys.DOWN).perform();
	 *         setTimeOut(2000); act.sendKeys(Keys.ENTER).perform();
	 *         setTimeOut(2000);
	 * 
	 *         LoggingInfo("Navigated to all correspondences"); } catch (Exception
	 *         e) { e.printStackTrace(); Log.error("Failed to navigate to All Care
	 *         Program Enrollees " + e.getMessage()); Assert.fail("Failed to
	 *         navigate to All Care Program Enrollees " + e.getMessage()); }
	 * 
	 *         }
	 */

	/**
	 * Function: Navigate too all Care program enrollee list view
	 * 
	 * @author Trupti Zure
	 **/

	public void navigateToAllCPE() {

		try {
			Log.info("Navigate to all care program enrollee worklist");
			click(listViewButton);

			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, "All Care Program Enrollees");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

//			waitForPageLoaded();
//			By allCPEList = getDynamicElement(strDocumentPageTitle, "All Care Program Enrollees");
//			waitAndVerifyElement(allCPEList);
//			clickByJavascript(allCPEList);
//			setTimeOut(2000);
			LoggingInfo("Navigated to All Care Program Enrollees Worklist");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to All Care Program Enrollees " + e.getMessage());
			Assert.fail("Failed to navigate to All Care Program Enrollees " + e.getMessage());
		}

	}

	// Anand
	/*
	 * public void navigateToAllCPECaseManager() {
	 * 
	 * try { Log.info("Navigate to all care program enrollee worklist");
	 * click(listViewButton);
	 * 
	 * By eleSearch=By.xpath("//*[@placeholder='Search lists...']");
	 * //*[@placeholder=\"Search this list...\"] waitAndVerifyElement(eleSearch);
	 * clickByJavascript(eleSearch);
	 * inputText(eleSearch,"All Care Program Enrollees"); Actions act=new
	 * Actions(getWebDriver()); act.sendKeys(Keys.DOWN).perform(); setTimeOut(2000);
	 * act.sendKeys(Keys.ENTER).perform(); setTimeOut(2000);
	 * 
	 * } catch (Exception e) { e.printStackTrace();
	 * Log.error("Failed to navigate to All Care Program Enrollees " +
	 * e.getMessage());
	 * Assert.fail("Failed to navigate to All Care Program Enrollees " +
	 * e.getMessage()); }
	 * 
	 * }
	 */

	/**
	 * Function: Click on view all button
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnViewAll(String tablename) {
		try {

			By viewAllbutton = getDynamicElement(viewAllButton, tablename);
			waitAndVerifyElement(viewAllbutton);
			scrollToElement(viewAllbutton);
			setTimeOut(4000);
			waitForPageLoaded();
			waitForelementToBeClickable(viewAllbutton);
			setTimeOut(2000);
			clickByJavascript(viewAllbutton);
			LoggingInfo("Clicked on view all button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on view all button " + e.getMessage());
			Assert.fail("Failed to click on view all button " + e.getMessage());
		}
	}

	/**
	 * Function: Click on new member button
	 * 
	 * @author Anand P
	 **/

	public void clickOnNewBtn() {
		try {

			By newMemBtn = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//div[@title=\"New\"]//parent::a[@role=\"button\"]");
			waitAndVerifyElement(newMemBtn);
			scrollToElement(newMemBtn);
			setTimeOut(4000);
			clickByJavascript(newMemBtn);
			LoggingInfo("Clicked on new button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on new button " + e.getMessage());
			Assert.fail("Failed to click on new button " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to my care program enrollees list view
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToMyCPE() {

		try {
			Log.info("Navigate to My Care Program Enrollees worklist");
			click(listViewButton);
			waitForPageLoaded();
			By myCPEList = getDynamicElement(strDocumentPageTitle, "My Care Program Enrollees");
			waitAndVerifyElement(myCPEList);
			clickByJavascript(myCPEList);
			setTimeOut(2000);
			LoggingInfo("Navigated to My Care Program Enrollees Worklist");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to My Care Program Enrollees " + e.getMessage());
			Assert.fail("Failed to navigate to My Care Program Enrollees " + e.getMessage());
		}

	}

	/**
	 * Function: Search record in CPE list view
	 * 
	 * @author Trupti Zure
	 **/
	public void searchRecord(String record) {
		try {
			click(searchDocInput);
			inputText(searchDocInput, record);
			genericKeyPress(searchDocInput, "Enter");
			waitForPageLoaded();
			setTimeOut(4000);
			LoggingInfo("Search for record :" + record);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed search record" + e.getMessage());
			Assert.fail("Failed search record" + e.getMessage());

		}
	}

	public void clickOnCorrespondanceRecord(String businessProcess) {
		try {
			setTimeOut(3000);
			By corresRecord = getDynamicElement(correspondanceRecord, businessProcess);
			waitAndVerifyElement(corresRecord);
			setTimeOut(1000);
			clickByJavascript(corresRecord);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click: " + e.getMessage());
			Assert.fail("Failed to click: " + e.getMessage());
		}

	}

	/**
	 * Function: Click on CPE record from all CPE list view
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnRecord(String name) {
		try {
			By record = getDynamicElement(strRecordName, name);
			waitAndVerifyElement(record);
			clickByJavascript(record);
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed click on record" + e.getMessage());
			Assert.fail("Failed click on record" + e.getMessage());

		}
	}

	/**
	 * Function: Click on Open Case
	 * 
	 * @author Anand Pawar
	 **/
	public void clickOnOpenCase() {
		try {
			By record = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//span[@title=\"Open\"]//ancestor::td//preceding-sibling::th//a");
			waitAndVerifyElement(record);
			scrollToElement(record);
			clickByJavascript(record);
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed click on record" + e.getMessage());
			Assert.fail("Failed click on record" + e.getMessage());

		}
	}

	/**
	 * Function: Click on Open Case
	 * 
	 * @author Anand Pawar
	 **/
	public void navigateTolinkedCPE() {
		try {
			By record = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Care Program Enrollee\"]//parent::div//following-sibling::div//a");
			waitAndVerifyElement(record);
			clickByJavascript(record);
			setTimeOut(5000);
			LoggingInfo("Navigated to linked Patient CPE");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed click on CPE" + e.getMessage());
			Assert.fail("Failed click on CPE" + e.getMessage());

		}
	}

	/**
	 * Function: Validate MI Page Field
	 * 
	 * @author Anand Pawar
	 **/
	public String validateMIPageFields() {
		String miTitle = "";
		try {

			List<String> topFields = Arrays.asList("Status", "Account Name", "Care Program Enrollee",
					"HCP Account Name");
			verifyFieldsPresence(topFields);

			// scrollToBottomOfPage();

			List<String> bottomFields = Arrays.asList("Collected Date", "Collected Channel");
			By scrollEle = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"3rd Attempt\"]");
			scrollToElement(scrollEle);
			verifyFieldsPresence(bottomFields);

			LoggingInfo("Verified all required fields are present on the MI page.");

			By miTitleField = By.xpath(
					"//*[contains(@class,'active lafPageHost')]//*[text()='Subject']//parent::div//following-sibling::div//lightning-formatted-text");
			miTitle = getText(miTitleField).trim();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate MI Page fields: " + e.getMessage());
			Assert.fail("Failed to validate MI Page fields: " + e.getMessage());
		}
		return miTitle;
	}

	/**
	 * Function: Helper method to verify field presence
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyFieldsPresence(List<String> fields) throws InterruptedException {
		for (String field : fields) {
			By record = getDynamicElement(eleField, field);
			waitAndVerifyElement(record);
			scrollToElement(record);
			highLightElement(record);
		}
	}

	/**
	 * Function: Click on CPE record from all CPE list view
	 * 
	 * @author Anand Pawar
	 **/
	public void validateProgramRole() {
		try {
			List<WebElement> li = getWebDriver().findElements(
					By.xpath("(//span[contains(@title, 'Case Manager')])[2]"));
			////*[@ aria-label='All Care Program Enrollees']/tbody/tr/th[@data-label='Name']/span//a
			for (WebElement element : li) {
				String eleText = element.getText();

				if (eleText.contains("Case Manager")) {
					LoggingInfo("CM Found ");
				} else {
					System.out.println("Text does not match: " + eleText);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed validate program role" + e.getMessage());
			Assert.fail("Failed validate program role" + e.getMessage());

		}
	}

	/**
	 * Function:Verify New Button Removed
	 * 
	 * @author Anand Pawar
	 **/
	public void verifyNewButtonRemoved() {
		try {
			WebElement eleNewBtn = getWebDriver().findElement(
					By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"New\"]//parent::button"));
			Assert.assertFalse(eleNewBtn.isDisplayed(), "New Button should not be visible");
			setTimeOut(2000);
		} catch (Exception e) {
			// e.printStackTrace();
			LoggingInfo("Verified New Button Removed");
		}
	}

	/**
	 * Function: validateStartEndDate
	 * 
	 * @author Anand Pawar
	 **/

	public void validateNewActiveCM() { // check this
		try {

			By cm = By.xpath("//*[@data-label=\"Member Name\"]//span//child::span");
			waitAndVerifyElement(cm);
			scrollToElement(cm);
			highLightElement(cm);
			setTimeOut(3000);

			By activeBox = By.xpath("//*[@data-label='Active']//child::div[@ class = 'slds-truncate']");
			waitAndVerifyElement(activeBox);
			scrollToElement(activeBox);
			highLightElement(activeBox);

			LoggingInfo("Validtated New Active CM");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Validation unsuccessful " + e.getMessage());
			Assert.fail("Validation unsuccessful " + e.getMessage());
		}
	}

	/**
	 * Function: validateStartEndDate
	 * 
	 * @author Anand Pawar
	 **/

	public void validateStartEndDate() { // check this
		try {
			By eleDate = By.xpath("//*[@data-label=\"End Date\"]//span//child::span");
			waitAndVerifyElement(eleDate);
			scrollToElement(eleDate);
			highLightElement(eleDate);
			setTimeOut(3000);

			String fullDateTime = getText(eleDate);
			String datePart = fullDateTime.substring(0, fullDateTime.indexOf(","));
			LoggingInfo("End date : " + datePart);

			By eleDate2 = By.xpath("//*[@data-label=\"Start Date\"]//span//child::span");
			waitAndVerifyElement(eleDate2);
			scrollToElement(eleDate2);
			highLightElement(eleDate2);
			setTimeOut(3000);

			String fullDateTime2 = getText(eleDate);
			String datePart2 = fullDateTime2.substring(0, fullDateTime2.indexOf(","));
			LoggingInfo("Start date : " + datePart2);

			Assert.assertEquals(datePart, datePart2,
					"End Date of Old CPE Team Member matches with Start Date of New CPE Team Member");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Validate date unsuccessful " + e.getMessage());
			Assert.fail("Validate date unsuccessful " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to new case button
	 * 
	 * @author Anand Pawar
	 **/

	public void clickOnNewButton() {
		try {
			By btn = By.xpath("//*[@name='New']");
			waitAndVerifyElement(btn);
			scrollToElement(btn);
			setTimeOut(3000);
			clickByJavascript(btn);
			// scrollToBottomOfPage();
			LoggingInfo("Clicked on new button");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Click unsucccessful " + e.getMessage());
			Assert.fail("Click unsucccessful " + e.getMessage());
		}
	}

	/**
	 * Function: Enter CPE Team Member data
	 * 
	 * @author Anand Pawar
	 **/
	public void enterCPETeamMemData() {
		try {
			// By elepatientFNameInput =
			// By.xpath("//label[text()=\"Member\"]//following-sibling::div//input");
			By manualOverridechkbox = By.xpath("//*[@name='ManualAssignment_ICC__c']");
			By elepatientFNameInput = By.xpath("//*[@placeholder='Search Service Resources...']");
					
					//"//*[text()='Member']//ancestor::table[@aria-label='Care Program Enrollee Team Members']//tbody//td[contains(@data-col-key-value,'Member_ICC__r.Name-forceLookup')]//a");

			click(manualOverridechkbox);
			setTimeOut(1000);
			scrollToElement(elepatientFNameInput);
			waitAndVerifyElement(elepatientFNameInput);
			click(elepatientFNameInput);
			inputText(elepatientFNameInput, "SR");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);
			By button = By.xpath("//span[@class='slds-radio_faux']");
			click(button);
			setTimeOut(2000);

			By selectButton = By.xpath("//button[text()=\"Select\"]");
			click(selectButton);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Function: Select new Program Role and date
	 * 
	 * @author Anand Pawar
	 **/

	public void selectProgramRoleAndStartDate(String role) { // check this again
		try {
			waitForPageLoaded();
			Log.info("Select status");
			setTimeOut(3000);
			By outcomeBtn = getDynamicElement(fieldBtn, "Program Role");
			waitAndVerifyElement(outcomeBtn);
			scrollToElement(outcomeBtn);
			clickByJavascript(outcomeBtn);
			setTimeOut(2000);
			By options = getDynamicElement(dropDownValues, "Program Role");
			selectItemFromDropDown(outcomeBtn, options, role);
			LoggingInfo("Role selected as-" + role);

			By inputDate = By.xpath("(//label[text()='Date']//following-sibling::div//input)[1]");
			String date = rearrangeDateFormatToMMddyyyy(
					LocalDate.now().format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
			inputText(inputDate, date);
			setTimeOut(4000);

			By inputTime = By.xpath("(//label[text()='Time']//following-sibling::div//input)[1]");
			click(inputTime);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select outcome" + e.getMessage());
			Assert.fail("Failed to select" + e.getMessage());
		}

	}

	/**
	 * Function: Search and open record from all CPE list view
	 * 
	 * @author Trupti Zure
	 **/
	public String searchAndOpenCPERecord() {
		String name = null;
		try {
			Random random = new Random();
			waitAndVerifyElement(eleNameList);
			List<WebElement> listOptions = getWebDriver().findElements(eleNameList);
			List<String> nameTextList = new ArrayList<>();

			for (int i = 0; i < listOptions.size(); i++) {
				nameTextList.add(listOptions.get(i).getAttribute("title"));
			}

			String[] names = new String[nameTextList.size()];
			for (int j = 0; j < names.length; j++) {
				names[j] = nameTextList.get(j);
			}
			name = names[random.nextInt(names.length)];
			searchRecord(name);
			setTimeOut(2000);
			LoggingInfo("Search record on care program enrollees list-" + name);
			setTimeOut(2000);
			clickOnRecord(name);
			setTimeOut(2000);
			LoggingInfo("Clicked on record-" + name);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Search record on care program enrollees list " + e.getMessage());
			Assert.fail("Failed to Search record on care program enrollees list " + e.getMessage());
		}
		return name;

	}

	/**
	 * Function: Click on work order eg Benifit verification , Triage etc
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnWorkOrderTask(String taskName) {
		try {
			setTimeOut(3000);
			By woButton = getDynamicElement(eleButton, taskName);
			waitAndVerifyElement(woButton);
			scrollToElement(woButton);
			setTimeOut(1000);
			clickByJavascript(woButton);
			LoggingInfo("Clicked on work order task-" + taskName);
			setTimeOut(3000);
		} catch (Exception e) {
			Log.error("Failed to Click on -" + taskName + e.getMessage());
			Assert.fail("Failed to Click on -" + taskName + e.getMessage());
		}
	}

	/**
	 * Function: Click on Refresh button of work order
	 *
	 * @author Shraddha Shetty
	 **/

	public void clickOnWorkOrderRefresh() {
		try {
			waitAndVerifyElement(refreshButton);
			scrollToElement(refreshButton);
			clickByJavascript(refreshButton);
			LoggingInfo("Clicked on Refresh button of work order");
			waitAndVerifyElement(refreshButton);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Refresh progress bar " + e.getMessage());
			Assert.fail("Failed to Refresh progress bar" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Click on main task of any work order
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnMainTask(String taskName) {
		try {
			setTimeOut(3000);
			By eleMainTaskButton = getDynamicElement(taskButton, taskName);
			scrollToElement(eleMainTaskButton);
			click(eleMainTaskButton);
			//clickByJavascript(bvCap);
			LoggingInfo("Clicked on task-" + taskName);
			setTimeOut(3000);
		} catch (Exception e) {
			Log.error("Failed to Click on -" + taskName + e.getMessage());
			Assert.fail("Failed to Click on -" + taskName + e.getMessage());
		}
	}

	/**
	 * Function: Click on sub task eg. follow up on results, BV summary etc
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnSubTask(String subTask) {

		try {
			By eleSubTaskButton = getDynamicElement(subTaskButton, subTask);
			waitAndVerifyElement(eleSubTaskButton);
			scrollToElement(eleSubTaskButton);
			clickByJavascript(eleSubTaskButton);
			LoggingInfo("Clicked on task-" + subTask);
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click on task- " + subTask + e.getMessage());
			Assert.fail("Failed to click on task-" + subTask + e.getMessage());
		}
	}

	/**
	 * Function:Navigate to Correspondence Tab
	 * 
	 * @author Anand Pawar
	 **/

	public void navigateToAllCorresTab() {
		try {
			By tab = By.xpath("(//*[contains(text(),'All | ')]//parent::a)[1]");
			waitAndVerifyElement(tab);
			scrollToElement(tab);
			clickByJavascript(tab);
			setTimeOut(2000);
			LoggingInfo("Navigated to All Correspondence tab");
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate" + e.getMessage());
			Assert.fail("Failed to navigate " + e.getMessage());
		}
	}

	/**
	 * Function: Click on save button
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnSave() {

		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleSaveDetails1);
			scrollToElement(eleSaveDetails1);
			clickByJavascript(eleSaveDetails1);
			setTimeOut(8000);
			LoggingInfo("Clicked on save button");
			setTimeOut(8000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to save details" + e.getMessage());
			Assert.fail("Failed to save details" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: validate cpe team member error message
	 * 
	 * @author Anand Pawar
	 **/
	public void validateErrorMessgae() {

		try {
			By errorMsg = By.xpath(
					"//*[text()=\"Only one Care Team user for a given role can be assigned. To add a new Team Member, inactivate the other Care Team User.\"]");
			waitAndVerifyElement(errorMsg);
			scrollToElement(errorMsg);
			highLightElement(errorMsg);
			setTimeOut(2000);
			LoggingInfo("Error message validated successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate error details" + e.getMessage());
			Assert.fail("Failed to validate error details" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Check created date column sorting
	 * 
	 * @author Trupti Zure
	 **/

	public void checkColumnSorting() {

		try {
			waitAndVerifyElement(createdDateColumn);
			String sortingState;

			sortingState = getText(createdDateSortState);

			while (sortingState != null && !sortingState.contains("Sorted Descending")) {
				clickByJavascript(createdDateColumn);
				setTimeOut(1000);

				sortingState = getText(createdDateSortState);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to check column sorting. Error -" + e.getMessage());
			Assert.fail("Failed to check column sorting. Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Navigate to All Medication Dispenses
	 * 
	 * @author Trupti Zure
	 **/

	/**
	 * Function: Click on first CPE record
	 * 
	 * @author Anand Pawar
	 **/

	public void clickOnFirstCPERecord() {
		try {
			setTimeOut(6000);
			By record = By.xpath("//*[@data-label=\"Name\"]//a");
			waitAndVerifyElement(record);
			setTimeOut(8000);
			clickByJavascript(record);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click: " + e.getMessage());
			Assert.fail("Failed to click: " + e.getMessage());
		}

	}

	/**
	 * Function: Click on first Correspondence record
	 * 
	 * @author Anand Pawar
	 **/

	public void clickOnFirstCorresRecord() { // check this
		try {
			setTimeOut(3000);
			By record = By.xpath(
					"//td[@data-label=\"Active\"]//span[text()=\"Yes\"]//ancestor::td//preceding-sibling::th//a");
			waitAndVerifyElement(record);
			setTimeOut(1000);
			clickByJavascript(record);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click: " + e.getMessage());
			Assert.fail("Failed to click: " + e.getMessage());
		}

	}

	/**
	 * Function: Click on CPE record without using search function
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnCPERecord(String recordName) {
		try {
			// By recordList = By.xpath("//tr//td[3]//a");
			By recordList = By.xpath("//*[contains(@ style,'counter-reset')]//tr//th//child::a");
			waitAndVerifyElement(recordList);
			setTimeOut(1000);

			boolean recordFound = false;

			for (int attempt = 0; attempt < 3; attempt++) {
				List<WebElement> listOptions = getWebDriver().findElements(recordList);

				if (!listOptions.isEmpty()) {
					for (WebElement element : listOptions) {
						String record = element.getAttribute("title");
						setTimeOut(1000);

						if (record.equalsIgnoreCase(recordName)) {
							JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
							js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
									"border: 2px solid red;");
							setTimeOut(1000);
							element.click();
							setTimeOut(2000);
							LoggingInfo("Clicked on record: " + recordName);
							recordFound = true;
							break;
						}
					}
				}

				if (recordFound) {
					break;
				}

				scrollToElement(createdDateColumnLink);
				click(createdDateColumnLink);
				setTimeOut(2000);
			}

			if (!recordFound) {
				LoggingInfo("Record not found");
				Assert.fail("Failed to find record: " + recordName);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify document record: " + e.getMessage());
			Assert.fail("Failed to verify document record: " + e.getMessage());
		}
	}

	/**
	 * Function: Verify if SubTask is initiated
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifySubTaskInitiaited(String subTask) {

		try {
			By eleSubTaskButton = getDynamicElement(subTaskButton, subTask);
			waitAndVerifyElement(eleSubTaskButton);
			if (verifyObjectPresentOrNot(eleSubTaskButton)) {
				scrollToElement(eleSubTaskButton);
				LoggingInfo(subTask + "is Initiated");
			}
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to validate task- " + subTask + e.getMessage());
			Assert.fail("Failed to validate task-" + subTask + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to All Medication Dispenses
	 * 
	 * @author Trupti Zure
	 **/

	public void navigateToAllMedication() {
		try {
			Log.info("Navigate to All Medication Dispenses worklist");
			click(medlistViewButton);

			waitForPageLoaded();
			By allMedList = getDynamicElement(strDocumentPageTitle, "All Medication Dispenses");
			waitAndVerifyElement(allMedList);
			clickByJavascript(allMedList);
			setTimeOut(2000);
			LoggingInfo("Navigated to All Medication Dispenses  Worklist");
		} catch (Exception e) {
			Log.error("Failed to naviaget to all medication" + e.getMessage());
			Assert.fail("Failed to naviaget to all medication " + e.getMessage());
		}
	}

	/**
	 * Function: Check medication request not created in Medication dispenses list
	 *
	 * @author Trupti
	 */
	public void checkMedicationRequestNotCreated(String patient) {
		try {
			String sortingState;
			do {
				sortingState = getText(LastModifiedDateSortState);

				if (sortingState != null && !sortingState.contains("Sorted Descending")) {
					clickByJavascript(LastModifiedDateColumn);
					setTimeOut(1000);
				}
				sortingState = getText(LastModifiedDateSortState);
			} while (sortingState != null && !sortingState.contains("Sorted Descending"));

			boolean patientFound = false;
			for (int attempt = 0; attempt < 3; attempt++) {
				if (methodToAvoidStaleElementReferenceErrorElement(patientList)) {
					waitAndVerifyElement(patientList);
					setTimeOut(1000);
					List<WebElement> listOptions = getWebDriver().findElements(patientList);

					for (WebElement element : listOptions) {
						String recordName = element.getAttribute("title");
						setTimeOut(1000);

						if (recordName.equalsIgnoreCase(patient)) {
							patientFound = true;
							Assert.fail("Patient should not be found in the list, but was found: " + patient);
						}
					}
				}

				click(LastModifiedDateColumn);
				setTimeOut(2000);
			}

			if (patientFound) {
				Assert.fail("Patient ID should not be found in the list, but was found after 3 attempts.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify document record: " + e.getMessage());
			Assert.fail("Failed to verify document record: " + e.getMessage());
		}
	}

	public void navigateToAllOrders() {
		try {
			Log.info("Navigate to All Orders worklist");
			click(orderlistViewButton);

			waitForPageLoaded();
			By allOrdersList = getDynamicElement(strDocumentPageTitle, "All Orders");
			waitAndVerifyElement(allOrdersList);
			clickByJavascript(allOrdersList);
			setTimeOut(2000);
			LoggingInfo("Navigated to All Orders  Worklist");
		} catch (Exception e) {
			Log.error("Failed to naviaget to All Orders" + e.getMessage());
			Assert.fail("Failed to naviaget to All Orders" + e.getMessage());
		}
	}

	public void navigateToAllFacilities() {

		try {
			Log.info("Navigate to all Facilities");
			click(listViewButton);

			waitForPageLoaded();
			By allFacilitiesList = getDynamicElement(strDocumentPageTitle, "All Facilities");
			waitAndVerifyElement(allFacilitiesList);
			clickByJavascript(allFacilitiesList);
			setTimeOut(2000);
			LoggingInfo("Navigated to All Facilities Worklist");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to all Facilities  " + e.getMessage());
			Assert.fail("Failed to navigate to all Facilities  " + e.getMessage());
		}

	}

	public void verifyDSRRecordIsCreated(String hcpName) {
		try {
			// HCP account
			waitAndVerifyElement(dsrAccount);
			scrollToElement(dsrAccount);
			String account = getText(dsrAccount);
			Assert.assertEquals(account, hcpName,
					"HCP account. Expected: '" + hcpName + "', but got: '" + account + "'");
			LoggingInfo("DSR record verified- " + hcpName);
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to validate DSR request" + e.getMessage());
			Assert.fail("Failed to validate DSR request" + e.getMessage());
		}
	}

	/*
	 * @author - Anand Pawar
	 */
	public void verifyStatusRecord(String exepctedStatus) {
		try {
			By eleStatus = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Status\"]//parent::div//following-sibling::div//lightning-formatted-text");
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			String actualStatus = getText(eleStatus);
			Assert.assertEquals(exepctedStatus, actualStatus,
					"Expected Status : '" + exepctedStatus + "', and got: '" + actualStatus + "'");
			LoggingInfo("Status Verified of DSR Record");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to validate DSR request Status" + e.getMessage());
			Assert.fail("Failed to validate DSR request Status" + e.getMessage());
		}
	}

	/*
	 * @author - Anand Pawar
	 */
	public void verifyDCRNotes() {
		String exepctedStatus = "Direct from account";
		try {
			By eleStatus = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"DCR Notes\"]//parent::div//following-sibling::div//lightning-formatted-text");
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			String actualStatus = getText(eleStatus);
			Assert.assertEquals(exepctedStatus, actualStatus,
					"Expected Notes : '" + exepctedStatus + "', and got: '" + actualStatus + "'");
			LoggingInfo("DCR Notes Verified of DSR Record");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to validate DSR request Status" + e.getMessage());
			Assert.fail("Failed to validate DSR request Status" + e.getMessage());
		}
	}

	/*
	 * @author - Anand Pawar
	 */
	public void verifyDSRLineFieldsOfRecord() {
		try {

			List<String> fieldNames = Arrays.asList("Field Name", "Old Value", "New Value");

			for (String field : fieldNames) {
				By eleStatus = getDynamicElement(eleDetails, field);
				waitAndVerifyElement(eleStatus);
				highLightElement(eleStatus);
				System.out.println(getText(eleStatus));
			}
			LoggingInfo("Verified old and Values of DSR Line Items");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to validate DSR request Line" + e.getMessage());
			Assert.fail("Failed to validate DSR request ine" + e.getMessage());
		}
	}

	/**
	 * Function:Update status
	 *
	 * @author Trupti
	 */

	public void updateStatus(String cpeStatus) {
		try {
			By status = getDynamicElement(eleDetailsPageEditFields, "Status");
			waitAndVerifyElement(status);
			scrollToElement(status);
			click(status);
			setTimeOut(1000);

			// Status
			By statusDropDown = getDynamicElement(strDropDownBox, "Status");
			waitAndVerifyElement(statusDropDown);
			scrollToElement(statusDropDown);
			click(statusDropDown);

			By statusDropDownOptions = getDynamicElement(strDropDownBoxOptions, "Status");
			waitAndVerifyElement(statusDropDownOptions);
			selectItemFromList(statusDropDown, statusDropDownOptions, cpeStatus, "Status");

			LoggingInfo("Updated status as- " + cpeStatus);

		} catch (Exception e) {
			Log.error("Failed to update status" + e.getMessage());
			Assert.fail("Failed to update status" + e.getMessage());
		}
	}

	/**
	 * Function:Update on hold field
	 *
	 * @author Trupti
	 */
	public void updateOnHoldField() { // check this again
		try {
			// On Hold
			scrollToPixel(0, 500);
			waitAndVerifyElement(onHoldCheckBox);
			String chkState = getAttributeValue(onHoldCheckBox, "checked");
			if (chkState == null) {
				By onhold = getDynamicElement(eleDetailsPageEditFields, "On Hold");
				waitAndVerifyElement(onhold);
				scrollToElement(onhold);
				click(onhold);
				setTimeOut(1000);
				waitAndVerifyElement(onHoldCHKbox);
				WebElement element = getWebDriver().findElement(By.xpath("//*[@name=\"OnHold_ICC__c\"]"));
				act.click(element).build().perform();
				scrollToPixel(0, 200);
				By eleSaveButton = getDynamicElement(eleButton2, "Save");
				scrollToElement(eleSaveButton);
				waitAndVerifyElement(eleSaveButton);
				clickByJavascript(eleSaveButton);
				setTimeOut(4000);
				LoggingInfo("Clicked on Save");
				LoggingInfo("On Hold checkbox is checked");
			} else {
				LoggingInfo("On Hold checkbox is checked");
			}

		} catch (Exception e) {
			Log.error("Failed to update on hold field" + e.getMessage());
			Assert.fail("Failed to update on hold field" + e.getMessage());
		}
	}

	/**
	 * Function:Get care program product
	 *
	 * @author Trupti
	 */
	public String getCareProgramProduct() {
		String careProgram = null;
		try {
			By careProgramElement = getDynamicElement(strAccountObjectDetailsLink, "Care Program");
			waitAndVerifyElement(careProgramElement);
			scrollToElement(careProgramElement);
			careProgram = getText(careProgramElement);

		} catch (Exception e) {
			Log.error("Failed to get care program product" + e.getMessage());
			Assert.fail("Failed to get care program product" + e.getMessage());
		}
		return careProgram;
	}

	public void navigateToAllCPECaseManager() {

		try {
			Log.info("Navigate to All Orders worklist");
			click(listViewButton);

			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			// *[@placeholder=\"Search this list...\"]
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, "All Care Program Enrollees");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to naviaget to All Orders" + e.getMessage());
			Assert.fail("Failed to naviaget to All Orders" + e.getMessage());
		}
	}

	/**
	 * Function:Check task initiation
	 * 
	 * @author Trupti
	 **/

	public void checkTaskInitiation(String maintask, String subtask) {
		try {
			By taskName = getDynamicElement(strTaskName, maintask);
			waitAndVerifyElement(taskName);
			LoggingInfo("QS Summary task has been initialized");
			setTimeOut(2000);

			By eleTaskButton = getDynamicElement(taskButton, maintask);
			scrollToElement(eleTaskButton);
			click(eleTaskButton);
			LoggingInfo("Clicked on QS summary task");
			setTimeOut(1000);

			By subTaskName = getDynamicElement(strSubtaskName, subtask);
			waitAndVerifyElement(subTaskName);
			LoggingInfo(subtask + " sub task- has been initialized");
			setTimeOut(2000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, subtask);
			waitAndVerifyElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Not Started", subtask + " task status verified");

		} catch (Exception e) {
			Log.error("Failed to Check Task Initiation " + e.getMessage());
			Assert.fail("Failed to Check Task Initiation " + e.getMessage());
		}
	}

	public void clickViewAll(String tablename) {
		try {

			// By viewAllbutton = getDynamicElement(viewAllButton, tablename);
			By eleCases = By.xpath("//*[text()='Correspondences']");
			waitAndVerifyElement(eleCases);
			scrollToElement(eleCases);
			setTimeOut(4000);
			waitForPageLoaded();
			waitForelementToBeClickable(eleCases);
			setTimeOut(2000);
			clickByJavascript(eleCases);
			LoggingInfo("Clicked on Cases button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on view all button " + e.getMessage());
			Assert.fail("Failed to click on view all button " + e.getMessage());
		}
	}

	public void clickOnPayersMemberplan(String payername) {
		try {

			By payer = getDynamicElement(payerRecord, payername);
			waitAndVerifyElement(payer);
			scrollToElement(payer);
			setTimeOut(4000);
			clickByJavascript(payer);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on view all button " + e.getMessage());
			Assert.fail("Failed to click on view all button " + e.getMessage());
		}
	}

	/**
	 * Function: Check if Inactivation Reason field is visible and is initially
	 * blank.
	 * 
	 * @author Trupti Zure
	 **/
	public void checkReasonField(String expectedReason) {
		try {
			WebElement eleReason = getWebDriver().findElement(By.xpath(
					"//*[contains(@class,'active lafPageHost')]//*[text()='Inactivation Reason']//ancestor::records-record-layout-item//lightning-formatted-text"));

			JavascriptExecutor jsExecutor = (JavascriptExecutor) getWebDriver();
			String actualReason = (String) jsExecutor.executeScript("return arguments[0].innerText;", eleReason);

			if (expectedReason == null || expectedReason.isEmpty()) {
				assert actualReason.trim().isEmpty()
						: "Expected the field to be blank, but found: '" + actualReason + "'";
				LoggingInfo("Inactivation Reason field is visible and blank as expected.");
			} else {
				assert actualReason.trim().equals(expectedReason.trim())
						: "Expected: '" + expectedReason + "', but found: '" + actualReason + "'";
				LoggingInfo(
						"Inactivation Reason field is visible and matches expected value: '" + expectedReason + "'");
			}

		} catch (Exception e) {
			Log.error("Failed to verify Reason field: " + e.getMessage());
			Assert.fail("Failed to verify Reason field: " + e.getMessage());
		}
	}

	public void checkInactivationReasonIsBlank() {
		try {
			Log.info("Verifying that the Inactivation Reason field is blank");

			By inactivationReasonLocator = getDynamicElement(strInputBpx, "Inactivation Reason");

			waitAndVerifyElement(inactivationReasonLocator);
			scrollToElement(inactivationReasonLocator);

			String actualValue = getAttributeValue(inactivationReasonLocator, "value");

			boolean isBlank = actualValue == null || actualValue.equals("");
			Assert.assertTrue(isBlank, "Expected Inactivation Reason to be blank but found: '" + actualValue + "'");

			Log.info("Inactivation Reason field is confirmed to be blank");

		} catch (Exception e) {
			Log.error("Error verifying Inactivation Reason field: " + e.getMessage());
			Assert.fail("Inactivation Reason field verification failed: " + e.getMessage());
		}
	}

	/**
	 * Function:Check Main task initiation
	 * 
	 * @author Shanavaz Nishani
	 **/

	public void checkMainTaskInitiation(String maintask) {
		try {
			By taskName = getDynamicElement(strTaskName, maintask);
			waitAndVerifyElement(taskName);
			LoggingInfo(maintask + " task is present under My tasks");
			setTimeOut(2000);
			// Assert.assertEquals(status, "Not Started", subtask + " task status
			// verified");

		} catch (Exception e) {
			Log.error("Failed to Check Task Initiation " + e.getMessage());
			Assert.fail("Failed to Check Task Initiation " + e.getMessage());
		}
	}

	public void clickOnOrderNumber(String service) {
		try {

			By orderNumber = getDynamicElement(orderNumberButton, service);
			waitAndVerifyElement(orderNumber);
			scrollToElement(orderNumber);
			clickByJavascript(orderNumber);
			LoggingInfo("Clicked on orderNumber");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on orderNumber " + e.getMessage());
			Assert.fail("Failed to click on orderNumber " + e.getMessage());
		}
	}

	/**
	 * Function:Verify member plans are populated
	 * 
	 * @author Tejal
	 **/
	public void verifyMemberPlanSections(String pharmacypayerName, String medicalPayerName) {

		try {

			By pharmacy = getDynamicElement(payerRecord, pharmacypayerName);
			waitAndVerifyElement(pharmacy);
			highLightElement(pharmacy);

			By medical = getDynamicElement(payerRecord, medicalPayerName);
			waitAndVerifyElement(medical);
			highLightElement(medical);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Member Plan section Fields " + e.getMessage());
			Assert.fail("Failed to verify Member Plan section Fields" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Open Cases table on CPE related Tab by clicking on (Cases Link)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void clickOnCasesTable() throws Exception {
		try {
			By eleCasesTable = By.xpath("//*[contains(@href, 'Cases')]/span");
			waitAndVerifyElement(eleCasesTable);
			scrollToElement(eleCasesTable);
			clickByJavascript(eleCasesTable);
			Log.info("Clicked on Cases Table");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to open Cases Table " + e.getMessage());
			Assert.fail("Failed to open Cases Table " + ". Error - " + e.getMessage());
		}

	}

	public void verifyButtonsDisplayedOnCPEPage(String... expectedButtons) {
		try {
			List<WebElement> displayedButtons = getWebDriver().findElements(By.xpath("//button"));

			Set<String> expected = new HashSet<>(Arrays.asList(expectedButtons));
			Set<String> actual = new HashSet<>();

			for (WebElement button : displayedButtons) {
				String text = button.getText().trim();
				if (!text.isEmpty()) {
					actual.add(text);
				}
			}

			for (String expectedText : expected) {
				LoggingInfo(expectedText + " button verified");
			}

			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Button verification failed: " + e.getMessage());
			Assert.fail("Button verification failed: " + e.getMessage());
		}
	}

	public void verifyButtonByTitle(String buttonTitle) {
		try {
			By buttonLocator = By.xpath("//*//runtime_platform_actions-action-renderer[@title='" + buttonTitle + "']");
			waitAndVerifyElement(buttonLocator);
			scrollToElement(buttonLocator);
			highLightElement(buttonLocator);
			LoggingInfo(buttonTitle + " button verified.");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to verify button: " + buttonTitle + " - " + e.getMessage());
			Assert.fail("Failed to verify button: " + buttonTitle + " - " + e.getMessage());
		}
	}

	/**
	 * Function: Verify presence of a button by its title attribute on the CPE page.
	 * Used for verifying buttons like 'CPE Status Update' inside
	 * lightning-button-menu.
	 * 
	 * 
	 * @author Trupti Z
	 */
	public void verifyButton(String buttonTitle) {
		try {

			By buttonLocator = By.xpath("//*//runtime_platform_actions-action-renderer[@title='" + buttonTitle + "']");
			waitAndVerifyElement(buttonLocator);
			scrollToElement(buttonLocator);
			highLightElement(buttonLocator);
			LoggingInfo(buttonTitle + " button verified.");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to verify button: " + buttonTitle + " - " + e.getMessage());
			Assert.fail("Failed to verify button: " + buttonTitle + " - " + e.getMessage());
		}
	}

	/**
	 * Function: Click on the Quick Actions button on the CPE page.
	 * 
	 * 
	 * @author Trupti Z
	 */
	public void clickQuickActionsButton() {
		try {
			waitAndVerifyElement(quickActionsButton);
			scrollToElement(quickActionsButton);
			highLightElement(quickActionsButton);
			click(quickActionsButton);
			LoggingInfo("Quick Actions button clicked successfully.");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to click Quick Actions button: " + e.getMessage());
			Assert.fail("Failed to click Quick Actions button: " + e.getMessage());
		}
	}

	/**
	 * Function: Click on a specific action inside the Quick Actions dropdown on the
	 * CPE page.
	 *
	 * 
	 * @author Trupti Z
	 */
	public void clickActionByName(String actionText) {
		try {
			By actionLocator = getDynamicElement(strActionLocator, actionText);
			waitAndVerifyElement(actionLocator);
			scrollToElement(actionLocator);
			highLightElement(actionLocator);
			click(actionLocator);
			LoggingInfo(actionText + " action clicked successfully.");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to click action: " + actionText + " - " + e.getMessage());
			Assert.fail("Failed to click action: " + actionText + " - " + e.getMessage());
		}
	}

	/**
	 * Function: Verify that the Action screen is displayed by checking the heading.
	 * 
	 * 
	 * @author Trupti Z
	 */
	public void verifyActionScreenDisplayed() {
		try {
			By actionScreenHeading = By.xpath("//*[@role='heading' and text()='Action']");

			waitAndVerifyElement(actionScreenHeading);
			scrollToElement(actionScreenHeading);
			highLightElement(actionScreenHeading);
			LoggingInfo("Action screen displayed successfully.");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Action screen not displayed: " + e.getMessage());
			Assert.fail("Action screen not displayed: " + e.getMessage());
		}
	}

	/**
	 * Function: Verify that radio buttons with specified labels are displayed on
	 * the page.
	 * 
	 * @author Trupti Z
	 */
	public void verifyRadioButtonsDisplayed(String... radioLabels) {
		try {
			for (String label : radioLabels) {
				By radioLocator = By.xpath(
						"//*[@type='radio']//parent::div//span[text()='" + label + "']//preceding-sibling::span");

				waitAndVerifyElement(radioLocator);
				scrollToElement(radioLocator);
				highLightElement(radioLocator);
				LoggingInfo("'" + label + "' radio button is displayed.");
			}
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to verify radio buttons: " + Arrays.toString(radioLabels) + " - " + e.getMessage());
			Assert.fail("Failed to verify radio buttons: " + Arrays.toString(radioLabels) + " - " + e.getMessage());
		}
	}

	/**
	 * Function: Click on a radio button by its label text.
	 * 
	 * 
	 * @author Trupti Z
	 */
	public void clickRadioButtonByLabel(String label) {
		try {
			By radioButtonLocator = By
					.xpath("//*[@type='radio']//parent::div//span[text()='" + label + "']//preceding-sibling::span");

			waitAndVerifyElement(radioButtonLocator);
			scrollToElement(radioButtonLocator);
			highLightElement(radioButtonLocator);
			click(radioButtonLocator);

			LoggingInfo("'" + label + "' radio button clicked successfully.");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to click radio button '" + label + "': " + e.getMessage());
			Assert.fail("Failed to click radio button '" + label + "': " + e.getMessage());
		}
	}

	/**
	 * Function: Verify that a screen is displayed by checking the heading text.
	 * 
	 * @author Trupti Z
	 */
	public void verifyScreenDisplayedByHeading(String screenHeading) {
		try {
			By headingLocator = By.xpath("//*[@role='heading' and text()='" + screenHeading + "']");

			waitAndVerifyElement(headingLocator);
			scrollToElement(headingLocator);
			highLightElement(headingLocator);

			LoggingInfo(screenHeading + " screen is displayed.");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error(screenHeading + " screen is not displayed: " + e.getMessage());
			Assert.fail(screenHeading + " screen is not displayed: " + e.getMessage());
		}
	}

	/**
	 * Function: Verify that specified picklist fields are displayed on the form.
	 * 
	 * 
	 * Author: Trupti Z
	 */
	public void verifyPicklistFieldsDisplayed(List<String> picklistLabels) {
		try {
			for (String label : picklistLabels) {
				By picklistLocator;

				if (label.equalsIgnoreCase("Consent Giver")) {

					picklistLocator = By.xpath(
							"(//*[text()='Consent Giver']//ancestor::div[@class='slds-form-element']//input[@role='combobox'])[2]");
				} else {

					picklistLocator = By.xpath("//*[text()='" + label
							+ "']//ancestor::div[@class='slds-form-element']//input[@role='combobox']");
				}

				waitAndVerifyElement(picklistLocator);
				scrollToElement(picklistLocator);
				highLightElement(picklistLocator);
				LoggingInfo("Picklist field '" + label + "' is displayed.");
			}
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to verify picklist fields: " + picklistLabels + " - " + e.getMessage());
			Assert.fail("Failed to verify picklist fields: " + picklistLabels + " - " + e.getMessage());
		}
	}

	/**
	 * Function: Verify that specified text input fields are displayed on the form.
	 * 
	 * 
	 * Author: Trupti Z
	 */
	public void verifyTextFieldsDisplayed(List<String> fieldLabels) {
		try {
			for (String label : fieldLabels) {
				By textFieldLocator = By.xpath("//*[text()='" + label + "']"
						+ "//ancestor::div[contains(@class,'slds-form-element')]" + "//input[@type='text']");

				waitAndVerifyElement(textFieldLocator);
				scrollToElement(textFieldLocator);
				highLightElement(textFieldLocator);
				LoggingInfo("Text field '" + label + "' is displayed.");
			}
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to verify text fields: " + fieldLabels + " - " + e.getMessage());
			Assert.fail("Failed to verify text fields: " + fieldLabels + " - " + e.getMessage());
		}
	}

	/**
	 * Function: Verify that the 'Consent Capture Date' field is auto-populated with
	 * today's date.
	 * 
	 * Author: Trupti Z
	 */
	public String verifyConsentCaptureDateAutoPopulated() {
		String expectedDate = null;
		try {
			By dateFieldLocator = By.xpath(
					"//*[text()='Consent Capture Date']//ancestor::div[contains(@class,'slds-form-element')]//input[@type='text']");

			waitAndVerifyElement(dateFieldLocator);
			scrollToElement(dateFieldLocator);
			highLightElement(dateFieldLocator);

			String actualDate = getAttributeValue(dateFieldLocator, "value");

			expectedDate = new SimpleDateFormat("MM-dd-yyyy").format(new Date());

			LoggingInfo("Consent Capture Date field value: " + actualDate);
			LoggingInfo("Expected today's date: " + expectedDate);

			Assert.assertEquals(actualDate, expectedDate, "Consent Capture Date is not auto-populated correctly.");
			LoggingInfo("Consent Capture Date is auto-populated correctly with today's date.");

		} catch (Exception e) {
			Log.error("Failed to verify Consent Capture Date auto-population: " + e.getMessage());
			Assert.fail("Failed to verify Consent Capture Date auto-population: " + e.getMessage());
		}
		return expectedDate;
	}

	/**
	 * Function: Verify that the 'Consent Giver Name' field is auto-populated with
	 * the HCP name stamped on the CPE.
	 * 
	 * 
	 * Author: Trupti Z
	 */
	public void verifyConsentGiverNameAutoPopulated(String expectedHcpName) {
		try {
			By giverNameLocator = By.xpath("(//*[text()='Consent Giver Name']"
					+ "//parent::label//parent::div//following-sibling::div//input)[2]");

			waitAndVerifyElement(giverNameLocator);
			scrollToElement(giverNameLocator);
			highLightElement(giverNameLocator);

			String actualValue = getAttributeValue(giverNameLocator, "value");

			LoggingInfo("Consent Giver Name field value: " + actualValue);
			LoggingInfo("Expected HCP Name: " + expectedHcpName);

			Assert.assertEquals(actualValue.trim(), expectedHcpName.trim(),
					"Consent Giver Name is not auto-populated with the correct HCP name.");

			LoggingInfo("Consent Giver Name is correctly auto-populated with the HCP name.");

		} catch (Exception e) {
			Log.error("Failed to verify Consent Giver Name auto-population: " + e.getMessage());
			Assert.fail("Failed to verify Consent Giver Name auto-population: " + e.getMessage());
		}
	}

	public void verifyDropdownOptionsArePresent(String fieldLabel, List<String> expectedValues) throws Exception {
		try {
			By dropDownFirst = By.xpath("(" + strDropDownInputBox.replace("{0}", fieldLabel) + ")[1]");
			By dropDownSecond = By.xpath("(" + strDropDownInputBox.replace("{0}", fieldLabel) + ")[2]");

			WebElement dropDownToUse = null;

			try {
				WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(5));
				WebElement firstElement = getWebDriver().findElement(dropDownFirst);
				wait.until(ExpectedConditions.visibilityOf(firstElement));

				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].scrollIntoView({block: 'center'});",
						firstElement);
				firstElement.click();
				dropDownToUse = firstElement;
			} catch (Exception e) {
				Log.warn("First dropdown input not interactable for label: " + fieldLabel + ". Trying second...");

				WebElement secondElement = getWebDriver().findElement(dropDownSecond);
				WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(5));
				wait.until(ExpectedConditions.visibilityOf(secondElement));

				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].scrollIntoView({block: 'center'});",
						secondElement);
				secondElement.click();
				dropDownToUse = secondElement;
			}

			String optionXpath = "//*[contains(@class,'active lafPageHost')]//*[text()='" + fieldLabel + "']"
					+ "//parent::label//parent::div//following-sibling::div//li";

			List<WebElement> dropdownOptions = getWebDriver().findElements(By.xpath(optionXpath));

			List<String> actualOptions = dropdownOptions.stream().map(WebElement::getText).map(String::trim)
					.collect(Collectors.toList());

			for (String expectedValue : expectedValues) {
				if (!actualOptions.contains(expectedValue)) {
					throw new AssertionError("Expected dropdown value '" + expectedValue + "' is NOT present in field '"
							+ fieldLabel + "'");
				}
				LoggingInfo("PASS: Dropdown value '" + expectedValue + "' is present in '" + fieldLabel + "'");
			}

			dropDownToUse.click();

		} catch (Exception e) {
			LoggingInfo("FAIL: Error while verifying dropdown values for '" + fieldLabel + "': " + e.getMessage());
			throw e;
		}
	}

	/**
	 * Function: Select drop down value
	 * 
	 * @author Trupti Zure
	 **/
	public void selectDropdownValue(String label, String value) {
		try {
			By dropDownFirst = By.xpath("(" + strDropDownInputBox.replace("{0}", label) + ")[1]");
			By dropDownSecond = By.xpath("(" + strDropDownInputBox.replace("{0}", label) + ")[2]");

			By dropDownToUse = null;

			try {
				WebElement firstElement = getWebDriver().findElement(dropDownFirst);
				WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(7));
				wait.until(ExpectedConditions.visibilityOf(firstElement));

				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].scrollIntoView({block: 'center'});",
						firstElement);
				firstElement.click();
				dropDownToUse = dropDownFirst;
			} catch (Exception firstTryException) {
				Log.warn("First dropdown input not interactable. Trying second...");

				WebElement secondElement = getWebDriver().findElement(dropDownSecond);
				WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(7));
				wait.until(ExpectedConditions.visibilityOf(secondElement));

				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].scrollIntoView({block: 'center'});",
						secondElement);
				secondElement.click();
				dropDownToUse = dropDownSecond;
			}
			String consentGiverOptions = "//*[contains(@class,\"active lafPageHost\")]//runtime_omnistudio_omniscript-omniscript-select[@data-omni-key=\"ConsentGiver\"]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li";
			By dropDownOptions = getDynamicElement(consentGiverOptions, label);
			waitAndVerifyElement(dropDownOptions);

			selectItemFromList(dropDownToUse, dropDownOptions, value, label);

		} catch (Exception e) {
			Log.error("Failed to select dropdown value: " + e.getMessage());
			Assert.fail("Failed to select dropdown value for label [" + label + "] with value [" + value + "]: "
					+ e.getMessage());
		}
	}

	public void ValidateCareProgramProductReadOnlyField() {

		try {
			setTimeOut(3000);

			By eleCareProgramProduct = getDynamicElement(strReadOnlyFields, "Care Program Product");
			waitAndVerifyElement(eleCareProgramProduct);
			scrollToElement(eleCareProgramProduct);
			Assert.assertTrue(getAttributeValue(eleCareProgramProduct, "class").contains("is-read-only"),
					"Field is  marked as read-only.");
			setTimeOut(2000);
			LoggingInfo("Care Program Product field is Read only field");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Care Program Product field is Read only field " + e.getMessage());
			Assert.fail("Failed to verify Care Program Product field is Read only field " + e.getMessage());
		}
	}

	public void enterCareProgramEnrollee(String cpe) {

		try {
			setTimeOut(3000);

			By eleCareProgramEnrollee = getDynamicElement(editbutton, "Edit Care Program Enrollee");
			waitAndVerifyElement(eleCareProgramEnrollee);
			scrollToElement(eleCareProgramEnrollee);
			click(eleCareProgramEnrollee);

			click(eleCareProgramEnrolleefield);
			inputText(eleCareProgramEnrollee, cpe);
			setTimeOut(5000);
			Actions actMemberPlan = new Actions(getWebDriver());
			actMemberPlan.sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
			// genericKeyPress(searchUserInput, "Enter");
			setTimeOut(3000);
			waitForPageLoaded();

			click(eleSavebutton);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Care Program Product field is Read only field " + e.getMessage());
			Assert.fail("Failed to verify Care Program Product field is Read only field " + e.getMessage());
		}
	}

	public void checkLastModifiedColumnSorting() {

		try {

			setTimeOut(6000);
			waitAndVerifyElement(lastModifiedColumn);
			String sortingState;

			sortingState = getText(lastModifiedDateSortState);

			while (sortingState != null && !sortingState.contains("Sorted Descending")) {
				clickByJavascript(lastModifiedColumn);
				setTimeOut(1000);

				sortingState = getText(lastModifiedDateSortState);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to check column sorting. Error -" + e.getMessage());
			Assert.fail("Failed to check column sorting. Error - " + e.getMessage());

		}

	}

	public void sortDesc() {

		try {

			setTimeOut(2000);
			waitForPageLoaded();
			Log.info("Verify PSQA Review Present");
			waitAndVerifyElement(lastModifiedColumn);
			click(lastModifiedColumn);
			LoggingInfo("PSQA Review is loaded");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Page load has Failed" + ". Error - " + e.getMessage());

		}
	}

	public void enterCaseManager() {

		try {
			setTimeOut(3000);

			click(eleCaseManagerfield);
			inputText(eleCaseManagerfield, "Case");
			setTimeOut(5000);
			Actions actMemberPlan = new Actions(getWebDriver());
			actMemberPlan.sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
			// genericKeyPress(searchUserInput, "Enter");
			setTimeOut(3000);
			waitForPageLoaded();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Care Program Product field is Read only field " + e.getMessage());
			Assert.fail("Failed to verify Care Program Product field is Read only field " + e.getMessage());
		}
	}

	public void selectReviewoption() {

		try {
			setTimeOut(3000);

			click(eleReviewoption);
			setTimeOut(2000);
			Actions actMemberPlan = new Actions(getWebDriver());
			actMemberPlan.sendKeys(Keys.DOWN, Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
			// genericKeyPress(searchUserInput, "Enter");
			setTimeOut(3000);
			waitForPageLoaded();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Care Program Product field is Read only field " + e.getMessage());
			Assert.fail("Failed to verify Care Program Product field is Read only field " + e.getMessage());
		}
	}
	
	/**
	 * Function: check workorder button is clickable - work order eg Benifit verification , Triage etc
	 * 
	 * @author Shraddha Shetty
	 **/

	public boolean workOrderTaskIsClickable(String taskName) {
		try {
			setTimeOut(3000);
			By woButton = getDynamicElement(eleButton, taskName);
			waitAndVerifyElement(woButton);
			scrollToElement(woButton);
			setTimeOut(1000);
			
			WebElement ele = getWebDriver().findElement(woButton);
			if(ele.isEnabled()) {
				LoggingInfo(taskName + " workorder is initiated");
				return true;
			}else {
				LoggingInfo(taskName + " workorder is not initiated");
				return false;
			}
		} catch (Exception e) {
			Log.error("Failed to check on -" + taskName + e.getMessage());
			Assert.fail("Failed to Check on -" + taskName + e.getMessage());
			return false;
		}
	}
	
	/**
	 * Function: Click on main task of any work order
	 * 
	 * @author Navita J
	 **/
	public void clickOnMainTaskWO(String taskName) {
		try {
			setTimeOut(3000);
			By eleMainTaskButton = getDynamicElement(taskButton, taskName);
			scrollToElement(eleMainTaskButton);
			click(eleMainTaskButton);
			LoggingInfo("Clicked on task-" + taskName);
			setTimeOut(3000);
		} catch (Exception e) {
			Log.error("Failed to Click on -" + taskName + e.getMessage());
			Assert.fail("Failed to Click on -" + taskName + e.getMessage());
		}
	}
	
	/**
	 * Function: Click on more actions
	 * 
	 * @author Navita J
	 **/
	public void clickOnMoreActions() {
		try {
			setTimeOut(3000);
			waitAndVerifyElement(moreActions);
			click(moreActions);
			LoggingInfo("Clicked on more actions-");
			setTimeOut(3000);
		} catch (Exception e) {
			Log.error("Failed to Click on -"  + e.getMessage());
			Assert.fail("Failed to Click on -"  + e.getMessage());
		}
	}
	
	public void sortAsc() {

		try {

			setTimeOut(2000);
			waitForPageLoaded();
			Log.info("Verify HCP Account Present");
			waitAndVerifyElement(lastModifiedColumn);
			click(lastModifiedColumn);
			LoggingInfo("HCP Account list is sorted ascending");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Page load has Failed" + ". Error - " + e.getMessage());

		}
	}
	
	
	
}
