package com.sanofi.selenium.constants;

public interface TestData {

	String[] headers = { "TestCaseID", "Patient Name", "Patient DOB", "Patient Primary phone", "Patient Email",
			"Gender", "Language", "Address", "City", "State", "Zip", "Patient Secondary phone",
			"Patient Authorization Date", "Patient Certifications Date", "Text Messaging Consent", "Voicemail", "Text",
			"Best Timing AM", "Best Timing Afternoon", "Best Timing PM", "Legal Representative Name", "Relationship",
			"Patient has NO Insurance", "Rx Payer Name", "Rx Phone", "Rx Policy ID", "Rx Group", "Rx BIN", "Rx PCN",
			"Medical Payer Name", "Medical Phone", "Medical Policy ID", "Medical Group", "Policyholder Name",
			"Relationship To Patient", "Preferred Specialty Pharmacy", "Specialty Pharmacy Name", "Pharmacy Phone",
			"Pharmacy Fax", "DUPIXENT MyWay", "Prescriber Name", "Specialty", "Prescriber Address", "Prescriber City",
			"Prescriber State", "Prescriber Zip", "Prescriber NPI", "Site/facility name", "Office Contact Name",
			"Office Contact Email", "Office Phone", "Office Fax", "Tax ID", "Date Of Diagnosis", "Diagnosis Code",
			"Prescriber State License", "Prescription 5A Sample Provided", "Prescription 5A Sample Provided Date",
			"Prescription 5A Prefilled Syringe", "Prescription 5A Prefilled Pen", "Prescription-5A RefillCaptured",
			"Prescription-5A Dose", "Prescription 5A Known Drug Allergies", "Prescription 5A Weight",
			"Prescription 5A Initial And Maintenance Doses", "Prescription 5B Quick Start",
			"Prescription 5B Sample Provided", "Prescription 5B Date", "Prescription 5B Prefilled Syringe",
			"Prescription 5B Prefilled Pen", "Prescription-B RefillCaptured", "Prescription-5B Dose",
			"Prescription 5B Known Drug Allergies", "Prescription 5B Weight",
			"Prescription 5B Initial And Maintenance Doses", "Prescriber Signature Date", "Substitutions Date",
			"Collaborating MD Name", "Nurse Practitioner NPI", "Eosinophil count", "Document ID", "File Name" };

	String[] firstNames = { "James", "Mary", "John", "Patricia", "Robert", "Jennifer", "Michael", "Linda", "William",
			"Elizabeth", "David", "Barbara", "Richard", "Susan", "Joseph", "Jessica", "Charles", "Sarah", "Thomas",
			"Karen", "Christopher", "Nancy", "Daniel", "Lisa", "Matthew", "Betty", "Anthony", "Helen", "Mark", "Sandra",
			"Donald", "Ashley", "Steven", "Dorothy", "Paul", "Kimberly", "Andrew", "Emily", "Joshua", "Donna", "Kevin",
			"Michelle", "Brian", "Carol", "George", "Amanda", "Edward", "Melissa", "Ronald", "Deborah", "Timothy",
			"Rebecca", "Jason", "Sharon", "Jeffrey", "Cynthia", "Ryan", "Kathleen", "Jacob", "Shirley", "Gary", "Amy",
			"Nicholas", "Angela", "Eric", "Helen", "Stephen", "Anna", "Larry", "Ruth", "Justin", "Brenda", "Benjamin",
			"Pamela", "Samuel", "Nicole", "Frank", "Katherine", "Raymond", "Virginia", "Jack", "Debra", "Gregory",
			"Rachel", "Dennis", "Carolyn", "Patrick", "Janet", "Zachary", "Doris", "Alexander", "Betty", "Jordan",
			"Megan", "Kyle", "Christine", "Austin", "Louise", "Ethan", "Catherine", "Adam", "Helen", "Christian",
			"Cheryl", "Walter", "Rita", "Harold", "Martha", "Terry", "Ashley", "Willie", "Dorothy", "Jackie", "Janice",
			"Bruce", "Irene", "Wayne", "Tina", "Albert", "Vivian", "Arthur", "Ann", "Henry", "Molly", "Joe", "Evelyn",
			"Lewis", "Joyce", "Roy", "Lois", "Carl", "Melanie", "Arthur", "Sue", "Billy", "Ruby", "Eugene", "Clara",
			"Louis", "Diana", "Fred", "Vivian", "Carl", "Rose", "Howard", "Samantha", "Jeremiah", "Lillian", "Earl",
			"Mildred", "Ray", "Hannah", "Leroy", "Mae", "Matthew", "Fannie", "Charles", "Lora", "Walter", "Beatrice",
			"Leonard", "Stella", "Vernon", "Jessie", "Ted", "Frances", "George", "Willa", "Ben", "Helen", "Jack",
			"Phyllis", "Joe", "Lola", "Michael", "Cynthia", "Bobby", "Gail", "Max", "Gwen", "Dale", "Sylvia", "Victor",
			"Lydia", "Mark", "Becky", "Rick", "Melinda", "Bill", "Sylvia" };

	String[] lastNames = { "Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis", "Garcia", "Rodriguez",
			"Wilson", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Perez", "Taylor", "Anderson", "Thomas", "Jackson",
			"White", "Harris", "Martin", "Thompson", "Moore", "Clark", "Lee", "Walker", "Hall", "Allen", "Young",
			"King", "Wright", "Scott", "Torres", "Nguyen", "Hill", "Adams", "Baker", "Nelson", "Carter", "Mitchell",
			"Perez", "Roberts", "Evans", "Green", "Turner", "Diaz", "Ramirez", "Parker", "Collins", "Edwards",
			"Stewart", "Sanchez", "Morris", "Rogers", "Reed", "Cook", "Morgan", "Bell", "Murphy", "Bailey", "Rivera",
			"Cooper", "Richardson", "Cox", "Ward", "Flores", "James", "Wood", "Jenkins", "Perry", "Powell", "Long",
			"Patterson", "Hughes", "Washington", "Butler", "Simmons", "Foster", "Graham", "Kelly", "Sanders", "Price",
			"Bennett", "Woodward", "Barnes", "Ross", "Henderson", "Coleman", "Jenkins", "Peters", "Boyd", "Burgess",
			"Reyes", "Diaz", "Murray", "Sullivan", "Bryant", "Davidson", "Hanson", "Carson", "Snyder", "Gilbert",
			"Daniels", "Bishop", "Curtis", "Bradley", "Harrison", "Palmer", "Hunt" };

	String[] domains = { "gmail.com", "yahoo.com", "hotmail.com", "example.com" };
	String[] genders = { "Male", "Female" };
	String[] languages = { "English", "Spanish", "Other" };
	String[] address = { "New Street", "Front Street", "Apartment" };
	String[] cityNames = { "New York City", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia",
			"San Antonio", "San Diego", "Dallas", "San Jose" };
	String[] statesAndTerritories = { "Alaska", "Alabama", "Arkansas", "Arizona", "California", "Colorado",
			"Connecticut", "District of Columbia", "Delaware", "Florida", "Georgia", "Hawaii", "Iowa", "Idaho",
			"Illinois", "Indiana", "Kansas", "Kentucky", "Louisiana", "Massachusetts", "Maryland", "Maine", "Michigan",
			"Minnesota", "Missouri", "Mississippi", "Montana", "North Carolina", "North Dakota", "Nebraska",
			"New Hampshire", "New Jersey", "New Mexico", "New York", "Nevada", "Ohio", "Oklahoma", "Oregon",
			"Pennsylvania", "Puerto Rico", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas",
			"United States Minor Outlying Islands", "Utah", "Virginia", "US Virgin Islands", "Vermont", "Washington",
			"Wisconsin", "West Virginia", "Wyoming" };

	String[] textCHKbox = { "Yes", "No" };

	String[] checkboxes = { "TRUE", "FALSE" };

	String[] authorizationsSigned = { "Yes", "No" };

	String[] legalRepfirstNames = { "John", "Mike", "Jack", "Ross", "Julie", "Joe", "Rosy" };

	String[] legalReplastNames = { "Doe", "Singh", "Daniels", "White", "Lee", "Kim", "Smith" };

	String[] relationship = { "Spouse/Partner", "Parent", "Guardian", "Child", "Caregiver", "Other" };

	String[] relationshipToPatient = { "Self", "Spouse", "Child", "Unknown", "Other Relationship" };

	String[] preSpecialties = { "DERMATOLOGY", "DERMATOPATHOLOGY", "Dialysis", "CYTOPATHOLOGY", "Cosmetic Surgery",
			"Bariatrics","ANESTHESIOLOGY" };

	String[] facilityNames = { "Mercy Hospital", "Mount Sinai Medical Center", "Mayo Clinic", "Cleveland Clinic",
			"Johns Hopkins Hospital", "Massachusetts General Hospital", "UCLA Medical Center", "Stanford Health Care",
			"NewYork-Presbyterian Hospital", "Vanderbilt University Medical Center" };

	String[] officeFirstNames = { "John", "Jane", "Alice", "Bob", "Michael", "Emily", "David", "Sarah", "Daniel",
			"Olivia", "James", "Emma", "William", "Ava", "Liam" };

	String[] officeLastNames = { "Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson", "Moore",
			"Taylor", "Anderson", "Thomas", "Jackson", "White", "Harris" };

	String[] dupixentOptions = { "Dupixent 200 MG/1.14ML pre-filled syringe", "Dupixent 200 MG/1.14ML pre-filled pen",
			"Dupixent 300 MG/2ML pre-filled syringe", "Dupixent 300 MG/2ML pre-filled pen" };

	String[] drugAllergies = { "Penicillin", "Aspirin", "Ibuprofen", "Sulfa drugs", "Codeine", "Insulin",
			"Cephalosporins", "Erythromycin", "Amoxicillin", "Naproxen" };

	String[] collaboratingMDFirstNames = { "Emily", "Andrew", "Sophia", "Michael", "Olivia", "William", "Emma",
			"Daniel", "Ava", "Alexander", "Brooklyn", "Peyton", "Addison", "Kennedy", "Zoe", "Levi", "Paisley", "Maya",
			"Charlotte", "Amelia", "Madison", "Ella", "Abigail", "Lily", "Isabella", "Kinsley", "Avery", "Harper",
			"Piper", "Zoe", "Sophie", "Sophia", "Victoria", "Addison", "Lily", "Levi", "Grace", "Lana" };
}
