package com.sanofi.selenium.xpaths;

import org.openqa.selenium.By;

public interface casesPageXpaths {

	/************************
	 * Elements
	 **************************************************/
	public static By elesave = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Cancel\"]/following::*[text()=\"Save\"]");
	public static By sucessToastMessage = By.xpath("//*[contains(@class,'toastContent')]//span");
	public static By CaseRecordTypeTextValue = By.xpath(
			"//*[contains(@class,'active lafPageHost')]//*[text()='Case Record Type']/parent::div/parent::*//following-sibling::*//*[contains(@class,'recordTypeName')]/span");
	public static By InputComments = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//textarea[@role='textbox']");
	public static By HouseholdIncome = By
			.xpath("//*[text()=\"Household Income\"]//parent::label//following-sibling::div//input");
	public static By taskCompletedButton = By
			.xpath("//*[contains(@class,\"maximized active lafPageHost\")]//button//span[text()=\"Completed\"]");
	public static By systemGeneratedTaskCheckBox = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"System Generated Task\"]/parent::div/parent::*//following-sibling::*//img[@class=' checked']");
	public static By caseLabel = By
			.xpath("//*[contains(@class,'active lafPageHost')]//*[contains(@class,'entityNameTitle')]");
	public static By changeOwnerSearchBox = By.xpath("//*[@title='Search Users']");
	public static By changeOwnerSearchResult = By.xpath("//*[text()[contains(.,'in Users')]]");
	public static By changeOwnerSubmitButton = By.xpath("//button[@title='Submit' or @name=\"change owner\"]");
	public static By eleApprovalSubmitButton = By.xpath("//button[@title='Submit']");
	
	public static By eleEnrollButton = By.xpath("//button[@name='Case.iCC_Enroll']");
	public static By eleSaveEditButton = By.xpath("//button[@name='SaveEdit']");
	// public static By coverageResultPopUp = By.xpath("//*[text()='Program Coverage
	// Results']");
	public static By eleCaseNumberLink = By.xpath("//span[@title='Case']//a");
	public static By eleProgCaseNumberLink = By.xpath("//span[text()='Program']/../../following-sibling::*//a//span");
	// public static By eleCaseOutcomeText = By.xpath("//*[contains(@class,'active
	// lafPageHost')]//*[text()='Case
	// Outcome']/parent::div//following-sibling::div//lightning-formatted-text");
	// public static By eleStatusText = By.xpath("//*[contains(@class,'active
	// lafPageHost')]//*[text()='Status']/parent::div//following-sibling::div//lightning-formatted-text");
	public static By programCoverageUpdate = By.xpath(
			"//*[contains(@class,'active lafPageHost')]//*[@placeholder='Search Program Coverage...']/parent::div/child::input");
	public static By eleTaskAssignedToText = By.xpath(
			"//*[contains(@class,'active lafPageHost')]//*[text()='Assigned To']/parent::div/parent::*//following-sibling::*//span//div/span");
	public static By eleIndexAnchorLink = By
			.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='Index Family']//parent::div//..//..//a");
	public static By eleChangeRecordTypeBTN = By.xpath(
			"//*[contains(@class,'active lafPageHost')]//*[text()=\"Case Record Type\"]//parent::div/parent::*//following-sibling::*//*[text()=\"Change Record Type\"]//ancestor::button");
	public static By addElement = By.xpath("//*[contains(@class,'active lafPageHost')]//button[text()='Add']");
	public static By saveElement = By.xpath("//*[contains(@class,'active lafPageHost')]//div//button[text()='Save']");
	public static By missingInformationTab = By
			.xpath("//*[contains(@class,'active lafPageHost')]//span[@title='Missing Information']");
	public static By strNewprogramCoverageIcon = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*//*[@title='New Program Coverage']");
	public static By strnNewprogramCoveragePopUpFreeGoodsType = By
			.xpath("//*[text()='Free Goods Coverage']//parent::div//preceding-sibling::div//input");
	public static By strFooterSaveBTN = By.xpath("//*[contains(@class,'modal-footer')]//*[@title='Save']");
	public static By strNextButton = By.xpath("//*[contains(@class,'modal-footer')]//*[text()='Next']");
	public static By strSearchProgramCase = By
			.xpath("//*[contains(@class,'modal-container')]//input[@placeholder=\"Search Cases...\"]");
	public static By strRow = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//div[@class='slds-tabs_scoped__content slds-show']//div//table//tbody//td[2]//div");
	public static By strRowPiece = By.xpath("//*[contains(@class,'active lafPageHost')]//table//tbody//tr//th//*//div");
	public static By strRowCategory = By.xpath(
			"//*[contains(@class,'active lafPageHost')]//table//tbody//tr//td//*//div//lightning-base-formatted-text");
	public static By modalContainerInputComments = By.xpath("//*[contains(@class,\"modal-container\")]//textarea[@role='textbox']");
	public static By submitForApprovalCommentTextBox = By.xpath(
			"//span[text()='Comments']//parent::label//following-sibling::textarea");
	public static By eleCommentText=By.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='Comments']//parent::div//..//span[text()='Testing']");

	/****************** Dynamic Locators *****************************************/
	public static String caseCreationInputsXpath = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::span//following-sibling::div//a";
	// public static String missingInfoXpath =
	// "//*[text()=\"{0}\"]/following-sibling::div//*[text()=\"{1}\"]";
	public static String moveSelectionToChosenXpath = "//*[text()=\"{0}\"]/following-sibling::div//*[text()=\"Move selection to Chosen\"]";
	public static String dropdownOptionsXpath = "//div[contains(@class,\"short visible positioned\")]//a[@title=\"{0}\"]";
	public static String strOwnerXpath = "//div[@class=\"name\"]//*[contains(text(),\"{0}\")]";
	public static String strTextElement = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String caseType = "//*[contains(@class,\"windowViewMode-normal isModal\")]//label//*[contains(text(),\"{0}\")]";
	public static String LinkText = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*//span//a//span";
	public static String taskLink = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*//span//a";
	public static String recordTypeText = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*//*[contains(@class,\"recordTypeName\")]/span";
	public static String TaskSubject = "//*[contains(@class,\"active lafPageHost\")]//a[@title =\"{0}\"]";
	public static String UpdateValue = "//*[contains(@class,\"active lafPageHost\")]//a[text()=\"{0}\"]//parent::li/a";
	public static String FetchCaseNumber = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*//a";
	public static String SelectField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::*//following-sibling::div//button";
	public static String ChooseFromDropdown = "//*[contains(@class,\"active lafPageHost\")]//*[@title=\"{0}\"]/parent::span";
	// public static String strOptionvalueXpath = "//*[contains(@class,\"active
	// lafPageHost\")]//*[text()=\"{1}\"]//parent::*//*[@title=\"{0}\"]/parent::span";
	public static String ViewAllLinks = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String serviceCaseInputsXpath = "//*[text()=\"{0}\"]//parent::label//following-sibling::div//input";
	public static String serviceProgramDropdowmXpath = "//div[contains(@class,\"contentWrapper\")]//div[@title=\"{0}\"]";
	public static String caseHeaderInfo = "//*[contains(@class,\"maximized active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//parent::div//following-sibling::p//lightning-formatted-text";
//	public static String dateField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label/following-sibling::div//input";
	public static String LightningTabBar = "//*[contains(@class,\"active lafPageHost\")]//ul[@role=\"tablist\"]//li//*[text()=\"{0}\"]";
	// public static String linkTitle = "//a[@title=\"{0}\"]";
	public static String caseFieldValueWhileEdit = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*/div//span//span//slot";
	public static String relatedListContainers = "//*[contains(@class,\"active lafPageHost\")]//span[@title=\"{0}\"]";
	public static String dropdownButtonXpath = "//span[text()=\"{0}\"]//parent::span/parent::div[contains(@class,\"uiInputSelect\")]//following-sibling::div//a";
	// public static String relatedToDropdown = "//*[contains(@class,\"active
	// lafPageHost\")]//*[text()=\"Related
	// To\"]/parent::label//following-sibling::div//a//div";
	// public static String relatedToValue =
	// "//*[contains(@class,\"entityMenuList\")]/div//ul//li//a[@title=\"Cases\"]";
	public static String caseListOption = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/ancestor::td//preceding-sibling::th//a";
	public static String caseListOptionWithStatus = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/ancestor::tr//*[text()=\"{1}\"]//ancestor::td//preceding-sibling::th//a";
	public static String strChooseStatusModal = "//div[contains(@class,\"slds-modal\")]//*[text()=\"{0}\"]";
	public static String strCaseUpdateFieldDropdown = "//label[text()=\"{0}\"]//parent::lightning-combobox//div//lightning-base-combobox-item//span[text()=\"{1}\"]";
	public static String strTablelink = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/ancestor::td/preceding-sibling::th//span//a";
	public static String textAreaField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//..//parent::*//following-sibling::div//textarea";
	public static String strCheckboxesXpath = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//parent::label//following-sibling::div//input";
	public static String strFollowUp="//*[contains(@class,\"active lafPageHost\")]//span[text()=\"Create Follow-up\"]//parent::label//parent::div//input";
	public static String textSubject = "//*[contains(@class,\"active lafPageHost\")]//*//a[@title=\"{0}\"]//ancestor::td//preceding-sibling::th//*//a[@title=\"{1}\"]";
	public static String comboCoverageDropDown = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Program Coverage\"]//ancestor::lightning-grouped-combobox//*//li//*[text()=\"{0}\"]";
	public static String LightningNumberText = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*//lightning-formatted-number";
	public static String strSearchTextBox = "//*[contains(@class,\"active lafPageHost\")]//*[@placeholder=\"{0}\"]";
	public static String strSearchDropdownOptionsList = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::lightning-grouped-combobox//*//li//*[text()=\"{1}\"]";
	public static String dropdownOptionsXpath1 = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-dropdown-trigger_click slds-is-open\")]//*[@title=\"{0}\"]";
	public static String caseCreationInputsXpath1 = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::*//following-sibling::div//button";
	public static String strServiceCaseEditPopUpXpathDropdown = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@aria-label,\"{0}\")]";
	public static String TaskSubjectWithStatus = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::td/preceding-sibling::th//a[@title =\"{1}\"]";
	public static String changeCaseType = "//*[text()=\"{0}\"]//parent::div//preceding-sibling::div//span[@class=\"slds-radio--faux\"]";
	public static String strTextBTN = "//*[text()=\"{0}\"]";
	public static String strFRMUpdateDropdownValue = "//a[text()=\"{0}\"]//parent::li/a";
	public static String strCaseWithStatus = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/ancestor::td//preceding-sibling::td//*[text()=\"{1}\"]//ancestor::td//preceding-sibling::th//span//a";
	public static String availableoptionXpath = "//*[text()=\"{0}\"]/following-sibling::div//*[text()=\"{1}\"]";
	public static String missingInformationDialogboxText = "//*[contains(@class,\"active lafPageHost\")]//a[text()=\"{0}\"]";
	public static String missingInformationTextXpath = "//*[contains(@class,\"active lafPageHost\")]//tr//td//div[text()=\"{0}\"]";
	public static String strmissingInformationname = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strmiTabfieldText = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::div/parent::*/following-sibling::*//span";
	public static String inputBox = "//*[contains(@class,\"active lafPageHost\")]//div//label[text()=\"{0}\"]/parent::div//input";
	public static String MissingInformationCheckBOX = "//*[contains(@class,\"active lafPageHost\")]//tr//th//*[text()=\"{0}\"]/ancestor::tr//input[contains(@type,'checkbox')]//parent::span";
	public static String strmissingInformationID = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::tr//th//*//a//span";
	public static String strmiExistingInfoCheckBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/ancestor::tr//lightning-input//input[contains(@type,'checkbox')]/../label//span";
	public static String serviceCaseInputsXpathPopUp = "//*[contains(@class,\"modal-container\")]//*[text()=\"{0}\"]//parent::label//following-sibling::div//input";

	public static String modelContainerOptions = "//div[@title=\"{0}\"]";
	public static String federalPovertyLevelEditButton = "//*[contains(@class,'active lafPageHost')]//*[text()='Federal Poverty Level']//parent::div//parent::div//parent::*/..//button[@title='Edit Federal Poverty Level']";
	public static String updatefederalPovertyAndTransactionDateValue = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//input";
	
	public static String approvalHistoryRecordLink = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	
	// public static String fieldInput = "//*[contains(@class,\"active
	// lafPageHost\")]//label[text()=\"{0}\"]/following-sibling::div//input";
	//	public static By programCoverageInput = By.xpath("//*[contains(@class,'active lafPageHost')]//*[@title=\"Search Program Coverage\"]/parent::div/child::input");
	// public static By changeOwnerSearchOption = By.xpath("//div[@class='name']//*[contains(text(),'Ashfield CE User')]");
	// public static By firstOption = By.xpath("//*[contains(@class,\"maximized
	// active lafPageHost\")]//*[@class='listContent']//li[1]");
	public static String caseStatus = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/ancestor::tr//*[text()=\"{1}\"]";
	public static String btnspanText = "//span[text()=\"{0}\"]";
    public static String strlinkTextAnchorTag = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*//a";
    public static String taskUpdateOptions = "//a[@title=\"{0}\"]";
    public static String statusTextContains = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]/parent::div/parent::*//following-sibling::*//*[contains(text(),\"{1}\")]";
    public static String selectFieldDialog = "//*[contains(@role,\"dialog\")]//*[text()=\"{0}\"]/parent::*//following-sibling::div//button";
}
