package com.sanofi.selenium.apiutils;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Predicate;
import java.util.zip.*;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;
import com.sanofi.selenium.utils.ReadExcel;
import java.nio.file.attribute.*;
import java.time.Instant;
import com.sanofi.selenium.utils.Log;
//************************Please dont touch and duplicate any variables of below Class***************************************************//
/**
 * This method to use for compress a directory in ZIP format.
 *
 * @author Pratiksha Dixit
 */
public class ZipDirectory {
	/**
	 * This method is the entry point for creating a zip file.
	 *
	 * @param destinationDir: absolute path of the distinaition folder.
	 * @param zipName:        destination file name to be zipped e.g. myZipfile.zip
	 * @param deleteExisting: whether to delete the existing zip file under
	 *                        destination dir with zipName
	 * @param filePredicate:  if this predicate returns true the file is included in
	 *                        the zip otherwise it's not included.
	 * @param sourceDirs:     multiple source directories to be zipped.
	 * @throws IOException
	 * @author pratidixit
	 */
	public static void ZipDirs(String destinationDir, String zipName, boolean deleteExisting,
			Predicate<File> filePredicate, String methodName, String... sourceDirs) throws IOException {
		ReentrantLock lock = new ReentrantLock();
		try {
			lock.lock();
			File destinationDirFile = new File(destinationDir);
			File zipFile = new File(destinationDir + File.separatorChar + zipName);

			if (!destinationDirFile.exists()) {
				if (!destinationDirFile.mkdirs()) {
					Log.info("cannot create directories ");
				}
			} else {
				boolean exists = zipFile.exists();
				if (exists && deleteExisting && !zipFile.delete()) {
					Log.info("cannot delete existing zip file: " + zipFile.getAbsolutePath());
				} else if (exists && !deleteExisting) {
					System.out.println("Zip file already exists: " + zipFile.getAbsolutePath());
					return;
				}
			}

			if (sourceDirs == null) {
				Log.info("Source dirs are null");

			}

			try (ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile)))) {

				for (String sourceDir : sourceDirs) {
					File sourceDirFile = new File(sourceDir);
					if (!sourceDirFile.exists()) {
						Log.info("Source dir doesn't exists " + sourceDirFile);
					}

					addDirRecursively(methodName, sourceDirFile.getName(), sourceDirFile.getAbsolutePath(),
							sourceDirFile, out, filePredicate);
				}
			}
			System.out.println("Zipping successfully completed");
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			lock.unlock();
		}
	}

	private static String fileToRelativePath(File file, String baseDir) {
		return file.getAbsolutePath().substring(baseDir.length() + 1);

	}

	private static void addDirRecursively(String methodName, String baseDirName, String baseDir, File dirFile,
			final ZipOutputStream out, Predicate<File> filePredicate) throws IOException {

		File[] files = dirFile.listFiles();
		if (!(baseDirName.equals("reports"))) {
			baseDirName = "Screenshots/" + methodName + "/" + baseDirName;
		}
		if (files != null) {
			for (File file : files) {
				if (!filePredicate.test(file)) {
					continue;
				}
				if (file.isDirectory()) {
					addDirRecursively(methodName, baseDirName, baseDir, file, out, filePredicate);
					continue;
				}
				ZipEntry zipEntry = new ZipEntry(baseDirName + File.separatorChar + fileToRelativePath(file, baseDir));
				BasicFileAttributes attr = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
				zipEntry.setLastModifiedTime(attr.lastModifiedTime());
				zipEntry.setCreationTime(attr.creationTime());
				zipEntry.setLastAccessTime(attr.lastAccessTime());
				zipEntry.setTime(attr.lastModifiedTime().toMillis());

				out.putNextEntry(zipEntry);
				try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(file))) {
					byte[] b = new byte[1024];
					int count;
					while ((count = in.read(b)) > 0) {
						out.write(b, 0, count);
					}
					out.closeEntry();
				}
			}
		}
	}

}
