package com.sanofi.selenium.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class IAPPage extends Utility_Function {

	public IAPPage(WebDriver driver) {
		super(driver);
	}

	Random rnd = new Random();

	/************************
	 * Elements
	 **************************************************/
	public static By eleNewBtn = By.xpath("//*[contains(@class, \"active lafPageHost\")]//button[text()='New']");
	public static By eleStartNewServiceButton = By.xpath(
			"//*[contains(@class, \"active lafPageHost\")]//*[text()=\"Start New Service\" and @type='button']");
	public static By eleNewServiceTitle = By
			.xpath("//*[contains(@class, \"active lafPageHost\")]//*[contains(text(),\"Start New Service\")]");
	public static By eleSelectDropDown = By.xpath("//*[contains(@class,\"active lafPageHost\")]//select");
	public static By eleMainTaskStatus = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"status-text\")]");
	public static By eleMainTaskStatus2 = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"status-text\")])[2]");
	public static By eleCPEWorkOrder = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Care Program Enrollee Work Order\"]");
	public static By eleAccountName = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),'Account')]//parent::div//span//child::slot//child::slot//span");
	public static By eleHealthCondtionRec = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[starts-with(text(), 'CON-')]//parent::span");
	public static By siteRecord = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Site\"]//parent::div//following-sibling::div//a");
	public static String strCondCode = "(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]/parent::div//following-sibling::div//a//slot//span)[2]";
	public static By eleOrderTable = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Orders\"]//tbody//tr");
	public static By eleCPEPTable = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//h1[@title=\"Care Program Enrollee Products\"]//following::tbody//tr");
	//public static By checkboxAttestation = By.xpath("//span/input[@type='checkbox' and @name='cbAttestation']");
	
	/************************
	 * Dynamic Elements
	 **************************************************/

	public static String eleButton = "//*[contains(@class,\"active lafPageHost\")]//button[@title=\"{0}\"]";
	public static String strTaskName = "//*[contains(@class,\"active lafPageHost\")]//h3[@class=\"slds-section__title\"]//*[text()=\"{0}\"]";
	public static String strSubtaskName = "//*[@class=\"card\"]//*[text()=\"{0}\"]";
	public static String taskButton = "(//*[contains(@class,\"active lafPageHost\")]//h3[@class=\"slds-section__title\"]//*[text()=\"{0}\"]//parent::div//span)[1]";
	public static String strSubTaskStatus = "(//*[@class=\"card\"]//*[text()=\"{0}\"]//parent::div//li)[2]";
	public static String subTaskButton = "//*[contains(@class,\"active lafPageHost\")]//div[@class=\"card\"]//*[text()=\"{0}\"]//parent::div";
	public static String strTaskTitle = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strDropDownInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]";
	public static String strInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::input";
	public static String strInputDateBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//input";
	public static String searchDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//span[contains(@class,\"option-text\")]";
	public static String button = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";
	public static String detailTabField = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//a";
	public static String editButton = "//*[contains(@class,\"active lafPageHost\")]//button[@title=\"{0}\"]";
	public static String editFieldList = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//button//span";
	public static String editFieldListOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//lightning-base-combobox-item";
	public static String inputField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//input";
	public static String strAccountObjectsCreated = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String relatedTabSection = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strAccountObjectDetails = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-text";
	public static String correspondenceInputField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"slds-form-element\")]//lightning-formatted-text";
	public static By checkboxAttestation = By.xpath("//*[@type='checkbox' and @name='cbAttestation']");
	/**
	 * Function: Click on start new service button
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnStartNewService() {
		try {
			scrollToTopOfPage();
			waitAndVerifyElement(eleStartNewServiceButton);
			waitForvisiblityOfElementLocated(eleStartNewServiceButton);
			scrollToElement(eleStartNewServiceButton);
			click(eleStartNewServiceButton);
			LoggingInfo("Clicked on 'Start New Service Button'");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click On Start New Service " + e.getMessage());
			Assert.fail("Failed to click On Start New Service " + e.getMessage());
		}
	}

	/**
	 * Function: verify Service Title
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyServiceTitle() {
		try {
			waitForPageLoaded();
			waitAndVerifyElement(eleNewServiceTitle);
			LoggingInfo("Start New Service pop up id loaded");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to verify Service Title " + e.getMessage());
			Assert.fail("Failed to verify Service Title " + e.getMessage());
		}
	}

	/**
	 * Function: Select service as IAP
	 * 
	 * @author Trupti Zure
	 **/

	public void selectService() {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			selectItemFromList(eleSelectDropDown, "IAP");
			LoggingInfo("Selected Service as IAP");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Service " + e.getMessage());
			Assert.fail("Failed to select Service " + e.getMessage());
		}
	}

	// Anand P
	public void selectQSService() {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			selectItemFromList(eleSelectDropDown, "Quick Start");
			LoggingInfo("Selected Service as QS");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Service " + e.getMessage());
			Assert.fail("Failed to select Service " + e.getMessage());
		}
	}
	
	
	/**
	 * Function:Check Attestation checkbox
	 *
	 * @author Shraddha Shetty
	 **/
	public void checkAttestationcheckboxIfPresent() {
		try {
			setTimeOut(1000);
			if(isElementPresent(checkboxAttestation)) {
				clickByJavascript(checkboxAttestation);
				LoggingInfo("Attestation checkbox selected");
				missingInformatioPage.clickNextButton();
			}else {
				LoggingInfo("Attestation checkbox not present");
			}
			
		//	missingInformatioPage.clickNextButton();
			
		} catch (Exception e) {
			Log.error("Failed to check Attestation checkbox " + e.getMessage());
			Assert.fail("Failed to check Attestation checkbox " + e.getMessage());
		}
	}

	// Anand P
	public void selectQSReason() {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			String reason = "Migrated Patient";
			selectItemFromList(eleSelectDropDown, reason);
			LoggingInfo("Selected Reason as-" + reason);
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Reason " + e.getMessage());
			Assert.fail("Failed to select Reason " + e.getMessage());
		}
	}

	/**
	 * Function: Select reason
	 * 
	 * @author Trupti Zure
	 **/
	public void selectReason() {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			//String reason = "Lapse in coverage";
			selectItemFromList(eleSelectDropDown, "Lapse in coverage");
			//LoggingInfo("Selected Reason as-" + reason);
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Reason " + e.getMessage());
			Assert.fail("Failed to select Reason " + e.getMessage());
		}
	}

	/**
	 * Function: check IAP WO has been initiated
	 * 
	 * @author Trupti Zure
	 **/
	public void checkIAPIntiation() {
		try {
			setTimeOut(10000);
			By IAPButton = getDynamicElement(eleButton, "IAP");
			waitAndVerifyElement(IAPButton);
			scrollToElement(IAPButton);
			click(IAPButton);
			String buttonState = getAttributeValue(IAPButton, "aria-pressed");
			// Assert the state of the button
			Assert.assertEquals(buttonState, "true", "IAP flow is initialized");
			LoggingInfo("IAP flow is initialized");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to check the status of IAP intiation " + e.getMessage());
			Assert.fail("Failed to check the status of IAP intiation " + e.getMessage());
		}
	}

	// Anand P
	public void enterExtendDiscontinue() {
		try {
			By enrollmentReasonDropDWN = getDynamicElement(strDropDownInputBox, "Extend?");
			waitAndVerifyElement(enrollmentReasonDropDWN);
			scrollToElement(enrollmentReasonDropDWN);
			click(enrollmentReasonDropDWN);
			String reason = "No";
			By enrollmentReasonDropDWNOPtions = getDynamicElement(strDropDownOptions, "Extend?");
			waitAndVerifyElement(enrollmentReasonDropDWNOPtions);
			selectItemFromList(enrollmentReasonDropDWN, enrollmentReasonDropDWNOPtions, reason, "Extend?");

			By enrollmentReasonDropDWN2 = getDynamicElement(strDropDownInputBox, "Discontinue?");
			waitAndVerifyElement(enrollmentReasonDropDWN2);
			scrollToElement(enrollmentReasonDropDWN2);
			click(enrollmentReasonDropDWN2);
			String reason2 = "Yes";
			By enrollmentReasonDropDWNOPtions2 = getDynamicElement(strDropDownOptions, "Discontinue?");
			waitAndVerifyElement(enrollmentReasonDropDWNOPtions2);
			selectItemFromList(enrollmentReasonDropDWN2, enrollmentReasonDropDWNOPtions2, reason2, "Discontinue?");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter Extend details " + e.getMessage());
			Assert.fail("Failed to enter Extend details " + e.getMessage());
		}
	}

	//Anand P
	public void enterExtendDiscontinueReason(String reason1, String reason2) {
		try {
			By enrollmentReasonDropDWN = getDynamicElement(strDropDownInputBox, "Extend?");
			waitAndVerifyElement(enrollmentReasonDropDWN);
			scrollToElement(enrollmentReasonDropDWN);
			click(enrollmentReasonDropDWN);
			String resn1 = reason1;
			By enrollmentReasonDropDWNOPtions = getDynamicElement(strDropDownOptions, "Extend?");
			waitAndVerifyElement(enrollmentReasonDropDWNOPtions);
			selectItemFromList(enrollmentReasonDropDWN, enrollmentReasonDropDWNOPtions, resn1, "Extend?");

			if(resn1=="No") {
			By enrollmentReasonDropDWN2 = getDynamicElement(strDropDownInputBox, "Discontinue?");
			waitAndVerifyElement(enrollmentReasonDropDWN2);
			scrollToElement(enrollmentReasonDropDWN2);
			click(enrollmentReasonDropDWN2);
			String resn2 = reason2;
			By enrollmentReasonDropDWNOPtions2 = getDynamicElement(strDropDownOptions, "Discontinue?");
			waitAndVerifyElement(enrollmentReasonDropDWNOPtions2);
			selectItemFromList(enrollmentReasonDropDWN2, enrollmentReasonDropDWNOPtions2, resn2, "Discontinue?");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter Extend details " + e.getMessage());
			Assert.fail("Failed to enter Extend details " + e.getMessage());
		}
	}
	
	
	// Anand P
	public void clickOnTask2() {
		try {
			By taskName = getDynamicElement(strTaskName, "Extend/Discontinue");
			waitAndVerifyElement(taskName);
			scrollToElement(taskName);
			clickByJavascript(taskName);

			By eleSubTaskButton = getDynamicElement(subTaskButton, "Extend/Discontinue");
			waitAndVerifyElement(eleSubTaskButton);
			scrollToElement(eleSubTaskButton);
			clickByJavascript(eleSubTaskButton);
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to click on task " + e.getMessage());
			Assert.fail("Failed to click on task " + e.getMessage());
		}
	}

	/**
	 * 
	 * /** Function: check IAP WO task has been initiated
	 * 
	 * @author Trupti Zure
	 **/

	public void checkIAPTaskInitiation() {
		try {

			// IAP Summary Task
			By taskName = getDynamicElement(strTaskName, "IAP Summary");
			waitAndVerifyElement(taskName);
			scrollToElement(taskName);
			LoggingInfo("IAP Summary task has been initialized");
			setTimeOut(2000);

			By eleTaskButton = getDynamicElement(taskButton, "IAP Summary");
			scrollToElement(eleTaskButton);
			click(eleTaskButton);
			LoggingInfo("Clicked on IAP Summary task");
			setTimeOut(1000);

			By subTaskName = getDynamicElement(strSubtaskName, "IAP Enrollment");
			waitAndVerifyElement(subTaskName);
			LoggingInfo("IAP Summary sub task- IAP Enrollment has been initialized");
			setTimeOut(2000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, "IAP Enrollment");
			waitAndVerifyElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Not Started", "IAP Enrollment task status verified");

		} catch (Exception e) {
			Log.error("Failed to check the status of IAP intiation " + e.getMessage());
			Assert.fail("Failed to check the status of IAP intiation " + e.getMessage());
		}
	}

	/**
	 * Function: Click on IAP enrollment task
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnTask() {
		try {
			By eleSubTaskButton = getDynamicElement(subTaskButton, "IAP Enrollment");
			waitAndVerifyElement(eleSubTaskButton);
			click(eleSubTaskButton);
			setTimeOut(2000);
			// closeTaskLoadingWindowIfVisible();
		} catch (Exception e) {
			Log.error("Failed to click on task " + e.getMessage());
			Assert.fail("Failed to click on task " + e.getMessage());
		}
	}

	/**
	 * Function: Verify task is loaded
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyTaskIsLoaded(String taskTitle) {
		try {
			waitForPageLoaded();
			By tasktitle = getDynamicElement(strTaskTitle, taskTitle);
			waitForvisiblityOfElementLocated(tasktitle);
			LoggingInfo(taskTitle + "-task is loaded");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to if verify Task Is Loaded " + e.getMessage());
			Assert.fail("Failed to if verify Task Is Loaded " + e.getMessage());
		}
	}

	/**
	 * Function: Enter Eligibility Criteria
	 * 
	 * @author Trupti Zure
	 **/
	public void enterEligibilityCriteria() {
		try {

			By enrollmentReasonDropDWN = getDynamicElement(strDropDownInputBox, "Enrollment Reason");
			waitAndVerifyElement(enrollmentReasonDropDWN);
			scrollToElement(enrollmentReasonDropDWN);
			click(enrollmentReasonDropDWN);
			String reason = "PA Processing";
			By enrollmentReasonDropDWNOPtions = getDynamicElement(strDropDownOptions, "Enrollment Reason");
			waitAndVerifyElement(enrollmentReasonDropDWNOPtions);
			selectItemFromList(enrollmentReasonDropDWN, enrollmentReasonDropDWNOPtions, reason, "Enrollment Reason");

			String[] dropdownLabels = { "Seeking PA Approval?", "Patient resides in US/PR?", "HCP in US/PR?" };
			for (String dropdownLabel : dropdownLabels) {
				By dropdownInputBox = getDynamicElement(strDropDownInputBox, dropdownLabel);
				waitAndVerifyElement(dropdownInputBox);
				scrollToElement(dropdownInputBox);
				click(dropdownInputBox);
				By dropdownOptions = getDynamicElement(strDropDownOptions, dropdownLabel);
				waitAndVerifyElement(dropdownOptions);
				selectItemFromList(dropdownInputBox, dropdownOptions, "Yes", dropdownLabel);
				LoggingInfo("Selected " + dropdownLabel + " as- Yes");
				setTimeOut(1000);
			}

			String[] dropdownLabels2 = { "Off-label indication?", "Inpatient?", "New to therapy?" };
			for (String dropdownLabel2 : dropdownLabels2) {
				By dropdownInputBox = getDynamicElement(strDropDownInputBox, dropdownLabel2);
				waitAndVerifyElement(dropdownInputBox);
				scrollToElement(dropdownInputBox);
				click(dropdownInputBox);
				By dropdownOptions = getDynamicElement(strDropDownOptions, dropdownLabel2);
				waitAndVerifyElement(dropdownOptions);
				selectItemFromList(dropdownInputBox, dropdownOptions, "No", dropdownLabel2);
				LoggingInfo("Selected " + dropdownLabel2 + " as- No");
				setTimeOut(1000);
			}
		} catch (Exception e) {
			Log.error("Failed to enter Eligibility Criteria " + e.getMessage());
			Assert.fail("Failed to enter Eligibility Criteria " + e.getMessage());
		}
	}

	/**
	 * Function: Click on IAP task
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnIAP() {
		try {
			setTimeOut(1000);
			By quickStartButton = getDynamicElement(eleButton, "IAP");
			waitAndVerifyElement(quickStartButton);
			click(quickStartButton);
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click on IAP " + e.getMessage());
			Assert.fail("Failed to click on IAP " + e.getMessage());
		}
	}

	/**
	 * Function: Check IAP task completion
	 * 
	 * @author Trupti Zure
	 **/
	public void checkIAPTaskComplition() {
		try {

			waitAndVerifyElement(eleMainTaskStatus);
			String mainTaskStatus = getText(eleMainTaskStatus);
			Assert.assertEquals(mainTaskStatus, "Done", "IAP Summary task completed successfully");
			LoggingInfo("IAP Summary task completed successfully");

			By eleTaskButton = getDynamicElement(taskButton, "IAP Summary");
			click(eleTaskButton);
			LoggingInfo("Clicked on IAP summary task");
			setTimeOut(1000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, "IAP Enrollment");
			waitAndVerifyElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Completed", "IAP Enrollment sub task completed successfully");
			LoggingInfo("IAP Enrollment sub task completed successfully");
		} catch (Exception e) {
			Log.error("Failed to check IAP TaskComplition " + e.getMessage());
			Assert.fail("Failed to check IAP TaskComplition " + e.getMessage());
		}
	}

	/**
	 * Function: Check IAP Extend/Discontinue Task Initiation
	 * 
	 * @author Trupti Zure
	 **/

	public void checkIAPSecondTaskInitiation() {
		try {

			// Extend/Discontinue Task
			By taskName = getDynamicElement(strTaskName, "Extend/Discontinue");
			waitAndVerifyElement(taskName);
			scrollToElement(taskName);
			LoggingInfo("Extend/Discontinue task has been initialized");
			setTimeOut(2000);

			By eleTaskButton = getDynamicElement(taskButton, "Extend/Discontinue");
			scrollToElement(eleTaskButton);
			click(eleTaskButton);
			LoggingInfo("Clicked on Extend/Discontinue task");
			setTimeOut(1000);

			By subTaskName = getDynamicElement(strSubtaskName, "Extend/Discontinue");
			waitAndVerifyElement(subTaskName);
			LoggingInfo("Extend/Discontinue sub task- IAP Enrollment has been initialized");
			setTimeOut(2000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, "Extend/Discontinue");
			waitAndVerifyElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Not Started", "Extend/Discontinue task status verified");

		} catch (Exception e) {
			Log.error("Failed to check IAP Task Complition " + e.getMessage());
			Assert.fail("Failed to check IAP Task Complition " + e.getMessage());
		}
	}

	/**
	 * Function: Click on Extend/Discontinue task
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnIAPTask() {
		try {

			By eleSubTaskButton = getDynamicElement(subTaskButton, "Extend/Discontinue");
			waitAndVerifyElement(eleSubTaskButton);
			clickByJavascript(eleSubTaskButton);
			setTimeOut(2000);
			// closeTaskLoadingWindowIfVisible();
		} catch (Exception e) {
			Log.error("Failed to click on IAP task " + e.getMessage());
			Assert.fail("Failed to click on IAP task " + e.getMessage());
		}
	}

	/**
	 * Function: Enter data in Discontinue
	 * 
	 * @author Trupti Zure
	 **/

	public void enterDiscontinue() {
		try {
			By discontinueDropDWN = getDynamicElement(strDropDownInputBox, "Discontinue?");
			waitAndVerifyElement(discontinueDropDWN);
			scrollToElement(discontinueDropDWN);
			click(discontinueDropDWN);
			String extend = "Yes";
			By discontinueDropDWNDropDWNOptions = getDynamicElement(strDropDownOptions, "Discontinue?");
			waitAndVerifyElement(discontinueDropDWNDropDWNOptions);
			selectItemFromList(discontinueDropDWN, discontinueDropDWNDropDWNOptions, extend, "Discontinue?");
		} catch (Exception e) {
			Log.error("Failed to enter discontinue details " + e.getMessage());
			Assert.fail("Failed to enter discontinue details " + e.getMessage());
		}
	}

	/**
	 * Function: Enter data in Discontinue Reason
	 * 
	 * @author Trupti Zure
	 **/
	public void enterDiscontinuationReason() {
		try {
			By discontinueReasonDropDWN = getDynamicElement(strDropDownInputBox, "Discontinuation Reason");
			waitAndVerifyElement(discontinueReasonDropDWN);
			// scrollToElement(discontinueReasonDropDWN);
			click(discontinueReasonDropDWN);
			String discontinue = "PA approved";
			By discontinueReasonDropDWNDropDWNOptions = getDynamicElement(searchDropDownOptions,
					"Discontinuation Reason");
			waitAndVerifyElement(discontinueReasonDropDWNDropDWNOptions);
			selectItemFromList(discontinueReasonDropDWN, discontinueReasonDropDWNDropDWNOptions, discontinue,
					"Discontinuation Reason");
		} catch (Exception e) {
			Log.error("Failed to enter discontinue reason " + e.getMessage());
			Assert.fail("Failed to enter discontinue reason " + e.getMessage());
		}
	}
	
	//Anand P
	public void enterExtensionReason() {
		try {
			By discontinueReasonDropDWN = getDynamicElement(strDropDownInputBox, "Extension Reason");
			waitAndVerifyElement(discontinueReasonDropDWN);
			// scrollToElement(discontinueReasonDropDWN);
			click(discontinueReasonDropDWN);
			String discontinue = "PA Delayed";
			By discontinueReasonDropDWNDropDWNOptions = getDynamicElement(searchDropDownOptions,
					"Extension Reason");
			waitAndVerifyElement(discontinueReasonDropDWNDropDWNOptions);
			selectItemFromList(discontinueReasonDropDWN, discontinueReasonDropDWNDropDWNOptions, discontinue,
					"Extension Reason");
		} catch (Exception e) {
			Log.error("Failed to enter Extension Reason " + e.getMessage());
			Assert.fail("Failed to enter Extension Reason " + e.getMessage());
		}
	}

	
	/**
	 * Function: Check IAP second task complition
	 * 
	 * @author Trupti Zure
	 **/

	public void checkIAPDiscontinueComplition() {
		try {

			waitAndVerifyElement(eleMainTaskStatus2);
			String mainTaskStatus = getText(eleMainTaskStatus2);
			Assert.assertEquals(mainTaskStatus, "Done", "Extend/Discontinue task completed successfully");
			LoggingInfo("IAP Extend/Discontinue task completed successfully");

			By eleTaskButton = getDynamicElement(taskButton, "Extend/Discontinue");
			click(eleTaskButton);
			LoggingInfo("Clicked on Extend/Discontinue task");
			setTimeOut(1000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, "Extend/Discontinue");
			waitAndVerifyElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Completed", "Extend/Discontinue sub task completed successfully");
			LoggingInfo("IAP Extend/Discontinue sub task completed successfully");
		} catch (Exception e) {
			Log.error("Failed to check IAP Discontinue Complition " + e.getMessage());
			Assert.fail("Failed to check IAP Discontinue Complition " + e.getMessage());
		}
	}

	/**
	 * Function: verify start new service button
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyStartNewServiceButton() {

		try {
			waitAndVerifyElement(eleStartNewServiceButton);
			scrollToElement(eleStartNewServiceButton);
			highLightElement(eleStartNewServiceButton);
			LoggingInfo("Start new service button verified");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to verify  Start New Service " + e.getMessage());
			Assert.fail("Failed to verify  Start New Service " + e.getMessage());
		}

	}

	/**
	 * Function: Check IAP second task initiation
	 * 
	 * @author Trupti Zure
	 **/
	public void checkIAPSecondTask() {
		try {

			// Extend/Discontinue Task
			By taskName = getDynamicElement(strTaskName, "Extend/Discontinue");
			waitAndVerifyElement(taskName);
			LoggingInfo("Extend/Discontinue is present");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to verify second task " + e.getMessage());
			Assert.fail("Failed to verify second task " + e.getMessage());
		}

	}

	/**
	 * Function: Navigate to CPE work order
	 * 
	 * @author Trupti Zure
	 **/

	public void navigateToCPEWorkOrder() {
		try {
			waitAndVerifyElement(eleCPEWorkOrder);
			scrollToElement(eleCPEWorkOrder);
			LoggingInfo("Navigated to CPE work order");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to complete BV flow  " + e.getMessage());
			Assert.fail("Failed to complete BV flow  " + e.getMessage());
		}
	}

	/**
	 * Function: Check CPE work order datas
	 * 
	 * @author Trupti Zure
	 **/

	public void checkCPEWorkOrderData(String careProduct, String patientName) {
		careProduct = careProduct.split(" -")[0];
		By tableRows = By.xpath(
				"//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-border_left\")]//div[contains(@class,\"data-table-row tableRow\")]");

		ArrayList<String> allData = getWorkTableData(tableRows, "CareProgrameeEnrolleeName", "Name", "Status");
		logData("Actual Data:", allData);

		ArrayList<String> expectedData = new ArrayList<>();
		expectedData.add(patientName + " - " + careProduct + ", " + "Benefits Verification" + ", " + "Completed");
	//	expectedData.add(patientName + " - " + careProduct + ", " + "PA/ Appeals" + ", " + "InProgress");
		logData("expecetd Data:", expectedData);
		boolean allExpectedFound = true;
		for (String expected : expectedData) {
			if (!allData.contains(expected)) {
				allExpectedFound = false;
				break;
			}
		}
		if (!allExpectedFound) {
			throw new AssertionError("Not all expected data is present in allData.");
		}
	}

	/**
	 * Function: Navigate to site record
	 * 
	 * @author Trupti Zure
	 **/

	public void navigateToSiteRecord() {
		try {
			refresh();
			By siteName = getDynamicElement(detailTabField, "Site");
			waitAndVerifyElement(siteName);
			//scrollToHalfPage();
			scrollToElement(siteName);
			setTimeOut(3000);
			clickByJavascript(siteName);
			LoggingInfo("Clicked on Site Record");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to navigate to Site record  " + e.getMessage());
			Assert.fail("Failed to navigate to Site record  " + e.getMessage());
		}
	}

	/**
	 * Function:Update RCMA account type field
	 * 
	 * @author Trupti Zure
	 **/

	public void updateRCMAccountField() {
		try {
			By rcmAccountTypeEdit = getDynamicElement(editButton, "Edit RCM Account Type");
			waitAndVerifyElement(rcmAccountTypeEdit);
			scrollToElement(rcmAccountTypeEdit);
			setTimeOut(2000);
			click(rcmAccountTypeEdit);
			By rcmList = getDynamicElement(editFieldList, "RCM Account Type");
			waitAndVerifyElement(rcmList);
			click(rcmList);
			By rcmListDropDownOptions = getDynamicElement(editFieldListOptions, "RCM Account Type");
			selectItemFromList(rcmList, rcmListDropDownOptions, "Hospitals", "RCM Account Type");
			LoggingInfo("Selected RCM Account Type as- Hospital");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to update RCM Account type- " + e.getMessage());
			Assert.fail("Failed to update RCM Account type- " + e.getMessage());
		}
	}

	/**
	 * Function:Update legacy id
	 * 
	 * @author Trupti Zure
	 **/
	public void updateLegacyID() {
		try {
			By legacyId = getDynamicElement(inputField, "Legacy Id");
			waitAndVerifyElement(legacyId);
			scrollToElement(legacyId);
			int randomNumber = rnd.nextInt(1000);
			String randomNumberString = String.valueOf(randomNumber);
			inputText(legacyId, randomNumberString);

		} catch (Exception e) {
			Log.error("Failed to update Legacy ID  " + e.getMessage());
			Assert.fail("Failed to update Legacy ID  " + e.getMessage());
		}
	}

	/**
	 * Function:Click on account name
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnAccountName() {
		try {
			setTimeOut(3000);
			scrollToElement(eleAccountName);
			waitAndVerifyElement(eleAccountName);
			click(eleAccountName);
			LoggingInfo("Clicked on Account Name");
		} catch (Exception e) {
			Log.error("Failed to navigated to Account record  " + e.getMessage());
			Assert.fail("Failed to navigated to Account record  " + e.getMessage());
		}
	}

	/**
	 * Function:Navigate to Health condition record
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToHealthConditions() {
		try {
			By healthCondition = getDynamicElement(strAccountObjectsCreated, "Health Conditions");
			scrollToElement(healthCondition);
			clickByJavascript(healthCondition);
			setTimeOut(2000);
			LoggingInfo("Clicked on Health conditions section");
		} catch (Exception e) {
			Log.error("Navigated to Health Condition Record  " + e.getMessage());
			Assert.fail("Navigated to Health Condition Record  " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Health condition code record
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyHCCodeRecord(String diagnosisCode) {
		try {

			waitAndVerifyElement(eleHealthCondtionRec);
			click(eleHealthCondtionRec);
			setTimeOut(2000);
			LoggingInfo("Clicks on Health Conditions record");

			By conditionCode = getDynamicElement(strCondCode, "Condition Code");
			verifyDetails(conditionCode, diagnosisCode, "Diagnosis Code");

		} catch (Exception e) {
			Log.error("Failed to verify Health condition code  " + e.getMessage());
			Assert.fail("Failed to verify Health condition code  " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to orders table
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToOrdersTable() {
		try {
			LoggingInfo("Navigate to order table ");
			By orderTable = getDynamicElement(relatedTabSection, "Orders");
			waitAndVerifyElement(orderTable);
			scrollToElement(orderTable);
			LoggingInfo("Navigated to Orders");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to navigate to orders table  " + e.getMessage());
			Assert.fail("Failed to navigate to orders table  " + e.getMessage());
		}
	}

	// Anand P
	public void navigateToCPEPTable() {
		try {
			LoggingInfo("Navigate to Care Program Enrollee Products table ");
			By orderTable = getDynamicElement(relatedTabSection, "Care Program Enrollee Products");
			waitAndVerifyElement(orderTable);
			scrollToElement(orderTable);
			LoggingInfo("Navigated to Orders");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to navigate to orders table  " + e.getMessage());
			Assert.fail("Failed to navigate to orders table  " + e.getMessage());
		}
	}

	//Anand P
	public void navigateClickToCPETeamMemberTable() {
		try {
			LoggingInfo("Navigate to Care Program Enrollee Team Members ");
			By orderTable = getDynamicElement(relatedTabSection, "Care Program Enrollee Team Members");
			waitAndVerifyElement(orderTable);
			scrollToElement(orderTable);
			clickByJavascript(orderTable);
			LoggingInfo("Navigated to Orders");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to navigate to orders table  " + e.getMessage());
			Assert.fail("Failed to navigate to orders table  " + e.getMessage());
		}
	}

	//Anand P
	public void verifyClickNewButton() {
		try {
			Log.info("Verify user is able to click on new button");
			waitAndVerifyElement(eleNewBtn);
			clickByJavascript(eleNewBtn);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify and click on new button " + e.getMessage());
			Assert.fail("Failed to verify and click on new button " + e.getMessage());
		}
	}
	

	
	
	
	/**
	 * Function: Verify SP record in orders table
	 * 
	 * @author Trupti Zure
	 **/

	public void verifySpecialityPharmRecord() {
		try {
			LoggingInfo("validate if the Specialty Pharmacy field is auto-populated ");
			boolean spFound = false;
			if (verifytable("Orders")) {
				List<WebElement> rows = getWebDriver().findElements(eleOrderTable);
				scrollToElement(eleOrderTable);
				for (WebElement row : rows) {
					WebElement woElement = row.findElement(By.xpath(".//td[@data-label=\"CPE Work Order\"]//a"));

					((JavascriptExecutor) getWebDriver()).executeScript(
							"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
							woElement);
					String workOrderName = woElement.getAttribute("Title");
					if (workOrderName.equals("IAP")) {
						WebElement spNameElement = row.findElement(By.xpath(".//td[@data-label=\"SP\"]//a"));

						((JavascriptExecutor) getWebDriver()).executeScript(
								"arguments[0].scrollIntoView({ behavior: 'auto', block: 'center', inline: 'nearest' });",
								spNameElement);
						String spName = spNameElement.getAttribute("Title");
						Assert.assertEquals("Sonexus", spName, "Speciality Pharamcy");//Theracom, Llc-> changed to Sonexus
						spFound = true;
						break;
					}

				}
				Assert.assertTrue(spFound, "SP name TheraCom not found in the Order table.");
				LoggingInfo("Verification completed: ");
			}
		} catch (Exception e) {
			Log.error("Failed to navigate to orders table  " + e.getMessage());
			Assert.fail("Failed to navigate to orders table  " + e.getMessage());
		}
	}
	
	//Anand P
	public void validateEnrollmentStartEndDate() {
		
		try {
		//Enrollment Start Date
			By startDate = getDynamicElement(strAccountObjectDetails, "Enrollment Start Date");
			waitAndVerifyElement(startDate);
			scrollToElement(startDate);
			highLightElement(startDate);
			String expectedStartDate = Utility_Function.getNthDayFromTodayFormatted(0);;
			String actualStartDate =getWebDriver().findElement(startDate).getText();
			Assert.assertEquals(actualStartDate, expectedStartDate, "Enrollment start date matches");
			LoggingInfo(
					"Enrollment start date is current date ");
			setTimeOut(2000);
			
			//Enrollment End Date
			By endDate = getDynamicElement(strAccountObjectDetails, "Enrollment End Date");
			waitAndVerifyElement(endDate);
			scrollToElement(endDate);
			highLightElement(endDate);
			String expectedEndDate = Utility_Function.getNthDayFromTodayFormatted(30);;
		     String actualEndDate = getWebDriver().findElement(endDate).getText();
			Assert.assertEquals(actualEndDate, expectedEndDate, "Enrollment end date matches");
			LoggingInfo(
					"Enrollment end date is current date + 30");
			setTimeOut(2000);
			
			

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate enrollment start and end date " + e.getMessage());
		}
		
	}
	
	//Anand P
	public void validateErrorMsg(){
		
		try {
			By errorMsg=By.xpath("//*[contains(text(), \"A patient cannot be enrolled in IAP for more than 6 months per enrollment.\")]");
			LoggingInfo("Verify Error Message");
			waitAndVerifyElement(errorMsg);
			LoggingInfo("Verified error message");
			setTimeOut(2000);
			
		} catch (Exception e) {
			Log.error("Failed to validate error message  " + e.getMessage());
			Assert.fail("Failed to validate error message " + e.getMessage());
		}
	}
	//Anand P
	public void validateEnrollmentEndDate(String date) {
		try {
			
			LoggingInfo("Verify Enrollment End Date");
			setTimeOut(2000);
			By endDate = getDynamicElement(strInputBox, "Enrollment End Date");
			waitAndVerifyElement(endDate);
			String dateValue = getAttributeValue(endDate, "value");

			Assert.assertEquals(dateValue, date,
					"Failed to verify end date: ");
			
		
		} catch (Exception e) {
			Log.error("Failed to validate enrollmenet record  " + e.getMessage());
			Assert.fail("Failed to validate enrollmenet record  " + e.getMessage());
		}
	}
	
	//Anand P
	public void editEnrollmentStartDate(String date){
	
	try {
		//Enrollment Start Date
			By startDate = getDynamicElement(strAccountObjectDetails, "Enrollment Start Date");
			waitAndVerifyElement(startDate);
			scrollToElement(startDate);
			highLightElement(startDate);
			
			By editBtn=By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Enrollment Start Date\"]//ancestor::dt//following-sibling::dd//span//following-sibling::button");
			click(editBtn);
			setTimeOut(1000);
			String pastDate=date;
			By dateInput=getDynamicElement(inputField,"Enrollment Start Date");
			inputText(dateInput, pastDate);
			setTimeOut(2000);
			
			}catch(Exception e){
			  e.printStackTrace();
			  Assert.fail("Failed to edit date " + e.getMessage());

			}
}
	

	/**
	 * Function: Navigate to CPE product record and verify CPEP
	 * 
	 * @author Trupti Zure
	 **/

	public void navigateToCPEPRecord(String CPEP) {
		try {
			LoggingInfo("Navigate to CPEP Record");
			boolean nameFound = false;
			if (verifytable("Care Program Enrollee Products")) {
				List<WebElement> rows = getWebDriver().findElements(eleCPEPTable);
				scrollToElement(eleCPEPTable);
				for (WebElement row : rows) {
					WebElement productNameElement = row.findElement(By.xpath(
							".//th[@data-label=\"Name\"]//a//parent::div//span[@class=\"slds-assistive-text\"]"));
					String cpepName = productNameElement.getText().trim();
					if (cpepName.contains(CPEP)) {
						setTimeOut(2000);
						WebElement nameElement = row.findElement(By
								.xpath("(.//th[@data-label=\"Name\"]//a//ancestor::div[@class=\"slds-truncate\"])[1]"));
						nameElement.click();
						nameFound = true;
						break;
					}

				}
				Assert.assertTrue(nameFound, "Clicked on CPEP record");
				LoggingInfo("Clicked on CPEP record: ");
			}
		} catch (Exception e) {
			Log.error("Failed to Click on CPEP record  " + e.getMessage());
			Assert.fail("Failed to Click on CPEP record  " + e.getMessage());
		}

	}

	public void verifyIAPCompletion() {
		try {
			By status = By.xpath("//p[text()=\"IAP\"]//parent::div//preceding-sibling::div//span[text()=\"Complete\"]");
			waitAndVerifyElement(status);
			LoggingInfo("IAP task completed successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("IAP task status is not completed  " + e.getMessage());
			Assert.fail("IAP task  status is not completed  " + e.getMessage());

		}
	}

	/**
	 * Function: Validate enrollment end date
	 * 
	 * @author Trupti Zure
	 **/

	public void validateEnrollmenetEndDate() {
		try {
			LoggingInfo("Verify Enrollment End Date");
			setTimeOut(2000);
			By endDate = getDynamicElement(strAccountObjectDetails, "Enrollment End Date");
			waitAndVerifyElement(endDate);
			String expectedEndDate = getDateNDaysFromToday(30);
			verifyDetails(endDate, expectedEndDate, "Enrollment End Date");
		} catch (Exception e) {
			Log.error("Failed to validate enrollmenet record  " + e.getMessage());
			Assert.fail("Failed to validate enrollmenet record  " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Correspondence Screen
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyCorrespondenceScreen() {
		try {

			Log.info("Verify Correspondence Screen");
			By tasktitle = By.xpath("//*[contains(@class,\"active lafPageHost\")]//h1[text()=\"Correspondence\"]");
			boolean found = isElementPresent(tasktitle);
			if (found) {
				missingInformatioPage.clickNextButton();
			}

		} catch (Exception e) {
			Log.error("Failed to verify Correspondence Screen  " + e.getMessage());
			Assert.fail("Failed to verify Correspondence Screen  " + e.getMessage());
		}
	}

	// Anand P
	public void checkIAPCompletion() {
		try {
			By status = By.xpath("//p[text()=\"IAP\"]//parent::div//preceding-sibling::div//span[text()=\"Complete\"]");
			waitAndVerifyElement(status);
			LoggingInfo("IAP completed successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("IAP status is not completed  " + e.getMessage());
			Assert.fail("IAP status is not completed  " + e.getMessage());

		}
	}

	/**
	 * Function: Enter Eligibility Criteria
	 * 
	 * @author Trupti Zure
	 **/
	public void enterEligibilityCriteria(String reason, String approval, String residential, String hcpUSPR,
			String indication, String inpatient, String therapy) {
		try {

			String[] dropdownLabels = { "Enrollment Reason", "Seeking PA Approval?", "Patient resides in US/PR?",
					"HCP in US/PR?", "Off-label indication?", "Inpatient?", "New to therapy?" };
			String[] dropdownLabelsValues = { reason, approval, residential, hcpUSPR, indication, inpatient, therapy };

			for (int i = 0; i < dropdownLabels.length; i++) {
				String dropdownLabel = dropdownLabels[i];
				By dropdownInputBox = getDynamicElement(strDropDownInputBox, dropdownLabel);
				waitAndVerifyElement(dropdownInputBox);
				scrollToElement(dropdownInputBox);
				click(dropdownInputBox);
				By dropdownOptions = getDynamicElement(strDropDownOptions, dropdownLabel);
				waitAndVerifyElement(dropdownOptions);
				selectItemFromList(dropdownInputBox, dropdownOptions, dropdownLabelsValues[i], dropdownLabel);
				setTimeOut(1000);

			}

		} catch (Exception e) {
			Log.error("Failed to enter Eligibility Criteria " + e.getMessage());
			Assert.fail("Failed to enter Eligibility Criteria " + e.getMessage());
		}
	}

	/**
	 * Function:enter Eligibility Outcome
	 * 
	 * @author Trupti
	 **/
	public void verifyAndEntereligibilityOutcome(String eligibilityOutcome, String outcomeOption, String reason) {
		try {
			scrollToTopOfPage();
			// Eligibility Outcome
			By eleEligOutcomeInputBox = getDynamicElement(strInputBox, "Eligibility Outcome");
			scrollToElement(eleEligOutcomeInputBox);
			verifyHardAssertInputFieldBox(eleEligOutcomeInputBox, eligibilityOutcome, "Eligibility Outcome");

			// Outcome
			By eleOutcome = getDynamicElement(strDropDownInputBox, "Outcome");
			waitAndVerifyElement(eleOutcome);
			click(eleOutcome);
			By eleOutcomeOptions = getDynamicElement(searchDropDownOptions, "Outcome");
			waitAndVerifyElement(eleOutcomeOptions);
			selectItemFromList(eleOutcome, eleOutcomeOptions, outcomeOption, "Outcome");
			LoggingInfo("Selected outcome as-" + outcomeOption);

			if (outcomeOption.equalsIgnoreCase("Denied")) {
				By eleOutcomeReason = getDynamicElement(strDropDownInputBox, "Outcome Reason");
				waitAndVerifyElement(eleOutcomeReason);
				click(eleOutcomeReason);
				By eleOutcomeReasonOptions = getDynamicElement(strDropDownOptions, "Outcome Reason");
				waitAndVerifyElement(eleOutcomeReasonOptions);
				selectItemFromList(eleOutcomeReason, eleOutcomeReasonOptions, reason, "Outcome Reason");
			}

		} catch (Exception e) {
			Log.error("Failed verify And Enter eligibility Outcome- " + e.getMessage());
			Assert.fail("Failed verify And Enter eligibility Outcome- " + e.getMessage());
		}
	}

	/**
	 * Function: Validate CPEP record is not created
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyCPEPRecordNotCreated(String CPEP) {
		try {
			LoggingInfo("Validating CPEP record is not created for: " + CPEP);
			boolean nameFound = false;
			if (verifytable("Care Program Enrollee Products")) {
				List<WebElement> rows = getWebDriver().findElements(eleCPEPTable);
				scrollToElement(eleCPEPTable);
				for (WebElement row : rows) {
					WebElement productNameElement = row.findElement(By.xpath(
							".//th[@data-label=\"Name\"]//span[@class=\"slds-truncate\"]//slot"));
					String cpepName = productNameElement.getText().trim().split(" - ")[0];
					if (cpepName.contains(CPEP)) {
						nameFound = true;
						break;
					}
				}

				Assert.assertFalse(nameFound, "CPEP record was unexpectedly created for: " + CPEP);
				LoggingInfo("CPEP record was not created for " + CPEP + " work order");
			}
		} catch (Exception e) {
			Log.error("Failed to verify on CPEP record  " + e.getMessage());
			Assert.fail("Failed to verify on CPEP record  " + e.getMessage());
		}

	}

	public void validateExtensionReason(String expectedExtensionReason) {
		try {
			LoggingInfo("Verify Extention Reason");
			setTimeOut(2000);
			By eleextensionReason= getDynamicElement(strAccountObjectDetails, "Extension Reason");
			waitAndVerifyElement(eleextensionReason);
			verifyDetails(eleextensionReason, expectedExtensionReason, "Extension Reason");
			setTimeOut(2000);
			LoggingInfo("Verified extension Reason");
		} catch (Exception e) {
			Log.error("Failed to validate extension reason " + e.getMessage());
			Assert.fail("Failed to validate extension reason   " + e.getMessage());
		}
	}

	public void verifyandenterExtentionReason(String extension) {
		try {
			By extensionReasonDropDWN = getDynamicElement(strDropDownInputBox, "Extension Reason");
			waitAndVerifyElement(extensionReasonDropDWN);
			click(extensionReasonDropDWN);
			By extensionReasonDropDWNDropDWNOptions = getDynamicElement(searchDropDownOptions,
					"Extension Reason");
			waitAndVerifyElement(extensionReasonDropDWNDropDWNOptions);
			selectItemFromList(extensionReasonDropDWN, extensionReasonDropDWNDropDWNOptions, extension,
					"Extension Reason");
		} catch (Exception e) {
			Log.error("Failed to enter Extension Reason " + e.getMessage());
			Assert.fail("Failed to enter Extension Reason " + e.getMessage());
		}
	}

	public void enterExtend() {
		try {
			By enrollmentReasonDropDWN = getDynamicElement(strDropDownInputBox, "Extend?");
			waitAndVerifyElement(enrollmentReasonDropDWN);
			scrollToElement(enrollmentReasonDropDWN);
			click(enrollmentReasonDropDWN);
			String reason = "Yes";
			By enrollmentReasonDropDWNOPtions = getDynamicElement(strDropDownOptions, "Extend?");
			waitAndVerifyElement(enrollmentReasonDropDWNOPtions);
			selectItemFromList(enrollmentReasonDropDWN, enrollmentReasonDropDWNOPtions, reason, "Extend?");

		

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter Extend details " + e.getMessage());
			Assert.fail("Failed to enter Extend details " + e.getMessage());
		}
	}


	/**
	 * Function: Navigate to CPE Sp product record and verify SP
	 * 
	 * @author Shanavaz Nishani
	 **/
	public static By eleCPEPSpTable = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Care Program Enrollee Product SPs\"]//tbody//tr");
	 public void navigateToCPEPSpsRecord(String CPEP) {
		try {
			LoggingInfo("Navigate to CPEP Record");
			boolean nameFound = false;
			if (verifytable("Care Program Enrollee Product SPs")) {
				List<WebElement> rows = getWebDriver().findElements(eleCPEPSpTable);
				scrollToElement(eleCPEPSpTable);
				for (WebElement row : rows) {
					WebElement productNameElement = row.findElement(By.xpath(".//th[@data-label=\"Care Program Enrollee Product SP Name\"]//a//parent::div//a//span[@class=\"slds-truncate\"]//span"));
					String cpepName = productNameElement.getText().trim();
					if (cpepName.contains(CPEP)) {
						setTimeOut(2000);
						WebElement nameElement = row.findElement(By
								.xpath("(.//th[@data-label=\"Care Program Enrollee Product SP Name\"]//a//ancestor::div[@class=\"slds-truncate\"])[1]"));
						nameElement.click();
						nameFound = true;
						break;
					}

				}
				Assert.assertTrue(nameFound, "Clicked on CPEP record");
				LoggingInfo("Clicked on CPEP record: ");
			}
		} catch (Exception e) {
			Log.error("Failed to Click on CPEP record  " + e.getMessage());
			Assert.fail("Failed to Click on CPEP record  " + e.getMessage());
		}

	}
	 public void clickOnIAPCpe() {
		    try {
		        By papCpe = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[contains(text(), \"IAP\")]//ancestor::a");
		        scrollToElement(papCpe);
		        waitAndVerifyElement(papCpe);
		        clickByJavascript(papCpe);
		        setTimeOut(1000);
		    } catch (Exception e) {
		        Log.error("Failed to click on PAP CPE task: " + e.getMessage());
		        Assert.fail("Failed to click on PAP CPE task: " + e.getMessage());
		    }
		}
	 public void validateDiscontinuationDate() {
			
			try {
			
				By Date = getDynamicElement(correspondenceInputField, "Discontinuation Date");
				waitAndVerifyElement(Date);
				scrollToElement(Date);
				String expectedStartDate = Utility_Function.getNthDayFromTodayFormatted(0);;
				String actualStartDate =getWebDriver().findElement(Date).getText();
				Assert.assertEquals(actualStartDate, expectedStartDate, "Discontinuation date matches");
				LoggingInfo(
						"Discontinuation date is current date ");
				setTimeOut(2000);
				} catch (Exception e) {
				e.printStackTrace();
				Assert.fail("Failed to validate Discontinuation start  date " + e.getMessage());
			}
			
		}
	 public void validateDiscontinuationReason() {
		    try {
		        By Reason = getDynamicElement(correspondenceInputField, "Discontinuation Reason");
		        waitAndVerifyElement(Reason);
		        scrollToElement(Reason);

		        String expectedReason = "PA approved";
		        String actualReason = getWebDriver().findElement(Reason).getText();

		        Assert.assertEquals(actualReason, expectedReason, "Discontinuation reason matches");
		        LoggingInfo("Discontinuation reason is as expected: PA approved");

		        setTimeOut(2000);
		    } catch (Exception e) {
		        e.printStackTrace();
		        Assert.fail("Failed to validate Discontinuation Reason: " + e.getMessage());
		    }
		}

		/**
	 * Function: Navigate to CPE work order
	 * 
	 * @author Kavyashree MB
	 **/

	public void verifyAndNavigateToCPEWorkOrder() {
		try {
			waitAndVerifyElement(eleCPEWorkOrder);
			scrollToElement(eleCPEWorkOrder);
			LoggingInfo("Navigated to CPE work order");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to complete BV flow  " + e.getMessage());
			Assert.fail("Failed to complete BV flow  " + e.getMessage());
		}
	}

		/**
	 * Function: Validare Order is created for the given order type
	 * 
	 * @author Shanavaz Nishani
	 **/
public void verifyOrderCreated(String ordertype){
	List<WebElement> rows = getWebDriver().findElements(By.xpath("//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Orders\"]//tbody//tr//td[@data-label=\"Order Type\"]"));
	for(WebElement row:rows){
		String orderTypeText = row.getText();
		if(orderTypeText.equalsIgnoreCase(ordertype)){
			LoggingInfo("Order is created successfully for: "+ordertype);
			break;
		}
	}
}

/**
 * Function: Finish button 
 * 
 * @author Tejal
 **/

public void finishButtonIfPresent() {
	try {
		setTimeOut(1000);
		
		By eleSaveButton = getDynamicElement(eleButton, "Finish"); 
		
		
		if (verifyElement(eleSaveButton)) {
			waitAndVerifyElement(eleSaveButton);
			clickByJavascript(eleSaveButton);
			LoggingInfo("Clicked on finish button");
		} else {
			LoggingInfo("Finish button not present");
		}
		
	} catch (Exception e) {
		Log.error("Failed  " + e.getMessage());
		Assert.fail("Failed  " + e.getMessage());
	}
}

/**
 * Function: Navigate to cpep sps record
 * 
 * @author Tejal
 **/
public void navigateToCPEPSpRecord(String pharmacyName) {
    try {
        By pharmacyElement = By.xpath("(//*[contains(text(), '" + pharmacyName + " -')])[1]");
 
        waitAndVerifyElement(pharmacyElement);
        scrollToElement(pharmacyElement);
        click(pharmacyElement);
 
        Log.info("Clicked on pharmacy: " + pharmacyName);
    } catch (Exception e) {
        Log.error("Failed to click on pharmacy: " + pharmacyName + ". Error - " + e.getMessage());
        Assert.fail("Failed to click on pharmacy: " + pharmacyName + ". Error - " + e.getMessage());
    }
}
 
}
