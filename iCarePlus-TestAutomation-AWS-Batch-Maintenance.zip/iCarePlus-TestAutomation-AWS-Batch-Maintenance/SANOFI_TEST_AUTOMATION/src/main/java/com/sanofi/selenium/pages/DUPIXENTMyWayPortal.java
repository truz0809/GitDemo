package com.sanofi.selenium.pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class DUPIXENTMyWayPortal extends Utility_Function {

	public DUPIXENTMyWayPortal(WebDriver driver) {
		super(driver);
	}
	
	
	String msg="We automatically use certain cookies to ensure our website functions properly and to keep it secure. Please see “Cookie Settings” for descriptions of other optional cookie categories. By selecting “Accept All Cookies,” you agree to and direct us to use cookies to collect your personal information (including health information) and to disclose it to our vendors and advertising network partners for the purposes of enhancing and analyzing the site and user experience, and assisting in our marketing efforts. You can change your selection at any time by selecting the link “Cookies Settings.” For more information, please consult our Privacy Notices. ";

	/************************
	 * Elements
	 **************************************************/

	public static By eleUploadDocButton = By.xpath("//*[text()='Upload Documents']");
	public static By eleAccessCodeInputField = By.xpath("//*[@class='slds-input' and @type='text']");
	public static By elePatientSubDocCHKbox = By.xpath("//*[@class='checkBox' and @type='checkbox']");
	public static By eleconsentCHKbox = By.xpath("//*[@class=\"checkBoxInput\" and @name='consenttoUpload']");
	public static By eleUploadFileButton = By.xpath("//span[text()=\"Upload Files\"]");
	public static By eleDocumentID = By.xpath("//p[contains(text(),\"Document\")]");
	public static By eleElectronicSigndBtn = By.xpath("//div[text()=\"Electronically Sign Patient Consent Form\"]");
	public static By elePgForms = By.xpath("//th[text()='Patient Authorization & Agreement Forms']");
	public static By eleEmailconf = By.xpath("//div[@class='signerEmailRow']//input[@id='form-control-signerEmail']");
	public static By elestateNextBtn = By.xpath("//button[@id='stateNext']");
	public static By elesignPatientAuth = By
			.xpath("(//div[@class='pdfFormField signature required todo-signature']//input)[1]");
	public static By eleSignaturePad = By.xpath("//div[@class='signature-pad']//input");
	public static By eleContinueBtn = By.xpath("//div[@class='tou-btn-inner']//button[text()='Continue']");
	public static By iframe = By.xpath("//iframe[@title='External Site Viewer']");
	public static By eleMessage = By.xpath("//div[@id='onetrust-policy-text']");
	public static By eleSanofiPolicy = By.xpath("(//a[text()='Sanofi Privacy Policy'])[1]");
	public static By eleRegereonNotice = By.xpath("(//a[text()='Regeneron Privacy Notice'])[1]");
	public static By elecookiesSettingsMessage = By.xpath("//div[@id='ot-pc-desc']");
	public static By eleclose = By.xpath("//button[@id='close-pc-btn-handler']");
	public static By eleStrictlyNecessarycookies = By.xpath(
			"//h3[@id='ot-category-title']//parent::section//div[@class='ot-accordion-layout ot-cat-item ot-vs-config'][1]");
	public static By clickHereTosign = By.xpath("//input[@placeholder=\"Click here to sign\"]");
	public static By signBox = By.xpath("//input[contains(@class,\"ignature-type-name ie-placeholder\")]");
	public static By loginHereEle = By.xpath("//div/a[contains(text(), \"Login here\")]");
	/************************
	 * Dynamic Elements
	 **************************************************/
	public static String button = "//button[text()=\"{0}\"]";
	public static String inputField = "//*[@name=\"{0}\" ]";
	public static String strFields = "//div//input[@name=\"{0}.Page 1\"]";
	public static String strFieldsSpanish = "//div[@data-fieldname=\"{0}\"]//input";
	public static String eleMsg ="//div[text()=\"{0}\"]";


	/**
	 * Function: Click on patient caregiver button
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnPatientorCaregiverButton() {
		try {
			waitForPageLoaded();
			By patientCaregiverButton = getDynamicElement(button, "I am a Patient or Caregiver");
			waitAndVerifyElement(patientCaregiverButton);
			waitForvisiblityOfElementLocated(patientCaregiverButton);
			click(patientCaregiverButton);
			LoggingInfo("Clicked on 'I am a Patient or Caregiver' button ");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to clicked on 'I am a Patient or Caregiver' button " + e.getMessage());
			Assert.fail("Failed to clicked on 'I am a Patient or Caregiver' button " + e.getMessage());
		}
	}
	
	public void handleLoginScreen() {
	    try {
	        WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(5)); // short timeout
	        WebElement nextButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='employeeLoginLink salesforceIdentityEmployeeLoginLink2']//a")));
	       
	        if (nextButton.isDisplayed()) {
	            System.out.println("Login screen appeared. Clicking Next.");
	            nextButton.click();
	        }
	    } catch (Exception e) {
	        System.out.println("Login screen not present. Proceeding without action.");
	    }
	}

	/**
	 * Function: Click on document upload button
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnUploadDocButton() {
		try {
			setTimeOut(3000);
			waitAndVerifyElement(eleUploadDocButton);
			clickByJavascript(eleUploadDocButton);
			LoggingInfo("Clicked on 'Upload documents' button ");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to clicked on 'Upload documents' button " + e.getMessage());
			Assert.fail("Failed to clicked on 'Upload documents' button " + e.getMessage());
		}
	}

	/**
	 * Function: Enter access code
	 * 
	 * @author Trupti Zure
	 **/
	public void enterAccessCode(String accessCode) {
		try {
			waitAndVerifyElement(eleAccessCodeInputField);
			inputText(eleAccessCodeInputField, accessCode);
			LoggingInfo("Entered access code- " + accessCode);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter access code " + e.getMessage());
			Assert.fail("Failed to enter access code " + e.getMessage());
		}
	}

	/**
	 * Function: Click on submit document button
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnSubmitCodeButton() {
		try {

			By submitCodeButton = getDynamicElement(button, "Submit code");
			waitAndVerifyElement(submitCodeButton);
			click(submitCodeButton);
			LoggingInfo("Clicked on 'Submit code' button ");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to clicked on 'Submit code' button " + e.getMessage());
			Assert.fail("Failed to clicked on 'Submit code' button " + e.getMessage());
		}
	}

	/**
	 * Function: Enter patient information
	 * 
	 * @author Trupti Zure
	 **/
	public void enterPatientInfo(String[] cpeDetails) {
		try {
			String[] nameParts = cpeDetails[0].split(" ");
			// Patient first name
			By firstNameInputField = getDynamicElement(inputField, "patientFirstName");
			waitAndVerifyElement(firstNameInputField);
			String firstName = nameParts[0];
			inputText(firstNameInputField, firstName);

			// Patient Last Name
			By lastNameInputField = getDynamicElement(inputField, "patientLastName");
			waitAndVerifyElement(lastNameInputField);
			String lastName = nameParts[nameParts.length - 1];
			inputText(lastNameInputField, lastName);

			// Patient DOB
			By dobInputField = getDynamicElement(inputField, "patientDateofBirth");
			waitAndVerifyElement(dobInputField);
			setTimeOut(2000);
			String dob = cpeDetails[1];
			inputText(dobInputField, dob);

			// Patient email
			By emailInputField = getDynamicElement(inputField, "patientEmailAddress");
			waitAndVerifyElement(emailInputField);
			scrollToElement(emailInputField);
			String email = cpeDetails[2];
			inputText(emailInputField, email);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter patient information " + e.getMessage());
			Assert.fail("Failed to enter patient information " + e.getMessage());
		}
	}

	/**
	 * Function: Click on submit document checkbox
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnSubmitDocCheckBox() {
		try {
			waitAndVerifyElement(elePatientSubDocCHKbox);
			scrollToElement(elePatientSubDocCHKbox);
			click(elePatientSubDocCHKbox);
			LoggingInfo("Clicked on submit documents checkbox");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on checkbox " + e.getMessage());
			Assert.fail("Failed to click on checkboxe " + e.getMessage());
		}
	}

	/**
	 * Function: Click on consent check box
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnConsentCheckBoxes() {
		try {
			waitAndVerifyElement(eleconsentCHKbox);
			scrollToElement(eleconsentCHKbox);
			click(eleconsentCHKbox);
			LoggingInfo("Clicked on consent checkbox");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on checkbox " + e.getMessage());
			Assert.fail("Failed to click on checkboxe " + e.getMessage());
		}
	}

	/**
	 * Function: Click on upload file button
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnUploadFileButton() {
		try {
			waitAndVerifyElement(eleUploadFileButton);
			scrollToElement(eleUploadFileButton);
			clickByJavascript(eleUploadFileButton);
			LoggingInfo("Clicked on upload file button");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on upload file button " + e.getMessage());
			Assert.fail("Failed to click on upload file button " + e.getMessage());
		}
	}

	/**
	 * Function: Click on submit file button
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnSubmitButton() {
		try {
			By submitButton = getDynamicElement(button, "Submit");
			waitAndVerifyElement(submitButton);
			click(submitButton);
			LoggingInfo("Clicked on 'Submit' button ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on submit button " + e.getMessage());
			Assert.fail("Failed to click on submit button " + e.getMessage());
		}
	}

	/**
	 * Function: After uploading document get document id
	 * 
	 * @author Trupti Zure
	 **/
	public String getDocumentID() {
		String id = null;
		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleDocumentID);
			scrollToElement(eleDocumentID);
			String documentID = getText(eleDocumentID);
			id = documentID.split(": ")[1];
			LoggingInfo("Document ID-" + id);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on submit button " + e.getMessage());
			Assert.fail("Failed to click on submit button " + e.getMessage());
		}
		return id;
	}

	/**
	 * Function: Click on accept all cookies button
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnAcceptAllCookies() {
		try {
			Log.info("Checking for 'Accept All Cookies' button...");
			setTimeOut(2000);
			By acceptCookiesButton = By.xpath("//*[text()='ACCEPT ALL COOKIES']");
			if (isElementPresent(acceptCookiesButton)) {
				click(acceptCookiesButton);
				Log.info("'Accept All Cookies' button clicked.");
			} else {
				Log.info("'Accept All Cookies' button not found. Proceeding without clicking.");
			}
		} catch (Exception e) {
			Log.error("Error while attempting to click 'Accept All Cookies' button: " + e.getMessage());
			Assert.fail("Failed to handle 'Accept All Cookies' banner: " + e.getMessage());
		}
	}
	
	public void clickOnAreYouEmployee() {
		
		By AreYouEmployeeButton = By.xpath("//*[contains(text(),'Are you an employee? Login here')]");
		if (isElementPresent(AreYouEmployeeButton)) {
			click(AreYouEmployeeButton);
			Log.info( "'AreYouEmployeeButton' button clicked.");
		} else {
			Log.info("'AreYouEmployeeButton' button  not found. Proceeding without clicking.");
		}
			
		}
		
	

	public boolean verifyLoginScreen() {
		boolean found = false;
		try {

			Log.info("Verify Login Screen");
			By username = By.xpath("//*[@id='username' and @type='email']");
			found = isElementPresent(username);

		} catch (Exception e) {
			Log.error("Failed to verify login page Screen  " + e.getMessage());
			Assert.fail("Failed to verify login page Screen  " + e.getMessage());
		}
		return found;
	}

	/**
	 * Function: Click on Electronically Sign Patient Consent Form button
	 * 
	 * @author Shanavaz Nishani
	 **/

	public void clickOnElectronicConsentForm() {
		try {
			waitForPageLoaded();
			waitAndVerifyElement(eleElectronicSigndBtn);
			waitForvisiblityOfElementLocated(eleElectronicSigndBtn);
			click(eleElectronicSigndBtn);
			LoggingInfo("Clicked on 'Electronically Sign Patient Consent Form' button ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to clicked on 'I am a Patient or Caregiver' button " + e.getMessage());
			Assert.fail("Failed to clicked on 'I am a Patient or Caregiver' button " + e.getMessage());
		}
	}

	public void verifyPatienteSignatureAuthorizationPage() {

		waitAndVerifyElement(elePgForms);
		if (verifyElement(elePgForms)) {
			LoggingInfo("Patient Authorization & Agreement Forms page is displayed");
		}
	}

	/**
	 * Function: Select Form Category(Review and sign electronically)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void selectCategoryForForm(String formCategory) {
		waitForPageLoaded();
		List<WebElement> eleFormCategory = getWebDriver().findElements(By.xpath("//table//tbody//tr//td[2]"));

		setTimeOut(2000);

		for (int i = 0; i < eleFormCategory.size(); i++) {
			WebElement webElement = eleFormCategory.get(i);

			if (webElement.getText().equalsIgnoreCase(formCategory)) {

				String xpath = String.format(
						"(//table//tbody//tr//td[2]//following-sibling::td//a[contains(text(),'Sign Electronically')])[%d]",
						i + 1);
				webElement.findElement(By.xpath(xpath)).click();
				LoggingInfo("Clicked on 'Sign Electronically' button for form category- " + formCategory);

				break;
			}
		}

		waitAndVerifyElement(iframe);
		switchToFrame(iframe);

		waitAndVerifyElement(eleContinueBtn);
		click(eleContinueBtn);
	}

	// Anand P
	public void selectMedDCategory() {
		try {
			waitForPageLoaded();
			By medDLink = By.xpath(
					"(//table//tbody//tr//td[2]//following-sibling::td//a[contains(text(),'Sign Electronically')])[3]");
			waitAndVerifyElement(medDLink);
			clickByJavascript(medDLink);

			waitAndVerifyElement(iframe);
			switchToFrame(iframe);

			waitAndVerifyElement(eleContinueBtn);
			click(eleContinueBtn);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click" + e.getMessage());

		}

	}

	/**
	 * Function: Enter Patient Details in the PDF(Dupixent Portal)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void enterPatientInfo(String patientName, String DOB, String address, String city, String state,
			String email, String primaryPhone) throws Exception {

		By eleName = getDynamicElement(strFields, "Name");
		waitAndVerifyElement(eleName);
		inputText(eleName, patientName);
		LoggingInfo("Name field is entered");

		// Enter DOB
		String[] dateParts = DOB.split("-");
		By eleMonth = getDynamicElement(strFields, "Month DOB");
		waitAndVerifyElement(eleMonth);
		inputText(eleMonth, dateParts[0]);
		By eleDay = getDynamicElement(strFields, "Day DOB");
		waitAndVerifyElement(eleDay);
		inputText(eleDay, dateParts[1]);
		By eleYear = getDynamicElement(strFields, "Year DOB");
		waitAndVerifyElement(eleYear);
		inputText(eleYear, dateParts[2].substring(2));
		LoggingInfo("DOB field is entered");

		By eleAddress = getDynamicElement(strFields, "Address");
		waitAndVerifyElement(eleAddress);
		inputText(eleAddress, address);
		LoggingInfo("Address field is entered");

		By eleCity = getDynamicElement(strFields, "City");
		waitAndVerifyElement(eleCity);
		inputText(eleCity, city);
		LoggingInfo("City field is entered");

		By eleState = getDynamicElement(strFields, "State");
		waitAndVerifyElement(eleState);
		inputText(eleState, state);
		LoggingInfo("State field is entered");

		By eleMail = getDynamicElement(strFields, "Email");
		waitAndVerifyElement(eleMail);
		inputText(eleMail, email);
		LoggingInfo("Email field is entered");

		// enter primaary phone
		String[] phonePart = primaryPhone.replaceAll("[()]", "").split("[ \\-]");
		By elephone1 = getDynamicElement(strFields, "Phone1");
		scrollToElement(elephone1);

		WebElement inputField = getWebDriver().findElement(By.xpath("//div[@data-fieldname='Phone1.Page 1']//input"));
		Actions actions = new Actions(getWebDriver());
		actions.moveToElement(inputField).click().sendKeys(phonePart[0]).perform();

		WebElement inputField1 = getWebDriver().findElement(By.xpath("//div[@data-fieldname='Phone 2.Page 1']//input"));
		actions.moveToElement(inputField1).click().sendKeys(phonePart[1]).perform();

		WebElement inputField2 = getWebDriver().findElement(By.xpath("//div[@data-fieldname='Phone 3.Page 1']//input"));
		actions.moveToElement(inputField2).click().sendKeys(phonePart[2]).perform();
		LoggingInfo("Primary Phone field is entered");
	}

	// Anand P
	public void enterPatientInfoMedD(String patientName, String DOB, String gender, String email, String phone,
			String people, String income) {
		try {
			String[] pName = patientName.split(" ");

			By eleFName = By.xpath("//div//input[@name=\"Custom Field 2\"]");
			waitAndVerifyElement(eleFName);
			scrollToElement(eleFName);
			inputText(eleFName, pName[0]);

			By eleLName = By.xpath("//div//input[@name=\"Custom Field 3\"]");
			waitAndVerifyElement(eleLName);
			scrollToElement(eleLName);
			inputText(eleLName, pName[1]);

			By elePhone = By.xpath("(//div//input[@type=\"tel\"])[1]");
			waitAndVerifyElement(elePhone);
			scrollToElement(elePhone);
			inputText(elePhone, phone);

			By gen = By.xpath("//div//input[@name=\"Custom Field 8\"]");
			waitAndVerifyElement(gen);
			scrollToElement(gen);
			inputText(gen, gender);

			// String date=Utility_Function.rearrangeDateFormat2(DOB);
			By dateOfBirth = By.xpath("//div//input[@name=\"Custom Field 9\"]");
			waitAndVerifyElement(dateOfBirth);
			scrollToElement(dateOfBirth);
			inputText(dateOfBirth, "02/03/91");

			By elePeople = By.xpath("//div//input[@name=\"Custom Field 13\"]");
			waitAndVerifyElement(elePeople);
			scrollToElement(elePeople);
			inputText(elePeople, people);

			By patient = By.xpath("//div//input[@name=\"Custom Field 27\"]");
			waitAndVerifyElement(patient);
			scrollToElement(patient);
			inputText(patient, patientName);

			By emailID = By.xpath("//div//input[@type=\"email\"]");
			waitAndVerifyElement(emailID);
			scrollToElement(emailID);
			inputText(emailID, email);

			By pIncome = By.xpath("//div//input[@placeholder=\"USD\"]");
			waitAndVerifyElement(pIncome);
			scrollToElement(pIncome);
			inputText(pIncome, income);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Function: Esign the required PDF
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void esignPDF() throws Exception {
		By elesignPatient = By.xpath("(//div[@class='pdfFormField signature required todo-signature'])[1]");

		scrollToElement(elesignPatient);
		click(elesignPatient);

		inputText(eleSignaturePad, "Automation");
		LoggingInfo("Signature is entered");

		By eleApplyBtn = getDynamicElement(button, "Apply");
		click(eleApplyBtn);

		scrollToElement(elesignPatient);
		click(elesignPatient);

		LoggingInfo("Required E-sign is Completed.");

	}

	// Anand P
	public void esignPDFMedD() throws Exception {
		By elesignPatient = By.xpath("(//div[@class='pdfFormField signature required todo-signature'])[1]");

		scrollToElement(elesignPatient);
		click(elesignPatient);

		inputText(eleSignaturePad, "sssss");
		LoggingInfo("Signature is entered");

		By eleApplyBtn = getDynamicElement(button, "Apply");
		click(eleApplyBtn);

		// scrollToElement(elesignPatient);
		// click(elesignPatient);

		LoggingInfo("Required E-sign is Completed.");

	}

	/**
	 * Function: Verify Mandatory Fields in the PDF form
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyRequiredFields(String field) throws Exception {

		if (field.equalsIgnoreCase("Signature:Patient")) {
			String val2 = getAttributeValue(elesignPatientAuth, "aria-required");
			if (val2.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a required Field");
			} else {
				Assert.fail(field + " is not a required Field");
			}
		} else {
			By eleName = getDynamicElement(strFields, field);
			scrollToElement(eleName);
			String val = getAttributeValue(eleName, "aria-required");
			if (val.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a required Field");
				highLightElement(eleName);
			} else {
				Assert.fail(field + " is not a required Field");
			}
		}

	}

	// Anand P
	public void verifyRequiredFieldsMedD(String field) throws Exception {

		if (field.equalsIgnoreCase("Signature:Patient")) {
			String val2 = getAttributeValue(elesignPatientAuth, "aria-required");
			if (val2.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a required Field");
			} else {
				Assert.fail(field + " is not a required Field");
			}
		} else if (field.equalsIgnoreCase("First Name")) {
			By eleName = By.xpath("//div//input[@name=\"Custom Field 2\"]");
			scrollToElement(eleName);
			String val = getAttributeValue(eleName, "aria-required");
			if (val.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a required Field");
				highLightElement(eleName);
			} else {
				Assert.fail(field + " is not a required Field");
			}
		} else if (field.equalsIgnoreCase("Last Name")) {
			By eleName = By.xpath("//div//input[@name=\"Custom Field 3\"]");
			scrollToElement(eleName);
			String val = getAttributeValue(eleName, "aria-required");
			if (val.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a required Field");
				highLightElement(eleName);
			} else {
				Assert.fail(field + " is not a required Field");
			}
		} else if (field.equalsIgnoreCase("Phone")) {
			By eleName = By.xpath("(//div//input[@type=\"tel\"])[1]");
			scrollToElement(eleName);
			String val = getAttributeValue(eleName, "aria-required");
			if (val.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a required Field");
				highLightElement(eleName);
			} else {
				Assert.fail(field + " is not a required Field");
			}
		} else if (field.equalsIgnoreCase("Gender")) {
			By eleName = By.xpath("//div//input[@name=\"Custom Field 8\"]");
			scrollToElement(eleName);
			String val = getAttributeValue(eleName, "aria-required");
			if (val.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a required Field");
				highLightElement(eleName);
			} else {
				Assert.fail(field + " is not a required Field");
			}
		} else if (field.equalsIgnoreCase("DOB")) {
			By eleName = By.xpath("//div//input[@name=\"Custom Field 9\"]");
			scrollToElement(eleName);
			String val = getAttributeValue(eleName, "aria-required");
			if (val.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a required Field");
				highLightElement(eleName);
			} else {
				Assert.fail(field + " is not a required Field");
			}
		} else if (field.equalsIgnoreCase("People in household")) {
			By eleName = By.xpath("//div//input[@name=\"Custom Field 13\"]");
			scrollToElement(eleName);
			String val = getAttributeValue(eleName, "aria-required");
			if (val.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a required Field");
				highLightElement(eleName);
			} else {
				Assert.fail(field + " is not a required Field");
			}
		} else if (field.equalsIgnoreCase("Annual income")) {
			By eleName = By.xpath("//div//input[@placeholder=\"USD\"]");
			scrollToElement(eleName);
			String val = getAttributeValue(eleName, "aria-required");
			if (val.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a required Field");
				highLightElement(eleName);
			} else {
				Assert.fail(field + " is not a required Field");
			}
		} else if (field.equalsIgnoreCase("Please print patient name")) {
			By eleName = By.xpath("//div//input[@name=\"Custom Field 27\"]");
			scrollToElement(eleName);
			String val = getAttributeValue(eleName, "aria-required");
			if (val.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a required Field");
				highLightElement(eleName);
			} else {
				Assert.fail(field + " is not a required Field");
			}
		} else if (field.equalsIgnoreCase("Email")) {
			By eleName = By.xpath("//div//input[@type=\"email\"]");
			scrollToElement(eleName);
			String val = getAttributeValue(eleName, "aria-required");
			if (val.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a required Field");
				highLightElement(eleName);
			} else {
				Assert.fail(field + " is not a required Field");
			}
		} else {
			LoggingInfo(field + " is a Invalid Field");
			Assert.fail(field + " is not a required Field");
		}

	}

	/**
	 * Function: Click to SIgn and Confirm Submission
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void clickToSign(String email) throws Exception {
		LoggingInfo("User is able to proceed and confirm submission of their signature via the Adobe e-Sign window");
		By btnSign = getDynamicElement(button, "Click to Sign");

		waitAndVerifyElement(btnSign);
		click(btnSign);

		waitForPageLoaded();
		waitAndVerifyElement(eleEmailconf);
		inputText(eleEmailconf, email);

		click(elestateNextBtn);
		setTimeOut(5000);
	}

	public void validateMessage() {
		try {
			setTimeOut(2000);
			By ele=getDynamicElement(eleMsg,msg);
			waitAndVerifyElement(ele);
			highLightElement(ele);
			LoggingInfo("verified message successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify message " + e.getMessage());
			Assert.fail("Failed to verify message" + e.getMessage());
		}
	}

	public void validateSanofiPrivacyPolicy() {
		try {
			waitAndVerifyElement(eleSanofiPolicy);
 			WebElement link=getWebDriver().findElement(eleSanofiPolicy);
			
			Actions actions = new Actions(getWebDriver());
	        actions.keyDown(Keys.CONTROL).click(link).keyUp(Keys.CONTROL).build().perform();
			LoggingInfo("Open sanofi privacy policy in new tab");

		//	click(eleSanofiPolicy);
			setTimeOut(2000);

			LoggingInfo("Verified sanofi privacy policy");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify sanofi privacy policy " + e.getMessage());
			Assert.fail("Failed to verify sanofi privacy policy " + e.getMessage());
		}
	}

	public void validateRegeneronPrivacyNotice() {
		try {

			waitAndVerifyElement(eleRegereonNotice);
            WebElement link=getWebDriver().findElement(eleRegereonNotice);
			
			Actions actions = new Actions(getWebDriver());
	        actions.keyDown(Keys.CONTROL).click(link).keyUp(Keys.CONTROL).build().perform();
			LoggingInfo("Opened Regeneron privacy policy in new tab");

			setTimeOut(2000);
		//	click(eleRegereonNotice);

			LoggingInfo("Verified regeneron privacy notice");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify regeneron privacy notice" + e.getMessage());
			Assert.fail("Failed to verify regeneron privacy notice " + e.getMessage());
		}
	}

	public void validateButtons() {
		try {
			By AcceptcookiesButton = getDynamicElement(button, "ACCEPT ALL COOKIES");
			waitAndVerifyElement(AcceptcookiesButton);

			By RejectcookiesButton = getDynamicElement(button, "REJECT OPTIONAL COOKIES");
			waitAndVerifyElement(RejectcookiesButton);

			By cookiessettingButton = getDynamicElement(button, "Cookies Settings");
			waitAndVerifyElement(cookiessettingButton);

			LoggingInfo("validated buttons successfully ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate buttons " + e.getMessage());
			Assert.fail("Failed to validate buttons" + e.getMessage());
		}
	}

	public void validatecookieSettingsMessage() {
		try {
			By cookiessettingButton = getDynamicElement(button, "Cookies Settings");
			waitAndVerifyElement(cookiessettingButton);
			click(cookiessettingButton);
			setTimeOut(2000);
			waitAndVerifyElement(elecookiesSettingsMessage);
			LoggingInfo("verified cookies settings message ");
			click(eleclose);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify cookies settings message  " + e.getMessage());
			Assert.fail("Failed to verify cookies settings message  " + e.getMessage());
		}
	}

	public void validateRejectOptionalCookiesbutton() {
		try {
			By RejectcookiesButton = getDynamicElement(button, "REJECT OPTIONAL COOKIES");
			waitAndVerifyElement(RejectcookiesButton);
			click(RejectcookiesButton);
			LoggingInfo("verified reject optional cookies button");
			getWebDriver().quit();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify reject optional cookies button  " + e.getMessage());
			Assert.fail("Failed to verify reject optional cookies button  " + e.getMessage());
		}
	}

	public void validateAcceptAllCookies() {
		try {
			By AcceptcookiesButton = getDynamicElement(button, "ACCEPT ALL COOKIES");
			waitAndVerifyElement(AcceptcookiesButton);
			click(AcceptcookiesButton);
			setTimeOut(2000);

			LoggingInfo("verified accept all cookies button");
			getWebDriver().close();
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify accept all cookies button  " + e.getMessage());
			Assert.fail("Failed to verify accept all cookies button  " + e.getMessage());
		}
	}

	public void verifyCookieSettings() {
		try {
			By cookiessettingButton = getDynamicElement(button, "Cookies Settings");
			waitAndVerifyElement(cookiessettingButton);
			click(cookiessettingButton);
			setTimeOut(2000);
			scrollToElement(eleStrictlyNecessarycookies);
			waitAndVerifyElement(eleStrictlyNecessarycookies);

			LoggingInfo("verified strictly Necessary cookies");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify strictly Necessary cookies  " + e.getMessage());
			Assert.fail("Failed to verify strictly Necessary cookies  " + e.getMessage());
		}
	}

	public void selectFormulariodeinscripcionCategory() {
		try {
			waitForPageLoaded();
			By eleFormulariodeLink = By.xpath(
					"(//table//tbody//tr//td[2]//following-sibling::td//a[contains(text(),'Sign Electronically')])[2]");
			waitAndVerifyElement(eleFormulariodeLink);
			clickByJavascript(eleFormulariodeLink);

			waitAndVerifyElement(iframe);
			switchToFrame(iframe);

			waitAndVerifyElement(eleContinueBtn);
			click(eleContinueBtn);

			LoggingInfo("verified to click Formularido link");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to  click Formularido link  " + e.getMessage());
			Assert.fail("Failed to click Formularido link" + e.getMessage());

		}

	}

	public void enterSpanishPatientInfo(String patientName, String DOB, String address, String city, String state,
			String email, String primaryPhone) throws Exception {

		try {

			By eleName = getDynamicElement(strFields, "Name");
			waitAndVerifyElement(eleName);
			inputText(eleName, patientName);
			LoggingInfo("Name field is entered");

			// Enter DOB
			String[] dateParts = DOB.split("-");
			By eleMonth = getDynamicElement(strFields, "Month DOB");
			waitAndVerifyElement(eleMonth);
			inputText(eleMonth, dateParts[0]);
			By eleDay = getDynamicElement(strFields, "Day DOB");
			waitAndVerifyElement(eleDay);
			inputText(eleDay, dateParts[1]);
			By eleYear = getDynamicElement(strFields, "Year DOB");
			waitAndVerifyElement(eleYear);
			inputText(eleYear, dateParts[2].substring(2));
			LoggingInfo("DOB field is entered");

			By eleAddress = getDynamicElement(strFields, "Address");
			waitAndVerifyElement(eleAddress);
			inputText(eleAddress, address);
			LoggingInfo("Address field is entered");

			By eleCity = getDynamicElement(strFields, "City");
			waitAndVerifyElement(eleCity);
			inputText(eleCity, city);
			LoggingInfo("City field is entered");

			By eleState = getDynamicElement(strFields, "State");
			waitAndVerifyElement(eleState);
			inputText(eleState, state);
			LoggingInfo("State field is entered");

			By eleMail = getDynamicElement(strFields, "Email");
			waitAndVerifyElement(eleMail);
			inputText(eleMail, email);
			LoggingInfo("Email field is entered");

			// enter primaary phone
			String[] phonePart = primaryPhone.replaceAll("[()]", "").split("[ \\-]");
			By elephone1 = getDynamicElement(strFields, "Phone1");
			scrollToElement(elephone1);

			WebElement inputField = getWebDriver()
					.findElement(By.xpath("//div[@data-fieldname='Phone1.Page 1']//input"));
			Actions actions = new Actions(getWebDriver());
			actions.moveToElement(inputField).click().sendKeys(phonePart[0]).perform();

			WebElement inputField1 = getWebDriver()
					.findElement(By.xpath("//div[@data-fieldname='Phone 2.Page 1']//input"));
			actions.moveToElement(inputField1).click().sendKeys(phonePart[1]).perform();

			WebElement inputField2 = getWebDriver()
					.findElement(By.xpath("//div[@data-fieldname='Phone 3.Page 1']//input"));
			actions.moveToElement(inputField2).click().sendKeys(phonePart[2]).perform();
			LoggingInfo("Primary Phone field is entered");

			LoggingInfo("verified spanish patient information");

		}

		catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify spanish patient information  " + e.getMessage());
			Assert.fail("Failed to verify spanish patient information" + e.getMessage());

		}

	}

	/**
	 * Function: Verify Mandatory Fields in the PDF form-spanish version
	 * 
	 * @author Trupti
	 **/
	public void verifyRequiredFieldsSpanishVer(String field) throws Exception {

		if (field.equalsIgnoreCase("Click to sign required")) {
			String val2 = getAttributeValue(elesignPatientAuth, "aria-required");
			if (val2.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a required Field");
			} else {
				Assert.fail(field + " is not a required Field");
			}
		} else {
//			scrollToPixel(0,250);
			By eleName = getDynamicElement(strFieldsSpanish, field);
			scrollToElement(eleName);
			String val = getAttributeValue(eleName, "aria-required");
			if (val.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a required Field");
				highLightElement(eleName);
			} else {
				Assert.fail(field + " is not a required Field");
			}
		}

	}

	/**
	 * Function: Enter Patient Details in the PDF(Dupixent Portal)
	 * 
	 * @author Trupti
	 **/
	public void enterPatientInfoSpanish(String fName, String lName, String primaryPhone) throws Exception {

		try {
			// Nombre
			By eleFName = getDynamicElement(strFieldsSpanish, "Custom Field 3");
			waitAndVerifyElement(eleFName);
			inputText(eleFName, fName);
			LoggingInfo("Nombre field is entered");

			// Apellido
			By eleLName = getDynamicElement(strFieldsSpanish, "Custom Field 2");
			waitAndVerifyElement(eleLName);
			inputText(eleLName, lName);
			LoggingInfo("Apellido is entered");

			// Número de tel.
			By elephone = getDynamicElement(strFieldsSpanish, "Custom Field 8");
			waitAndVerifyElement(elephone);
			inputText(elephone, primaryPhone);
			LoggingInfo("Número de tel. is entered");

			// Género
			By eleGender = getDynamicElement(strFieldsSpanish, "Custom Field 9");
			waitAndVerifyElement(eleGender);
			inputText(eleGender, "Female");
			LoggingInfo("Género is entered");

			// Fecha de nac.
			By eleDate = getDynamicElement(strFieldsSpanish, "Custom Field 10");
			waitAndVerifyElement(eleDate);
			String date = getNthDayFromTodaymmddyy(0);
			inputText(eleDate, date);

			// ¿Cuántas personas viven en su hogar? -
			By eleHouseHold = getDynamicElement(strFieldsSpanish, "Custom Field 14");
			waitAndVerifyElement(eleHouseHold);
			inputText(eleHouseHold, "50000");
			LoggingInfo("How many people live in your household?");

			// ¿Cuál es el ingreso anual total de su hogar?
			By eleTotalIncome = getDynamicElement(strFieldsSpanish, "Custom Field 27");
			waitAndVerifyElement(eleTotalIncome);
			inputText(eleTotalIncome, "50000");
			LoggingInfo("What is the total annual income of your household?");

			// Signature 2
			By eleSignature = getDynamicElement(strFieldsSpanish, "Signature 2");
			waitAndVerifyElement(eleSignature);
			inputText(eleSignature, "Automation@test.com");
			LoggingInfo("Signature 2 entered");

			By elesignPatient = By.xpath("(//div[@class='pdfFormField signature required todo-signature'])[1]");

			scrollToElement(elesignPatient);
			click(elesignPatient);

			inputText(eleSignaturePad, "Automation");
			LoggingInfo("Signature is entered");

			By eleApplyBtn = getDynamicElement(button, "Apply");
			click(eleApplyBtn);

		} catch (Exception e) {
			Log.error("Failed to fill details" + e.getMessage());
			Assert.fail("Failed to fill details " + e.getMessage());
		}

	}

	/**
	 * Function: Verify Patient Signature Authorization Page Form
	 * 
	 * @author Kavyashree
	 **/

	public void verifyPatienteSignatureAuthorizationPageForms() {

		try {
			waitAndVerifyElement(elePgForms);
			if (verifyElement(elePgForms)) {
				LoggingInfo("Patient Authorization & Agreement Forms page is verified");
			}

		} catch (Exception e) {
			Log.error("Failed to verify Patient Authorization & Agreement Forms page" + e.getMessage());
			Assert.fail("Failed to verify Patient Authorization & Agreement Forms page " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Mandatory Fields in the Enrollment PDF form
	 * 
	 * @author Kavyashree
	 **/
	public void verifyMandatoryFields(String field) throws Exception {

		if (field.equalsIgnoreCase("Signature:Patient")) {
			String val2 = getAttributeValue(elesignPatientAuth, "aria-required");
			if (val2.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a Mandatory Field");
			} else {
				Assert.fail(field + " is not a Mandatory Field");
			}
		} else {
			By eleName = getDynamicElement(strFields, field);
			scrollToElement(eleName);
			String val = getAttributeValue(eleName, "aria-required");
			if (val.equalsIgnoreCase("true")) {
				LoggingInfo(field + " is a Mandatory Field");
				highLightElement(eleName);
			} else {
				Assert.fail(field + " is not a Mandatory Field");
			}
		}

	}
	
	/**
	 * Function: Click Login Here
	 * 
	 * @author Shraddha
	 **/

	public void clcikLoginHere() {

		try {
			waitAndVerifyElement(loginHereEle);
			click(loginHereEle);
			waitForPageLoaded();
		} catch (Exception e) {
			Log.error("Failed to login " + e.getMessage());
			Assert.fail("Failed to login " + e.getMessage());
		}
	}

}
