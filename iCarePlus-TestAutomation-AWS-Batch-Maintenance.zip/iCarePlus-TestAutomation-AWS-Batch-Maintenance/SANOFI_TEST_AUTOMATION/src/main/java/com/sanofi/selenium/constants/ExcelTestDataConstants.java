package com.sanofi.selenium.constants;

public interface ExcelTestDataConstants {

	public static final String testCaseID = "TestCaseID";
	/***** Patient Information & Authorizations *****/
	public static final String documentTypeSelected = "Document Type Selected";
	public static final String careProductProgram = "Care Product Program";
	public static final String patientName = "Patient Name";
	public static final String patientDOB = "Patient DOB";
	public static final String patientPrimaryphone = "Patient Primary phone";
	public static final String patientEmail = "Patient Email";
	public static final String gender = "Gender";
	public static final String language = "Language";
	public static final String patientAddress = "Address";
	public static final String city = "City";
	public static final String state = "State";
	public static final String zip = "Zip";
	public static final String patientSecondaryphone = "Patient Secondary phone";
	public static final String patientAuthorizationDate = "Patient Authorization Date";
	public static final String patientCertificationsDate = "Patient Certifications Date";
	public static final String textMessagingConsent = "Text Messaging Consent";
	public static final String voicemail = "Voicemail";
	public static final String text = "Text";
	public static final String bestTimingAM = "Best Timing AM";
	public static final String bestTimingAfternoon = "Best Timing Afternoon";
	public static final String bestTimingPM = "Best Timing PM";
	public static final String legalRepresentativeName = "Legal Representative Name";
	public static final String legalrelationship = "Relationship";

	/***** Insurance Information *****/

	public static final String patienthasNOInsurance = "Patient has NO Insurance";
	public static final String rxPayerName = "Rx Payer Name";
	public static final String rxPhone = "Rx Phone";
	public static final String rxPolicyID = "Rx Policy ID";
	public static final String rxGroup = "Rx Group";
	public static final String rxBIN = "Rx BIN";
	public static final String rxPCN = "Rx PCN";
	public static final String medicalPayerName = "Medical Payer Name";
	public static final String medicalPhone = "Medical Phone";
	public static final String medicalPolicyID = "Medical Policy ID";
	public static final String medicalGroup = "Medical Group";
	public static final String policyholderName = "Policyholder Name";
	public static final String insrelationshipToPatient = "Relationship To Patient";
	public static final String preferredSpecialtyPharmacy = "Preferred Specialty Pharmacy";
	public static final String specialtyPharmacyName = "Specialty Pharmacy Name";
	public static final String pharmacyPhone = "Pharmacy Phone";
	public static final String pharmacyfax = "Pharmacy Fax";
	public static final String dUPIXENTMyWay = "DUPIXENT MyWay";

	/***** Prescriber Information *****/

	public static final String prescriberName = "Prescriber Name";
	public static final String specialty = "Specialty";
	public static final String prescriberAddress = "Prescriber Address";
	public static final String prescriberCity = "Prescriber City";
	public static final String prescriberState = "Prescriber State";
	public static final String prescriberZip = "Prescriber Zip";
	public static final String prescriberNPI = "Prescriber NPI";
	public static final String sitefacilityname = "Site/facility name";
	public static final String officeContactName = "Office Contact Name";
	public static final String officeContactEmail = "Office Contact Email";
	public static final String officePhone = "Office Phone";
	public static final String officeFax = "Office Fax";
	public static final String taxID = "Tax ID";
	public static final String prescriberstateLicense = "Prescriber State License";

	/***** Diagnosis Information *****/

	public static final String dateOfDiagnosis = "Date Of Diagnosis";
	public static final String diagnosisCode = "Diagnosis Code";
	public static final String count = "Eosinophil count";

	/***** Prescription Information *****/

	public static final String aSampleProvided = "Prescription 5A Sample Provided";
	public static final String aSampleProvidedDate = "Prescription 5A Sample Provided Date";
	public static final String aPrefilledSyringe = "Prescription 5A Prefilled Syringe";
	public static final String aPrefilledPen = "Prescription 5A Prefilled Pen";
	public static final String prescriptionARefillCaptured = "Prescription-5A RefillCaptured";
	public static final String prescription5ADose = "Prescription-5A Dose";
	public static final String aKnownDrugAllergies = "Prescription 5A Known Drug Allergies";
	public static final String aWeight = "Prescription 5A Weight";
	public static final String aInitialAndMaintenanceDoses = "Prescription 5A Initial And Maintenance Doses";
	public static final String prescription5BQuickStart = "Prescription 5B Quick Start";
	public static final String bSampleProvided = "Prescription 5B Sample Provided";
	public static final String bSampleProvidedDate = "Prescription 5B Date";
	public static final String bPrefilledSyringe = "Prescription 5B Prefilled Syringe";
	public static final String bPrefilledPen = "Prescription 5B Prefilled Pen";
	public static final String prescriptionBRefillCaptured = "Prescription-B RefillCaptured";
	public static final String prescription5BDose = "Prescription-5B Dose";
	public static final String bKnownDrugAllergies = "Prescription 5B Known Drug Allergies";
	public static final String bWeight = "Prescription 5B Weight";
	public static final String bInitialAndMaintenanceDoses = "Prescription 5B Initial And Maintenance Doses";
	public static final String prescriberSigned = "Prescriber Signed";
	public static final String prescriberSignatureDate = "Prescriber Signature Date";
	public static final String substitutionsDate = "Substitutions Date";
	public static final String collaboratingMDName = "Collaborating MD Name";
	public static final String NursePractitionerNPI = "Nurse Practitioner NPI";
	
	/**BV Verification Review and Finalize Benefit section**/
	public static final String callReferenceNumber = "Call Reference Number";
	public static final String payerRepName = "Payer Rep Name";
	public static final String coverageBenefitName = "Coverage Benefit Name";
	public static final String pharmacyDeductible= "Pharmacy Deductible";
	public static final String prescriptionServiceID= "Prescription Service ID";
	public static final String patientHasMedicarePartD = "Patient has Medicare Part D";
	public static final String pARequired= "PA required";
	public static final String medicalAndPharmacyBenefitsCombined= "Medical and pharmacy benefits combined";
	public static final String docID= "Document ID";
	public static final String EFfileName= "File Name";


}