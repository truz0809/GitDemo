package com.sanofi.selenium.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

import com.sanofi.selenium.utils.Utilities;

public class Configuration {

	private String fileName;

	public Configuration(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * Function: Read application file
	 *
	 * @param key
	 * @return
	 */

	// Add new config files name in if-else if you want to use multiple config files
	// to be used
	public static String readApplicationFile(String key) {

		String value = null;

		try {

			value = System.getenv(key);

			// Get password from env variable- Gihub secret
			if (value != null && !value.isEmpty()) {
				return value;
			}

			String env = "TestOrg";
			Files.write(Paths.get("env.txt"), env.getBytes());
			File f = null;
			try {

				Properties prop = new Properties();
				if (env.equals("QAOrg")) {
					f = new File(Utilities.getPath() + "//QAOrg_Config.properties");
				} else if (env.equals("QAEnhOrg")) {
					f = new File(Utilities.getPath() + "//QAEnhOrg_Config.properties");
				} else if (env.equals("UATOrg")) {
					f = new File(Utilities.getPath() + "//UATOrg_Config.properties");
				}else if (env.equals("TOLEUATOrg")) {
					f = new File(Utilities.getPath() + "//TOLEUATOrg_Config.properties");
				}else if (env.equals("TestOrg")) {
					f = new File(Utilities.getPath() + "//TestOrg_Config.properties");
				}else if (env.equals("TrainingOrg")) {
					f = new File(Utilities.getPath() + "//TrainingOrg_Config.properties");
				}else if (env.equals("TOLEQAOrg")) {
					f = new File(Utilities.getPath() + "//TOLEQAOrg_Config.properties");
				}else if (env.equals("TOLEQAr2Org")) {
					f = new File(Utilities.getPath() + "//TOLEQAr2Org_Config.properties");
				}else if (env.equals("QAWave2Org")) {
					f = new File(Utilities.getPath() + "//QAWave2Org_Config.properties");
				
				}
				if (f.exists()) {
					prop.load(new FileInputStream(f));
					value = prop.getProperty(key);
				} else {
					throw new Exception("File not found");
				}
			} catch (FileNotFoundException ex) {
				System.out.println("Failed to read from application.properties file.");
				throw ex;
			}
			if (value == null) {
				throw new Exception("Key not found in properties file");
			}
		} catch (

		FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * Function: Read application file
	 * 
	 * @param filename
	 * @return
	 */

	public static Properties readTestData(String fileName) throws Exception {

		Properties prop = new Properties();
		try {
			File f = new File(Utilities.getPath() + "//" + fileName + ".properties");
			if (f.exists()) {
				prop.load(new FileInputStream(f));
			}
		} catch (FileNotFoundException e) {
			throw new FileNotFoundException("File not found " + fileName);
		}
		return prop;
	}

	/**
	 * Function: Read application file
	 * 
	 * @param key and file.
	 * @return
	 */
	public static String readTestData(String key, String fileName) throws Exception {
		Properties prop = new Properties();
		String value;
		try {
			File f = new File(Utilities.getPath() + "//" + fileName + ".properties");
			System.out.println(Utilities.getPath() + "//" + fileName + ".properties");
			if (f.exists()) {
				prop.load(new FileInputStream(f));
				value = prop.getProperty(key);
			} else {
				throw new Exception("File not found");
			}
		} catch (FileNotFoundException ex) {
			throw ex;
		}
		if (value == null) {
			throw new Exception("Key not found in properties file");
		}
		return value;
	}

	/**
	 * Function: update application file
	 *
	 * @param key,filename,value.
	 * @return
	 */
	public static void updatePropertyTestData(String key, String value, String expFileName) {

		try {

			File f = null;
			try {

				Properties props = new Properties();

				f = new File(Utilities.getPath() + "//" + expFileName + ".properties");

				final FileInputStream configStream = new FileInputStream(f);
				props.load(configStream);
				configStream.close();

				props.setProperty(key, value);

				final FileOutputStream output = new FileOutputStream(f);
				props.store(output, "");
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				output.close();

			} catch (FileNotFoundException ex) {
				System.out.println("Failed to write from .properties file.");
				throw ex;
			}
		} catch (final IOException ex) {
			System.out.println(ex);
		}
	}

}
