package com.sanofi.selenium.core;

public class User {
	protected static String USERNAME, PASSWORD, LOGINURL, GRANTSERVICE, CLIENTID, CLIENTSECRET, REST_ENDPOINT,
			API_VERSION, assistRx_Endpoint, marketing_Endpoint, mCK_ClientSecrete, mCK_ClientId, mCK_GrantType,
			mCK_Scope, mCK_Token_URL, mCK_ApiKey, mCK_Endpoint_URL, atlantisKeyValue, atlantis_URI, atlantis_ProgramId,
			rdTmtCrewUsername, rdTmtCrewPassword, enrollmentURI, annexusURI, trialCardURI, annexusPassword,
			trialCardPassword, DISUserName, BVUsername, CMUserName, SAUserName,  DupixentMyWayPortalURL, URL, PCUserName,
			DISUser1Name, BOUsername, DISPassword1, uploadType, PMUserName, DISUser, BusinessOpsUserName, FRMUserName,
			TPLUserName, NurseEduUserName, QualityMGRUserName, QualityMGRPassword, CPEUrl, UserPassword, PSRUser, ARUserName, PSRUserName, ARSUserName, BOUserName;

	public static void configureUser() throws Exception {
		DISUserName = Configuration.readApplicationFile("DISUserName");
		BVUsername = Configuration.readApplicationFile("BVUserName");
		CMUserName = Configuration.readApplicationFile("CaseMangerUserName");
		PCUserName = Configuration.readApplicationFile("ProgramcoordinatorUserName");
		FRMUserName = Configuration.readApplicationFile("FRMUserName");
		BusinessOpsUserName = Configuration.readApplicationFile("BusinessOpsUserName");
		PMUserName = Configuration.readApplicationFile("ProgramManagerUserName");
		TPLUserName = Configuration.readApplicationFile("TPLUserName");
		NurseEduUserName = Configuration.readApplicationFile("NurseEduUserName");
		QualityMGRUserName = Configuration.readApplicationFile("QualityManagerUserName");
		SAUserName = Configuration.readApplicationFile("SystemAdminUserName");
		DupixentMyWayPortalURL = Configuration.readApplicationFile("DupixentMyWayPortalURL");
		URL = Configuration.readApplicationFile("url");
		uploadType = Configuration.readApplicationFile("uploadType");
		DISUser = Configuration.readApplicationFile("DISUserOwner");
		CPEUrl = Configuration.readApplicationFile("CPEUrl");
		mCK_Endpoint_URL = Configuration.readApplicationFile("MCKESSON_ENDPOINT_URL");
		assistRx_Endpoint = Configuration.readApplicationFile("URI_AssistRX");
		annexusURI = Configuration.readApplicationFile("URI_Annexus");
		marketing_Endpoint = Configuration.readApplicationFile("URI_Marketing");
		trialCardURI = Configuration.readApplicationFile("URI_TrialCard");
		mCK_Token_URL = Configuration.readApplicationFile("MCKESSON_TOKEN_URL");
		UserPassword = Configuration.readApplicationFile("UserPassword");
		PSRUserName = Configuration.readApplicationFile("PSRUserName");
        ARUserName = Configuration.readApplicationFile("ARUserName");
		BOUserName = Configuration.readApplicationFile("BusinessOpsUserName");
		ARSUserName = Configuration.readApplicationFile("ARSUserName");

	}

	protected static String getConfigValue(String key) {
		// First, try to get the value from environment variables (more secure for CI/CD
		// pipelines)
		String value = System.getenv(key);
		if (value != null && !value.isEmpty()) {
			return value;
		}

		// If environment variable is not set, fall back to reading from a configuration
		// file (e.g., .properties)
		try {
			return Configuration.readApplicationFile(key);
		} catch (Exception e) {
			// Handle exception if both methods fail (you might want to log or throw a more
			// specific error)
			throw new RuntimeException("Configuration value for " + key + " could not be found", e);
		}
	}
}