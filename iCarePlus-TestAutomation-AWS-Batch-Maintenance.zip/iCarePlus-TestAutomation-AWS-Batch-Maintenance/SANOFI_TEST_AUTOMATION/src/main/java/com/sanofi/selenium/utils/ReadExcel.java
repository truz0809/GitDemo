package com.sanofi.selenium.utils;

import java.io.*;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;

import com.sanofi.selenium.core.Configuration;
import com.sanofi.selenium.core.ExcelDataUpdate;

public class ReadExcel {
	private static String Filepath = System.getProperty("user.dir") + "/TestData/" + "TestDataFile.xlsx";
	private static String Filepath1 = System.getProperty("user.dir") + "/TestData/" + "EnrollmentFormTestData.xlsx";
	private String testNGExcelFilepath = System.getProperty("user.dir") + "/TestData/" + "TestNG.xlsx";
	private String sheetName;
	public Map<String, String> map;
	String value;
	private static final Set<String> createdThreadFiles = Collections.synchronizedSet(new HashSet<>());
	private String threadSafeFilePath;
	private static final Object excelLock = new Object();

	public ReadExcel(String sheetIName) {
		this.sheetName = sheetIName;

		String currentPath = TestDataContext.getExcelPath();

		if (currentPath == null) {
			if (shouldCreateCopy()) {
				String generatedPath = createThreadSafeCopy();
				TestDataContext.setExcelPath(generatedPath);
				this.threadSafeFilePath = generatedPath;
			} else {
				TestDataContext.setExcelPath(Filepath1);
				this.threadSafeFilePath = Filepath1;
			}
		} else {
			this.threadSafeFilePath = currentPath;
		}
	}

	public ReadExcel(String sheetIName, String customFilePath) {
		this.sheetName = sheetIName;
		if (customFilePath != null && !customFilePath.isEmpty()) {
			TestDataContext.setExcelPath(customFilePath);
			this.threadSafeFilePath = customFilePath;
		} else {
			System.out.println("Using shared file path (Filepath1)");
			TestDataContext.setExcelPath(Filepath1);
			this.threadSafeFilePath = Filepath1;
		}
	}

	private String createThreadSafeCopy() {
		String threadName = Thread.currentThread().getName();
		String dest = System.getProperty("user.dir") + "/TestData/Test_" + threadName + "_EnrollmentFormTestData.xlsx";

		synchronized (createdThreadFiles) {
			if (!createdThreadFiles.contains(dest)) {
				try {
					Path source = Paths.get(Filepath1);
					Path destination = Paths.get(dest);
					Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);

					createdThreadFiles.add(dest);
					System.out.println("Created Excel copy for thread: " + threadName + " at: " + dest);
				} catch (IOException e) {
					e.printStackTrace();
					return Filepath1;
				}
			} else {
				System.out.println("Reusing Excel copy for thread: " + threadName);
			}
		}

		return dest;
	}

	public Map<String, String> getExcelInputData(int rowNo) {
		synchronized (excelLock) {
			Map<String, String> excelData = new HashMap<>();
			String path = TestDataContext.getExcelPath();
			try (FileInputStream fis = new FileInputStream(path); XSSFWorkbook workbook = new XSSFWorkbook(fis)) {

				XSSFSheet sheet = workbook.getSheet(sheetName);
				Row headerRow = sheet.getRow(0);
				Row dataRow = sheet.getRow(rowNo);

				if (headerRow == null || dataRow == null) {
					System.out.println("Row not found in Excel: Row " + rowNo);
					return excelData;
				}

				int columnCount = headerRow.getLastCellNum();
				for (int j = 0; j < columnCount; j++) {
					String key = headerRow.getCell(j).getStringCellValue();
					String value = getCellValueAsString(dataRow.getCell(j));
					excelData.put(key, value);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

			return excelData;
		}
	}

	public Map<String, String> getExcelInputData(String testcaseID) {
		synchronized (excelLock) {
			Map<String, String> excelData = new HashMap<>();
			String path = TestDataContext.getExcelPath();
			try (FileInputStream fis = new FileInputStream(path); XSSFWorkbook workbook = new XSSFWorkbook(fis)) {

				XSSFSheet sheet = workbook.getSheet(sheetName);
				Row headerRow = sheet.getRow(0);
				if (headerRow == null)
					return excelData;

				List<String> columnHeader = new ArrayList<>();
				for (Cell cell : headerRow) {
					columnHeader.add(cell.getStringCellValue());
				}

				for (int i = 1; i <= sheet.getLastRowNum(); i++) {
					Row row = sheet.getRow(i);
					if (row != null && testcaseID.equalsIgnoreCase(getCellValueAsString(row.getCell(0)))) {
						for (int j = 0; j < columnHeader.size(); j++) {
							Cell cell = row.getCell(j);
							excelData.put(columnHeader.get(j), getCellValueAsString(cell));
						}
						break;
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

			return excelData;
		}
	}

	public XSSFSheet getSheet() throws IOException {
		String path = TestDataContext.getExcelPath();
		try (FileInputStream fis = new FileInputStream(path); XSSFWorkbook workbook = new XSSFWorkbook(fis)) {
			return workbook.getSheet(sheetName);
		}
	}

	public XSSFSheet getSheetData(String expFilePath) throws IOException {
		FileInputStream fis = new FileInputStream(expFilePath);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		return wb.getSheetAt(0);
	}

	public String getCellValueAsString(Cell cell) {
		DataFormatter formatter = new DataFormatter();
		return formatter.formatCellValue(cell);
	}

	public String getSheetName(int index) throws IOException {
		String path = TestDataContext.getExcelPath();
		FileInputStream file = new FileInputStream(path);
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		return workbook.getSheetName(index);
	}

	public int getSheetCount() throws IOException {
		String path = TestDataContext.getExcelPath();
		FileInputStream file = new FileInputStream(path);
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		return workbook.getNumberOfSheets();
	}

	public int totolColumnCount() throws IOException {
		XSSFSheet sheet = getSheet();
		Row row = sheet.getRow(0);
		return row.getLastCellNum();
	}

	public static String readJiraKeysBasedOnMethodName(String fileName, String methodName)
			throws FileNotFoundException, IOException {
		ReentrantLock lock = new ReentrantLock();
		String jirakey = "";
		Map<String, Integer> requiredHeaders = new HashMap<>();
		XSSFWorkbook workbook = new XSSFWorkbook(fileName);
		DataFormatter formatter = new DataFormatter();
		XSSFSheet sheet = workbook.getSheetAt(0);
		try {
			lock.lock();
			for (Cell cell : sheet.getRow(0)) {
				requiredHeaders.put(cell.getStringCellValue(), cell.getColumnIndex());
			}

			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				Row row = sheet.getRow(i);
				if (formatter.formatCellValue(row.getCell(requiredHeaders.get("TestName")))
						.equalsIgnoreCase(methodName)) {
					jirakey = formatter.formatCellValue(row.getCell(requiredHeaders.get("JIRAKey")));
					System.out.println("Inside Get Jira Key Method" + jirakey);
				}
			}
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			lock.unlock();
		}
		return jirakey;
	}

	public void updateExecutionResultInTestNgExcelData(HashMap<String, String> TestNGResultHashMapata)
			throws IOException, InvalidFormatException {

		FileInputStream inputStream = new FileInputStream(testNGExcelFilepath);
		Workbook workbook = WorkbookFactory.create(inputStream);
		Sheet sheetdata = workbook.getSheetAt(0);

		for (int i = 1; i <= sheetdata.getLastRowNum(); i++) {
			Cell cell = sheetdata.getRow(i).getCell(1);
			String testCaseValue = getCellValueAsString(cell);
			if (TestNGResultHashMapata.containsKey(testCaseValue)) {
				for (Map.Entry<String, String> entry : TestNGResultHashMapata.entrySet()) {
					String strTestCaseNameValue = entry.getKey();
					if (testCaseValue.contains(strTestCaseNameValue)) {
						SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
						String CurrentDate = dateFormat.format(new Date());
						sheetdata.getRow(i).createCell(8).setCellValue(entry.getValue());
						sheetdata.getRow(i).createCell(9).setCellValue(CurrentDate);
						break;
					}
				}
			}
		}

		inputStream.close();
		FileOutputStream outputstream = new FileOutputStream(testNGExcelFilepath);
		workbook.write(outputstream);
		outputstream.close();
		System.out.println("Execution Result Update successfully In TestNg.xlsx File");
	}

	public static void setCellData(String sheetName1, String colNumber, String rowNumb, String value) {
		int rowNum = Integer.parseInt(rowNumb);
		FileInputStream fis = null;
		FileOutputStream fos = null;
		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		XSSFRow row = null;
		XSSFCell cell = null;

		try {
			fis = new FileInputStream(Filepath1);
			workbook = new XSSFWorkbook(fis);
			fis.close();

			sheet = workbook.getSheet(sheetName1);
			row = sheet.getRow(rowNum);
			if (row == null)
				row = sheet.createRow(rowNum);

			cell = row.getCell(CellReference.convertColStringToIndex(colNumber));
			if (cell == null)
				cell = row.createCell(CellReference.convertColStringToIndex(colNumber));

			cell.setCellValue(value);

			fos = new FileOutputStream(Filepath1);
			workbook.write(fos);
			fos.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public static void cleanUpExcelCopy() {
		String path = TestDataContext.getExcelPath();
		if (path != null && !path.equals(Filepath1)) {
			try {
				Files.deleteIfExists(Paths.get(path));
				createdThreadFiles.remove(path);
				Log.info("Deleted test-specific Excel file: " + path);
			} catch (IOException e) {
				Log.info("Failed to delete Excel file: " + path);
				e.printStackTrace();
			}
		}
		TestDataContext.clear();

	}

	private String getExecutionModeFromConfig() {
		String mode = Configuration.readApplicationFile("executionMode");
		if (mode == null || mode.trim().isEmpty()) {
			mode = "Local";
		} else {
			mode = mode.trim();
		}
		System.out.println("Execution mode from config: " + mode);
		return mode;
	}

	private boolean shouldCreateCopy() {
		String mode = getExecutionModeFromConfig();
		return mode.equalsIgnoreCase("Remote");
	}

}
