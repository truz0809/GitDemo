package com.sanofi.selenium.pages;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Random;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import static org.testng.Assert.assertEquals;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class DocumentManagementPage extends Utility_Function {
	public DocumentManagementPage(WebDriver driver) {
		super(driver);
	}

	Random random = new Random();
	/************************
	 * Elements
	 **************************************************/
	public static By eleinactiveButton = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//select[@name='Inactivation_Reason' and contains(@class, 'slds-select')]");
	public static By eleCPEStatusButton = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),'CPE Status Update')]");

	public static By eleOwnerNameField = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//p[text()='Owner Name']//parent::div//following-sibling::p//child::span[@class='slds-truncate']/slot");

	public static By docfield = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"Document Type\"]//parent::label//parent::div//following-sibling::div//input");
	public static By docType = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"Document Type\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(text(),'Invalid Document')]");
	public static By eleFirstRecord = By.xpath("(//a[text()='Open CPE'])[1]");
	public static By eleMainTaskStatus = By.xpath("//*[text()='Start New Service']");
	public static By eleSelectDropDown = By.xpath("//*[contains(@class,\"active lafPageHost\")]//select");
	public static By eleMessage = By
			.xpath("//p[text()='The Correspondence Sharps Kit has been successfully generated.']");
	public static By eleSelectItemsToSend = By.xpath(
			"(//*[text()='Select Items to Send']//parent::label//parent::div//following-sibling::div//input)[1]");
	public static By eleSelectItemsToSendDropdown = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()='Select Items to Send']//parent::label//parent:: div //following-sibling:: div // li //child::span[contains(@class,\"option-text\")]");
	public static By listViewButton = By.xpath("//*[@title=\"Select a List View: Assessment Tasks\"]");
	public static By listViewButtonproducts = By

			.xpath("//*[@title=\"Select a List View: Care Program Products\"]");

	public static By eleDCRDropdownOptions = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()='DCR Notes']//parent::label//parent:: div //following-sibling:: div//*[@role=\"option\"]//child::span//child::span");
	public static By myAssessmentListView = By.xpath("//*[text()=\"My Assessment Tasks\"]");
	public static By eleCorrespondenceBuuton = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),'Correspondence')]");

	public static By eleEditPrefferedSP = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()='Edit Preferred Specialty Pharmacy']//parent::button");
	public static By eleEditSPtype = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()='Edit SP Type']//parent::button");

	public static By error = By.xpath("//*[text()=\"We hit a snag.\"]");
	public static By eleClose=By.xpath("//*[text()=\"We hit a snag.\"]//parent::div//ancestor::header//preceding-sibling::lightning-button-icon//button");

	public static By eleErrorMessage = By.xpath(
			"//p[text()='The correspondence cannot be generated because the Fax information is either missing or incomplete.']");

	public static By eleFinishButton = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()='Finish']");
	public static By eleSite = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()='Site']//ancestor::records-record-layout-item//a");
	public static By eleHCP = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()='Prescriber']//ancestor::records-record-layout-item//a//child::slot//slot//span");
	public static By eleEditFax = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//span[text()='Edit Fax']//parent::button");

	public static By eleFaxField = By.xpath("//*[contains(@class,\"active lafPageHost\")]//label[text()='Fax']");
	public static By eleEditFaxButton = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@name='Edit']");

	public static By eleFaxInput = By.xpath("//*[contains(@class,\"active lafPageHost\")]//input[@name='Fax']");
	public static By eleDocName = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()='DMW Summary of Benefits - MD Fax.docx']");
	public static By eleDoc = By.xpath("//*[@Class='Modal ProgressModal closed']");
	public static By eleSendButton = By.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Send\"])[1]");
	public static By eleSuccessMessage = By.xpath(
			"//p[text()='The Correspondence DMW Summary of Benefits - MD Fax has been successfully generated.']");
	public static By eleBV = By.xpath("//input[@data-value='BV']");
	public static By eleProcessTextField = By
			.xpath("//*[text()='Process Name']//parent::label//parent::div//following-sibling::div//input");
	public static By eleCloseCorrespondence = By.xpath("//*[contains(@title,'Close correspondenceMultiIcc')]");
	public static By eleErrorMSG = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-text-block\")]//p");
	public static By successMessage = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-text-block\")]//p)[1]");
	public static By eleAccountName = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//p[contains(text(),'Account')]//parent::div//span[@class=\"slds-truncate\"]");
	public static By eleCorrespondencesTable = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@title=\"Correspondences\"]");
	public static By dashboardTitle = By.xpath("//*[text()=\"Case Manager Homepage\"]");

	public static By failReportTitle = By.xpath("//article//div[text()=\"My Failed Correspondence\"]");
	public static By viewReportLink = By
			.xpath("//*[contains(text(),'My Failed Correspondence')]//following::a[contains(text(),'View Report')]");
	// public static By viewReportLink = By.xpath("//*[contains(text(),'My Failed
	// Correspondence')]//following::a[contains(text(),'View Report')]");
	public static By eleSuccessMessageForPT = By.xpath(
			"//p[text()='The Correspondence DMW Summary of Benefits (PA) - PT Letter has been successfully generated.']");
	public static By eleCreProgramEnrolleeName = By.xpath(
			"//records-entity-label[text()='Care Program Enrollee']//parent::slot//parent::div//following-sibling::slot//lightning-formatted-text");

	public static By eleMailingAddress = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()='Mailing Address']//parent::div//parent::dt//following-sibling::dd//child::button//span[text()=\"Edit Mailing Address\"]");
	public static By eleMailingCountry = By
			.xpath("//*[text()=\"Mailing Country\"]//parent::label//parent::div//following-sibling::div//input");
	public static By eleErrorMessageForPT = By.xpath(
			"//p[text()='The correspondence cannot be generated because the Mailing Address information is either missing or incomplete.']");
	public static By eleMailingState = By
			.xpath("//*[text()=\"Mailing State/Province\"]//parent::label//parent::div//following-sibling::div//input");
	public static By eleCOR = By
			.xpath("//th[@title='Correspondence Name']//parent::tr//parent::thead//following-sibling::tbody//div[1]");

	public static By eleResponseMessage = By
			.xpath("//*[text()='Message']//parent::div//parent::dt//following-sibling::dd//lightning-formatted-text");

	public static By eleOwnerName = By
			.xpath("//*[contains(@class, 'owner-name')]//slot[text()='PSQA Review Worklist']");
	public static String strAddressTextArea = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"row\")]//textarea";

	public static By disableAutoOCRCHKBox = By.xpath(
			"//*[contains(@class,'active lafPageHost')]//*[text()=\"Disable Auto OCR\"]//ancestor::span[@class=\"slds-checkbox\"]//input");

	public static By receivedDocTab = By.xpath("//a[@title=\"Received Documents\"]");
	public static By elecaseManagerField = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-form-element\")]//*[text()=\"Case Manager\"]//ancestor::dt//following-sibling::dd//a//span/slot)[2]");
	public static By eleError = By
			.xpath("//p[text()='Please assign this received document to yourself and then proceed']");
	public static By eleFirstCPERecord = By
			.xpath("(//*[@title='Name']//ancestor::thead//following-sibling::tbody//th//span)[1]//a");
	public static By eleRDTab = By.xpath("//a[@title='Received Documents']");
	public static String strDetailsPageDocTitle = "//div[contains(@class,\"entityNameTitle\")]//following-sibling::slot//*[text()=\"{0}\"]";
	public static By searchDocInput = By.xpath("//*[@placeholder=\"Search this list...\"]");
	// public static By eleOwnerName = By.xpath("//span[text()='Created
	// By']//ancestor::dt//following-sibling::dd//records-modstamp//a//slot[text()='Test_DIS
	// User_1']");
	public static By eleMemberPlans = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@title=\"Member Plans\"]");
	public static By buttonsaveAs = By.xpath("//*[@data-element='saveAsButton']");
	public static By menuButton = By.xpath("//*[@data-element='menuButton']");
	public static By fileName = By.xpath("//input[@data-testid='fileNameInput']");
	public static By saveFileButton = By.xpath("//button/span[text()='Save File']");
	public static By frameName = By.xpath("//iframe[@id='webviewer-1']");
	public static By reportFrameName = By.xpath("//iframe[@title='Report Viewer']");
	public static By accessibilityFrameName = By.xpath("//iframe[@title='accessibility title']");
	public static By eleFrameImg = By.xpath("//canvas[@class='hacc canvas1']");
	public static By eleFilesSection = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@title=\"Files\"]");
	public static By receivedDateSortingState = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Received Date\"]//ancestor::th//span[contains(@class,\"assistive-text\")])[2]");
	public static By receivedDateSortingColumn = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Received Date\"]//ancestor::th//a");
	public static By correspondenceSortingState = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Correspondence Name\"]//ancestor::th//span[contains(@class,\"assistive-text\")])[2]");
	public static By correspondenceSortingColumn = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Correspondence Name\"]//ancestor::th//a");
	public static By documentTab = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//a[@data-label=\"Document\"]");
	public static By detailsTab = By.xpath("//*[contains(@class,\"active lafPageHost\")]//a[@data-label=\"Details\"]");
	public static By relatedTab = By.xpath("//*[contains(@class,\"active lafPageHost\")]//a[@data-label=\"Related\"]");
	public static By eleSelectBtn = By.xpath("//button[text()='Select']");
	public static By eleCORElement = By
			.xpath("(//th[@title='Correspondence Name']//ancestor::thead//following-sibling::tbody//a)[1]");
	public static By eleDUP = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Correspondence Code\"]//parent::div//following-sibling::div//lightning-formatted-text");
	public static By eleCorrRec = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[contains(text(), 'COR-00')]//ancestor::a");
	public static By eleFailedStatus = By.xpath("(//lightning-formatted-text[text()='Failed'])[1]");
	public static By eleResendBtn = By.xpath("//*[@name='Correspondence_ICC__c.Resend_ICC']");
	public static By eleExistingRec = By.xpath("(//th//parent::slot//parent::a)[4]");
	public static By eleEditTaxIdField = By.xpath("//*[@title='Edit Tax id']");
	public static By eleInputTaxId = By.xpath("//*[@name='ICC_FacilityTaxID__c']");
	public static By elePhoneInp = By.xpath("//*[@name='Phone']");
	public static By eleSaveEdit = By.xpath("//*[@name='SaveEdit']");

	public static String strTextBoxesInput = "// *[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//following-sibling::div//input";
	public static String accDetailsLinkField2 = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[contains(@class, \"test-id__field-label\") and text()=\"{0}\"]";

	public static String fieldBtn = "//*[@aria-label=\"{0}\" and @type=\"button\"]";
	public static String dropDownValues = "//*[@aria-label=\"{0}\"]//parent::div//following-sibling::div//lightning-base-combobox-item[@role=\"option\"]//span[@class=\"slds-media__body\"]//child::span";
	public static String casecolumnHeader = "//*[text()=\"{0}\"]";
	public static String caseNumberHeader = "//table//th[@scope='col' and @role='columnheader']//a//child::span//following-sibling::span[text()='Case Number']";
	public static String strQuickStartCPE = "//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"{0}\")]//ancestor::a";
	public static String strAccountObjectDetails = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-text";

	// public static By eleResendBtn =
	// By.xpath("//button[@name='Correspondence_ICC__c.Resend_ICC']");
	/************************
	 * 
	 * /************************ Dynamic Elements
	 **************************************************/
	public static String eleEdit = "//*[contains(@class,\"active lafPageHost\")]//*[@title=\"{0}\"]";
	public static String editBtn = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";
	public static By eleCorrespondance = By.xpath("//*[text()='Correspondence']");
	public static By eleCheckBox1 = By.xpath("(//*[@class=\"slds-checkbox_faux\"])[3]");
	public static By eleCheckBox2 = By.xpath("(//*[@class=\"slds-checkbox_faux\"])[4]");
	public static String strProcessNameDropList = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]";
	public static String elenavigationButton = "(//*[text()=\"{0}\"])[1]";
	public static String strOutcomeDropdown = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//child::div//child::input";
	public static By eleSendAttchment = By.xpath("(//*[text()='Send'])[1]");
	public static String eleButton = "//*[contains(@class,\"active lafPageHost\")]//*[@title=\"{0}\"]";
	public static String strTaskName = "//*[contains(@class,\"active lafPageHost\")]//h3[@class=\"slds-section__title\"]//span[text()=\"{0}\"]";
	public static String strDocumentPageTitle = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strDropDownXpath = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strDropDownInputBox = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input)[1]";
	public static String strDropDownSelectItemsToSend = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input)[1]";

	public static String strDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//span[contains(@class,\"option-text\")]";
	public static String searchDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//span[contains(@class,\"option-text\")]";
	public static String accountInputBox = "//*[contains(@class,\"active lafPageHost\")]//label[text()=\"{0}\"]//parent::div//input";
	public static String correspondenceInputField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"slds-form-element\")]//lightning-formatted-text";
	public static String statusInputField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String detailsPageLinkFields = "(//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-form-element\")]//*[text()=\"{0}\"]//ancestor::dt//following-sibling::dd//a//span)[2]";
	public static String eleTableName = "//*[contains(@class,\"active lafPageHost\")]//span[@title=\"{0}\"]";
	public static String eleDetailsPageLinkEditFields = "//*[contains(@class,\"active lafPageHost\")]//label[text()=\"{0}\"]//ancestor::div[contains(@class,\"test-id\")]//input";
	public static String accountTextAreaBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::lightning-textarea//following-sibling::div//child::textarea";
	public static String strFieldCPEPage = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-text";
	public static String strFieldCPEPageName = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-name";
	public static String strFieldCPEPageEmail = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-email";
	public static String strInsuranceDate = "//label[text()=\"{0}\"]";
	public static String columnHeader = "(//*[@role=\"button\" and text()=\"{0}\"])[2]";
	public static String corresValues = "//span[text()=\"{0}\"]//ancestor::dt//following-sibling::dd//lightning-formatted-text";
	public static String strAccDropDownBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//input";
	public static String strAccDropDownBoxOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//lightning-base-combobox-item//span[contains(@class,\"slds-truncate\")]";
	public static String detailsPageFields = "(//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-form-element\")]//*[text()=\"{0}\"]//ancestor::dt//following-sibling::dd//span)[1]";
	public static By eleDocId = By.xpath("//*[contains(@class,\"active lafPageHost\")]//tr[1]//td[3]");
	public static String strSource = "//*[contains(@class,\"active lafPageHost\")]//td//span[@title=\"{0}\"]//ancestor::td//following-sibling::td[1]";
	public static String strSourceChnl = "//*[contains(@class,\"active lafPageHost\")]//td//span[@title=\"{0}\"]//ancestor::td//following-sibling::td[2]";
	public static String strStatus = "//*[contains(@class,\"active lafPageHost\")]//td//span[@title=\"{0}\"]//ancestor::td//following-sibling::td[3]";
	public static String cpeDetailsLinkField = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div";
	public static String accDetailsLinkField = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//parent::dt//following-sibling::dd//a";
	public static String generateDoc = "//h3[contains(text(),\"{0}\")]";
	public static String strCPEUpdateDropdown = "//*[contains(@class,\"active lafPageHost\")]//select[@name=\"{0}\"]";
	public static String strFieldCPEPage2 = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//span";

	public static String eleDate = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//ancestor::records-record-layout-item//lightning-formatted-text";
	public static String memPlan = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//parent::slot//parent::a//ancestor::td//preceding-sibling::th//a";

	public static String caseRadioButton = "(//label[contains(@class, 'slds-radio__label') and .//span[contains(text(), \"{0}\")]]/span[contains(@class, 'slds-radio_faux')])[1]";
	/*******************************************
	 * new method for consent form
	 */
	public static String eleDemoGraphicInputFields = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@name,\"{0}\")]";
	public static String editButton = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@title,\"{0}\") and contains(@class,\"edit\")]";
	public static By eleAuthorizationConsentTitle = By
			.xpath("//strong[contains(text(), 'Authorization Form Consents')]");
	public static String strAccountName = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[@title=\"{0}\"]//parent::div//*[starts-with(text(),\"Automation\")]";
	public static String strAuthorizationieldButtons = "//*[text()=\"{0}\"]";
	public static By eleAuthrizationFieldsValueName = By.xpath("//*[@name='Name']");
	public static String strSearchList = "//label[text()=\"{0}\"]";

	public static By strSearchCarePgm = By.xpath("//*[@placeholder='Search Care Programs...']");
	public static By eleAuthorizationFormConsentGiverValue = By.xpath("(//*[@placeholder='Search...'])[2]");
	public static String strRelatedRec = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[@title=\"{1}\"]";
	public static String strAuthorizationFormStatusValue = "//*[@aria-label=\"{0}\" and @type=\"button\"]";
	public static By eleDataPurposeSearchField = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),'Data Use Purpose')]/following::span[contains(text(),'Show more results for')]");
	public static By eleCarePgmSearchField = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),'Care Program')]/following::span[contains(text(),'Show more results for')]");

	public static By eleDataPurposeInputField = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"field_textarea\")]//*[contains(text(),'Data Use Purpose')]//following-sibling::div//input");
	public static By eleCarePgmInputField = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"field_textarea\")]//*[contains(text(),'Care Program')]//following-sibling::div//input");

	public static By eleConsentCapDateInputField = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"field_textarea\")]//*[contains(text(),'Consent Capture Date')]//following-sibling::div//input");
	public static By eleConsentRecord = By.xpath("//span[text()='Select Item 1']//preceding-sibling::span");

	public static By eleAuthorizationFormRelatedRecValue = By.xpath("(//*[@placeholder='Search...'])[1]");
	public static By tab = By.xpath("//ul[contains(@class,'tabBarItems slds-grid')]//a[@role='tab']");
	// Dropdown ListValues
	public static String strAuthorizationFormTxtListVal = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[text()=\"Dupixent Patient Authorization Form Text\"]";
	public static String strConsentCapListValue = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[text()=\"{1}\"]";
	public static By eleAuthorizationConsentCapInput = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()='Consent Captured Date Time']//following-sibling::div//child::div//child::div//following-sibling::div//child::input[@name='ConsentCapturedDateTime'])[1]");
	public static By eleAuthorizationConsentExpInput = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()='Consent Expiration Date Time']//following-sibling::div//child::div//child::div//following-sibling::div//child::input[@name='ConsentExpirationDateTime'])[1]");
	public static String strDataUsePurListVal = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[text()=\"{1}\"]";
	public static String strCarePrgmListVal = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[text()=\"{1}\"]";
	public static String strStatusListValue = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[text()=\"{1}\"]";
	public static String strInputText = "//*[contains(@class,\"active lafPageHost\")]//*[@name=\"{0}\" and @part=\"input\"]";
	public static String strTextArea = "//*[contains(@class,\"active lafPageHost\")]//textarea[@name=\"{0}\"]";
	public static String strCaseFields = "//*[contains(@class,\"active lafPageHost\")]//div//*[text()=\"{0}\"]";
	public static By eleCaseLink = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Cases\"]//tbody//tr[1]//th[1]//a[@data-refid='recordId']");
	public static By eleSubjectField = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Cases\"]//tbody//tr[1]//td[1]//span");
	public static By eleCasesTable = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@title=\"Cases\"]");

	public static By newBtn = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()='New']");

	public static By elCPETeamMember = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//span[@title=\"Care Program Enrollee Team Members\"]");

	public static By eleRecentCorrespondenceRec = By
			.xpath("((//*[contains(@class,\"active lafPageHost\")]//span[contains(text(), \"COR-\")]))[1]");
	public static By eleRecentCPERecord = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//th//a[contains(@title,'Automation')])[1]");
	public static By eleListView = By.xpath("//*[@title=\"Select a List View: Care Program Enrollees\"]");
	public static By eleListViewAcc = By.xpath("//*[@title=\"Select a List View: Accounts\"]");

	public static String strColumn = "//*[contains(@class,\"active lafPageHost\")]//th[@aria-label=\"{0}\"]//span";

	public static String strColumnCase = "//*[contains(@class,\"active lafPageHost\")]//span[@title=\"{0}\"]";

	public static By eleExisitngCPERecord = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//td//a[contains(text(),'')])[1]");
	public static String strRecord = "//*[contains(@class,\"active lafPageHost\")]//th//span//a[@title=\"{0}\"]";
	public static String strNextButtons = "(//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"])[1]";
	public static By eleDCRNotesType = By.xpath("//*[@aria-label=\"DCR Notes\"]");
	public static String strInsAddDate = "//*[@name=\"{0}\"]";
	public static By eleCOPD = By.xpath("//*[@title='Yes']");
	public static By eleRecentCase = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//td[@data-label=\"Record Type\"]//*[text()=\"Missing Information\"]//ancestor::tr//a)[1]");
	public static String strLastModified = "(//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//ancestor::div[contains(@class,\"slds-form-element\")]//a//child::span)[3]";
	public static By eleResendFinishBtn = By.xpath("//*[text()='Finish']");
	public static String strField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"slds-form-element\")]//lightning-formatted-text";
	public static By eleShowMoreActions = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"Show more actions\")]//parent::button");
	// public static By elePolicyHolderDt =
	// By.xpath("//input[@name='PolicyholderDOB_ICC__c']");InsuranceAddDate_ICC__c

	public void createAuthorizationFormConsentRecord(String fullName, String consentGiverName, String sourceType,
			String dataUsePurpose, String careProgramType, String consentStatus) {
		try {
			// Name
			inputText(eleAuthrizationFieldsValueName, fullName);
			setTimeOut(2000);
			LoggingInfo("User enters name in the authorization form consent page");

			// ConsentGiver
			By consentGiverRec = getDynamicElement(strSearchList, "Consent Giver");
			scrollToElement(consentGiverRec);
			waitAndVerifyElement(eleAuthorizationFormConsentGiverValue);
			setTimeOut(1000);
			inputText(eleAuthorizationFormConsentGiverValue, consentGiverName);
			setTimeOut(500);
			selectItemFromDropdown(strSearchList, strRelatedRec, "Consent Giver", consentGiverName);
			LoggingInfo("User selects Consent Giver");
			setTimeOut(2000);

			// Authorization Form Text
			selectItemFromDropdown(strSearchList, strAuthorizationFormTxtListVal, "Authorization Form Text",
					"Dupixent Patient Authorization Form Text");
			LoggingInfo("User selects Authorization Form Text option from dropdown");
			setTimeOut(2000);

			// Consent Captured Source Type
			selectItemFromDropdown(strAuthorizationFormStatusValue, strConsentCapListValue,
					"Consent Captured Source Type", sourceType);
			LoggingInfo("User selects Consent Captured Source Type option from dropdown");
			setTimeOut(2000);

			// Consent Captured Date Time

			int year = 2000 + random.nextInt(23);
			int month = 1 + random.nextInt(12);
			int day = 1 + random.nextInt(28);
			String consentCaptureDate = String.format("%02d/%02d/%02d", month, day, year);

			scrollToElement(eleConsentCapDateInputField);
			setTimeOut(500);
			inputText(eleConsentCapDateInputField, consentCaptureDate);
			setTimeOut(2000);
			LoggingInfo("User enters Consent Captured date");

			// Data Use Purpose
			inputText(eleDataPurposeInputField, dataUsePurpose);
			setTimeOut(3000);
			click(eleDataPurposeSearchField);
			setTimeOut(3000);
			// By eleConsentRecordType = getDynamicElement(eleConsentRecord,
			// dataUsePurpose);
			waitAndVerifyElement(eleConsentRecord);
			click(eleConsentRecord);
			setTimeOut(1000);
			click(eleSelectBtn);
			LoggingInfo("User selects Care Program option from dropdown");
			setTimeOut(2000);

			// Consent Expiration Date Time

			int yearE = 2000 + random.nextInt(23);
			int monthE = 1 + random.nextInt(12);
			int dayE = 1 + random.nextInt(28);
			String consentExpDate = String.format("%02d/%02d/%02d", monthE, dayE, yearE);

			scrollToElement(eleAuthorizationConsentExpInput);
			setTimeOut(1000);
			inputText(eleAuthorizationConsentExpInput, consentExpDate);
			setTimeOut(2000);
			LoggingInfo("User enters Consent Expiration date");

			// Care Program
			inputText(eleCarePgmInputField, careProgramType);
			setTimeOut(3000);
			click(eleCarePgmSearchField);
			setTimeOut(3000);
			waitAndVerifyElement(eleConsentRecord);
			click(eleConsentRecord);
			setTimeOut(1000);
			click(eleSelectBtn);
			LoggingInfo("User selects Data Use Purpose option from dropdown");
			setTimeOut(2000);

			// Status
			By authorizationStatus = getDynamicElement(strAuthorizationFormStatusValue, "Status");
			scrollToElement(authorizationStatus);
			setTimeOut(1000);

			selectItemFromDropdown(strAuthorizationFormStatusValue, strStatusListValue, "Status", consentStatus);
			LoggingInfo("User selects status option from dropdown");
			setTimeOut(2000);

			// Related Record
			By relatedRec = getDynamicElement(strSearchList, "Related Record");
			scrollToElement(relatedRec);
			setTimeOut(500);
			inputText(eleAuthorizationFormRelatedRecValue, fullName);
			setTimeOut(500);
			selectItemFromDropdown(strSearchList, strRelatedRec, "Related Record", fullName);
			LoggingInfo("User selects related record from the dropdown");
			setTimeOut(2000);

			// Save
			By authorizationFieldSave = getDynamicElement(strAuthorizationieldButtons, "Save");
			waitAndVerifyElement(authorizationFieldSave);
			click(authorizationFieldSave);
			setTimeOut(4000);
			LoggingInfo("User clicks on Save button");
			LoggingInfo("Consents are collected verbally and are linked with patients record");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Authorization page " + e.getMessage());
			Assert.fail("Failed to verify Authorization page " + e.getMessage());
		}
	}

	public void clickOnAccountName(String name) {
		try {
			By record = getDynamicElement(strAccountName, name);
			scrollToElement(record);
			waitAndVerifyElement(record);
			clickByJavascript(record);
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed click on record" + e.getMessage());
			Assert.fail("Failed click on record" + e.getMessage());

		}
	}

	public void verifyConsentIsNotOnFile() {
		try {
			setTimeOut(2000);
			scrollToElement(eleAuthorizationConsentTitle);
			setTimeOut(5000);
			if (verifyObjectPresentOrNot(eleAuthorizationConsentTitle)) {
				LoggingInfo("Consent is not provided by Patient");
			} else {
				LoggingInfo("Consent is provided by Patient");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed click on record" + e.getMessage());
			Assert.fail("Failed click on record" + e.getMessage());

		}
	}

	public void switchTab(String tabTitle, String tabName) {
		try {
			setTimeOut(5000);
			List<WebElement> listOfTabs = tab.findElements(getWebDriver());
			for (WebElement tab : listOfTabs) {
				String name = tab.getText();
				if (name.contains(tabTitle) && name.contains(tabName)) {
					tab.click();
					Log.info("Switched to the required Tab");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed click on tab" + e.getMessage());
			Assert.fail("Failed click on tab" + e.getMessage());
		}

	}

	/**
	 * Function: Verify DUP correspondence code
	 * 
	 * @author Anand Pawar
	 *
	 *         public void verifyStartEndDateCorrespondence(String starDate, String
	 *         enDate) { try {
	 * 
	 *         By startDate = getDynamicElement(eleDate, "Start Date");
	 *         waitAndVerifyElement(startDate); scrollToElement(startDate);
	 *         highLightElement(startDate); String message = getText(startDate);
	 *         Assert.assertEquals(starDate, message, "Start Date matches as
	 *         expected"); LoggingInfo("Start Date is populated as expected");
	 *         setTimeOut(2000);
	 * 
	 *         By endDate = getDynamicElement(eleDate, "JRC/PRB Date");
	 *         waitAndVerifyElement(endDate); scrollToElement(endDate);
	 *         highLightElement(endDate); String eDate = getText(endDate);
	 *         Assert.assertEquals(enDate, eDate, "End Date matches as expected");
	 *         LoggingInfo("End Date is populated as expected"); setTimeOut(2000);
	 * 
	 *         } catch (Exception e) { Log.error("Failed to verify message " +
	 *         e.getMessage()); Assert.fail("Failed to verify message: " +
	 *         e.getMessage()); } }
	 */

	/**
	 * Function: Verify DUP correspondence code
	 * 
	 * @author Anand Pawar
	 *
	 *         public void verifyCorresDUPCode(String code) { try {
	 * 
	 *         By dupCode = By.xpath( "//*[contains(@class,\"active
	 *         lafPageHost\")]//span[text()=\"JRC/PRB
	 *         Code\"]//ancestor::dt//following-sibling::dd//slot//lightning-formatted-text");
	 *         waitAndVerifyElement(dupCode); scrollToElement(dupCode);
	 *         highLightElement(dupCode); String message = getText(dupCode);
	 *         Assert.assertEquals(message, code, "Code matches as expected");
	 *         LoggingInfo("Dupix Code is populated as expected"); setTimeOut(2000);
	 * 
	 *         } catch (Exception e) { Log.error("Failed to verify message " +
	 *         e.getMessage()); Assert.fail("Failed to verify message: " +
	 *         e.getMessage()); } }
	 */

	public void updateDemographicInfo(String firstName, String lastName, String city) throws InterruptedException {
		try {
			By demographicInfoEditButton = getDynamicElement(editButton, "Mailing Address");
			scrollToElement(demographicInfoEditButton);
			click(demographicInfoEditButton);

			By demoInfoFirstName = getDynamicElement(eleDemoGraphicInputFields, "firstName");
			inputText(demoInfoFirstName, firstName);
			setTimeOut(2000);

			By demoInfoLastName = getDynamicElement(eleDemoGraphicInputFields, "lastName");
			inputText(demoInfoLastName, lastName);
			setTimeOut(2000);

			By demoInfoCityName = getDynamicElement(eleDemoGraphicInputFields, "city");
			scrollToElement(demoInfoCityName);
			inputText(demoInfoCityName, city);
			setTimeOut(2000);

			By authorizationFieldSave = getDynamicElement(strAuthorizationieldButtons, "Save");
			waitAndVerifyElement(authorizationFieldSave);
			click(authorizationFieldSave);
			setTimeOut(4000);
			LoggingInfo("Deomgraphic Info for the patient has been saved.");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to update Info" + e.getMessage());
			Assert.fail("Failed to update Info" + e.getMessage());
		}

	}

	/*
	 * @author - Anand Pawar
	 */
	public void updateSiteInfo(String Name, String Phone, String Tax) throws InterruptedException {
		try {
			waitAndVerifyElement(eleEditFaxButton);
			scrollToElement(eleEditFaxButton);
			click(eleEditFaxButton);

			By eleName = getDynamicElement(eleDemoGraphicInputFields, "Name");
			inputText(eleName, Name);
			setTimeOut(2000);

			By elePhone = getDynamicElement(eleDemoGraphicInputFields, "Phone");
			inputText(elePhone, Phone);
			setTimeOut(2000);

			By eleFax = getDynamicElement(eleDemoGraphicInputFields, "Fax");
			scrollToElement(eleFax);
			inputText(eleFax, Phone);
			setTimeOut(2000);

			By eleTax = getDynamicElement(eleDemoGraphicInputFields, "ICC_FacilityTaxID__c");
			scrollToElement(eleTax);
			inputText(eleTax, Tax);
			setTimeOut(2000);

//			By eleSave = getDynamicElement(strAuthorizationieldButtons, "Save");
//			waitAndVerifyElement(eleSave);
//			click(eleSave);
			setTimeOut(4000);
			LoggingInfo("Site Updated Info for the patient has been saved.");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to update Info" + e.getMessage());
			Assert.fail("Failed to update Info" + e.getMessage());
		}

	}

	/*
	 * @author - Anand Pawar
	 */

	public void verifyDCRNotesIsMandatory() {
		try {
			waitAndVerifyElement(eleEditFaxButton);
			scrollToElement(eleEditFaxButton);
			clickByJavascript(eleEditFaxButton);
			setTimeOut(1000);

			By eleDCR = By.xpath("//*[contains(@class,\"active lafPageHost\")]//button[@aria-label=\"DCR Notes\"]");
			waitAndVerifyElement(eleDCR);
			clickByJavascript(eleDCR);
			selectItemFromList(eleDCR, eleDCRDropdownOptions, "--None--", "DCR Notes");

			By eleSave = getDynamicElement(strAuthorizationieldButtons, "Save");
			waitAndVerifyElement(eleSave);
			clickByJavascript(eleSave);
			setTimeOut(4000);

			By error = By.xpath("//h2[text()=\"We hit a snag.\"]");
			waitAndVerifyElement(error);
			highLightElement(error);

			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Service " + e.getMessage());
			Assert.fail("Failed to select Service " + e.getMessage());
		}
	}

	public void navigateToCPERecord() {
		try {
			waitAndVerifyElement(eleFirstRecord);
			clickByJavascript(eleFirstRecord);
			setTimeOut(3000);
			LoggingInfo("Navigation to first record successful");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed click on record" + e.getMessage());
			Assert.fail("Failed click on record" + e.getMessage());

		}
	}

	public void selectService() {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			selectItemFromList(eleSelectDropDown, "Fulfillment");
			LoggingInfo("Selected Service as Fulfillment");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Service " + e.getMessage());
			Assert.fail("Failed to select Service " + e.getMessage());
		}
	}

	public void selectReason() {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			String reason = "Patient requested";
			selectItemFromList(eleSelectDropDown, reason);
			LoggingInfo("Selected Reason as-" + reason);
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Reason " + e.getMessage());
			Assert.fail("Failed to select Reason " + e.getMessage());
		}
	}

	public void validateConfirmationMessage() {
		try {
			waitAndVerifyElement(eleMessage);
			LoggingInfo("Confirmation message verified");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to verify Confirmation message " + e.getMessage());
			Assert.fail("Failed to verify Confirmation message " + e.getMessage());
		}
	}

	public void itemsToSend() {
		try {
			waitForPageLoaded();
			waitAndVerifyElement(eleSelectItemsToSend);
			click(eleSelectItemsToSend);
			selectItemFromList(eleSelectItemsToSend, eleSelectItemsToSendDropdown, "Sharps Kit",
					"Select Items To Send");
			LoggingInfo("verified to select items to send");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to verify select items to send " + e.getMessage());
			Assert.fail("Failed to verify select items to send" + e.getMessage());
		}
	}

	public void verifyRecentlyViewList() {

		try {
			Log.info("Recently View Documents List");
			waitForPageLoaded();
			By allReceiveddocumentList = getDynamicElement(strDocumentPageTitle, "Recently Viewed");
			waitAndVerifyElement(allReceiveddocumentList);
			LoggingInfo("verified to load Recently viewed list");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to load Recently Viewed List" + ". Error - " + e.getMessage());

		}
	}

	public void verifyToClickCurrespondance() {
		try {
			waitForPageLoaded();
			waitAndVerifyElement(eleCorrespondance);
			click(eleCorrespondance);
			setTimeOut(3000);

			By processName = getDynamicElement(strOutcomeDropdown, "Process Name");
			By strProcessNameDropdownList = getDynamicElement(strProcessNameDropList, "Process Name");
			click(processName);
			selectItemFromList(processName, strProcessNameDropdownList, "Med D PAP Re-enrollment", "Process Name");
			setTimeOut(2000);

			LoggingInfo("User enters Process Name");

			setTimeOut(2000);
			By selectItemsToSend = getDynamicElement(strOutcomeDropdown, "Select Items to Send");
			By strSelectItemDropdownList = getDynamicElement(strProcessNameDropList, "Select Items to Send");
			click(selectItemsToSend);
			selectItemFromList(selectItemsToSend, strSelectItemDropdownList,
					"DMW Med D PAP Annual Re-Enrollment - HCP Fax", "Select Items to Send");
			setTimeOut(2000);

			By nextButton = getDynamicElement(elenavigationButton, "Next");
			waitAndVerifyElement(nextButton);
			scrollToElement(nextButton);
			click(nextButton);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select Process Name " + e.getMessage());
			Assert.fail("Failed to select Process Name " + e.getMessage());
		}
	}

	public void PickTemplates() {
		try {

			By checkBox = By.xpath(
					"//span[text()='iCare+ DMW Prescription Transfer Letter']//ancestor::c-data-table-cell//preceding-sibling::c-clm-select-row-cell-extended//span[@class='slds-checkbox_faux']");
			waitAndVerifyElement(checkBox);
			verifyandSelectCheckBox(checkBox, "TRUE", "iCare+ DMW Prescription Transfer Letter");
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Pick Template" + e.getMessage());
			Assert.fail("Failed to Pick Template" + e.getMessage());
		}
	}

	public void selectCPEStatus(String cpeStatus) {
		try {

			By eleCPEUpdateDropdown = getDynamicElement(strCPEUpdateDropdown, "Status");
			selectItemFromList(eleCPEUpdateDropdown, cpeStatus);
			Log.info("Selected CPE status: " + cpeStatus);

			LoggingInfo("Made CPE status as " + cpeStatus);

			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Service " + e.getMessage());
			Assert.fail("Failed to select Service " + e.getMessage());
		}
	}

	public void NavigateBackAndForth() {
		try {

			By PreviousClick = getDynamicElement(elenavigationButton, "Previous");
			scrollToElement(PreviousClick);
			click(PreviousClick);

			setTimeOut(2000);

			By clickNext = getDynamicElement(elenavigationButton, "Next");
			scrollToElement(clickNext);
			click(clickNext);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigated to My Assessment Tasks " + e.getMessage());
			Assert.fail("Failed to navigated to My Assessment Tasks " + e.getMessage());
		}
	}

	public void SendAttachement() {
		try {

			setTimeOut(2000);
			By clickNext = getDynamicElement(elenavigationButton, "Next");
			waitAndVerifyElement(clickNext);
			scrollToElement(clickNext);
			click(clickNext);

			setTimeOut(50000);
			waitAndVerifyElement(eleSendAttchment);
			scrollToElement(eleSendAttchment);
			click(eleSendAttchment);

			setTimeOut(2000);
			By finish = getDynamicElement(elenavigationButton, "Finish");
			waitAndVerifyElement(finish);
			scrollToElement(finish);
			click(finish);

			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to send template " + e.getMessage());
			Assert.fail("Failed to send template " + e.getMessage());
		}
	}

	public void verifyToClickMyAssessmentTasksView() {
		try {
			click(listViewButton);
			waitForPageLoaded();
			// By myAssessmentListView = getDynamicElement(strDocumentPageTitle, "My
			// Assessment Tasks");
			waitAndVerifyElement(myAssessmentListView);
			setTimeOut(2000);
			click(myAssessmentListView);
			waitForPageLoaded();
			LoggingInfo("Navigated to My Assessment Tasks");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigated to My Assessment Tasks " + e.getMessage());
			Assert.fail("Failed to navigated to My Assessment Tasks " + e.getMessage());
		}
	}

	public void clickOnCorrespondenceBotton() {
		try {
			waitAndVerifyElement(eleCorrespondenceBuuton);
			scrollToElement(eleCorrespondenceBuuton);
			click(eleCorrespondenceBuuton);
			LoggingInfo("Clicked on 'Correspondence Button'");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click On Correspondence Button " + e.getMessage());
			Assert.fail("Failed to click On Correspondence Button" + e.getMessage());
		}
	}

	public void selectProcessNameAndItemToSend(String processName, String itemsToSend) {
		try {

			setTimeOut(3000);
			By eleProcessDropdown = getDynamicElement(strDropDownXpath, "Process Name");
			waitAndVerifyElement(eleProcessDropdown);
			click(eleProcessDropdown);
			setTimeOut(1000);
			getWebDriver().findElement(eleProcessTextField).sendKeys(processName);
			setTimeOut(2000);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
			LoggingInfo("Selected Process as " + processName);
			setTimeOut(1000);
			waitAndVerifyElement(eleSelectItemsToSend);
			click(eleSelectItemsToSend);
			selectItemFromList(eleSelectItemsToSend, eleSelectItemsToSendDropdown, itemsToSend, "Select Items To Send");
			LoggingInfo("verified to select items to send");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Process and items to send " + e.getMessage());
			Assert.fail("Failed to select Process and items to send " + e.getMessage());
		}
	}

	public void verifyErrorMessage() {
		try {
			waitAndVerifyElement(eleErrorMessage);
			LoggingInfo("Error message verified");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to verify Error message " + e.getMessage());
			Assert.fail("Failed to verify Errormessage " + e.getMessage());
		}
	}

	public void clickonFinishButton() {
		try {
			Log.info("Verify user is able to click on finish button");
			waitAndVerifyElement(eleFinishButton);
			scrollToElement(eleFinishButton);
			clickByJavascript(eleFinishButton);
			setTimeOut(2000);
			LoggingInfo("User clicks on Finish button");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Finish Button " + e.getMessage());
			Assert.fail("Failed to click on Finish Button " + e.getMessage());
		}
	}

	public void verifyToclearFax() {
		try {
			Log.info("Verify user is able to edit and update Fax");
			waitAndVerifyElement(eleSite);
			scrollToElement(eleSite);
			clickByJavascript(eleSite);
			setTimeOut(2000);
			waitAndVerifyElement(eleEditFax);
			scrollToElement(eleEditFax);
			click(eleEditFax);
			setTimeOut(2000);
			getWebDriver().findElement(eleFaxInput).clear();
			LoggingInfo("User edit and update Fax successfully");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to update Fax" + e.getMessage());
			Assert.fail("Failed to update Fax " + e.getMessage());
		}
	}

	public void verifyFaxCorrespondenceRecord() {
		try {
			setTimeOut(2000);
			By faxRecord = By.xpath(
					"(//*[contains(@class, 'active lafPageHost')]//table[@aria-label='Correspondences']//tbody//tr)[1]//th");
			waitAndVerifyElement(faxRecord);
			clickByJavascript(faxRecord);

		} catch (Exception e) {
			Log.error("Failed to verify correspondence record " + e.getMessage());
			Assert.fail("Failed to verify correspondence record: " + e.getMessage());
		}
	}

	// Anand P
	public void editDOB() {

		try {
			waitForPageLoaded();
			String streetAddress = "5/4/1998";
			By eleDOB = getDynamicElement(strInputText, "PersonBirthdate");
			waitAndVerifyElement(eleDOB);
			scrollToElement(eleDOB);
			setTimeOut(2000);
			clearInputFieldText(eleDOB);
			inputText(eleDOB, streetAddress);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Anand P
	public void editGender() {
		try {
			By eleGender = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@aria-label=\"Gender\"]");
			click(eleGender);
			setTimeOut(2000);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
			setTimeOut(2000);
			LoggingInfo("User is able to edit gender");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void editCopdCode() {
		try {
			By elecopd = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Eosinophil Count Populated\"]//parent::div//following-sibling::div//button");
			click(elecopd);
			setTimeOut(1000);
			click(eleCOPD);
			setTimeOut(2000);
			LoggingInfo("User is able to edit COPD");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Anand P
	public void clickEditMedication() {
		try {
			By med = getDynamicElement(editButton, "Edit Medication");
			waitAndVerifyElement(med);
			scrollToElement(med);
			click(med);
			setTimeOut(2000);

			LoggingInfo("User is able to edit medication");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void editInsurancePhone() {
		try {
			By med = getDynamicElement(editButton, "Edit Insurance Phone");
			waitAndVerifyElement(med);
			scrollToElement(med);
			click(med);
			setTimeOut(2000);

			By phoneInputBox = getDynamicElement(accountInputBox, "Insurance Phone");
			waitAndVerifyElement(phoneInputBox);
			scrollToElement(phoneInputBox);
			String number = generatePhoneNumber();
			clearInputFieldText(phoneInputBox);
			sendKeysWithActionClass(phoneInputBox, number);
			setTimeOut(2000);

			LoggingInfo("User is able to edit Insurance Phone Number");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Anand P
	public void editGroupNumberRxPCN() {
		try {
			By med = getDynamicElement(editButton, "Edit Group Number");
			waitAndVerifyElement(med);
			scrollToElement(med);
			click(med);
			setTimeOut(2000);

			String groupNumber = "17168";
			By refill = getDynamicElement(accountInputBox, "Group Number");
			waitAndVerifyElement(refill);
			scrollToElement(refill);
			inputText(refill, groupNumber);
			LoggingInfo("User is able to editGroupNumber");

			String rxPCN = "1561768790";
			By pcn = getDynamicElement(accountInputBox, "Rx PCN");
			waitAndVerifyElement(pcn);
			inputText(pcn, rxPCN);

			String policyholderDate = "12/31/2025";
			By policyHolderDOB = getDynamicElement(strInsAddDate, "PolicyholderDOB_ICC__c");
			waitAndVerifyElement(policyHolderDOB);
			click(policyHolderDOB);
			setTimeOut(1000);
			inputText(policyHolderDOB, policyholderDate);
			setTimeOut(2000);

			String insAddDate = "12/31/2025";
			By insuranceAddDate = getDynamicElement(strInsAddDate, "InsuranceAddDate_ICC__c");
			waitAndVerifyElement(insuranceAddDate);
			scrollToElement(insuranceAddDate);
			click(insuranceAddDate);
			setTimeOut(1000);
			inputText(insuranceAddDate, insAddDate);
			LoggingInfo("User is able to edit Insurance Add Date");
			setTimeOut(2000);

			String planId = "373883";
			By planID = getDynamicElement(strInsAddDate, "PlanID_ICC__c");
			waitAndVerifyElement(planID);
			scrollToElement(planID);
			setTimeOut(1000);
			click(planID);
			setTimeOut(1000);
			inputText(planID, planId);
			setTimeOut(2000);
			LoggingInfo("User is able to edit plan ID");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void clickEditConditionCode() {
		try {
			By med = getDynamicElement(editButton, "Edit Condition Code");
			waitAndVerifyElement(med);
			scrollToElement(med);
			click(med);
			setTimeOut(2000);

			LoggingInfo("User is able to edit medication");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Anand P
	public void verifyToFillMailingAddress() {
		try {
			setTimeOut(4000);
			Log.info("Verify user is able to edit and update mailing address");
			waitAndVerifyElement(eleMailingAddress);
			scrollToElement(eleMailingAddress);
			setTimeOut(2000);
			clickByJavascript(eleMailingAddress);
			setTimeOut(2000);

			waitAndVerifyElement(eleMailingCountry);
			click(eleMailingCountry);
			setTimeOut(2000);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
			setTimeOut(2000);
			LoggingInfo("User is able to edit and update mailing country successfully");

			String streetAddress = "2225 Front road";
			By eleStreet = getDynamicElement(strTextArea, "street");
			waitAndVerifyElement(eleStreet);
			scrollToElement(eleStreet);
			setTimeOut(2000);
			inputText(eleStreet, streetAddress);
			LoggingInfo("User is able to  edit and update mailing street successfully");
			setTimeOut(2000);

			String cityName = "San Diego";
			By eleCity = getDynamicElement(strInputText, "city");
			waitAndVerifyElement(eleCity);
			scrollToElement(eleCity);
			setTimeOut(2000);
			inputText(eleCity, cityName);
			LoggingInfo("User is able to edit and update mailing city successfully");
			setTimeOut(2000);

			String zipCode = "17187";
			By elePostalCode = getDynamicElement(strInputText, "postalCode");
			waitAndVerifyElement(elePostalCode);
			scrollToElement(elePostalCode);
			setTimeOut(2000);
			inputText(elePostalCode, zipCode);
			LoggingInfo("User is able to edit and updated postal code successfully");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to update mailing address" + e.getMessage());
			Assert.fail("Failed to update mailing address " + e.getMessage());
		}
	}

	// Anand P
	public void editFax(String patientFax) {

		int faxNo = 1265161780;
		// int Fax = Integer.valueOf(faxNo);

		try {

			Log.info("Verify user is able to edit and update Fax");
			waitAndVerifyElement(eleSite);
			scrollToElement(eleSite);
			clickByJavascript(eleSite);
			setTimeOut(2000);
			// waitAndVerifyElement(eleEditFax);
			// scrollToElement(eleEditFax);

			waitAndVerifyElement(eleEditFaxButton);
			scrollToElement(eleEditFaxButton);
			click(eleEditFaxButton);

			// click(eleEditFax);
			click(eleFaxField);
			clearText(eleFaxInput);
			setTimeOut(2000);
			// inputText(eleFaxInput, faxNo);
			//

			// getWebDriver().findElement(eleFaxInput).sendKeys(""+faxNo);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.NUMPAD3).sendKeys(Keys.NUMPAD4).sendKeys(Keys.NUMPAD5).sendKeys(Keys.NUMPAD8)
					.sendKeys(Keys.NUMPAD0).sendKeys(Keys.NUMPAD6).sendKeys(Keys.NUMPAD5).sendKeys(Keys.NUMPAD2)
					.sendKeys(Keys.NUMPAD1).sendKeys(Keys.NUMPAD0).build().perform();

			LoggingInfo("User edit and update Fax successfully");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit fax id " + e.getMessage());
			Assert.fail("Failed to edit fax id " + e.getMessage());
		}
	}

	public void verifyToEditFax() {
		try {
			Log.info("Verify user is able to edit and update Fax");
			waitAndVerifyElement(eleSite);
			scrollToElement(eleSite);
			clickByJavascript(eleSite);
			setTimeOut(2000);

			waitAndVerifyElement(eleEditFax);
			scrollToElement(eleEditFax);
			click(eleEditFax);
			setTimeOut(2000);
			getWebDriver().findElement(eleFaxInput).clear();
			getWebDriver().findElement(eleFaxInput).sendKeys("6151678899");
			LoggingInfo("User edit and update Fax successfully");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to update Fax" + e.getMessage());
			Assert.fail("Failed to update Fax " + e.getMessage());
		}
	}

	public void verifyGenerateDocumentScreen() {
		try {
			Log.info("Verify Generate Document Screen");
			setTimeOut(9000);
			waitAndVerifyElement(eleDocName);
			setTimeOut(9000);
			LoggingInfo("User verify Generate Document Screen successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Generate Document Screen " + e.getMessage());
			Assert.fail("Failed to verify Generate Document Screen  " + e.getMessage());
		}
	}

	public void clickSendButton() {
		try {
			Log.info("Verify user is able to click on Send button");
			setTimeOut(9000);
			scrollToBottomOfPage();
			scrollToElement(eleSendButton);
			waitAndVerifyElement(eleSendButton);
			setTimeOut(9000);
			click(eleSendButton);
			LoggingInfo("User clicks on Send button");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Send Button " + e.getMessage());
			Assert.fail("Failed to click on Send Button " + e.getMessage());
		}
	}

	public void verifySuccessMessage() {
		try {
			waitAndVerifyElement(eleSuccessMessage);
			setTimeOut(2000);
			LoggingInfo("User verifies success message");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify success message " + e.getMessage());
			Assert.fail("Failed to verify success message " + e.getMessage());
		}
	}

	public void verifyNextAndSaveLaterButtonIsHidden() {
		try {
			if (verifyButtonIsNotDisplayed("Save for later")) {
				Log.info("Save Later button is hidden");
			}
			if (verifyButtonIsNotDisplayed("Next")) {
				Log.info("Next button is hidden");
			}

			LoggingInfo("Next and Save For Later Buttons are hidden/removed from UI");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify if  Buttons are displayed" + e.getMessage());
			Assert.fail("Failed to verify if  Buttons are displayed " + e.getMessage());
		}

	}

	/**
	 * Function: Verify Next and save for later button
	 * 
	 * @author Sonica P
	 **/
	public void verifyNextAndSaveForLaterButtonIsNotHidden() {
		try {
			By eleNextButton = getDynamicElement(strNextButtons, "Next");
			scrollToElement(eleNextButton);
			waitAndVerifyElement(eleNextButton);
			LoggingInfo(
					"Verifies Next button is present since the system directly links CPE record when existing patient is selected");

			By eleSaveForLaterButton = getDynamicElement(strNextButtons, "Save for later");
			scrollToElement(eleSaveForLaterButton);
			waitAndVerifyElement(eleSaveForLaterButton);
			LoggingInfo(
					"Verifies Save for later button is present since the system directly links CPE record when existing patient is selected");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify if Buttons are displayed" + e.getMessage());
			Assert.fail("Failed to verify if Buttons are displayed " + e.getMessage());
		}
	}

	public void verifySuccessMessageForPT() {
		try {
			waitAndVerifyElement(eleSuccessMessageForPT);
			setTimeOut(2000);
			LoggingInfo("User verifies success message");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify success message " + e.getMessage());
			Assert.fail("Failed to verify success message " + e.getMessage());
		}
	}

	public void verifyToClearMailingAddress() {
		try {
			setTimeOut(4000);
			Log.info("Verify user is able to edit and update mailing address");
			waitAndVerifyElement(eleMailingAddress);
			scrollToElement(eleMailingAddress);
			setTimeOut(2000);
			clickByJavascript(eleMailingAddress);
			setTimeOut(2000);

			waitAndVerifyElement(eleMailingCountry);
			click(eleMailingCountry);
			setTimeOut(2000);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
			setTimeOut(2000);
			LoggingInfo("User is able to edit and update mailing country successfully");

			By eleStreet = getDynamicElement(strTextArea, "street");
			waitAndVerifyElement(eleStreet);
			scrollToElement(eleStreet);
			click(eleStreet);
			setTimeOut(2000);
			getWebDriver().findElement(eleStreet).clear();
			LoggingInfo("User ks able to  edit and update mailing street successfully");
			setTimeOut(2000);

			By eleCity = getDynamicElement(strInputText, "city");
			waitAndVerifyElement(eleCity);
			scrollToElement(eleCity);
			click(eleCity);
			setTimeOut(2000);
			getWebDriver().findElement(eleCity).clear();
			LoggingInfo("User is able to edit and update mailing city successfully");
			setTimeOut(2000);

			By elePostalCode = getDynamicElement(strInputText, "postalCode");
			waitAndVerifyElement(elePostalCode);
			scrollToElement(elePostalCode);
			click(elePostalCode);
			setTimeOut(2000);
			getWebDriver().findElement(elePostalCode).clear();
			LoggingInfo("User is able to edit and updated postal code successfully");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to update mailing address" + e.getMessage());
			Assert.fail("Failed to update mailing address " + e.getMessage());
		}
	}

	public void verifyErrorMessageForPT() {
		try {
			waitAndVerifyElement(eleErrorMessageForPT);
			LoggingInfo("Error message verified");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to verify Error message " + e.getMessage());
			Assert.fail("Failed to verify Errormessage " + e.getMessage());
		}
	}

	public void validateResponseMessage() {
		try {
			scrollToElement(eleCOR);
			waitAndVerifyElement(eleCOR);
			clickByJavascript(eleCOR);
			setTimeOut(2000);
			scrollToElement(eleResponseMessage);
			waitAndVerifyElement(eleResponseMessage);
			String Response = getAttributeValue(eleResponseMessage, "value");
			if (Response.contains("Success")) {
				LoggingInfo("Response message verified");
				setTimeOut(1000);
			} else {
				LoggingInfo("Failed to verify response message");
				setTimeOut(1000);
			}
		} catch (Exception e) {
			Log.error("Failed to verify response message " + e.getMessage());
			Assert.fail("Failed to verify response message " + e.getMessage());
		}
	}

	/**
	 * Function: Select process name
	 * 
	 * @author Trupti Zure
	 **/
	public void selectProcessName(String processName) {
		try {

			waitForPageLoaded();
			// Process Name
			By processNameDropdown = getDynamicElement(strDropDownInputBox, "Process Name");
			waitAndVerifyElement(processNameDropdown);
			click(processNameDropdown);
			By processNameDropdownOptions = getDynamicElement(strDropDownOptions, "Process Name");
			waitAndVerifyElement(processNameDropdownOptions);
			selectItemFromList(processNameDropdown, processNameDropdownOptions, processName, "Process Name");
			setTimeOut(1000);
			LoggingInfo("Selected process Name as-" + processName);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select process name " + e.getMessage());
			Assert.fail("Failed to select process name " + e.getMessage());
		}
	}

	/**
	 * Function: select QS option form items to send not present
	 * 
	 * @author Anand Pawar
	 **/
	public void validateQSOptionNotPresent() {
		try {
			// Select Items to Send
			By selectItemsToSendDropdown = getDynamicElement(strDropDownInputBox, "Select Items to Send");
			waitAndVerifyElement(selectItemsToSendDropdown);
			scrollToElement(selectItemsToSendDropdown);
			click(selectItemsToSendDropdown);

			By selectItemsToSendDropdownOptions = getDynamicElement(searchDropDownOptions, "Select Items to Send");
			List<WebElement> options = getWebDriver().findElements(selectItemsToSendDropdownOptions);

			boolean isOptionANotPresent = true;
			boolean isOptionBNotPresent = true;

			for (WebElement option : options) {
				if (option.getText().equals("DMW Quick Start Program Eligibility Reminder (First Notice) HCP Fax")) {
					isOptionANotPresent = false;
					break;
				}
				if (option.getText().equals("DMW Quick Start Program Eligibility Reminder (Final Notice) HCP Fax")) {
					isOptionBNotPresent = false;
					break;

				}
				if (!isOptionANotPresent && !isOptionBNotPresent) {
					break;
				}
			}

			if (isOptionANotPresent && isOptionBNotPresent) {
				LoggingInfo("Both options not present as expected in the dropdown.");
			}

		} catch (Exception e) {

		}
	}

	/**
	 * Function: select option form items to send
	 * 
	 * @author Trupti Zure
	 **/
	public void selectItemsToSend(String selectItem) {
		try {
			// Select Items to Send
			// refresh();
			setTimeOut(4000);
			By selectItemsToSendDropdown = getDynamicElement(strDropDownSelectItemsToSend, "Select Items to Send");
			waitAndVerifyElement(selectItemsToSendDropdown);
			scrollToElement(selectItemsToSendDropdown);
			click(selectItemsToSendDropdown);
			By selectItemsToSendDropdownOptions = getDynamicElement(searchDropDownOptions, "Select Items to Send");
			waitAndVerifyElement(selectItemsToSendDropdownOptions);
			selectItemFromList(selectItemsToSendDropdown, selectItemsToSendDropdownOptions, selectItem,
					"Select Items to Send");
			setTimeOut(1000);
			LoggingInfo("Selected Items To Send as-" + selectItem);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select Items To Send " + e.getMessage());
			Assert.fail("Failed to select Items To Send " + e.getMessage());
		}
	}

	/**
	 * Function: Validate error message
	 * 
	 * @author Trupti Zure
	 **/
	public void validateErrorMessage(String expectedErrorMsg) {
		try {
			waitAndVerifyElement(eleErrorMSG);
			String actualErrorMsg = getText(eleErrorMSG);
			Assert.assertEquals(actualErrorMsg, expectedErrorMsg,
					"Error message mismatch. Expected: '" + expectedErrorMsg + "', but got: '" + actualErrorMsg + "'");
			LoggingInfo("Error message validated successfully");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate error message " + e.getMessage());
			Assert.fail("Failed to validate error message " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to account
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToAccount() {
		try {
			waitAndVerifyElement(eleAccountName);
			scrollToElement(eleAccountName);
			click(eleAccountName);
			LoggingInfo("Navigated to account");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to account " + e.getMessage());
			Assert.fail("Failed to navigate to account " + e.getMessage());
		}
	}

	public void editEmail2(String accountName) {
		try {

			By emailInputBox = getDynamicElement(accountInputBox, "Email");
			waitAndVerifyElement(emailInputBox);
			String email = accountName + "@autotest.com";
			inputText(emailInputBox, email);

			LoggingInfo("Entered email: " + email);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit email id " + e.getMessage());
			Assert.fail("Failed to edit email id " + e.getMessage());
		}
	}

	public void editRefillQty() {
		try {
			String qty = "10";

			By refill = getDynamicElement(accountInputBox, "Refill Quantity");
			waitAndVerifyElement(refill);
			inputText(refill, qty);
			LoggingInfo("Entered refill Qty: " + qty);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit refill qty " + e.getMessage());
			Assert.fail("Failed to edit refill qty" + e.getMessage());
		}
	}

	public void editOnsetPeriodDate() {
		try {
			String date = Utility_Function.getNthPastDayFromToday(7);
			By refill = getDynamicElement(accountInputBox, "Date");
			waitAndVerifyElement(refill);
			inputText(refill, date);

			LoggingInfo("Entered Onset Period date: " + date);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit refill qty " + e.getMessage());
			Assert.fail("Failed to edit refill qty" + e.getMessage());
		}
	}

	/**
	 * Function: Edit email on account section
	 * 
	 * @author Trupti Zure
	 **/
	public void editEmail(String accountName) {
		try {

			By emailEdit = getDynamicElement(editButton, "Edit Email");
			waitAndVerifyElement(emailEdit);
			scrollToElement(emailEdit);
			setTimeOut(2000);
			click(emailEdit);
//
//			By otherphone = getDynamicElement(editButton, "Other Phone");
//
//			scrollToElement(otherphone);
//
//			click(otherphone);

			By emailInputBox = getDynamicElement(accountInputBox, "Email");
			waitAndVerifyElement(emailInputBox);
			String email = accountName + "@autotest.com";
			inputText(emailInputBox, email);

			LoggingInfo("Entered email: " + email);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit email id " + e.getMessage());
			Assert.fail("Failed to edit email id " + e.getMessage());
		}
	}

	/**
	 * Function: Clear existing email id
	 * 
	 * @author Trupti Zure
	 **/
	public void clearEmail() {
		try {

			By emailEdit = getDynamicElement(editButton, "Edit Email");
			waitAndVerifyElement(emailEdit);
			scrollToElement(emailEdit);
			setTimeOut(2000);
			click(emailEdit);

			By emailInputBox = getDynamicElement(accountInputBox, "Email");
			waitAndVerifyElement(emailInputBox);
			clearText(emailInputBox);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit email id " + e.getMessage());
			Assert.fail("Failed to edit email id " + e.getMessage());
		}
	}

	/**
	 * Function: Validate success message
	 * 
	 * @author Trupti Zure
	 **/
	public String validateSuccessMessage() {
		String actualMsg = null;
		try {
			waitAndVerifyElement(successMessage);
			actualMsg = getText(successMessage);
			LoggingInfo("");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Success message " + e.getMessage());
			Assert.fail("Failed to validate Success message " + e.getMessage());
		}
		return actualMsg;
	}

	/**
	 * Function: Navigate to correspondence table
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToCorrespondenceTable() {
		try {
			scrollToElement(eleCorrespondencesTable);
			waitAndVerifyElement(eleCorrespondencesTable);
			scrollToElement(eleCorrespondencesTable);
			LoggingInfo("Navigated to correspondence table");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Navigated to correspondence table " + e.getMessage());
			Assert.fail("Navigated to correspondence table " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Correspondences record
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyCorrespondenceRecord(String serviceArea) {
		try {
			String sortingState;
			do {
				sortingState = getText(correspondenceSortingState);
				if (!sortingState.equalsIgnoreCase("Sorted Descending")) {
					clickByJavascript(correspondenceSortingColumn);
					setTimeOut(1000);
				}
				sortingState = getText(correspondenceSortingState);
			} while (!sortingState.equalsIgnoreCase("Sorted Descending"));

			if (verifytable("Correspondences")) {
				setTimeOut(2000);
				List<WebElement> rows = getWebDriver().findElements(By.xpath(
						"//*[contains(@class, 'active lafPageHost')]//table[@aria-label='Correspondences']//tbody//tr"));

				List<WebElement> serviceRows = new ArrayList<>();
				for (WebElement row : rows) {
					String correspondenceType = row
							.findElement(By.xpath(".//td[@data-label='Service Area']//span//lst-formatted-text"))
							.getText();
					if (serviceArea.equals(correspondenceType)) {
						serviceRows.add(row);
					}
				}

				boolean serviceAreaFound = false;

				if (!serviceRows.isEmpty()) {
					for (int i = 0; i < serviceRows.size(); i++) {
						String correspondenceType = serviceRows.get(i)
								.findElement(By.xpath(".//td[@data-label='Service Area']//span//lst-formatted-text"))
								.getText();
					}

					WebElement latestRecord = serviceRows.get(serviceRows.size() - 1);
					String actualServiceArea = latestRecord
							.findElement(By.xpath(".//td[@data-label='Service Area']//span//lst-formatted-text"))
							.getText().trim();
					Assert.assertEquals(actualServiceArea, serviceArea, "Record not found in correspondence table");
					serviceAreaFound = true;
					LoggingInfo("'Correspondence' record verified-" + serviceArea);
				} else {
					Log.error("No Correspondence records found for " + serviceArea);
				}

				Assert.assertTrue(serviceAreaFound,
						"Service Area '" + serviceArea + "' not found in the Correspondences table.");
				LoggingInfo("Verification completed for service Area " + serviceArea);
				setTimeOut(2000);
			}
		} catch (Exception e) {
			Log.error("Failed to verify correspondence record: " + e.getMessage());
			Assert.fail("Failed to verify correspondence record: " + e.getMessage());
		}
	}

	/**
	 * Function: Click Correspondences record
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnCorrespondenceRecord(String serviceArea) {
		try {
			String sortingState;
			do {
				sortingState = getText(correspondenceSortingState);
				if (!sortingState.equalsIgnoreCase("Sorted Descending")) {
					scrollToElement(correspondenceSortingColumn);
					clickByJavascript(correspondenceSortingColumn);
					setTimeOut(1000);
				}
				sortingState = getText(correspondenceSortingState);
			} while (!sortingState.equalsIgnoreCase("Sorted Descending"));

			if (verifytable("Correspondences")) {

				List<WebElement> rows = getWebDriver().findElements(By.xpath(
						"//*[contains(@class, 'active lafPageHost')]//table[@aria-label='Correspondences']//tbody//tr"));

				List<WebElement> serviceRows = new ArrayList<>();
				for (WebElement row : rows) {
					String correspondenceType = row
							.findElement(By.xpath(".//td[@data-label='Service Area']//span//lst-formatted-text"))
							.getText();
					if (serviceArea.equals(correspondenceType)) {
						serviceRows.add(row);
					}
				}

				if (!serviceRows.isEmpty()) {
					WebElement targetRecord = null;

					targetRecord = serviceRows.get(0);

					WebElement link = targetRecord.findElement(By.xpath(".//div[contains(@class,'slds-grid')]//a"));

					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", link);

					LoggingInfo(
							"Clicked on the first created 'Correspondence' record for service area: " + serviceArea);
				} else {
					Log.error("No Correspondence records found for service area: " + serviceArea);
				}

				LoggingInfo("Successfully clicked on the correspondence record for service area: " + serviceArea);
				setTimeOut(2000);
			}
		} catch (Exception e) {
			Log.error("Failed to click on correspondence record: " + e.getMessage());
			Assert.fail("Failed to click on correspondence record: " + e.getMessage());
		}
	}

	/**
	 * Function: Verify message is populated
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyMessageIsPopulated() {
		try {

			By messageInputField = getDynamicElement(correspondenceInputField, "Message");
			scrollToElement(messageInputField);
			String message = getWebDriver().findElement(messageInputField).getText();
			Assert.assertTrue(message == null || message.isEmpty(), "The message field is empty or null.");
			LoggingInfo("The message field is populated");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to verify message " + e.getMessage());
			Assert.fail("Failed to verify message: " + e.getMessage());
		}
	}

	/**
	 * Function: Verify DUP correspondence code
	 * 
	 * @author Anand Pawar
	 **/
	public void verifyDUPCode(String code) {
		try {

			By dupCode = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//span[text()=\"Correspondence Code\"]//parent::div//following-sibling::div//slot//lightning-formatted-text");
			waitAndVerifyElement(dupCode);
			scrollToElement(dupCode);
			highLightElement(dupCode);
			String message = getText(dupCode);
			Assert.assertEquals(message, code, "Code matches as expected");
			LoggingInfo("Dupix Code is populated as expected");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to verify message " + e.getMessage());
			Assert.fail("Failed to verify message: " + e.getMessage());
		}
	}

	/**
	 * Function: Verify DUP correspondence code
	 * 
	 * @author Anand Pawar
	 **/
	public void verifyCorresDUPCode(String code) {
		try {

			By dupCode = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//span[text()=\"JRC/PRB Code\"]//ancestor::records-record-layout-item//lightning-formatted-text");
			waitAndVerifyElement(dupCode);
			scrollToElement(dupCode);
			highLightElement(dupCode);
			String message = getText(dupCode);
			Assert.assertEquals(message, code, "Code matches as expected");
			LoggingInfo("Dupix Code is populated as expected");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to verify message " + e.getMessage());
			Assert.fail("Failed to verify message: " + e.getMessage());
		}
	}

	/**
	 * Function: Verify DUP correspondence code
	 * 
	 * @author Anand Pawar
	 **/
	public void verifyStartEndDateCorrespondence(String starDate, String enDate) {
		try {

			By startDate = getDynamicElement(eleDate, "Start Date");
			waitAndVerifyElement(startDate);
			scrollToElement(startDate);
			highLightElement(startDate);
			String message = getText(startDate);
			Assert.assertEquals(starDate, message, "Start Date matches as expected");
			LoggingInfo("Start Date is populated as expected");
			setTimeOut(2000);

			By endDate = getDynamicElement(eleDate, "JRC/PRB Date");
			waitAndVerifyElement(endDate);
			scrollToElement(endDate);
			highLightElement(endDate);
			String eDate = getText(endDate);
			Assert.assertEquals(enDate, eDate, "End Date matches as expected");
			LoggingInfo("End Date is populated as expected");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to verify message " + e.getMessage());
			Assert.fail("Failed to verify message: " + e.getMessage());
		}
	}

	public void verifyInvalidDoc() {
		try {
			setTimeOut(2000);
			clickByJavascript(docfield);
			Log.info("Verify Invald document on picklist values");
			setTimeOut(3000);
			scrollToElement(docType);
			waitAndVerifyElement(docType);
			if (verifyObjectPresentOrNot(docType)) {
				Log.info("Invalid Document is present in Picklist values");
			}
			LoggingInfo("User is able to see Invalid document type in picklist values");
			refresh();
			setTimeOut(3000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Invalid Document from picklist values" + e.getMessage());
			Assert.fail("Failed to validate Invalid Document from picklist values" + e.getMessage());
		}

	}

	/**
	 * Function: Verify OwnerName on child document page
	 * 
	 * @author Shanavaz Nishani
	 */
	public void verifyOwnerName() throws InterruptedException {
		try {
			scrollToElement(eleOwnerNameField);
			String ownerName = eleOwnerNameField.findElement(getWebDriver()).getAttribute("innerText");
			if (ownerName.contains("PSQA Review Worklist")) {
				LoggingInfo("Owner name is assigned to PSQA Review Worklist");
				Log.info("Owner name is assigned to PSQA Review Worklist");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Owner Name" + e.getMessage());
			Assert.fail("Failed to validate Owner Name" + e.getMessage());
		}
	}

	public void validateError() {
		try {
			waitAndVerifyElement(eleError);
			LoggingInfo("Error message verified");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to verify Error message " + e.getMessage());
			Assert.fail("Failed to verify Error message " + e.getMessage());
		}
	}

	public void clickOnCPERecord(String docID) {

		try {

			setTimeOut(2000);
			waitAndVerifyElement(eleFirstCPERecord);
			click(eleFirstCPERecord);
			setTimeOut(2000);
			LoggingInfo("Successfully clicked on CPE Record");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on CPE Record " + e.getMessage());
			Assert.fail("Failed to click on CPE Record  " + e.getMessage());
		}

	}

	public void switchtoRecievedDocuments() {
		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleRDTab);
			clickByJavascript(eleRDTab);
			setTimeOut(2000);
			LoggingInfo("User switched to Received document successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to switch to Received document" + e.getMessage());
			Assert.fail("Failed to switch to Received document " + e.getMessage());
		}
	}

	public void verifyDocDetailsPage(String fileName) {
		try {
			Log.info("Verify details page");
			setTimeOut(7000);
			waitForPageLoaded();
			String windowTitle = getWindowTitle();
			Log.info("Verify user is navigated to details page");
			if (windowTitle.contains(fileName))
				Assert.assertTrue(true, "Navigated to details Page of the ‘Received Documents’.");
			else
				Assert.fail("Failed to naviage to details page");

			Log.info("Verify received document record");
			By parentRecordTitle = getDynamicElement(strDetailsPageDocTitle, fileName);
			waitAndVerifyElement(parentRecordTitle);
			verifyDetails(parentRecordTitle, fileName, "Document title");
			setTimeOut(3000);
			waitAndVerifyElement(eleOwnerName);
			setTimeOut(2000);
			Log.info("Verified owner Name");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify details of document page and owner name " + e.getMessage());
			Assert.fail("Failed to verify details of document page and owner name" + e.getMessage());
		}
	}

	/**
	 * Function: Edit phone details of patient account
	 * 
	 * @author Trupti Zure
	 **/
	public void editPhone() {
		try {
			By phoneInputBox = getDynamicElement(accountInputBox, "Phone");
			waitAndVerifyElement(phoneInputBox);
			scrollToElement(phoneInputBox);
			clearInputFieldText(phoneInputBox);
			String number = generatePhoneNumber();
			sendKeysWithActionClass(phoneInputBox, number);

			By otherphoneInputBox = getDynamicElement(accountInputBox, "Other Phone");
			waitAndVerifyElement(otherphoneInputBox);
			scrollToElement(otherphoneInputBox);
			clearInputFieldText(otherphoneInputBox);
			String othernumber = generatePhoneNumber();
			sendKeysWithActionClass(otherphoneInputBox, othernumber);

			LoggingInfo("Entered phone and othe phone: " + number);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit phone" + e.getMessage());
			Assert.fail("Failed to edit phone" + e.getMessage());
		}
	}

	/**
	 * Function: Validate document details
	 * 
	 * @author Trupti Zure
	 **/
	public void validateDocumentDetails(String documentID) {
		try {

			// Status
			By statusField = getDynamicElement(correspondenceInputField, "Status");
			waitAndVerifyElement(statusField);
			scrollToElement(statusField);
			String actualStatus = getText(statusField);
			Assert.assertTrue(actualStatus.equals("Draft") || actualStatus.equals("Need Review"),
					"Status is not 'Draft' or 'Need Review'. Current status: " + actualStatus);

			// Document ID
			By documentIDField = getDynamicElement(correspondenceInputField, "Document #");
			waitAndVerifyElement(documentIDField);
			scrollToElement(documentIDField);
			String actualid = getText(documentIDField);
			Assert.assertEquals(documentID, actualid,
					"Document id missmatch. Expected: '" + documentID + "', but got: '" + actualid + "'");

			// Source channel
			By sourceChannelField = getDynamicElement(correspondenceInputField, "Source Channel");
			waitAndVerifyElement(sourceChannelField);
			scrollToElement(sourceChannelField);
			String actualChannel = getText(sourceChannelField);
			Assert.assertEquals("Web", actualChannel,
					"Source channel missmatch. Expected: '" + "Web" + "', but got: '" + actualChannel + "'");

			// Source
			By sourceField = getDynamicElement(correspondenceInputField, "Source");
			waitAndVerifyElement(sourceField);
			scrollToElement(sourceField);
			String sourceChannel = getText(sourceField);
			Assert.assertEquals("DupixentMyWay Portal", sourceChannel,
					"Source missmatch. Expected: '" + "DupixentMyWay Portal" + "', but got: '" + sourceChannel + "'");

			// Disable Auto OCR
			waitAndVerifyElement(disableAutoOCRCHKBox);
			scrollToElement(disableAutoOCRCHKBox);
			String checkBoxValue = getAttributeValue(disableAutoOCRCHKBox, "checked");
			Assert.assertEquals("true", checkBoxValue,
					"Disable Auto OCR. Expected: '" + "true" + "', but got: '" + checkBoxValue + "'");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate document details " + e.getMessage());
			Assert.fail("Failed to validate document details " + e.getMessage());
		}
	}

	/**
	 * Function: Verify owner name of document
	 * 
	 * @author Trupti Zure
	 **/
	public void validateOwnerName() {
		try {
			// Owner name
			waitAndVerifyElement(eleOwnerName);
			waitForvisiblityOfElementLocated(eleOwnerName);
			String ownerName = getText(eleOwnerName);
			Assert.assertEquals("PSQA Review Worklist", ownerName,
					"Owner missmatch. Expected: '" + "PSQA Review Worklist" + "', but got: '" + ownerName + "'");
			LoggingInfo("Owner Name is assigned to PSQA Review Worklist ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate owner name " + e.getMessage());
			Assert.fail("Failed to validate owner name " + e.getMessage());
		}
	}

	/**
	 * Function: Click on received document id tab
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnReceivedDocument() {
		try {
			waitAndVerifyElement(receivedDocTab);
			clickByJavascript(receivedDocTab);
			LoggingInfo("Clicked on received docuement tab");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on received docuement tab " + e.getMessage());
			Assert.fail("Failed to click on received docuement tab " + e.getMessage());
		}
	}

	/**
	 * Function: Verify case manger details
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyCaseManagerDetails(String expectedCaseManager) {
		try {
			By cmEdit = getDynamicElement(editButton, "Edit Case Manager");
			scrollToElement(cmEdit);
			setTimeOut(2000);
			click(cmEdit);

			By caseManagerInputField = getDynamicElement(eleDetailsPageLinkEditFields, "Case Manager");
			waitAndVerifyElement(caseManagerInputField);
			String caseManager = getAttributeValue(caseManagerInputField, "data-value");

			Assert.assertEquals(caseManager, expectedCaseManager,
					"Case Manger missmatch. Expected: '" + expectedCaseManager + "', but got: '" + caseManager + "'");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify case manger" + e.getMessage());
			Assert.fail("Failed to verify case manger " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to received document table in CPE related tab
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToReceivedDocTable() {
		try {

			waitForPageLoaded();
			setTimeOut(6000);
			By eleReceivedDocumentTable = getDynamicElement(eleTableName, "Received Documents");
			waitAndVerifyElement(eleReceivedDocumentTable);
			scrollToElement(eleReceivedDocumentTable);
			setTimeOut(4000);
			LoggingInfo("Navigated to Received Documents table");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to received document table" + e.getMessage());
			Assert.fail("Failed to navigate to received document table " + e.getMessage());
		}
	}

	/**
	 * Function: Verify received document id is linked to CPE
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyReceivedDocIDLinkedToCPE(String expectedFileName) {
		try {
			String sortingState;
			do {
				sortingState = getText(receivedDateSortingState);
				if (!sortingState.equalsIgnoreCase("Sorted Descending")) {
					clickByJavascript(receivedDateSortingColumn);
					setTimeOut(1000);
				}
				sortingState = getText(receivedDateSortingState);
			} while (!sortingState.equalsIgnoreCase("Sorted Descending"));

			boolean fileFound = false;
			if (verifytable("Received Documents")) {
				By eleReceivedDocTable = By.xpath(
						"//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Received Documents\"]//tbody//tr");
				List<WebElement> rows = getWebDriver().findElements(eleReceivedDocTable);
				scrollToElement(eleReceivedDocTable);
				for (WebElement row : rows) {
					WebElement nameElement = row
							.findElement(By.xpath(".//th//a//span[@class=\"slds-truncate\"]//slot//span"));
					String fileName = nameElement.getText().trim();
					if (fileName.contains(expectedFileName)) {
						fileFound = true;
						break;
					}

				}
				Assert.assertTrue(fileFound,
						"File name '" + expectedFileName + "' not found in the Received document table.");
				LoggingInfo("Verification completed: " + expectedFileName);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify New Received Document is Linked to the Existing CPE-" + e.getMessage());
			Assert.fail("Failed to verify New Received Document is Linked to the Existing CPE-" + e.getMessage());
		}
	}

	/**
	 * Function: Clear mailing address of patient account
	 * 
	 * @author Samarth S
	 **/
	public void clearMailingAddress() {
		try {

			By MailingEdit = getDynamicElement(editButton, "Mailing Address");
			waitAndVerifyElement(MailingEdit);
			scrollToElement(MailingEdit);
			setTimeOut(2000);
			click(MailingEdit);

			By email = getDynamicElement(accountInputBox, "Email");
			waitAndVerifyElement(email);
			clearText(email);

			By MailingCountry = getDynamicElement(accountInputBox, "Mailing Country");
			waitAndVerifyElement(MailingCountry);
			clearText(MailingCountry);

			By MailingStreet = getDynamicElement(accountTextAreaBox, "Mailing Street");
			waitAndVerifyElement(MailingStreet);
			clearText(MailingStreet);

			By MailingCity = getDynamicElement(accountInputBox, "Mailing City");
			waitAndVerifyElement(MailingCity);
			clearText(MailingCity);

			By MailingCState = getDynamicElement(accountInputBox, "Mailing State/Province");
			waitAndVerifyElement(MailingCState);
			clearText(MailingCState);

			By MailingCZip = getDynamicElement(accountInputBox, "Mailing Zip/Postal Code");
			waitAndVerifyElement(MailingCZip);
			clearText(MailingCZip);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit mailing address " + e.getMessage());
			Assert.fail("Failed to edit mailing address" + e.getMessage());
		}
	}

	/**
	 * Function: Edit mailing address of patient account
	 * 
	 * @author Samarth S
	 **/
	public void editMailingAddress(String Email,String street, String city, String state, String zipCode) {
		try {

			By MailingAddressEdit = getDynamicElement(editButton, "Mailing Address");
			waitAndVerifyElement(MailingAddressEdit);
			scrollToElement(MailingAddressEdit);
			setTimeOut(2000);
			click(MailingAddressEdit);

			By email = getDynamicElement(accountInputBox, "Email");
			waitAndVerifyElement(email);
			scrollToElement(email);
			inputText(email, Email);

			// Mailing Country
			By MailCountryInputBox = getDynamicElement(strAccDropDownBox, "Mailing Country");
			waitAndVerifyElement(MailCountryInputBox);
			click(MailCountryInputBox);
			String MailingCountry = "United States";
			By countryOptions = getDynamicElement(strAccDropDownBoxOptions, "Mailing Country");
			waitAndVerifyElement(countryOptions);
			selectItemFromList(MailCountryInputBox, countryOptions, MailingCountry, "Mailing Country");
			LoggingInfo("Entered Country: " + MailingCountry);

			// Mailing Street
			By MailCityStreet = getDynamicElement(strAddressTextArea, "Mailing Street");
			waitAndVerifyElement(MailCityStreet);
			inputText(MailCityStreet, street);
			LoggingInfo("Entered Street: " + street);

			// Mailing City
			By MailCityInputBox = getDynamicElement(accountInputBox, "Mailing City");
			waitAndVerifyElement(MailCityInputBox);
			inputText(MailCityInputBox, city);
			LoggingInfo("Entered Street: " + city);

			// Mailing State/Province
			By stateInputBox = getDynamicElement(strAccDropDownBox, "Mailing State/Province");
			waitAndVerifyElement(stateInputBox);
			click(stateInputBox);
			setTimeOut(2000);
			By stateOptions = getDynamicElement(strAccDropDownBoxOptions, "Mailing State/Province");
			waitAndVerifyElement(stateOptions);
			state = "Alaska";
			selectItemFromList(stateInputBox, stateOptions, state, "Mailing State/Province");
			LoggingInfo("Entered state: " + state);

			// Mailing Zip/Postal Code
			By MailPincodeInputBox = getDynamicElement(accountInputBox, "Mailing Zip/Postal Code");
			waitAndVerifyElement(MailPincodeInputBox);
			inputText(MailPincodeInputBox, zipCode);
			LoggingInfo("Entered Country: " + zipCode);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit email id " + e.getMessage());
			Assert.fail("Failed to edit email id " + e.getMessage());
		}
	}

	/**
	 * Function: Download PDF from the page where correspondence file s generated
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void savePdfFromCorrespondencePage(String pdfName) throws InterruptedException {
		try {
			setTimeOut(20000);
			waitForPageLoaded();
			setTimeOut(2000);
			waitForPresenceOfElementLocated(frameName);
			switchToFrame(frameName);
			waitForvisiblityOfElementLocated(eleFrameImg);
			waitForPresenceOfElementLocated(menuButton);
			click(menuButton);
			click(buttonsaveAs);
			setTimeOut(3000);

			scrollToElement(fileName);
			clearText(fileName);
			inputText(fileName, pdfName);
			clickByJavascript(saveFileButton);
			getWebDriver().switchTo().defaultContent();
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to save PDF " + e.getMessage());
			Assert.fail("Failed to save PDF " + e.getMessage());
		}

	}
	
	/**
	 * Function: Download Correspondence PDF from Generate screen
	 * 
	 * @author Shanavaz Nishani
	 **/
	public String downloadPDFfromGenerateDocScreen(String file, String windowName) throws Exception {
		waitFor(20000);
		By elePDF = By.xpath("//*[@class='pdf_viewer']");
		String url = getAttributeValue(elePDF, "src");
		((JavascriptExecutor) getWebDriver()).executeScript("window.open('" + url + "', '_blank');");
		setTimeOut(5000);
		refresh();
		setTimeOut(2000);

		Robot robot = new Robot();
		robot.setAutoDelay(1000);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_S);
		robot.keyRelease(KeyEvent.VK_S);
		robot.keyRelease(KeyEvent.VK_CONTROL);

		setTimeOut(5000);
		String DEST = System.getProperty("user.dir") + File.separator + "TestData" + File.separator + "PDFDownloads"
				+ File.separator + file.trim();
		documentsPage.uploadPDFFile(DEST);
		setTimeOut(10000);
		LoggingInfo("File downloaded successfully from Generate Doc screen");
		switchToWindowByIndex(0);

		return DEST;
	}



	/**
	 * Function: Validate data/required text from the downloaded PDF
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validatePDFData(String pathToPDF, String textToValidate, int pageNumber) throws IOException {
		PDDocument document = PDDocument.load(new File(pathToPDF));
		try {
			// Set up PDFTextStripper for a specific page
			PDFTextStripper pdfStripper = new PDFTextStripper();
			pdfStripper.setStartPage(pageNumber);
			pdfStripper.setEndPage(pageNumber);
			String pdfText = pdfStripper.getText(document);
			document.close();
			// remove all the line breaks and extra white spaces
			String normalizedActualText = pdfText.replaceAll(",", "").replaceAll("\\r?\\n", " ").replaceAll("\\s+",
					" ");
			if (textToValidate.endsWith("United States")) {
				textToValidate = textToValidate.substring(0, textToValidate.length() - "United States".length()).trim();
			}
			if (normalizedActualText.contains(textToValidate)) {
				LoggingInfo("Expected text matches with PDF data");
			} else {

				LoggingInfo("Expected text not found in PDF data");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate PDF data " + e.getMessage());
			Assert.fail("Failed to validate PDF data " + e.getMessage());
		}
	}

	/**
	 * Function: Validate the Correspondence fields
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateCorrespondenceFields(boolean section) {

		String[] fieldsLabels = { "Channel", "Recipient Type", "Service Area", "Status", "Correspondence Name" };

		try {
			for (String fieldLabel : fieldsLabels) {
				By fieldLocator = getDynamicElement(correspondenceInputField, fieldLabel);
				scrollToElement(fieldLocator);
				verifyAnyFieldIsEnabledOrDisabled(fieldLocator, fieldLabel, section);
				setTimeOut(2000);

			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate Correspondence section " + e.getMessage());
		}
	}

	public void clickFirstCorrespondence(String fileName) {
		try {
			String pdfName = fileName + ".pdf";
			setTimeOut(2000); // Optional: Adjust or replace this with an explicit wait

			// Wait for the elements to be visible before proceeding
			WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(10));
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(
					"//*[contains(@class, 'active lafPageHost')]//span[@title='Files']//ancestor::div[2]//following-sibling::div//ul/li[@role='listitem']//span[contains(@class,'itemTitle')]")));

			List<WebElement> rows = getWebDriver().findElements(By.xpath(
					"//*[contains(@class, 'active lafPageHost')]//span[@title='Files']//ancestor::div[2]//following-sibling::div//ul/li[@role='listitem']//span[contains(@class,'itemTitle')]"));

			List<WebElement> pdfList = new ArrayList<>();

			for (WebElement row : rows) {
				String FileName = row.getText().trim(); // Trim to remove any leading/trailing spaces
				if (pdfName.equals(FileName)) {
					pdfList.add(row);
				}
			}

			// Check if the pdfList has the expected matching element
			if (!pdfList.isEmpty()) {
				WebElement latestRecord = pdfList.get(0);

				// Ensure that the element is clickable (optional: check visibility before
				// clicking)
				wait.until(ExpectedConditions.elementToBeClickable(latestRecord));

				// Click on the element using JavaScript
				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", latestRecord);
				LoggingInfo("Clicked on the latest 'PDF' record.");
			} else {
				Log.error("No PDF records found for " + pdfName);
			}

		} catch (Exception e) {
			Log.error("Failed to verify PDF correspondence record: " + e.getMessage());
			Assert.fail("Failed to verify PDF correspondence record: " + e.getMessage());
		}

	}

	/**
	 * Function: Verify Files on CPE page Related section
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyFilesRecord(String fileName) {
		try {
			String pdfName = fileName + ".pdf";
			setTimeOut(2000);
			List<WebElement> rows = getWebDriver().findElements(By.xpath(
					"//*[contains(@class, 'active lafPageHost')]//span[@title='Files']//ancestor::div[2]//following-sibling::div//ul/li[@role='listitem']//span[contains(@class,'itemTitle')]"));
			List<WebElement> pdfList = new ArrayList<>();
			for (WebElement row : rows) {
				String FileName = row.getText();
				if (pdfName.equals(FileName)) {
					pdfList.add(row);

				}
			}
			if (!pdfList.isEmpty()) {
				WebElement latestRecord = pdfList.get(0);
				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", latestRecord);
				LoggingInfo("Clicked on the latest 'PDF' record.");
			} else {
				Log.error("No  PDF records found." + pdfName);
			}

		} catch (Exception e) {
			Log.error("Failed to verify PDF correspondence record " + e.getMessage());
			Assert.fail("Failed to verify PDF correspondence record: " + e.getMessage());

		}

	}

	/**
	 * Function: Verify Files on CPE page Related section docx format
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyFilesRecordDocx(String fileName) {
		try {
			String pdfName = fileName + ".docx";
			setTimeOut(2000);
			List<WebElement> rows = getWebDriver().findElements(By.xpath(
					"//*[contains(@class, 'active lafPageHost')]//span[@title='Files']//ancestor::div[2]//following-sibling::div//ul/li[@role='listitem']//span[contains(@class,'itemTitle')]"));
			List<WebElement> pdfList = new ArrayList<>();
			for (WebElement row : rows) {
				String FileName = row.getText();
				if (pdfName.equals(FileName)) {
					pdfList.add(row);

				}
			}
			if (!pdfList.isEmpty()) {
				WebElement latestRecord = pdfList.get(0);
				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", latestRecord);
				LoggingInfo("Clicked on the latest 'PDF' record.");
			} else {
				Log.error("No  PDF records found." + pdfName);
			}

		} catch (Exception e) {
			Log.error("Failed to verify PDF correspondence record " + e.getMessage());
			Assert.fail("Failed to verify PDF correspondence record: " + e.getMessage());

		}

	}

	/**
	 * Function: Delete the downloaded PDF
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void deletePDF(String pdfPath) {

		File pdfFile = new File(pdfPath);

		// Delete the PDF file if it exists
		if (pdfFile.exists()) {
			boolean deleted = pdfFile.delete();
			if (deleted) {

				System.out.println("File deleted successfully.");
			} else {
				System.out.println("Failed to delete the file.");
			}
		} else {
			System.out.println("File does not exist.");
		}
	}

	/**
	 * Function: Get patient details from CPE page details section
	 * 
	 * @author Shanavaz Nishani
	 **/
	public String getPatientDetailsFromCPEPage(String fieldName) throws InterruptedException {
		String requiredFieldText = "";
		setTimeOut(5000);
		try {
			By Requiredfield = getDynamicElement(strFieldCPEPage2, fieldName);
			if (!verifyObjectPresentOrNot(Requiredfield)) {
				Log.info(fieldName + "Field not found");
			}
			scrollToElement(Requiredfield);
			setTimeOut(2000);
			requiredFieldText = getText(Requiredfield).trim();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get details from CPE page :" + e.getMessage());
			Assert.fail("Failed to get details from CPE page :" + e.getMessage());

		}
		return requiredFieldText;

	}

	public String getPatientDetailsFromCPEPageName(String fieldName) throws InterruptedException {
		String requiredFieldText = "";
		setTimeOut(5000);
		try {
			By Requiredfield = getDynamicElement(strFieldCPEPageName, fieldName);
			if (!verifyObjectPresentOrNot(Requiredfield)) {
				Log.info(fieldName + "Field not found");
			}
			scrollToElement(Requiredfield);
			setTimeOut(2000);
			requiredFieldText = getText(Requiredfield).trim();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get details from CPE page :" + e.getMessage());
			Assert.fail("Failed to get details from CPE page :" + e.getMessage());

		}
		return requiredFieldText;

	}

	public String getPatientDetailsFromCPEPageEmail(String fieldName) throws InterruptedException {
		String requiredFieldText = "";
		setTimeOut(5000);
		try {
			By Requiredfield = getDynamicElement(strFieldCPEPageEmail, fieldName);
			if (!verifyObjectPresentOrNot(Requiredfield)) {
				Log.info(fieldName + "Field not found");
			}
			scrollToElement(Requiredfield);
			setTimeOut(2000);
			requiredFieldText = getText(Requiredfield).trim();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get details from CPE page :" + e.getMessage());
			Assert.fail("Failed to get details from CPE page :" + e.getMessage());

		}
		return requiredFieldText;

	}

	public void closeButton() {
		setTimeOut(3000);
		By closeButton = By.xpath("//button[@title='Close']");

		if (verifyObjectPresentOrNot(closeButton)) {
			Log.info("Close button is displayed");
			click(closeButton);
		} else {
			Log.info("Close button is not present");
		}

	}

	/**
	 * Function: Validate the Correspondence fields
	 * 
	 * @author Trupti Zure
	 **/
	public void validateCorrespondenceFields(String channel, String recipientType, String serviceArea, String status) {
		String[] fieldsLabels = { "Channel", "Recipient Type", "Service Area", "Status" };
		String[] fieldsValues = { channel, recipientType, serviceArea, status };

		try {
			for (int i = 0; i < fieldsLabels.length; i++) {
				By fieldLocator = getDynamicElement(correspondenceInputField, fieldsLabels[i]);
				scrollToElement(fieldLocator);
				verifyHardAssertInputFieldBox(fieldLocator, fieldsValues[i], fieldsLabels[i]);
				setTimeOut(2000);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Validation of Correspondence section failed: " + e.getMessage());
		}
	}

	public void validateCorrespondenceFieldsnew(String channel, String recipientType, String serviceArea) {
		String[] fieldsLabels = { "Channel", "Recipient Type", "Service Area" };
		String[] fieldsValues = { channel, recipientType, serviceArea };

		try {
			for (int i = 0; i < fieldsLabels.length; i++) {
				By fieldLocator = getDynamicElement(correspondenceInputField, fieldsLabels[i]);
				scrollToElement(fieldLocator);
				verifyHardAssertInputFieldBox(fieldLocator, fieldsValues[i], fieldsLabels[i]);
				setTimeOut(2000);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Validation of Correspondence section failed: " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to files section
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToFilesSection() {
		try {
			waitAndVerifyElement(eleFilesSection);
			scrollToElement(eleFilesSection);
			LoggingInfo("Navigated to Files section");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Navigated to files section " + e.getMessage());
			Assert.fail("Navigated to files section " + e.getMessage());
		}
	}

	/**
	 * Function: Click close btn
	 * 
	 * @author Anand Pawar
	 **/
	public void clickCloseBtn() {
		try {
			By btnclose = By.xpath("//button[@title=\"Close\"]");
			waitAndVerifyElement(btnclose);
			click(btnclose);
			setTimeOut(2000);
			LoggingInfo("Navigated to Files section");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Navigated to files section " + e.getMessage());
			Assert.fail("Navigated to files section " + e.getMessage());
		}
	}

	/**
	 * Function: Validate multiple fields from pdf
	 * 
	 * @author Trupti Zure
	 **/
	public void validateMultiplePDFFields(String pathToPDF, Map<String, Integer> fieldsToValidate) throws IOException {

		PDDocument document = PDDocument.load(new File(pathToPDF));
		try {

			PDFTextStripper pdfStripper = new PDFTextStripper();
			StringBuilder validationResults = new StringBuilder();

			for (Map.Entry<String, Integer> entry : fieldsToValidate.entrySet()) {
				String textToValidate = entry.getKey();
				int pageNumber = entry.getValue();

				pdfStripper.setStartPage(pageNumber);
				pdfStripper.setEndPage(pageNumber);
				String pdfText = pdfStripper.getText(document);

				String normalizedActualText = pdfText.replaceAll("\\r?\\n", " ").replaceAll("\\s+", " ");

				if (normalizedActualText.contains(textToValidate)) {
					validationResults.append("Validation passed for: ").append(textToValidate).append("\n");
					LoggingInfo("Expected text matches with PDF data: " + textToValidate);
				} else {
					validationResults.append("Validation failed for: ").append(textToValidate).append("\n");
					Assert.fail("Expected text not found in PDF data:" + textToValidate);
					LoggingInfo("Expected text not found in PDF data: " + textToValidate);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate PDF data: " + e.getMessage());
			Assert.fail("Failed to validate PDF data: " + e.getMessage());
		} finally {
			document.close();
		}
	}

	/**
	 * Function: Delete existing file
	 * 
	 * @author Trupti Zure
	 **/

	public void deleteExistingFile(String filepath) {
		try {
			File file = new File(filepath);

			if (!file.exists()) {
				Log.info("File does not exist: " + filepath);
				return;
			}

			if (file.delete()) {
				Log.info("File deleted successfully");
			} else {
				Log.info("Failed to delete the file");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to delete file" + e.getMessage());
			Assert.fail("Failed to delete file " + e.getMessage());
		}
	}

	/**
	 * Function: Keep clicking on send button until finish button is displayed
	 * 
	 * @author Trupti Zure
	 **/

	public void clickSendButtonUntilFinish() {
		try {
			Log.info("Verify user is able to click on Next button until Finish button appears");

			boolean isFinishButtonDisplayed = false;

			while (!isFinishButtonDisplayed) {
				waitAndVerifyElement(eleSendButton);
				scrollToElement(eleSendButton);
				clickByJavascript(eleSendButton);
				setTimeOut(5000);

				isFinishButtonDisplayed = isElementDisplayed(eleFinishButton);

				if (isFinishButtonDisplayed) {
					LoggingInfo("Finish button is now displayed, stopping the loop.");
				} else {
					LoggingInfo("Send button clicked, waiting for Finish button.");
					setTimeOut(2000);
				}
			}

			LoggingInfo("User successfully clicked on Next button until Finish button appears.");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Next Button until Finish button appears: " + e.getMessage());
			Assert.fail("Failed to click on Next Button until Finish button appears: " + e.getMessage());
		}
	}

	public void verifyPrimaryRecordMemberPlansSection() {
		try {
			scrollToHalfPage();
			waitAndVerifyElement(eleMemberPlans);
			scrollToElement(eleMemberPlans);
			LoggingInfo("verified member plans section");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify member plans section" + e.getMessage());
			Assert.fail("Failed to verify member plans section " + e.getMessage());
		}
	}

	// Anand P
	public void verifyFailedCorrespondenceReport() {

		try {

			scrollToElement(failReportTitle);
			waitAndVerifyElement(failReportTitle);
			LoggingInfo("My Failed Correspondence title verified successfully");

			LoggingInfo("Click on View Report");
			setTimeOut(1000);
			scrollToElement(viewReportLink);
			waitAndVerifyElement(viewReportLink);
			click(viewReportLink);
			LoggingInfo("Clicked on View Report ");
			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to Failed Correspondence  " + e.getMessage());
			Assert.fail("Failed to verify Errormessage " + e.getMessage());
		}

	}

	// Anand P
	public void verifyDashboardTitle() {
		try {
			By frame = By.xpath("//iframe[@title='dashboard']");
			switchToFrame(frame);

			setTimeOut(1000);
			waitAndVerifyElement(dashboardTitle);
			LoggingInfo("Succesfully validated the title");

		} catch (Exception e) {
			Log.error("Failed to validate title " + e.getMessage());
			Assert.fail("Failed to validate " + e.getMessage());
		}
	}

	// Anand P
	public void validateColumns() {
		try {
			refresh();
			setTimeOut(2000);
			switchToFrame(reportFrameName);
			String[] headerValue = { "Care Program Enrollee", "Correspondence Name", "Recipient Type",
					"Recipient Details", "Service Area", "Channel", "Status", "Status Reason" };

			for (String header : headerValue) {
				By headerName = getDynamicElement(columnHeader, header);
				waitAndVerifyElement(headerName);
				LoggingInfo("Succesfully validated column " + header);
				setTimeOut(2000);
			}

		} catch (Exception e) {
			Log.error("Failed to validate columns " + e.getMessage());
			Assert.fail("Failed to validate columns " + e.getMessage());
		}
	}

	// Anand P
	public void clickOnCorrespondenceRecord() {
		try {
			setTimeOut(1000);
			By corresRecord = By
					.xpath("(//div[contains(@class, 'wave-table-cell-text') and contains(@class, 'css-0')]//a)[4]");
			click(corresRecord);
			LoggingInfo("Successfully clicked on Correspondence Record");

		} catch (Exception e) {
			Log.error("Failed to click on correspondence record" + e.getMessage());
			Assert.fail("Failed to click on correspondence record " + e.getMessage());
		}
	}

	// Anand P
	public void clickOnAllCorrespondence() {

		try {
			setTimeOut(2000);

			By frame = By.xpath("//iframe[@title='Report Viewer']");
			switchToFrame(frame);

			By corresBtn = By.xpath("//button[text()=\"All correspondences\"]");
			scrollToElement(corresBtn);
			click(corresBtn);
			LoggingInfo("Successfully clicked on All Correspondence Buttton");

		} catch (Exception e) {
			Log.error("Failed to click on correspondence button" + e.getMessage());
			Assert.fail("Failed to click on correspondence button " + e.getMessage());
		}
	}

	// Anand P
	public void validateValuesOfCorrespondence() {
		try {

			getWebDriver().switchTo().defaultContent();

			String[] corsValue = { "Correspondence Name", "Channel", "Recipient Type", "Service Area", "Status" };

			for (String header : corsValue) {
				By value = getDynamicElement(correspondenceInputField, header);
				waitAndVerifyElement(value);
				String text = getText(value);
				LoggingInfo("Succesfully validated column value " + header);
				setTimeOut(2000);
			}

		} catch (Exception e) {
			Log.error("Failed to validate values of correspondence columns " + e.getMessage());
			Assert.fail("Failed to validate values of correspondence columns " + e.getMessage());
		}

	}

	public void navigateToFiles() {
		try {
			waitAndVerifyElement(eleFilesSection);
			scrollToElement(eleFilesSection);
			LoggingInfo("Navigated to Files section");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Navigated to files section " + e.getMessage());
			Assert.fail("Navigated to files section " + e.getMessage());
		}
	}

	public void clickOnCorrespondence() {
		try {
			setTimeOut(1000);
			By corresRecord = By
					.xpath("(//div[contains(@class, 'wave-table-cell-text') and contains(@class, 'css-0')]//a)[4]");
			click(corresRecord);
			LoggingInfo("Successfully clicked on Correspondence Record");

		} catch (Exception e) {
			Log.error("Failed to click on correspondence record" + e.getMessage());
			Assert.fail("Failed to click on correspondence record " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to Cases table
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void navigateToCasesTable() {
		try {
			waitForPageLoaded();
			setTimeOut(6000);
			waitAndVerifyElement(eleCasesTable);
			scrollToElement(eleCasesTable);
			setTimeOut(5000);
			// scrollToElement(eleCasesTable);
			// scrollToBottomOfPage();
			LoggingInfo("Navigated to cases table");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Navigated to correspondence table " + e.getMessage());
			Assert.fail("Navigated to correspondence table " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to CPE Team Member table
	 * 
	 * @author Anand Pawar
	 **/

	public void navigateToCPETeamMemberTable() {
		try {
			waitAndVerifyElement(elCPETeamMember);
			scrollToElement(elCPETeamMember);
			setTimeOut(3000);
			scrollToElement(elCPETeamMember);
			// scrollToBottomOfPage();
			LoggingInfo("Navigated to cases table");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Navigated to correspondence table " + e.getMessage());
			Assert.fail("Navigated to correspondence table " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to new case button
	 * 
	 * @author Anand Pawar
	 **/

	public void clickOnNewButton() {
		try {
			waitAndVerifyElement(newBtn);
			scrollToElement(newBtn);
			setTimeOut(3000);
			clickByJavascript(newBtn);
			// scrollToBottomOfPage();
			LoggingInfo("Clicked on new button");
			setTimeOut(1000);
			refresh();
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Click unsucccessful " + e.getMessage());
			Assert.fail("Click unsucccessful " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Case with empty subject and open.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyandOpenCase() throws Exception {
		WebElement table = getWebDriver().findElement(
				By.xpath("//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Cases\"]//tbody"));
		List<WebElement> rows = table.findElements(By.tagName("tr"));

		clickByJavascript(eleCaseLink);
		setTimeOut(2000);

	}

	/**
	 * Function: Verify Case page Layout/fields.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyCaseFileds() throws Exception {

		String[] inputLabels = { "Status", "Account Name", "Care Program", "Contact Phone", "Created By",
				"Last Modified By", "Care Program Enrollee" };

		try {

			for (String inputLabel : inputLabels) {
				By fieldName = getDynamicElement(strCaseFields, inputLabel);
				scrollToElement(fieldName);
				boolean found = isElementPresent(fieldName);
				Assert.assertTrue(found);
				LoggingInfo("Field is present on layout- " + inputLabel);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Field " + e.getMessage());
			Assert.fail("Failed to verify Field " + e.getMessage());
		}
	}

	public void validateMultiplePDFField(String pathToPDF, Map<String, Integer> fieldsToValidate) throws IOException {
		PDDocument document = PDDocument.load(new File(pathToPDF));
		try {
			PDFTextStripper pdfStripper = new PDFTextStripper();
			StringBuilder validationResults = new StringBuilder();

			for (Map.Entry<String, Integer> entry : fieldsToValidate.entrySet()) {
				String textToValidate = entry.getKey();
				int pageNumber = entry.getValue();

				pdfStripper.setStartPage(pageNumber);
				pdfStripper.setEndPage(pageNumber);
				String pdfText = pdfStripper.getText(document);

				String normalizedActualText = pdfText.replaceAll("\\r?\\n", " ").replaceAll("\\s+", " ").toLowerCase();
				String normalizedExpectedText = textToValidate.toLowerCase();

				if (normalizedActualText.contains(normalizedExpectedText)) {
					validationResults.append("Validation passed for: ").append(textToValidate).append("\n");
					LoggingInfo("Expected text matches with PDF data: " + textToValidate);
				} else {
					validationResults.append("Validation failed for: ").append(textToValidate).append("\n");
					Assert.fail("Expected text not found in PDF data: " + textToValidate);
					LoggingInfo("Expected text not found in PDF data: " + textToValidate);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate PDF data: " + e.getMessage());
			Assert.fail("Failed to validate PDF data: " + e.getMessage());
		} finally {
			document.close();
		}
	}

	/**
	 * Function: wait untill the finish button on the page.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void waitForFinishButton() throws Exception {
		boolean isFinishButtonDisplayed = false;

		while (!isFinishButtonDisplayed) {
			setTimeOut(5000);

			isFinishButtonDisplayed = isElementDisplayed(eleFinishButton);

			if (isFinishButtonDisplayed) {
				LoggingInfo("Finish button is now displayed, stopping the loop.");
			} else {
				LoggingInfo("Send button clicked, waiting for Finish button.");
				setTimeOut(2000);
			}
		}

	}

	// Anand P
	public void verifySpecialtyPharmacy() {
		try {
			By selectedPharmacy = getDynamicElement(detailsPageFields, "Selected Specialty Pharmacy");
			waitAndVerifyElement(selectedPharmacy);
			scrollToElement(selectedPharmacy);
			highLightElement(selectedPharmacy);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify pharmacy" + e.getMessage());
			Assert.fail("Failed to verify pharmacy " + e.getMessage());
		}
	}

	// Anand P
	public void editAndPassFax() {
		try {

			waitAndVerifyElement(eleEditFax);
			scrollToElement(eleEditFax);
			click(eleEditFax);
			setTimeOut(2000);

			waitAndVerifyElement(eleFaxInput);
			scrollToElement(eleFaxInput);
			getWebDriver().findElement(eleFaxInput).clear();
			LoggingInfo("User enters 11 digit fax number");
			inputText(eleFaxInput, "12345678901");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit Fax" + e.getMessage());
			Assert.fail("Failed to edit Fax " + e.getMessage());
		}
	}

	// Anand P
	public void editAndPassPhone() {
		try {

			By elePhone = getDynamicElement(eleDemoGraphicInputFields, "Phone");
			waitAndVerifyElement(elePhone);
			scrollToElement(elePhone);
			getWebDriver().findElement(elePhone).clear();
			LoggingInfo("User enters 11 digit phone number");
			inputText(elePhone, "12341617190");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit Phone" + e.getMessage());
			Assert.fail("Failed to edit Phone " + e.getMessage());
		}
	}

	// Anand P
	public void enterCredentials() {
		try {

			By eleCred = getDynamicElement(eleDemoGraphicInputFields, "Credentials");
			waitAndVerifyElement(eleCred);
			scrollToElement(eleCred);
			getWebDriver().findElement(eleCred).clear();
			LoggingInfo("User enters 11 digit phone number");
			inputText(eleCred, "MD");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit Cred" + e.getMessage());
			Assert.fail("Failed to edit Cred " + e.getMessage());
		}
	}

	// Anand P
	public void editZip() {
		try {

			By eleZip = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Billing Zip/Postal Code\"]//following-sibling::div//input");
			waitAndVerifyElement(eleZip);
			scrollToElement(eleZip);
			getWebDriver().findElement(eleZip).clear();
			LoggingInfo("User enters 6 digit zip number");
			inputText(eleZip, "123416");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit Phone" + e.getMessage());
			Assert.fail("Failed to edit Phone " + e.getMessage());
		}

	}

	// Sonica

	public void editNPI() {
		try {

			By eleNPI = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"NPI #\"]//following-sibling::div//input");
			waitAndVerifyElement(eleNPI);
			scrollToElement(eleNPI);
			getWebDriver().findElement(eleNPI).clear();
			LoggingInfo("User enters only 6 digit number");
			inputText(eleNPI, "123416");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit NPI" + e.getMessage());
			Assert.fail("Failed to edit NPI " + e.getMessage());
		}

	}

	// Anand P
	public void validateFaxErrorMsg() {
		try {
			String expectedError = "ACC-VR36: Fax only accepts 10-digit number.";
			By errorMsg = By.xpath("//*[text()=\"ACC-VR36: Fax only accepts 10-digit number.\"]");
			waitAndVerifyElement(errorMsg);
			scrollToElement(errorMsg);
			highLightElement(errorMsg);
			String actualError = getText(errorMsg);
			Assert.assertEquals(expectedError, actualError, "Error message validated successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate error message" + ". Error - " + e.getMessage());

		}

	}

	// Anand P
	public void validatePhoneErrorMsg() {
		try {
			String expectedError = "ACC-VR37: Phone only accepts 10-digit number.";
			By errorMsg = By.xpath("//*[text()=\"ACC-VR37: Phone only accepts 10-digit number.\"]");
			waitAndVerifyElement(errorMsg);
			scrollToElement(errorMsg);
			highLightElement(errorMsg);
			String actualError = getText(errorMsg);
			Assert.assertEquals(expectedError, actualError, "Error message validated successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate error message" + ". Error - " + e.getMessage());

		}

	}

	// Anand P
	public void validateZipErrorMsg() {
		try {
			String expectedError = "ACC-VR39: Billing Zip/Postal Code only accepts 5-digit number.";
			By errorMsg = By.xpath("//*[text()=\"ACC-VR39: Billing Zip/Postal Code only accepts 5-digit number.\"]");
			waitAndVerifyElement(errorMsg);
			scrollToElement(errorMsg);
			highLightElement(errorMsg);
			String actualError = getText(errorMsg);
			Assert.assertEquals(expectedError, actualError, "Error message validated successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate error message" + ". Error - " + e.getMessage());

		}

	}

	// Sonica
	public void validateNPIErrorMsg() {
		try {
			String expectedError = "ACC-VR41: Prescriber NPI # only accepts 10-digit number.";
			By errorMsg = By.xpath("//*[text()=\"ACC-VR41: Prescriber NPI # only accepts 10-digit number.\"]");
			waitAndVerifyElement(errorMsg);
			scrollToElement(errorMsg);
			highLightElement(errorMsg);
			String actualError = getText(errorMsg);
			Assert.assertEquals(expectedError, actualError, "Error message validated successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate error message" + ". Error - " + e.getMessage());

		}

	}

	// Anand P
	public void clickSave() {
		try {
			By btnSave = getDynamicElement(strAuthorizationieldButtons, "Save");
			waitAndVerifyElement(btnSave);
			scrollToElement(btnSave);
			click(btnSave);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on Save" + ". Error - " + e.getMessage());

		}

	}

	// Anand P
	public void clickCancel() {
		try {
			By btnCancel = getDynamicElement(strAuthorizationieldButtons, "Cancel");
			waitAndVerifyElement(btnCancel);
			scrollToElement(btnCancel);
			click(btnCancel);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on Cancel" + ". Error - " + e.getMessage());

		}

	}

	// Anand P
	public void clickEditBtn() {
		try {

			By btnEdit = getDynamicElement(editBtn, "Edit Phone");
			waitAndVerifyElement(btnEdit);
			scrollToElement(btnEdit);
			click(btnEdit);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on edit button" + e.getMessage());
			Assert.fail("Failed to click on edit button  " + e.getMessage());
		}
	}

	/**
	 * Function: Open Exisitng Correspondence Record.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void openRecentCorrspndceRec() {

		try {
			waitAndVerifyElement(eleRecentCorrespondenceRec);
			click(eleRecentCorrespondenceRec);
			LoggingInfo("Existing  record opened successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Open Existing  Record " + e.getMessage());
			Assert.fail("Failed to Open Existing  Record " + e.getMessage());
		}

	}

	/**
	 * Function: Open Exisitng CPE Record.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void openRecentdoc() throws Exception {
		try {
			waitAndVerifyElement(eleRecentCPERecord);
			scrollToElement(eleRecentCPERecord);
			clickByJavascript(eleRecentCPERecord);
			LoggingInfo("Existing CPE record opened successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Open Existing CPE Record " + e.getMessage());
			Assert.fail("Failed to Open Existing CPE Record " + e.getMessage());
		}

	}

	/**
	 * Function: Validating Field Layout on Received Document Page, Details tab for
	 * different sections.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void ReceivedDocPageFieldValidation(String userType, String sectionToValidate) throws InterruptedException {
		String strDetailsSec = "Details";
		String strRelatedInfoSec = "Related Information";
		String strAddDocInfoSec = "Additional Document Information";
		String strSysInfoSec = "System Information";

		// Define common fields for each section
		Map<String, String[]> sectionFields = new HashMap<>();
		sectionFields.put(strDetailsSec,
				new String[] { "Document Type", "Document #", "Enrollment Form Version", "Status", "Received Date" });
		sectionFields.put(strRelatedInfoSec, new String[] { "Care Program Enrollee", "Parent Received Document" });
		sectionFields.put(strAddDocInfoSec,
				new String[] { "Patient First Name", "Patient Last Name", "Patient Date of Birth",
						"Patient Email Address", "Doc Submitter Name", "Doc Submitter Email Address",
						"Doc Submitter Role" });
		sectionFields.put(strSysInfoSec,
				new String[] { "Created By", "Created Date", "Legacy Id", "Reciever Fax ID", "Source System",
						"Source Channel", "Source", "Last Modified By", "Last Modified Date", "Submitter Fax ID",
						"Vendor ID", "Reciever Fax Number", "Disable Auto OCR" });

		// Define user-specific fields (extend common fields if necessary)
		Map<String, String[]> userFields = new HashMap<>();
		switch (userType) {
		case "DIS":

			userFields.put(strDetailsSec, sectionFields.get(strDetailsSec));
			userFields.put(strRelatedInfoSec, sectionFields.get(strRelatedInfoSec));
			userFields.put(strAddDocInfoSec, mergeFields(sectionFields.get(strAddDocInfoSec), "Submitter Fax Number"));
			userFields.put(strSysInfoSec, sectionFields.get(strSysInfoSec));
			break;

		case "PC":

			userFields.put(strDetailsSec, mergeFields(sectionFields.get(strDetailsSec), "PSQA Review Outcome"));
			userFields.put(strRelatedInfoSec, mergeFields(sectionFields.get(strRelatedInfoSec), "Patient",
					"Case Manager", "Care Program Product", "Reviewed by CM"));
			userFields.put(strAddDocInfoSec, sectionFields.get(strAddDocInfoSec));
			userFields.put(strSysInfoSec, mergeFields(sectionFields.get(strSysInfoSec), "Submitter Fax Number"));
			break;

		case "SYS":

			userFields.put(strDetailsSec, sectionFields.get(strDetailsSec));
			userFields.put(strRelatedInfoSec, sectionFields.get(strRelatedInfoSec));
			userFields.put(strAddDocInfoSec, mergeFields(sectionFields.get(strAddDocInfoSec), "Submitter Fax Number"));
			userFields.put(strSysInfoSec, sectionFields.get(strSysInfoSec));
			break;

		case "CM":

			userFields.put(strDetailsSec, sectionFields.get(strDetailsSec));
			userFields.put(strRelatedInfoSec, mergeFields(sectionFields.get(strRelatedInfoSec), "Patient",
					"Case Manager", "Care Program Product", "Reviewed by CM"));
			userFields.put(strAddDocInfoSec, sectionFields.get(strAddDocInfoSec));
			userFields.put(strSysInfoSec, mergeFields(sectionFields.get(strSysInfoSec), "Submitter Fax Number"));
			break;

		default:
			Log.info("Unknown user type");
			return;
		}

		// Validate the fields for the given user
		if (userFields.containsKey(sectionToValidate)) {
			String[] fields = userFields.get(sectionToValidate);
			LoggingInfo("validating fields in " + sectionToValidate + " for user " + userType);
			System.out.println("Validating fields in " + sectionToValidate + " for user " + userType);

			// Validate each field in the section
			for (String field : fields) {
				try {
					// Generate dynamic XPath based on sectionName and field
					String xpath = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//parent::button//parent::h3//parent::div//following-sibling::div//*[text()=\"{1}\"]";
					By fieldName = getDynamicElement(xpath, sectionToValidate, field);
					scrollToElement(fieldName);
					highLightElement(fieldName);
					boolean found = isElementDisplayed(fieldName);
					Assert.assertTrue(found);
					LoggingInfo(field + " - Field is present on " + sectionToValidate + " layout");

				} catch (NoSuchElementException e) {
					LoggingInfo("Field " + field + " not found in " + sectionToValidate + " for user " + userType);
				}
			}
		} else {
			LoggingInfo("Section " + sectionToValidate + " not found for user " + userType);
		}
	}

	// Helper method to merge existing fields with additional fields for
	// ReceivedDocPageFieldValidation
	private String[] mergeFields(String[] existingFields, String... additionalFields) {
		List<String> allFields = new ArrayList<>();
		for (String field : existingFields) {
			allFields.add(field);
		}
		for (String additionalField : additionalFields) {
			allFields.add(additionalField);
		}
		return allFields.toArray(new String[0]);
	}

	/**
	 * Function: Verify Correspondence object Layout/fields.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyCorrespondenceFields() throws Exception {

		String[] inputLabels = { "Recipient Details", "Vendor ID" };

		try {
			for (String inputLabel : inputLabels) {
				By fieldName = getDynamicElement(strCaseFields, inputLabel);
				scrollToElement(fieldName);
				boolean found = isElementPresent(fieldName);
				highLightElement(fieldName);
				Assert.assertTrue(found);
				LoggingInfo("Field is present on Correspondence layout- " + inputLabel);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Field " + e.getMessage());
			Assert.fail("Failed to verify Field " + e.getMessage());
		}
	}

	/**
	 * Function: Click on List View dropdown of CPE object
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void ClicklistViewdropdownofCPEobject() {
		try {
			refresh();
			Log.info("Click on List View dropdown of CPE object");
			click(eleListView);
			waitForPageLoaded();
			LoggingInfo("Clicked on List View dropdown of CPE object");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on ListView dropdown " + e.getMessage());
			Assert.fail("Failed to Click on ListView dropdown " + e.getMessage());
		}

	}

	/**
	 * Function: Validate Filters on ListView
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateListViewFilters(String listOption) {

		String listView = String.format("//*[text()=\"%s\"]//parent::a", listOption);
		boolean objectPresent = verifyObjectPresentOrNot(By.xpath(listView));
		if (objectPresent) {
			highLightElement(By.xpath(listView));
			LoggingInfo(listOption + " Filter is present in CPE drop-down");
		} else {
			LoggingInfo(listView + " Filter is not present in CPE drop-down");
		}

	}

	public void validateListView(String listOption) {

		String listView = String.format("//*[text()=\"%s\"]", listOption);
		boolean objectPresent = verifyObjectPresentOrNot(By.xpath(listView));
		if (objectPresent) {
			highLightElement(By.xpath(listView));
			LoggingInfo(listOption + " Filter is present in CPE drop-down");
		} else {
			LoggingInfo(listView + " Filter is not present in CPE drop-down");
		}

	}

	/**
	 * Function: Verify Columns Header on page
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyColumnsHeader(String[] columnHeaders) {
		try {
			for (String inputLabel : columnHeaders) {
				By fieldName = getDynamicElement(strColumn, inputLabel);
				boolean found = isElementPresent(fieldName);
				highLightElement(fieldName);
				Assert.assertTrue(found);
				LoggingInfo(inputLabel + " -Column is present on layout");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Column not present on layout " + e.getMessage());
			Assert.fail("Column not present on layout " + e.getMessage());
		}
	}

	// Anand P
	public void verifyColumnsHeaderCases(String[] columnHeaders) {
		try {
			for (String inputLabel : columnHeaders) {
				By fieldName = getDynamicElement(strColumnCase, inputLabel);
				boolean found = isElementPresent(fieldName);
				highLightElement(fieldName);
				Assert.assertTrue(found);
				LoggingInfo(inputLabel + " -Column is present on layout");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Column not present on layout " + e.getMessage());
			Assert.fail("Column not present on layout " + e.getMessage());
		}
	}

	/**
	 * Function: Open Exisitng CPE Record.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void openExistingdoc() throws Exception {
		try {
			waitAndVerifyElement(eleExisitngCPERecord);
			scrollToElement(eleExisitngCPERecord);
			clickByJavascript(eleExisitngCPERecord);
			LoggingInfo("Existing CPE record opened successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Open Existing CPE Record " + e.getMessage());
			Assert.fail("Failed to Open Existing CPE Record " + e.getMessage());
		}

	}

	/**
	 * Function: Validate Account Object Fields
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateAccountObjFields() throws Exception {

		String logElements = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//ancestor::records-record-layout-item//lightning-formatted-text";

		By eleStatus = getDynamicElement(logElements, "Status");
		scrollToElement(eleStatus);
		String status = getText(eleStatus);
		if (status.contains("Active")) {
			boolean condition = true;
			highLightElement(eleStatus);
			Assert.assertTrue(condition, "Status is Active");
		} else {
			Assert.fail("Status is " + status);
		}

		By eleSource = getDynamicElement(logElements, "Source System");
		scrollToElement(eleSource);
		String source = getText(eleSource);
		if (source.contains("Cencora")) {
			boolean condition = true;
			highLightElement(eleSource);
			Assert.assertTrue(condition, "Source System is Cencora");
		} else {
			Assert.fail("Source System is " + source);
		}

		By eleLegacy = getDynamicElement(logElements, "Legacy Id");
		scrollToElement(eleLegacy);
		String legacy = getText(eleLegacy);
		if (!legacy.isEmpty()) {
			boolean condition = true;
			highLightElement(eleLegacy);
			Assert.assertTrue(condition, "Legacy Id is True/Present");
		} else {
			Assert.fail("Legacy Id is False/Not Present");
		}
		LoggingInfo("Account Object Fields Validate Successfully");
	}

	/**
	 * Function: Navigate to List of CPE
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void navigateToListofCPE(String strlistName) {
		try {

			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, strlistName);
			setTimeOut(5000);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(5000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(9000);

			// String strlist = "(//*[text()=\"{0}\"]//parent::a)[1]";
			// By eleList = getDynamicElement(strlist, strlistName);
			// click(eleList);
			// waitForPageLoaded();
			LoggingInfo("Navigated to" + strlistName + " list");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to " + strlistName + e.getMessage());
			Assert.fail("Failed to navigate to " + strlistName + e.getMessage());
		}
	}

	public void navigateToListofCPEAdmin(String strlistName) {
		try {

			String strlist = "(//*[text()=\"{0}\"]//parent::a)[1]";
			By eleList = getDynamicElement(strlist, strlistName);
			click(eleList);
			waitForPageLoaded();
			LoggingInfo("Navigated to" + strlistName + " list");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to " + strlistName + e.getMessage());
			Assert.fail("Failed to navigate to " + strlistName + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to List of CPE All Migrated (Maintainence)
	 * 
	 * @author Anand Pawar
	 **/

	public void navigateToListofCPEAllMigrated(String strlistName) {
		try {

			refresh();
			Log.info("Navigate to All Migrated CPE");
			click(eleListView);
			waitForPageLoaded();

			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, strlistName);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

			LoggingInfo("Navigated to" + strlistName + " list");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to " + strlistName + e.getMessage());
			Assert.fail("Failed to navigate to " + strlistName + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to List of CPE Care Program Products (Maintainence)
	 * 
	 * @author Anand Pawar
	 **/
	public void navigateToListofCPEListView(String strlistName) {
		try {
			// String strlist = "(//*[text()=\"{0}\"]//parent::a)[1]";
			// By eleList = getDynamicElement(strlist, strlistName);
			// click(eleList);

			Log.info("Navigate to All Care Program Products Worklist");
			click(listViewButtonproducts);
			waitForPageLoaded();

			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, strlistName);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

			LoggingInfo("Navigated to" + strlistName + " list");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to " + strlistName + e.getMessage());
			Assert.fail("Failed to navigate to " + strlistName + e.getMessage());
		}
	}

	/**
	 * Function: Click on List View dropdown of CPE object
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void ClicklistViewdropdownobject(String objectName) {
		try {
			setTimeOut(4000);
			String ss = "//button[@title='Select a List View: " + objectName + "']";
			Log.info("Click on List View dropdown object");
			click(By.xpath(ss));
			waitForPageLoaded();
			LoggingInfo("Clicked on List View dropdown object");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on ListView dropdown " + e.getMessage());
			Assert.fail("Failed to Click on ListView dropdown " + e.getMessage());
		}

	}

	// Anand P
	public void verifyCaseRecordNotVisibleAsDMWNurseEducatorListView(String objectName) {
		try {
			By noRecordMsg = By.xpath("//*[text()=\"Nothing to see here\"]");
			waitAndVerifyElement(noRecordMsg);
			scrollToElement(noRecordMsg);
			highLightElement(noRecordMsg);

			LoggingInfo("No Record message verified successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("No Record message not found " + e.getMessage());
			Assert.fail("No Record message not found  " + e.getMessage());
		}

	}

	/**
	 * Function: Validate Records present
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateRecordPresent(String recName) throws Exception {
		scrollToBottomOfPage();
		try {
			By eleRecord = getDynamicElement(strRecord, recName);
			if (verifyObjectPresentOrNot(eleRecord)) {
				scrollToElement(eleRecord);
				highLightElement(eleRecord);
				LoggingInfo(recName + " Product is present in Master Record");
			} else {
				LoggingInfo(recName + " Product is not present in Master Record");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Record " + e.getMessage());
			Assert.fail("Failed to validate Record " + e.getMessage());
		}

	}

	public void verifyCPEspField(String spName) throws Exception {
		String logElements = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//ancestor::records-record-layout-item//lightning-formatted-text";

		By eleStatus = getDynamicElement(logElements, "Care Program Enrollee Product SP Name");
		scrollToElement(eleStatus);
		String status = getText(eleStatus);
		if (status.contains(spName)) {
			boolean condition = true;
			highLightElement(eleStatus);
			Assert.assertTrue(condition,
					"SP record validated successfully in the Care Program Enrollee Product Object Related List.");
			LoggingInfo("SP record validated successfully in the Care Program Enrollee Product Object Related List.");
		} else {
			Assert.fail("Failed to validate SP record " + status);
		}
	}

	public void switchtoRequiredTab(String tabName) {
		String ss = "//a[@title=\"{0}\"]";
		try {
			setTimeOut(2000);
			By eleTab = getDynamicElement(ss, tabName);
			waitAndVerifyElement(eleTab);
			clickByJavascript(eleTab);
			setTimeOut(2000);
			LoggingInfo("User switched to " + tabName + " successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to switch to Received document" + e.getMessage());
			Assert.fail("Failed to switch to Received document " + e.getMessage());
		}
	}

	public void validateNoNewSPRecord() {
		By eleSPrec = By.xpath("//*[@aria-label='Care Program Enrollee Product SPs']//tbody//tr");
		try {
			if (getWebDriver().findElements(eleSPrec).size() < 2) {
				scrollToElement(eleSPrec);
				LoggingInfo("No New SP record is present");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Function: Validate Source SourceChannel Status and DOC# of an document.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateDOcdetails(String docID) {

		String documentId = getText(eleDocId);
		if (documentId.contains(docID)) {
			boolean condition = true;
			highLightElement(eleDocId);
			Assert.assertTrue(condition, "Document # is auto generated and populated.");
			LoggingInfo("Document # is " + documentId);
		} else {
			Assert.fail("Document # is not auto generated.");
		}

		By eleSource = getDynamicElement(strSource, docID);
		String source = getText(eleSource);
		if (source.contains("DupixentMyWay Portal")) {
			boolean condition = true;
			highLightElement(eleSource);
			Assert.assertTrue(condition, "Source is DupixentMyWay Portal");
			LoggingInfo("Source is " + source);
		} else {
			Assert.fail("Expected Source not found ");
		}

		By eleSourceChnl = getDynamicElement(strSourceChnl, docID);
		String sourceChnl = getText(eleSourceChnl);
		if (sourceChnl.contains("Web")) {
			boolean condition = true;
			highLightElement(eleSourceChnl);
			Assert.assertTrue(condition, "Source Channel is Web");
			LoggingInfo("Source Channel is " + sourceChnl);

		} else {
			Assert.fail("Expected Source Channel not found");
		}

		By eleStatus = getDynamicElement(strStatus, docID);
		String status = getText(eleStatus);
		if (status.contains("Draft")) {
			boolean condition = true;
			highLightElement(eleStatus);
			Assert.assertTrue(condition, "Status is Draft");
			LoggingInfo("Status is " + status);
			System.out.println("Status is Draft");
		} else {
			Assert.fail("Expected Status not found");
		}
	}

	public void validateDocumentPageLayout() {
		try {

			boolean docTab = isElementDisplayed(documentTab);
			Assert.assertTrue(docTab, "Document PDF tab not found");
			boolean deatilsTab = isElementDisplayed(detailsTab);
			Assert.assertTrue(deatilsTab, "Details tab not found");
			boolean related = isElementDisplayed(relatedTab);
			Assert.assertTrue(related, "Related tab not found");
			LoggingInfo("Document PDF,Related list and details tab are displayed");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Function: Verify site record is present on CPE
	 * 
	 * @author Trupti Zure
	 **/
	public boolean verifySiteRecordIsPresent() {
		boolean found = false;
		try {

			setTimeOut(2000);
			By siteRecord = getDynamicElement(cpeDetailsLinkField, "Site");
			waitAndVerifyElement(siteRecord);
			String site = getText(siteRecord);
			found = !site.isEmpty();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify site details " + e.getMessage());
			Assert.fail("Failed to verify site details " + e.getMessage());

		}
		return found;

	}

	/**
	 * Function: Verify Fax is present on Site Record
	 * 
	 * @author Trupti Zure
	 **/

	public boolean verifyFaxIsPresent() {
		boolean found = false;
		try {
			waitAndVerifyElement(eleSite);
			scrollToElement(eleSite);
			clickByJavascript(eleSite);
			By faxRecord = getDynamicElement(accDetailsLinkField2, "Fax");
			waitAndVerifyElement(faxRecord);
			String fax = getText(faxRecord);
			found = !fax.isEmpty();

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify fax details " + e.getMessage());
			Assert.fail("Failed to verify fax details " + e.getMessage());

		}
		return found;

	}

	/**
	 * Function: Verify generate document screen
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyGenerateDocScreen(String docname) {
		try {
			Log.info("Verify Generate Document Screen");
			setTimeOut(9000);
			By docscreen = getDynamicElement(generateDoc, docname);
			waitAndVerifyElement(docscreen);
			LoggingInfo("User verify Generate Document Screen successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Generate Document Screen " + e.getMessage());
			Assert.fail("Failed to verify Generate Document Screen  " + e.getMessage());
		}
	}

	/**
	 * Function: Click on correspondence
	 * 
	 * @author Kavyashree MB
	 **/

	public void clickOncorrespondence() {
		try {

			waitAndVerifyElement(eleCORElement);
			scrollToElement(eleCORElement);
			clickByJavascript(eleCORElement);
			setTimeOut(2000);
			LoggingInfo("Clicked on correspondence succesfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on correspondence " + e.getMessage());
			Assert.fail("Failed to Click on correspondence  " + e.getMessage());
		}
	}

	/**
	 * Function: Click on HCP
	 * 
	 * @author Anand
	 **/

	public void clickOnHCPLink() {
		try {

			By eleHCP = By.xpath("(//th[@data-label=\"Account Name\"]//a)[3]");
			waitAndVerifyElement(eleHCP);
			scrollToElement(eleHCP);
			clickByJavascript(eleHCP);
			setTimeOut(2000);
			LoggingInfo("Clicked on HCP succesfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on HCP " + e.getMessage());
			Assert.fail("Failed to Click on HCP  " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Items to send
	 * 
	 * @author Anand Pawar
	 **/
	public void verifyItemsToSend(String selectItem) {
		try {

			setTimeOut(4000);
			By selectItemsToSendDropdown = getDynamicElement(strDropDownSelectItemsToSend, "Select Items to Send");
			waitAndVerifyElement(selectItemsToSendDropdown);
			scrollToElement(selectItemsToSendDropdown);
			click(selectItemsToSendDropdown);
			By selectItemsToSendDropdownOptions = getDynamicElement(searchDropDownOptions, "Select Items to Send");
			waitAndVerifyElement(selectItemsToSendDropdownOptions);

			ArrayList<String> pickListValues = new ArrayList<>(
					Arrays.asList("DMW Notification of Accelerated Rx Triage - MD Fax",
							"DMW Medi-Cal Rx Notification of Accelerated Rx Triage - MD Fax"));

			for (String pickListValue : pickListValues) {
				String strFilterValue = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Select Items to Send\"]//parent::div//following-sibling::div//li//child::span[(text()='%s')]";
				String xp = String.format(strFilterValue, pickListValue);
				By eleSearchFilterValue = By.xpath(xp);
				scrollToElement(eleSearchFilterValue);
				highLightElement(eleSearchFilterValue);
				setTimeOut(2000);

			}

			selectItemFromList(selectItemsToSendDropdown, selectItemsToSendDropdownOptions, selectItem,
					"Select Items to Send");
			setTimeOut(1000);
			LoggingInfo("Selected Items To Send as-" + selectItem);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select Items To Send " + e.getMessage());
			Assert.fail("Failed to select Items To Send " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Correspondence code
	 * 
	 * @author Kavyashree MB
	 **/

	public void verifyDUP(String DUPCode) {
		try {
			setTimeOut(4000);
			waitAndVerifyElement(eleDUP);
			scrollToElement(eleDUP);
			String CORCode = getText(eleDUP);
			if (DUPCode.equalsIgnoreCase(CORCode)) {
				LoggingInfo("Verified Correspondence code");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Correspondence code " + e.getMessage());
			Assert.fail("Failed to verify Correspondence code  " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Correspondence name
	 * 
	 * @author Anand
	 **/

	public void verifyCorresName() {
		try {

			By eleName = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"DMW PAP Approval Medicare Enrollee - Payer Fax\"]");
			setTimeOut(4000);
			waitAndVerifyElement(eleName);
			highLightElement(eleName);
			LoggingInfo("Verified Correspondence Name");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Correspondence name " + e.getMessage());
			Assert.fail("Failed to verify Correspondence name  " + e.getMessage());
		}
	}

	/**
	 * Function: Verify recepient details
	 * 
	 * @author Anand Pawar
	 **/

	public void verifyRecepient(String recepient) {
		try {
			By eleRec = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Recipient Details\"]//parent::div//following-sibling::div//lightning-formatted-text");
			setTimeOut(4000);
			waitAndVerifyElement(eleRec);
			scrollToElement(eleRec);
			String CORCode = getText(eleRec);
			if (CORCode.equalsIgnoreCase(recepient)) {
				LoggingInfo("Receipent Details verified");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
			Assert.fail("Failed to verify   " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Correspondence code
	 * 
	 * @author Tejal
	 **/
	public void DUPCodeIsPopulated() {
		try {

			By messageInputField = getDynamicElement(correspondenceInputField, "Correspondence Code");
			waitAndVerifyElement(messageInputField);
			scrollToElement(messageInputField);
			String message = getText(messageInputField);
			Assert.assertFalse(message.isEmpty(), "The message field is empty or null.");
			LoggingInfo("The message field is populated");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to verify message " + e.getMessage());
			Assert.fail("Failed to verify message: " + e.getMessage());
		}
	}

	/**
	 * Function : Validate Records present in CPE related List tables
	 *
	 * @author Shanavaz Nishani
	 **/
	public void validatedata(String tableName, String fileName) {
		scrollToHalfPage();
		careProgram.clickOnViewAll(tableName);
		List<WebElement> rows = getWebDriver().findElements(By.xpath(
				"//table[@aria-label='" + tableName + "']//tbody//tr//th//a//span[contains(text(),'Automation')]"));
		if (rows.size() > 0) {
			for (WebElement row : rows) {
				String text = row.getText();
				if (!text.contains(fileName)) {
					LoggingInfo("Document is not present in :" + tableName);

				} else {
					LoggingInfo("Document is present in :" + tableName);
				}

			}
		}
	}

	/**
	 * Function: Open Exisitng Case Record.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void openRecentCase() throws Exception {
		try {
			waitAndVerifyElement(eleRecentCase);
			scrollToElement(eleRecentCase);
			clickByJavascript(eleRecentCase);
			LoggingInfo("Existing Case record opened successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Open Existing Case Record " + e.getMessage());
			Assert.fail("Failed to Open Existing Case Record " + e.getMessage());
		}

	}

	/**
	 * Function: Validate Resend Button
	 * 
	 * @author Sonica P
	 **/
	public void validateResendBtn() {
		try {
			waitAndVerifyElement(eleResendBtn);
			LoggingInfo("Resend Button validated successfully");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate resend button " + e.getMessage());
			Assert.fail("Failed to validate resend button " + e.getMessage());
		}
	}

	public void statusCheckFail() {
		try {

			setTimeOut(3000);
			By messageInputField = getDynamicElement(correspondenceInputField, "Request Status");
			scrollToElement(messageInputField);
			waitAndVerifyElement(messageInputField);

			String requestStatus = getText(messageInputField);

			Log.info("Request Status value: '" + requestStatus + "'");

			if (requestStatus.equalsIgnoreCase("Failure")) {
				Log.info("Request Status is valid (Failure). Test Passed.");
			} else {
				Log.error("Request Status is invalid: " + requestStatus);
				Assert.fail("Request Status should be Failure Found: '" + requestStatus + "'");
			}

		} catch (Exception e) {
			Log.error("Failed to verify status " + e.getMessage());
			Assert.fail("Failed to verify status: " + e.getMessage());
		}
	}

	
	/**
	 * Function: Validate Nursing Error Msg
	 *
	 * @author Shanavaz Nishani
	 **/
	public void validateNursingErrorMsg(String expectedError) {
		try {
			// String expectedError = "ACC-VR37: Phone only accepts 10-digit number.";
			String strMsg = "//*[text()=\"{0}\"]";
			By errorMsg = getDynamicElement(strMsg, expectedError);
			waitAndVerifyElement(errorMsg);
			scrollToElement(errorMsg);
			highLightElement(errorMsg);
			String actualError = getText(errorMsg);
			Assert.assertEquals(expectedError, actualError, "Error message validated successfully");
 
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate error message" + ". Error - " + e.getMessage());
 
		}
 
	}
	/**
	 * Function: Navigate to Cases table
	 * 
	 * @author Sonica P
	 **/
	public void navigateToCasesSection() {
		try {
			waitAndVerifyElement(eleCasesTable);
			scrollToElement(eleCasesTable);
			setTimeOut(3000);
			scrollToElement(eleCasesTable);
			setTimeOut(1000);
			clickByJavascript(eleCasesTable);
			// scrollToBottomOfPage();
			LoggingInfo("Navigated to cases table");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Navigated to correspondence table " + e.getMessage());
			Assert.fail("Navigated to correspondence table " + e.getMessage());
		}
	}

	public void statusCheck() {
		try {

			setTimeOut(6000);
			By messageInputField = getDynamicElement(correspondenceInputField, "Request Status");
			scrollToElement(messageInputField);
			waitAndVerifyElement(messageInputField);

			String requestStatus = getText(messageInputField).trim();

			Log.info("Request Status value: '" + requestStatus + "'");

			if (requestStatus.equalsIgnoreCase("Success") || requestStatus.isEmpty()) {
				Log.info("Request Status is valid (Success or Blank). Test Passed.");
			} else {
				Log.error("Request Status is invalid: " + requestStatus);
				Assert.fail("Request Status should be either blank or 'Success'. Found: '" + requestStatus + "'");
			}

		} catch (Exception e) {
			Log.error("Failed to verify message " + e.getMessage());
			Assert.fail("Failed to verify message: " + e.getMessage());
		}
	}

	/**
	 * Function: Validate failed status
	 * 
	 * @author Sonica P
	 **/
	public void validateStatusFailed(String expectedStatusFailed) {
		try {
			waitAndVerifyElement(eleFailedStatus);
			String actualErrorMsg = getText(eleFailedStatus);
			Assert.assertEquals(actualErrorMsg, expectedStatusFailed, "Error message mismatch. Expected: '"
					+ expectedStatusFailed + "', but got: '" + actualErrorMsg + "'");
			LoggingInfo("Failed status validated successfully");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate status " + e.getMessage());
			Assert.fail("Failed to validate status " + e.getMessage());
		}
	}

	/**
	 * Function: Validate the Correspondence fields-Service Area
	 * 
	 * @author Sonica P
	 **/
	public void validateCorrespondenceFieldsServiceArea(String serviceArea) {
		String[] fieldsLabels = { "Service Area" };
		String[] fieldsValues = { serviceArea };

		try {
			for (int i = 0; i < fieldsLabels.length; i++) {
				By fieldLocator = getDynamicElement(correspondenceInputField, fieldsLabels[i]);
				scrollToElement(fieldLocator);
				verifyHardAssertInputFieldBox(fieldLocator, fieldsValues[i], fieldsLabels[i]);
				setTimeOut(2000);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Validation of Correspondence section failed: " + e.getMessage());
		}
	}

	public void clickCorrespondenceRec() {
		try {
			waitAndVerifyElement(eleCorrRec);
			click(eleCorrRec);
			setTimeOut(2000);
			LoggingInfo("User clicks on Correspondence record");
		} catch (Exception e) {
			Log.error("Failed to click on correspondence record: " + e.getMessage());
			Assert.fail("Failed to click on correspondence record: " + e.getMessage());

		}
	}
	
	public void validateEditSiteRCMID() {
		try {
			
			By edit=By.xpath("//*[@title=\"Edit RCM ID\"]");
			scrollToElement(edit);
			click(edit);
			
			By inpRCM=By.xpath("//*[@name=\"RCMID_ICC__c\"]");
		    click(inpRCM);
			inputText(inpRCM,"123456789");
			
			By phone=By.xpath("//*[@name=\"Phone\"]");
			scrollToElement(phone);
			click(phone);
			
			missingInformatioPage.clickOnSaveButton();

			
			
			By rcmidField = getDynamicElement(correspondenceInputField, "RCM ID");

			waitAndVerifyElement(rcmidField);
			scrollToElement(rcmidField);

			String rcmIdValue = getWebDriver().findElement(rcmidField).getText();
			Log.info("RCM ID value retrieved: " + rcmIdValue);

			if (!rcmIdValue.contains(",")) {
				Log.info("RCM ID is valid (no commas present): " + rcmIdValue);
			} else {
				Log.error("RCM ID is invalid (contains commas): " + rcmIdValue);
				Assert.fail("RCM ID contains commas: " + rcmIdValue);
			}

		} catch (Exception e) {
			Log.error("Failed to verify RCM ID: " + e.getMessage());
			Assert.fail("Failed to verify RCM ID: " + e.getMessage());
		}
	}

	public void validateRCMID() {
		try {
			By rcmidField = getDynamicElement(correspondenceInputField, "RCM ID");

			waitAndVerifyElement(rcmidField);
			scrollToElement(rcmidField);

			String rcmIdValue = getWebDriver().findElement(rcmidField).getText();
			Log.info("RCM ID value retrieved: " + rcmIdValue);

			if (!rcmIdValue.contains(",")) {
				Log.info("RCM ID is valid (no commas present): " + rcmIdValue);
			} else {
				Log.error("RCM ID is invalid (contains commas): " + rcmIdValue);
				Assert.fail("RCM ID contains commas: " + rcmIdValue);
			}

		} catch (Exception e) {
			Log.error("Failed to verify RCM ID: " + e.getMessage());
			Assert.fail("Failed to verify RCM ID: " + e.getMessage());
		}
	}

	public void validateResendBtnIsHidden() {
		try {
			setTimeOut(2000);
			WebElement resendButton = getWebDriver().findElement(eleResendBtn);
			Assert.assertFalse(resendButton.isDisplayed(), "Resend Button should be hidden, but it is visible");

			LoggingInfo("Verified: Resend Button is hidden as required");

		} catch (NoSuchElementException e) {
			LoggingInfo("Verified: Resend Button is absent, as expected (hidden)");

		} catch (Exception e) {

			LoggingInfo("Failed to verify Resend Button is hidden: " + e.getMessage());
		}
	}

	/**
	 * Function: This functions opens a correspondece record and checkes if it has
	 * Failed correspondence, if not then it will return to CPE page and selects the
	 * next record.(Continues until the failed correspondece CPE found).
	 * 
	 * @author SHanavaz Nishani
	 **/
	public void openCPEwithFailedCorrespondence() throws InterruptedException {

		List<WebElement> CPERecords = getWebDriver().findElements(By.xpath("//th[@data-label='Name']//a"));
		boolean failedStatusCorrespondence = false;

		for (WebElement record : CPERecords) {
			record.click();
			setTimeOut(2000);
			accountObject.clickOnTab(tabsName.get(1));
			setTimeOut(2000);
			navigateToCorrespondenceTable();
			setTimeOut(2000);
			// careProgram.clickOnViewAll("Correspondences");

			List<WebElement> correspondenceRecords = getWebDriver().findElements(By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[@aria-label=\"Correspondences\"]//tbody//tr//th"));
			if (correspondenceRecords.size() == 0) {
				Log.info("No Correspondence Records found for this CPE.");
				switchtoRequiredTab("Care Program Enrollees");
				setTimeOut(2000);
				continue;
			}
			boolean failedStatus = false;

			if (correspondenceRecords.size() > 0) {
				for (WebElement correspondenceRecord : correspondenceRecords) {
					String status = correspondenceRecord
							.findElement(By.xpath(".//ancestor::th//following-sibling::td[3]//span")).getText().trim();
					if (status.contains("Failed")) {
						LoggingInfo("User is able to see details of Care Program Enrollee Record");
						failedStatus = true;
						scrollToWebElement(correspondenceRecord);
						WebElement link = correspondenceRecord
								.findElement(By.xpath(".//div[contains(@class,'slds-grid')]//a"));
						setTimeOut(5000);
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].style.border='3px solid red'",
								link);
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", link);
						setTimeOut(5000);
						LoggingInfo("Correspondence record with Failed status opened successfully");
						break;
					}
				}

				if (failedStatus) {
					failedStatusCorrespondence = true;
					break;
				} else {
					Log.info("No Failed Correspondence Records found for this CPE.");
					switchtoRequiredTab("Care Program Enrollees");

				}
			}

		}
		if (!failedStatusCorrespondence) {
			Log.info("No Failed Correspondence Records found for any CPE.");
			Assert.fail("No Failed Correspondence Records found for any CPE.");
		}
	}

	/**
	 * Function: This method verifies the Filed value
	 * 
	 * @author SHanavaz Nishani
	 **/
	public void validateFieldValue(String fieldName, String fieldValue) throws Exception {

		By eleFieldLocator = getDynamicElement(strField, fieldName);
		scrollToElement(eleFieldLocator);
		String actualFieldValue = getText(eleFieldLocator).trim();
		if (actualFieldValue.contains(fieldValue)) {
			Log.info("Field value is as expected: " + actualFieldValue);
			LoggingInfo("Field value is as expected: " + actualFieldValue);
		} else {
			Log.error("Field value mismatch. Expected: " + fieldValue + ", but got: " + actualFieldValue);
			Assert.fail("Field value mismatch. Expected: " + fieldValue + ", but got: " + actualFieldValue);
		}

	}

	/**
	 * Function: Verify adn click on Resend Button
	 * 
	 * @author SHanavaz Nishani
	 **/
	public void clickOnResendBtn() throws Exception {
		try {
			waitAndVerifyElement(eleResendBtn);
			LoggingInfo("Resend Button validated successfully");
			setTimeOut(4000);
			scrollToElement(eleResendBtn);
			click(eleResendBtn);
			LoggingInfo("Clicked on Resend Button successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate resend button " + e.getMessage());
			Assert.fail("Failed to validate resend button " + e.getMessage());
		}
	}

	/**
	 * Function: Click on Finish Button after Resend Btn is clicked
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void clickOnResendFinishBtn() {
		try {

			setTimeOut(2000);
			waitAndVerifyElement(eleResendFinishBtn);
			click(eleResendFinishBtn);
			LoggingInfo("Clicked on Finish Button successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click Finish button " + e.getMessage());
			Assert.fail("Failed to click Finish button " + e.getMessage());
		}

	}

	/**
	 * Function: Validate Last Modified By field(has current User)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateLastModifiedField(String user) throws Exception {

		By eleLastModified = getDynamicElement(strLastModified, "Last Modified By");
		scrollToElement(eleLastModified);
		String lastModified = getText(eleLastModified).trim();
		if (lastModified.equalsIgnoreCase(user)) {
			Log.info("Last Modified By field is updated with Current User: " + lastModified);
			LoggingInfo("Last Modified By field is updated with Current User: " + lastModified);
		} else {
			Log.error("Last Modified By field value not updated to Current User. Expected: " + user + ", but got: "
					+ lastModified);
			Assert.fail("Last Modified By field value not updated to Current User. Expected: " + user + ", but got: "
					+ lastModified);
		}

	}

	/**
	 * Function: Selecrt Triage value from the dropdown
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void editSelectedTriage(String triageValue) throws Exception {

		try {
			By selectedTriageEdit = getDynamicElement(editButton, "Selected for Triage");
			waitAndVerifyElement(selectedTriageEdit);
			scrollToElement(selectedTriageEdit);
			setTimeOut(2000);
			click(selectedTriageEdit);

			By authorizationStatus = getDynamicElement(strAuthorizationFormStatusValue, "Selected for Triage");
			scrollToElement(authorizationStatus);
			setTimeOut(1000);

			selectItemFromDropdown(strAuthorizationFormStatusValue, strStatusListValue, "Selected for Triage",
					triageValue);
			LoggingInfo("User selects " + triageValue + " from the dropdown Selected for Triage");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Select value from the dropdown " + e.getMessage());
			Assert.fail("Failed to Select value from the dropdown " + e.getMessage());
		}

	}
	
	
	public void clickOnshowMoreActionsButton() {
	try {
		scrollToElement(eleShowMoreActions);
		setTimeOut(2000);
		waitAndVerifyElement(eleShowMoreActions);
		click(eleShowMoreActions);
		LoggingInfo("Clicked on 'CPE Status Button'");
		setTimeOut(2000);
	} catch (Exception e) {
		Log.error("Failed to click On CPE Status Button " + e.getMessage());
		Assert.fail("Failed to click On CPE Status Button" + e.getMessage());
	}
}


	public void clickOnCPEStatusButton() {
		try {
			
			waitAndVerifyElement(eleCPEStatusButton);
			scrollToElement(eleCPEStatusButton);
			click(eleCPEStatusButton);
			LoggingInfo("Clicked on 'CPE Status Button'");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click On CPE Status Button " + e.getMessage());
			Assert.fail("Failed to click On CPE Status Button" + e.getMessage());
		}
	}

	public void clickOnInactivationReason(String InactivationReason) {
		try {
			waitAndVerifyElement(eleinactiveButton);
			scrollToElement(eleinactiveButton);

			click(eleinactiveButton);

			for (String reason : InactivationReasons) {
				validateListView(reason);
			}
			By eleCPEInactiveReason = getDynamicElement(strCPEUpdateDropdown, "Inactivation_Reason");
			waitAndVerifyElement(eleCPEInactiveReason);
			selectItemFromList(eleCPEInactiveReason, InactivationReason);
			Log.info("Selected Inactivation Reason: " + InactivationReason);

			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click On CPE Status Button " + e.getMessage());
			Assert.fail("Failed to click On CPE Status Button" + e.getMessage());
		}
	}

	public void selectUnenrollPatBox(String consent) {
		String strUnenrollConfirmBtn = "//*[contains(@class,\"active lafPageHost\")]//span[@class=\"slds-radio\"]//input[@value=\"{0}\"]//parent::span//child::span[@class=\"slds-radio_faux\"]";

		By eleUnenrollConfirmBtn = getDynamicElement(strUnenrollConfirmBtn, consent);
		waitAndVerifyElement(eleUnenrollConfirmBtn);
		clickByJavascript(eleUnenrollConfirmBtn);
		Log.info("Clicked on Unenroll Patient confirmation button: " + consent);
	}

	/**
	 * Function: Change Member Plan Status to Active
	 * 
	 * @author Anand Pawar
	 **/

	public void changeMemberPlanStatusActive(String memberPlan) {
		try {
			By record = getDynamicElement(memPlan, memberPlan);
			scrollToElement(record);
			waitAndVerifyElement(record);
			clickByJavascript(record);

			By editStatus = getDynamicElement(eleEdit, "Edit Status");
			scrollToElement(editStatus);
			waitAndVerifyElement(editStatus);
			clickByJavascript(editStatus);

			if (memberPlan.equalsIgnoreCase(pharamcyMember.get(0))
					|| memberPlan.equalsIgnoreCase(pharamcyMember.get(4))) {
				selectMemberPlanStatus("Active");

				By planId = getDynamicElement(strTextBoxesInput, "Plan ID");
				scrollToElement(planId);
				waitAndVerifyElement(planId);
				inputText(planId, "plan");

				By dobDate = getDynamicElement(strTextBoxesInput, "Policyholder DOB");
				scrollToElement(dobDate);
				waitAndVerifyElement(dobDate);
				String dob = getNthPastDayFromToday(1000);
				inputText(dobDate, dob);

				By insuranceAddDate = getDynamicElement(strTextBoxesInput, "Insurance Add Date");
				scrollToElement(insuranceAddDate);
				waitAndVerifyElement(insuranceAddDate);
				String date = getDateNDaysFromToday(0);
				inputText(insuranceAddDate, date);

				click(planId);

			} else {

				selectMemberPlanStatus("Active");
			}

			setTimeOut(5000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed click on record" + e.getMessage());
			Assert.fail("Failed click on record" + e.getMessage());

		}
	}

	/**
	 * Function: Get Welcome cases count from the cases table
	 * 
	 * @author Shanavaz Nishani
	 **/
	public int verifyWelcomeCases() {
		int numberOfWelcomeCases = 0;
		try {
			List<WebElement> welcomeCases = getWebDriver().findElements(By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Cases\"]//tbody//tr//td//span[contains(text(),\"Welcome\")]"));
			numberOfWelcomeCases = welcomeCases.size();
			Log.info("Number of Welcome cases: " + numberOfWelcomeCases);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify welcome cases " + e.getMessage());
			Assert.fail("Failed to verify welcome cases " + e.getMessage());
		}
		return numberOfWelcomeCases;
	}

	/**
	 * Function: Validate Cases Object Columns Left to Right
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void valdiateCasesObjColumnsLeftToRight() {
		refresh();
		setTimeOut(3000);
		Log.info("Validate Cases Object Columns Left to Right");
		setTimeOut(5000);

		List<String> expectedHeaders = Arrays.asList("Case Number", "Record Type", "Care Program Enrollee", "Status",
				"Date/Time Opened", "Case Owner Alias");

		List<WebElement> columnElements = getWebDriver()
				.findElements(By.xpath("//table//th[@scope='col' and @role='columnheader']"));
		//// child::lightning-primitive-header-factory//child::span//child::a//child::span//following-sibling::span
		List<String> actualHeaders = new ArrayList<>();

		for (int i = 0; i < columnElements.size(); i++) {
			if (i != 0 && i != 7) {
				String headerText = columnElements.get(i).getText().trim();
				actualHeaders.add(headerText);
				WebElement ele = columnElements.get(i).findElement(By.xpath(".//a"));
				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].style.border='2px solid red'", ele);

			}
		}

		if (actualHeaders.equals(expectedHeaders)) {
			LoggingInfo("Column order is as expected " + expectedHeaders + " and " + actualHeaders);
		} else {
			Log.error("Column order is incorrect. Expected: " + expectedHeaders + ", but got: " + actualHeaders);
			Assert.fail("Column order is incorrect. Expected: " + expectedHeaders + ", but got: " + actualHeaders);
		}

	}

	/**
	 * Function: Validate Cases Object Columns
	 * 
	 * @author Sonica P
	 **/
	public void verifyColumnOrder() {

		refresh();
		setTimeOut(3000);
		Log.info("Validate Cases Object Columns Left to Right");
		setTimeOut(5000);

		List<String> expectedHeaders = Arrays.asList("Case Number", "Record Type", "Care Program Enrollee", "Status",
				"Date/Time Opened", "Case Owner Alias");

		List<WebElement> columnElements = getWebDriver().findElements(By.xpath(
				"//*[contains(@class,\"active lafPageHost\")]//table//th[@scope='col' and @role='columnheader']//child::lightning-primitive-header-factory//child::span//child::a//child::span//following-sibling::span"));
		List<String> actualHeaders = new ArrayList<>();

		for (int i = 0; i < columnElements.size(); i++) {
			String headerText = columnElements.get(i).getText();
			actualHeaders.add(headerText);
		}

		if (actualHeaders.equals(expectedHeaders)) {
			LoggingInfo("Column order is as expected " + expectedHeaders + " and " + actualHeaders);
		} else {
			Log.error("Column order is incorrect. Expected: " + expectedHeaders + ", but got: " + actualHeaders);
			Assert.fail("Column order is incorrect. Expected: " + expectedHeaders + ", but got: " + actualHeaders);
		}
	}

	public void verifyWelcomeCaseIsCreated() {
		try {

			By welcomeCase = By.xpath(
					"//*[contains(@class,'active lafPageHost')]//table//tr[.//span[text()='Welcome Message']][1]//a");

			if (isElementPresent(welcomeCase)) {
				Log.info("Welcome Correspondence case is created.");
			} else {
				Log.info("No Welcome Correspondence case found.");
			}

		} catch (Exception e) {
			Log.error("Failed to verify welcome case: " + e.getMessage());
			Assert.fail("Failed to verify welcome case: " + e.getMessage());
		}
	}

	public void verifyNoWelcomeCaseIsCreated() {
		try {

			setTimeOut(2000);
			WebElement viewAllButton = getWebDriver().findElement(By.xpath(
					"//*[contains(@class,'active lafPageHost')]//*[text()='Cases']//parent::span[text()='View All']"));
			Assert.assertFalse(viewAllButton.isDisplayed(),
					"'View All' button should not be visible, indicating no welcome case is created");
			LoggingInfo("Verified: 'View All' button is absent, no welcome case is created");

		} catch (NoSuchElementException e) {
			LoggingInfo("Verified: 'View All' button is absent, as expected (no welcome case is created)");

		} catch (Exception e) {
			LoggingInfo("Failed to verify no welcome case is created: " + e.getMessage());
		}
	}

	public void verifyWelcomeCaseIsNotCreated() {
		try {

			setTimeOut(2000);
			By welcomeCase = By.xpath(
					"//*[contains(@class,'active lafPageHost')]//table//tr[.//span[text()='Welcome Message']][2]//a");
			if (!isElementPresent(welcomeCase)) {
				Log.info("No Welcome Correspondence case found as expected.");
				LoggingInfo("Verified: No Welcome Correspondence case is created, as expected.");
			} else {

				Log.error("Unexpected Welcome Correspondence case found.");
				LoggingInfo("Unexpected Welcome Correspondence case found, test failed.");
				Assert.fail("Failed: Welcome Correspondence case is present, but it should not be.");
			}

		} catch (NoSuchElementException e) {

			Log.info("Welcome Correspondence case element not found, as expected.");
			LoggingInfo("Verified: No Welcome Correspondence case is present, as expected.");
		} catch (Exception e) {
			Log.error("Failed to verify welcome case: " + e.getMessage());
			LoggingInfo("Failed to verify welcome case: " + e.getMessage());
			Assert.fail("Failed to verify welcome case: " + e.getMessage());
		}
	}

	/**
	 * Function: select member plan status
	 * 
	 * @author Anand P
	 **/
	public void selectMemberPlanStatus(String status) {
		try {
			waitForPageLoaded();
			Log.info("Select member plan Status");
			setTimeOut(3000);
			By outcomeBtn = getDynamicElement(fieldBtn, "Status");
			waitAndVerifyElement(outcomeBtn);
			scrollToElement(outcomeBtn);
			clickByJavascript(outcomeBtn);
			setTimeOut(2000);
			By options = getDynamicElement(dropDownValues, "Status");
			selectItemFromDropDown(outcomeBtn, options, status);
			LoggingInfo("Status selected as-" + status);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select" + e.getMessage());
			Assert.fail("Failed to select" + e.getMessage());
		}

	}

	/**
	 * Function: Validate error message
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyErrorMessage(String expectedErrorMsg) {
		try {
			By eleerrorMsg = By
					.xpath("//*[contains(@class,\"active lafPageHost\")]//div[@class=\"quick-actions-panel\"]//p");
			waitAndVerifyElement(eleerrorMsg);
			String actualErrorMsg = getText(eleerrorMsg);
			Assert.assertEquals(actualErrorMsg, expectedErrorMsg,
					"Error message mismatch. Expected: '" + expectedErrorMsg + "', but got: '" + actualErrorMsg + "'");
			LoggingInfo("Error message validated successfully");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate error message " + e.getMessage());
			Assert.fail("Failed to validate error message " + e.getMessage());
		}
	}

	public void clcikOnEditbtn(String btnName) throws Exception {
		try {
			waitForPageLoaded();
			By btn = getDynamicElement(editButton, btnName);
			waitAndVerifyElement(btn);
			scrollToElement(btn);
			click(btn);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on edit button " + e.getMessage());
			Assert.fail("Failed to click on edit button " + e.getMessage());
		}

	}

	public void validateCaseIsFormed(String caseType) {
		try {

			setTimeOut(5000);
			By recordtype = getDynamicElement(correspondenceInputField, "Record Type");
			waitAndVerifyElement(recordtype);
			scrollToElement(recordtype);
			String actualText = getText(recordtype);

			if (actualText.contains(caseType)) {
				Log.info("Validation Passed: The record type contains the expected case type: " + caseType);
			} else {
				Log.error("Validation Failed: The record type does not contain the expected case type. Expected: "
						+ caseType + " but found: " + actualText);
				Assert.fail("The expected case type '" + caseType + "' was not found in the record type. Found: "
						+ actualText);
			}

		} catch (Exception e) {
			Log.error("An error occurred: " + e.getMessage());
			Assert.fail("An error occurred during validation: " + e.getMessage());
		}
	}

	public void validateCaseColumns() {
		try {
			refresh();
			setTimeOut(2000);

			String[] headerValue = { "Case Number", "Record Type", "Status", "Date/Time Opened", "Date/Time Closed" };

			for (String header : headerValue) {

				if ("Status".equals(header)) {
					By statusHeader = By.xpath("(//span[text()='Status'])[4]");
					waitAndVerifyElement(statusHeader);
					LoggingInfo("Successfully validated column " + header);
				} else {
					By headerName = getDynamicElement(casecolumnHeader, header);
					waitAndVerifyElement(headerName);
					LoggingInfo("Successfully validated column " + header);
				}

			}

		} catch (Exception e) {
			Log.error("Failed to validate columns: " + e.getMessage());
			Assert.fail("Failed to validate columns: " + e.getMessage());
		}
	}

	public void validateColsAreRemoved() {
		try {

			setTimeOut(2000);
			WebElement section1 = getWebDriver().findElement(By.xpath("(//span[text()=\"Priority\"])"));
			Assert.assertFalse(section1.isDisplayed(), "Priority column should not be present");
			setTimeOut(2000);
			WebElement section2 = getWebDriver().findElement(By.xpath("(//span[text()=\"Subject\"])"));
			Assert.assertFalse(section2.isDisplayed(), "Subject column should not be present");

		} catch (Exception e) {
			// e.printStackTrace();
			LoggingInfo("Validated Both columns are not visible as expected");
		}

	}

	public void selectNewCase(String caseName) {
		try {

			setTimeOut(3000);
			By detailTab = getDynamicElement(caseRadioButton, caseName);
			clickByJavascript(detailTab);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on to-" + caseName + e.getMessage());
			Assert.fail("Failed to click on to-" + caseName + e.getMessage());
		}
	}

	public void validateMissingInformationCaseIsAbsent() {
		try {

			setTimeOut(2000);
			WebElement section1 = getWebDriver().findElement(By.xpath(
					"(//label[contains(@class, 'slds-radio__label') and .//span[contains(text(), 'Missing Information')]]/span[contains(@class, 'slds-radio_faux')])[1]"));
			Assert.assertFalse(section1.isDisplayed(), "Missing info case should not be present");

		} catch (Exception e) {

			LoggingInfo("Missing info case is not present as required");
		}

	}

	public void switchToAccessibilityFrame() {
		try {
			setTimeOut(1000);
			switchToFrame(accessibilityFrameName);
			LoggingInfo("Switched to accessibility frame successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to switch to accessibility frame: " + e.getMessage());
			Assert.fail("Unable to switch to accessibility frame: " + e.getMessage());
		}
	}

	public void clickNextButton() {
		try {
			Log.info("Verify user is able to click on Next and Save buttons");

			By eleNextButton = By
					.xpath("//button[@type='button' and @aria-disabled='false' and normalize-space(text())='Next']");
			waitAndVerifyElement(eleNextButton);
			clickByJavascript(eleNextButton);
			LoggingInfo("User clicked on Next button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Next or Save Button: " + e.getMessage());
			Assert.fail("Failed to click on Next or Save Button: " + e.getMessage());
		}
	}

	public void switchToParentFrame() {
		try {
			getWebDriver().switchTo().parentFrame();
			LoggingInfo("Switched to parent frame successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to switch to parent frame: " + e.getMessage());
			Assert.fail("Unable to switch to parent frame: " + e.getMessage());
		}
	}

	public void clickSaveButton() {
		try {

			By eleSaveButton = By
					.xpath("//button[@type='button' and @aria-disabled='false' and normalize-space(text())='Save']");
			clickByJavascript(eleSaveButton);
			setTimeOut(3000);
			LoggingInfo("User clicked on Save button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Next or Save Button: " + e.getMessage());
			Assert.fail("Failed to click on Next or Save Button: " + e.getMessage());
		}
	}

	public void clickOnSiteRecord() {
		try {
			Log.info("Verify user is able to click on site record");
			waitAndVerifyElement(eleSite);
			scrollToElement(eleSite);
			clickByJavascript(eleSite);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Site record: " + e.getMessage());
			Assert.fail("Failed to click on Site record: " + e.getMessage());
		}
	}

	/*
	 * @author - Anand Pawar
	 */
	public void validateCheckboxEnabled() {
		scrollToPixel(0, 500);

		try {
			WebElement checkbox = getWebDriver().findElement(By.xpath(
					"//*[contains(@class,'active lafPageHost')]//input[@name='AddDCRinProgress_ICC__c']//ancestor::lightning-primitive-input-checkbox"));
			String checkedAttribute = checkbox.getAttribute("checked");

			if (checkedAttribute != null) {
				System.out.println("Checkbox is checked.");
			} else {
				System.out.println("Checkbox is not checked.");
			}

		} catch (Exception e) {
			Log.error("Failed to verify " + e.getMessage());
			Assert.fail("Failed to verify  " + e.getMessage());
		}

	}

	public void verifyAddDSRField() {
		try {
			By eleAddDSR = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Add DCR in Progress?\"]");
			waitAndVerifyElement(eleAddDSR);
			scrollToElement(eleAddDSR);
			highLightElement(eleAddDSR);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
			Assert.fail("Failed to verify " + e.getMessage());
		}
	}

	/*
	 * @author - Anand Pawar
	 */
	public void verifyAndClickOnPrescriberRecord(String hcp) {
		try {
			Log.info("Verify user is able to click on HCP record");
			waitAndVerifyElement(eleHCP);
			scrollToElement(eleHCP);
			String actualText = getText(eleHCP);
			Assert.assertEquals(actualText, hcp);

			highLightElement(eleHCP);

			clickByJavascript(eleHCP);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Site record: " + e.getMessage());
			Assert.fail("Failed to click on Site record: " + e.getMessage());
		}
	}

	/**
	 * Function: Open Exisitng Correspondence Record.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void openFirstRecentRecord() {

		try {
			waitForPageLoaded();
			waitFor(3000);
			By firstRecord = By.xpath("(//*[contains(@class,\"active lafPageHost\")]//table//tbody//tr//th//a)[1]");
			waitAndVerifyElement(firstRecord);
			clickByJavascript(firstRecord);
			LoggingInfo("Existing  record opened successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Open Existing  Record " + e.getMessage());
			Assert.fail("Failed to Open Existing  Record " + e.getMessage());
		}

	}

	public void enterFaxNumber(String fax) {
		try {
			By faxInputBox = By.xpath("//*[contains(@class,\"active lafPageHost\")]//input");
			String faxValue = getAttributeValue(faxInputBox, "value");

			if (faxValue != null && !faxValue.isEmpty()) {
				assertEquals(faxValue, fax, "Existing fax value doesn't match the expected input.");
			} else {
				WebElement element = getWebDriver().findElement(faxInputBox);
				JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
				String script = "arguments[0].focus();" + "arguments[0].value = arguments[1];"
						+ "arguments[0].dispatchEvent(new Event('input', { bubbles: true }));"
						+ "arguments[0].dispatchEvent(new Event('change', { bubbles: true }));"
						+ "arguments[0].blur();";
				js.executeScript(script, element, fax);
				Log.info("Entered fax number: " + fax);
			}

		} catch (Exception e) {
			Log.error("Failed to enter fax number: " + e.getMessage());
			Assert.fail("Failed to enter fax number: " + e.getMessage());
		}
	}

	/**
	 * Function: Click on Cases Table from related list
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void openCaseTable() throws Exception {
		try {
			By eleCaseTab = By.xpath("//a//span[@title=\"Cases\"]");
			scrollToElement(eleCaseTab);
			clickByJavascript(eleCaseTab);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Open Existing  Record " + e.getMessage());
			Assert.fail("Failed to Open Existing  Record " + e.getMessage());
		}
	}

	public void selectDCRNotes(String type) {
		try {
			waitForPageLoaded();
			Log.info("Select DCR Notes");
			setTimeOut(3000);
			waitAndVerifyElement(eleDCRNotesType);
			scrollToElement(eleDCRNotesType);
			clickByJavascript(eleDCRNotesType);
			setTimeOut(2000);
			By options = By.xpath(
					"//button[@aria-label=\"DCR Notes\"]//parent::div//following-sibling::div//lightning-base-combobox-item[@role=\"option\"]//span[@class=\"slds-media__body\"]//child::span");
			selectItemFromDropDown(eleDCRNotesType, options, type);
			LoggingInfo("DCR Notes selected as-" + type);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select" + e.getMessage());
			Assert.fail("Failed to select" + e.getMessage());
		}

	}

	public void validateCorrespondenceItemToSenddropdown() throws InterruptedException {

		setTimeOut(4000);
		By selectItemsToSendDropdown = getDynamicElement(strDropDownSelectItemsToSend, "Select Items to Send");
		waitAndVerifyElement(selectItemsToSendDropdown);
		scrollToElement(selectItemsToSendDropdown);
		click(selectItemsToSendDropdown);

		By selectItemsToSendDropdownOptions = getDynamicElement(searchDropDownOptions, "Select Items to Send");
		waitAndVerifyElement(selectItemsToSendDropdownOptions);
		List<WebElement> options = getWebDriver().findElements(selectItemsToSendDropdownOptions);

		System.out.println("Dropdown options:");
		for (WebElement option : options) {
			System.out.println(option.getText().trim());

		}

	}

	/**
	 * Function: verify Prefered specialty pharmacy is Mandatory
	 * 
	 * @author Tejal
	 **/

	public void verifyPSPisMandatory() {
		try {
			click(eleEditPrefferedSP);

			By preferredSPDropdown = By.xpath(
					"//label[normalize-space(text())='Preferred Specialty Pharmacy']/following-sibling::div//lightning-base-combobox");
			waitAndVerifyElement(preferredSPDropdown);

			WebElement dropdownElement = getWebDriver().findElement(preferredSPDropdown);
			dropdownElement.click();
			dropdownElement.sendKeys(Keys.ARROW_UP);
			dropdownElement.sendKeys(Keys.ENTER);

			By saveEdit = By.xpath("//button[@name='SaveEdit']");
			
			By mandatoryError = By.xpath(
					"//div[@class='fieldLevelErrors' and .//strong[contains(text(), 'Review the following fields')] and .//a[contains(text(), 'Preferred Specialty Pharmacy')]]");
			if (verifyObjectPresentOrNot(mandatoryError)) {
				LoggingInfo("Preferred Specialty Pharmacy field is mandatory");
			} else {
				LoggingInfo("Preferred Specialty Pharmacy validation message not displayed");
			}
		
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Function: verify sp type is not editable
	 * 
	 * @author Tejal
	 **/
	public void validateSPTypeisNotEditable() {
		try {
			WebElement spTypeEditIcon = getWebDriver().findElement(eleEditSPtype);
			Assert.assertFalse(spTypeEditIcon.isDisplayed(), "SP Type edit icon should be hidden, but it is visible");
			LoggingInfo("Verified: SP Type field is not editable as expected");


		} catch (NoSuchElementException e) {
			LoggingInfo("Verified: SP Type edit control is absent, confirming the field is not editable");

		} catch (Exception e) {
			LoggingInfo("Failed to verify that SP Type field is non-editable: " + e.getMessage());
		}
	}

	/**
	 * Function: validate sp type
	 * 
	 * @author Tejal
	 **/
	public void validateSPType(String expectedValue) {
		try {
			By spType = getDynamicElement(correspondenceInputField, "SP Type");

			waitAndVerifyElement(spType);
			scrollToElement(spType);
			highLightElement(spType);

			String spTypeValue = getWebDriver().findElement(spType).getText();
			Log.info("SP Type value retrieved: " + spTypeValue);

			if (spTypeValue.equalsIgnoreCase(expectedValue)) {
				Log.info("SP Type is valid and matches expected value: " + expectedValue);
			} else {
				Log.error("SP Type is invalid. Expected: " + expectedValue + ", but found: " + spTypeValue);
				Assert.fail("SP Type mismatch. Expected: " + expectedValue + ", but found: " + spTypeValue);
			}

		} catch (Exception e) {
			Log.error("Failed to validate SP Type: " + e.getMessage());
			Assert.fail("Failed to validate SP Type: " + e.getMessage());
		}
	}

	public void valiadteErrorForNonEditableFields() {
		try {

			By editButton = By.xpath("//*[contains(@class,\"active lafPageHost\")]//button[text()=\"Edit\"]");
			waitAndVerifyElement(editButton);
			click(editButton);

			By clearSelectionButton = By.xpath("//button[@title='Clear Selection']");
			waitAndVerifyElement(clearSelectionButton);
			click(clearSelectionButton);

			By inputField = By.xpath("//label[normalize-space(text())='Account Name']/following-sibling::div//input");
			waitAndVerifyElement(inputField);
			getWebDriver().findElement(inputField).sendKeys(Keys.ENTER);

			By date = By.xpath("//label[normalize-space(text())='Submitted Date']/following-sibling::div//input");
			waitAndVerifyElement(date);
			scrollToElement(date);
			clearText(date);
			getWebDriver().findElement(date).sendKeys("6/6/2013");

			By statusDropdown = By.xpath(
					"//label[normalize-space(text())='Status']/following::button[contains(@class, 'slds-combobox__input')][1]");
			waitAndVerifyElement(statusDropdown);
			scrollToElement(statusDropdown);
			WebElement dropdown = getWebDriver().findElement(statusDropdown);
			dropdown.click();

			dropdown.sendKeys(Keys.ARROW_DOWN);
			dropdown.sendKeys(Keys.ENTER);

			By saveEdit = By.xpath("//button[@name='SaveEdit']");
			waitAndVerifyElement(saveEdit);
			click(saveEdit);
			By mandatoryError = By.xpath("//div[@class='pageLevelErrors'\r\n"
					+ "  and .//strong[normalize-space(text())='Review the errors on this page.']\r\n"
					+ "  and .//li[normalize-space(text())='Account name can not be updated']\r\n"
					+ "  and .//li[normalize-space(text())='Status of Order cannot be changed manually']\r\n"
					+ "  and .//li[normalize-space(text())='Submitted Date cannot be changed manually']\r\n" + "]");

			if (verifyObjectPresentOrNot(mandatoryError)) {
				LoggingInfo("Preferred Specialty Pharmacy field is mandatory");
			} else {
				LoggingInfo("Preferred Specialty Pharmacy validation message not displayed");
			}
			highLightElement(mandatoryError);

			By cancelButton = By.xpath("//button[@title='Cancel and close']");
			waitAndVerifyElement(cancelButton);
			click(cancelButton);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit email id " + e.getMessage());
			Assert.fail("Failed to edit email id " + e.getMessage());
		}
	}

	public void validateSPType() {
		try {
			By spTypeField = getDynamicElement(correspondenceInputField, "SP Type");
			waitAndVerifyElement(spTypeField);
			scrollToElement(spTypeField);

			String spTypeValue = getText(spTypeField);
			Assert.assertEquals(spTypeValue, "Non-Alliance", "SP Type is not 'Non-Alliance'");

			LoggingInfo("SP Type is correctly populated as 'Non-Alliance'");

		} catch (Exception e) {
			Log.error("Failed to validate SP Type: " + e.getMessage());
			Assert.fail("Failed to validate SP Type: " + e.getMessage());
		}
	}

	public void validateRestFieldsAreUneditable() {
		try {
			String[] xpaths = {
					"//*[contains(@class,'active lafPageHost')]//span[text()='Edit Care Program Enrollee Product']//parent::button",
					"//*[contains(@class,'active lafPageHost')]//span[text()='Edit Care Program Enrollee']//parent::button",
					"//*[contains(@class,'active lafPageHost')]//span[text()='Edit Prescription']//parent::button",
					"//*[contains(@class,'active lafPageHost')]//span[text()='Edit CPE Work Order']//parent::button" };

			for (String xpath : xpaths) {
				List<WebElement> elements = getWebDriver().findElements(By.xpath(xpath));

				if (!elements.isEmpty() && elements.get(0).isDisplayed()) {
					Assert.fail("Element should be hidden but is visible: " + xpath);
				}
			}

			LoggingInfo("Verified: All rest fields are uneditable as expected.");
			By closeOrderButton = By.xpath("//button[contains(@title, 'Close') and contains(@title, '| Order')]");
			waitAndVerifyElement(closeOrderButton);
			click(closeOrderButton);
			LoggingInfo("Clicked on 'Close Order' button successfully.");

		} catch (Exception e) {
			LoggingInfo("Failed to verify rest fields are uneditable: " + e.getMessage());
			Assert.fail("Exception occurred while verifying uneditable fields: " + e.getMessage());
		}
	}

	/**
	 * Function: Validate that the new document is linked to the existing
	 * CPE(present in Received Docs table)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateNewDocLinkedToCPE(String expectedFileName) throws Exception {
		boolean fileFound = false;
		int count = 0;
		if (verifytable("Received Documents")) {
			By eleReceivedDocTable = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//table[@aria-label=\"Received Documents\"]//tbody//tr");
			List<WebElement> rows = getWebDriver().findElements(eleReceivedDocTable);
			scrollToElement(eleReceivedDocTable);
			for (WebElement row : rows) {
				WebElement nameElement = row
						.findElement(By.xpath(".//th//a//span[@class=\"slds-truncate\"]//slot//span"));
				String fileName = nameElement.getText().trim();
				if (fileName.contains(expectedFileName)) {
					LoggingInfo("New Enrollment form is linked to the existing CPE");
					fileFound = true;
					count++;
					break;
				}

				Assert.assertTrue(fileFound,
						"File name '" + expectedFileName + "'found in the Received document table.");
				LoggingInfo("Verification completed: " + expectedFileName);
			}
		}
		System.out.println(count);
	}

	/**
	 * Function: Download Correspondence PDF from Generate screen
	 * 
	 * @author Shanavaz Nishani
	 **/
	public String downloadPDFfromGenerateDocScreen(String file) throws Exception {
		waitFor(20000);
		By elePDF = By.xpath("//*[@class='pdf_viewer']");
		String url = getAttributeValue(elePDF, "src");
		((JavascriptExecutor) getWebDriver()).executeScript("window.open()");
		ArrayList<String> tabs = new ArrayList<>(getWebDriver().getWindowHandles());
		getWebDriver().switchTo().window(tabs.get(1));
		getWebDriver().get(url);

		setTimeOut(5000);
		refresh();
		setTimeOut(2000);

		Robot robot = new Robot();
		robot.setAutoDelay(1000);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_S);
		robot.keyRelease(KeyEvent.VK_S);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.setAutoDelay(1000);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_S);
		robot.keyRelease(KeyEvent.VK_S);
		robot.keyRelease(KeyEvent.VK_CONTROL);

		setTimeOut(5000);
		String DEST = System.getProperty("user.dir") + File.separator + "TestData" + File.separator + "PDFDownloads"
				+ File.separator + file.trim();
		documentsPage.uploadPDFFile(DEST);
		setTimeOut(10000);
		refresh();
		LoggingInfo("File downloaded successfully from Generate Doc screen");
		getWebDriver().switchTo().window(tabs.get(0));

		return DEST;
	}

	/**
	 * Function: validate Primary Field
	 * 
	 * @author Tejal
	 **/
	public void validatePrimaryField(String expectedValue) {
		try {

			By primaryField = getDynamicElement(correspondenceInputField, "Primary");

			waitAndVerifyElement(primaryField);
			scrollToElement(primaryField);
			highLightElement(primaryField);

			String primaryFieldValue = getWebDriver().findElement(primaryField).getText();

			Log.info("Primary field value retrieved: " + primaryFieldValue);

			if (expectedValue.equals(primaryFieldValue)) {
				Log.info("Primary field is valid (value is " + expectedValue + "): " + primaryFieldValue);
			} else {
				Log.error("Primary field is invalid (value is not " + expectedValue + "): " + primaryFieldValue);
				Assert.fail("Primary field value is not " + expectedValue + ": " + primaryFieldValue);
			}

		} catch (Exception e) {
			Log.error("Failed to verify Primary field: " + e.getMessage());
			Assert.fail("Failed to verify Primary field: " + e.getMessage());
		}
	}

	/**
	 * Function: changePrimary Field To NO
	 * 
	 * @author Tejal
	 **/

	public void changePrimaryFieldToNO() {
		try {

			By firstXPath = By.xpath("//*[contains(@class,'active lafPageHost')]//button[contains(@title,'Primary')]");
			click(firstXPath);

			LoggingInfo("CLICKED ON EDIT BUTTON");

			By secondXPath = By.xpath("//button[@aria-label='Primary' and @data-value='Yes']");
			click(secondXPath);

			LoggingInfo("CLICKED ON FILED BUTTON");

			System.out.println("Changed value to NO from drop down");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();

		} catch (Exception e) {
			System.err.println("Error occurred while changing Primary field to NO: " + e.getMessage());
		}
	}

	/**
	 * Function: validate Error Msg
	 * 
	 * @author Tejal
	 **/
	public void validateErrorMsg() {
		try {
			String expectedError = "There has to be one Active Primary CCR Record";
			By errorMsg = By.xpath("//*[text()=\"There has to be one Active Primary CCR Record\"]");
			waitAndVerifyElement(errorMsg);
			scrollToElement(errorMsg);
			highLightElement(errorMsg);
			String actualError = getText(errorMsg);
			Assert.assertEquals(expectedError, actualError, "Error message validated successfully");

			By close = By
					.xpath("//button[contains(@title, 'Close') and contains(@title, 'Contact Contact Relationship')]");
			highLightElement(close);
			click(close);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate error message" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: creating New Relationship
	 * 
	 * @author Tejal
	 **/
	public void creatingNewRelationship() {
		try {

			By newRelationship = By.xpath("//div[text()='New Relationship']");
			waitAndVerifyElement(newRelationship);
			click(newRelationship);

			By relationshipButton = By.xpath("//button[@aria-label='Relationship']");
			waitAndVerifyElement(relationshipButton);
			click(relationshipButton);

			By patientParentOption = By.xpath("(//span[text()='Patient-Parent'])[1]");
			waitAndVerifyElement(patientParentOption);
			click(patientParentOption);

			WebElement searchContactsInputElement = getWebDriver()
					.findElement(By.xpath("//input[@placeholder='Search Contacts...']"));
			searchContactsInputElement.sendKeys("joe singh");

			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();

			By isActiveCheckbox = By.xpath("//input[@type='checkbox' and @name='IsActive']");
			waitAndVerifyElement(isActiveCheckbox);
			clickByJavascript(isActiveCheckbox);

		} catch (Exception e) {
			Log.error("Error while creating new relationship: " + e.getMessage());
			Assert.fail("Failed to create new relationship: " + e.getMessage());
		}
	}

	/**
	 * Function:
	 * 
	 * @author Tejal
	 **/
	public void validateErrorMessage() {
		try {
			String expectedError = "ACC-VR37: Phone only accepts 10-digit number.";
			By errorMsg = By.xpath("//*[text()=\"There has to be one Active Primary CCR Record\"]");
			waitAndVerifyElement(errorMsg);
			scrollToElement(errorMsg);
			highLightElement(errorMsg);
			String actualError = getText(errorMsg);
			Assert.assertEquals(expectedError, actualError, "Error message validated successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate error message" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function:Open any CPEP record when there are multiple records by row number
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void openCPEPRecordByrowNum(int recordNum, String filename) throws Exception {

		try {
			By eleQuickStartCPE = getDynamicElement(strQuickStartCPE, filename);
			List<WebElement> papcpeps = getWebDriver().findElements(eleQuickStartCPE);
			JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
			js.executeScript("arguments[0].click();", papcpeps.get(recordNum));
			Log.info("PAP CPEP record is Created");

		} catch (Exception e) {
			// TODO: handle exception
			Log.error("Failed to Open PAP CPEP record - " + e.getMessage());
			Assert.fail("Failed to Open PAP CPEP record - " + e.getMessage());
		}
	}

	/**
	 * Function: Get Patient ID(Care program Enrollee Field) from Details Tab of CPE
	 * 
	 * @author Shanavaz Nishani
	 **/
	public String getPatientCPEID() throws Exception {
		String patientID = "";
		By eleCPEID = By.xpath("//*[contains(@field-label,\"Care Program Enrollee\")]//lightning-formatted-text");
		scrollToElement(eleCPEID);

		String CPEFieldText = getText(eleCPEID).trim();
		if (!CPEFieldText.isEmpty()) {
			String[] parts = CPEFieldText.split("-");
			patientID = parts[0] + "-" + parts[1];
		} else {
			Log.error("Patient ID not Found on Care program Enrollee Field");
		}
		return patientID;

	}

	/**
	 * Function: Get Copay Card Number from Copay CPEP
	 * 
	 * @author Shanavaz Nishani
	 **/
	public String getCopayCardID() throws Exception {
		String copayCardNum = "";
		try {
			By ele = getDynamicElement(strAccountObjectDetails, "Copay Card #");
			scrollToElement(ele);
			copayCardNum = getText(ele).trim();
			highLightElement(ele);
			if (copayCardNum.isEmpty()) {
				Log.error("Copay Card Number Field is emptys");
			}
		} catch (Exception e) {
			Log.error("Failed to get Copay Card Number - " + e.getMessage());
			Assert.fail("Failed to get Copay Card Number  - " + e.getMessage());
		}
		return copayCardNum;
	}

	/**
	 * Function: Verify Consent Renewal Case not created
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyConsentRenewalCaseNotCreated() {
		By sl = By.xpath("//*[contains(@class,'active lafPageHost')]//table//tr[.//span[text()='Consent Renewal']]//a");
		if (!isElementPresent(sl)) {
			LoggingInfo("Verified: No Consent Renewal case is created, as expected.");
		} else {
			Log.error("Unexpected Consent Renewal Case is created.");
			Assert.fail("Failed: Consent Renewal Case is created.");
		}
	}

	/**
	 * Function: Click on List View dropdown of Accounts
	 * 
	 * @author Sonica P
	 **/
	public void ClicklistViewdropdownofAccounts() {
		try {
			refresh();
			waitFor(3000);
			Log.info("Click on List View dropdown of Accounts");
			clickByJavascript(eleListViewAcc);
			waitForPageLoaded();
			LoggingInfo("Clicked on List View dropdown of Accounts");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on ListView dropdown " + e.getMessage());
			Assert.fail("Failed to Click on ListView dropdown " + e.getMessage());
		}

	}

	/**
	 * Function: Click on existing facility record
	 * 
	 * @author Sonica P
	 **/
	public void selectExistingRec() {
		try {
			waitForPageLoaded();
			waitFor(5000);
			By columnHeader=By.xpath("//th//a");
			clickByJavascript(columnHeader);
			waitFor(4000);
			Log.info("Click on existing record");
			clickByJavascript(eleExistingRec);
			LoggingInfo("Click on existing record");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on existing record " + e.getMessage());
			Assert.fail("Failed to Click on existing record " + e.getMessage());
		}
	}

	
	/**
	 * Function: Validate Tax Id field in All Facilities Accounts section
	 * 
	 * @author Sonica P
	 **/
	public void validateTaxIdField(String taxId) {
		try {
			Log.info("Edit tax id field");
			clickByJavascript(eleEditTaxIdField);
			LoggingInfo("Click on edit tax id field");
			waitFor(2000);
			click(eleInputTaxId);
			inputText(eleInputTaxId, taxId);
			click(elePhoneInp);

			waitFor(2000);
			Log.info("Click on save button");
			waitAndVerifyElement(eleSaveEdit);
			clickByJavascript(eleSaveEdit);
			LoggingInfo("Clicked on save button");
			
			List<WebElement> errorElements = getWebDriver().findElements(error);
			
			if(!errorElements.isEmpty() && errorElements.get(0).isDisplayed()) {
				waitFor(2000);
				click(eleClose);
				By eleDCR = By.xpath("//*[contains(@class,\"active lafPageHost\")]//button[@aria-label=\"DCR Notes\"]");
				waitAndVerifyElement(eleDCR);
				clickByJavascript(eleDCR);
				selectItemFromList(eleDCR, eleDCRDropdownOptions, "Direct from account", "DCR Notes");
				
				By eleSave = getDynamicElement(strAuthorizationieldButtons, "Save");
				waitAndVerifyElement(eleSave);
				clickByJavascript(eleSave);
				setTimeOut(4000);			
			}else {
				System.out.println("Error not present");
			}
				
			
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on save tax id" + e.getMessage());
			Assert.fail("Failed to click on save tax id " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Tax ID field on Facility record, is 9digits without any
	 * comma
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateTaxIDFieldFormat() {

		By eleTaxID = getDynamicElement(strAccountObjectDetails, "Tax id");
		String taxID = getText(eleTaxID).trim();

		String digitsOnly = taxID.replaceAll("\\D", "");
		int digitCount = digitsOnly.length();

		if (digitCount == 9 && !taxID.contains(",")) {
			LoggingInfo("Tax ID field is populated without comma’s and it is 9 Char long");
		} else {
			Assert.fail("Tax ID field Invalid input. Found " + digitCount + " digits. Value: '" + taxID + "'");
			Log.error("Tax ID field Invalid input. Found " + digitCount + " digits. Value: '" + taxID + "'");

		}
	}

	public void validateSaveErrorMsg() {
		try {
			String expectedError = "Please select CPE linked to the Patient";
			By errorMsg = By.xpath("//*[text()=\"Please select CPE linked to the Patient\"]");
			waitAndVerifyElement(errorMsg);
			scrollToElement(errorMsg);
			highLightElement(errorMsg);
			String actualError = getText(errorMsg);
			Assert.assertEquals(expectedError, actualError, "Error message validated successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate error message" + ". Error - " + e.getMessage());

	}
}

public void validateErrorMsgForAddressInAccount() {
    try {
        String expectedError = "Commas and forward slashes are not allowed in addresses. Please remove them to continue.";
        
        // Error message locator
        By errorMsg = By.xpath("//li[normalize-space()='Commas and forward slashes are not allowed in addresses. Please remove them to continue.']");
        
        waitAndVerifyElement(errorMsg);
        scrollToElement(errorMsg);
        highLightElement(errorMsg);
        
        String actualError = getText(errorMsg);
        Assert.assertEquals(expectedError, actualError, "Error message validated successfully");
        
        By cancel = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Cancel\"]//parent::button");
		 highLightElement(cancel);
		   click(cancel);


        Log.info("Patient address field cleared after validating error message.");
    } catch (Exception e) {
        e.printStackTrace();
        Assert.fail("Failed to validate error message. Error - " + e.getMessage());
    }
}



public void validateErrorMsgForAddress() {
    try {
        String expectedError = "Commas and forward slashes are not allowed in addresses. Please remove them to continue.";
        
      
        By errorMsg = By.xpath("//div[text()='Commas and forward slashes are not allowed in addresses. Please remove them to continue.']");
        
        waitAndVerifyElement(errorMsg);
        scrollToElement(errorMsg);
        highLightElement(errorMsg);
        
        String actualError = getText(errorMsg);
        Assert.assertEquals(expectedError, actualError, "Error message validated successfully");

        
        By eleAddressInput = By.xpath("//span[normalize-space()='Address']/ancestor::div[contains(@class, 'slds-form-element')]//input");

        
        waitAndVerifyElement(eleAddressInput);
        scrollToElement(eleAddressInput);
        clearInputFieldText(eleAddressInput);

        Log.info("Patient address field cleared after validating error message.");
    } catch (Exception e) {
        e.printStackTrace();
        Assert.fail("Failed to validate error message. Error - " + e.getMessage());
    }
}

public void validateStatus() {
    try {
        By status = getDynamicElement(correspondenceInputField, "Status");

        waitAndVerifyElement(status);
        scrollToElement(status);

        String statusValue = getWebDriver().findElement(status).getText();

        Log.info("Status value found: " + statusValue);

       
        Assert.assertEquals(statusValue, "Sent", "Status should be 'Sent'");

        Log.info("Status validated successfully as 'Sent'.");
    } catch (Exception e) {
        Log.error("Failed to verify Status: " + e.getMessage());
        Assert.fail("Failed to verify Status: " + e.getMessage());
    }
}


/**
 * Function: validate Primary Field
 * 
 * @author Tejal
 **/
public void validateSelectedForTriageField(String expectedValue) {
    try {
    	 By sps = By.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Selected Specialty Pharmacy\"]//parent::div//parent::div//a//span)[3]");
	        
	        waitAndVerifyElement(sps);
	        scrollToElement(sps);
	        highLightElement(sps);
	        click(sps);
    	
    	
     
        By primaryField = getDynamicElement(correspondenceInputField, "Selected for Triage");

     
        waitAndVerifyElement(primaryField);
        scrollToElement(primaryField);
        highLightElement(primaryField);

    
        String primaryFieldValue = getWebDriver().findElement(primaryField).getText();
        
        Log.info("Primary field value retrieved: " + primaryFieldValue);

        if (expectedValue.equals(primaryFieldValue)) {
            Log.info("Primary field is valid (value is " + expectedValue + "): " + primaryFieldValue);
        } else {
            Log.error("Primary field is invalid (value is not " + expectedValue + "): " + primaryFieldValue);
            Assert.fail("Primary field value is not " + expectedValue + ": " + primaryFieldValue);
        }

    } catch (Exception e) {
        Log.error("Failed to verify Primary field: " + e.getMessage());
        Assert.fail("Failed to verify Primary field: " + e.getMessage());
    }
}

/**
 * Function: verify Selected Specialty Pharmacy is not editable
 * 
 * @author Tejal
 **/
public void validateSelectedSpecialtyPharmacyisNotEditable() {
	try {
		WebElement spTypeEditIcon = getWebDriver().findElement(eleEditSPtype);
		Assert.assertFalse(spTypeEditIcon.isDisplayed(), "Selected Specialty Pharmacy edit icon should be hidden, but it is visible");

		LoggingInfo("Verified: SP Type field is not editable as expected");

	} catch (NoSuchElementException e) {
		LoggingInfo("Verified: SP Type edit control is absent, confirming the field is not editable");

	} catch (Exception e) {
		LoggingInfo("Failed to verify that SP Type field is non-editable: " + e.getMessage());
	}
}

























}

