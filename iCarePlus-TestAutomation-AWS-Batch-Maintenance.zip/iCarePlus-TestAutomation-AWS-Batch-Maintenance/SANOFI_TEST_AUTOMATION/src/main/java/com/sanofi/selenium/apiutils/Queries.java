package com.sanofi.selenium.apiutils;

import java.util.Map;

import com.sanofi.selenium.enums.APIEnum;

public class Queries {

	/**
	 * Function: To create SOQL query statement for PSP object
	 * 
	 * @author Kruti Unnithan
	 * @param accID
	 * @return Query statement
	 */
	public static String PSPmarketingConsentAccIDsoql(String accountId) {

		return "select \r\n" + "Id, \r\n" + "iCC_Active__c \r\n" + "from \r\n"
				+ "PatientConnect__PC_Program_Service_Permission__c \r\n" + "where\r\n"
				+ "PatientConnect__PC_ProgramCase__r.AccountId = " + "'" + accountId + "'" + "\r\n" + "and\r\n"
				+ "PatientConnect__PC_ProgramCase__r.Account.RecordType.Name = 'General Participant'\r\n" + "and \r\n"
				+ "PatientConnect__PC_Program_Service_Permission_Name__c LIKE 'RBD Marketing Consent%'";
	}

	/**
	 * Function: To create SOQL query statement for Account object
	 * 
	 * @author Kruti Unnithan
	 * @param email
	 * @return Query statement
	 */
	public static String AccountIDForEmailSoql(String email) {

		return "select \r\n" + "Id \r\n,Name \r\n " + "from \r\n" + "Account \r\n" + "where \r\n"
				+ "PatientConnect__PC_Email__c = " + "'" + email + "'";
	}

	public static String AccountIDForFirstNAmeSoql(String firstName) {
		String AccID = "select \r\n" + "Id \r\n" + "from \r\n" + "Account \r\n" + "where \r\n"
				+ "PatientConnect__PC_First_Name__c = " + "'" + firstName + "'";
		return AccID;
	}
	/**
	 * Function: To create SOQL query statement for Account object based on account source
	 * 
	 * @author Pratiksha Dixit
	 * @param email, Account source
	 * @return Query statement
	 */
	public static String AccountIDForEmailSoqlBasedOnAccountSource(String email,String accountSource) {

		return "select \r\n"
				+ "Id \r\n"
				+ "from \r\n"
				+ "Account \r\n"
				+ "where \r\n"
				+ "PatientConnect__PC_Email__c = "+"'"+email+"'"+"and  AccountSource="+"'"+accountSource+"'";
	}


	public static String AccountIDForLastNAmeSoql(String lastName) {
		String AccID = "select \r\n" + "Id \r\n" + "from \r\n" + "Account \r\n" + "where \r\n"
				+ "PatientConnect__PC_Last_Name__c = " + "'" + lastName + "'";
		return AccID;
	}

	public static String AccountIDForName(String name) {
		String AccID = "select Id from Account where Name= " + "'" + name + "'";
		return AccID;
	}

	public static String getAccountDetailsWithID(String id) {
		String AccID = "Select ID, Name, AccountID, Account.Name FROM Contact WHERE AccountID= " + "'" + id + "'";
		return AccID;
	}

	/**
	 * Function: To create SOQL query statement for PSP object for account ID
	 * 
	 * @author Kruti Unnithan
	 * @param accountId
	 * @return Query statement
	 */
	public static String pspIDForAccountSoql(String accountId) {

		return "select \r\n" + "Id \r\n" + "from \r\n" + "PatientConnect__PC_Program_Service_Permission__c \r\n"
				+ "where \r\nPatientConnect__PC_ProgramCase__r.AccountId = " + "'" + accountId + "'";
	}

	/**
	 * Function: To create SOQL query statement for PSP object for program case ID
	 * 
	 * @author Yuti Shah
	 * @param accountId
	 * @return Query statement
	 */
	public static String pspIDForProgramCaseSoql(String caseId) {

		return "select Id, PatientConnect__PC_End_Date__c, PatientConnect__PC_Service__r.name from PatientConnect__PC_Program_Service_Permission__c where PatientConnect__PC_ProgramCase__c = '"
				+ caseId + "'";
	}

	/**
	 * Function: To create SOQL query statement for Health Plan object
	 * 
	 * @author Kruti Unnithan
	 * @param accountId
	 * @return Query statement
	 */
	public static String healthPlanRecordCount(String accountId) {

		return "select \r\n" + "count(Id) \r\n" + "from \r\n" + "PatientConnect__PC_Health_Plan__c \r\n" + "where \r\n"
				+ "PatientConnect__Patient__c = " + "'" + accountId + "'";
	}

	/**
	 * Function: To create SOQL query statement for Association object
	 * 
	 * @author Kruti Unnithan
	 * @param patientFirstName, patientLastName
	 * @return Query statement
	 */
	public static String careTeamID(String patientFirstName, String patientLastName) {

		return "select \r\n" + "Id \r\n" + "from \r\n" + "PatientConnect__PC_Association__c \r\n" + "where \r\n"
				+ "iCC_Patient__c = " + "'" + patientFirstName + " " + patientLastName
				+ "' and iCC_To_Relationship_Type__c = 'Parent/Guardian'";
	}

	/**
	 * Function: To create SOQL query statement for program case object
	 * 
	 * @author Yuti Shah
	 * @param patientFirstName, patientLastName
	 * @return Query statement
	 */
	public static String careTeamIdFromProgramCase(String caseId, String objName) {

		return "select \r\n" + "Id, PatientConnect__PC_Role__c \r\n" + "from \r\n"
				+ "PatientConnect__PC_Association__c \r\n" + "where \r\n" + objName + " = " + "'" + caseId + "'";
	}

	/**
	 * Function: To create SOQL query statement for Case object
	 * 
	 * @author Kruti Unnithan
	 * @param accountId, program
	 * @return Query statement
	 */
	public static String caseID(String accountId, APIEnum program) {

		return "select \r\n" + "Id, \r\n" + "CaseNumber, \r\n" + "PatientConnect__PC_Case_Outcome__c \r\n" + "from \r\n"
				+ "Case \r\n" + "where \r\n" + "AccountId = " + "'" + accountId + "'" + "\r\n" + "and \r\n"
				+ "RecordType.Name = " + "'" + program + "'";
	}

	/**
	 * Function: To create SOQL query statement for Getting Program case Id based on
	 * the EP name and account ID
	 * 
	 * @author Pratiksha
	 * @param accountId, program
	 * @return Query statement
	 */
	public static String caseIDWithEPName(String accountId, APIEnum program, String epName) {

		return "select \r\n" + "Id, \r\n" + "CaseNumber, \r\n" + "PatientConnect__PC_Case_Outcome__c \r\n" + "from \r\n"
				+ "Case \r\n" + "where \r\n" + "AccountId = " + "'" + accountId + "'" + "\r\n" + "and \r\n"
				+ "RecordType.Name = " + "'" + program + "' and PatientConnect__PC_EngagementProgramName__c=" + "'"
				+ epName + "'";
	}

	/**
	 * Function: To create SOQL query statement for Case object
	 * 
	 * @author Harika Mudumby
	 * @param program case number
	 * @return Query statement
	 */
	public static String getCaseNumber(String program, String caseType) {

		return "select \r\n" + "Id, \r\n" + "CaseNumber, \r\n" + "RecordType.Name \r\n" + "from \r\n" + "Case \r\n"
				+ "where \r\n" + "RecordType.Name = " + "'" + caseType + "'" + "\r\n" + "and \r\n"
				+ "PatientConnect__PC_Program__r.casenumber = " + "'" + program + "'";
	}

	/**
	 * Function: To create SOQL query statement for Case object
	 * 
	 * @author Kruti Unnithan
	 * @param accountId, program
	 * @return Query statement
	 */
	public static String RDcaseID(String status, APIEnum program, String product) {

		return "select \r\n" + "Id, \r\n" + "iCC_Product_Name__c, \r\n" + "CaseNumber \r\n" + "from \r\n" + "Case \r\n"
				+ "where \r\n" + "RecordType.Name = " + "'" + program + "'" + "\r\n" + "and \r\n" + "Status = " + "'"
				+ status + "'" + "\r\n" + "and \r\n" + "iCC_Product_Name__c = " + "'" + product + "'" + "\r\n"
				+ "limit 10";
	}

	/**
	 * Function: To create SOQL query statement for Case object
	 * 
	 * @author Yuti Shah
	 * @param accountId, program
	 * @return Query statement
	 */
	public static String caseIDFromProgramCase(String programCaseId) {

		return "select Id, RecordType.Name ,status, CaseNumber, PatientConnect__PC_Case_Outcome__c from Case where PatientConnect__PC_Program__c = '"
				+ programCaseId + "'";
	}

	/**
	 * Function: To create SOQL query statement for Case object
	 * 
	 * @author Chaithanya
	 * @param accountId, program
	 * @return Query statement
	 */
	public static String caseIDFromProgramCaseWithoutAtlantisProgram(String programCaseId) {

		return "select Id, RecordType.Name ,status, CaseNumber, PatientConnect__PC_Case_Outcome__c from Case where PatientConnect__PC_Program__c = '"
				+ programCaseId + "' and iCC_Record_Type_Name__c != 'iCC_Atlantis_Connections_Program'";
	}

	/**
	 * Function: To create SOQL query statement for Prescription object
	 * 
	 * @author Kruti Unnithan
	 * @param progCaseID
	 * @return Query statement
	 */
	public static String prescriptionID(String progCaseID) {

		return "select \r\n" + "Id \r\n" + "from \r\n" + "PatientConnect__PC_Prescription__c \r\n" + "where \r\n"
				+ "PatientConnect__PC_Program_Case__c = " + "'" + progCaseID + "'";
	}

	/**
	 * Function: To create SOQL query statement for Program Case Object
	 * 
	 * @author Yuti Shah
	 * @param caseId
	 * @return Query statement
	 */
	public static String programCaseDetails(String caseId) {

		return "Select Id, account.name ,account.Id, iCC_Engagement_Program_Code__c, PatientConnect__PC_Engagement_Program__r.name, PatientConnect__PC_Program_Product__r.name , status, iCC_Product_Name__c, PatientConnect__PC_Case_Outcome__c from Case where id = '"
				+ caseId + "'";
	}

	/**
	 * Function: To create SOQL query statement for Treatment Summary object from
	 * program Case
	 * 
	 * @author Yuti Shah
	 * @param accountId
	 * @return Query statement
	 */
	public static String treatmentSummaryFromProgramCase(String caseId) {

		return "select \r\n" + "Id, RecordType.Name,iCC_Treatment_Status__c, iCC_Treatment_Start_Reason__c \r\n"
				+ "from \r\n" + "iCC_Treatment_Summary__c \r\n" + "where \r\n" + "iCC_Program__c = " + "'" + caseId
				+ "'";
	}

	/**
	 * Function: To create SOQL query statement for Treatment Summary object
	 * 
	 * @author Kruti Unnithan
	 * @param accountId
	 * @return Query statement
	 */
	public static String treatmentSummaryID(String accountId) {

		return "select \r\n" + "Id \r\n" + "from \r\n" + "iCC_Treatment_Summary__c \r\n" + "where \r\n"
				+ "iCC_Account__c = " + "'" + accountId + "'";
	}

	/**
	 * Function: To create SOQL query statement for order Details object
	 * 
	 * @author Yuti Shah
	 * @param orderId
	 * @return Query statement
	 */
	public static String orderDetails(String orderId) {

		return "Select iCC_Order_Quantity_1__c, iCC_Order_Quantity_2__c, Pricebook2.name, account.name, EffectiveDate, Status, "
				+ "Owner.name from Order where id = '" + orderId + "'";
	}

	/**
	 * Function: To create SOQL query statement for Treatment Summary object
	 * 
	 * @author Yuti Shah
	 * @param orderId
	 * @return Query statement
	 */
	public static String orderProductDetails(String orderId) {

		return "Select id, iCC_Patient_Name__r.name, iCC_Program_Case__r.CaseNumber, iCC_Program_Case__c, iCC_Rx_Dose__r.name, "
				+ "iCC_Part_Description_A__r.name, iCC_Part_Description_B__r.name, iCC_Quantity_A__c, iCC_Quantity_B__c,iCC_Strength_A__c, "
				+ "iCC_Strength_B__c , iCC_Infusion_or_PillStart__c , iCC_Frequency__c from OrderItem where order.id = '"
				+ orderId + "'";
	}

	/**
	 * Function: To create SOQL query statement for Program Coverage object
	 * 
	 * @author Kruti Unnithan
	 * @param accountId
	 * @return Query statement
	 */
	public static String progCoverageID(String accountId) {

		return "select \r\n" + "count(Id) \r\n" + "from \r\n" + "PatientConnect__PC_Program_Coverage__c \r\n"
				+ "where \r\n" + "iCC_Account__c = " + "'" + accountId + "'";
	}

	/**
	 * Function: To create SOQL query statement for Program Coverage object
	 * 
	 * @author Yuti Shah
	 * @param caseId
	 * @return Query statement
	 */
	public static String progCoverageIdFromProgCase(String caseId) {

		return "select \r\n" + "Id \r\n" + "from \r\n" + "PatientConnect__PC_Program_Coverage__c \r\n" + "where \r\n"
				+ "PatientConnect__PC_Program__c = " + "'" + caseId + "'";
	}

	/**
	 * Function: To create SOQL query statement for Document Log object
	 * 
	 * @author Kruti Unnithan
	 * @param progCaseID
	 * @return Query statement
	 */
	public static String documentLogID(String progCaseID) {

		return "select \r\n" + "Id \r\n" + "from \r\n" + "PatientConnect__PC_Document_Log__c \r\n" + "where \r\n"
				+ "PatientConnect__PC_Program__r.CaseNumber = " + "'" + progCaseID + "'";
	}

	/**
	 * Function: To create SOQL query statement for Document object
	 * 
	 * @author Kruti Unnithan
	 * @param docName
	 * @return Query statement
	 */
	public static String documentID(String docName) {

		return "select \r\n" + "Id, \r\n" + "PatientConnect__PC_Description__c \r\n" + "from \r\n"
				+ "PatientConnect__PC_Document__c \r\n" + "where \r\n" + "Name = " + "'" + docName + "'";
	}

	public static String accDetails(String accountId) {
		String accFieldDetails = "select \r\n" + "Id,\r\n" + "PatientConnect__PC_Preferred__c, \r\n"
				+ "iCC_Date_Of_Birth_DD_MM_YYYY__c, \r\n" + "PatientConnect__PC_Email__c, \r\n" + "iCC_Age__c,\r\n"
				+ "name, \r\n" + "Type, \r\n" + "PatientConnect__PC_Gender__c, \r\n" + "AccountSource, \r\n"
				+ "PersonMobilePhone, \r\n" + "RecordType.Name, \r\n" + "PatientConnect__PC_Primary_Address_1__c, \r\n"
				+ "PatientConnect__PC_Primary_City__c, \r\n" + "PatientConnect__PC_Primary_State__c, \r\n"
				+ "PatientConnect__PC_Primary_Zip_Code__c, \r\n" + "BillingCountry \r\nfrom \r\n" + "Account \r\n"
				+ "where \r\nId =  " + "'" + accountId + "'";

		return accFieldDetails;
	}

	/**
	 * Function: To create SOQL query statement for Getting active product details
	 * based on the product family
	 * 
	 * @author Pratiksha Dixit
	 * @param productFamily
	 * @return Query statement
	 */
	public static String getActiveProductsDetails(String productFamily) {
		String productDetails = "select Id,Name,iCC_ERP_Part_Number__c,PatientConnect__PC_Strength__c,iCC_Part_Description_Order_Preference__c from Product2 where IsActive=true \r\n"
				+ "and iCC_Product_Family__r.Name =" + "'" + productFamily + "'" + "\r\n" + "limit 2";

		return productDetails;
	}

	/**
	 * 
	 * Function: To Get SCA account with active PSBS record, with Payer account
	 * having credit limit and credit status as Normal, and active contract
	 * 
	 * @author Pratiksha Dixit
	 * @return Query statement
	 */

	public static String getScaAccount() {

		String scaAccount = "select Id,Name,iCC_Account_Group__c from Account where PatientConnect__PC_Status__c='Active' and iCC_Credit_Status__c='Normal' and iCC_Credit_Limit__c!=null and id in(select AccountId from contract where Status='Active') and id in( select iCC_Payer__c from iCC_PSBS__c where iCC_Payer__r.PatientConnect__PC_Status__c='Active' and iCC_Active__c=true) and iCC_Account_Group__c includes ('Ship to') limit 10";

		return scaAccount;

	}

	/**
	 * 
	 * Function: To Get PSBS those are linked to SCA accounts by Ship to
	 * 
	 * @author Pratiksha Dixit
	 * @return Query statement
	 */

	public static String getPSBSId(String scaAccount) {
		String psbsIds = "select Id,Name,iCC_Payer__c,iCC_Payer__r.Name from iCC_PSBS__c where iCC_PSBS_Owner__r.Name="
				+ "'" + scaAccount + "'";
		return psbsIds;
	}

	/**
	 * 
	 * Function: To Get active PSBS those are linked to SCA accounts by Ship to
	 * 
	 * @author Pratiksha Dixit
	 * @return Query statement
	 */

	public static String getActivePSBSId(String scaAccount) {
		String psbsIds = "select Id,Name,iCC_Payer__c,iCC_Payer__r.Name from iCC_PSBS__c where iCC_Active__c=true and iCC_PSBS_Owner__r.Name="
				+ "'" + scaAccount + "'";
		return psbsIds;
	}

	/**
	 * 
	 * Function: To Get active PSBS details
	 * 
	 * @author Pratiksha Dixit
	 * @return Query statement
	 */

	public static String getPsbsDetails(String psbsId) {
		String psbsDetails = "select Id,iCC_Payer__r.Name,iCC_Payer__r.iCC_ERP_Number__c from iCC_PSBS__c where Name="
				+ "'" + psbsId + "'";
		return psbsDetails;
	}

	/**
	 * 
	 * Function: To Get active Unit price of product with the help of productname
	 * and price book
	 * 
	 * @author Pratiksha Dixit
	 * @return Query statement
	 */

	public static String getUnitPrice(String productName, String priceBookType) {
		String unitPrice = "select Id,UnitPrice,Pricebook2.Name from PricebookEntry where Name=" + "'" + productName
				+ "'" + "and IsActive=true and Pricebook2.Name=" + "'" + priceBookType + "'"
				+ "and Pricebook2.IsActive =true";
		return unitPrice;
	}

	/**
	 * 
	 * Function: To Get Order Number with the help of order Sfdc id
	 * 
	 * @author Pratiksha Dixit
	 * @return Query statement
	 */

	public static String getOrderNumber(String orderSfdcId) {
		return "select OrderNumber from Order where Id=" + "'" + orderSfdcId + "'";
	}

	/**
	 * 
	 * Function: To Get SFDC ID of program coverage based on the coverage number
	 * 
	 * @author Pratiksha Dixit
	 * @return Query statement
	 */

	public static String getSfdcIDProgramCoverage(String pcNumber) {
		return "select Id from PatientConnect__PC_Program_Coverage__c where Name =" + "'" + pcNumber + "'";
	}

	/**
	 * 
	 * Function: To Get AlternateInfusion Dose name with the help of infusion Dose
	 * Name
	 * 
	 * @author Pratiksha Dixit
	 * @return Query statement
	 */

	public static String getAlternateInfusionDose(String infusionDose) {
		return "select Id,Name,iCC_Alternate_Dose__r.Name from PatientConnect__PC_Prescription__c where Name=" + "'"
				+ infusionDose + "'";
	}

	/**
	 * 
	 * Function: To Get active Unit price of product with the help of product2name
	 * and price book
	 * 
	 * @author Harika Mudumby
	 * @return Query statement
	 */

	public static String getUnitPrice(String productName) {
		return "select Id,Name,UnitPrice from PricebookEntry where product2.Name=" + "'" + productName + "'"
				+ "and IsActive=true and Pricebook2.IsActive = true and Pricebook2.Name = 'Commercial'";
	}

	/**
	 * 
	 * Function: To Get Supply chain account id using account name
	 * 
	 * @author Harika Mudumby
	 * @return Query statement
	 */

	public static String supplyChainAccountID(String accountName) {
		return "select Id,iCC_Supply_Chain_Account_ID__c ,iCC_ERP_Number__c from Account where Name=" + "'"
				+ accountName + "'";

	}

	/**
	 * 
	 * Function: To Get ERP account using ERP ID
	 * 
	 * @author Harika Mudumby
	 * @return Query statement
	 */

	public static String erpAccount(String erpID) {
		return "select Id, Name from iCC_ERP_Account__c where iCC_ERP_Number__c=" + "'" + erpID + "'";

	}

	/**
	 * Function: To create SOQL query statement for Patient SCA Association
	 * 
	 * @author Kruti Unnithan
	 * @param SCA ID
	 * @return Query statement
	 */
	public static String patientAssociation(String SCAid) {

		return "select \r\n" + "count(Id) \r\n" + "from \r\n" + "iCC_Patient_SCA_Association__c \r\n" + "where \r\n"
				+ "iCC_Supply_Chain_Account__c = " + "'" + SCAid + "'";
	}

	/**
	 * Function: To create SOQL query statement for SCA object agiasnt fields Price
	 * Book and 340B
	 * 
	 * @author Kruti Unnithan
	 * @param priceBookValue = Commercial or 340B/PHS, nullFlag = true/false
	 * @return Query statement
	 */
	public static String SCAidForProceBookAnd340B(String priceBookValue, boolean nullFlag) {
		if (nullFlag) {
			return "select \r\n" + "Id, \r\n" + "Name \r\n" + "from \r\n" + "Account \r\n" + "where \r\n"
					+ "iCC_Supply_Chain_Account_ID__c LIKE 'SCA%' \r\n" + "and \r\n" + "iCC_Price_Book__r.Name = " + "'"
					+ priceBookValue + "'" + "\r\n" + "and \r\n" + "iCC_340B_ID__c = null \r\n" + "limit 1";
		} else {
			return "select \r\n" + "Id \r\n" + "from \r\n" + "Account \r\n" + "where \r\n"
					+ "iCC_Supply_Chain_Account_ID__c LIKE 'SCA%' \r\n" + "and \r\n" + "iCC_Price_Book__r.Name = " + "'"
					+ priceBookValue + "'" + "\r\n" + "and \r\n" + "iCC_340B_ID__c != null \r\n" + "limit 1";
		}
	}

	/**
	 * Function: To create SOQL query statement for SCA object
	 * 
	 * @author Kruti Unnithan
	 * @param Ship Status
	 * @return Query statement
	 */
	public static String SCAidForShipStatus(String shipStatus) {

		return "select Id,\r\n" + "iCC_Supply_Chain_Account_ID__c, \r\n" + "Name,  \r\n"
				+ "(select Id, iCC_Supply_Chain_Account__c \r\n" + "from \r\n" + "Patient_SCA_Associations1__r \r\n"
				+ "where \r\n" + "iCC_Supply_Chain_Account__c = null) \r\n" + "from \r\n" + "Account \r\n"
				+ "where \r\n" + "iCC_Supply_Chain_Account_ID__c LIKE 'SCA%' \r\n" + "and \r\n"
				+ "PatientConnect__PC_Status__c = 'Active' \r\n" + "and \r\n" + "iCC_Ship_Status__c = " + "'"
				+ shipStatus + "'" + "\r\n" + "and \r\n" + "(NOT Name like '%Test%') \r\n" + "limit 10";
	}

	/**
	 * Function: To create SOQL query statement for fetch
	 * 
	 * @author Dipali Yadav
	 * @param EP name,region sfdc id
	 * @return Query statement
	 */
	public static String getCareTeamMemberWithCareTeamRolePRUMDetailsLinkedWithZipcode(String expEPName,
			String expSfdcId) {

		String Values = "select \r\n" + "PatientConnect__PC_CareTeamMember__r.Name,iCC_Status__c, \r\n"
				+ "PatientConnect__PC_CareTeamRole__c \r\n" + "from \r\n"
				+ "PatientConnect__PC_ProgramRegionUserMapping__c \r\n" + "where \r\n"
				+ "PatientConnect__PC_EngagementProgram__r.Name = " + "'" + expEPName + "'" + "\r\n" + "and \r\n"
				+ "PatientConnect__PC_Region__r.Id= " + "'" + expSfdcId + "'";
		return Values;

	}

	/*
		*//**
			 * Function: To create SOQL query statement for PSP object
			 * 
			 * @author Yuti Shah
			 * @param
			 * @return Query statement
			 */
	public static String PRUMidByRegionAndEP(String regionId, String EP) {

		return "select id, PatientConnect__PC_CareTeamRole__c, PatientConnect__PC_CareTeamAccount__r.name from PatientConnect__PC_ProgramRegionUserMapping__c where  PatientConnect__PC_Region__c = '"
				+ regionId + "' and PatientConnect__PC_EngagementProgram__r.name = '" + EP
				+ "' and PatientConnect__PC_CareTeamRole__c IN ('Regional Business Director','Sales Rep')" + "";
	}

	/**
	 * Function: To create SOQL query statement for Program Case having Rx Dose
	 * 
	 * @author Kruti Unnithan
	 * @return Query statement
	 */
	public static String progCaseWithDose() {

		return "select \r\n" + "Id, \r\n" + "PatientConnect__PC_Program_Case__c, \r\n"
				+ "PatientConnect__PC_Program_Case__r.CaseNumber, \r\n"
				+ "PatientConnect__PC_Program_Case__r.Account.Name \r\n" + "from \r\n"
				+ "PatientConnect__PC_Prescription__c \r\n" + "where \r\n" + "RecordType.Name = 'Oral Dose' \r\n"
				+ "and \r\n" + "PatientConnect__PC_Product__r.Name = 'Cerdelga'\r\n" + "limit 1";
	}

	/**
	 * Function: To Get case numbers of expected ep
	 * 
	 * @author Pratiksha Dixit
	 * @return Query statement
	 */
	public static String getCaseNumberBasedOnProgramCase(String epName) {
		return "select id,CaseNumber From Case where PatientConnect__PC_Engagement_Program__r.Name='" + epName + "' and iCC_Record_Type_Name__c!='PC_Program'";
	}

	/**
	 * Function: get AccoutID
	 * 
	 * @author Chaithanya
	 * @return Query statement
	 */
	public static String getAccoutID(String accountName, String source) {
		return "Select ID FROM Account WHERE AccountSource = '" + source + "' and Name='" + accountName + "'";
	}

	/**
	 * 
	 * Function: get RecordTypeId
	 * 
	 * @author Chaithanya
	 * @return Query statement
	 * 
	 */

	public static String getRecordTypeIDquey(String caseNumber)

	{

		return

		"Select RecordTypeId from Case where CaseNumber = '" + caseNumber + "'";

	}

	/**
	 * 
	 * Function: get PRUM ID based on the region id ,care member name,role
	 * 
	 * @author Pratiksha Dixit
	 * @return Query statement
	 * 
	 */

	public static String getPRUMIDBasedOnCareMemberRoleAndName(String regionSFDCID, String careMemberName,
			String careRole, String careMemeberStatus) {
		return "select Id,Name,iCC_Status__c,iCC_Disease__c,\r\n" + "PatientConnect__PC_CareTeamMember__r.Name, \r\n"
				+ "PatientConnect__PC_CareTeamRole__c \r\n" + "from\r\n"
				+ "PatientConnect__PC_ProgramRegionUserMapping__c \r\n" + "where \r\n"
				+ "PatientConnect__PC_Region__r.Id= '" + regionSFDCID
				+ "' and PatientConnect__PC_CareTeamMember__r.Name='" + careMemberName + "' and iCC_Status__c ='"
				+ careMemeberStatus + "' and PatientConnect__PC_CareTeamRole__c='" + careRole + "'";
	}

	/**
	 * 
	 * Function: get Automation Account based on type
	 * 
	 * @author Pratiksha Dixit
	 * @return Query statement
	 * 
	 */
	public static String getAutomationAccount(String patientType) {
		return "select Name from Account where Name Like 'Automation%' and Type='" + patientType + "'";

	}

	/**
	 * 
	 * Function: Get the ExistingProgram Case ID Based on the EP's
	 * 
	 * @author Pratiksha Dixit
	 * @return Query statement
	 * 
	 */
	public static String getProgramCaseIDBasedOnEP(String EPName) {
		return "select Id From Case where PatientConnect__PC_EngagementProgramName__c ='" + EPName
				+ "' and Status='Active' limit 10";
	}
	
	/**
	 * 
	 * Function: To Get Supply chain account id using account name
	 * 
	 * @author Chaithanya
	 * @return Query statement
	 */

	public static String getAccountIDForSupplyChain(String accountName) {
		return "select iCC_ERP_Number__c from Account where Name= '"+accountName+"' and RecordType.name = 'Supply Chain Account'";

	}
	
	/**
	 * Function: To create SOQL query statement for PSP object for program case ID
	 * 
	 * @author Chaithanya
	 * @param accountId
	 * @return Query statement
	 */
	public static String pspIDForProgramCaseSoqlForActive(String caseId) {

		return "select Id, PatientConnect__PC_End_Date__c, PatientConnect__PC_Service__r.name from PatientConnect__PC_Program_Service_Permission__c where PatientConnect__PC_ProgramCase__c = '"
				+ caseId + "' and iCC_Active__c = true";
	}
	
	/**
	 * Function: dispense Record Dates
	 * 
	 * @author Chaithanya
	 * @param accountId
	 * @return Query statement
	 */
	public static String dispenseRecordDates(String despenseId) {

		return "select iCC_Prior_Dispense_s_ANI_Date__c,iCC_Covered_From__c,iCC_Anticipated_Next_Infusion_Date__c from PatientConnect__PC_Dispense__c where "
				+ "Name = '"+despenseId+"'";
	}
	
	/**
	 * Function: get All Dispenses
	 * 
	 * @author Chaithanya
	 * @param accountId
	 * @return Query statement
	 */
	public static String getAllDispenses(String programCaseId) {

		return "select Name from PatientConnect__PC_Dispense__c where iCC_Program_Case__c = '"+programCaseId+"' ORDER BY Name ASC";
	}
	
}
