package com.sanofi.selenium.constants;

import java.util.ArrayList;
import java.util.Arrays;

public interface CareProgramEnrolleeConstant {

	public static final ArrayList<String> listOptions = new ArrayList<>(Arrays.asList("Yes", "No"));

	public static final ArrayList<String> taskTitle = new ArrayList<>(
			Arrays.asList("Eligibility Assessment", "Eligibility Outcome", "Correspondence", "Order Details",
					"Extend/Discontinue", "Review", "Pre-Check", "Communicate Results", "Capture Coverage Outcome"));
	
	public static final ArrayList<String> captureCoverageOutcomes = new ArrayList<>(Arrays.asList("Alternate Coverage Found", "Alternate Coverage Not Found"));

	public static final ArrayList<String> pAOptions = new ArrayList<>(Arrays.asList("YES", "NO"));

	public static final ArrayList<String> pAOutcomeOptions = new ArrayList<>(Arrays.asList("Not On File", "Approved",
			"Denied", "Pending", "Cancelled", "Required", "Unable to determine Outcome", "Withdrawn","Alternate Coverage Found","Alternate Coverage Not Found"));

	public static final ArrayList<String> reasonForHCPFollowupOutcomeOptions = new ArrayList<>(
			Arrays.asList("Not On File", "Approved", "Denied", "Pending", "Withdrawn"));

	public static final ArrayList<String> reasonForHCPFollowupOutcomeReason = new ArrayList<>(
			Arrays.asList("None", "No Intent of Submission"));

	public static final ArrayList<String> pARequiredAndOptions = new ArrayList<>(
			Arrays.asList("PA Required & Not on File", "PA Required & on File as Approved",
					"PA Required & on File as Denied", "PA Required & Pending"));

	public static final ArrayList<String> pAPOutcomeOptions = new ArrayList<>(
			Arrays.asList("Missing Information", "Approved"));

	public static final ArrayList<String> appealNeeded = new ArrayList<>(Arrays.asList("YES", "NO"));

	public static final ArrayList<String> StatusCheck = new ArrayList<>(Arrays.asList("In Progress", "Completed"));

	public static final ArrayList<String> statusOptionsMIOpenCases = new ArrayList<>(
			Arrays.asList("In Progress", "Open", "Cancelled", "Closed", "Collected", "Not Collected"));

	// public static final ArrayList<String> statusOptionsMIOpenCases = new
	// ArrayList<>(Arrays.asList("In Progress", "Open", "Cancelled", "Closed",
	// "Collected", "Not Collected"));

	public static final String PayerName = "TestAutomation";

	public static final String nextFollowUpDate = "09-15-2024";

	public static final String approval = "2";

	public static final String numberOfInjectionsUsed = "2";

	public static final String paEffectiveDate = "07-27-2024";

	public static final String paExpirationDate = "08-27-2024";

	public static final String numberOfInjectionsApproved = "2";
	public static final String hcpOfficeContactName = "Automation Testing";

	public static final String intendedDate = "08-28-2025";
	public static final String PolicyHolderDOB = "06-01-2005";
	public static final String InsuranceAddDate = "07-02-2024";
	public static final String PlanID = "667677";
	public static final String policyHolderDOB = "4/7/2010";
	public static final String InsuranceDate = "1/3/2012";

	public static final ArrayList<String> paSections = new ArrayList<>(
			Arrays.asList("PA/ Appeal Approved", "PA/ Appeal Pending", "PA/ Appeal Denied"));

	public static final ArrayList<String> SPtype = new ArrayList<>(Arrays.asList("Non-Alliance", "Alliance"));

	public static final String denialDate = "07-25-2024";

	public static final ArrayList<String> intentOfSubmission = new ArrayList<>(Arrays.asList("Yes", "No"));

	public static final ArrayList<String> contactMade = new ArrayList<>(Arrays.asList("Yes", "No"));

	public static final ArrayList<String> attemptOutcome = new ArrayList<>(
			Arrays.asList("Contact Made", "No Contact Made"));

	public static final ArrayList<String> expedited = new ArrayList<>(Arrays.asList("Yes", "No"));

	public static final ArrayList<String> consentCapturedSourceType = new ArrayList<>(
			Arrays.asList("Written", "eSign", "Verbal"));

	public static final ArrayList<String> consentStatus = new ArrayList<>(Arrays.asList("Seen", "Signed", "Rejected"));

	public static final ArrayList<String> workOrderName = new ArrayList<>(
			Arrays.asList("Benefits Verification", "PA/ Appeals", "Quick Start", "Copay", "Triage", "PAP"));
	public static final ArrayList<String> serviceReason = new ArrayList<>(
			Arrays.asList("Migrated Patient", "Lapse in coverage", "Patient requested", "Third party restrictions", "Received QS Rx"));

	/************* Benefits Verification constants ******************/
	public static final ArrayList<String> bvMainTaskNames = new ArrayList<>(Arrays.asList("BV Capture", "BV Summary"));
	public static final ArrayList<String> bvSubTaskNames = new ArrayList<>(
			Arrays.asList("Review and Finalize Benefit", "Review and Send Summary of Benefits"));
	public static final ArrayList<String> planType = new ArrayList<>(
			Arrays.asList("Private Commercial", "Tricare", "Medicare Part D", "Mediciad Plan","-- Clear --"));
	public static final ArrayList<String> coverageStatus = new ArrayList<>(
			Arrays.asList("Covered", "Not covered", "PA required", "Third party restriction","Uninsured"));
	public static final ArrayList<String> pharmacyDeductiable = new ArrayList<>(Arrays.asList("YES", "NO"));
	public static final ArrayList<String> medicarePartD = new ArrayList<>(Arrays.asList("YES", "NO"));
	public static final ArrayList<String> paRequired = new ArrayList<>(Arrays.asList("YES", "NO"));

	public static final ArrayList<String> outComeOptions = new ArrayList<>(
			Arrays.asList("Covered", "Covered with Restrictions", "Not Covered", "Unable to Complete", "Uninsured"));
	public static final ArrayList<String> papOptions = new ArrayList<>(
			Arrays.asList("PAP Appeal", "PA Appeal Denied", "Med D Annual Reverification", "Migrated Patient","Received QS Rx"));
	public static final ArrayList<String> denialReason = new ArrayList<>(
			Arrays.asList("Medical Necessity", "Step Therapy"));

	public static final ArrayList<String> appealLevel = new ArrayList<>(
			Arrays.asList("1st level", "2nd level", "3rd level"));

	public static final ArrayList<String> outComeReasonOptions = new ArrayList<>(
			Arrays.asList("No Restrictions", "PA Required", "Underinsured", "Third Party Restriction"));
	public static final ArrayList<String> sectionNames = new ArrayList<>(
			Arrays.asList("PA Required & Pending", "PA Required & Not on File"));
	public static final ArrayList<String> pendingReason = new ArrayList<>(Arrays.asList("Still under review",
			"Additional documentation required", "Administrative", "Clinical", "Lab Value"));
	public static final ArrayList<String> additionalDocReq = new ArrayList<>(Arrays.asList("Payer Specific Form"));
	public static final String processor = "Automation processor";
	public static final String authorization = "Automation authorization";
	public static final String electronicsite = "https://www.automation.com";
	public static final ArrayList<String> method = new ArrayList<>(Arrays.asList("Call", "Fax", "Web"));
	public static final ArrayList<String> faxedToMDO = new ArrayList<>(Arrays.asList("YES", "NO"));
	public static final ArrayList<String> turnAroundTime = new ArrayList<>(Arrays.asList("2", "3"));
	public static final ArrayList<String> memberPlan = new ArrayList<>(
			Arrays.asList("TestAutomation Payer Pharmacy", "TestAutomation Payer Medical","Payer Pharmacy TestAutomation","Thera Medical LLC","CVS Specialty Pharmacy","Pamer, Mark J, Medical Group"));

	/************************* PA/Appeals constants *************************/
	public static final ArrayList<String> paMainTaskNames = new ArrayList<>(
			Arrays.asList("Prior Auth", "PA Summary", "1st Appeal", "1st Appeal Summary", "2nd Appeal",
					"2nd Appeal Summary", "3rd Appeal", "3rd Appeal Summary"));
	public static final ArrayList<String> paSubTaskNames = new ArrayList<>(
			Arrays.asList("Follow up on Results", "Communicate Results and Send SOB", "HCP Follow Up"));
	public static final ArrayList<String> paStatus = new ArrayList<>(Arrays.asList("In Progress", "Completed"));
	public static final ArrayList<String> payerContact = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> attempts = new ArrayList<>(Arrays.asList("1", "2", "3"));
	public static final ArrayList<String> hcpFollowUpRequired = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> receiptRequired = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> PAOutcomeReason = new ArrayList<>(
			Arrays.asList("None", "Medical Necessity", "Payer Outcome Not Available","Lab Value", "Additional documentation required"));
	public static final ArrayList<String> AdditionalInfoRequired = new ArrayList<>(
			Arrays.asList("Payer Specific Form", "Clinical Information Needed"));
	
	public static final ArrayList<String> paDosage = new ArrayList<>(Arrays.asList("Initial dose", "Maintenance dose"));
	public static final ArrayList<String> hcpContact = new ArrayList<>(Arrays.asList("Yes", "No"));

	public static final ArrayList<String> appealPacked = new ArrayList<>(Arrays.asList("Fax", "Verbal", "Web"));
	public static final ArrayList<String> proceedWithAppeal = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> nextFollowupTime = new ArrayList<>(
			Arrays.asList("Morning", "Afternoon", "Evening"));
	public static final ArrayList<String> submissionChannel = new ArrayList<>(Arrays.asList("Fax", "Verbal", "Web"));
	public static final ArrayList<String> nextSteps = new ArrayList<>(Arrays.asList("Resubmit PA"));
	public static final ArrayList<String> levelOfAppeal = new ArrayList<>(
			Arrays.asList("1st level", "2nd level", "3rd level"));
	public static final ArrayList<String> avgOutcomeTime = new ArrayList<>(Arrays.asList("1", "2", "3"));
	public static final ArrayList<String> attempt = new ArrayList<>(Arrays.asList("VC-01002204", "VC-01002205", "VC-01002206"));
	public static final ArrayList<String> notifiedDenial = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> attemptOutcomes = new ArrayList<>(Arrays.asList("Contact Made", "No Contact Made"));
	public static final ArrayList<String> paAppealTasks = new ArrayList<>(
			Arrays.asList("1st Appeal", "2nd Appeal", "3rd Appeal"));
	ArrayList<String> paAppealSummaryTasks = new ArrayList<>(
			Arrays.asList("PA Summary", "1st Appeal Summary", "2nd Appeal Summary", "3rd Appeal Summary"));

	/************* Quick start constants ******************/
	public static final ArrayList<String> quickStartMainTaskNames = new ArrayList<>(Arrays.asList("QS Summary"));
	public static final ArrayList<String> quickStartSubTaskNames = new ArrayList<>(Arrays.asList("Enrollment"));
	public static final ArrayList<String> quickStartOutcome = new ArrayList<>(
			Arrays.asList("Approved", "Denied", "Cancelled", "Discontinued", "Re-activated"));
	public static final ArrayList<String> quickStartStatus = new ArrayList<>(Arrays.asList("Active", "Discontinued"));
	public static final ArrayList<String> reason = new ArrayList<>(
			Arrays.asList("Missing Information", "Residency criteria", "Patient/HCP Request", "PA/Appeal Approved",
					"Patient expired", "Eligibility timeframe", "Not actively seeking coverage",
					"Coverage options exhausted", "Alternate coverage approved"));
	public static final ArrayList<String> quickStartLabels = new ArrayList<>(Arrays.asList("PA/Appeal Approval Date"));

	/************* Copay constants ******************/
	public static final ArrayList<String> copayMainTaskNames = new ArrayList<>(Arrays.asList("Copay Eligibility"));
	public static final ArrayList<String> copaySubTaskNames = new ArrayList<>(Arrays.asList("Copay Eligibility"));
	public static final ArrayList<String> copayOutcome = new ArrayList<>(Arrays.asList("Eligible", "Not Eligible"));

	/************* Triage constants ******************/
	public static final ArrayList<String> triageMainTaskNames = new ArrayList<>(Arrays.asList("Triage"));
	public static final ArrayList<String> triageSubTaskNames = new ArrayList<>(Arrays.asList("Submit Order"));
	public static final ArrayList<String> alliancePharmacy = new ArrayList<>(
			Arrays.asList("Accredo Health Group, Inc", "Walgreen Co", "Elixir Pharmacy", "CVS Specialty Pharmacy",
					"Optum Pharmacy 705, Llc", "Centerwell Pharmacy, Inc", "Senderra Rx Partners, Llc"));
	public static final ArrayList<String> nonAlliancePharmacy = new ArrayList<>(Arrays.asList("Mill Street Pharmacy, Inc",
			"Preveon Specialty Pharmacy", "Walmart", "Automation Specialty Pharmacy"));
	public static final ArrayList<String> mrStatus = new ArrayList<>(Arrays.asList("Active", "Completed", "Cancelled"));
	public static final ArrayList<String> BusinessProcess = new ArrayList<>(Arrays.asList("Copay","BV","PA"));
	/************* PAP constants ******************/

	public static final ArrayList<String> papSubTaskNames = new ArrayList<>(
			Arrays.asList("Pre-Check", "Research and Capture Outcome", "Communicate Results", "Capture Coverage Outcome", "Eligibility","Research and Capture Outcome"));
			
	public static final ArrayList<String> lISEligible = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> alternateResearch = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> coverageSituation = new ArrayList<>(Arrays.asList("Patient Uninsured",
			"Patient Underinsured", "Med Part D - Financial Hardship", "Med Part D - Potentially LIS", "None",null));
	public static final ArrayList<String> alternateCoverage = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> papMainTaskNames = new ArrayList<>(
			Arrays.asList("Alternate Coverage", "Confirm PAP Eligibility"));
public static final ArrayList<String> quickStartReason = new ArrayList<>(Arrays.asList("Received QS Rx"));
	public static final ArrayList<String> service = new ArrayList<>(
			Arrays.asList("BV", "PAP", "IAP", "Copay", "Injection Training Case", "Quick Start","Triage"));

	/************* Free Goods ******************/
	public static final ArrayList<String> channelType = new ArrayList<>(
			Arrays.asList("Fax", "Letter", "Phone", "Email", "MCS-154", "Direct Mail", "Voice"));
	public static final ArrayList<String> masterCorrespondencefields = new ArrayList<>(
			Arrays.asList("DMW Med D PAP Annual Re-Enrollment - HCP Fax",
					"DMW Quick Start Program Eligibility Reminder (Final Notice) - PT Letter",
					"DMW Med Part D PAP Re-Enrollment - PT Call Reminder",
					"DMW PAP Denial  - HCP Fax", "DMW Med D PAP Re-Enrollment Form - PT Letter", "MCS-1739"));
	public static final ArrayList<String> parentCampaignStatus = new ArrayList<>(
			Arrays.asList("--None--", "In Progress", "Completed", "Aborted", "Planned"));
	public static final ArrayList<String> newCampaign = new ArrayList<>(Arrays.asList("Child", "Parent"));

	/************* Care Team Assignments ******************/
	public static final ArrayList<String> managerFields = new ArrayList<>(
			Arrays.asList("Case Manager", "Field Reimbursement Manager"));
	public static final ArrayList<String> prescriberDetails = new ArrayList<>(
			Arrays.asList("Kanha HCP", "Testing site"));

	/************* IAP constants ******************/
	public static final ArrayList<String> enrollmentReason = new ArrayList<>(
			Arrays.asList("PA Processing", "Change in insurance", "Appeal Processing", "SP Delay"));
	public static final ArrayList<String> paApproval = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> indication = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> residential = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> hcpUSPR = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> inpatient = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> therapy = new ArrayList<>(Arrays.asList("Yes", "No"));
	public static final ArrayList<String> eligibilityOutcome = new ArrayList<>(
			Arrays.asList("Eligible", "Not Eligible","Denied"));
	public static final ArrayList<String> iapoutcome = new ArrayList<>(
			Arrays.asList("Approved", "Denied", "Withdrawn"));
	
	public static final ArrayList<String> alternateCovOutcome = new ArrayList<>(
			Arrays.asList("Alternate Coverage Found", "Alternate Coverage Not Found"));
	public static final ArrayList<String> extensionReason = new ArrayList<>(Arrays.asList("PA Delayed"));

	public static final String[] columnsMyMigratedCPE = { "Created Date", "Name", "Status", "Account", "Pharmacy Payer",
			"Field Reimbursement Manager", "Prescriber", "Site", "Current Work Order Name" };
	public static final String[] columnsAllMigratedCPE = { "Created Date", "Name", "Status", "Account",
			"Pharmacy Payer", "Case Manager", "Field Reimbursement Manager", "Prescriber", "Site",
			"Current Work Order Names" };
	public static final ArrayList<String> listViewFilters = new ArrayList<>(
			Arrays.asList("All Migrated Care Program Enrollees", "My Migrated Care Program Enrollees", "All Products",
					"All Care Program Products"));
	public static final ArrayList<String> RecivedlistViewFilters = new ArrayList<>(
			Arrays.asList("All Received Documents", "My Received Documents", "Received Document Worklist",
					"Recently Viewed", "Recently Viewed Received Documents"));

	public static final ArrayList<String> InactivationReasons = new ArrayList<>(
			Arrays.asList("Unable to Contact", "Consent Expired", "Inactive Patient", "HCP requested",
					"Patient deceased", "Duplicate patient", "Indication change"));
	/************* CPE constants ******************/
	public static final ArrayList<String> cpeStatus = new ArrayList<>(
			Arrays.asList("Active", "Inactive", "Pending", "Draft"));

	/*** Patient Education Constants ****/
	public static final ArrayList<String> trainingType = new ArrayList<>(
			Arrays.asList("Virtual", "In Person", "On the Spot"));

	public static final ArrayList<String> trainingStatus = new ArrayList<>(
			Arrays.asList("Received", "Did not Receive", "On the Spot"));

	public static final String[] columnsDMWNurseEducators = { "Case Number", "Type of Training", "Patient Age",
			"Zip Code", "HCP Training Status" };

	public static final ArrayList<String> nursingOutcome = new ArrayList<>(Arrays.asList("Completed", "Not Completed"));

	public static final ArrayList<String> nursingOutcomeReason = new ArrayList<>(Arrays.asList("Training Completed"));

	public static final ArrayList<String> caseStatus = new ArrayList<>(Arrays.asList("Open", "Closed"));

	public static final ArrayList<String> caseTypes = new ArrayList<>(
			Arrays.asList("Missing Information", "Injection Training", "Welcome Message", "Order Follow up", "Pharmacy",
					"Medical", "Consent Opt Out", "Consent Renewal","Med D AR"));

	public static final ArrayList<String> miStatusOptions = new ArrayList<>(Arrays.asList("In Progress"));

	public static final ArrayList<String> AllianceSP_List = new ArrayList<>(
			Arrays.asList("Cvs Specialty Pharmacy", "Accredo Health Group, Inc", "Acariahealth Pharmacy, Inc",
					"Amber Specialty Pharmacy", "Kroger Specialty Pharmacy Florida 2, Llc", "Walgreen Co",
					 "Birdi, Inc", "Bioplus Specialty Pharmacy Services, Llc",
					"Centerwell Pharmacy, Inc", "Theracom, Llc"));
//"Optum Pharmacy 705, Llc",
	
	public static final ArrayList<String> PayerPharmacyFieldName = new ArrayList<>(
			Arrays.asList("Specialty Pharmacy", "Payer Collected Pharmacy #1", "Payer Collected Pharmacy #2",
					"Payer Collected Pharmacy #3"));

	public static final ArrayList<String> ListViewFilters_BO_NE = new ArrayList<>(
			Arrays.asList("All Received Documents", "My Received Documents",
					"Recently Viewed", "Recently Viewed Received Documents"));

	public static final ArrayList<String> statusCPEP = new ArrayList<>(
			Arrays.asList("Active", "Inactive",
					"Dicontinued","Expired"));

	public static final ArrayList<String> cpepProductName = new ArrayList<>(
			Arrays.asList("MobileApp", "Dupixent"));
	
	public static final ArrayList<String> inactivationReason = new ArrayList<>(
			Arrays.asList("Unable to Contact", "","Consent Expired", "Inactive Patient",
					"HCP requested", "Patient deceased", "Duplicate patient", "Indication change"));

	public static final ArrayList<String> Cases_ListView = new ArrayList<>(
			Arrays.asList("Recently Viewed", "All Open Cases", "My Cases", "My Open Cases","AR Specialist Queue"));

	public static final ArrayList<String> Accounts_ListView = new ArrayList<>(
			Arrays.asList("All HCPs", "All Facilities"));

	public static final ArrayList<String> papActionRequired_picklist = new ArrayList<>(
			Arrays.asList("Patient to submit re-enrollment form (or be discontinued)",
					"Missing Information (patient or provider)",
					"No action required"));

	public static final ArrayList<String> patientMedicarePartD_picklist = new ArrayList<>(
			Arrays.asList("Yes", "No"));

	public static final ArrayList<String> order_Status = new ArrayList<>(
			Arrays.asList("Submitted", "Sent to SP"));

	public static final ArrayList<String> orderType = new ArrayList<>(
			Arrays.asList("Commercial"));

	public static final ArrayList<String> fieldNames = new ArrayList<>(
			Arrays.asList("Order Type","Status","Alliance SP?","Order Sent Date"));

	public static final ArrayList<String> Reason_PicklistValues = new ArrayList<>(
			Arrays.asList("Virtual", "In Person", "On the Spot"));

	public static final ArrayList<String> ClosureAttempt_PicklistValues = new ArrayList<>(
			Arrays.asList("Voice Call", "Fax", "Email", "SMS", "Patient Letter", "Not Applicable"));

	public static final ArrayList<String> CollectedChannel_PicklistValues = new ArrayList<>(
			Arrays.asList("Phone", "Document"));

	public static final ArrayList<String> attempt_Fields = new ArrayList<>(
			Arrays.asList("1st Attempt", "2nd Attempt", "3rd Attempt", "1st Attempt Date", "2nd Attempt Date","3rd Attempt Date"));


	public static final ArrayList<String> MICases_Table = new ArrayList<>(
			Arrays.asList("Open Cases", "Closed Cases"));

	public static final ArrayList<String> BulkClose_Options = new ArrayList<>(
			Arrays.asList("Yes", "No"));

	public static final ArrayList<String> memberPlanAndMedStatus = new ArrayList<>(
			Arrays.asList("Draft","Inactive","Active","Cancelled"));

	public static final ArrayList<String> memberPlanType = new ArrayList<>(
			Arrays.asList("Pharmacy","Medical","Primary"));

	public static final ArrayList<String> fieldsDetailTab = new ArrayList<>(
			Arrays.asList("Phone","Email","Prescriber","Site"));

	public static final ArrayList<String> relatedContDropdownOpt = new ArrayList<>(
			Arrays.asList("View Relationship","Edit Relationship","Remove Relationship"));

	public static final ArrayList<String> workorderStatus = new ArrayList<>(
			Arrays.asList("Canceled","Completed","InProgress"));


	public static final ArrayList<String> viewAllTable = new ArrayList<>(
			Arrays.asList("Care Program Enrollee Products","Member Plans","Contact Contact Relationships","Received Documents"));

	public static final ArrayList<String> payerFieldVal = new ArrayList<>(
			Arrays.asList("iccRxPayerName","iccMedicalPayerName"));

	public static final ArrayList<String> dupCodes = new ArrayList<>(
			Arrays.asList("US.DUP.25.02.0145", "US.DUP.24.12.0147"));

	public static final ArrayList<String> patientAccountStatus = new ArrayList<>(
			Arrays.asList("Inactive", "Deceased", "Duplicate"));

	public static final ArrayList<String> medicareAandBoption = new ArrayList<>(Arrays.asList("Yes", "No"));

	public static final ArrayList<String> taxId = new ArrayList<>(Arrays.asList("123456789"));

	public static final ArrayList<String> listViewFiltersAcc = new ArrayList<>(Arrays.asList("All Facilities"));

	public static final ArrayList<String> outcome_LoVs = new ArrayList<>(
			Arrays.asList("Renewed", "Triaged to Commercial SP","Eligibility Not Met","Unable to Contact","Cancelled"));
		
	public static final String[] columnsARSpecialistQ = { "Case Number", "Care Program Enrollee", "Date/Time Opened" };

	public static final ArrayList<String> caseOwners = new ArrayList<>(Arrays.asList("AR Specialist Queue","Shruthi Chakravarthy","Abhijeet Gurjar","Data Intake Specialist"));

	public static final ArrayList<String> caseOwnerTitle = new ArrayList<>(Arrays.asList("AR Specialist","Data Intake Specialist"));

	public static final ArrayList<String> fieldHyperLink = new ArrayList<>(Arrays.asList("Care Program Enrollee","Account Name","Care Program"));

	public static final ArrayList<String> standardBtns = new ArrayList<>(Arrays.asList("Change Owner","Assign Label"));

}
