package com.sanofi.selenium.pages;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class DocumentPage extends Utility_Function {

	public DocumentPage(WebDriver driver) {
		super(driver);
	}

	String highlightStyle = "background-color: yellow; border: 3px solid red;";
	String errorMsg = "Error: Document Type is required.";
	String pageErrorMsg = "Invalid Format.";

	/************************
	 * Elements
	 **************************************************/
	public static By nameSort = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Name\"]//parent::a");
	public static By uploadDoc = By.xpath("(//*[@title='Upload Documents'])[1]");
	public static By doneButton = By.xpath("//span[text()='Done']");
	public static By eleDocumentPageTab = By.xpath(
			"(//li//span[@title=\"ReceivedDocument\"]//following-sibling::span[contains(@class,\"title slds-truncate\")])[1]");
	public static By strDocOCRStatus = By.xpath(
			"//*[contains(@class, \"active lafPageHost\")]//*[text()=\"OCR Status\"]//ancestor::record_flexipage-record-field//lightning-formatted-text");
	public static By detailsPageStatus = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,'slds-form-element__control')]//*[contains(@class,'test-id')]//lightning-formatted-text)[2]");
 
	public static By eleType = By.xpath("//button[@aria-label=\"Type of Training\"]");
	public static By eleStatus = By.xpath("//button[@aria-label=\"HCP Training Status\"]");
	public static By status = By.xpath("//button[@aria-label='Status']");

	public static By eleDocumentType = By
			.xpath("//*[text()=\"Document Type\"]//parent::label//parent::div//following-sibling::div//input");
	public static By eleDocumentTypeOptions = By.xpath(
			"//*[text()=\"Document Type\"]//parent::label//parent::div//following-sibling::div//li//*[contains(@class,'option-text')]");
	public static By submitButton = By.xpath("//*[text()='Submit' and @class='btnLabel']");
	public static By parentsubRecord = By
			.xpath("(//div[contains(@class,\"tabBar slds-grid slds-tabs--default slds-sub-tabs\")]//a)[1]");
	public static By childSubRecord = By.xpath("(//div[contains(@class,\"slds-sub-tabs\")]//a)[2]");
	public static By childRecord = By.xpath(
			"//div[contains(@class,\"slds-truncate\")]//a[contains(@class,\"slds-truncate\")]//child::span//span//slot");
	public static By searchDocInput = By.xpath("//*[@placeholder=\"Search this list...\"]");
	public static By checkbox = By.xpath(
			"//span[text()=\"Select item 1\"]//preceding-sibling::span//ancestor::div[contains(@class,\"slds-grid--align-spread\")]//input");
	public static By assignToMeButton = By.xpath("//div[@title='Assign to me']");
	public static By listViewButton = By.xpath("//*[contains(@title,'Select a List View') and @type='button']");
	public static By listViewButtonPartyRelation = By
			.xpath("//button[@title=\"Select a List View: Party Role Relationships\"]");
	public static By allRecDocuments = By.xpath("//*[text()=\"All Received Documents\"]");
	public static By parentDocID = By.xpath("//th//*[contains(@class,\"slds-truncate uiOutputText\")]");
	public static By parentDocumentID = By.xpath("(//td//*[contains(@class,\"slds-truncate uiOutputText\")])[1]");
	public static final By eleProfileImg = By.xpath("//*[contains(@class,\"actions__avatar\") and @type='button']");
	public static final By eleLogoutBtn = By.xpath("//*[text()=\"Log Out\" and @href=\"/secur/logout.jsp\"]");
	public static final By parentDocIDlist = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-cell-edit lockTrigger\")]//span[contains(@class,'uiOutputText')]");
	public static final By receivedDocColumn = By.xpath("//*[text()=\"Received Date\"]//parent::a");
	public static final By documentsStatus = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-cell-edit cellContainer\")]//*[contains(@class,\"forceInlineEditCell\")]//*[@class=\"slds-truncate\"]");
	public static By eleError = By.xpath("//div[contains(text(), 'Error:')]");
	public static By pageError = By.xpath("//div[contains(text(), 'Invalid ')]");
	public static By eleTransformDocument = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Rotate and Split\"]//parent::button");
	public static By docSort = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Document #\"]//parent::a");
	public static By listSort = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Account Name\"]//parent::a");
 
	public static By receivedDateSort = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Received Date\"]//parent::a");

	public static By documentSort = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Document #\"]//parent::a");
	public static By receivedDocRecords = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-cell-edit lockTrigger\")]//a");

	public static String recXpath = "//*[text()=\"{0}\"]//ancestor::td";

	public static String record = "//span[text()=\"{0}\"]//ancestor::td//following-sibling::td//*[text()=\"Open Document\"]";

	public static String assignToMe = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::tr//span[contains(@class,\"checkbox\")]";

	public static String createDate = "(//*[text()=\"{0}\"]//ancestor::td//following-sibling::td//span[contains(@class,\"uiOutputDateTime\")])[2]";

	public static String fieldBtn = "//button[@aria-label=\"{0}\"]";
	public static String dropDownValues = "//button[@aria-label=\"{0}\"]//parent::div//following-sibling::div//lightning-base-combobox-item[@role=\"option\"]//span[@class=\"slds-media__body\"]//child::span";
 
	public static String strAccount = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::span//parent::slot//parent::span)[2]";
	public static String strRecordName = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[@title=\"{0}\"]";
	public static By docOwnerName = By
			.xpath("//div[contains(@class,\"slds-grid\")]//a[contains(@class,\"slds-truncate\")]//child::span");
 
	public static By receivedDateColumn = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Received Date\"]//parent::a");
 
	public static By receivedDateColumnVal = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Received Date\"]//parent::a//span[contains(@class,\"slds-assistive-text\")]");
 
	public static By documentColumn = By
 
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Document #\"]//parent::a");
	public static By receivedDateSortState = By.xpath(
 
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Received Date\"]//parent::a//parent::div//span[contains(@class,\"text\")])[2]");
	public static By createdDateColumn = By
 
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Created Date\"]//parent::a");
	public static By createdDateSortState = By.xpath(
 
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Created Date\"]//parent::a//following-sibling::span)[2]");
	public static By docSortState = By.xpath(
 
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Document #\"]//parent::a//parent::div//span[contains(@class,\"text\")])[2]");
	public static By elereceiveRecord = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//a[@title='Patient Consent and Enrollment Form – English.pdf'])[1]");
 
	public static By eleEditButton = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//button[@title='Edit Effective To']");
	public static By eleInputDate = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//input[@name='EffectiveTo']");
	public static By eleInputInsuranceAddDate = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//input[@name='InsuranceAddDate_ICC__c']");
	public static By elePolicyHolderDOB = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//input[@name='PolicyholderDOB_ICC__c']");
	public static By elePlanID = By.xpath("//*[contains(@class,\"active lafPageHost\")]//input[@name='PlanID_ICC__c']");
	public static By eleSaveBtn = By.xpath("//*[contains(@class,\"active lafPageHost\")]//button[text()='Save']");
	public static By eleChangeOwner = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//button[@title=\"Change Owner\"]//lightning-primitive-icon[@exportparts=\"icon\"]");
	public static By searchUserInput = By.xpath("//*[@placeholder=\"Search Users...\"]");
	public static By changeOwnerBtn = By.xpath("//button[text()=\"Change Owner\"]");
	public static By listViewButtonAcc = By.xpath("//button[@title=\"Select a List View: Accounts\"]");
	public static By editStatusCase = By.xpath("//button[@title='Edit Status']");
	public static By eleClosedStatus = By.xpath("//lightning-base-combobox-item[@data-value='Closed']");
	public static By eleStatusDropDown = By.xpath("//lightning-base-combobox-item[@data-value='Closed']");
	public static By eleSaveBtnCases = By.xpath("//button[text()='Save']");
	public static By eleNursingOutReason = By
			.xpath("//li[text()='CAS-VR43: Nursing Outcome Reason is required when the Status is Closed.']");
	public static By eleNursingOut = By
			.xpath("//li[text()='CAS-VR42: Nursing Outcome is required when the Status is Closed.']");
	public static By eleEditNursing = By.xpath("//button[@title='Edit Nursing Outcome']");
	public static By eleGlobalType = By.xpath("//button[@aria-label=\"Global Opt-Out\"]");
	public static By eleShowActions = By.xpath("//*[text()='Show Actions']//ancestor::a");
	public static By elechangeOwnernew = By.xpath("//a[@title='Change Owner']");
	public static By elesubmitBtn = By.xpath("//*[@title='Submit']");
	public static By receivedDocName = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//div[contains(@data-target-selection-name, \"ReceivedDocument.Name\")]//slot[@name=\"output\"]/lightning-formatted-text");
	public static By userResultTitle = By.xpath("//h1[contains(@class, \"title\") and text()=\"User Results\"]");
	public static By userRecordName = By
			.xpath("//div[contains(@class, \"forceSearchResultsGridView\")]//a[@data-refid=\"recordId\"]");
	public static By backToClassifyBtn = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//span[text()=\"Back to Classify\"]");
	public static By eleProductIndication = By.xpath(
			"//*[contains(text(),'Product Indication')]//ancestor::div[@class=\"slds-grid\"]//following-sibling::div//input");
	public static By eleProductIndicationDropdown = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()='Product Indication']//parent::label//parent:: div //following-sibling:: div // li //child::span[contains(@class,\"option-text\")]");

	/************************
	 * Dynamic Elements
	 *
	 **************************************************/
	public static String strDocumentPageTitle = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strReceivedDocumentTitle = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String documentRecordLink = "//span[contains(@class,'slds-grid')]//child::a[@title=\"{0}\"]";
	public static String strDetailsPageDocTitle = "//div[contains(@class,\"entityNameTitle\")]//following-sibling::slot//*[text()=\"{0}\"]";
	public static String detailsPageTabsButton = "//*[contains(@class,\"active lafPageHost\")]//li//*[text()=\"{0}\"]";
	public static String detailsPageFields = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-text";
	public static String detailsPageLinkFields = "(//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-form-element\")]//*[text()=\"{0}\"]//ancestor::dt//following-sibling::dd//a//slot)[2]";
	public static String listViewOptions = "//*[text()=\"{0}\"]";
	public static String eleCcr = "//th//span//a[text()=concat(\'Patient-'\'{0}\''-CCR\')]";
	public static String openDocument = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-cell-edit lockTrigger cellContainer\")]//*[text()=\"{0}\"]//ancestor::td//following-sibling::td//span/a[text()=\"Open Document\"]";
	public static String checkboxes = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-cell-edit lockTrigger\")]//*[text()=\"{0}\"]//ancestor::tr//span[contains(@class,\"checkbox\")]";
	public static String docStatus = "(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-cell-edit lockTrigger cellContainer\")]//*[text()=\"{0}\"]//ancestor::td//following-sibling::td//*[contains(@class,\"slds-truncate\")])[3]";
	public static String transformDoc = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[@class=\"slds-grid\"]//following-sibling::div//input";
	public static String eleButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";
	public static String eleButtonDelete = "//*[contains(@class,\"active lafPageHost\")]//h3[text()=\"{0}\"]//following::div//*[text()=\"{1}\"]";
	public static String eleTable = "//table[@aria-label=\"{0}\"]//tbody";
	public static String strDocumentListTitle = "//span[text()=\"{0}\"]";
	public static String transformDoc2 = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[@class=\"slds-grid\"]//following-sibling::div//input)[2]";
	public static String strinactivationReason = "//*[contains(@class,\"active lafPageHost\")]//lightning-formatted-text[text()=\"{0}\"]";
 
	// public static String pharmacyRecord = "//*[contains(@class,\"active
	// lafPageHost\")]//*[text()=\"{0}\"]//ancestor::td//preceding-sibling::th//a[contains(text(),\"pharmacy\")]";
	public static String medicalRecord = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::td//preceding-sibling::th//*[contains(text(),\"Medical\")]//ancestor::a";
	public static String recordLink = "(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-cell-edit lockTrigger\")]//*[text()=\"{0}\"]//ancestor::tr//a)[1]";
	public static By eleAllcorrspndnce = By.xpath("//*[text()=\"All\"]//parent::a");
	public static By eleListView = By.xpath("//button[@title=\"Select a List View: Correspondences\"]");
	public static String detailsPageLinkFields2 = "(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//parent::dt//following-sibling::dd//a//span)[3]";
 
	public static String strTextBoxesInput = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//following-sibling::div//input";
	public static String strfields = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//span";
 
	public static String pharmacyRecord = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::td//preceding-sibling::th//*[contains(text(),\"Pharmacy\")]//ancestor::a";
	public static By listViewButtonCPE = By.xpath("//*[@title=\"Select a List View: Care Program Enrollees\"]");
	public static By actionsDropdwon = By.xpath("//a[@title=\"Change Owner\"]");
	public static String stractionsBtn = "//*[@title=\"{0}\"]//ancestor::td//following-sibling::td//*[text()=\"Show Actions\"]//ancestor::a[@role=\"button\"]";
	public static By sbmitBtn = By.xpath("//button[@title=\"Submit\"]");
	public static String editFieldList = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//button//span[@class=\"slds-truncate\"]";
	public static String editFieldListOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//lightning-base-combobox-item";
	public static String editButton = "//*[contains(@class,\"active lafPageHost\")]//button[@title=\"{0}\"]";
	public static String strOwnerNameField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\" and @class=\"test-id__field-label\"]//parent::div//following-sibling::div//a//span//span//span";
	public static By ownerFieldValue = By.xpath("//div[@role='dialog']//p/span[@class='uiOutputText']");
	public static String strFileName = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-cell-edit lockTrigger cellContainer\")]//*[text()=\"{0}\"]//ancestor::th//following-sibling::td[4]//span[contains(@class,\"slds-truncate\")]";
	public static By eleLatestDoc = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//th//a[contains(text(),\"Enrollment\")])[1]//ancestor::tr//th//a");
	public static String strCheckbox = ("//*[contains(@class,\"active lafPageHost\")]//th//a[contains(text(),\"{0}\")]//ancestor::tr//span[contains(@class,\"checkbox\")]");
	public static String strStatusDropDownInputBox = ("//*[contains(@class,\"active lafPageHost\")]//label[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//child::lightning-base-combobox");
	public static String strStatusListBox = ("//*[contains(@class,\"active lafPageHost\")]//label[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div[@aria-label=\"{0}\"]");
	public static String stropenDocument = "(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-cell-edit lockTrigger cellContainer\")]//*[contains(text(),\"{0}\")]//ancestor::th//following-sibling::td//a[text()=\"Open Document\"])[1]";
	public static By listViewButtonAccounts = By.xpath("//*[@title=\"Select a List View: Accounts\"]");
	public static String relatedTabSection = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static By eleCancelBtn = By.xpath("//*[contains(@class,\"active lafPageHost\")]//button[text()='Cancel']");

	public static By caselistViewButton = By.xpath("//button[@title=\"Select a List View: Cases\"]");
	//public static String relatedTabSection = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";



	public static String childDoc = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//following::lightning-formatted-text)[1]";
	
	////////////////////////////////////////////////////////////////////////////////
	/**
	 * Function: verify Recently View Document List view is displayed by default
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyRecentlyViewDocumentList() {

		try {
			Log.info("Recently View Documents List");
			waitForPageLoaded();
			By allReceiveddocumentList = getDynamicElement(strDocumentPageTitle, "Recently Viewed");
			waitAndVerifyElement(allReceiveddocumentList);
			waitForPresenceOfElementLocated(allReceiveddocumentList);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to load Recently Viewed List" + ". Error - " + e.getMessage());

		}
	}

	  /**
	       * Function : Valdiate the error message 
	       * 
	       * @author a.a.rajendra.chandak
	       */
	      public void validateErrorMessage(String errorMessage)
	      {
	    	 verifyReviewErrorMessaagePopup(errorMessage); 
	      }


		/** Function : to click on the CPE Record  
      	 * 
      	 * @author a.a.rajendra.chandak
      	 */
            public void clickOnCPERecordLink(String tableName, String fieldName)
            {
          	try
          	{
          	//By cpeLink = By.xpath("//*[@aria-label='"+tableName+"']/div//div[@ data-label= '"+fieldName+"']//ancestor::div[contains(@class,'head') ]//following-sibling::div[contains(@ class, 'body')]//div[contains(@ data-label,'"+fieldName+"')]//span");
          //	By cpeLink = By.xpath("//div[@ data-label= '"+fieldName+"']//ancestor::div[contains(@class,'head')]//following-sibling::div[contains(@ class, 'body')]//div[contains(@ data-label,'"+fieldName+"')]//span");
          	By cpeLink = By.xpath("//*[contains(@class,'active lafPageHost')]//following-sibling::div[contains(@ class, 'body')]//div[contains(@ data-label,'"+fieldName+"')]//span");	
          	waitAndVerifyElement(cpeLink);
        		setTimeOut(1000);
        		highLightElement(cpeLink);
        		String fieldValue = getText(cpeLink);
        		System.out.println(fieldValue);
        		setTimeOut(2000);
        		actionClick(cpeLink);
        		setTimeOut(2000);
        		//documentsPage.switchToChildWindow(fieldValue);
        		LoggingInfo("The CPE link is clicked and the user is on the CPE tab");
          	  }
          	  catch(Exception e)
          	  {
          		e.printStackTrace();
          		Log.error("The CPE link is not clicked" + e.getMessage());
      			Assert.fail("The CPE link is not clicked" + e.getMessage());
          		  
          	  }
            }












		  	  /**
	 * Function : Click on the Related tab --> go to particular section
	 * 
	 * @author a.a.rajendra.chandak
	 */
	public void goToParticularSectionInRelatedTab(String tabName, String section)
	{
			try 
			{
				refresh();
				setTimeOut(3000);
				waitForPageLoaded(); 
				setTimeOut(2000);
				LoggingInfo("Click on Related tab");
				By relatedTab = getDynamicElement(relatedTabSection, tabName);
				waitAndVerifyElement(relatedTab);
				scrollToElement(relatedTab);
				setTimeOut(2000);
				waitAndVerifyElement(relatedTab);
				scrollToElement(relatedTab);
				clickByJavascript(relatedTab);
				setTimeOut(4000);
				LoggingInfo("Navigate to Related tab ");
				By orderTable = getDynamicElement(relatedTabSection, section);
				setTimeOut(2000);
				scrollToElement(orderTable);
				setTimeOut(2000);
				waitAndVerifyElement(orderTable);
				setTimeOut(4000);
				LoggingInfo("Navigated to particular section");
			} 
			catch (Exception e) 
			{
				Log.error("Failed to navigate to particular section in the related tab" + e.getMessage());
				Assert.fail("Failed to navigate to particular section in the related tab  " + e.getMessage());
			}
		}




	/** 
	       * Select the dropdown value
	       *
	       * @author a.a.rajendra.chandak
	       */
	      public void selectTheDropDownValue(String fieldName ,String dropDownValue) 
			{
				try 
				{
					//By editTheElement = By.xpath("//button[contains(@ title, 'Edit "+fieldName+"')]");
					By editTheElement = By.xpath("//*[contains(@class,'active lafPageHost')]//button[contains(@ title, 'Edit "+fieldName+"')]");
					//refresh(); 
					//scrollUp("-2000");
		  			scrollToElement(editTheElement);
		  			setTimeOut(1000);
		  			click(editTheElement);
		  			setTimeOut(1000);
		            By fieldNameElement = By.xpath("//*[text() = '"+fieldName+"']/../div/lightning-base-combobox//button");
		            waitAndVerifyElement(fieldNameElement);
		            click(fieldNameElement);
		            setTimeOut(2000);
		            List<WebElement> dropDownOptions = getWebDriver().findElements(By.xpath("//*[text() = '"+fieldName+"']/../div//div//child::div//span[@ class = 'slds-media__body']/span"));
		   			 System.out.println("Count :" +dropDownOptions.size());
		   			 for(WebElement element : dropDownOptions)
		   			 {
		   				 String documentTypeName = element.getText(); 
		   				 System.out.println(documentTypeName);
		   				// scrollToWebElement(element);
		   				 scrollToHalfPage();
		   				 if(documentTypeName.contains(dropDownValue))
		   				 {
		   				 By dropDownValueToBeClicked = By.xpath("//*[text() = 'DCR Notes']/../div//div//child::div//span[@ class = 'slds-media__body']/span[contains(text(), '"+dropDownValue+"')]");
		   				// actionClick(dropDownValueToBeClicked);
		   				 click(dropDownValueToBeClicked);
		   				  break; 
		   				 }
		   			 }
		   				LoggingInfo("The value "+dropDownValue+" is selected in the "+fieldName+" drop-down field ");
		            }
		  		catch(Exception e)
		  		{
		  			e.printStackTrace();
		    		Log.error("The value "+dropDownValue+" is not selected in the "+fieldName+" drop-down field" +e.getMessage());
					Assert.fail("The value "+dropDownValue+" is not selected in the "+fieldName+" drop-down field" +e.getMessage());
			}
			}



	/** Function : to click on the Record Link, based on the table name and column name  
		 * 
		 * @author a.a.rajendra.chandak
		 */
	      public void clickOnTheHCPLink(String tableName, String fieldName, String linkName)
	      {
	    	try
	    	{
	    		List<WebElement> docTypeOptions = getWebDriver().findElements(By.xpath("//table[@aria-label='"+tableName+"']//th[@data-label='"+fieldName+"']//div[@ class='slds-truncate']//a"));
	   			 System.out.println("Count :" +docTypeOptions.size());
	   			 for(WebElement element : docTypeOptions)
	   			 {
	   				 String documentTypeName = element.getAttribute("title"); 
	   				 System.out.println(documentTypeName);
	   				// scrollToWebElement(element);
	   				 scrollToHalfPage();
	   				 if(documentTypeName.contains(linkName))
	   				 {
	   				  By elementToBeClicked = By.xpath("//span[contains(.,'"+linkName+"')]//ancestor::tr/th//a");
	   				  waitAndVerifyElement(elementToBeClicked);
	   				  String elementText = getText(elementToBeClicked);
	   				  actionClick(elementToBeClicked);
	   				  //clickByJavascript(elementToBeClicked);
	   				  setTimeOut(3000);
	   				  break;
	   				 }
	   			 }
	   			LoggingInfo("The HCP link is clicked");
	        	  }
	        	  catch(Exception e)
	        	  {
	        		e.printStackTrace();
	        		Log.error("The HCP link is not clicked" + e.getMessage());
					Assert.fail("The HCP link is not clicked" + e.getMessage());
	        	  }	
	      }





	/**
	 * Function : Switch to different tab 
	 * @author a.a.rajendra.chandak 
	 */
	 public void switchToChildWindow(String tabName)
	 {
		 try
		 {
			 Log.info("Open each child window");
			List<WebElement> li = getWebDriver().findElements(By.xpath("//*[@ class =  'tabBarItems slds-tabs--default__nav']//li[@ role = 'presentation']"));
			

				for (WebElement element : li) 
				{
				setTimeOut(2000);	
				String eleText = element.getText();
				element.click();
				setTimeOut(3000);
				String title = getWebDriver().getTitle(); 
				System.out.println(title);
				//if(title.contains(tabName))
			//	if(tabName.contains(title))
				if(StringUtils.contains(tabName, title))
				{
				 System.out.println(getWebDriver().getTitle());
				 break;
				}
				}				
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
			Log.error("Failed to open the child window" + e.getMessage());
			Assert.fail("Failed to open the child window" + ". Error - " + e.getMessage()); 
		 }
	 }



	/**
	  * Function : Click on the Name 
	  * 
	  * @author a.a.rajendra.chandak
	  */
	 public void verifyDocumentName()
	 {
		 try
		 {
			 waitForPageLoaded(); 
			 Log.info("Verify Document Type");
			 setTimeOut(1000);
			//th[@ title = 'Document Type']//ancestor::table/tbody/tr/td[4]
			//th[@ title = 'Document Type']//ancestor::table/tbody/tr/td[4]//span[@ class = 'slds-truncate']
			 List<WebElement> docTypeOptions = getWebDriver().findElements(By.xpath("//th[@ title = 'Name']//ancestor::table/tbody/tr/th//a"));
			 System.out.println("Count :" +docTypeOptions.size());
			 for(WebElement element : docTypeOptions)
			 {
				 String documentTypeName = element.getText(); 
				 System.out.println(documentTypeName);
				// scrollToWebElement(element);
				 scrollToHalfPage();
				 if(documentTypeName.contains("Automation"))
				 {
					element.click();
					break;
				 }
			 }
			 LoggingInfo("Document Name is clicked");
		 }
		 catch(Exception e)
		 {
			e.printStackTrace();
			Log.error("Failed to click Document Name" + e.getMessage());
			Assert.fail("Failed to click Document Name" + e.getMessage());
			 
		 }
	 }
	 
	/**
	 * Function : Click on the Related tab --> go to particular section --> click on View ALL
	 * 
	 * @author a.a.rajendra.chandak
	 
	public void goToParticularSectionInRelatedTabAndClickViewAll(String tabName, String section)
	{
			try 
			{
				refresh();
				setTimeOut(3000);
				waitForPageLoaded(); 
				setTimeOut(2000);
				LoggingInfo("Click on Related tab");
				By relatedTab = getDynamicElement(relatedTabSection, tabName);
				waitAndVerifyElement(relatedTab);
				scrollToElement(relatedTab);
				waitAndVerifyElement(relatedTab);
				clickByJavascript(relatedTab);
				LoggingInfo("Navigate to Related tab ");
				By orderTable = getDynamicElement(relatedTabSection, section);
				setTimeOut(2000);
				scrollToElement(orderTable);
				setTimeOut(4000);
				LoggingInfo("Navigated to particular section");
				waitAndVerifyElement(orderTable);
				bvPage.clickOnViewAll(section);
				setTimeOut(2000);
				documentsPage.switchToChildWindow(section);
				setTimeOut(2000);
			} 
			catch (Exception e) 
			{
				Log.error("Failed to navigate to orders table  " + e.getMessage());
				Assert.fail("Failed to navigate to orders table  " + e.getMessage());
			}
		}*/

			/**
	 * Function: Click on cancel button
	 * 
	 * @author Anand P
	 **/

	public void clickOnCancel() 
	{
		try 
		{
			setTimeOut(2000);
			waitAndVerifyElement(eleCancelBtn);
			scrollToElement(eleCancelBtn);
			click(eleCancelBtn);
			setTimeOut(2000);
			refresh(); 
			setTimeOut(3000);
			LoggingInfo("Clicked on Cancel button");

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			Log.error("Failed to Cancel button" + e.getMessage());
			Assert.fail("Failed to Cancel button" + ". Error - " + e.getMessage());
		}
	}  




		/**
	  * Function : Verify the dropDown/PickList Values
	  * 
	  * @author a.a.rajendra.chandak
	  */
		public void VerifyTheDropDownValue(String fieldName ,String dropDownValue) 
		{
			try 
			{
				
				//By editTheElement = By.xpath("//button[contains(@ title, 'Edit "+fieldName+"')]");
				By editTheElement = By.xpath("//*[contains(@class,'active lafPageHost')]//button[contains(@ title, 'Edit "+fieldName+"')]");
				//refresh(); 
				//scrollUp("-2000");
	  			scrollToElement(editTheElement);
	  			setTimeOut(1000);
	  			click(editTheElement);
	  			setTimeOut(1000);
	            By fieldNameElement = By.xpath("//*[text() = '"+fieldName+"']/../div/lightning-base-combobox//button");
	            waitAndVerifyElement(fieldNameElement);
	            click(fieldNameElement);
	            setTimeOut(2000);
	            List<WebElement> dropDownOptions = getWebDriver().findElements(By.xpath("//*[text() = '"+fieldName+"']/../div//div//child::div//span[@ class = 'slds-media__body']/span"));
	   			 System.out.println("Count :" +dropDownOptions.size());
	   			 for(WebElement element : dropDownOptions)
	   			 {
	   				 String documentTypeName = element.getText(); 
	   				 System.out.println(documentTypeName);
	   				// scrollToWebElement(element);
	   				 scrollToHalfPage();
	   				 if(documentTypeName.contains(dropDownValue))
	   				 {
	   				  Assert.assertTrue(true);
	   				  break; 
	   				 }
	   			 }
	   				LoggingInfo("The "+dropDownValue+" is available in the "+fieldName+" drop-down field ");
	            }
	  		catch(Exception e)
	  		{
	  			e.printStackTrace();
	    		Log.error("The "+dropDownValue+" is not available in the "+fieldName+" drop-down field" +e.getMessage());
				Assert.fail("The "+dropDownValue+" is not available in the "+fieldName+" drop-down field" +e.getMessage());
			}
		}


 
		/** Function : to click on the DCR Link, based on the table name and column name  
	 * 
	 * @author a.a.rajendra.chandak
	 */
      public void clickOnDCRLink(String tableName, String fieldName)
      {
    	try
    	{
    	By dcrElementLink = By.xpath("(//table[@aria-label='"+tableName+"']//th[@data-label='"+fieldName+"']//div[@ class='slds-truncate']//a//span[@ class = 'slds-truncate']//span)[2]");
    	waitAndVerifyElement(dcrElementLink);
  		setTimeOut(1000);
  		highLightElement(dcrElementLink);
  		String fieldValue = getText(dcrElementLink);
  		System.out.println(fieldValue);
  		setTimeOut(2000);
  		actionClick(dcrElementLink);
  		setTimeOut(2000);
  		documentsPage.switchToChildWindow(fieldValue);
  		LoggingInfo("The DCR link is clicked and the user is on the DCR tab");
    	  }
    	  catch(Exception e)
    	  {
    		e.printStackTrace();
    		Log.error("The DCR link is not clicked" + e.getMessage());
			Assert.fail("The DCR link is not clicked" + e.getMessage());		  
    	  }
      }




		/** Function : to click on the DCR Line ItemLink, based on the table name and column name  
  	 * 
  	 * @author a.a.rajendra.chandak
  	 */
        public void clickOnDCRLineItemLink(String tableName, String fieldName)
        {
      	try
      	{
      	By dcrElementLink = By.xpath("(//table[@aria-label='"+tableName+"']//th[@data-label='"+fieldName+"']//div[@ class='slds-truncate']//a//span[@ class = 'slds-truncate']//span)[2]");
      	waitAndVerifyElement(dcrElementLink);
    		setTimeOut(1000);
    		highLightElement(dcrElementLink);
    		String fieldValue = getText(dcrElementLink);
    		System.out.println(fieldValue);
    		setTimeOut(2000);
    		actionClick(dcrElementLink);
    		setTimeOut(2000);
    		//documentsPage.switchToChildWindow(fieldValue);
    		LoggingInfo("The DCR link is clicked and the user is on the DCR tab");
      	  }
      	  catch(Exception e)
      	  {
      		e.printStackTrace();
      		Log.error("The DCR link is not clicked" + e.getMessage());
  			Assert.fail("The DCR link is not clicked" + e.getMessage());
      		  
      	  }
        }




	/**
	 * Function : Verify the field value & click on the link  
	 * 
	 * @author a.a.rajendra.chandak 
	 * 
	
	public void verifyTheFieldValueAndClickOnTheFieldValueLink(String fieldName)
	{
		try
		{
		By CPEElement = null;	
		By eleField = getDynamicElement(strfields, fieldName);
		waitAndVerifyElement(eleField);
		scrollToElement(eleField);
		setTimeOut(1000);
		highLightElement(eleField);
		String fieldValue = getText(eleField);
		System.out.println(fieldValue);
		String[] word = fieldValue.split("Open ");
		String actualWord = word[1]; 
		setTimeOut(2000);
		waitAndVerifyElement(eleField);
		if(validateEditPenIconPresent(fieldName))
		{
		CPEElement = By.xpath("//button[contains(@title, 'Edit "+fieldName+"')]/../span//a");
		}
		else
		{
		CPEElement = By.xpath("//*[contains(@class,'active lafPageHost')]//span[text()='"+fieldName+"']//parent::div//following-sibling::div//a//span");
		}
		setTimeOut(2000);
		actionClick(CPEElement);
		setTimeOut(2000);
		//documentsPage.switchToChildWindow(actualWord);
		setTimeOut(3000);
		LoggingInfo("The "+fieldName+" value is populated and the link is also clicked");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("The "+fieldName+" value is populated and the link is also clicked "+e.getMessage());
			Assert.fail("The "+fieldName+" value is populated and the link is also clicked "+e.getMessage());
		}		
	}  */




	 	/**
	 * Function : Verify the field value
	 * 
	 * @author a.a.rajendra.chandak
	 * 
	 
	 public void verifyFieldValue(String fieldName, String expectedValue)
	 {
		 try
		 {
			 By eleField = getDynamicElement(strfields, fieldName);
				waitAndVerifyElement(eleField);
				scrollToElement(eleField);
				setTimeOut(2000);
				waitAndVerifyElement(eleField);
				highLightElement(eleField);
				String cpeText = getText(eleField);
				System.out.println(cpeText);
				setTimeOut(2000);
				if(expectedValue.contains(cpeText))
				{
				Assert.assertTrue(true);
				}
				LoggingInfo("The "+fieldName+" link is populated");
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
			 Log.error("The "+fieldName+" link is not populated "+e.getMessage());
			Assert.fail("The "+fieldName+" link is not populated "+e.getMessage());
		 }		 
	 }*/



	public void navigateToRecentlyViewedListView() 
		{
			try 
			{
				Log.info("Navigate to Recently Viewed List View");
				click(caselistViewButton);				
				By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
				waitAndVerifyElement(eleSearch);
				clickByJavascript(eleSearch);
				inputText(eleSearch, "Recently Viewed");
				Actions act = new Actions(getWebDriver());
				act.sendKeys(Keys.DOWN).perform();
				setTimeOut(2000);
				act.sendKeys(Keys.ENTER).perform();
				setTimeOut(2000);

			} 
			catch (Exception e) 
			{
				e.printStackTrace();
				Log.error("Failed to navigate to Received Document " + e.getMessage());
				Assert.fail("Failed to navigate to Received Document " + e.getMessage());
			}
		}


		 /**
	  * Function : To verify the checkbox is checked or not 
	  * 
	  * @author a.a.rajendra.chandak
	  */
	 public void verifyCheckBoxIsCheckedOrNot(String fieldName)
	 {
		 By elementField =  getDynamicElement(strfields, fieldName);
		 isCheckboxSelected(elementField);
	 }
	 

	 
		/**
	 * Function : To click on record/case based on its status
	 * 
	 * @author a.a.rajendra.chandak
	 * 
	 */
      public void clickOnRecordBasedOnRecordTypeAndStatus(String Table, String columnName1 , String columnValue1, String columnName2, String columnValue2)
      {    	  
        	try
        	{
        		//refresh(); 
        		waitForPageLoaded(); 
        		setTimeOut(2000);
        		List<WebElement> docTypeOptions = getWebDriver().findElements(By.xpath("//table[@aria-label='"+Table+"']//td[@data-label='"+columnName1+"']//span[contains(text(),'"+columnValue1+"')]//ancestor::td//following-sibling::td[@ data-label='"+columnName2+"']//div//span"));
   			 System.out.println("Count :" +docTypeOptions.size());
   			 for(WebElement element : docTypeOptions)
   			 {
   				 String documentTypeName = element.getText(); 
   				 System.out.println(documentTypeName);
   				// scrollToWebElement(element);
   				 scrollToHalfPage();
   				 if(documentTypeName.contains(columnValue2))
   				 {
   				 // By elementToBeClicked = By.xpath("//span[contains(.,'"+columnValue2+"')]//ancestor::tr/th//a");
   				  By elementToBeClicked = By.xpath("//*[contains(@class, 'active lafPageHost')]//span[contains(.,'"+columnValue2+"')]//ancestor::tr/th//a");  				  
   				  waitAndVerifyElement(elementToBeClicked);
 //  				  String elementText = getText(elementToBeClicked);
//   				  String[] word = elementText.split(" "); 
//   				  String actualWord = word[1];
   				  setTimeOut(1000);
//   				  actionClick(elementToBeClicked);
   				  clickByJavascript(elementToBeClicked);
   				  //setTimeOut(2000);
   				  //documentsPage.switchToChildWindow(actualWord);
   				  setTimeOut(3000);
   				  break;
   				 }
   			 }
   			 LoggingInfo("The link with status as "+columnValue2+" is clicked successfully ");
        	  }
        	  catch(Exception e)
        	  {
        		e.printStackTrace();
        		Log.error("The link with status as "+columnValue2+" is not clicked"+ e.getMessage());
    			Assert.fail("The link with status as "+columnValue2+" is not clicked" + e.getMessage());
        	  }
          }




		public void navigateToCaseListView() 
		{
		try 
		{
			Log.info("Navigate to AR Specialist Queue");
			click(caselistViewButton);
			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, "AR Specialist Queue");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to Received Document " + e.getMessage());
			Assert.fail("Failed to navigate to Received Document " + e.getMessage());
		}
	}
	
	/**
	 * Function : Click on the Related tab --> go to particular section --> click on View ALL
	 * 
	 * @author a.a.rajendra.chandak
	 */
	public void goToParticularSectionInRelatedTabAndClickViewAll(String tabName, String section)
	{
			try 
			{
				refresh();
				setTimeOut(3000);
				waitForPageLoaded(); 
				setTimeOut(2000);
				LoggingInfo("Click on Related tab");
				By relatedTab = getDynamicElement(relatedTabSection, tabName);
				waitAndVerifyElement(relatedTab);
				scrollToElement(relatedTab);
				waitAndVerifyElement(relatedTab);
				clickByJavascript(relatedTab);
				LoggingInfo("Navigate to Related tab ");
				By orderTable = getDynamicElement(relatedTabSection, section);
				setTimeOut(2000);
				scrollToElement(orderTable);
				setTimeOut(4000);
				LoggingInfo("Navigated to particular section");
				waitAndVerifyElement(orderTable);
				bvPage.clickOnViewAll(section);
				setTimeOut(2000);
				//documentsPage.switchToChildWindow(section);
				setTimeOut(2000);
			} 
			catch (Exception e) 
			{
				Log.error("Failed to navigate to orders table  " + e.getMessage());
				Assert.fail("Failed to navigate to orders table  " + e.getMessage());
			}
		}




	/**
	 * Function : Verify the field value & click on the link  
	 * 
	 * @author a.a.rajendra.chandak 
	 * 
	 */
	public void verifyTheFieldValueAndClickOnTheFieldValueLink(String fieldName)
	{
		try
		{
		By CPEElement = null;	
		By eleField = getDynamicElement(strfields, fieldName);
		waitAndVerifyElement(eleField);
		scrollToElement(eleField);
		setTimeOut(1000);
		highLightElement(eleField);
		String fieldValue = getText(eleField);
		System.out.println(fieldValue);
		String[] word = fieldValue.split("Open ");
		String actualWord = word[1]; 
		setTimeOut(2000);
		waitAndVerifyElement(eleField);
		if(validateEditPenIconPresent(fieldName))
		{
		CPEElement = By.xpath("//button[contains(@title, 'Edit "+fieldName+"')]/../span//a");
		}
		else
		{
		CPEElement = By.xpath("//*[contains(@class,'active lafPageHost')]//span[text()='"+fieldName+"']//parent::div//following-sibling::div//a//span");
		}
		setTimeOut(2000);
		actionClick(CPEElement);
		setTimeOut(2000);
		//documentsPage.switchToChildWindow(actualWord);
		setTimeOut(3000);
		LoggingInfo("The "+fieldName+" value is populated and the link is also clicked");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Log.error("The "+fieldName+" value is populated and the link is also clicked "+e.getMessage());
			Assert.fail("The "+fieldName+" value is populated and the link is also clicked "+e.getMessage());
		}		
	}





	/**
	 * Function : Verify the field value
	 * 
	 * @author a.a.rajendra.chandak
	 * 
	 */
	 public void verifyFieldValue(String fieldName, String expectedValue)
	 {
		 try
		 {
			 By eleField = getDynamicElement(strfields, fieldName);
				waitAndVerifyElement(eleField);
				scrollToElement(eleField);
				setTimeOut(2000);
				waitAndVerifyElement(eleField);
				highLightElement(eleField);
				String cpeText = getText(eleField);
				System.out.println(cpeText);
				setTimeOut(2000);
				if(expectedValue.contains(cpeText))
				{
				Assert.assertTrue(true);
				}
				LoggingInfo("The "+fieldName+" link is populated");
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
			 Log.error("The "+fieldName+" link is not populated "+e.getMessage());
			Assert.fail("The "+fieldName+" link is not populated "+e.getMessage());
		 }		 
	 }




	/*
	 * @author Anand Pawar
	 **/

	public void verifyMyAssessmentTaskList() {

		try {
			Log.info("My Assessments Tasks List View");
			waitForPageLoaded();
			By allReceiveddocumentList = getDynamicElement(strDocumentPageTitle, "My Assessment Tasks");
			waitAndVerifyElement(allReceiveddocumentList);
			waitForPresenceOfElementLocated(allReceiveddocumentList);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to load Recently Viewed List" + ". Error - " + e.getMessage());

		}
	}

	// Anand P
	public void verifyParentDocumentType() {
		try {

			waitForPageLoaded();
			String strDoc = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//slot//lightning-formatted-text";
			By eleDoc = getDynamicElement(strDoc, "Document Type");
			scrollToElement(eleDoc);
		//	waitAndVerifyElement(eleDoc);
		//	highLightElement(eleDoc);
		//	String text=getWebDriver().findElement(eleDoc).getText();
			List<WebElement> elements = getWebDriver().findElements(eleDoc);
		//    String text = elements.get(0).getText();

			if (elements.isEmpty()) {
				Log.info("Verified Document Type  as Null");
			}

			String strDoc2="(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//slot//span//span)";
			By eleParent = getDynamicElement(strDoc2, "Parent Received Document");
			scrollToElement(eleParent);
//			waitAndVerifyElement(eleParent);
//			highLightElement(eleParent);
			List<WebElement> elements2 = getWebDriver().findElements(eleParent);
	//	    String text2 = elements2.get(0).getText();

			
			if (elements2.isEmpty()) {
				Log.info("Verified Parent Received Document as Null");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify details" + ". Error - " + e.getMessage());

		}

	}

	// Anand P
	public void navigateToReceivedDocumentsTable() {
		try {

			By recDocTable = By
					.xpath("//*[contains(@class,'active lafPageHost')]//*[@aria-label='Received Documents']");
			waitAndVerifyElement(recDocTable);
			scrollToElement(recDocTable);
			waitFor(2000);
			Log.info("Navigated to Received document table");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to navigate" + ". Error - " + e.getMessage());

		}
	}

	// Anand P
	public void verifyOwnerName() {
		try {

			By ownerName = By.xpath(
					"//*[contains(@class,'active lafPageHost')]//*[@aria-label='Received Documents']//td[@data-label=\"Owner Name\"]//span");
			waitAndVerifyElement(ownerName);
			scrollToElement(ownerName);
			highLightElement(ownerName);
			waitFor(2000);
			Log.info("Owner name verified");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify owner name" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function : Click on add button
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnAddButton() {
		try {
			By addButton = getDynamicElement(eleButton, "Add");
			scrollToElement(addButton);
			waitAndVerifyElement(addButton);
			click(addButton);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify add " + e.getMessage());
			Assert.fail("Failed to verify add" + e.getMessage());
		}

	}

	// Anand P
	public void splitDocumentRight() {
		try {

			By eleTransform = By.xpath(
					"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Rotate and Split\"]//parent::button)[2]");
			waitAndVerifyElement(eleTransform);
			scrollToElement(eleTransform);
			clickByJavascript(eleTransform);
			setTimeOut(2000);

			ArrayList<String> transformations = new ArrayList<>(
					Arrays.asList("Rotate Right", "Flip", "Rotate Left", "Range of pages"));

			String transformation = transformations.get(0);
			By eleTransformDoc = getDynamicElement(transformDoc2, transformation);
			waitAndVerifyElement(eleTransformDoc);
			inputText(eleTransformDoc, "1");

			String transformation2 = transformations.get(3);
			By eleTransformDoc2 = getDynamicElement(transformDoc2, transformation2);
			waitAndVerifyElement(eleTransformDoc2);
			inputText(eleTransformDoc2, "1-4");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to split the document" + e.getMessage());
			Assert.fail("Failed to split the document" + e.getMessage());
		}
	}

	// Anand P
	public void classifyAddedDocument(String docType) {
		try {
			waitForPageLoaded();
			Log.info("Classify Parent document");
			setTimeOut(3000);
			By eleDoc = By.xpath(
					"(//*[contains(@class,\"slds-combobox\")]//*[text()=\"Document Type\"]//parent::label//parent::div//following-sibling::div)[2]");
			waitAndVerifyElement(eleDoc);
			click(eleDoc);

			setTimeOut(2000);
			WebElement option = getWebDriver().findElement(By.xpath(
					"(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"Document Type\"]//parent::label//parent::div//following-sibling::div//li// child::span[contains(@class,\"option-text\")])[16]"));
			option.click();

			setTimeOut(2000);
			LoggingInfo("Document Type classified as-" + docType);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Classify document" + e.getMessage());
			Assert.fail("Failed to Classify document" + e.getMessage());
		}

	}

	// Anand P
	public void splitDoc() {
		try {

			waitAndVerifyElement(eleTransformDocument);
			click(eleTransformDocument);
			setTimeOut(1000);

			ArrayList<String> transformations = new ArrayList<>(
					Arrays.asList("Rotate Right", "Flip", "Rotate Left", "Range of pages"));

			String transformation = transformations.get(1);
			By eleTransformDoc = getDynamicElement(transformDoc, transformation);
			waitAndVerifyElement(eleTransformDoc);
			inputText(eleTransformDoc, "1");

			String transformation2 = transformations.get(3);
			By eleTransformDoc2 = getDynamicElement(transformDoc, transformation2);
			waitAndVerifyElement(eleTransformDoc2);
			inputText(eleTransformDoc2, "1-4");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to split the document" + e.getMessage());
			Assert.fail("Failed to split the document" + e.getMessage());
		}
	}

	/*
	 * @author - Anand Pawar
	 */
	public void splitAndRotatDocument() {
		try {

			waitAndVerifyElement(eleTransformDocument);
			click(eleTransformDocument);
			setTimeOut(1000);

			ArrayList<String> transformations = new ArrayList<>(
					Arrays.asList("Rotate Right", "Flip", "Rotate Left", "Range of pages"));

			String transformation = transformations.get(0);
			By eleTransformDoc = getDynamicElement(transformDoc, transformation);
			waitAndVerifyElement(eleTransformDoc);
			inputText(eleTransformDoc, "1-2");

			String transformation2 = transformations.get(1);
			By eleTransformDoc2 = getDynamicElement(transformDoc, transformation2);
			waitAndVerifyElement(eleTransformDoc2);
			inputText(eleTransformDoc2, "2-3");

			String transformation3 = transformations.get(2);
			By eleTransformDoc3 = getDynamicElement(transformDoc, transformation3);
			waitAndVerifyElement(eleTransformDoc3);
			inputText(eleTransformDoc3, "3-4");

			String transformation4 = transformations.get(3);
			By eleTransformDoc4 = getDynamicElement(transformDoc, transformation4);
			waitAndVerifyElement(eleTransformDoc4);
			inputText(eleTransformDoc4, "1-4");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to split the document" + e.getMessage());
			Assert.fail("Failed to split the document" + e.getMessage());
		}
	}

	// Anand P
	public void clickChildDoc() {
		try {

			By childDoc = By.xpath(
					"(//*[contains(@class,'active lafPageHost')]//table[@aria-label='Received Documents']//th[@data-label=\"Name\"]//span//a)[1]");
			waitAndVerifyElement(childDoc);
			scrollToElement(childDoc);
			clickByJavascript(childDoc);
			waitFor(2000);
			Log.info("Clicked on child document");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify child doc" + ". Error - " + e.getMessage());

		}
	}

	public void clickChild2Doc() {
		try {

			By childDoc = By.xpath(
					"(//*[contains(@class,'active lafPageHost')]//table[@aria-label='Received Documents']//th[@data-label=\"Name\"]//span//a)[2]");
			waitAndVerifyElement(childDoc);
			scrollToElement(childDoc);
			clickByJavascript(childDoc);
			waitFor(2000);
			Log.info("Clicked on child document");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify child doc" + ". Error - " + e.getMessage());

		}
	}

	public void clickChild3Doc() {
		try {

			By childDoc = By.xpath(
					"(//*[contains(@class,'active lafPageHost')]//table[@aria-label='Received Documents']//th[@data-label=\"Name\"]//span//a)[3]");
			waitAndVerifyElement(childDoc);
			scrollToElement(childDoc);
			clickByJavascript(childDoc);
			waitFor(2000);
			Log.info("Clicked on child document");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify child doc" + ". Error - " + e.getMessage());

		}
	}

	public void clickChild6Doc() {
		try {

			By childDoc = By.xpath(
					"(//*[contains(@class,'active lafPageHost')]//table[@aria-label='Received Documents']//th[@data-label=\"Name\"]//span//a)[6]");
			waitAndVerifyElement(childDoc);
			scrollToElement(childDoc);
			clickByJavascript(childDoc);
			waitFor(2000);
			Log.info("Clicked on child document");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify child doc" + ". Error - " + e.getMessage());

		}
	}

	public void clickChild9Doc() {
		try {

			By childDoc = By.xpath(
					"(//*[contains(@class,'active lafPageHost')]//table[@aria-label='Received Documents']//th[@data-label=\"Name\"]//span//a)[9]");
			waitAndVerifyElement(childDoc);
			scrollToElement(childDoc);
			clickByJavascript(childDoc);
			waitFor(2000);
			Log.info("Clicked on child document");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify child doc" + ". Error - " + e.getMessage());

		}
	}

	// Anand P
	public void verifyChild1Record() {
		try {

			waitForPageLoaded();
			By child1DocId = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Document #\"]//parent::div//following-sibling::div//lightning-formatted-text");
			scrollToElement(child1DocId);
			waitAndVerifyElement(child1DocId);
			highLightElement(child1DocId);
			String child1 = getText(child1DocId);// return child1
			System.out.println(child1);

			Log.info("Verified child1 Record");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify details" + ". Error - " + e.getMessage());

		}

	}

	// Anand P
	public void clickParentReceivedDocument() {
		try {

			By parentDoc = By.xpath(
					"(//*[contains(@class,'active lafPageHost')]//*[text()='Parent Received Document']//parent::div//following-sibling::div//span)[1]");
			scrollToElement(parentDoc);
			waitAndVerifyElement(parentDoc);
			waitFor(2000);
			By link = By.xpath(
					"//*[contains(@class,'active lafPageHost')]//*[text()='Parent Received Document']//parent::div//following-sibling::div//slot//a");
			clickByJavascript(link);
			Log.info("Click on parent Received document");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify details" + ". Error - " + e.getMessage());

		}
	}

	// Anand P
	public void verifyPatientNameField() {
		try {

			By pName = getDynamicElement(detailsPageFields, "Patient First Name");
			scrollToElement(pName);
			waitAndVerifyElement(pName);
			highLightElement(pName);
			Log.info("Verified patient name is read only field");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify patient name field" + ". Error - " + e.getMessage());

		}
	}

	// Anand P
	public void verifyPatietnSearchTabNotVisible() {
		try {

			setTimeOut(2000);
			WebElement section1 = getWebDriver().findElement(By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"omniscript-body\")]//*[text()=\"Patient Search\"]"));
			Assert.assertFalse(section1.isDisplayed(), "Patient search tab not visible");
			setTimeOut(2000);

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println("Patient search tab is not present on the page, as expected.");
			LoggingInfo("Validated patient search tab not visible as expected");
		}

	}

	/**
	 * Function: verify upload button display on screen
	 * 
	 * @author Trupti Zure
	 **/

	public void VerifyUploadDocumentButton() {
		try {
			Log.info("Verify Upload document button");
			waitAndVerifyElement(uploadDoc);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Upload document button verifies" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Upload enrollment document
	 * 
	 * @author Kavyashree
	 **/
	public void uploadEnrollmentDocuement(String file) {
		try {
			Log.info("Upload enrollment Document");
			waitAndVerifyElement(uploadDoc);
			click(uploadDoc);
			setTimeOut(5000);
			Robot action = new Robot();
			action.setAutoDelay(2000);

			StringSelection sel = new StringSelection(file);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(sel, null);

			action.keyPress(KeyEvent.VK_CONTROL);
			setTimeOut(2000);
			action.keyPress(KeyEvent.VK_V);
			setTimeOut(2000);

			action.keyRelease(KeyEvent.VK_V);
			setTimeOut(2000);
			action.keyRelease(KeyEvent.VK_CONTROL);
			setTimeOut(2000);

			action.keyPress(KeyEvent.VK_ENTER);
			setTimeOut(2000);
			action.keyRelease(KeyEvent.VK_ENTER);
			setTimeOut(2000);
			waitForPresenceOfElementLocated(doneButton);
			// waitAndVerifyElement(doneButton);
			setTimeOut(6000);
			click(doneButton);
			LoggingInfo("Successfully uploaded document");
			Assert.assertTrue(true, "Successfully uploaded document ");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to upload document " + e.getMessage());
			Assert.fail("Failed to upload document" + e.getMessage());
		}

	}

	/**
	 * Function: Verify record is displayed
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyRecord(String fileName) {
		try {
			Log.info("Verify docuement record");
			waitForPageLoaded();
			By documentRecord = getDynamicElement(strReceivedDocumentTitle, fileName);
			waitAndVerifyElement(documentRecord);
			highLightElement(documentRecord);
			LoggingInfo(fileName + "-Docuement record verified");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify document record " + e.getMessage());
			Assert.fail("Failed to verify document record " + e.getMessage());
		}
	}

	/**
	 * Function: Verify record and click on record
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyRecordAndClick(String fileName) {
		try {
			Log.info("Verify docuement record");
			waitForPageLoaded();
			System.out.println("FN" + fileName);
			By documentRecord = getDynamicElement(strReceivedDocumentTitle, fileName);
			waitAndVerifyElement(documentRecord);
			scrollToElement(documentRecord);
			click(documentRecord);
			LoggingInfo(fileName + "-Docuement record verified");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify document record " + e.getMessage());
			Assert.fail("Failed to verify document record " + e.getMessage());
		}
	}

	/**
	 * Function: Verify record and click on record
	 * 
	 * @author Anand Pawar
	 **/
	public void verifyRecordAndOpen(String date) {
		try {

			By openDoc = getDynamicElement(record, date);
			waitAndVerifyElement(openDoc);
			scrollToElement(openDoc);
			click(openDoc);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify document record " + e.getMessage());
			Assert.fail("Failed to verify document record " + e.getMessage());
		}
	}

	/**
	 * Function: search document on list view
	 * 
	 * @author Trupti Zure
	 **/
	public void searchDocument(String fileName) {
		try {
			click(searchDocInput);
			inputText(searchDocInput, fileName);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.ENTER).perform();
			// genericKeyPress(searchDocInput, "Enter");
			setTimeOut(10000);
			waitForPageLoaded();
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed search document" + e.getMessage());
			Assert.fail("Failed search document" + e.getMessage());

		}
	}

	/**
	 * Function: search document on list view
	 * 
	 * @author Anand P
	 **/
	public String searchDocumentAndAssign(String cpeName) {

		String createdDate = "";
		try {
			By record = getDynamicElement(recXpath, cpeName);
			waitAndVerifyElement(record);
			highLightElement(record);

			By checkBox = getDynamicElement(assignToMe, cpeName);
			click(checkBox);

			LoggingInfo("Clicked on checkbox");

			By date = getDynamicElement(createDate, cpeName);
			createdDate = getText(date);

			waitAndVerifyElement(assignToMeButton);
			clickByJavascript(assignToMeButton);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Fail to assign" + e.getMessage());
			Assert.fail("Fail to assign" + e.getMessage());

		}

		return createdDate;
	}

	/**
	 * Function: search document on list view
	 * 
	 * @author Anand P
	 **/
	public void searchDocumentWithName(String fileName) {
		try {
			click(searchDocInput);
			inputText(searchDocInput, fileName);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.ENTER).perform();
			// genericKeyPress(searchDocInput, "Enter");
			setTimeOut(3000);
			clickByJavascript(receivedDateSort);
			setTimeOut(3000);
			clickByJavascript(documentSort);
			waitForPageLoaded();
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed search document" + e.getMessage());
			Assert.fail("Failed search document" + e.getMessage());

		}
	}

	/**
	 * Function:Get parent document id
	 * 
	 * @author Trupti Zure
	 **/
	public String getParentDocumentID(String fileName) {
		String parentDocID = null;
		int maxRetries = 4;
		int retryCount = 0;

		try {
			setTimeOut(2000);
			click(searchDocInput);
			inputText(searchDocInput, fileName);
			genericKeyPress(searchDocInput, "Enter");
			waitForPageLoaded();

			By enrollementFileRecord = By.xpath("(//td//*[contains(@class,\"slds-truncate uiOutputText\")])[1]");
			boolean docFound = false;

			while (retryCount < maxRetries && !docFound) {
				try {
					WebElement parentDocumentElement = getWebDriver().findElement(enrollementFileRecord);
					LoggingInfo("Get document ID of parent document");
					parentDocID = parentDocumentElement.getText().trim();
					Log.info("Salesforce ID of parent document: " + parentDocID);
					docFound = true;
				} catch (StaleElementReferenceException e) {
					retryCount++;
					if (retryCount < maxRetries) {
						click(docSort);
						setTimeOut(2000);
					} else {
						throw e;
					}
				}
			}

			if (!docFound) {
				throw new NoSuchElementException("Enrollement File Record not found after retries.");
			}

			setTimeOut(3000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get document record ID: " + e.getMessage());
			Assert.fail("Failed to get document record ID: " + e.getMessage());
		}

		return parentDocID;
	}

	/**
	 * Function:Get parent document id
	 * 
	 * @author Trupti Zure
	 **/
	public String getParentDocID(String fileName) {
		String parentSFID = null;
		try {
			Log.info("Navigate to All Received Documents");
			click(listViewButton);
			setTimeOut(2000);
			click(allRecDocuments);

			waitForPageLoaded();
			LoggingInfo("Navigated to All Received Documents list");

			click(searchDocInput);
			inputText(searchDocInput, fileName);
			genericKeyPress(searchDocInput, "Enter");
			waitForPageLoaded();

			By enrollementFilerRecord = getDynamicElement(documentRecordLink, fileName);
			waitAndVerifyElement(enrollementFilerRecord);
			verifyRecord(fileName);

			Log.info("Get salesforce ID of parent document");
			parentSFID = getText(parentDocID);
			Log.info("salesforce ID of parent document-" + parentSFID);

			setTimeOut(3000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get document record ID" + e.getMessage());
			Assert.fail("Failed to get document record ID" + e.getMessage());

		}
		return parentSFID;
	}

	/**
	 * Function : Assign the document
	 * 
	 * @author Samarth S
	 **/
	public void assigntoMe(String docID) {
		By checkbox = getDynamicElement(checkboxes, docID);
		waitAndVerifyElement(checkbox);
		clickByJavascript(checkbox);
		setTimeOut(2000);
		LoggingInfo("Clicked on checkbox");

		waitAndVerifyElement(assignToMeButton);
		clickByJavascript(assignToMeButton);
		setTimeOut(2000);
		LoggingInfo("Clicked on Assign to me button");
	}

	/**
	 * Function : Navigate to received document worklist
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToReceiveddocument() {

		try {
			Log.info("Navigate to received document worklist");
			click(listViewButton);

			By eleMyReceivedDocList = getDynamicElement(listViewOptions, "Received Document Worklist");
			click(eleMyReceivedDocList);

			waitForPageLoaded();
			By myReceiveddocumentList = getDynamicElement(strDocumentPageTitle, "Received Document Worklist");
			waitAndVerifyElement(myReceiveddocumentList);
			setTimeOut(2000);
			LoggingInfo("Navigated to Received Document Worklist");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to Received Document " + e.getMessage());
			Assert.fail("Failed to navigate to Received Document " + e.getMessage());
		}

	}

	/**
	 * Function : Verify document and assign the document to DIS user
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyAndAssignDocumentID(String docID) {
		int maxRetries = 4;
		int retryCount = 0;

		try {
			setTimeOut(5000);
			boolean docFound = false;
			while (retryCount < maxRetries && !docFound) {
				click(searchDocInput);
				inputText(searchDocInput, docID);
				genericKeyPress(searchDocInput, "Enter");
				waitForPageLoaded();
				setTimeOut(3000);
				retryCount++;
				docFound = isElementDisplayed(parentDocIDlist);
				if (!docFound) {
					refresh();
					clickByJavascript(receivedDateSort);
					setTimeOut(3000);
				}
			}

			By checkbox = getDynamicElement(checkboxes, docID);
			waitAndVerifyElement(checkbox);
			clickByJavascript(checkbox);
			setTimeOut(2000);
			LoggingInfo("Clicked on checkbox");

			waitAndVerifyElement(assignToMeButton);
			clickByJavascript(assignToMeButton);
			setTimeOut(2000);
			LoggingInfo("Clicked on Assign to me button");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to assign record " + e.getMessage());
			Assert.fail("Failed to assign record " + e.getMessage());
		}

	}

	/**
	 * Function : Verify document and assign the document to DIS user
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyAndAssignDocID(String docID) {
		try {
			waitAndVerifyElement(receivedDateColumn);
			String sortingState;

			// Sort by date
			do {
				sortingState = getText(receivedDateSortState);

				if (sortingState != null && !sortingState.contains("Sorted Descending")) {
					clickByJavascript(receivedDateColumn);
					setTimeOut(1000);
				}
				sortingState = getText(receivedDateSortState);
			} while (sortingState != null && !sortingState.contains("Sorted Descending"));

			// Sort by document
			do {
				sortingState = getText(docSortState);

				if (sortingState != null && !sortingState.contains("Sorted Descending")) {
					clickByJavascript(documentColumn);
					setTimeOut(1000);
				}
				sortingState = getText(docSortState);
			} while (sortingState != null && !sortingState.contains("Sorted Descending"));

			boolean docIdFound = false;
			List<WebElement> listOptions = getWebDriver().findElements(parentDocIDlist);
			for (int attempt = 0; attempt < 3; attempt++) {
				if (methodToAvoidStaleElementReferenceErrorElements(parentDocIDlist)) {
					waitAndVerifyElement(parentDocIDlist);
					setTimeOut(1000);
					listOptions = getWebDriver().findElements(parentDocIDlist);

					// Iterate through the list and check each item
					for (WebElement element : listOptions) {
						String ids = element.getText();
						System.out.println(ids);
						setTimeOut(1000);

						if (ids.equalsIgnoreCase(docID)) {
							JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
							js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
									highlightStyle);
							setTimeOut(1000);

							By checkbox = getDynamicElement(checkboxes, docID);
							waitAndVerifyElement(checkbox);
							clickByJavascript(checkbox);
							setTimeOut(2000);
							LoggingInfo("Clicked on checkbox");

							waitAndVerifyElement(assignToMeButton);
							clickByJavascript(assignToMeButton);
							setTimeOut(2000);
							LoggingInfo("Clicked on Assign to me button");
							docIdFound = true;
							break;
						}
					}

					if (docIdFound) {
						break;
					}

					scrollToNextPage();
					setTimeOut(2000);
				}

				if (docIdFound) {
					break;
				}

				click(docSort);
				setTimeOut(2000);
			}

			if (!docIdFound) {
				Log.error("Document ID not found after 3 attempts: " + docID);
				Assert.fail("Failed to find document ID: " + docID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify document record " + e.getMessage());
			Assert.fail("Failed to verify document record " + e.getMessage());
		}
	}

	// Scroll to the next page to load more elements dynamically
	private void scrollToNextPage() {
		JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
		js.executeScript("window.scrollBy(0, 250);"); // Scroll down by 250px (adjust as necessary)
	}

	public boolean methodToAvoidStaleElementReferenceErrorElements(By locator) {
		try {
			List<WebElement> elements = getWebDriver().findElements(locator);
			return elements != null && elements.size() > 0;
		} catch (StaleElementReferenceException e) {
			return false;
		}
	}

	// Anand P
	public void clickAndAssignCPE() {
		try {
			waitForPageLoaded();
			setTimeOut(2000);
			By record = By.xpath("(//span[@class=\"slds-checkbox_faux\"])[2]");
			waitAndVerifyElement(record);
			clickByJavascript(record);
			setTimeOut(2000);

			waitAndVerifyElement(assignToMeButton);
			clickByJavascript(assignToMeButton);
			setTimeOut(10000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Anand P
	public void navigateMyCPEListView() {

		try {
			Log.info("Navigate to all care program enrollee worklist");
			click(listViewButtonCPE);

			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			// *[@placeholder=\"Search this list...\"]
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, "My Care Program Enrollees");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to My Care Program Enrollees " + e.getMessage());
			Assert.fail("Failed to navigate to My Care Program Enrollees " + e.getMessage());
		}

	}

	// Anand
	public void navigateNurseEducatorsListView() {
		try {
			waitForPageLoaded();
			By button = By.xpath("//button[@title=\"Select a List View: Cases\"]");
			waitAndVerifyElement(button);
			clickByJavascript(button);
			setTimeOut(3000);

			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			// *[@placeholder=\"Search this list...\"]
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, "DMW Nurse Educators");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Anand P
	public void verifyNewCaseTitle() {
		try {
			waitForPageLoaded();
			By title = By.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"New Case: Injection Training\"])[1]");
			waitAndVerifyElement(title);
			highLightElement(title);
			setTimeOut(3000);
			LoggingInfo("Verified New Case: Injection Training title");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Anand
	public void verifyAccountAndHCPName(String pName, String hcpName) {
		try {
			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Account Name");
			scrollToElement(elepatientFNameInput);
			waitAndVerifyElement(elepatientFNameInput);
			// verifyAndEnterInfoInputField(elepatientFNameInput, pName, "Account Name");

			By hcpNameInput = getDynamicElement(strTextBoxesInput, "HCP Account Name");
			scrollToElement(hcpNameInput);
			waitAndVerifyElement(hcpNameInput);
			// verifyAndEnterInfoInputField(hcpNameInput, hcpName, "HCP Account Name");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enterMIData() {
		try {
			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Care Program MI");
			scrollToElement(elepatientFNameInput);
			waitAndVerifyElement(elepatientFNameInput);
			click(elepatientFNameInput);
			inputText(elepatientFNameInput, "DMW");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			// verifyAndEnterInfoInputField(elepatientFNameInput, pName, "Account Name");
			By recodID = By.xpath("(//tbody//tr//td//a[@data-refid=\"recordId\"])[51]");
			click(recodID);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Function: enter secondary pharmacy member
	 * 
	 * @author Anand Pawar
	 **/
	public void enterSecondaryPharmacy(String name, String phone, String memNumber, String groupNumber) {
		try {
			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Payer");
			scrollToElement(elepatientFNameInput);
			waitAndVerifyElement(elepatientFNameInput);
			click(elepatientFNameInput);
			inputText(elepatientFNameInput, name);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			// verifyAndEnterInfoInputField(elepatientFNameInput, pName, "Account Name");
			By button = By.xpath("//span[@class='slds-radio_faux']");
			click(button);
			setTimeOut(2000);

			By selectButton = By.xpath("//button[text()=\"Select\"]");
			click(selectButton);

			By nameInput = getDynamicElement(strTextBoxesInput, "Name");
			scrollToElement(nameInput);
			waitAndVerifyElement(nameInput);
			inputText(nameInput, name);

			By planId = getDynamicElement(strTextBoxesInput, "Plan ID");
			scrollToElement(planId);
			waitAndVerifyElement(planId);
			inputText(planId, "plan");

			By insuranceAddDate = getDynamicElement(strTextBoxesInput, "Insurance Add Date");
			scrollToElement(insuranceAddDate);
			waitAndVerifyElement(insuranceAddDate);
			inputText(insuranceAddDate, "3/12/2025");

			By dobDate = getDynamicElement(strTextBoxesInput, "Policyholder DOB");
			scrollToElement(dobDate);
			waitAndVerifyElement(dobDate);
			inputText(dobDate, "3/12/2002");

			By elePhone = getDynamicElement(strTextBoxesInput, "Insurance Phone");
			scrollToElement(elePhone);
			waitAndVerifyElement(elePhone);
			inputText(elePhone, phone);

			By eleGrp = getDynamicElement(strTextBoxesInput, "Group Number");
			scrollToElement(eleGrp);
			waitAndVerifyElement(eleGrp);
			inputText(eleGrp, groupNumber);

			By eleMem = getDynamicElement(strTextBoxesInput, "Member Number");
			scrollToElement(eleMem);
			waitAndVerifyElement(eleMem);
			inputText(eleMem, memNumber);

			selectMemberPlanType("Secondary");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Function: enter secondary medical member
	 * 
	 * @author Anand Pawar
	 **/
	public void enterSecondaryMedical(String name, String memNumber, String groupNumber) {
		try {
			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Payer");
			scrollToElement(elepatientFNameInput);
			waitAndVerifyElement(elepatientFNameInput);
			click(elepatientFNameInput);
			inputText(elepatientFNameInput, name);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			// verifyAndEnterInfoInputField(elepatientFNameInput, pName, "Account Name");
			By button = By.xpath("//span[@class='slds-radio_faux']");
			click(button);
			setTimeOut(2000);

			By selectButton = By.xpath("//button[text()=\"Select\"]");
			click(selectButton);

			By nameInput = getDynamicElement(strTextBoxesInput, "Name");
			scrollToElement(nameInput);
			waitAndVerifyElement(nameInput);
			inputText(nameInput, name);

			By eleGrp = getDynamicElement(strTextBoxesInput, "Group Number");
			scrollToElement(eleGrp);
			waitAndVerifyElement(eleGrp);
			inputText(eleGrp, groupNumber);

			By eleMem = getDynamicElement(strTextBoxesInput, "Member Number");
			scrollToElement(eleMem);
			waitAndVerifyElement(eleMem);
			inputText(eleMem, memNumber);

			selectMemberPlanType("Secondary");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enterWMData() {
		try {
			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Care Program");
			scrollToElement(elepatientFNameInput);
			waitAndVerifyElement(elepatientFNameInput);
			click(elepatientFNameInput);
			inputText(elepatientFNameInput, "DMW");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			// verifyAndEnterInfoInputField(elepatientFNameInput, pName, "Account Name");

			By button = By.xpath("//span[@class='slds-radio_faux']");
			click(button);
			setTimeOut(2000);

			By selectButton = By.xpath("//button[text()=\"Select\"]");
			click(selectButton);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enterAccountAndHCPName() {
		try {
			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Account Name");
			scrollToElement(elepatientFNameInput);
			waitAndVerifyElement(elepatientFNameInput);
			click(elepatientFNameInput);
			inputText(elepatientFNameInput, "Automation");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();

			By button = By.xpath("//span[@class='slds-radio_faux']");
			click(button);
			setTimeOut(2000);

			By selectButton = By.xpath("//button[text()=\"Select\"]");
			click(selectButton);

			By hcpNameInput = getDynamicElement(strTextBoxesInput, "HCP Account Name");
			scrollToElement(hcpNameInput);
			waitAndVerifyElement(hcpNameInput);
			click(hcpNameInput);
			inputText(hcpNameInput, "Automation");
			act.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();

			click(button);
			setTimeOut(2000);

			clickByJavascript(selectButton);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Anand
	public void selectTrainingType(String type) {
		try {
			waitForPageLoaded();
			Log.info("Select training type");
			setTimeOut(3000);
			waitAndVerifyElement(eleType);
			scrollToElement(eleType);
			clickByJavascript(eleType);
			setTimeOut(2000);
			By options = By.xpath(
					"//button[@aria-label=\"Type of Training\"]//parent::div//following-sibling::div//lightning-base-combobox-item[@role=\"option\"]//span[@class=\"slds-media__body\"]//child::span");
			selectItemFromDropDown(eleType, options, type);
			LoggingInfo("Training Type selected as-" + type);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select" + e.getMessage());
			Assert.fail("Failed to select" + e.getMessage());
		}

	}

	/**
	 * Function: select member plan
	 * 
	 * @author Anand P
	 **/
	public void selectMemberPlanType(String type) {
		try {
			waitForPageLoaded();
			Log.info("Select member plan type");
			setTimeOut(3000);
			By outcomeBtn = getDynamicElement(fieldBtn, "Primary/Secondary/Tertiary");
			waitAndVerifyElement(outcomeBtn);
			scrollToElement(outcomeBtn);
			clickByJavascript(outcomeBtn);
			setTimeOut(2000);
			By options = getDynamicElement(dropDownValues, "Primary/Secondary/Tertiary");
			selectItemFromDropDown(outcomeBtn, options, type);
			LoggingInfo("Tyoe selected as-" + type);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select" + e.getMessage());
			Assert.fail("Failed to select" + e.getMessage());
		}

	}

	// Anand
	public void selectHCPTrainingStatus(String statusTr) {
		try {
			waitForPageLoaded();
			Log.info("Select training status");
			setTimeOut(3000);
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			clickByJavascript(eleStatus);
			setTimeOut(2000);
			By options = By.xpath(
					"//button[@aria-label=\"HCP Training Status\"]//parent::div//following-sibling::div//lightning-base-combobox-item[@role=\"option\"]//span[@class=\"slds-media__body\"]//child::span");
			selectItemFromDropDown(eleStatus, options, statusTr);

			LoggingInfo("HCP Training Type selected as-" + statusTr);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select" + e.getMessage());
			Assert.fail("Failed to select" + e.getMessage());
		}

	}

	// Anand
	public void selectCaseStatus(String caseStatus) {
		try {
			waitForPageLoaded();
			Log.info("Select status");
			setTimeOut(3000);
			waitAndVerifyElement(status);
			scrollToElement(status);
			clickByJavascript(status);
			setTimeOut(2000);
			By options = By.xpath(
					"//button[@aria-label=\"Status\"]//parent::div//following-sibling::div//lightning-base-combobox-item[@role=\"option\"]//span[@class=\"slds-media__body\"]//child::span");
			selectItemFromDropDown(status, options, caseStatus);
			LoggingInfo("Case Status selected as-" + caseStatus);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select status" + e.getMessage());
			Assert.fail("Failed to select" + e.getMessage());
		}

	}

	// Anand P
	public void selectNursingOutcome(String outcome) {
		try {
			waitForPageLoaded();
			Log.info("Select status");
			setTimeOut(3000);
			By outcomeBtn = getDynamicElement(fieldBtn, "Nursing Outcome");
			waitAndVerifyElement(outcomeBtn);
			scrollToElement(outcomeBtn);
			clickByJavascript(outcomeBtn);
			setTimeOut(2000);
			By options = getDynamicElement(dropDownValues, "Nursing Outcome");
			selectItemFromDropDown(outcomeBtn, options, outcome);
			LoggingInfo("Outcome selected as-" + outcome);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select outcome" + e.getMessage());
			Assert.fail("Failed to select" + e.getMessage());
		}

	}

	// Anand P
	public void selectNursingOutcomeReason(String outcomeReason) {
		try {
			waitForPageLoaded();
			Log.info("Select outcome reason");
			setTimeOut(3000);
			By outcomeBtn = getDynamicElement(fieldBtn, "Nursing Outcome Reason");
			waitAndVerifyElement(outcomeBtn);
			scrollToElement(outcomeBtn);
			clickByJavascript(outcomeBtn);
			setTimeOut(2000);
			By options = getDynamicElement(dropDownValues, "Nursing Outcome Reason");
			selectItemFromDropDown(outcomeBtn, options, outcomeReason);
			LoggingInfo("Outcome selected as-" + outcomeReason);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select outcome Reason" + e.getMessage());
			Assert.fail("Failed to select" + e.getMessage());
		}

	}

	/**
	 * Function: To get case number
	 * 
	 * @author Anand P
	 **/
	public String getCaseNumber() {
		String caseNumber = "";
		try {
			waitForPageLoaded();
			By number = By
					.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Case\"]//parent::slot//parent::div//following-sibling::slot//lightning-formatted-text");
			waitAndVerifyElement(number);
			scrollToElement(number);
			caseNumber = getText(number);
			LoggingInfo("Case number is -" + caseNumber);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get case number" + e.getMessage());
			Assert.fail("Failed to get case number" + e.getMessage());
		}

		return caseNumber;

	}

	public void clickOnEditButton() {
		try {
			By button = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"Dupixent\")]//ancestor::tr//td//button");
			waitAndVerifyElement(button);
			clickByJavascript(button);
			setTimeOut(3000);

			By editButton = By.xpath("//a[@title=\"Edit\"]");
			waitAndVerifyElement(editButton);
			clickByJavascript(editButton);
			Log.info("Clicked on edit button");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickOnNextButton() {
		try {

//			getWebDriver().switchTo().frame(1);
//			By button = By.xpath("//button[text()='Next']");
//			waitAndVerifyElement(button);
//			clickByJavascript(button);
//			setTimeOut(3000);
//			getWebDriver().switchTo().parentFrame();

			By button = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Next\"]//parent::button");
			waitAndVerifyElement(button);
			clickByJavascript(button);
			setTimeOut(3000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickOnNextButtonInCM() {
		try {

			By button = By.xpath("//*[text()='Next']");
			waitAndVerifyElement(button);
			clickByJavascript(button);
			setTimeOut(3000);
			getWebDriver().switchTo().parentFrame();

			setTimeOut(3000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickNextButton() {
		try {

			By button = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Next\"]//parent::button");
			waitAndVerifyElement(button);
			clickByJavascript(button);
			setTimeOut(3000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Function: Click on CPE
	 * 
	 * @author Anand P
	 **/

	public void clickOnCPE() {
		try {
			By button = By.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='Created Date']//parent::a");
			waitAndVerifyElement(button);
			clickByJavascript(button);
			setTimeOut(3000);

			By myCPE = By.xpath("(//*[contains(@class,\"active lafPageHost\")]//td[@role=\"gridcell\"]//a)[1]");
			waitAndVerifyElement(myCPE);
			clickByJavascript(myCPE);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Function : Navigate to my received document id
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToMyReceivedDoc(String docID, String status) {
		int maxRetries = 4;
		int retryCount = 0;
		waitForPageLoaded();
		By myReceiveddocumentList = getDynamicElement(strDocumentPageTitle, "My Received Documents");
		waitAndVerifyElement(myReceiveddocumentList);
		setTimeOut(2000);
		LoggingInfo("User is navigated to My Received Documents");
		Log.info("Verify received document id");
		boolean docFound = false;
		while (retryCount < maxRetries && !docFound) {
			click(searchDocInput);
			inputText(searchDocInput, docID);
			genericKeyPress(searchDocInput, "Enter");
			waitForPageLoaded();
			clickByJavascript(docSort);
			setTimeOut(3000);
			clickByJavascript(docSort);
			retryCount++;
			docFound = isElementDisplayed(parentDocIDlist);
			if (!docFound) {
				refresh();
				setTimeOut(3000);
			}

		}
		By documentStatus = getDynamicElement(docStatus, docID);
		highLightElement(documentStatus);
		setTimeOut(2000);
		verifyDetails(documentStatus, status, "Document status");
		LoggingInfo(status + "-Document status verified");

		By openDoc = getDynamicElement(openDocument, docID);
		waitAndVerifyElement(openDoc);
		clickByJavascript(openDoc);
		setTimeOut(5000);
		LoggingInfo("Clicked on open document");

	}

	/**
	 * Function : Navigate to my received document id and check status
	 * 
	 * @author Trupti Zure
	 **/

	public void navigateToMyReceivedDocument(String docID, String status) {
		try {
			waitForPageLoaded();
			By myReceiveddocumentList = getDynamicElement(strDocumentPageTitle, "My Received Documents");
			waitAndVerifyElement(myReceiveddocumentList);
			setTimeOut(2000);
			LoggingInfo("User is navigated to My Received Documents");
			setTimeOut(2000);
			waitAndVerifyElement(createdDateColumn);
			String sortingState;

			do {
				sortingState = getText(createdDateSortState);
				if (!sortingState.contains("Sorted Descending")) {
					clickByJavascript(createdDateColumn);
					setTimeOut(1000);
				}
				sortingState = getText(createdDateSortState);
			} while (!sortingState.contains("Sorted Descending"));

			Log.info("Verify received document id");
			boolean docIdFound = false;
			for (int attempt = 0; attempt < 5; attempt++) {
				if (methodToAvoidStaleElementReferenceErrorElement(parentDocIDlist)) {
					waitAndVerifyElement(parentDocIDlist);
					setTimeOut(1000);
					List<WebElement> listOptions = getWebDriver().findElements(parentDocIDlist);

					for (WebElement element : listOptions) {
						String ids = element.getText();
						setTimeOut(1000);

						if (ids.equalsIgnoreCase(docID)) {

							JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
							js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element,
									highlightStyle);
							setTimeOut(1000);

							By documentStatus = getDynamicElement(docStatus, docID);
							highLightElement(documentStatus);
							setTimeOut(2000);
							verifyDetails(documentStatus, status, "Document status");
							LoggingInfo(status + "-Document status verified");

							By openDoc = getDynamicElement(openDocument, docID);
							waitAndVerifyElement(openDoc);
							clickByJavascript(openDoc);
							setTimeOut(2000);
							LoggingInfo("Clicked on open document");
							docIdFound = true;
							break;
						}
					}
				}

				if (!docIdFound) {
					By documentStatus = getDynamicElement(docStatus, docID);
					highLightElement(documentStatus);
					setTimeOut(2000);
					verifyDetails(documentStatus, status, "Document status");
					LoggingInfo(status + "-Document status verified");

					By openDoc = getDynamicElement(openDocument, docID);
					waitAndVerifyElement(openDoc);
					clickByJavascript(openDoc);
					setTimeOut(2000);
					LoggingInfo("Clicked on open document");
					docIdFound = true;
					break;
				}
				if(docIdFound) {
					break;
				}

				click(createdDateColumn);
				setTimeOut(2000);
			}

			if (!docIdFound) {
				Log.error("Document ID not found after 5 attempts: " + docID);
				Assert.fail("Failed to find document ID: " + docID);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify document record " + e.getMessage());
			Assert.fail("Failed to verify document record " + e.getMessage());
		}
	}

	/**
	 * Function : Verify and click on document record
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyAndClickDocumentRecord(String fileName) {
		try {
			Log.info("Verify and click on docuement record");
			waitForPageLoaded();
			By documentRecord = getDynamicElement(strReceivedDocumentTitle, fileName);
			waitAndVerifyElement(documentRecord);
			highLightElement(documentRecord);
			LoggingInfo(fileName + "-Docuement record verified");
			By enrollementFilerRecord = getDynamicElement(documentRecordLink, fileName);
			waitAndVerifyElement(enrollementFilerRecord);
			click(enrollementFilerRecord);
			LoggingInfo(enrollementFilerRecord + "-Clicked on the record");
			setTimeOut(5000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify document record " + e.getMessage());
			Assert.fail("Failed to verify document record " + e.getMessage());
		}
	}

	/**
	 * Function : Verify document details page
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyDocDetailsPage(String fileName, String ownerName) {
		try {
			Log.info("Verify details page");
			setTimeOut(7000);
			waitForPageLoaded();
			String windowTitle = getWindowTitle();
			Log.info("Verify user is navigated to details page");
			if (windowTitle.contains(fileName))
				Assert.assertTrue(true, "Navigated to details Page of the ‘Received Documents’.");
			else
				Assert.fail("Failed to naviage to details page");

			Log.info("Verify received document record");
			By parentRecordTitle = getDynamicElement(strDetailsPageDocTitle, fileName);
			waitAndVerifyElement(parentRecordTitle);
			verifyDetails(parentRecordTitle, fileName, "Document title");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify details of document page " + e.getMessage());
			Assert.fail("Failed to verify details of document page" + e.getMessage());
		}
	}

	/**
	 * Function: Click on pharmacy record
	 * 
	 * @author Anand P
	 **/

	public void clickOnPharmacyRecord(String patientName) {
		try {
			Log.info("Verify Pharamcy record");
			setTimeOut(3000);
			By pharmacyRecordName = getDynamicElement(pharmacyRecord, patientName);
			waitAndVerifyElement(pharmacyRecordName);
			scrollToElement(pharmacyRecordName);
			clickByJavascript(pharmacyRecordName);
			setTimeOut(3000);
			LoggingInfo("Clicked on Pharmacy record of :" + patientName);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Pharmacy record " + e.getMessage());
			Assert.fail("Failed to click on Pharmacy record " + e.getMessage());
		}
	}

	/**
	 * Function: Edit Effective To date of Pharmacy
	 * 
	 * @author Anand P
	 **/

	public void editPharmacyEffectiveToDate() {
		try {
			Log.info("Edit Effective To date Pharamcy record");
			waitForPageLoaded();
			scrollToElement(eleEditButton);
			waitAndVerifyElement(eleEditButton);
			clickByJavascript(eleEditButton);
			setTimeOut(3000);
			waitAndVerifyElement(eleInputDate);
			click(eleInputDate);
			String pastDate = getNthPastDayFromToday(1000);// format change
			// String inputDate=rearrangeDateFormatToMMddyyyy(pastDate);
			inputText(eleInputDate, pastDate);
			LoggingInfo("Edit done successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit date on Pharmacy record " + e.getMessage());
			Assert.fail("Failed to edit date on Pharmacy record " + e.getMessage());
		}

	}

	/*
	 * Function: Click on Medical record
	 * 
	 * @author Anand P
	 **/

	public void clickOnMedicalRecord(String patientName) {
		try {
			Log.info("Verify Pharamcy record");
			setTimeOut(3000);
			By medicalRecordName = getDynamicElement(medicalRecord, patientName);
			waitAndVerifyElement(medicalRecordName);
			scrollToElement(medicalRecordName);
			clickByJavascript(medicalRecordName);
			setTimeOut(3000);
			LoggingInfo("Clicked on Pharmacy record of :" + patientName);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Pharmacy record " + e.getMessage());
			Assert.fail("Failed to click on Pharmacy record " + e.getMessage());
		}
	}

	/**
	 * Function: Edit Effective To date of Medical
	 * 
	 * @author Anand P
	 **/

	public void editMedicalEffectiveToDate() {
		try {
			Log.info("Edit Effective To date Medical record");
			waitForPageLoaded();
			scrollToElement(eleEditButton);
			waitAndVerifyElement(eleEditButton);
			clickByJavascript(eleEditButton);
			setTimeOut(3000);
			waitAndVerifyElement(eleInputDate);
			click(eleInputDate);
			String futureDate = getNthDayFromTodayFormat(39);
			inputText(eleInputDate, futureDate);
			setTimeOut(3000);
			LoggingInfo("Edit done successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit date on Medical record " + e.getMessage());
			Assert.fail("Failed to edit date on Medical record " + e.getMessage());
		}

	}

	/**
	 * Function: Add insurance date
	 * 
	 * @author Anand P
	 **/

	public void inputInsuranceAddDate() {
		try {
			Log.info("Enter Insurance Add date Pharamcy record");
			setTimeOut(3000);
			scrollToElement(eleInputInsuranceAddDate);
			waitAndVerifyElement(eleInputInsuranceAddDate);
			click(eleInputInsuranceAddDate);
			String pastDate = getNthDayFromTodayFormat(20);
			inputText(eleInputInsuranceAddDate, pastDate);
			LoggingInfo("Edit done successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit Insurance date on Pharmacy record " + e.getMessage());
			Assert.fail("Failed to edit Insurance date on Pharmacy record " + e.getMessage());
		}

	}

	/**
	 * Function: Add policy holder DOB
	 * 
	 * @author Anand P
	 **/

	public void inputPolicyHolderDOB() {
		try {
			Log.info("Enter Insurance Add date Pharamcy record");
			setTimeOut(3000);
			scrollToElement(elePolicyHolderDOB);
			waitAndVerifyElement(elePolicyHolderDOB);
			String pastDate = getNthPastDayFromToday(900);
			inputText(elePolicyHolderDOB, pastDate);
			LoggingInfo("Edit done successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit policy holder DOB on Pharmacy record " + e.getMessage());
			Assert.fail("Failed to edit Policy Holder DOB Pharmacy record " + e.getMessage());
		}

	}

	/**
	 * Function: Add plan ID
	 * 
	 * @author Anand P
	 **/
	public void inputPlanID() {
		try {
			Log.info("Enter Insurance Add date Pharamcy record");
			setTimeOut(3000);
			scrollToElement(elePlanID);
			waitAndVerifyElement(elePlanID);
			inputText(elePlanID, "plan");
			LoggingInfo("Edit done successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit policy holder DOB on Pharmacy record " + e.getMessage());
			Assert.fail("Failed to edit Policy Holder DOB Pharmacy record " + e.getMessage());
		}

	}

	/**
	 * Function: Click on save button
	 * 
	 * @author Anand P
	 **/

	public void clickOnSave() {

		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleSaveBtn);
			scrollToElement(eleSaveBtn);
			click(eleSaveBtn);
			setTimeOut(2000);
			LoggingInfo("Clicked on save button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to save details" + e.getMessage());
			Assert.fail("Failed to save details" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function : Verify and OCR status of document
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyOCRStatus(String docOcrStatus) {
		try {
			Log.info("Verify OCR Status");
			scrollToTopOfPage();
			waitAndVerifyElement(strDocOCRStatus);
			scrollToElement(strDocOCRStatus);
			setTimeOut(7000);
			verifyOCRstatus(strDocOCRStatus, docOcrStatus);
			highLightElement(strDocOCRStatus);
			LoggingInfo("OCR status verified");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify OCR status" + e.getMessage());
			Assert.fail("Failed to verify OCR status" + e.getMessage());
		}
	}

	/**
	 * Function : Verify parent document details
	 * 
	 * @author Trupti Zure
	 **/

	public void verfiyParentDocDetailsPage(String tabname, String status) {
		try {
			Log.info("Verify status of document");
			setTimeOut(2000);
			By detailTab = getDynamicElement(detailsPageTabsButton, tabname);
			waitAndVerifyElement(detailTab);
			click(detailTab);
			setTimeOut(2000);

			waitAndVerifyElement(detailsPageStatus);
			String parentDocstatus = getText(detailsPageStatus);

			if (parentDocstatus.equals(status)) {
				Assert.assertTrue(true, "Status verified successfully");
				Log.info(status + "-Status verified successfully");
			} else {
				Assert.fail("Failed to verify status of document:" + "Actual status-" + parentDocstatus
						+ " Expected status-" + status);
				Log.info("Failed to verify status of document:" + "Actual status-" + parentDocstatus
						+ " Expected status-" + status);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify status" + e.getMessage());
			Assert.fail("Failed to verify status" + e.getMessage());
		}
	}

	// Anand P
	public void verifyPDFVersionOfEFVisible(String tabname) {
		try {
			Log.info("Verify Details tab of document");
			setTimeOut(2000);
			By detailTab = getDynamicElement(detailsPageTabsButton, "Details");
			scrollToElement(detailTab);
			waitAndVerifyElement(detailTab);
			clickByJavascript(detailTab);
			setTimeOut(2000);

			Log.info("Verify Document tab");
			setTimeOut(2000);
			By documentTab = getDynamicElement(detailsPageTabsButton, tabname);
			waitAndVerifyElement(documentTab);
			clickByJavascript(documentTab);
			scrollToHalfPage();
			setTimeOut(2000);
			Log.info("Verified PDF Document still visible");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify pdf EF" + e.getMessage());
			Assert.fail("Failed to verify pdf EF" + e.getMessage());
		}

	}

	/**
	 * Function : Classify the document
	 * 
	 * @author Trupti Zure
	 **/

	public void classifyDocument(String docType) {
		try {
			waitForPageLoaded();
			Log.info("Classify Parent document");
			setTimeOut(3000);
			waitAndVerifyElement(eleDocumentType);
			click(eleDocumentType);
			setTimeOut(2000);
			waitAndVerifyElement(eleDocumentTypeOptions);
			selectItemFromDropDown(eleDocumentType, eleDocumentTypeOptions, docType);
			LoggingInfo("Document Type classified as-" + docType);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Classify document" + e.getMessage());
			Assert.fail("Failed to Classify document" + e.getMessage());
		}

	}
	public void selectDocumentType(String docType) {
		try {
			waitForPageLoaded();
			Log.info("Select Document Type");
			setTimeOut(3000);
			waitAndVerifyElement(eleDocumentType);
			click(eleDocumentType);
			setTimeOut(2000);
			waitAndVerifyElement(eleDocumentTypeOptions);
			String option = "//*[@role=\"option\" and @data-value=\"{0}\"]";
			By eleOption = getDynamicElement(option, docType);
			scrollToElement(eleOption);
			click(eleOption);
			LoggingInfo("Document Type selected as-" + docType);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select document type" + e.getMessage());
			Assert.fail("Failed to select document type" + e.getMessage());
		}

	}

	/**
	 * Function : click on submit button
	 * 
	 * @author Trupti Zure
	 **/

	public void submitDocument() {
		try {
			Log.info("Clicked on submit document");
			waitAndVerifyElement(submitButton);
			scrollToElement(submitButton);
			click(submitButton);
			waitForPageLoaded();
		}

		catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to submit document" + e.getMessage());
			Assert.fail("Failed to submit document" + e.getMessage());
		}
	}

	/**
	 * Function : compare parent and child document ids
	 * 
	 * @author Trupti Zure
	 **/
	public void compareDocumentIDs(String parentDocID, String childDocID) {
		try {
			// Compare the child document ID with the parent document ID
			boolean isChildDocumentCreated = !childDocID.equals(parentDocID);
			if (isChildDocumentCreated) {
				Log.info("Child document with ID " + childDocID + " is created.");
			} else {
				Log.info("Child document with ID " + childDocID + " is not created.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to create new child document ID" + e.getMessage());
			Assert.fail("Failed to create new child document ID" + e.getMessage());
		}
	}

	/**
	 * Function : Verify child document details page
	 * 
	 * @author Trupti Zure
	 **/
	public void verfiyChildDocDetailsPage(String tabname, String docType, String Status, String fileName) {
		try {
			Log.info("Verify details of child document");
			setTimeOut(2000);
			By detailTab = getDynamicElement(detailsPageTabsButton, tabname);
			waitAndVerifyElement(detailTab);
			click(detailTab);

			By documentType = getDynamicElement(detailsPageFields, "Document Type");
			waitAndVerifyElement(documentType);
			verifyDetails(documentType, docType, "Document Type");

			By childDocStatus = getDynamicElement(detailsPageFields, "Status");
			waitAndVerifyElement(childDocStatus);
			verifyDetails(childDocStatus, Status, "Document Status");

			By parentDocument = getDynamicElement(detailsPageLinkFields, "Parent Received Document");
			waitAndVerifyElement(parentDocument);
			verifyDetails(parentDocument, fileName, "Parent Received Document");

			/*
			 * By careProgramProduct = getDynamicElement(detailsPageLinkFields,
			 * "Care Program Product"); waitAndVerifyElement(careProgramProduct);
			 * verifyDetails(careProgramProduct, careProgramProductType,
			 * "Care Program Product");
			 */

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify status" + e.getMessage());
			Assert.fail("Failed to verify status" + e.getMessage());
		}
	}

	/**
	 * Function : Navigate to parent record
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToparentRecord() {
		try {
			Log.info("Navigate to parent document");
			waitAndVerifyElement(parentsubRecord);
			click(parentsubRecord);
			LoggingInfo("Navigated to parent document record");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to parent record" + e.getMessage());
			Assert.fail("Failed to navigate to parent record" + e.getMessage());
		}
	}

	/**
	 * Function : Navigate to child document record with filename
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyChildRecord(String tabname, String filName) {
		try {
			Log.info("Verify child document recod");
			By relatedTab = getDynamicElement(detailsPageTabsButton, tabname);
			waitAndVerifyElement(relatedTab);
			click(relatedTab);

			waitAndVerifyElement(childRecord);
			verifyDetails(childRecord, filName, "ChildRecord");
			highLightElement(childRecord);
			LoggingInfo("New child record is created");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify child record" + e.getMessage());
			Assert.fail("Failed to verify child record" + e.getMessage());
		}

	}

	/**
	 * Function : Navigate to child document record
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToChildRecord() {
		try {
			Log.info("Navigate to child record");
			waitAndVerifyElement(childSubRecord);
			click(childSubRecord);
			setTimeOut(2000);
			LoggingInfo("Navigated to child document record");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to child record" + e.getMessage());
			Assert.fail("Failed to navigate to child record" + e.getMessage());
		}
	}

	/**
	 * Function : Logout from application
	 * 
	 * @author Samarth S
	 **/
	public void logout() {
		try {
			refresh();
			waitForPageLoaded();
			setTimeOut(5000);
			scrollToTopOfPage();
			clickByJavascript(eleProfileImg);
			setTimeOut(5000);
			scrollToElement(eleLogoutBtn);
			clickByJavascript(eleLogoutBtn);
			LoggingInfo("Clicks on Logout Button");
			setTimeOut(6000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Function : click on assign to me button
	 * 
	 * @author Samarth S
	 **/

	public void clickOnAssignToMe() {
		try {
			Log.info("Click on Assign to me Button");
			waitAndVerifyElement(assignToMeButton);
			clickByJavascript(assignToMeButton);
			setTimeOut(2000);
			LoggingInfo("Clicked on Assign to me button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on assign to me" + e.getMessage());
			Assert.fail("Failed to click on assign to me" + e.getMessage());
		}

	}

	/**
	 * Function : Verify my received document list view
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyMyReceivedDocumentsList() {
		try {
			Log.info("Recently View Documents List");
			waitForPageLoaded();
			By allReceiveddocumentList = getDynamicElement(strDocumentPageTitle, "My Received Documents");
			waitAndVerifyElement(allReceiveddocumentList);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to load Recently Viewed List" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function : Verify document list view
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyListView() {
		try {
			Log.info("Verify List View");
			click(listViewButton);
			setTimeOut(2000);
			ArrayList<String> docList = new ArrayList<>(Arrays.asList("All Received Documents", "My Received Documents",
					"Received Document Worklist", "Recently Viewed", "Recently Viewed Received Documents"));

			for (int i = 0; i < docList.size(); i++) {
				String doc = docList.get(i);
				By eleReceivedDocList = getDynamicElement(listViewOptions, docList.get(i));
				waitAndVerifyElement(eleReceivedDocList);
				Assert.assertTrue(true, "Document list view is present: " + doc);
			}
			LoggingInfo("List View verified successfully");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify List View" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function : Verify document status
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyDocumentsStatus() {
		try {

			Log.info("Navigate to My Received documents list");
			setTimeOut(2000);
			By eleMyReceivedDocList = getDynamicElement(listViewOptions, "My Received Documents");
			click(eleMyReceivedDocList);

			By myReceiveddocumentList = getDynamicElement(strDocumentPageTitle, "My Received Documents");
			waitAndVerifyElement(myReceiveddocumentList);
			setTimeOut(2000);
			Log.info("Verify received documents status");

			List<WebElement> docStatus = getWebDriver().findElements(documentsStatus);
			for (WebElement statusElement : docStatus) {
				String status = statusElement.getText();
				if ("In Review".equals(status) || "Processing".equals(status)) {
					Assert.assertTrue(true, "Document status is: " + status);
					Log.info("Document status is: " + status);
				} else {
					Assert.fail("Document status is not In Review or Processing. Status: " + status);
				}
			}
			LoggingInfo("Verified documents status successfully");

		}

		catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify status of document record " + e.getMessage());
			Assert.fail("Failed to verify status of document record " + e.getMessage());
		}
	}

	/**
	 * Function : Navigate to All Received Documents and click on assign to me
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToAllReceivedDoc() {
		try {
			Log.info("Navigate to All Received Documents and click on assign to me");
			click(listViewButton);
			click(allRecDocuments);
			waitForPageLoaded();
			LoggingInfo("Navigated to All Received Documents list");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to all received documents " + e.getMessage());
			Assert.fail("Failed to navigate to all received documents " + e.getMessage());
		}
	}

	/**
	 * Function : Navigate to All Received Documents and click on assign to me
	 * 
	 * @author Trupti Zure
	 **/
	public void navigateToAllReceivedDocPMUser() {
		try {
			Log.info("Navigate to All Received Documents and click on assign to me");
			click(listViewButton);

			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, "All Received Documents");
			setTimeOut(2000);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();

			waitForPageLoaded();

			LoggingInfo("Navigated to All Received Documents list");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to all received documents " + e.getMessage());
			Assert.fail("Failed to navigate to all received documents " + e.getMessage());
		}
	}

	/**
	 * Function : Verify document status
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyDocumentStatus(String docStatus) {
		try {
			waitAndVerifyElement(documentsStatus);
			String status = getText(documentsStatus);
			if (docStatus.equals(status)) {
				Assert.assertTrue(true, "Document status is: " + status);
				Log.info("Document status is: " + status);
			} else {
				Assert.fail("Document status draft. Status: " + status);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify document status " + e.getMessage());
			Assert.fail("Failed to verify document status" + e.getMessage());
		}
	}

	/**
	 * Function : Check error when user submits the document without classifying
	 * document
	 * 
	 * @author Trupti Zure
	 **/

	public void classifyDocumentError() {
		try {

			Log.info("Submit document without classifying document");
			waitAndVerifyElement(eleDocumentType);
			submitDocument();

			waitAndVerifyElement(eleError);
			verifyTextPresent(eleError, errorMsg);
			setTimeOut(2000);
			LoggingInfo("Successfully verified Error message when the field is not filled");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify error" + e.getMessage());
			Assert.fail("Failed to verify error" + e.getMessage());
		}
	}

	/**
	 * Function : Verify transform document error
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyTransformDocError() {
		try {

			waitAndVerifyElement(eleTransformDocument);
			click(eleTransformDocument);
			setTimeOut(1000);

			ArrayList<String> transformations = new ArrayList<>(
					Arrays.asList("Rotate Right", "Flip", "Rotate Left", "Range of pages"));

			for (int i = 0; i < transformations.size(); i++) {
				String transformation = transformations.get(i);
				By eleTransformDoc = getDynamicElement(transformDoc, transformation);
				waitAndVerifyElement(eleTransformDoc);
				inputText(eleTransformDoc, "89%ab+}");
				submitDocument();
				setTimeOut(2000);
				WebElement errorElement = getWebDriver().findElements(pageError).get(i);
				String errorMessage = errorElement.getText();
				verifyTextPresent(pageError, errorMessage);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify error" + e.getMessage());
			Assert.fail("Failed to verify error" + e.getMessage());
		}
	}

	/**
	 * Function : Clear inputs given in transformations input box
	 * 
	 * @author Trupti Zure
	 **/

	public void clearTextOnTransformDoc() {
		try {
			ArrayList<String> transformations = new ArrayList<>(
					Arrays.asList("Rotate Right", "Flip", "Rotate Left", "Range of pages"));
			for (int i = 0; i < transformations.size(); i++) {
				String transformation = transformations.get(i);
				By eleTransformDoc = getDynamicElement(transformDoc, transformation);
				waitAndVerifyElement(eleTransformDoc);
				getWebDriver().findElements(eleTransformDoc).clear();
				setTimeOut(2000);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to clear text" + e.getMessage());
			Assert.fail("Failed to clear text" + e.getMessage());
		}
	}

	/**
	 * Function : Click on add and deleted buttons
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnAddAndDeleteButton() {
		try {
			By addButton = getDynamicElement(eleButton, "Add");
			scrollToElement(addButton);
			waitAndVerifyElement(addButton);
			click(addButton);

			// verify document2 button
			By documet2Button = getDynamicElement(eleButton, "Document 2");
			waitAndVerifyElement(documet2Button);

			// verify delete button
			// By deleteButton = getDynamicElement(eleButton, "Delete");
			By deleteButton = getDynamicElement(eleButtonDelete, "Document 2", "Delete");
			waitAndVerifyElement(deleteButton);
			scrollToElement(deleteButton);
			highLightElement(deleteButton);
			setTimeOut(2000);
			LoggingInfo("Delete button is visible after adding a new document.");
			setTimeOut(2000);
			click(deleteButton);
			setTimeOut(5000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify add and delete button" + e.getMessage());
			Assert.fail("Failed to verify add and delete button" + e.getMessage());
		}

	}

	/**
	 * Function : Verify on received document work list view links are not present
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyTableLinksAreNotPresent() {
		try {
			setTimeOut(50000);
			// By eleMyReceivedDocList = getDynamicElement(listViewOptions, "Received
			// Document Worklist");
			// click(eleMyReceivedDocList);
			setTimeOut(2000);
			By recDocTable = getDynamicElement(eleTable, "Received Document Worklist");
			waitAndVerifyElement(recDocTable);

			WebElement table = getWebDriver().findElement(recDocTable);
			List<WebElement> rows = table.findElements(By.tagName("tr"));

			for (WebElement row : rows) {

				if (!row.findElements(By.tagName("td")).isEmpty()) {
					List<WebElement> columns = row.findElements(By.tagName("td"));
					// Excluding the last column for link verification
					for (int i = 0; i < columns.size() - 1; i++) {
						List<WebElement> links = columns.get(i).findElements(By.tagName("a"));
						if (!links.isEmpty()) {
							// If links are found, fail the test case
							Assert.fail("Table contains links.");
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify links" + e.getMessage());
			Assert.fail("Failed to verify links" + e.getMessage());
		}
	}

	/**
	 * Function : Navigate to All Received Documents
	 * 
	 * @author Trupti Zure
	 **/

	public void navigateToAllRecDocAndSearchRecord(String fileName) {
		try {
			Log.info("Navigate to All Received Documents");
			click(listViewButton);
			setTimeOut(2000);
			click(allRecDocuments);

			waitForPageLoaded();
			LoggingInfo("Navigated to All Received Documents list");

			click(searchDocInput);
			inputText(searchDocInput, fileName);
			genericKeyPress(searchDocInput, "Enter");
			waitForPageLoaded();

			By enrollementFilerRecord = getDynamicElement(documentRecordLink, fileName);
			waitAndVerifyElement(enrollementFilerRecord);
			verifyRecord(fileName);

			setTimeOut(3000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to search record" + e.getMessage());
			Assert.fail("Failed to search record" + e.getMessage());

		}

	}

	/**
	 * Function : Upload file
	 * 
	 * @author Trupti Zure
	 **/

	public void uploadFile(String filePath) {
		try {

			setTimeOut(4000);
			// Create Robot instance
			Robot robot = new Robot();

			robot.setAutoDelay(500);

			StringSelection selection = new StringSelection(filePath);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);

			robot.keyPress(KeyEvent.VK_CONTROL); // Press Ctrl
			robot.keyPress(KeyEvent.VK_V); // Press V
			robot.keyRelease(KeyEvent.VK_V); // Release V
			robot.keyRelease(KeyEvent.VK_CONTROL); // Release Ctrl
			robot.delay(1000); // Adding delay after pasting

			robot.keyPress(KeyEvent.VK_ENTER); // Press Enter
			robot.keyRelease(KeyEvent.VK_ENTER); // Release Enter
			robot.delay(2000);

			robot.delay(2000);

		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Failed to upload file: " + e.getMessage(), e);
		}
	}

	public void checkRecivedDocListView() {
		try {
			Log.info("Verify List View");
			click(listViewButton);
			setTimeOut(4000);
			ArrayList<String> docList = new ArrayList<>(Arrays.asList("All Received Documents", "My Received Documents",
					"Received Document Worklist", "Recently Viewed", "Recently Viewed Received Documents"));

			for (int i = 0; i < docList.size(); i++) {
				String doc = docList.get(i);
				By eleReceivedDocList = getDynamicElement(listViewOptions, docList.get(i));
				waitAndVerifyElement(eleReceivedDocList);
				Assert.assertTrue(true, "Document list view is present: " + doc);
			}
			LoggingInfo("List View verified successfully");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify List View" + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function : Search record
	 * 
	 * @author Trupti Zure
	 **/
	public void searchRecord(String cpeName) {
		try {
			click(searchDocInput);
			inputText(searchDocInput, cpeName);
			genericKeyPress(searchDocInput, "Enter");
			waitForPageLoaded();
			LoggingInfo("Record searched successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to search record" + e.getMessage());
			Assert.fail("Failed to search record" + e.getMessage());

		}
	}

	/**
	 * Function : Click on cpe record
	 * 
	 * @author Kavyashree
	 **/

	public void clickOnRecord(String cpeName) {
		try {
			By record = getDynamicElement(strRecordName, cpeName);
			waitAndVerifyElement(record);
			clickByJavascript(record);
			setTimeOut(5000);
			LoggingInfo("clicked on record successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on record" + e.getMessage());
			Assert.fail("Failed to click on recordr" + e.getMessage());

		}
	}

	/**
	 * Function : Verify prescriber name
	 * 
	 * @author Kavyashree
	 **/
	public void verifyPrescriberName(String prescriberName) {
		try {
			By elePreName = getDynamicElement(strAccount, prescriberName);
			waitAndVerifyElement(elePreName);
			scrollToElement(elePreName);
			String preName = getText(elePreName);
			if (preName.contains("Dr.")) {
				setTimeOut(2000);
				LoggingInfo("Prescriber Name verified successfully");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify prescriber name" + e.getMessage());
			Assert.fail("Failed to verify prescriber name" + e.getMessage());

		}
	}

	/**
	 * Function : Upload enrollment document
	 * 
	 * @author Samarth S
	 **/
	public void uploadEnrollmentDocument(String file) {
		try {
			Log.info("Upload enrollment Document");
			waitAndVerifyElement(uploadDoc);
			click(uploadDoc);
			setTimeOut(5000);
			uploadFile(file);
			waitForvisiblityOfElementLocated(doneButton);
			waitForPresenceOfElementLocated(doneButton);
			setTimeOut(6000);
			click(doneButton);
			LoggingInfo("Successfully uploaded document");
			Assert.assertTrue(true, "Successfully uploaded document ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to upload document " + e.getMessage());
			Assert.fail("Failed to upload document" + e.getMessage());
		}
	}

	/**
	 * Function : Navigate to details tab and validate Status
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyChildDocStatus(String tabname, String Status) {
		try {
			Log.info("Verify Status is in Needs Review on Details Tab");
			setTimeOut(2000);
			By detailTab = getDynamicElement(detailsPageTabsButton, tabname);
			waitAndVerifyElement(detailTab);
			click(detailTab);

			By childDocStatus = getDynamicElement(detailsPageFields, "Status");
			waitAndVerifyElement(childDocStatus);
			verifyDetails(childDocStatus, Status, "Document Status");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify status" + e.getMessage());
			Assert.fail("Failed to verify status" + e.getMessage());
		}
	}

	/**
	 * Function : Navigate to PQSA worklist view
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void navigateToPQSAWorklist() {

		try {
			Log.info("Navigate to received document worklist");
			click(listViewButton);

			By eleMyReceivedDocList = getDynamicElement(listViewOptions, "PSQA Review Worklist");
			click(eleMyReceivedDocList);

			waitForPageLoaded();
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to Received Document " + e.getMessage());
			Assert.fail("Failed to navigate to Received Document " + e.getMessage());
		}
	}

	public String verifyDOCInPSQAReviewList(String fileName) {
		String parentDocID = null;
		int maxRetries = 4;
		int retryCount = 0;

		try {
			By enrollementFileRecord = By.xpath("//tr[1]/th[@scope='row']/span/a");
			boolean docFound = false;

			LoggingInfo("Verify User is able to see invalid document being added on PQSA Review Worklist");
			while (retryCount < maxRetries && !docFound) {
				try {
					setTimeOut(2000);
					click(searchDocInput);
					inputText(searchDocInput, fileName);
					setTimeOut(1000);
					genericKeyPress(searchDocInput, "Enter");
					waitForPageLoaded();
					setTimeOut(2000);
					click(nameSort);
					setTimeOut(1000);
					docFound = isElementDisplayed(enrollementFileRecord);
					String recordName = getText(enrollementFileRecord);
					if (docFound && recordName.contains(fileName)) {
						highLightElement(enrollementFileRecord);
						LoggingInfo("User is able to see invalid document being added on the PQSA list view");
					}
				} catch (StaleElementReferenceException e) {
					retryCount++;
					if (retryCount < maxRetries) {
						click(nameSort);
						setTimeOut(2000);
					} else {
						throw e;
					}
				}
			}

			if (!docFound) {
				throw new NoSuchElementException(
						"Enrollement  Record not found in PQSA Review Worklist after retries.");
			}

			setTimeOut(3000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Enrollement record in PQSA Review Worklist" + e.getMessage());
			Assert.fail("Failed to validate Enrollement record in PQSA Review Worklist" + e.getMessage());
		}

		return parentDocID;
	}

	public void uploadDocument(String file) {
		try {
			Log.info("Upload enrollment Document");
			uploadFile(file);
			waitForPresenceOfElementLocated(doneButton);
			setTimeOut(6000);
			click(doneButton);
			LoggingInfo("Successfully uploaded document");
			Assert.assertTrue(true, "Successfully uploaded document ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to upload document " + e.getMessage());
			Assert.fail("Failed to upload document" + e.getMessage());
		}
	}

	public void navigatetoPSQAReviewWorklistView() {
		try {
			click(listViewButton);
			waitForPageLoaded();
			By PSQAReviewList = getDynamicElement(strDocumentListTitle, "PSQA Review Worklist");
			waitAndVerifyElement(PSQAReviewList);
			clickByJavascript(PSQAReviewList);
			setTimeOut(2000);
			LoggingInfo("Navigated to PSQA Review Worklist");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to PSQA Review Worklist" + e.getMessage());
			Assert.fail("Failed to navigate to PSQA Review Worklist" + e.getMessage());
		}
	}

	public void searchAccount(String recordName) {
		try {
			click(searchDocInput);
			inputText(searchDocInput, recordName);
			genericKeyPress(searchDocInput, "Enter");

			By accountName = By.xpath("//a[@title=\"" + recordName + "\"]");
			boolean isAccountNameFound = isElementPresent(accountName);

			int attempts = 0;
			int maxAttempts = 5;

			while (!isAccountNameFound && attempts < maxAttempts) {
				try {
					click(listSort);
					setTimeOut(2000);
					isAccountNameFound = isElementPresent(accountName);
				} catch (StaleElementReferenceException e) {

					Log.warn("StaleElementReferenceException caught: " + e.getMessage());
				}
				attempts++;
			}

			if (!isAccountNameFound) {
				Log.warn("Account name not found after " + maxAttempts + " attempts.");
			}

			waitForPageLoaded();
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to search document: " + e.getMessage());
			Assert.fail("Failed to search document: " + e.getMessage());
		}
	}

	/**
	 * Function: Download PDF from the Realated Section of CPE page
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void downloadPDFfileFromRelatedCPESection(String file) {
		try {
			Log.info("Download PDF from Related Section CPE Page");
			By btnDownload = By.xpath("//button/span[text()='Download']");
			waitAndVerifyElement(btnDownload);
			click(btnDownload);
			waitForPageLoaded();
			setTimeOut(10000);

			Robot robot = new Robot();
			robot.setAutoDelay(300);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_S);
			robot.keyRelease(KeyEvent.VK_S);
			robot.keyRelease(KeyEvent.VK_CONTROL);

			setTimeOut(5000);
			String DEST = System.getProperty("user.dir") + File.separator + "TestData" + File.separator + "PDFDownloads"
					+ File.separator + file.trim();
			// String DEST = System.getProperty("user.dir") + File.separator + "downloads" +
			// File.separator + file.trim();
			uploadPDFFile(DEST);
			setTimeOut(10000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to download document " + e.getMessage());
			Assert.fail("Failed to download document" + e.getMessage());
		}

	}

	/**
	 * Function: Get child document id
	 * 
	 * @author Trupti Zure
	 **/
	public String getChildDocumentID() {
		String childDocumentID = null;
		try {
			By childDocID = getDynamicElement(childDoc, "Document #");
			waitAndVerifyElement(childDocID);
			scrollToElement(childDocID);
			childDocumentID = getText(childDocID);
			LoggingInfo("Child document id" + childDocID);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get child document id " + e.getMessage());
			Assert.fail("Failed to get child document id " + e.getMessage());
		}
		return childDocumentID;
	}

	/**
	 * Function: Navigate to my received document
	 * 
	 * @author Trupti Zure
	 **/

	public void navigateToMyReceivedDocument() {

		try {
			setTimeOut(5000);
			Log.info("Navigate to my received document");
			click(listViewButton);

			waitForPageLoaded();
			By myReceivedDocumentList = getDynamicElement(listViewOptions, "My Received Documents");
			waitAndVerifyElement(myReceivedDocumentList);
			clickByJavascript(myReceivedDocumentList);
			setTimeOut(2000);
			LoggingInfo("Navigated to My Received Documents Worklist");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to My Received Documents " + e.getMessage());
			Assert.fail("Failed to navigate to My Received Documents " + e.getMessage());
		}

	}

	/**
	 * Function: Open Child Doc
	 * 
	 * @author Trupti Zure
	 **/

	public void openChildDoc() {

		try {
			Log.info("Navigate to recently View ");

			By eleRecord = By.xpath("//th[@scope=\"row\"]//a");

			clickByJavascript(eleRecord);

			accountObject.clickOnTab(tabsName.get(0));

			setTimeOut(2000);
			LoggingInfo("Details tab");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to My Received Documents " + e.getMessage());
			Assert.fail("Failed to navigate to My Received Documents " + e.getMessage());
		}

	}

	/**
	 * Function: Upload pdf file
	 * 
	 * @author Trupti Zure
	 **/
	public void uploadPDFFile(String filePath) {
		try {

			setTimeOut(2000);
			Robot robot = new Robot();
			robot.setAutoDelay(300);

			StringSelection sel = new StringSelection(filePath);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(sel, null);

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			setTimeOut(2000);

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Failed to upload file: " + e.getMessage(), e);
		}
	}

	/**
	 * Function: Open document from all received document list
	 *
	 * @author Trupti
	 */

	public void openDocumentFromAllRecivedDocList(String docID) {
		try {

			waitForPageLoaded();
			setTimeOut(8000);

			sortColumnDescending(createdDateSortState, createdDateColumn);

			sortColumnDescending(docSortState, documentColumn);

			boolean docIdFound = false;

			for (int attempt = 0; attempt < 5 && !docIdFound; attempt++) {
				setTimeOut(1000);

				List<WebElement> docElements = getWebDriver().findElements(parentDocIDlist);

				for (WebElement docElement : docElements) {
					String currentId = docElement.getText().trim();
					System.out.println(currentId);

					if (currentId.equalsIgnoreCase(docID)) {

						highlightElement(docElement);

						By receivedDoc = getDynamicElement(recordLink, docID);
						waitAndVerifyElement(receivedDoc);
						clickByJavascript(receivedDoc);
						setTimeOut(2000);

						LoggingInfo("Clicked on received document with ID: " + docID);
						docIdFound = true;
						break;
					}
				}

				if (!docIdFound) {
					click(docSort);
					By receivedDoc = getDynamicElement(recordLink, docID);
					waitAndVerifyElement(receivedDoc);
					clickByJavascript(receivedDoc);
					setTimeOut(2000);
				}
			}

			if (!docIdFound) {
				click(docSort);
				By receivedDoc = getDynamicElement(recordLink, docID);
				waitAndVerifyElement(receivedDoc);
				clickByJavascript(receivedDoc);
			//	Log.error("Document ID not found after 3=5 attempts: " + docID);
			//	Assert.fail("Failed to find document ID: " + docID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify document record: " + e.getMessage());
			Assert.fail("Failed to verify document record: " + e.getMessage());
		}
	}

	// --- Reusable helpers ---

	private void sortColumnDescending(By sortStateLocator, By columnHeaderLocator) {
		String sortingState;
		do {
			sortingState = getText(sortStateLocator);
			if (sortingState != null && !sortingState.contains("Sorted Descending")) {
				clickByJavascript(columnHeaderLocator);
				setTimeOut(1000);
			}
		} while (sortingState != null && !sortingState.contains("Sorted Descending"));
	}

	private void highlightElement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
		js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, highlightStyle);
		setTimeOut(500);
	}

	// Anand P

	public void changeOwner() {
		try {
			LoggingInfo("Click on Change Owner");
			setTimeOut(4000);
			refresh();
			scrollToElement(eleChangeOwner);
			clickByJavascript(eleChangeOwner);
			waitForPageLoaded();
			LoggingInfo("Successfully clicked on change Owner");

			click(searchUserInput);
			inputText(searchUserInput, PSRUserName);
			setTimeOut(5000);
			Actions actMemberPlan = new Actions(getWebDriver());
			actMemberPlan.sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
			// genericKeyPress(searchUserInput, "Enter");
			setTimeOut(3000);
			waitForPageLoaded();
			
			if (isElementDisplayed(userResultTitle)) {
				waitForelementToBeClickable(userRecordName);
				click(userRecordName);
			}

			waitAndVerifyElement(changeOwnerBtn);
			clickByJavascript(changeOwnerBtn);

			waitAndVerifyElement(docOwnerName);
			// WebElement ele=getWebDriver().findElement(By.xpath(docOwnerName));
			// String text=ele.getText();
			// Assert.assertEquals(text, DISUser);

			setTimeOut(2000);
			LoggingInfo("Successfully Changed Owner");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to change Owner " + e.getMessage());
			Assert.fail("Failed to change Owner" + e.getMessage());
		}
	}

	// Anand P
	public void navigateToMyReceivedDocListView() {

		try {
			Log.info("Navigate to My Received Documents");
			click(listViewButton);

			By eleSearch = By.xpath("//*[@type='text' and @placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, "My Received Documents");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to Received Document " + e.getMessage());
			Assert.fail("Failed to navigate to Received Document " + e.getMessage());
		}

	}

	// Sonica
	public void navigateToAllReceivedDocListView() {

		try {
			Log.info("Navigate to received document worklist");
//			click(listViewButton);
//			By eleMyReceivedDocList = getDynamicElement(listViewOptions, "All Received Documents");
//			click(eleMyReceivedDocList);
			setTimeOut(2000);

			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(4000);
			LoggingInfo("Navigated to All Received Documents");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to Received Document " + e.getMessage());
			Assert.fail("Failed to navigate to Received Document " + e.getMessage());
		}

	}

	// Anand P
	public void navigateToPartyRelationListView() {

		try {
			Log.info("Navigate to received document worklist");
			click(listViewButtonPartyRelation);
			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, "All Party Role Relationships");
			setTimeOut(2000);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to Received Document " + e.getMessage());
			Assert.fail("Failed to navigate to Received Document " + e.getMessage());
		}

	}

	// Anand P
	public void verifyRelationshipCCR(String relation) {

		try {

			String dynamicValue = relation;
			String xpathExpression = String.format("//th//span//a[text()=concat('Patient-', '%s', '-CCR')]",
					dynamicValue);

			WebElement element = getWebDriver().findElement(By.xpath(xpathExpression));

			String ele = element.getText();
			System.out.println(ele);
			LoggingInfo("Successfully validated CCR relation as " + relation);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to Received Document " + e.getMessage());
			Assert.fail("Failed to navigate to Received Document " + e.getMessage());
		}

	}

	// Anand P
	public void navigateToAllFacilitiesListView() {

		try {
			Log.info("Navigate All Facilities list view");
//			click(listViewButtonAcc);
//			By eleMyReceivedDocList = getDynamicElement(listViewOptions, "All Facilities");
//			click(eleMyReceivedDocList);
			setTimeOut(2000);

			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(8000);
			LoggingInfo("Navigated to All Facilities");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigated to All Facilities " + e.getMessage());
			Assert.fail("Failed to navigated to All Facilities " + e.getMessage());
		}
	}

	public void navigateToAllHCPListView() {

		try {

			Log.info("Navigate All Facilities list view");
			click(listViewButtonAcc);
			setTimeOut(2000);
			By eleMyReceivedDocList = getDynamicElement(listViewOptions, "All HCPs");
			click(eleMyReceivedDocList);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to HCP list view " + e.getMessage());
			Assert.fail("Failed to navigate to HCP list view " + e.getMessage());
		}

	}

	/**
	 * Function: Navigate to all HCPs
	 * 
	 * @author Sonica P
	 **/
	public void navigateToAllHCP() {
		try {
//		Log.info("Navigate to All HCPs");
//		click(listViewButton);
//
//		By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
//		waitAndVerifyElement(eleSearch);
//		clickByJavascript(eleSearch);
//		inputText(eleSearch, "All HCPs");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(8000);
			// refresh();
			LoggingInfo("Navigated to All HCPs");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigated to All HCPs " + e.getMessage());
			Assert.fail("Failed to navigated to All HCPs " + e.getMessage());
		}

	}

	// Shanavaz NIshani
	public void navigateToAllcorrspondnce() {
		try {
			Log.info("Navigate to All Received Documents and click on assign to me");
			click(eleListView);
//			click(eleAllcorrspndnce);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(4000);
			waitForPageLoaded();
			LoggingInfo("Navigated to All Correspondences");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to all Correspondences " + e.getMessage());
			Assert.fail("Failed to navigate to all Correspondences " + e.getMessage());
		}
	}

	/**
	 * Function:Get parent document id
	 * 
	 * @author Shanavaz Nishani
	 **/
	public String getParentDocumentIDOfLatestDoc(String fileName) {
		String parentDocID = null;
		int maxRetries = 4;
		int retryCount = 0;

		try {
			setTimeOut(2000);

			By enrollementFileRecord = By.xpath("(//th//*[contains(@class,\"slds-truncate uiOutputText\")])[1]");
			waitAndVerifyElement(enrollementFileRecord);
			boolean docFound = false;

			while (retryCount < maxRetries && !docFound) {
				try {
					click(searchDocInput);// change
					inputText(searchDocInput, fileName);// change
					genericKeyPress(searchDocInput, "Enter");// change
					setTimeOut(7000);
					waitForPageLoaded();// change
					WebElement parentDocumentElement = getWebDriver().findElement(enrollementFileRecord);
					Thread.sleep(4000);
					LoggingInfo("Get document ID of parent document");

					parentDocID = parentDocumentElement.getText().trim();
					Log.info("Salesforce ID of parent document: " + parentDocID);
					docFound = true;

				} catch (StaleElementReferenceException e) {
					retryCount++;
					if (retryCount < maxRetries) {
						clearInputText(searchDocInput);// change
						genericKeyPress(searchDocInput, "Enter");// change
						waitForPageLoaded();// change
						clickByJavascript(docSort);
						setTimeOut(2000);
					} else {
						throw e;
					}
				}
			}

			if (!docFound) {
				throw new NoSuchElementException("Enrollement File Record not found after retries.");
			}

			setTimeOut(3000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get document record ID: " + e.getMessage());
			Assert.fail("Failed to get document record ID: " + e.getMessage());
		}

		return parentDocID;
	}

	public void clickOnDetailsTabChildRecord(String tabname) {
		try {
			Log.info("Verify details of child document");
			setTimeOut(2000);
			By detailTab = getDynamicElement(detailsPageTabsButton, tabname);
			waitAndVerifyElement(detailTab);
			click(detailTab);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Tab " + e.getMessage());
			Assert.fail("Failed to click on Tab " + e.getMessage());
		}
	}

	// Trupti
	public void verifyFieldsAreNotVisible() {
		try {

			// Case Manger
			By caseManger = By.xpath("//span[text()=\"Case Manager\" and contains(@class,\"test-id\")]");
			Assert.assertFalse(isElementDisplayed(caseManger), "Case manager field is displayed on UI");

			// Reviewed by CM
			By reviewdByCM = By.xpath("//span[text()=\"Reviewed by CM\"]");
			Assert.assertFalse(isElementDisplayed(reviewdByCM), "Reviewed by CM field is displayed on UI");

			LoggingInfo(
					"Newly added fields not visible on the Details page of Received Document: Case Manager Reviewed by CM");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get document record ID: " + e.getMessage());
			Assert.fail("Failed to get document record ID: " + e.getMessage());
		}

	}

	// Trupti
	public void verifyFieldsAreVisible() {
		try {

			// Case Manger
			By caseManger = By.xpath("//*[contains(@class,\"active lafPageHost\")]//span[text()=\"Case Manager\"]");
			Assert.assertTrue(isElementDisplayed(caseManger), "Case manager field is displayed on UI");

			// Care Program Enrollee
			By cpe = By.xpath("//*[contains(@class,\"active lafPageHost\")]//span[text()=\"Care Program Enrollee\"]");
			Assert.assertTrue(isElementDisplayed(cpe), "Case manager field is displayed on UI");

			// Reviewed by CM
			By reviewdByCM = By.xpath("//*[contains(@class,\"active lafPageHost\")]//span[text()=\"Reviewed by CM\"]");
			Assert.assertTrue(isElementDisplayed(reviewdByCM), "Reviewed by CM field is displayed on UI");

			LoggingInfo(
					"Newly added fields are visible on the Details page of Received Document: Case Manager Reviewed by CM,Care Program Enrollee");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get document record ID: " + e.getMessage());
			Assert.fail("Failed to get document record ID: " + e.getMessage());
		}

	}

	// Trupti
	public void verifyFieldsValue(String CMname, String cpeName) {
		try {
			// Care Program Enrollee
			By cpe = getDynamicElement(detailsPageLinkFields2, "Care Program Enrollee");
			waitAndVerifyElement(cpe);
			scrollToElement(cpe);
			String cpetext = getText(cpe);
			Assert.assertEquals(cpetext, cpeName);
			LoggingInfo("Care Program Enrollee field verified");

			// Case Manager
			By cm = getDynamicElement(detailsPageLinkFields2, "Case Manager");
			waitAndVerifyElement(cm);
			scrollToElement(cm);
			String cmext = getText(cm);
			Assert.assertEquals(cmext, CMname);
			LoggingInfo("Case manager field verified");

			// Reviewed by CM
			WebElement element = getWebDriver().findElement(By.xpath(
					"//*[contains(@class,'active lafPageHost')]//*[text()='Reviewed by CM']//ancestor::dt//following-sibling::dd//child::lightning-formatted-text"));
			JavascriptExecutor jsExecutor = (JavascriptExecutor) getWebDriver();
			String innerText = (String) jsExecutor.executeScript("return arguments[0].innerText;", element);

			assert innerText.isEmpty() : "Expected text to be empty, but found: " + innerText;
			LoggingInfo("Reviewed by CM field is empty");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify values " + e.getMessage());
			Assert.fail("Failed to verify values " + e.getMessage());
		}

	}

	/**
	 * Function : Entering values in transform document(Rotate and Split)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void enterTransformDocValues() {
		try {
			waitAndVerifyElement(eleTransformDocument);
			click(eleTransformDocument);
			setTimeOut(1000);
			ArrayList<String> transformations = new ArrayList<>(
					Arrays.asList("Rotate Right", "Flip", "Rotate Left", "Range of pages"));

			By eleRotateRight = getDynamicElement(transformDoc, transformations.get(0));
			inputText(eleRotateRight, "1-2");

			By eleFlip = getDynamicElement(transformDoc, transformations.get(1));
			inputText(eleFlip, "2-3");

			By eleRotateLeft = getDynamicElement(transformDoc, transformations.get(2));
			inputText(eleRotateLeft, "3-4");

			By eleRangeofPgs = getDynamicElement(transformDoc, transformations.get(3));
			inputText(eleRangeofPgs, "1-4");

			LoggingInfo("Transform Doc(Rotate and Split) Values entered successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Enter Transform Doc Values" + e.getMessage());
			Assert.fail("Failed to Enter Transform Doc Values" + e.getMessage());
		}

	}

	/**
	 * Function : Validating if record is present or not in the list
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateRecordIsPresent(String recordName) {
		try {
			List<WebElement> elements = getWebDriver().findElements(By.xpath("//table//tbody//tr"));
			if (elements.size() > 0) {
				By record = getDynamicElement(strRecordName, recordName);
				waitAndVerifyElement(record);
				LoggingInfo("Record is present in the list");
			} else {
				LoggingInfo("Record is not present in the list");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate record" + e.getMessage());
			Assert.fail("Failed to validate record" + e.getMessage());
		}
	}

	/**
	 * Function : Validate CPE and Rec Doc Fields(If the EF is linked to exisitng
	 * patient)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateCPEandRecDocFields() throws Exception {
		try {

			By eleCPEField = getDynamicElement(strfields, "Care Program Enrollee");
			waitAndVerifyElement(eleCPEField);
			scrollToElement(eleCPEField);
			highLightElement(eleCPEField);
			String cpeText = getText(eleCPEField);
			System.out.println(cpeText);
			Assert.assertTrue(cpeText.isBlank(), "Enrollment Form is not Linked to the Care Program Enrollee");
			LoggingInfo("Enrollment Form is not Linked to the Care Program Enrollee");

			By eleRecDocField = getDynamicElement(strfields, "Parent Received Document");
			waitAndVerifyElement(eleRecDocField);
			scrollToElement(eleRecDocField);
			highLightElement(eleRecDocField);
			String recDocText = getText(eleRecDocField);
			System.out.println(recDocText);
			Assert.assertTrue(recDocText.isBlank(), "Enrollment Form is not Linked to the Patient");
			LoggingInfo("Enrollment Form is not Linked to the Patient");
			LoggingInfo("Care Program Enrollee and Parent Received Document fields are empty");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Validate Fields " + e.getMessage());
			Assert.fail("Failed to Vaidate Fields " + e.getMessage());
		}

	}

	/**
	 * Function : Change owner of the document from Show Actions Dropdown present in
	 * List view
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void changeOwnerByDropdown(String docID) {

		try {
			By eleShowActionsDropdown = getDynamicElement(stractionsBtn, docID);
			click(eleShowActionsDropdown);

			click(actionsDropdwon);
			setTimeOut(5000);
			click(searchUserInput);
			inputText(searchUserInput, DISUser);
			setTimeOut(7000);
			Actions actMemberPlan = new Actions(getWebDriver());
			actMemberPlan.sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
			setTimeOut(5000);
			waitForPageLoaded();

			waitAndVerifyElement(sbmitBtn);
			clickByJavascript(sbmitBtn);
			setTimeOut(5000);

			LoggingInfo("Successfully Changed Owner");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Change Owner of the Document" + e.getMessage());
			Assert.fail("Failed to Change Owner of the Document" + e.getMessage());
		}

	}

	/**
	 * Function: Enter new HCP name
	 * 
	 * @author Anand Pawar
	 **/
	public void enterHCPName(String hcp) {
		try {
			waitForPageLoaded();
			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Related Contact");
			scrollToElement(elepatientFNameInput);
			waitAndVerifyElement(elepatientFNameInput);
			click(elepatientFNameInput);
			inputText(elepatientFNameInput, hcp);

			By eleShow = By.xpath("//*[contains(text(), 'Show more results for')]");
			waitAndVerifyElement(eleShow);
			clickByJavascript(eleShow);

			setTimeOut(2000);

			setTimeOut(2000);
			By button = By.xpath("//span[@class='slds-radio_faux']");
			click(button);
			setTimeOut(2000);

			By selectButton = By.xpath("//button[text()=\"Select\"]");
			click(selectButton);
			setTimeOut(2000);

//			String hcpRecord="(//*[contains(@class,\"active lafPageHost\")]//lightning-base-combobox-formatted-text[@title=\"{0}\"])[1]";
//			By eleHCPRecord=getDynamicElement(hcpRecord, hcp);
//			waitAndVerifyElement(eleHCPRecord);
//			scrollToElement(eleHCPRecord);
//			clickByJavascript(eleHCPRecord);
			LoggingInfo("Entered new HCP");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter" + e.getMessage());
			Assert.fail("Failed to enter" + e.getMessage());
		}

	}

	/**
	 * Function: Enter new Site name
	 * 
	 * @author Anand Pawar
	 **/
	public void enterSiteName() {
		try {
			waitForPageLoaded();
			By elepatientFNameInput = getDynamicElement(strTextBoxesInput, "Site");
			scrollToElement(elepatientFNameInput);
			waitAndVerifyElement(elepatientFNameInput);
			click(elepatientFNameInput);
			inputText(elepatientFNameInput, "Mount Sinai Medical Center");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			By button = By.xpath("(//span[@class='slds-radio_faux'])[2]");
			click(button);
			setTimeOut(2000);

			By selectButton = By.xpath("//button[text()=\"Select\"]");
			click(selectButton);
			LoggingInfo("Entered new HCP");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter" + e.getMessage());
			Assert.fail("Failed to enter" + e.getMessage());
		}

	}

	public void selectHCPFromDropDown() {
		try {

			By relationshipList = getDynamicElement(editFieldList, "Relationship");
			waitAndVerifyElement(relationshipList);
			clickByJavascript(relationshipList);

			By relationshipListDropDownOptions = getDynamicElement(editFieldListOptions, "Relationship");
			waitAndVerifyElement(relationshipListDropDownOptions);

			String status = "HCP-Prescribing";
			selectItemFromList(relationshipList, relationshipListDropDownOptions, status, "Status");
			LoggingInfo("Selected relation as- " + status);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select" + e.getMessage());
			Assert.fail("Failed to select  " + e.getMessage());
		}

	}

	/**
	 * Function: Click on active edit button
	 *
	 * @author anand pawar
	 */
	public void clickOnEditActive() {
		try {
			By relationEdit = getDynamicElement(editButton, "Edit Active");
			waitAndVerifyElement(relationEdit);
			scrollToElement(relationEdit);
			setTimeOut(2000);
			click(relationEdit);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on relationship edit button " + e.getMessage());
			Assert.fail("Failed Click on relationship edit button" + e.getMessage());
		}
	}

	/**
	 * Function: Click on active check button
	 *
	 * @author anand pawar
	 */
	public void clickActiveCheckBox() {
		try {

			setTimeOut(5000);
			By eleCheckBox = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//span[text()=\"Active\"]//parent::label//following-sibling::div//child::span[@class=\"slds-checkbox_faux\"]");
			waitAndVerifyElement(eleCheckBox);
			scrollToElement(eleCheckBox);
			setTimeOut(2000);
			waitForelementToBeClickable(eleCheckBox);
			clickByJavascript(eleCheckBox);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on checkbox" + e.getMessage());
			Assert.fail("Failed Click on checkbox" + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to CCR tab
	 *
	 * @author anand pawar
	 */
	public void navigateToCCRTab() {
		try {
			By eleCheckBox = By.xpath("//span[text()='Contact Contact Relationships']");
			waitAndVerifyElement(eleCheckBox);
			scrollToElement(eleCheckBox);
			setTimeOut(2000);
			clickByJavascript(eleCheckBox);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate" + e.getMessage());
			Assert.fail("Failed navigate" + e.getMessage());
		}
	}

	/**
	 * Function: Click on site edit button
	 *
	 * @author anand pawar
	 */
	public void clickOnEditSiteButton() {
		try {
			By relationEdit = getDynamicElement(editButton, "Edit Site");
			waitAndVerifyElement(relationEdit);
			scrollToElement(relationEdit);
			setTimeOut(2000);
			click(relationEdit);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Click on relationship edit button " + e.getMessage());
			Assert.fail("Failed Click on relationship edit button" + e.getMessage());
		}
	}

	/**
	 * Function : Select first record from the list view(Randomly selected)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public String selectFirstRecordFromList() {
		String fileName = null;
		try {

			waitAndVerifyElement(eleLatestDoc);
			fileName = getText(eleLatestDoc);
			highLightElement(eleLatestDoc);

			By checkbox = getDynamicElement(strCheckbox, fileName);
			waitAndVerifyElement(checkbox);
			clickByJavascript(checkbox);
			setTimeOut(2000);
			LoggingInfo("Clicked on checkbox and Selected record from the list view");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Select record from List " + e.getMessage());
			Assert.fail("Failed to Select record from List " + e.getMessage());
		}
		return fileName;

	}

	/**
	 * Function : Verify Status of the document from the list view
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyDocStatusFromListView(String fileName, String docStatus) {
		try {
			setTimeOut(3000);
			By eleFile = getDynamicElement(strFileName, fileName);
			waitAndVerifyElement(eleFile);
			String fileStatus = getText(eleFile);
			System.out.println(fileStatus);
			Assert.assertEquals(fileStatus, docStatus, "Document status is as expected");
			LoggingInfo("Document status is as expected : " + fileStatus);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Document Status " + e.getMessage());
			Assert.fail("Failed to validate Document Status " + e.getMessage());
		}

	}

	/**
	 * Function : Validate Owner Name from the Document details page(Last Modified
	 * By, Created By) This function hovers over the Owner name field and verifies
	 * the name of the user
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateOwnerName(String userName) throws Exception {
		LoggingInfo("Validating that the owner of the received document record is changed to " + userName + " user.");
		try {

			By ReviewedByCM = By.xpath("//*[text()='Reviewed by CM' and @class='test-id__field-label']");
			scrollToElement(ReviewedByCM);

			By PatEmail = By.xpath("//*[text()='Patient Email Address' and @class='test-id__field-label']");
			scrollToElement(PatEmail);

			By eleOwnerField = getDynamicElement(strOwnerNameField, "Last Modified By");
			// waitAndVerifyElement(eleOwnerField);
			setTimeOut(2000);
			// scrollToElement(eleOwnerField);
			String ownerName = getText(eleOwnerField);
			if(ownerName.contains(userName)){
			System.out.println(ownerName);	
			Assert.assertTrue(ownerName.contains(userName), "Owner name is not as expected");
			}else {
				Assert.fail("Owner name is not as expected");
			}

			LoggingInfo("Owner name is verified successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Owner or User Name " + e.getMessage());
			Assert.fail("Failed to validate Owner or User Name  " + e.getMessage());
		}

	}

	/**
	 * Function: Edit status in cases
	 *
	 * @author Sonica P
	 */
	public void editStatusCase() throws Exception {
		try {
			waitAndVerifyElement(editStatusCase);
			scrollToElement(editStatusCase);
			click(editStatusCase);
			setTimeOut(2000);
			LoggingInfo("User clicks on Edit status button");

			click(eleStatusDropDown);
			setTimeOut(1000);
			click(eleClosedStatus);
			setTimeOut(1000);
			LoggingInfo("User selects status from drop down");

			click(eleSaveBtnCases);
			setTimeOut(2000);
			LoggingInfo("User clicks on Save button");

			waitAndVerifyElement(eleNursingOutReason);
			waitAndVerifyElement(eleNursingOut);
			LoggingInfo("User successfully verifies nursing outcome reason and nursing reason");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to edit the status" + e.getMessage());
			Assert.fail("Failed to edit the status  " + e.getMessage());
		}
	}

	/**
	 * Function: Fill Nursing details in cases section
	 *
	 * @author Sonica P
	 */
	public void fillNursingOutcomeDetails(String nursingOutcomeValue, String nursingOutcomeReasonValues)
			throws Exception {

		try {
			scrollToElement(eleEditNursing);
			setTimeOut(1000);
			click(eleEditNursing);
			setTimeOut(1000);

			By nursingOutcomeDropDownInputBox = getDynamicElement(strStatusDropDownInputBox, "Nursing Outcome");
			waitAndVerifyElement(nursingOutcomeDropDownInputBox);
			scrollToElement(nursingOutcomeDropDownInputBox);
			click(nursingOutcomeDropDownInputBox);
			setTimeOut(1000);

			By nursingDropDownOptions = getDynamicElement(strStatusListBox, "Nursing Outcome");
			waitAndVerifyElement(nursingDropDownOptions);
			// selectItemFromDropDown(nursingOutcomeDropDownInputBox,nursingDropDownOptions,
			// nursingOutcomeValue);
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
			setTimeOut(2000);

			LoggingInfo("User selects Nursing Outcome option");

			// Nursing Outcome Reason
			By nursingOutcomeReasonDropDown = getDynamicElement(strStatusDropDownInputBox, "Nursing Outcome Reason");
			waitAndVerifyElement(nursingOutcomeReasonDropDown);
			scrollToElement(nursingOutcomeReasonDropDown);
			setTimeOut(1000);
			click(nursingOutcomeReasonDropDown);
			setTimeOut(1000);
			LoggingInfo("User clicks on Nursing Outcome Reason field");

			By nursingOutcomeReasonDropDownOptions = getDynamicElement(strStatusListBox, "Nursing Outcome Reason");
			waitAndVerifyElement(nursingOutcomeReasonDropDownOptions);
			setTimeOut(1000);
			// selectItemFromDropDown(nursingOutcomeReasonDropDown,
			// nursingOutcomeReasonDropDownOptions, nursingOutcomeValue);
			act.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
			setTimeOut(2000);
			LoggingInfo("User selects Nursing Outcome Reason option");

			click(eleSaveBtnCases);
			setTimeOut(2000);
			LoggingInfo("User clicks on Save button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select nursing details" + e.getMessage());
			Assert.fail("Failed to select nursing details  " + e.getMessage());
		}
	}

	/**
	 * Function : Verify to click on list view
	 * 
	 * @author Kavyashree
	 **/

	public void clickOnListView() {

		try {
			Log.info("Verify to click on list view");
			click(listViewButton);
			setTimeOut(2000);
			LoggingInfo("list view clicked successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on list view" + e.getMessage());
			Assert.fail("Failed to click on list view " + e.getMessage());
		}

	}

	/**
	 * Function : Verify to list view as DIS User
	 * 
	 * @author Kavyashree
	 **/

	public void verifyListViewAsDISUser() {

		try {
			click(listViewButton);

			By eleMyReceivedDocList = getDynamicElement(listViewOptions, "My Received Documents");
			waitAndVerifyElement(eleMyReceivedDocList);
			highLightElement(eleMyReceivedDocList);
			LoggingInfo("Verified My Received documents in list view as DIS User");

			By elReceivedDocWorkList = getDynamicElement(listViewOptions, "Received Document Worklist");
			waitAndVerifyElement(elReceivedDocWorkList);
			LoggingInfo("Verified Received document worklist in list view as DIS User");

			By eleMyRecentlyViewed = getDynamicElement(listViewOptions, "Recently Viewed");
			waitAndVerifyElement(eleMyRecentlyViewed);
			LoggingInfo("Verified Recently viewed in list view as DIS User");

			By eleRecentlyViewedReceivedDoc = getDynamicElement(listViewOptions, "Recently Viewed Received Documents");
			waitAndVerifyElement(eleRecentlyViewedReceivedDoc);
			highLightElement(eleRecentlyViewedReceivedDoc);
			LoggingInfo("Verified Recently viewed Received documents in list view as DIS User");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Verify List view as dis user " + e.getMessage());
			Assert.fail("Failed to Verify List view as dis user " + e.getMessage());
		}

	}

	/**
	 * Function : Verify to list view as PC User
	 * 
	 * @author Kavyashree
	 **/

	public void verifyListViewAsPCUser() {

		try {

			By eleMyReceivedDocList = getDynamicElement(listViewOptions, "My Received Documents");
			waitAndVerifyElement(eleMyReceivedDocList);
			highLightElement(eleMyReceivedDocList);
			LoggingInfo("Verified My Received documents in list view as PC User");

			By elPSQAReviewWorklist = getDynamicElement(listViewOptions, "PSQA Review Worklist");
			waitAndVerifyElement(elPSQAReviewWorklist);
			LoggingInfo("Verified PSQA Review worklist in list view as PC User");

			By eleMyRecentlyViewed = getDynamicElement(listViewOptions, "Recently Viewed");
			waitAndVerifyElement(eleMyRecentlyViewed);
			LoggingInfo("Verified Recently viewed in list view as PC User");

			By eleRecentlyViewedReceivedDoc = getDynamicElement(listViewOptions, "Recently Viewed Received Documents");
			waitAndVerifyElement(eleRecentlyViewedReceivedDoc);
			highLightElement(eleRecentlyViewedReceivedDoc);
			LoggingInfo("Verified Recentky viewed Received documents in list view as PC User");
			setTimeOut(2000);
			LoggingInfo("Verified List view as PC user");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to Verify List view as PC user " + e.getMessage());
			Assert.fail("Failed to Verify List view as dPC user " + e.getMessage());
		}

	}

	/**
	 * Function : Verify All received document is hidden
	 * 
	 * @author Kavyashree
	 **/

	public void verifyAllReceivedDocumentHidden() {

		try {

			By eleAllReceivedDocList = getDynamicElement(listViewOptions, "All Received Documents");

			if (getWebDriver().findElement(eleAllReceivedDocList).isDisplayed()) {
				LoggingInfo("All recieved document is visible");
				Assert.fail();
			} else {
				setTimeOut(2000);
				LoggingInfo("All recieved document is hidden");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to hide All received document " + e.getMessage());
			Assert.fail("Failed to hide All received document " + e.getMessage());
		}

	}

	/**
	 * Function : Verify to click on received document - Enrollment pdf as PM User
	 * 
	 * @author Kavyashree
	 **/

	public void verifyToClickOnRecord() {

		try {

			waitAndVerifyElement(elereceiveRecord);
			clickByJavascript(elereceiveRecord);
			setTimeOut(2000);
			LoggingInfo("Clicked on receieved document");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on received document " + e.getMessage());
			Assert.fail("Failed to click on received document " + e.getMessage());
		}

	}

	/**
	 * Function : Verify to Open recieved document - Enrollment pdf as DIS User
	 * 
	 * @author Kavyashree
	 **/

	public void verifyToOpenDoc(String name) {

		try {

			By openDoc = getDynamicElement(stropenDocument, name);
			waitAndVerifyElement(openDoc);
			clickByJavascript(openDoc);
			setTimeOut(2000);
			LoggingInfo("Clicked on open document");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on open document " + e.getMessage());
			Assert.fail("Failed to click on open document " + e.getMessage());
		}

	}

	public String validateInactivationReasonIsPopulated(String expectedReason) {
		String inactivationReasonText = "";
		try {
			By reason = getDynamicElement(strinactivationReason, expectedReason);

			scrollToElement(reason);
			waitAndVerifyElement(reason);

			inactivationReasonText = getText(reason);

			Log.info("Successfully validated Inactivation Reason: " + expectedReason);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Inactivation Reason: " + e.getMessage());
			Assert.fail("Failed to validate Inactivation Reason: " + e.getMessage());
		}
		return inactivationReasonText;
	}

	/**
	 * Function : Click on edit button
	 * 
	 * @author Trupti Zure
	 **/
	public void clickonEditButton() {
		try {
			By addButton = getDynamicElement(eleButton, "Edit");
			scrollToElement(addButton);
			waitAndVerifyElement(addButton);
			click(addButton);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify add " + e.getMessage());
			Assert.fail("Failed to verify add" + e.getMessage());
		}

	}

	/**
	 * Function: Switch to frame if present
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void switchFrameIfPresent(By framelocator) {
		setTimeOut(2000);
		if (getWebDriver().findElements(framelocator).size() > 0) {
			switchToFrame(framelocator);
			Log.info("Switched to frame");
		} else {
			getWebDriver().switchTo().defaultContent();
		}

	}

	/**
	 * Function: Create a New Case
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void createNewCase(String CaseName) {
		String strCaseName = "//*[contains(@class, \"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::label//*[contains(@class,\"slds-radio\")]";
		setTimeOut(3000);

		switchFrameIfPresent(By.xpath("//iframe[@title=\"accessibility title\"]"));
		By eleCaseRadioBtn = getDynamicElement(strCaseName, CaseName);
		waitAndVerifyElement(eleCaseRadioBtn);
		clickByJavascript(eleCaseRadioBtn);

		accountObject.clickOnNext();
		setTimeOut(5000);

		getWebDriver().switchTo().defaultContent();
		By eleCasePage = By.xpath("//*[contains(@class, \"active lafPageHost\")]//h2");
		waitAndVerifyElement(eleCasePage);
		String casePageText = getText(eleCasePage);
		if (casePageText.contains(CaseName)) {
			LoggingInfo("New Case: " + CaseName + " page layout is displayed successfully");
		} else {
			Log.error("Failed to create New case: " + CaseName);
			Assert.fail("Failed to create New case: " + CaseName);
		}
	}

	/**
	 * Function: Verify if the fields are autopopulated in the New Case page
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyFieldsAutopopulated(String fieldName) {

		String strFields = "//*[contains(@class, \"active lafPageHost\")]//label[text()=\"{0}\"]//following-sibling::div//input";
		By eleHCPName = getDynamicElement(strFields, fieldName);
		String fieldValue = getAttributeValue(eleHCPName, "data-value");
		if (!fieldValue.isEmpty()) {
			LoggingInfo("Field " + fieldName + " is Auto Populated with value: " + fieldValue);
		} else {
			Log.error("Field " + fieldName + " is Not Auto Populated");
			Assert.fail("Field " + fieldName + " is Not Auto Populated");
		}
	}

	/**
	 * Function: Select Global Opt-Out Type from the dropdown
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void selectGlobalOptOutType(String type) {
		try {
			waitForPageLoaded();
			Log.info("Select training type");
			setTimeOut(3000);
			waitAndVerifyElement(eleGlobalType);
			scrollToElement(eleGlobalType);
			clickByJavascript(eleGlobalType);
			setTimeOut(2000);
			By options = By.xpath(
					"//button[@aria-label=\"Global Opt-Out\"]//parent::div//following-sibling::div//lightning-base-combobox-item[@role=\"option\"]//span[@class=\"slds-media__body\"]//child::span");
			selectItemFromDropDown(eleGlobalType, options, type);
			LoggingInfo("Global Opt-Out Type selected as-" + type);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select" + e.getMessage());
			Assert.fail("Failed to select" + e.getMessage());
		}

	}
// author Tejal

	public void verifyAllReceivedDocumentIsHidden() {
		try {
			setTimeOut(2000);
			By eleAllReceivedDoc = By.xpath("//*[text()=\"All Received Documents\"]");

			List<WebElement> elements = getWebDriver().findElements(eleAllReceivedDoc);

			if (elements.isEmpty()) {
				LoggingInfo("Verified: 'All Received Documents' is absent, as expected (hidden)");
			} else if (!elements.get(0).isDisplayed()) {
				LoggingInfo("Verified: 'All Received Documents' is present but hidden");
			} else {
				LoggingInfo("'All Received Documents' is visible, which is not expected");
				Assert.fail("'All Received Documents' should be hidden, but it is visible");
			}

		} catch (Exception e) {
			LoggingInfo("Unexpected error while verifying visibility of 'All Received Documents': " + e.getMessage());
			Assert.fail("Unexpected error while verifying visibility of 'All Received Documents': " + e.getMessage());
		}
	}

// author tejal
	public void navigateToAllHCPS() {

		try {
			Log.info("Navigate to My Received Documents");
			click(listViewButtonAccounts);
			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, "All HCPs");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to Received Document " + e.getMessage());
			Assert.fail("Failed to navigate to Received Document " + e.getMessage());
		}

	}

	// author Tejal
	public void navigateToAllFacilities() {

		try {
			Log.info("Navigate to My Received Documents");
			click(listViewButtonAccounts);
			By eleSearch = By.xpath("//*[@placeholder='Search lists...']");
			waitAndVerifyElement(eleSearch);
			clickByJavascript(eleSearch);
			inputText(eleSearch, "All Facilities");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to Received Document " + e.getMessage());
			Assert.fail("Failed to navigate to Received Document " + e.getMessage());
		}

	}

	/**
	 * Function: Get Received Date of Document
	 * 
	 * @author Shraddha Shetty
	 **/
	public String getReceivedDateFromDetailsTab() {
		try {
			By eleReceivedDateVal = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Received Date\"]//parent::div//following-sibling::div/span/slot/lightning-formatted-text");
			waitAndVerifyElement(eleReceivedDateVal);
			String receivedDate = getText(eleReceivedDateVal);
			String formatChangereceivedDate = convertDateFormat(receivedDate);
			return formatChangereceivedDate;
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Faileds to get received date of Documents " + e.getMessage());
			Assert.fail("Failed to get received date of Document " + e.getMessage());
			return null;
		}

	}

	/**
	 * Function: Convert Date format MM/dd/yyyy to yyy_MM-dd
	 * 
	 * @author Shraddha Shetty
	 **/
	public String convertDateFormat(String inputDate) {
		// Define input and output formats
		SimpleDateFormat inputFormat = new SimpleDateFormat("M/dd/yyyy");
		SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy_MM_dd");

		try {
			Date date = inputFormat.parse(inputDate);
			outputFormat.format(date);
			return outputFormat.format(date);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to convert Date " + e.getMessage());
			Assert.fail("Failed to convert Date " + e.getMessage());
			return null;
		}
	}

	/**
	 * Function: validate Naming format of Received Document as per Classification
	 * of document
	 * 
	 * @author Shraddha Shetty
	 **/
	public void validateNamingFormatOfReceivedDoc(String DocumentType, String ReceivedDate) {
		try {
			setTimeOut(10000);
			LoggingInfo("Verifying Doc Name.");
			waitForvisiblityOfElementLocated(receivedDocName);
			scrollToElement(receivedDocName);
			String docName = getText(receivedDocName);
			String expectedDocName = DocumentType + "_" + ReceivedDate;
			if (!docName.equals(expectedDocName)) {
				setTimeOut(6000);
				docName = getText(receivedDocName);
			}
			Assert.assertEquals(docName, expectedDocName, "Naming format of document of document is not as expected.");
			LoggingInfo(docName + " is in expected format");

		} catch (Exception e) {
			Log.error("Failed to verify naming format of document " + e.getMessage());
			Assert.fail("Failed to verify naming format of document " + e.getMessage());
		}
	}

	/**
	 * Function: validate Help Text on fields
	 * 
	 * @author Shraddha Shetty
	 **/
	public void validateHelpTextOnStatusField(String expectedhHelpText) {
		try {
			waitForPageLoaded();
			By helpTextele = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//records-record-layout-item//span[contains(text(),'Help Status')]/following-sibling::span");
			waitForvisiblityOfElementLocated(helpTextele);
			String helpText = getText(helpTextele);
			Assert.assertEquals(helpText, expectedhHelpText, "Help Text of Status Field is not as expected");
			LoggingInfo("Help Text " + expectedhHelpText + " is expected");

		} catch (Exception e) {
			Log.error("Failed to verify help text of status field " + e.getMessage());
			Assert.fail("Failed to verify help text of status field " + e.getMessage());
		}
	}

	/**
	 * Function: Change owner of document to user passed in arguement
	 * 
	 * @author Shraddha Shetty
	 **/

	public void changeOwner(String username) {
		try {
			LoggingInfo("Click on Change Owner");
			setTimeOut(4000);
			refresh();
			scrollToElement(eleChangeOwner);
			clickByJavascript(eleChangeOwner);
			waitForPageLoaded();
			LoggingInfo("Successfully clicked on change Owner");

			click(searchUserInput);
			inputText(searchUserInput, username);
			setTimeOut(5000);
			Actions actMemberPlan = new Actions(getWebDriver());
			actMemberPlan.sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
			// genericKeyPress(searchUserInput, "Enter");
			setTimeOut(3000);
			waitForPageLoaded();

			if (isElementDisplayed(userResultTitle)) {
				waitForelementToBeClickable(userRecordName);
				click(userRecordName);
			}

			waitAndVerifyElement(changeOwnerBtn);
			clickByJavascript(changeOwnerBtn);

			waitAndVerifyElement(docOwnerName);
			setTimeOut(2000);
			LoggingInfo("Successfully Changed Owner");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to change Owner " + e.getMessage());
			Assert.fail("Failed to change Owner" + e.getMessage());
		}
	}

	/**
	 * Function: Verify record
	 * 
	 * @author Shraddha Shetty
	 **/
	public void verifyRecordUsingFileName(String fileName) {
		try {
			Log.info("Verify docuement record");
			waitForPageLoaded();
			System.out.println("FN" + fileName);
			By documentRecord = getDynamicElement(strReceivedDocumentTitle, fileName);
			waitAndVerifyElement(documentRecord);
			scrollToElement(documentRecord);
			LoggingInfo(fileName + "-Docuement record verified");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify document record " + e.getMessage());
			Assert.fail("Failed to verify document record " + e.getMessage());
		}
	}

	/**
	 * Function: Click Back to Classify Button to navigate back to classify document
	 * page
	 * 
	 * @author Shraddha Shetty
	 **/
	public void clickBackToClassify() {
		try {
			waitForPageLoaded();
			waitAndVerifyElement(backToClassifyBtn);
			scrollToElement(backToClassifyBtn);
			click(backToClassifyBtn);
			waitForPageLoaded();
			refresh();
			waitAndVerifyElement(eleDocumentType);
			LoggingInfo("Back to classify document");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Back to Classify button " + e.getMessage());
			Assert.fail("Failed to click on Back to Classify button " + e.getMessage());
		}
	}

	/**
	 * Function: Click Back to Classify Button to navigate back to classify document
	 * page
	 * 
	 * @author Shraddha Shetty
	 **/
	public void clickBackToClassifyWithProductIndication(String productIndication) {
		try {
			waitForPageLoaded();
			waitAndVerifyElement(backToClassifyBtn);
			waitAndVerifyElement(eleProductIndication);
			scrollToElement(eleProductIndication);
			click(eleProductIndication);
			selectItemFromList(eleProductIndication, eleProductIndicationDropdown, productIndication,
					"Care program product");
			waitForPageLoaded();
			scrollToElement(backToClassifyBtn);
			click(backToClassifyBtn);
			waitForPageLoaded();
			refresh();
			LoggingInfo("Back to classify document");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Back to Classify button " + e.getMessage());
			Assert.fail("Failed to click on Back to Classify button " + e.getMessage());
		}
	}

	/**
	 * Function: Navigate to Document
	 * 
	 * @author Shraddha Shetty
	 **/
	public void navigateToDocument(String filename) {
		try {
			waitForPageLoaded();
			By docTabEle = By.xpath(
					"//li[contains(@class, \"oneConsoleTabItem tabItem slds-tabs\")]/a[@role=\"tab\"]//span[@class=\"title slds-truncate\" and text()=\""
							+ filename + " | Received Document\"]");
			waitAndVerifyElement(docTabEle);
			click(docTabEle);
			waitForPageLoaded();
			waitAndVerifyElement(eleDocumentType);
			LoggingInfo("Back to classify document");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Back to Classify button " + e.getMessage());
			Assert.fail("Failed to click on Back to Classify button " + e.getMessage());
		}
	}

	public void clickOnShowActions() {

		try {

			setTimeOut(10000);
			Log.info("Verify to click on show Actions");
			clickByJavascript(eleShowActions);
			setTimeOut(2000);
			LoggingInfo("Show Actions clicked successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on show Actions" + e.getMessage());
			Assert.fail("Failed to click on show Actions " + e.getMessage());
		}

	}

	public void changeOwnerFromlist() {

		try {
			setTimeOut(4000);
			Log.info("Verify to click on change owner option");
			click(elechangeOwnernew);
			setTimeOut(2000);
			LoggingInfo("change owner clicked successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on change owner" + e.getMessage());
			Assert.fail("Failed to click on change owner " + e.getMessage());
		}

		click(searchUserInput);
		inputText(searchUserInput, "PSR");
		setTimeOut(5000);
		Actions actMemberPlan = new Actions(getWebDriver());
		actMemberPlan.sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();
		// genericKeyPress(searchUserInput, "Enter");
		setTimeOut(3000);
		waitForPageLoaded();

		waitAndVerifyElement(elesubmitBtn);
		clickByJavascript(elesubmitBtn);
		waitForPageLoaded();

	}

	public void clickOnRecord() {

		try {
			By recordList = By.xpath("(//tbody//tr//th//child::a)[1]");
			waitAndVerifyElement(recordList);
			setTimeOut(1000);
			click(recordList);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on show Actions" + e.getMessage());
			Assert.fail("Failed to click on show Actions " + e.getMessage());
		}

	}

	/**
	 * Function: Veirfy if a Standard Button is removed from the page layout
	 * 
	 * @author Shanavaz Nishani
	 **/	
public void verifyStdButtonRemoved(String buttonName) {
		try {
			String strFilterValue = "//*[contains(@class, 'active lafPageHost')]//button[@title='%s']";
			String eleStdButton = String.format(strFilterValue, buttonName);

			// By eleStdButton = getDynamicElement(stdButton, buttonName);
			if (getWebDriver().findElements(By.xpath(eleStdButton)).size() > 0) {
				LoggingInfo(buttonName + " button is displayed");
				Assert.fail();
			} else {
				setTimeOut(2000);
				LoggingInfo(buttonName + " button has not displayed as expected");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + buttonName + " button " + e.getMessage());
			Assert.fail("Failed to verify " + buttonName + " button " + e.getMessage());
		}

	}

	/**
	 * Function: Open Recent Case from case list view
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void openRecentCase(String cpeName) {
		String strRecentCase = "//a//span[contains(text(),\"{0}\")]//ancestor::td//preceding-sibling::th//a";
		By recentCase = getDynamicElement(strRecentCase, cpeName);
		try {
			waitAndVerifyElement(recentCase);
			clickByJavascript(recentCase);
			setTimeOut(3000);
			LoggingInfo("Clicked on recent case");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on recent case " + e.getMessage());
			Assert.fail("Failed to click on recent case " + e.getMessage());

		}
	}

	public void selectCaseToAssign(String caseName) throws Exception {
		String ss = "//a//span[contains(text(),\"{0}\")]//ancestor::td//preceding-sibling::td//*[@class=\"slds-checkbox_faux\"]";
		By selectCase = getDynamicElement(ss, caseName);
		scrollToElement(selectCase);
		clickByJavascript(selectCase);
		setTimeOut(2000);
		Log.info("Selected the case to assign");
	}
	/**
	 * Function: Check if Case is present in Cases Table
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void checkIfCaseIsPresent(String recordType) {
		List<WebElement> elements = getWebDriver().findElements(
				By.xpath("//*[contains(@class,\"active lafPageHost\")]//td[@data-label=\"Record Type\"]//*[text()]"));
		boolean recordFound = false;
		for (WebElement ele : elements) {
			String recordName = ele.getText();
			if (recordName.contains(recordType)) {
				LoggingInfo("The record type is as expected: " + recordName);
				recordFound = true;
				break;
			}
		}
		if (!recordFound) {
			Log.error("The record type is not as expected: " + recordType);
			Assert.fail("The record type is not as expected: " + recordType);
		}
	}

	/**
	 * Function: Click on Case based on Record Type and Status
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void clickOnCaseBasedOnStatus(String recordType, String Expectedstatus) {

		List<WebElement> rows = getWebDriver()
				.findElements(By.xpath("//*[contains(@class, 'active lafPageHost')]//table//tbody//tr"));

		for (WebElement row : rows) {
			try {
				WebElement nameTd = row.findElement(By.xpath(".//td[@data-label='Record Type']"));
				WebElement statusTd = row.findElement(By.xpath(".//td[@data-label='Status']"));
				WebElement th = row.findElement(By.xpath(".//th[@data-label='Case Number']//a//slot//span//span"));

				String name = nameTd.getText().trim();
				String status = statusTd.getText().trim();

				if (name.equals(recordType) && status.equals(Expectedstatus)) {
					th.click(); // Click the <th> (e.g., a checkbox)
					break; // Remove this if you want to click all matching rows
				}
			} catch (NoSuchElementException e) {
				// Skip rows that don't match the expected structure
			}
		}
	}

/**
	 * Function : Edit And Update the Case fields, by selecting the value from the
	 * dropdown
	 *
	 * @author a.a.rajendra.chandak
	 */
	public void EditAndUpdateTheCaseFields(String fieldName, String fieldValueToBeSelected) {
		try {

			scrollToElement(editStatusCase);
			setTimeOut(1000);
			click(editStatusCase);
			setTimeOut(1000);
			By fieldNameElement = By.xpath("//*[text() = '" + fieldName + "']/../div/lightning-base-combobox//button");
			waitAndVerifyElement(fieldNameElement);
			click(fieldNameElement);
			setTimeOut(2000);
			List<WebElement> dropDownOptions = getWebDriver().findElements(By.xpath("//*[text() = '" + fieldName
					+ "']/../div//div//child::div//span[@ class = 'slds-media__body']/span"));
			System.out.println("Count :" + dropDownOptions.size());
			for (WebElement element : dropDownOptions) {
				String documentTypeName = element.getText();
				System.out.println(documentTypeName);
				// scrollToWebElement(element);
				scrollToHalfPage();
				if (documentTypeName.contains(fieldValueToBeSelected)) {
					By optionToBeSelected = By.xpath("//*[text() = '" + fieldName
							+ "']/../div//div//child::div//span[@ class = 'slds-media__body']/span[contains(text(), '"
							+ fieldValueToBeSelected + "')]");
					waitAndVerifyElement(optionToBeSelected);
					click(optionToBeSelected);
					break;
				}
			}
			LoggingInfo("The " + fieldName + " is edited and updated to " + fieldValueToBeSelected + "");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("The " + fieldName + " is not updated to " + fieldValueToBeSelected + "" + e.getMessage());
			Assert.fail("The " + fieldName + " is not updated to " + fieldValueToBeSelected + "" + e.getMessage());
		}
	}

	/**
	 * Function : Update the Case fields, by selecting the value from the dropdown
	 *
	 *
	 *
	 */

	public void UpdateTheCaseFields(String fieldName, String fieldValueToBeSelected) {
		try {

			// scrollToElement(editStatusCase);
			// setTimeOut(1000);
			// click(editStatusCase);
			setTimeOut(1000);
			By fieldNameElement = By.xpath("//*[text() = '" + fieldName + "']/../div/lightning-base-combobox//button");
			waitAndVerifyElement(fieldNameElement);
			click(fieldNameElement);
			setTimeOut(2000);
			List<WebElement> dropDownOptions = getWebDriver().findElements(By.xpath("//*[text() = '" + fieldName
					+ "']/../div//div//child::div//span[@ class = 'slds-media__body']/span"));
			System.out.println("Count :" + dropDownOptions.size());
			for (WebElement element : dropDownOptions) {
				String documentTypeName = element.getText();
				System.out.println(documentTypeName);
				// scrollToWebElement(element);
				scrollToHalfPage();
				if (documentTypeName.contains(fieldValueToBeSelected)) {
					By optionToBeSelected = By.xpath("//*[text() = '" + fieldName
							+ "']/../div//div//child::div//span[@ class = 'slds-media__body']/span[contains(text(), '"
							+ fieldValueToBeSelected + "')]");
					waitAndVerifyElement(optionToBeSelected);
					click(optionToBeSelected);
					break;
				}
			}
			LoggingInfo("The " + fieldName + " is updated to " + fieldValueToBeSelected + "");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("The " + fieldName + " is not updated to " + fieldValueToBeSelected + "" + e.getMessage());
			Assert.fail("The " + fieldName + " is not updated to " + fieldValueToBeSelected + "" + e.getMessage());
		}
	}

public void validateErrorMsgforCases() {
		try {
			By eleErrorMsg = By.xpath("//ul[@class='errorsList slds-list_dotted slds-m-left_medium']//li[text()=\"This status transition is not allowed manually.\"]");
			waitAndVerifyElement(eleErrorMsg);
			scrollToElement(eleErrorMsg);
			highLightElement(eleErrorMsg);
			if(isElementDisplayed(eleErrorMsg)){
				LoggingInfo("Error message is displayed as expected: This status transition is not allowed manually.");}
			else {
				Assert.fail("Error message is not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Error message " + e.getMessage());
			Assert.fail("Failed to validate Error message " + e.getMessage());
		}

	}

	public void validateErrorMsgAccntDetails(String exepectedError) {
		try {
			String strError = "//*[contains(@class, \"active lafPageHost\")]//*[text()=\"{0}\"]";
			By eleErrorMsg = getDynamicElement(strError, exepectedError);
			waitAndVerifyElement(eleErrorMsg);
			if (isElementDisplayed(eleErrorMsg)) {
				scrollToElement(eleErrorMsg);
				highLightElement(eleErrorMsg);
				LoggingInfo("Error message is displayed as expected: " + exepectedError);
			} else {
				Assert.fail("Error message is not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Error message " + e.getMessage());
			Assert.fail("Failed to validate Error message " + e.getMessage());
		}

	}

	public void validateErrorMsgChangeOwner(String exepectedError) {
		try {
			String strError = "//span[text()=\"{0}\"]";
			By eleErrorMsg = getDynamicElement(strError, exepectedError);
			waitAndVerifyElement(eleErrorMsg);
			if (isElementDisplayed(eleErrorMsg)) {
				scrollToElement(eleErrorMsg);
				highLightElement(eleErrorMsg);
				LoggingInfo("Error message is displayed as expected: " + exepectedError);
			} else {
				Assert.fail("Error message is not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to validate Error message " + e.getMessage());
			Assert.fail("Failed to validate Error message " + e.getMessage());
		}

	}

/**
	 * Function : Click on the respective Column Name
	 *
	 * @author a.a.rajendra.chandak
	 */
	public void clickOnTheDocumentName(String columnName, String recordTypeValue, String Status) {
		try {
			waitForPageLoaded();
			Log.info("Click on Case Name");
			setTimeOut(1000);
			// th[@ title = 'Document Type']//ancestor::table/tbody/tr/td[4]
			// th[@ title = 'Document Type']//ancestor::table/tbody/tr/td[4]//span[@ class =
			// 'slds-truncate']
			List<WebElement> docTypeOptions = getWebDriver()
					.findElements(By.xpath("//thead/tr/th/../..//following-sibling::tbody/tr//td[@ data-label='"
							+ columnName + "']/span/div[contains(.,'" + recordTypeValue + "')]"));
			System.out.println("Count :" + docTypeOptions.size());
			for (WebElement element : docTypeOptions) {
				String documentTypeName = element.getText();
				System.out.println(documentTypeName);
				// scrollToWebElement(element);
				scrollToHalfPage();
				if (documentTypeName.contains(recordTypeValue)) {
					By elementToBeClicked = By.xpath("//tr//td/span/div[contains(.,'" + recordTypeValue
							+ "')]//ancestor::td//following-sibling::td//span[text() = '" + Status
							+ "']//ancestor::td//preceding-sibling::th//a");
					click(elementToBeClicked);
					break;
				}
			}
			LoggingInfo("Document Name is clicked");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click Document Name" + e.getMessage());
			Assert.fail("Failed to click Document Name" + e.getMessage());

		}
	}

	/**
	 * Function: Change owner of document to user passed in arguement with role
	 * 
	 * @author Shanavaz Nishani
	 **/
public void changeOwner(String userName, String UserRole) {
		try {
			LoggingInfo("Click on Change Owner");
			setTimeOut(4000);
			refresh();
			scrollToElement(eleChangeOwner);
			clickByJavascript(eleChangeOwner);
			waitForPageLoaded();
			LoggingInfo("Successfully clicked on change Owner");

			click(searchUserInput);
			inputText(searchUserInput, userName);
			setTimeOut(5000);

			String eleOption = "//div[@title=\"{0}\"]//following-sibling::div[@title=\"{1}\"]";
			By eleUser = getDynamicElement(eleOption, userName, UserRole);
			scrollToElement(eleUser);
			clickByJavascript(eleUser);
			setTimeOut(3000);
			waitForPageLoaded();

			waitAndVerifyElement(changeOwnerBtn);
			clickByJavascript(changeOwnerBtn);

			setTimeOut(2000);
			LoggingInfo("Onwer changed to " + userName);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to change Owner " + e.getMessage());
			Assert.fail("Failed to change Owner" + e.getMessage());
		}
	}

	/**
	 * Function: Update Case Details(e.g. Account Name, Care Program)
	 * 
	 * @author Shanavaz Nishani
	 **/
public void updateCaseDetails(String fieldClear, String fieldVal) throws Exception {

		String strClearSel = "//label[text()=\"{0}\"]//following-sibling::div//button[@title=\"Clear Selection\"]";
		By eleClearSel = getDynamicElement(strClearSel, fieldClear);
		clickByJavascript(eleClearSel);
		setTimeOut(2000);

		String strAccntField = "//label[text()=\"{0}\"]//following-sibling::div//input";
		By eleAccntField = getDynamicElement(strAccntField, fieldClear);
		inputText(eleAccntField, fieldVal);

		String strAdvncSearch = "//label[text()=\"{0}\"]//following-sibling::div//lightning-base-combobox-item[@data-value=\"actionAdvancedSearch\"]";
		By eleAdvncSearch = getDynamicElement(strAdvncSearch, fieldClear);
		waitAndVerifyElement(eleAdvncSearch);
		clickByJavascript(eleAdvncSearch);
		setTimeOut(2000);

		By eleSearchBox = By.xpath("//form//input[contains(@placeholder,'Search')]");
		waitAndVerifyElement(eleSearchBox);
		clearInputText(eleSearchBox);
		inputText(eleSearchBox, fieldVal);
		setTimeOut(2000);

		By eleSearchIcon = By.xpath("//form//button[@type='submit']");
		clickByJavascript(eleSearchIcon);

		By strRec = By.xpath("(//label//span[@class='slds-radio_faux'])[1]");
		waitAndVerifyElement(strRec);
		scrollToElement(strRec);
		clickByJavascript(strRec);
		setTimeOut(2000);

		By eleDoneBtn = By.xpath("//button[text()='Select']");
		scrollToElement(eleDoneBtn);
		clickByJavascript(eleDoneBtn);
		setTimeOut(2000);

		LoggingInfo("Case details updated successfully");

	}

	/**
	 * Function: Create a New Med D AR Case
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void createNewMedARCase(String accName, String careProgram, String status) {

		String strAccntField = "//*[contains(@class, \"active lafPageHost\")]//label[text()=\"{0}\"]//following-sibling::div//input";
		String option = "//*[contains(@class, \"active lafPageHost\")]//lightning-base-combobox-formatted-text[@title=\"{0}\"]";
		By eleAccntField = getDynamicElement(strAccntField, "Account Name");
		inputText(eleAccntField, accName);
		By eleOption = getDynamicElement(option, accName);
		clickByJavascript(eleOption);

		By eleCareProgram = getDynamicElement(strAccntField, "Care Program");
		inputText(eleCareProgram, careProgram);
		By eleOption2 = getDynamicElement(option, careProgram);
		clickByJavascript(eleOption2);

		By relationshipList = getDynamicElement(editFieldList, "Status");
		waitAndVerifyElement(relationshipList);
		clickByJavascript(relationshipList);

		By relationshipListDropDownOptions = getDynamicElement(editFieldListOptions, "Status");
		waitAndVerifyElement(relationshipListDropDownOptions);

		selectItemFromList(relationshipList, relationshipListDropDownOptions, status, "Status");
		LoggingInfo("Selected relation as- " + status);
		setTimeOut(2000);

		documentsPage.clickOnSave();

		setTimeOut(3000);

		Log.info("Med D AR Case created successfully");

	}

	/**
	 * Function: Close Error Dialog if displayed
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void closeErrorDialog(){
		By errorDia= By.xpath("//*[@title='Close error dialog']");
		try{
			if(isElementDisplayed(errorDia)){
				clickByJavascript(errorDia);
				LoggingInfo("Closed error dialog");
			}else{
				LoggingInfo("Error dialog not displayed");
			}
		}catch (Exception e){
			e.printStackTrace();
			Log.error("Failed to close error dialog" + e.getMessage());

	}
}

	/**
	 * Function: Fill Nursing Details
	 * 
	 * @author Shanavaz Nishani
	 **/
public void fillNursingDetails(String NursingOutcome, String NursingOutcomeReason) throws Exception{

		 By nursingOutcome = By.xpath("//button[@aria-label=\"Nursing Outcome\"]");
		waitForPageLoaded();
			setTimeOut(3000);
			waitAndVerifyElement(nursingOutcome);
			scrollToElement(nursingOutcome);
			clickByJavascript(nursingOutcome);
			setTimeOut(2000);
			By options = By.xpath(
					"//button[@aria-label=\"Nursing Outcome\"]//parent::div//following-sibling::div//lightning-base-combobox-item[@role=\"option\"]//span[@class=\"slds-media__body\"]//child::span");
			selectItemFromDropDown(nursingOutcome, options, NursingOutcome);
			LoggingInfo("Nursing Outcome selected as -" + NursingOutcome);

			By nursingReason = By.xpath("//button[@aria-label=\"Nursing Outcome Reason\"]");
			setTimeOut(3000);
			waitAndVerifyElement(nursingReason);
			scrollToElement(nursingReason);
			clickByJavascript(nursingReason);
			setTimeOut(2000);
			scrollToElement(nursingReason);
			By options2 = By.xpath(
					"//button[@aria-label=\"Nursing Outcome Reason\"]//parent::div//following-sibling::div//lightning-base-combobox-item[@role=\"option\"]//span[@class=\"slds-media__body\"]//child::span");
			selectItemFromDropDown(nursingReason, options2, NursingOutcomeReason);
			LoggingInfo("Nursing Outcome Reason selected as -" + NursingOutcomeReason);
	}

	public String getFormName(){
		String form="";
		By formName = By.xpath("//*[contains(@title,'Enrollment')]//*[@class='title slds-truncate']");
		try{
			waitAndVerifyElement(formName);
			form=getText(formName);
			LoggingInfo("Form Name is: "+form);
			String parts[] = form.split("\\|");
			form=parts[0].trim();
		}catch (Exception e){
			e.printStackTrace();	
			Log.error("Failed to get form name" + e.getMessage());
			Assert.fail("Failed to get form name" + e.getMessage());
		}
		return form;
	}
}
