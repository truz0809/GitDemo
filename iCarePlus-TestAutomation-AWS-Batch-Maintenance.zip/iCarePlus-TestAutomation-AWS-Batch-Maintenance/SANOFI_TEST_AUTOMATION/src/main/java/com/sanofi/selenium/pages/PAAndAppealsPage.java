package com.sanofi.selenium.pages;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class PAAndAppealsPage extends Utility_Function {

	public PAAndAppealsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	String errorMsg = "Status cannot be marked as Completed when Outcome is Pending or Not on File";
	/************************* Elements *************************/

	public static By eleMyTaskTitle = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"My Tasks\" and @class=\"main_title\"]");
	public static By eleRequiredStatus = By.xpath("//*[text()='Required']");
	public static String elePAIcon = "(//*[local-name()='svg' and @class='slds-icon' and @data-key='work_type'])[2]";
	public static By eleSavePADetails = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()='Save']//parent::button)[1]");
	public static By eleHCPFollowUp = By.xpath("//*[text()='Not Started']");
	public static By eleErroMessage = By.xpath("//div[contains(@class,\"notification\")]//p");
	public static By eleToastMessage = By
			.xpath("//div[contains(@class,\"toastContent\")]//div[contains(@class,\"toastTitle\")]");
	public static By eleTaskComplitionErrorMsg = By.xpath(
			"//div[contains(@class,\"toastContainer\")]//div[@class=\"slds-list--inline\"]//span[contains(@class,\"toastMessage\")]");
	public static By NoTaskMsg = By.xpath("//*[text()=\"You don't have any tasks right now. Check back later.\"]");
	public static By eleNotStartedStatus = By.xpath("//*[text()='Not Started']");

	/************************* Dynamic Elements *************************/

	public static String strBVStatus = "//*[text()=\"{0}\"]";
	public static String strTextBoxesInput = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strPriorAuth = "//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div";
	public static String strPriorAuthDropdown = "//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::*//parent::*//following-sibling::*//li//child::*[contains(@class,\"option-text\")]";
	public static String strPriorAuthDateField = "//*[text()=\"{0}\"]//parent::*//parent::div//following-sibling::div//input";
	public static String eleButton = "//*[contains(@class,\"active lafPageHost\")]//button[@title=\"{0}\"]";
	public static String strTaskName = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strSubtaskName = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String taskButton = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//span)[1]";
	public static String strSubTaskStatus = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//li)[2]";
	public static String strSubTaskRequired = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//li)[1]";
	public static String subTaskButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::*[@class='card']";
	public static String subTaskSectionButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";
	public static String strInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strPatientCardTitles = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]";
	public static String strDropDownInputBox = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li";
	public static By eleSelectDropDown = By.xpath("//*[contains(@class,\"active lafPageHost\")]//select");
	public static String strStatus = "(//*[text()=\"{0}\"]//following-sibling::ul//span)[2]";
	public static String strTaskRequired = "(//*[text()=\"{0}\"]//following-sibling::ul//span)[1]";

	public void verifyPATaskInitiated() {
		try {
			waitForPageLoaded();
			setTimeOut(3000);
			By PAAppealButton = getDynamicElement(eleButton, "PA/ Appeals");
			setTimeOut(2000);
			waitAndVerifyElement(PAAppealButton);
			click(PAAppealButton);
			setTimeOut(2000);
			String buttonState = getAttributeValue(PAAppealButton, "aria-pressed");
			// Assert the state of the button
			Assert.assertEquals(buttonState, "true", "PA Appeal flow is initialized");
			LoggingInfo("PA Appeal flow is initialized");
			setTimeOut(3000);

		} catch (Exception e) {
			Log.error("Failed to check the status of PA Appeal flow intiation " + e.getMessage());
			Assert.fail("Failed to check the status of PA Appeal flowintiation " + e.getMessage());
		}
	}

	public void verifyPAAppealTask() {

		try {
			setTimeOut(2000);
			Actions act = new Actions(getWebDriver());
			WebElement BVIcon = getWebDriver().findElement(By.xpath(elePAIcon));
			act.moveToElement(BVIcon).click(BVIcon).perform();
			setTimeOut(2000);
			waitAndVerifyElement(eleMyTaskTitle);
			By elePriorAuth = getDynamicElement(strBVStatus, "Prior Auth");
			waitAndVerifyElement(elePriorAuth);
			clickByJavascript(elePriorAuth);
			LoggingInfo("Prior Auth verified successfully");
			setTimeOut(2000);
			waitAndVerifyElement(eleRequiredStatus);
			scrollToElement(elePriorAuth);
			click(eleRequiredStatus);
			setTimeOut(2000);
			LoggingInfo("PA/Appeal Task verified successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify PA/Appeal Tasks  " + e.getMessage());
			Assert.fail("Failed to verify PA/Appeal Tasks " + ". Error - " + e.getMessage());

		}

	}
	
	/**
	 * Verifies that drop down options are present
	 *
	 * @Author Trupti Zure
	 */
	public void verifyDropdownOptionsArePresent(String fieldLabel, List<String> expectedValues) throws Exception {
		try {
			By elefieldLabel = getDynamicElement(strDropDownInputBox, fieldLabel);
			waitAndVerifyElement(elefieldLabel);
			scrollToElement(elefieldLabel);
			click(elefieldLabel);

			String optionXpath = "//*[contains(@class,'active lafPageHost')]//*[text()='" + fieldLabel + "']"
					+ "//parent::label//parent::div//following-sibling::div//li";

			List<WebElement> dropdownOptions = getWebDriver().findElements(By.xpath(optionXpath));

			List<String> actualOptions = dropdownOptions.stream().map(WebElement::getText).map(String::trim)
					.collect(Collectors.toList());

			for (String expectedValue : expectedValues) {
				if (!actualOptions.contains(expectedValue)) {
					throw new AssertionError("Expected dropdown value '" + expectedValue + "' is NOT present in field '"
							+ fieldLabel + "'");
				}
				LoggingInfo("PASS: Dropdown value '" + expectedValue + "' is present in '" + fieldLabel + "'");
			}

			click(elefieldLabel);

		} catch (Exception e) {
			LoggingInfo("FAIL: Error while verifying dropdown values for '" + fieldLabel + "': " + e.getMessage());
			throw e;
		}
	}
	
	
	/**
	 * Verifies that field is mandatory
	 *
	 * @Author Trupti Zure
	 */
	public void verifyFieldIsMandatory(String fieldLabel) {
		try {
			String xpath = "//*[text()='" + fieldLabel + "']//parent::label//abbr";
			By mandatoryAsterisk = By.xpath(xpath);

			if (isElementPresent(mandatoryAsterisk)) {
				LoggingInfo("PASS: Field '" + fieldLabel + "' is marked as mandatory with '*'.");
			} else {
				throw new AssertionError("Field '" + fieldLabel + "' is NOT marked as mandatory.");
			}

		} catch (Exception e) {
			LoggingInfo("FAIL: Error while checking if field '" + fieldLabel + "' is mandatory: " + e.getMessage());
			throw e;
		}
	}

	public void verifyToClickOnPriorAuth(String status, String payerContact, String reciptofRequireDoc, String attempts,
			String payername, String outcome, String outcomeReason, String nextfollowupdate, String hcpFollowUp,
			String approval, String numberofinjectionsused, String paeffectivedate, String pADosage,
			String paexpirationdate, String numberofinjectionsapproved) {

		try {
			setTimeOut(2000);
			// status
			By eleStatus = getDynamicElement(strPriorAuth, "Status");
			click(eleStatus);
			waitAndVerifyElement(eleStatus);
			By eleStatusDropdown = getDynamicElement(strPriorAuthDropdown, "Status");
			waitAndVerifyElement(eleStatusDropdown);
			selectItemFromDropDown(eleStatus, eleStatusDropdown, status);

			// Payer Contact Successful?
			By elePayerContact = getDynamicElement(strInputBox, "Payer Contact Successful?");
			waitAndVerifyElement(elePayerContact);
			click(elePayerContact);
			By elePayerContactDropdown = getDynamicElement(strPriorAuthDropdown, "Payer Contact Successful?");
			waitAndVerifyElement(elePayerContactDropdown);
			selectItemFromDropDown(elePayerContact, elePayerContactDropdown, payerContact);

			// Receipt of Required documents?
			By elereciptofRequireDoc = getDynamicElement(strPriorAuth, "Receipt of Required documents?");
			waitAndVerifyElement(elereciptofRequireDoc);
			click(elereciptofRequireDoc);
			By elereciptofRequireDocDropdown = getDynamicElement(strPriorAuthDropdown,
					"Receipt of Required documents?");
			waitAndVerifyElement(elereciptofRequireDocDropdown);
			selectItemFromDropDown(elereciptofRequireDoc, elereciptofRequireDocDropdown, reciptofRequireDoc);

			// # Attempts
			By eleAttempts = getDynamicElement(strPriorAuth, "# Attempts");
			waitAndVerifyElement(eleAttempts);
			scrollToElement(eleAttempts);
			click(eleAttempts);
			By eleAttemptsDropdown = getDynamicElement(strPriorAuthDropdown, "# Attempts");
			waitAndVerifyElement(eleAttemptsDropdown);
			selectItemFromDropDown(eleAttempts, eleAttemptsDropdown, attempts);

			// Payer Rep Name
			By elepayerName = getDynamicElement(strTextBoxesInput, "Payer Rep Name");
			inputText(elepayerName, payerRepName);

			// Outcome
			By eleOutcome = getDynamicElement(strPriorAuth, "Outcome");
			waitAndVerifyElement(eleOutcome);
			scrollToElement(eleOutcome);
			click(eleOutcome);
			By eleOutcomeDropdown = getDynamicElement(strPriorAuthDropdown, "Outcome");
			waitAndVerifyElement(eleOutcomeDropdown);
			selectItemFromDropDown(eleOutcome, eleOutcomeDropdown, outcome);

			// Outcome Reason
			By eleOutcomeReason = getDynamicElement(strPriorAuth, "Outcome Reason");
			waitAndVerifyElement(eleOutcomeReason);
			click(eleOutcomeReason);
			By eleOutcomeReasonDropdown = getDynamicElement(strPriorAuthDropdown, "Outcome Reason");
			waitAndVerifyElement(eleOutcomeReasonDropdown);
			selectItemFromDropDown(eleOutcomeReason, eleOutcomeReasonDropdown, outcomeReason);

			// Next Follow up Date
			By eleNextFollowUpDate = getDynamicElement(strPriorAuthDateField, "Next Follow up Date");
			waitAndVerifyElement(eleNextFollowUpDate);
			inputText(eleNextFollowUpDate, nextfollowupdate);

			// HCP Follow Up Required?
			By elehcpFollowUp = getDynamicElement(strPriorAuth, "HCP Follow Up Required?");
			waitAndVerifyElement(elehcpFollowUp);
			scrollToElement(elehcpFollowUp);
			click(elehcpFollowUp);
			By elehcpFollowUpDropdown = getDynamicElement(strPriorAuthDropdown, "HCP Follow Up Required?");
			waitAndVerifyElement(elehcpFollowUpDropdown);
			selectItemFromDropDown(elehcpFollowUp, elehcpFollowUpDropdown, hcpFollowUp);

			// Approval #
			By eleApproval = getDynamicElement(strTextBoxesInput, "Approval #");
			waitAndVerifyElement(eleApproval);
			inputText(eleApproval, approval);

			// Number of injections used
			By elenumberOfInjections = getDynamicElement(strTextBoxesInput, "Number of injections used");
			waitAndVerifyElement(elenumberOfInjections);
			inputText(elenumberOfInjections, numberofinjectionsused);

			// PA Effective Date
			By eleEffectiveDate = getDynamicElement(strPriorAuthDateField, "PA Effective Date");
			waitAndVerifyElement(eleEffectiveDate);
			inputText(eleEffectiveDate, paeffectivedate);

			// PA dose coverage
			By elePADoseCoverage = getDynamicElement(strPriorAuth, "PA dose coverage");
			waitAndVerifyElement(elePADoseCoverage);
			click(elePADoseCoverage);
			By elePADoseCoverageDropdown = getDynamicElement(strPriorAuthDropdown, "PA dose coverage");
			waitAndVerifyElement(elePADoseCoverageDropdown);
			selectItemFromDropDown(elePADoseCoverage, elePADoseCoverageDropdown, pADosage);

			// PA Expiration Date

			By eleExpirationDate = getDynamicElement(strPriorAuthDateField, "PA Expiration Date");
			waitAndVerifyElement(eleExpirationDate);
			inputText(eleExpirationDate, paexpirationdate);

			// Number of injections approved
			By elenumberOfInjectionsApproved = getDynamicElement(strTextBoxesInput, "Number of injections approved");
			waitAndVerifyElement(elenumberOfInjectionsApproved);
			inputText(elenumberOfInjectionsApproved, numberofinjectionsapproved);

			LoggingInfo("Verified Prior Auth section");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Prior Auth Section  " + e.getMessage());
			Assert.fail("Failed to verify Prior Auth Section " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Click on save button
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnSave() {

		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleSavePADetails);
			scrollToElement(eleSavePADetails);
			click(eleSavePADetails);
			setTimeOut(2000);
			LoggingInfo("Clicked on save button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to save details" + e.getMessage());
			Assert.fail("Failed to save details" + ". Error - " + e.getMessage());

		}

	}

	public void clickOnPATask() {
		try {
			setTimeOut(3000);
			By paAppealsButton = getDynamicElement(eleButton, "PA/ Appeals");
			waitAndVerifyElement(paAppealsButton);
			scrollToElement(paAppealsButton);
			click(paAppealsButton);
			setTimeOut(3000);
		} catch (Exception e) {
			Log.error("Failed to Click on PA/Appeals button " + e.getMessage());
			Assert.fail("Failed to Click on PA/Appeals start button " + e.getMessage());
		}
	}

	public void verifyHCPFollowUp(String status, String attempts, String hcpcontact) {

		try {

			waitForPageLoaded();
			waitAndVerifyElement(eleMyTaskTitle);
			By elePriorAuth = getDynamicElement(strBVStatus, "Prior Auth");
			waitAndVerifyElement(elePriorAuth);
			clickByJavascript(elePriorAuth);
			setTimeOut(1000);
			waitAndVerifyElement(eleHCPFollowUp);
			scrollToElement(eleHCPFollowUp);
			click(eleHCPFollowUp);
			setTimeOut(1000);
			By eleStatus = getDynamicElement(strPriorAuth, "Status");
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			click(eleStatus);
			By eleStatusDropdown = getDynamicElement(strPriorAuthDropdown, "Status");
			waitAndVerifyElement(eleStatusDropdown);
			selectItemFromDropDown(eleStatus, eleStatusDropdown, status);
			setTimeOut(1000);

			By eleAttempts = getDynamicElement(strPriorAuth, "# Attempts");
			click(eleAttempts);
			waitAndVerifyElement(eleAttempts);
			By eleAttemptsDropdown = getDynamicElement(strPriorAuthDropdown, "# Attempts");
			selectItemFromDropDown(eleAttempts, eleAttemptsDropdown, attempts);
			setTimeOut(1000);

			By eleHCPContact = getDynamicElement(strPriorAuth, "HCP Contact Successful?");
			scrollToElement(eleHCPContact);
			click(eleHCPContact);
			waitAndVerifyElement(eleHCPContact);
			By eleHCPContactDropdown = getDynamicElement(strPriorAuthDropdown, "HCP Contact Successful?");
			waitAndVerifyElement(eleHCPContactDropdown);
			selectItemFromDropDown(eleHCPContact, eleHCPContactDropdown, hcpcontact);
			waitAndVerifyElement(eleSavePADetails);
			scrollToElement(eleSavePADetails);
			click(eleSavePADetails);

			setTimeOut(2000);

			LoggingInfo("Verified HCP Follow Up section");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify HCP Follow Up Section  " + e.getMessage());
			Assert.fail("Failed to verify HCP Follow Up Section " + ". Error - " + e.getMessage());

		}

	}

	public void verifyPASummarySection(String status, String hcpcontact, String hcpOfficeName, String outcome,
			String outcomeReason, String proceedwithAppeal, String intendedDate, String appealPacket) {

		try {
			waitForPageLoaded();
			setTimeOut(2000);

			By elePASummary = getDynamicElement(strBVStatus, "PA Summary");
			waitAndVerifyElement(elePASummary);
			scrollToElement(elePASummary);
			clickByJavascript(elePASummary);
			setTimeOut(1000);
			By eleSubTaskButton = getDynamicElement(subTaskButton, "Communicate Results and Send SOB");
			waitAndVerifyElement(eleSubTaskButton);
			clickByJavascript(eleSubTaskButton);
			setTimeOut(1000);

			By eleStatus = getDynamicElement(strPriorAuth, "Status");
			waitAndVerifyElement(eleStatus);
			click(eleStatus);
			By eleStatusDropdown = getDynamicElement(strPriorAuthDropdown, "Status");
			waitAndVerifyElement(eleStatusDropdown);
			selectItemFromDropDown(eleStatus, eleStatusDropdown, status);

			By eleHCPContact = getDynamicElement(strPriorAuth, "HCP Contact Successful?");
			waitAndVerifyElement(eleHCPContact);
			click(eleHCPContact);
			By eleHCPContactDropdown = getDynamicElement(strPriorAuthDropdown, "HCP Contact Successful?");
			waitAndVerifyElement(eleHCPContactDropdown);
			selectItemFromDropDown(eleHCPContact, eleHCPContactDropdown, hcpcontact);

			By eleHCPOfficeContact = getDynamicElement(strTextBoxesInput, "HCP Office Contact Name");
			waitAndVerifyElement(eleHCPOfficeContact);
			inputText(eleHCPOfficeContact, hcpOfficeName);

			By eleOutcome = getDynamicElement(strPriorAuth, "Outcome");
			waitAndVerifyElement(eleOutcome);
			click(eleOutcome);
			By eleOutcomeDropdown = getDynamicElement(strPriorAuthDropdown, "Outcome");
			waitAndVerifyElement(eleOutcomeDropdown);
			selectItemFromDropDown(eleOutcome, eleOutcomeDropdown, outcome);

			By eleOutcomeReason = getDynamicElement(strPriorAuth, "Outcome Reason");
			waitAndVerifyElement(eleOutcomeReason);
			click(eleOutcomeReason);
			By eleOutcomeReasonDropdown = getDynamicElement(strPriorAuthDropdown, "Outcome Reason");
			selectItemFromDropDown(eleOutcomeReason, eleOutcomeReasonDropdown, outcomeReason);

			By eleproceedWithAppeal = getDynamicElement(strPriorAuth, "Proceed with Appeal?");
			scrollToElement(eleproceedWithAppeal);
			click(eleproceedWithAppeal);
			By eleproceedWithAppealDropdown = getDynamicElement(strPriorAuthDropdown, "Proceed with Appeal?");
			selectItemFromDropDown(eleproceedWithAppeal, eleproceedWithAppealDropdown, proceedwithAppeal);

			waitAndVerifyElement(eleSavePADetails);
			scrollToElement(eleSavePADetails);
			click(eleSavePADetails);
			LoggingInfo("Verified PA Summary section");
			setTimeOut(4000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify PA Summary Section  " + e.getMessage());
			Assert.fail("Failed to verify  PA Summary Section " + ". Error - " + e.getMessage());

		}

	}

	public void checkPATaskInitiation() {
		try {

			// Prior Auth
			By taskName = getDynamicElement(strTaskName, "Prior Auth");
			waitAndVerifyElement(taskName);
			LoggingInfo("Prior Auth task has been initialized");
			setTimeOut(2000);

			By eleTaskButton = getDynamicElement(taskButton, "Prior Auth");
			scrollToElement(eleTaskButton);
			click(eleTaskButton);
			LoggingInfo("Clicked on Prior Auth task");
			setTimeOut(1000);

			By subTaskName = getDynamicElement(strSubtaskName, "Follow up on Results");
			waitAndVerifyElement(subTaskName);
			LoggingInfo("Prior Auth sub task-Follow up on Results has been initialized");
			setTimeOut(2000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, "Follow up on Results");
			waitAndVerifyElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Not Started", "Follow up on Results task status verified");

			By subTaskStatusRequired = getDynamicElement(strSubTaskRequired, "Follow up on Results");
			waitAndVerifyElement(subTaskStatusRequired);
			String reqStatus = getText(subTaskStatusRequired);
			// Assert the status of subtask
			Assert.assertEquals(reqStatus, "Required", "Follow up on Results task status required verified");

			// PA Summary
			By pataskName = getDynamicElement(strTaskName, "PA Summary");
			waitAndVerifyElement(pataskName);
			LoggingInfo("PA Summary task is present");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to Check PA Task Initiation " + e.getMessage());
			Assert.fail("Failed to Check PA Task Initiation " + e.getMessage());
		}
	}

	/*
	 * Author - Anand P
	 * 
	 * Function: Enter data in HCP follow up details task with Intent of submission
	 * as No
	 * 
	 * Change log-Updated the XPath details to a common XPath, updated Office
	 * contact name condition
	 */

	public void enterHCPFollowUpDetailsIntent(String hcpSuccessful, String attempts, String hcpName,
			String intentOfSub) {
		try {

			// hcpSuccessful
			By eleHCPContact = getDynamicElement(strDropDownInputBox, "HCP Contact Successful?");
			scrollToElement(eleHCPContact);
			click(eleHCPContact);
			waitAndVerifyElement(eleHCPContact);
			By eleHCPContactDropdown = getDynamicElement(strDropDownOptions, "HCP Contact Successful?");
			waitAndVerifyElement(eleHCPContactDropdown);
			selectItemFromList(eleHCPContact, eleHCPContactDropdown, hcpSuccessful, "HCP Contact Successful?");

			// # Attempts
			By eleAttempts = getDynamicElement(strDropDownInputBox, "# Attempts");
			click(eleAttempts);
			waitAndVerifyElement(eleAttempts);
			By eleAttemptsDropdown = getDynamicElement(strDropDownOptions, "# Attempts");
			selectItemFromList(eleAttempts, eleAttemptsDropdown, attempts, "# Attempts");
			setTimeOut(1000);

			if (hcpSuccessful.equalsIgnoreCase("Yes")) {
				// HCP Office Contact Name
				By eleHCPOfficeContact = getDynamicElement(strInputBox, "HCP Office Contact Name");
				waitAndVerifyElement(eleHCPOfficeContact);
				inputText(eleHCPOfficeContact, hcpName);

				// Intent of Submission
				By eleIntentofSub = getDynamicElement(strDropDownInputBox, "Intent of Submission");
				click(eleIntentofSub);
				waitAndVerifyElement(eleIntentofSub);
				By eleIntentofSubOptions = getDynamicElement(strDropDownOptions, "Intent of Submission");
				selectItemFromList(eleIntentofSub, eleIntentofSubOptions, intentOfSub, "Intent of Submission");
				setTimeOut(1000);
			}
		} catch (Exception e) {
			Log.error("Failed to enter HCP Follow up details  " + e.getMessage());
			Assert.fail("Failed to enter HCP Follow up details " + ". Error - " + e.getMessage());
		}
	}

	/*
	 * Author - Anand P Function - Verify no subtask generated in PA summary section
	 */

	public void verifyPASummarySectionNotGenerated() {
		try {

			waitForPageLoaded();
			setTimeOut(2000);

			By elePASummary = getDynamicElement(strBVStatus, "PA Summary");
			waitAndVerifyElement(elePASummary);
			scrollToElement(elePASummary);
			clickByJavascript(elePASummary);
			Log.info("Verify No Subtasks generated in PA Summary Section");
			waitAndVerifyElement(NoTaskMsg);
			scrollToElement(NoTaskMsg);
			Assert.assertTrue(getWebDriver().findElement(NoTaskMsg).isDisplayed());
			LoggingInfo("Verified No Subtasks generated in PA Summary Section.");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Locator Search Failed Not able to validate" + ". Error - " + e.getMessage());
		}
	}

	/*
	 * Author Anand P Function - Validate that HCP Follow up task is created every
	 * time the BV specialist marks \"HCP Follow up Required\" as yes
	 *
	 */
	public void validateMultipleHCPFollowUpTaskCreated() {

		try {

			clickOnPATask();
			By elePriorAuth = getDynamicElement(strBVStatus, "Prior Auth");
			waitAndVerifyElement(elePriorAuth);
			scrollToElement(elePriorAuth);
			clickByJavascript(elePriorAuth);
			setTimeOut(4000);

			By hcpFollowup = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"HCP Follow Up\")]");

			List<WebElement> eleHCPFollowUp = getWebDriver().findElements(hcpFollowup);
			int eleCount = eleHCPFollowUp.size();
			System.out.println("HCP Follow Up task created " + eleCount + " times and visible to CM user");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("HCP follow up task does not exist" + e.getMessage());
		}
	}

	/**
	 * Function:Check completion status of HCP Follow Up Task
	 * 
	 * @author Anand P
	 **/

	public void checkPATaskCompletion(String task, String subTask) {
		try {
			clickOnPATask();
			By elePriorAuth = getDynamicElement(strBVStatus, task);
			waitAndVerifyElement(elePriorAuth);
			scrollToElement(elePriorAuth);
			clickByJavascript(elePriorAuth);
			setTimeOut(2000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, subTask);
			waitAndVerifyElement(subTaskStatus);
			scrollToElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Completed", "Enrollment sub task completed successfully");
			LoggingInfo("HCP Follow up sub task completed successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to check HCP FOllow up task " + e.getMessage());
			Assert.fail("Failed to check HCP Follow up Task Complition " + e.getMessage());
		}
	}

	/*
	 * Author Anand P Function - Validate that HCP Follow up task is created every
	 * time the BV specialist marks \"HCP Follow up Required\" as yes
	 *
	 */
	public void validateHCPTaskInitiatedStatusAsNotStarted() {
		try {

			clickOnPATask();
			By elePriorAuth = getDynamicElement(strBVStatus, "Prior Auth");
			waitAndVerifyElement(elePriorAuth);
			scrollToElement(elePriorAuth);
			clickByJavascript(elePriorAuth);
			setTimeOut(2000);

			By hcpFollowup = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"HCP Follow Up\")]");

			boolean isPresent = isElementPresent(hcpFollowup);
			if (isPresent) {
				LoggingInfo("HCP FollowUp is visible with status as not started");
			} else {
				throw new AssertionError("HCP card - not found");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate HCP follow up task " + e.getMessage());
		}

	}

	/**
	 * Function: Enter mandatory details in PA Appeals denied section
	 * 
	 * @author Anand P
	 **/

	public void enterMandatoryPAAppealDeniedDetails(String appeal, String denialDate) {

		try {
			// Denial Date
			By eleintendedDate = getDynamicElement(strInputBox, "Denial Date");
			waitAndVerifyElement(eleintendedDate);
			scrollToElement(eleintendedDate);
			inputText(eleintendedDate, intendedDate);

			// Appeal needed?
			By eleAppeal = getDynamicElement(strDropDownInputBox, "Appeal needed?");
			waitAndVerifyElement(eleAppeal);
			scrollToElement(eleAppeal);

			click(eleAppeal);
			By eleAppealOptions = getDynamicElement(strDropDownOptions, "Appeal needed?");
			waitAndVerifyElement(eleAppealOptions);
			selectItemFromList(eleAppeal, eleAppealOptions, appeal, "Appeal needed?");
			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to enter details of PA Appeal Denied " + e.getMessage());
			Assert.fail("Failed to enter details of PA Appeal Denied  " + e.getMessage());

		}

	}

	/**
	 * Function: Click on prior auth task
	 * 
	 * @author Trupti Zure
	 **/

	public void clickOnTask() {
		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleRequiredStatus);
			click(eleRequiredStatus);
			setTimeOut(2000);
			// closeTaskLoadingWindowIfVisible();
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click on Prior Auth sub task " + e.getMessage());
			Assert.fail("Failed to click on Prior Auth sub task " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Error message when the Outcome is Pending or Not on File
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyErrorMessage() {
		try {
			setTimeOut(3000);
			waitAndVerifyElement(eleErroMessage);
			verifyTextPresent(eleErroMessage, errorMsg);
			setTimeOut(2000);
			LoggingInfo("Successfully verified Error message when the Outcome is Pending or Not on File.");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify error message " + e.getMessage());
		}
	}

	public void enterPAAppealDetails(String status, String payerContact, String reciptofRequireDoc, String attempts,
			String payername, String outcome, String outcomeReason, String nextfollowupdate, String hcpFollowUp) {
		try {
			setTimeOut(2000);
			// status
			By eleStatus = getDynamicElement(strPriorAuth, "Status");
			click(eleStatus);
			waitAndVerifyElement(eleStatus);
			By eleStatusDropdown = getDynamicElement(strPriorAuthDropdown, "Status");
			waitAndVerifyElement(eleStatusDropdown);
			selectItemFromDropDown(eleStatus, eleStatusDropdown, status);

			// Payer Contact Successful?
			By elePayerContact = getDynamicElement(strPriorAuth, "Payer Contact Successful?");
			waitAndVerifyElement(elePayerContact);
			click(elePayerContact);
			By elePayerContactDropdown = getDynamicElement(strPriorAuthDropdown, "Payer Contact Successful?");
			waitAndVerifyElement(elePayerContactDropdown);
			selectItemFromDropDown(elePayerContact, elePayerContactDropdown, payerContact);

			// Receipt of Required documents?
			By elereciptofRequireDoc = getDynamicElement(strPriorAuth, "Receipt of Required documents?");
			waitAndVerifyElement(elereciptofRequireDoc);
			click(elereciptofRequireDoc);
			By elereciptofRequireDocDropdown = getDynamicElement(strPriorAuthDropdown,
					"Receipt of Required documents?");
			waitAndVerifyElement(elereciptofRequireDocDropdown);
			selectItemFromDropDown(elereciptofRequireDoc, elereciptofRequireDocDropdown, reciptofRequireDoc);

			// # Attempts
			By eleAttempts = getDynamicElement(strPriorAuth, "# Attempts");
			waitAndVerifyElement(eleAttempts);
			scrollToElement(eleAttempts);
			click(eleAttempts);
			By eleAttemptsDropdown = getDynamicElement(strPriorAuthDropdown, "# Attempts");
			waitAndVerifyElement(eleAttemptsDropdown);
			selectItemFromDropDown(eleAttempts, eleAttemptsDropdown, attempts);

			// Payer Rep Name
			By elepayerName = getDynamicElement(strTextBoxesInput, "Payer Rep Name");
			inputText(elepayerName, payerRepName);

			// Outcome
			By eleOutcome = getDynamicElement(strPriorAuth, "Outcome");
			waitAndVerifyElement(eleOutcome);
			scrollToElement(eleOutcome);
			click(eleOutcome);
			By eleOutcomeDropdown = getDynamicElement(strPriorAuthDropdown, "Outcome");
			waitAndVerifyElement(eleOutcomeDropdown);
			selectItemFromDropDown(eleOutcome, eleOutcomeDropdown, outcome);

			// Outcome Reason
			By eleOutcomeReason = getDynamicElement(strPriorAuth, "Outcome Reason");
			waitAndVerifyElement(eleOutcomeReason);
			click(eleOutcomeReason);
			By eleOutcomeReasonDropdown = getDynamicElement(strPriorAuthDropdown, "Outcome Reason");
			waitAndVerifyElement(eleOutcomeReasonDropdown);
			selectItemFromDropDown(eleOutcomeReason, eleOutcomeReasonDropdown, outcomeReason);

			// HCP Follow Up Required?
			By elehcpFollowUp = getDynamicElement(strPriorAuth, "HCP Follow Up Required?");
			waitAndVerifyElement(elehcpFollowUp);
			scrollToElement(elehcpFollowUp);
			click(elehcpFollowUp);
			By elehcpFollowUpDropdown = getDynamicElement(strPriorAuthDropdown, "HCP Follow Up Required?");
			waitAndVerifyElement(elehcpFollowUpDropdown);
			selectItemFromDropDown(elehcpFollowUp, elehcpFollowUpDropdown, hcpFollowUp);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to enter PA and Appeals Details " + e.getMessage());
		}
	}

	/**
	 * Function: Select outcome
	 * 
	 * @author Trupti Zure
	 **/
	public void selectOutcome(String outcome) {
		try {

			// Outcome
			By eleOutcome = getDynamicElement(strDropDownInputBox, "Outcome");
			waitAndVerifyElement(eleOutcome);
			scrollToElement(eleOutcome);
			click(eleOutcome);
			By eleOutcomeDropdown = getDynamicElement(strDropDownOptions, "Outcome");
			waitAndVerifyElement(eleOutcomeDropdown);
			selectItemFromDropDown(eleOutcome, eleOutcomeDropdown, outcome);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select outcome " + e.getMessage());
		}
	}

	/**
	 * Function: Select outcome reason
	 * 
	 * @author Trupti Zure
	 **/
	public void selectOutcomeReason(String outcomeReason) {
		try {

			// Outcome Reason
			By eleOutcomeReason = getDynamicElement(strPriorAuth, "Outcome Reason");
			verifyAnyFieldIsEnabledOrDisabled(eleOutcomeReason, "Outcome Reason", true);
			click(eleOutcomeReason);
			By eleOutcomeReasonDropdown = getDynamicElement(strPriorAuthDropdown, "Outcome Reason");
			waitAndVerifyElement(eleOutcomeReasonDropdown);
			selectItemFromDropDown(eleOutcomeReason, eleOutcomeReasonDropdown, outcomeReason);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select outcome Reason " + e.getMessage());
		}
	}

	/**
	 * Function: Validate PA Appeal Appeal Section
	 * 
	 * @author Trupti Zure
	 **/
	public void validatePAAppealSection(boolean section) {

		String[] fieldsLabels = { "Approval #", "Number of injections used", "PA Effective Date", "PA dose coverage",
				"PA Expiration Date", "Number of injections approved" };

		try {

			By elePaAppealApproved = getDynamicElement(subTaskSectionButton, "PA/ Appeal Approved");
			verifyAnyFieldIsEnabledOrDisabled(elePaAppealApproved, "PA/ Appeal Approved", section);
			LoggingInfo("'PA/ Appeal Approved' section is enable");
			setTimeOut(2000);

			for (String fieldLabel : fieldsLabels) {
				By fieldLocator = getDynamicElement(strInputBox, fieldLabel);
				verifyAnyFieldIsEnabledOrDisabled(fieldLocator, fieldLabel, section);
				setTimeOut(2000);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate PA/ Appeals Approved section " + e.getMessage());
		}
	}

	/**
	 * Function: Validate PA Appeal Denied Section
	 * 
	 * @author Trupti Zure
	 **/
	public void validatePAAppealDeniedSection(boolean section) {

		String[] fieldsLabels = { "Denial Date", "Provider notified of the denial?", "Appeal needed?",
				"Next steps after denial", "Level of Appeal allowed?" };

		try {

			By elePaAppealApproved = getDynamicElement(subTaskSectionButton, "PA/ Appeal Denied");
			verifyAnyFieldIsEnabledOrDisabled(elePaAppealApproved, "PA/ Appeal Denied", section);
			LoggingInfo("'PA/ Appeal Denied' section is enable");
			setTimeOut(2000);

			for (String fieldLabel : fieldsLabels) {
				By fieldLocator = getDynamicElement(strInputBox, fieldLabel);
				verifyAnyFieldIsEnabledOrDisabled(fieldLocator, fieldLabel, section);
				setTimeOut(2000);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate PA/ Appeals Approved section " + e.getMessage());
		}
	}

	/**
	 * Function: Validate PA Appeal Pending Section
	 * 
	 * @author Trupti Zure
	 **/
	public void validatePAAppealPendingSection(boolean section) {

		String[] fieldsLabels = { "Next Follow up Time", "Additional documents required", "Channel for Follow up" };

		try {

			By elePaAppealApproved = getDynamicElement(subTaskSectionButton, "PA/ Appeal Pending");
			verifyAnyFieldIsEnabledOrDisabled(elePaAppealApproved, "PA/ Appeal Pending", section);
			LoggingInfo("'PA/ Appeal Pending' section is enable");
			setTimeOut(2000);

			for (String fieldLabel : fieldsLabels) {
				By fieldLocator = getDynamicElement(strInputBox, fieldLabel);
				verifyAnyFieldIsEnabledOrDisabled(fieldLocator, fieldLabel, section);
				setTimeOut(2000);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate PA/ Appeal Pending section " + e.getMessage());
		}
	}

	/**
	 * Function: Validate No sections appears on screen
	 * 
	 * @author Trupti Zure
	 **/

	public void validateNoSectionAppears(ArrayList<String> sectionNames) {
		try {
			for (String sectionName : sectionNames) {
				By elePaAppealApproved = getDynamicElement(subTaskSectionButton, sectionName);
				boolean isPresent = isElementPresent(elePaAppealApproved);

				if (isPresent) {
					throw new AssertionError("Section is present - " + elePaAppealApproved);
				} else {
					LoggingInfo(sectionName + " - not found");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate No section appears: " + e.getMessage());
		}
	}

	/**
	 * Function: Enter PA Appeal And Approved Details
	 * 
	 * @author Trupti Zure
	 **/

	public void enterPAAppealAndApprovedDetails(String numberofinjectionsused, String paeffectivedate, String pADosage,
			String paexpirationdate, String numberofinjectionsapproved) {

		try {

			// Approval #
			By eleApproval = getDynamicElement(strTextBoxesInput, "Approval #");
			waitAndVerifyElement(eleApproval);
			scrollToElement(eleApproval);
			inputText(eleApproval, "PA approval");

			// Number of injections used
			By elenumberOfInjections = getDynamicElement(strTextBoxesInput, "Number of injections used");
			waitAndVerifyElement(elenumberOfInjections);
			inputText(elenumberOfInjections, numberofinjectionsused);

			// PA Effective Date
			By eleEffectiveDate = getDynamicElement(strPriorAuthDateField, "PA Effective Date");
			waitAndVerifyElement(eleEffectiveDate);
			inputText(eleEffectiveDate, paeffectivedate);

			// PA dose coverage
			By elePADoseCoverage = getDynamicElement(strPriorAuth, "PA dose coverage");
			waitAndVerifyElement(elePADoseCoverage);
			click(elePADoseCoverage);
			By elePADoseCoverageDropdown = getDynamicElement(strPriorAuthDropdown, "PA dose coverage");
			waitAndVerifyElement(elePADoseCoverageDropdown);
			selectItemFromDropDown(elePADoseCoverage, elePADoseCoverageDropdown, pADosage);

			// PA Expiration Date

			By eleExpirationDate = getDynamicElement(strPriorAuthDateField, "PA Expiration Date");
			waitAndVerifyElement(eleExpirationDate);
			inputText(eleExpirationDate, paexpirationdate);

			// Number of injections approved
			By elenumberOfInjectionsApproved = getDynamicElement(strTextBoxesInput, "Number of injections approved");
			waitAndVerifyElement(elenumberOfInjectionsApproved);
			inputText(elenumberOfInjectionsApproved, numberofinjectionsapproved);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate section: " + e.getMessage());
		}
	}

	/**
	 * Function: Add business days to current date
	 * 
	 * @author Trupti Zure
	 **/

	public static Date addBusinessDays(Date date, int days, String timeZoneID) {

		Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone(timeZoneID));
		calendar.setTime(date);

		DateTime result = new DateTime(date);

		if (isWeekend(result)) {
			result = getNextBusinessDate(result);
		}

		while (days > 0) {
			result = result.plusDays(1);
			if (!isWeekend(result)) {
				days--;
			}
		}

		return result.toDate();
	}

	/**
	 * Function: Check weekend
	 * 
	 * @author Trupti Zure
	 **/

	private static boolean isWeekend(DateTime dateTime) {
		int dayOfWeek = dateTime.getDayOfWeek();
		return dayOfWeek == DateTimeConstants.SATURDAY || dayOfWeek == DateTimeConstants.SUNDAY;
	}

	/**
	 * Function: Get next business date
	 * 
	 * @author Trupti Zure
	 **/
	private static DateTime getNextBusinessDate(DateTime result) {
		while (isWeekend(result)) {
			result = result.plusDays(1);
		}
		return result;
	}

	/**
	 * Function: Get current date
	 * 
	 * @author Trupti Zure
	 **/
	public static Date getCurrentDate(String timeZoneID) {
		Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone(timeZoneID));
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}

	/**
	 * Function: Get 10 business days from the completion of task
	 * 
	 * @author Trupti Zure
	 **/

	public String getDate() {
		Date today = getCurrentDate("America/New_York");
		Date futureDate = addBusinessDays(today, 10, "America/New_York");
		SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
		String formattedDate = formatter.format(futureDate);
		return formattedDate;
	}

	/**
	 * Function: Validate Next follow up date on prior auth task
	 * 
	 * @author Trupti Zure
	 **/

	public void validateNextFollowUpDate() {
		try {
			// Next Follow up Date
			By eleNextFollowUpDate = getDynamicElement(strPriorAuthDateField, "Next Follow up Date");
			waitAndVerifyElement(eleNextFollowUpDate);
			scrollToElement(eleNextFollowUpDate);
			String expectedFollowUpdate = getDate();
			String actualFollowUpdate = getAttributeValue(eleNextFollowUpDate, "value");
			Assert.assertEquals(actualFollowUpdate, expectedFollowUpdate, "Follow up date matches");
			LoggingInfo(
					"PA Tasks has \"Next Follow Update\" of 10 business days from the completion of Review & Send Summary ");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate next follow up date: " + e.getMessage());
		}
	}

	/*
	 * Author - Anand P Function - Verify PA/Appeal task is completed
	 */

	public void verifyPACompleteStatus() {
		try {
			setTimeOut(2000);

			By paAppealsButton = getDynamicElement(eleButton, "PA/ Appeals");
			scrollToElement(paAppealsButton);
			click(paAppealsButton);
			LoggingInfo("PA/Appeal flow is completed");

		} catch (Exception e) {
			Log.error("Failed to complete PA/Appeal  flow  " + e.getMessage());
			Assert.fail("Failed to complete PA/Appeal flow  " + e.getMessage());
		}
	}

	/**
	 * Function: Validate HCP is Task Not Initiated
	 * 
	 * @author Trupti Zure
	 **/
	public void validateHCPTaskNotInitiated() {
		try {

			clickOnPATask();
			By elePriorAuth = getDynamicElement(strBVStatus, "Prior Auth");
			waitAndVerifyElement(elePriorAuth);
			clickByJavascript(elePriorAuth);
			setTimeOut(2000);

			By hcpFollowup = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"HCP-Follow up\"]");
			boolean isPresent = isElementPresent(hcpFollowup);

			if (isPresent) {
				throw new AssertionError("Element is present - HCP Follow up task");
			} else {
				LoggingInfo("HCP Follow up task - not found");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate HCP follow up task " + e.getMessage());
		}
	}

	/**
	 * Function: Validate presence of HCP information card
	 * 
	 * @author Trupti Zure
	 **/
	public void validateHCPInformationCardPresent() {
		try {

			By hcpCardTitle = getDynamicElement(strPatientCardTitles, "HCP Information");
			waitAndVerifyElement(hcpCardTitle);
			By hcpCard = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"HCP Information\"]/ancestor::div[3]//following-sibling::div[1]");
			boolean isPresent = isElementPresent(hcpCard);
			if (isPresent) {
				LoggingInfo("HCP information card is visible");
			} else {
				throw new AssertionError("HCP card - not found");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate HCP card information visibilty " + e.getMessage());
			Log.error("Failed to validate HCP card information visibilty " + e.getMessage());
		}
	}

	/**
	 * Function: Validate presence of HCO information card
	 * 
	 * @author Trupti Zure
	 **/
	public void validateHCOInformationCardPresent() {
		try {

			By hcoCardTitle = getDynamicElement(strPatientCardTitles, "HCO Information");
			waitAndVerifyElement(hcoCardTitle);
			scrollToElement(hcoCardTitle);
			By hcoCard = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),'HCO Information')]//ancestor::div[3]//following-sibling::div[1]");
			boolean isPresent = isElementPresent(hcoCard);
			if (isPresent) {
				LoggingInfo("HCO information card is visible to BV");
			} else {
				LoggingInfo("HCO information card is not visible to BV");
				throw new AssertionError("HCO information card is not visible to BV");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate HCO card information visibilty " + e.getMessage());
			Log.error("Failed to validate HCO card information visibilty " + e.getMessage());
		}
	}

	public void verifyAndEnterHCPFollowUpDetails(String status, String attempts, String hcpcontact) {

		try {

			waitForPageLoaded();
			waitAndVerifyElement(eleMyTaskTitle);
			By elePriorAuth = getDynamicElement(strBVStatus, "Prior Auth");
			waitAndVerifyElement(elePriorAuth);
			scrollToElement(elePriorAuth);
			clickByJavascript(elePriorAuth);
			setTimeOut(2000);
			waitAndVerifyElement(eleHCPFollowUp);
			clickByJavascript(eleHCPFollowUp);
			setTimeOut(1000);
			By eleStatus = getDynamicElement(strPriorAuth, "Status");
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			clickByJavascript(eleStatus);
			By eleStatusDropdown = getDynamicElement(strPriorAuthDropdown, "Status");
			waitAndVerifyElement(eleStatusDropdown);
			selectItemFromDropDown(eleStatus, eleStatusDropdown, status);
			setTimeOut(1000);

			By eleAttempts = getDynamicElement(strPriorAuth, "# Attempts");
			click(eleAttempts);
			waitAndVerifyElement(eleAttempts);
			By eleAttemptsDropdown = getDynamicElement(strPriorAuthDropdown, "# Attempts");
			selectItemFromDropDown(eleAttempts, eleAttemptsDropdown, attempts);
			setTimeOut(1000);

			By eleHCPContact = getDynamicElement(strPriorAuth, "HCP Contact Successful?");
			scrollToElement(eleHCPContact);
			click(eleHCPContact);
			waitAndVerifyElement(eleHCPContact);
			By eleHCPContactDropdown = getDynamicElement(strPriorAuthDropdown, "HCP Contact Successful?");
			waitAndVerifyElement(eleHCPContactDropdown);
			selectItemFromDropDown(eleHCPContact, eleHCPContactDropdown, hcpcontact);
			waitAndVerifyElement(eleSavePADetails);
			clickByJavascript(eleSavePADetails);

			setTimeOut(2000);

			LoggingInfo("Verified HCP Follow Up section");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify HCP Follow Up Section  " + e.getMessage());
			Assert.fail("Failed to verify HCP Follow Up Section " + ". Error - " + e.getMessage());

		}

	}

	public void changeStatusToCompleted(String status) {

		try {
			setTimeOut(2000);
			// change status
			By eleStatus = getDynamicElement(strDropDownInputBox, "Status");
			click(eleStatus);
			waitAndVerifyElement(eleStatus);
			By eleStatusDropdown = getDynamicElement(strDropDownOptions, "Status");
			waitAndVerifyElement(eleStatusDropdown);
			selectItemFromDropDown(eleStatus, eleStatusDropdown, status);
			LoggingInfo("Changed status to-" + status);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify the status " + e.getMessage());
			Assert.fail("Failed to verify status " + ". Error - " + e.getMessage());

		}

	}

	public void verifyToEnterOnPriorAuthForDeniedOutcome(String status, String payerContact, String reciptofRequireDoc,
			String attempts, String payername, String outcome, String outcomeReason, String nextfollowupdate,
			String hcpFollowUp, String denialDate, String appealNeeded) {

		try {
			setTimeOut(2000);
			// status
			By eleStatus = getDynamicElement(strPriorAuth, "Status");
			click(eleStatus);
			waitAndVerifyElement(eleStatus);
			By eleStatusDropdown = getDynamicElement(strPriorAuthDropdown, "Status");
			waitAndVerifyElement(eleStatusDropdown);
			selectItemFromDropDown(eleStatus, eleStatusDropdown, status);

			// Payer Contact Successful?

			By elePayerContact = getDynamicElement(strPriorAuth, "Payer Contact Successful?");
			waitAndVerifyElement(elePayerContact);
			click(elePayerContact);
			By elePayerContactDropdown = getDynamicElement(strPriorAuthDropdown, "Payer Contact Successful?");
			waitAndVerifyElement(elePayerContactDropdown);
			selectItemFromDropDown(elePayerContact, elePayerContactDropdown, payerContact);

			// Receipt of Required documents?
			By elereciptofRequireDoc = getDynamicElement(strPriorAuth, "Receipt of Required documents?");
			waitAndVerifyElement(elereciptofRequireDoc);
			click(elereciptofRequireDoc);
			By elereciptofRequireDocDropdown = getDynamicElement(strPriorAuthDropdown,
					"Receipt of Required documents?");
			waitAndVerifyElement(elereciptofRequireDocDropdown);
			selectItemFromDropDown(elereciptofRequireDoc, elereciptofRequireDocDropdown, reciptofRequireDoc);

			// # Attempts
			By eleAttempts = getDynamicElement(strPriorAuth, "# Attempts");
			waitAndVerifyElement(eleAttempts);
			scrollToElement(eleAttempts);
			click(eleAttempts);
			By eleAttemptsDropdown = getDynamicElement(strPriorAuthDropdown, "# Attempts");
			waitAndVerifyElement(eleAttemptsDropdown);
			selectItemFromDropDown(eleAttempts, eleAttemptsDropdown, attempts);

			// Payer Rep Name
			By elepayerName = getDynamicElement(strTextBoxesInput, "Payer Rep Name");
			inputText(elepayerName, payerRepName);

			// Outcome
			By eleOutcome = getDynamicElement(strPriorAuth, "Outcome");
			waitAndVerifyElement(eleOutcome);
			scrollToElement(eleOutcome);
			click(eleOutcome);
			By eleOutcomeDropdown = getDynamicElement(strPriorAuthDropdown, "Outcome");
			waitAndVerifyElement(eleOutcomeDropdown);
			selectItemFromDropDown(eleOutcome, eleOutcomeDropdown, outcome);

			// Outcome Reason
			By eleOutcomeReason = getDynamicElement(strPriorAuth, "Outcome Reason");
			waitAndVerifyElement(eleOutcomeReason);
			click(eleOutcomeReason);
			By eleOutcomeReasonDropdown = getDynamicElement(strPriorAuthDropdown, "Outcome Reason");
			waitAndVerifyElement(eleOutcomeReasonDropdown);
			selectItemFromDropDown(eleOutcomeReason, eleOutcomeReasonDropdown, outcomeReason);

			// Next Follow up Date
			By eleNextFollowUpDate = getDynamicElement(strPriorAuthDateField, "Next Follow up Date");
			waitAndVerifyElement(eleNextFollowUpDate);
			inputText(eleNextFollowUpDate, nextfollowupdate);

			// HCP Follow Up Required?
			By elehcpFollowUp = getDynamicElement(strPriorAuth, "HCP Follow Up Required?");
			waitAndVerifyElement(elehcpFollowUp);
			scrollToElement(elehcpFollowUp);
			click(elehcpFollowUp);
			By elehcpFollowUpDropdown = getDynamicElement(strPriorAuthDropdown, "HCP Follow Up Required?");
			waitAndVerifyElement(elehcpFollowUpDropdown);
			selectItemFromDropDown(elehcpFollowUp, elehcpFollowUpDropdown, hcpFollowUp);

			// PA Effective Date
			By eleDenialDate = getDynamicElement(strPriorAuthDateField, "Denial Date");
			waitAndVerifyElement(eleDenialDate);
			inputText(eleDenialDate, denialDate);

			By eleAppealNeeded = getDynamicElement(strPriorAuth, "Appeal needed?");
			waitAndVerifyElement(eleAppealNeeded);
			click(eleAppealNeeded);
			By eleAppealNeededDropdown = getDynamicElement(strPriorAuthDropdown, "Appeal needed?");
			waitAndVerifyElement(eleAppealNeededDropdown);
			selectItemFromDropDown(eleAppealNeeded, eleAppealNeededDropdown, appealNeeded);

			LoggingInfo("Verified Prior Auth section");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Prior Auth Section  " + e.getMessage());
			Assert.fail("Failed to verify Prior Auth Section " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Enter data in Reason For Follow Up Details task
	 * 
	 * @author Trupti Zure
	 **/

	public void enterReasonForFollowUpDetails(String status, String outcome, String outcomeReason,
			String additonalDoc) {
		try {
			// Status
			By eleStatus = getDynamicElement(strPriorAuth, "Status");
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			click(eleStatus);
			By eleStatusDropdown = getDynamicElement(strPriorAuthDropdown, "Status");
			waitAndVerifyElement(eleStatusDropdown);
			selectItemFromList(eleStatus, eleStatusDropdown, status, "Status");
			setTimeOut(1000);
			if (outcome != null) {
				// Outcome
				By eleOutcome = getDynamicElement(strPriorAuth, "Outcome");
				waitAndVerifyElement(eleOutcome);
				scrollToElement(eleOutcome);
				click(eleOutcome);
				By eleOutcomeDropdown = getDynamicElement(strPriorAuthDropdown, "Outcome");
				waitAndVerifyElement(eleOutcomeDropdown);
				selectItemFromList(eleOutcome, eleOutcomeDropdown, outcome, "Outcome");
			}
			if (outcomeReason != null) {
				// Outcome Reason
				By eleOutcomeReason = getDynamicElement(strPriorAuth, "Outcome Reason");
				waitAndVerifyElement(eleOutcomeReason);
				click(eleOutcomeReason);
				By eleOutcomeReasonDropdown = getDynamicElement(strPriorAuthDropdown, "Outcome Reason");
				waitAndVerifyElement(eleOutcomeReasonDropdown);
				selectItemFromList(eleOutcomeReason, eleOutcomeReasonDropdown, outcomeReason, "Outcome Reason");
			}
			if (additonalDoc != null) {
				// Additional Documents Required
				By eleDocRequired = getDynamicElement(strPriorAuth, "Additional Documents Required");
				waitAndVerifyElement(eleDocRequired);
				click(eleDocRequired);
				By eleDocRequiredOptions = getDynamicElement(strPriorAuthDropdown, "Additional Documents Required");
				waitAndVerifyElement(eleDocRequiredOptions);
				selectItemFromList(eleDocRequired, eleDocRequiredOptions, additonalDoc,
						"Additional Documents Required");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter HCP Follow up details  " + e.getMessage());
			Assert.fail("Failed to enter HCP Follow up details " + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Enter data in HCP follow up details task
	 * 
	 * @author Trupti Zure
	 **/
	public void enterHCPFollowUpDetails(String hcpSuccessful, String attempts, String hcpName, String intentOfSub,
			String subChannel, String followUpTime, String nxtFollowUpDate, String channel) {
		try {

			// hcpSuccessful
			By eleHCPContact = getDynamicElement(strDropDownInputBox, "HCP Contact Successful?");
			scrollToElement(eleHCPContact);
			click(eleHCPContact);
			waitAndVerifyElement(eleHCPContact);
			By eleHCPContactDropdown = getDynamicElement(strDropDownOptions, "HCP Contact Successful?");
			waitAndVerifyElement(eleHCPContactDropdown);
			selectItemFromList(eleHCPContact, eleHCPContactDropdown, hcpSuccessful, "HCP Contact Successful?");

			// # Attempts
			By eleAttempts = getDynamicElement(strDropDownInputBox, "# Attempts");
			waitAndVerifyElement(eleAttempts);
			click(eleAttempts);
			By eleAttemptsDropdown = getDynamicElement(strDropDownOptions, "# Attempts");
			selectItemFromList(eleAttempts, eleAttemptsDropdown, attempts, "# Attempts");
			setTimeOut(1000);

			// HCP Office Contact Name
			By eleHCPOfficeContact = getDynamicElement(strInputBox, "HCP Office Contact Name");
			waitAndVerifyElement(eleHCPOfficeContact);
			inputText(eleHCPOfficeContact, hcpName);

			// Intent of Submission
			By eleIntentofSub = getDynamicElement(strDropDownInputBox, "Intent of Submission");
			click(eleIntentofSub);
			waitAndVerifyElement(eleIntentofSub);
			By eleIntentofSubOptions = getDynamicElement(strDropDownOptions, "Intent of Submission");
			selectItemFromList(eleIntentofSub, eleIntentofSubOptions, intentOfSub, "Intent of Submission");
			setTimeOut(1000);

			if (intentOfSub.equals("Yes")) {
				// Intended Date of Submission
				By eleDateOfSub = getDynamicElement(strInputBox, "Intended Date of Submission");
				waitAndVerifyElement(eleDateOfSub);
				String date = getDate();
				inputText(eleDateOfSub, date);
			}
			// Submission Channel
			By eleSubChannel = getDynamicElement(strDropDownInputBox, "Submission Channel");
			click(eleSubChannel);
			waitAndVerifyElement(eleSubChannel);
			By eleSubChannelOptions = getDynamicElement(strDropDownOptions, "Submission Channel");
			selectItemFromList(eleSubChannel, eleSubChannelOptions, subChannel, "Submission Channel");
			setTimeOut(1000);

			// Next Follow up Time
			if (followUpTime != null) {
				By elefollowUpTime = getDynamicElement(strInputBox, "Next Follow up Time");
				click(elefollowUpTime);
				waitAndVerifyElement(elefollowUpTime);
				By elefollowUpTimeOptions = getDynamicElement(strDropDownOptions, "Next Follow up Time");
				selectItemFromList(eleIntentofSub, elefollowUpTimeOptions, followUpTime, "Next Follow up Time");
				setTimeOut(1000);
			}

			// Next Follow up Date
			if (nxtFollowUpDate != null) {
				By elenxtFollowUpDate = getDynamicElement(strInputBox, "Next Follow up Date");
				waitAndVerifyElement(elenxtFollowUpDate);
				inputText(elenxtFollowUpDate, nxtFollowUpDate);

			}

			// Channel for Follow up
			if (channel != null) {
				By elefollowUpTime = getDynamicElement(strDropDownInputBox, "Channel for Follow up");
				click(elefollowUpTime);
				waitAndVerifyElement(elefollowUpTime);
				By elefollowUpTimeOptions = getDynamicElement(strDropDownOptions, "Channel for Follow up");
				selectItemFromList(eleIntentofSub, elefollowUpTimeOptions, followUpTime, "Channel for Follow up");
				setTimeOut(1000);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter HCP Follow up details  " + e.getMessage());
			Assert.fail("Failed to enter HCP Follow up details " + ". Error - " + e.getMessage());

		}
	}

	public void clickOnHCPTask() {

		try {
			waitAndVerifyElement(eleMyTaskTitle);
			By elePriorAuth = getDynamicElement(strBVStatus, "Prior Auth");
			waitAndVerifyElement(elePriorAuth);
			clickByJavascript(elePriorAuth);
			By eleSubTaskButton = getDynamicElement(subTaskButton, "HCP Follow Up");
			waitAndVerifyElement(eleSubTaskButton);
			clickByJavascript(eleSubTaskButton);
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click on task " + e.getMessage());
			Assert.fail("Failed to click on task " + e.getMessage());
		}
	}

	/**
	 * Function: Verify toast message when action is completed
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyToastMessage() {
		try {
			String expectedMessage = "Action Completed";
			waitAndVerifyElement(eleToastMessage);
			String actualMessage = getText(eleToastMessage);
			Assert.assertEquals(actualMessage, expectedMessage, "Toast message");
			LoggingInfo("Toast message verified");
		} catch (Exception e) {
			Log.error("Failed to verify toast message " + e.getMessage());
			Assert.fail("Failed to verify toast message " + e.getMessage());
		}
	}

	/**
	 * Function: Verify error message when action is completed
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyTaskComplitionErrorMessage() {
		try {
			String expectedMessage = "Select a task related to a care program enrollee work order step that’s in progress.";
			waitAndVerifyElement(eleTaskComplitionErrorMsg);
			String actualErrorMessage = getText(eleTaskComplitionErrorMsg);
			Assert.assertEquals(actualErrorMessage, expectedMessage, "Error message");
			LoggingInfo("Error message verified");

		} catch (Exception e) {
			Log.error("Failed to verify error message " + e.getMessage());
			Assert.fail("Failed to verify error message " + e.getMessage());
		}
	}

	public void enterStatus(String status) {
		try {
			// status
			By eleStatus = getDynamicElement(strPriorAuth, "Status");
			click(eleStatus);
			waitAndVerifyElement(eleStatus);
			By eleStatusDropdown = getDynamicElement(strPriorAuthDropdown, "Status");
			waitAndVerifyElement(eleStatusDropdown);
			selectItemFromDropDown(eleStatus, eleStatusDropdown, status);

		} catch (Exception e) {
			Log.error("Failed to enter status " + e.getMessage());
			Assert.fail("Failed to enter status " + e.getMessage());
		}
	}

	/**
	 * Function: Click Follow Up On Prior Auth Task
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnPriorAuthTask() {
		try {
			By eleTaskButton = getDynamicElement(taskButton, "Prior Auth");
			click(eleTaskButton);
			LoggingInfo("Clicked on Prior Auth task");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to click on prior auth task " + e.getMessage());
			Assert.fail("Failed to click on prior auth task " + e.getMessage());
		}
	}

	/**
	 * Function: Click Follow Up On Results Task
	 * 
	 * @author Trupti Zure
	 **/
	public void clickOnFollowUpOnResultsTask() {

		try {
			waitAndVerifyElement(eleMyTaskTitle);
			By elePriorAuth = getDynamicElement(strBVStatus, "Prior Auth");
			waitAndVerifyElement(elePriorAuth);
			clickByJavascript(elePriorAuth);
			By eleSubTaskButton = getDynamicElement(subTaskButton, "Follow up on Results");
			waitAndVerifyElement(eleSubTaskButton);
			clickByJavascript(eleSubTaskButton);
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click on task " + e.getMessage());
			Assert.fail("Failed to click on task " + e.getMessage());
		}
	}

	/**
	 * Function: Enter mandatory details on PA Appeal section
	 * 
	 * @author Trupti Zure
	 **/
	public void enterMandatoryPAAppealDetails(String status, String payerContact, String attempt, String hcpFollowUp,
			String reciept, String payerName) {
		try {

			// Status
			By elestatus = getDynamicElement(strDropDownInputBox, "Status");
			waitAndVerifyElement(elestatus);
			scrollToElement(elestatus);
			click(elestatus);
			By elestatusOptions = getDynamicElement(strDropDownOptions, "Status");
			waitAndVerifyElement(elestatusOptions);
			selectItemFromList(elestatus, elestatusOptions, status, "Status");
			setTimeOut(1000);

			// Payer Contact Successful?
			By elePayerContact = getDynamicElement(strDropDownInputBox, "Payer Contact Successful?");
			waitAndVerifyElement(elePayerContact);
			scrollToElement(elePayerContact);
			click(elePayerContact);
			By elePayerContactOptions = getDynamicElement(strDropDownOptions, "Payer Contact Successful?");
			waitAndVerifyElement(elePayerContactOptions);
			selectItemFromList(elePayerContact, elePayerContactOptions, payerContact, "Payer Contact Successful?");
			setTimeOut(1000);
			if (payerContact.equalsIgnoreCase("Yes")) {
				// Receipt of Required documents?
				By elereqDocuments = getDynamicElement(strDropDownInputBox, "Receipt of Required documents?");
				waitAndVerifyElement(elereqDocuments);
				scrollToElement(elereqDocuments);
				click(elereqDocuments);
				By elereqDocumentsOptions = getDynamicElement(strDropDownOptions, "Receipt of Required documents?");
				waitAndVerifyElement(elereqDocumentsOptions);
				selectItemFromList(elereqDocuments, elereqDocumentsOptions, reciept, "Receipt of Required documents?");
				setTimeOut(3000);

				// Payer Rep Name
				By elePayerRepName = getDynamicElement(strDropDownInputBox, "Payer Rep Name");
				waitAndVerifyElement(elePayerRepName);
				scrollToElement(elePayerRepName);
				setTimeOut(1000);
				inputText(elePayerRepName, payerName);
				setTimeOut(1000);
			}

			// # Attempts
			By eleAttempts = getDynamicElement(strDropDownInputBox, "# Attempts");
			waitAndVerifyElement(eleAttempts);
			scrollToElement(eleAttempts);
			click(eleAttempts);
			By eleAttemptsOptions = getDynamicElement(strDropDownOptions, "# Attempts");
			waitAndVerifyElement(eleAttemptsOptions);
			selectItemFromList(eleAttempts, eleAttemptsOptions, attempt, "# Attempts");
			setTimeOut(1000);

			// HCP Follow Up Required?
			By elehcpFollowUp = getDynamicElement(strDropDownInputBox, "HCP Follow Up Required?");
			waitAndVerifyElement(elehcpFollowUp);
			scrollToElement(elehcpFollowUp);
			click(elehcpFollowUp);
			By elehcpFollowUpOptions = getDynamicElement(strDropDownOptions, "HCP Follow Up Required?");
			waitAndVerifyElement(elehcpFollowUp);
			selectItemFromList(elehcpFollowUp, elehcpFollowUpOptions, hcpFollowUp, "HCP Follow Up Required?");
			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to enter details on PA and Appeal section " + e.getMessage());
			Assert.fail("Failed to enter details on PA and Appeal section " + e.getMessage());
		}
	}
	
	/**
	 * Function: Enter mandatory details on PA Appeal section-2nd Appeal
	 * 
	 * @author Sonica P
	 **/
	public void enterMandatoryPAAppealDetailsfor2ndAppeal(String status, String payerContact, String attempt, String hcpFollowUp,
			String reciept, String payerName) {
		try {

			// Status
			By elestatus = getDynamicElement(strDropDownInputBox, "Status");
			waitAndVerifyElement(elestatus);
			scrollToElement(elestatus);
			click(elestatus);
			By elestatusOptions = getDynamicElement(strDropDownOptions, "Status");
			waitAndVerifyElement(elestatusOptions);
			selectItemFromList(elestatus, elestatusOptions, status, "Status");
			setTimeOut(1000);

			// Payer Contact Successful?
			By elePayerContact = getDynamicElement(strDropDownInputBox, "Payer Contact Successful?");
			waitAndVerifyElement(elePayerContact);
			scrollToElement(elePayerContact);
			click(elePayerContact);
			By elePayerContactOptions = getDynamicElement(strDropDownOptions, "Payer Contact Successful?");
			waitAndVerifyElement(elePayerContactOptions);
			selectItemFromList(elePayerContact, elePayerContactOptions, payerContact, "Payer Contact Successful?");
			setTimeOut(1000);
			if (payerContact.equalsIgnoreCase("Yes")) {
				// Receipt of Required documents?
				By elereqDocuments = getDynamicElement(strDropDownInputBox, "Receipt of Required documents?");
				waitAndVerifyElement(elereqDocuments);
				scrollToElement(elereqDocuments);
				click(elereqDocuments);
				By elereqDocumentsOptions = getDynamicElement(strDropDownOptions, "Receipt of Required documents?");
				waitAndVerifyElement(elereqDocumentsOptions);
				selectItemFromList(elereqDocuments, elereqDocumentsOptions, reciept, "Receipt of Required documents?");
				setTimeOut(3000);

				// Payer Rep Name
				By elePayerRepName = getDynamicElement(strDropDownInputBox, "Payer Rep Name");
				waitAndVerifyElement(elePayerRepName);
				scrollToElement(elePayerRepName);
				setTimeOut(1000);
				inputText(elePayerRepName, payerName);
				setTimeOut(1000);
			}

			// # Attempts
			By eleAttempts = getDynamicElement(strDropDownInputBox, "# Attempts");
			waitAndVerifyElement(eleAttempts);
			scrollToElement(eleAttempts);
			click(eleAttempts);
			By eleAttemptsOptions = getDynamicElement(strDropDownOptions, "# Attempts");
			waitAndVerifyElement(eleAttemptsOptions);
			selectItemFromList(eleAttempts, eleAttemptsOptions, attempt, "# Attempts");
			setTimeOut(1000);

//			// HCP Follow Up Required?
//			By elehcpFollowUp = getDynamicElement(strDropDownInputBox, "HCP Follow Up Required?");
//			waitAndVerifyElement(elehcpFollowUp);
//			scrollToElement(elehcpFollowUp);
//			click(elehcpFollowUp);
//			By elehcpFollowUpOptions = getDynamicElement(strDropDownOptions, "HCP Follow Up Required?");
//			waitAndVerifyElement(elehcpFollowUp);
//			selectItemFromList(elehcpFollowUp, elehcpFollowUpOptions, hcpFollowUp, "HCP Follow Up Required?");
//			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to enter details on PA and Appeal section " + e.getMessage());
			Assert.fail("Failed to enter details on PA and Appeal section " + e.getMessage());
		}
	}

	
	public void enterMandatoryPAAppealDetails1(String status, String payerContact, String attempt,
			String reciept, String payerName) {
		try {

			// Status
			By elestatus = getDynamicElement(strDropDownInputBox, "Status");
			waitAndVerifyElement(elestatus);
			scrollToElement(elestatus);
			click(elestatus);
			By elestatusOptions = getDynamicElement(strDropDownOptions, "Status");
			waitAndVerifyElement(elestatusOptions);
			selectItemFromList(elestatus, elestatusOptions, status, "Status");
			setTimeOut(1000);

			// Payer Contact Successful?
			By elePayerContact = getDynamicElement(strDropDownInputBox, "Payer Contact Successful?");
			waitAndVerifyElement(elePayerContact);
			scrollToElement(elePayerContact);
			click(elePayerContact);
			By elePayerContactOptions = getDynamicElement(strDropDownOptions, "Payer Contact Successful?");
			waitAndVerifyElement(elePayerContactOptions);
			selectItemFromList(elePayerContact, elePayerContactOptions, payerContact, "Payer Contact Successful?");
			setTimeOut(1000);
			if (payerContact.equalsIgnoreCase("Yes")) {
				// Receipt of Required documents?
				By elereqDocuments = getDynamicElement(strDropDownInputBox, "Receipt of Required documents?");
				waitAndVerifyElement(elereqDocuments);
				scrollToElement(elereqDocuments);
				click(elereqDocuments);
				By elereqDocumentsOptions = getDynamicElement(strDropDownOptions, "Receipt of Required documents?");
				waitAndVerifyElement(elereqDocumentsOptions);
				selectItemFromList(elereqDocuments, elereqDocumentsOptions, reciept, "Receipt of Required documents?");
				setTimeOut(3000);

				// Payer Rep Name
				By elePayerRepName = getDynamicElement(strDropDownInputBox, "Payer Rep Name");
				waitAndVerifyElement(elePayerRepName);
				scrollToElement(elePayerRepName);
				setTimeOut(1000);
				inputText(elePayerRepName, payerName);
				setTimeOut(1000);
			}

			// # Attempts
			By eleAttempts = getDynamicElement(strDropDownInputBox, "# Attempts");
			waitAndVerifyElement(eleAttempts);
			scrollToElement(eleAttempts);
			click(eleAttempts);
			By eleAttemptsOptions = getDynamicElement(strDropDownOptions, "# Attempts");
			waitAndVerifyElement(eleAttemptsOptions);
			selectItemFromList(eleAttempts, eleAttemptsOptions, attempt, "# Attempts");
			setTimeOut(1000);

			// HCP Follow Up Required?
			/*By elehcpFollowUp = getDynamicElement(strDropDownInputBox, "HCP Follow Up Required?");
			waitAndVerifyElement(elehcpFollowUp);
			scrollToElement(elehcpFollowUp);
			click(elehcpFollowUp);
			By elehcpFollowUpOptions = getDynamicElement(strDropDownOptions, "HCP Follow Up Required?");
			waitAndVerifyElement(elehcpFollowUp);
			selectItemFromList(elehcpFollowUp, elehcpFollowUpOptions, hcpFollowUp, "HCP Follow Up Required?");
			setTimeOut(1000);*/

		} catch (Exception e) {
			Log.error("Failed to enter details on PA and Appeal section " + e.getMessage());
			Assert.fail("Failed to enter details on PA and Appeal section " + e.getMessage());
		}
	}
	
	
	
	
	/**
	 * Function: Enter outcome and outcome reason
	 * 
	 * @author Trupti Zure
	 **/

	public void enterOutcomeAndOutcomeReason(String outcome, String outcomeReason) {
		try {

			// Outcome
			By eleOutcome = getDynamicElement(strDropDownInputBox, "Outcome");
			waitAndVerifyElement(eleOutcome);
			scrollToElement(eleOutcome);
			click(eleOutcome);
			By eleOutcomeOptions = getDynamicElement(strDropDownOptions, "Outcome");
			waitAndVerifyElement(eleOutcomeOptions);
			selectItemFromList(eleOutcome, eleOutcomeOptions, outcome, "Outcome");
			setTimeOut(1000);

			// Outcome Reason
			By eleOutcomeReason = getDynamicElement(strDropDownInputBox, "Outcome Reason");
			waitAndVerifyElement(eleOutcomeReason);
			scrollToElement(eleOutcomeReason);
			click(eleOutcomeReason);
			By eleOutcomeReasonOptions = getDynamicElement(strDropDownOptions, "Outcome Reason");
			waitAndVerifyElement(eleOutcomeReasonOptions);
			selectItemFromList(eleOutcomeReason, eleOutcomeReasonOptions, outcomeReason, "Outcome Reason");
			setTimeOut(1000);

//			// Additional Information Required
//			By eleAddInfo = getDynamicElement(strDropDownInputBox, "Additional Information Required");
//			waitAndVerifyElement(eleAddInfo);
//			scrollToElement(eleAddInfo);
//			click(eleAddInfo);
//			By eleAddInfoOptions = getDynamicElement(strDropDownOptions, "Additional Information Required");
//			waitAndVerifyElement(eleAddInfoOptions);
//			selectItemFromList(eleAddInfo, eleAddInfoOptions, addInfo, "Additional Information Required");
//			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to enter details of outcome and outcome reason " + e.getMessage());
			Assert.fail("Failed to enter details of outcome and outcome reason " + e.getMessage());
		}

	}

	/**
	 * Function: Enter outcome and outcome reason
	 * 
	 * @author Trupti Zure
	 **/

	public void enterOutcomeAndOutcomeReasonAddInfo(String outcome, String outcomeReason, String addInfo) {
		try {

			// Outcome
			By eleOutcome = getDynamicElement(strDropDownInputBox, "Outcome");
			waitAndVerifyElement(eleOutcome);
			scrollToElement(eleOutcome);
			click(eleOutcome);
			By eleOutcomeOptions = getDynamicElement(strDropDownOptions, "Outcome");
			waitAndVerifyElement(eleOutcomeOptions);
			selectItemFromList(eleOutcome, eleOutcomeOptions, outcome, "Outcome");
			setTimeOut(1000);

			// Outcome Reason
			By eleOutcomeReason = getDynamicElement(strDropDownInputBox, "Outcome Reason");
			waitAndVerifyElement(eleOutcomeReason);
			scrollToElement(eleOutcomeReason);
			click(eleOutcomeReason);
			By eleOutcomeReasonOptions = getDynamicElement(strDropDownOptions, "Outcome Reason");
			waitAndVerifyElement(eleOutcomeReasonOptions);
			selectItemFromList(eleOutcomeReason, eleOutcomeReasonOptions, outcomeReason, "Outcome Reason");
			setTimeOut(1000);

			// Additional Information Required
//			By eleAddInfo = getDynamicElement(strDropDownInputBox, "Additional Information Required");
//			waitAndVerifyElement(eleAddInfo);
//			scrollToElement(eleAddInfo);
//			click(eleAddInfo);
//			By eleAddInfoOptions = getDynamicElement(strDropDownOptions, "Additional Information Required");
//			waitAndVerifyElement(eleAddInfoOptions);
//			selectItemFromList(eleAddInfo, eleAddInfoOptions, addInfo, "Additional Information Required");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to enter details of outcome and outcome reason " + e.getMessage());
			Assert.fail("Failed to enter details of outcome and outcome reason " + e.getMessage());
		}

	}

	/**
	 * Function: Enter mandatory details on PA Approved section
	 * 
	 * @author Trupti Zure
	 **/

	public void enterMandatoryPAApprovedDetails(String effectiveDate, String doseCoverage, String expirationDate) {
		try {
			// Approval #
			By eleApproval = getDynamicElement(strInputBox, "Approval #");
			waitAndVerifyElement(eleApproval);
			scrollToElement(eleApproval);
			inputText(eleApproval, "Test automation approval");

			// PA Effective Date
			By elePAEffectiveDate = getDynamicElement(strInputBox, "PA Effective Date");
			waitAndVerifyElement(elePAEffectiveDate);
			scrollToElement(elePAEffectiveDate);
			inputText(elePAEffectiveDate, effectiveDate);

			// PA dose coverage
			By eleDoseCoverage = getDynamicElement(strDropDownInputBox, "PA dose coverage");
			waitAndVerifyElement(eleDoseCoverage);
			click(eleDoseCoverage);
			By eleDoseCoverageOptions = getDynamicElement(strDropDownOptions, "PA dose coverage");
			waitAndVerifyElement(eleDoseCoverageOptions);
			selectItemFromList(eleDoseCoverage, eleDoseCoverageOptions, doseCoverage, "PA dose coverage");
			setTimeOut(1000);

			// PA Expiration Date
			By elePAExpirationDate = getDynamicElement(strInputBox, "PA Expiration Date");
			waitAndVerifyElement(elePAExpirationDate);
			scrollToElement(elePAExpirationDate);
			inputText(elePAExpirationDate, expirationDate);

		} catch (Exception e) {
			Log.error("Failed to enter details of PA Approved Details " + e.getMessage());
			Assert.fail("Failed to enter details of PA Approved Details " + e.getMessage());
		}
	}

	/**
	 * Function: Enter HCP contact details
	 * 
	 * @author Trupti Zure
	 **/

	public void enterHCPContactDetails(String status, String contactSuccessful, String hcpName, String attempts, String intentOfSub) {
		try {

			// Status
			By eleStatus = getDynamicElement(strDropDownInputBox, "Status");
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			click(eleStatus);
			By eleStatusOptions = getDynamicElement(strDropDownOptions, "Status");
			waitAndVerifyElement(eleStatusOptions);
			selectItemFromList(eleStatus, eleStatusOptions, status, "Status");
			setTimeOut(1000);

			// HCP Contact Successful?
			By eleHCPContactSuccessful = getDynamicElement(strDropDownInputBox, "HCP Contact Successful?");
			waitAndVerifyElement(eleHCPContactSuccessful);
			click(eleHCPContactSuccessful);
			By eleHCPContactSuccessfulOptions = getDynamicElement(strDropDownOptions, "HCP Contact Successful?");
			waitAndVerifyElement(eleHCPContactSuccessfulOptions);
			selectItemFromList(eleHCPContactSuccessful, eleHCPContactSuccessfulOptions, contactSuccessful,
					"HCP Contact Successful?");
			if (contactSuccessful.equalsIgnoreCase("Yes")) {
				// HCP Office Contact Name
				By elehcpContact = getDynamicElement(strInputBox, "HCP Office Contact Name");
				waitAndVerifyElement(elehcpContact);
				scrollToElement(elehcpContact);
				inputText(elehcpContact, hcpName);
			}
			setTimeOut(1000);

			// Attempts
			By eleAttempts = getDynamicElement(strDropDownInputBox, "# Attempts");
			waitAndVerifyElement(eleAttempts);
			scrollToElement(eleAttempts);
			click(eleAttempts);
			By eleAttemptsOptions = getDynamicElement(strDropDownOptions, "# Attempts");
			waitAndVerifyElement(eleAttemptsOptions);
			selectItemFromList(eleAttempts, eleAttemptsOptions, attempts, "# Attempts");
			setTimeOut(1000);

//			// Intent of Submission
//			By eleIntentOfSub = getDynamicElement(strDropDownInputBox, "Intent of Submission");
//			waitAndVerifyElement(eleIntentOfSub);
//			scrollToElement(eleIntentOfSub);
//			click(eleIntentOfSub);
//			By eleIntentOfSubOptions = getDynamicElement(strDropDownOptions, "Intent of Submission");
//			waitAndVerifyElement(eleIntentOfSubOptions);
//			selectItemFromList(eleIntentOfSub, eleIntentOfSubOptions, intentOfSub, "Intent of Submission");
//			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to enter details of PA Approved Details " + e.getMessage());
			Assert.fail("Failed to enter details of PA Approved Details " + e.getMessage());
		}
	}

	
	public void enterHCPContactDetails1(String status, String contactSuccessful, String hcpName) {
		try {

			// Status
			By eleStatus = getDynamicElement(strDropDownInputBox, "Status");
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			click(eleStatus);
			By eleStatusOptions = getDynamicElement(strDropDownOptions, "Status");
			waitAndVerifyElement(eleStatusOptions);
			selectItemFromList(eleStatus, eleStatusOptions, status, "Status");
			setTimeOut(1000);

			// HCP Contact Successful?
			By eleHCPContactSuccessful = getDynamicElement(strDropDownInputBox, "HCP Contact Successful?");
			waitAndVerifyElement(eleHCPContactSuccessful);
			click(eleHCPContactSuccessful);
			By eleHCPContactSuccessfulOptions = getDynamicElement(strDropDownOptions, "HCP Contact Successful?");
			waitAndVerifyElement(eleHCPContactSuccessfulOptions);
			selectItemFromList(eleHCPContactSuccessful, eleHCPContactSuccessfulOptions, contactSuccessful,
					"HCP Contact Successful?");
			if (contactSuccessful.equalsIgnoreCase("Yes")) {
				// HCP Office Contact Name
				By elehcpContact = getDynamicElement(strInputBox, "HCP Office Contact Name");
				waitAndVerifyElement(elehcpContact);
				scrollToElement(elehcpContact);
				inputText(elehcpContact, hcpName);
			}
			setTimeOut(1000);


		} catch (Exception e) {
			Log.error("Failed to enter details of PA Approved Details " + e.getMessage());
			Assert.fail("Failed to enter details of PA Approved Details " + e.getMessage());
		}
	}
	
	
	/**
	 * Function: Enter details in PA Appeals denied section
	 * 
	 * @author Trupti Zure
	 **/
	public void enterPAAppealDeniedDetails(String appeal, String intendedDate, String submissionChannel) {
		try {
			// Proceed with Appeal?
			By eleAppeal = getDynamicElement(strDropDownInputBox, "Proceed with Appeal?");
			waitAndVerifyElement(eleAppeal);
			scrollToElement(eleAppeal);
			click(eleAppeal);
			By eleAppealOptions = getDynamicElement(strDropDownOptions, "Proceed with Appeal?");
			waitAndVerifyElement(eleAppealOptions);
			selectItemFromList(eleAppeal, eleAppealOptions, appeal, "Proceed with Appeal?");
			setTimeOut(1000);

			if (appeal.equalsIgnoreCase("Yes")) {
				// Intended Date of Appeal Submission
				By eleintendedDate = getDynamicElement(strInputBox, "Intended Date of Appeal Submission");
				waitAndVerifyElement(eleintendedDate);
				inputText(eleintendedDate, intendedDate);
			}

			// Appeal Packet Submission Channel
			By elePacketSubmission = getDynamicElement(strDropDownInputBox, "Appeal Packet Submission Channel");
			waitAndVerifyElement(elePacketSubmission);
			click(elePacketSubmission);
			By elePacketSubmissionOptions = getDynamicElement(strDropDownOptions, "Appeal Packet Submission Channel");
			waitAndVerifyElement(elePacketSubmissionOptions);
			selectItemFromList(elePacketSubmission, elePacketSubmissionOptions, submissionChannel,
					"Appeal Packet Submission Channel");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to enter details of PA Appeal Denied " + e.getMessage());
			Assert.fail("Failed to enter details of PA Appeal Denied  " + e.getMessage());
		}
	}

	public void enterPAAppealDeniedDetailsForFirstLevelAppeal(String appeal) {
		try {
			// Proceed with Appeal?
			By eleAppeal = getDynamicElement(strDropDownInputBox, "Proceed with Appeal?");
			waitAndVerifyElement(eleAppeal);
			scrollToElement(eleAppeal);
			click(eleAppeal);
			By eleAppealOptions = getDynamicElement(strDropDownOptions, "Proceed with Appeal?");
			waitAndVerifyElement(eleAppealOptions);
			selectItemFromList(eleAppeal, eleAppealOptions, appeal, "Proceed with Appeal?");
			setTimeOut(1000);

			if (appeal.equalsIgnoreCase("Yes")) {
				// Intended Date of Appeal Submission
				By eleintendedDate = getDynamicElement(strInputBox, "Intended Date of Appeal Submission");
				waitAndVerifyElement(eleintendedDate);
				inputText(eleintendedDate, intendedDate);
			}

		} catch (Exception e) {
			Log.error("Failed to enter details of PA Appeal Denied " + e.getMessage());
			Assert.fail("Failed to enter details of PA Appeal Denied  " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Fields in Follow Up on Results
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validatePAAppealFollowUpResultSection(boolean section) {

		String[] fieldsLabels = { "Status", "# Attempts", "Payer Contact Successful?", "Outcome", "Outcome Reason",
				"HCP Follow Up Required?" };

		try {

			By elePaAppealApproved = getDynamicElement(subTaskSectionButton, "PA/ Appeal Details");
			verifyAnyFieldIsEnabledOrDisabled(elePaAppealApproved, "PA/ Appeal Details", section);
			LoggingInfo("'PA/ Appeal Details' section is enable");
			setTimeOut(2000);

			for (String fieldLabel : fieldsLabels) {
				By fieldLocator = getDynamicElement(strInputBox, fieldLabel);
				verifyAnyFieldIsEnabledOrDisabled(fieldLocator, fieldLabel, section);
				setTimeOut(2000);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate PA/ Appeals Follow up on Results section " + e.getMessage());
		}
	}

	/**
	 * Function: Validate PA Appeal Pending Section
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateHCPFollowUpSection(boolean section) {

		String[] fieldsLabels = { "Status", "# Attempts", "HCP Contact Successful?" };

		try {

			By elePaAppealApproved = getDynamicElement(subTaskSectionButton, "HCP Follow Up Details");
			verifyAnyFieldIsEnabledOrDisabled(elePaAppealApproved, "HCP Follow Up Details", section);
			LoggingInfo("'HCP Follow Up section is enable");
			setTimeOut(2000);

			for (String fieldLabel : fieldsLabels) {
				By fieldLocator = getDynamicElement(strInputBox, fieldLabel);
				verifyAnyFieldIsEnabledOrDisabled(fieldLocator, fieldLabel, section);
				setTimeOut(2000);

			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate HCP Follow Up section " + e.getMessage());
		}
	}

	public void enterHCPFollowUpDetails(String status, String attempts, String hcpcontact) {

		try {

			By eleStatus = getDynamicElement(strPriorAuth, "Status");
			waitAndVerifyElement(eleStatus);
			scrollToElement(eleStatus);
			click(eleStatus);
			By eleStatusDropdown = getDynamicElement(strPriorAuthDropdown, "Status");
			waitAndVerifyElement(eleStatusDropdown);
			selectItemFromDropDown(eleStatus, eleStatusDropdown, status);
			setTimeOut(2000);

			By eleAttempts = getDynamicElement(strPriorAuth, "# Attempts");
			click(eleAttempts);
			waitAndVerifyElement(eleAttempts);
			By eleAttemptsDropdown = getDynamicElement(strPriorAuthDropdown, "# Attempts");
			selectItemFromDropDown(eleAttempts, eleAttemptsDropdown, attempts);
			setTimeOut(2000);

			By eleHCPContact = getDynamicElement(strPriorAuth, "HCP Contact Successful?");
			scrollToElement(eleHCPContact);
			click(eleHCPContact);
			waitAndVerifyElement(eleHCPContact);
			By eleHCPContactDropdown = getDynamicElement(strPriorAuthDropdown, "HCP Contact Successful?");
			waitAndVerifyElement(eleHCPContactDropdown);
			selectItemFromDropDown(eleHCPContact, eleHCPContactDropdown, hcpcontact);
			setTimeOut(2000);

			LoggingInfo("Verified HCP Follow Up section");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify HCP Follow Up Section  " + e.getMessage());
			Assert.fail("Failed to verify HCP Follow Up Section " + ". Error - " + e.getMessage());

		}

	}

	/**
	 * Function: Validate HCP is Task Initiated
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateHCPTaskCreated() {
		try {
			By hcpFollowup = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"HCP Follow Up\"]");
			boolean isPresent = isElementPresent(hcpFollowup);

			if (isPresent) {
				LoggingInfo("HCP Follow up task is created");
			} else {
				LoggingInfo("HCP Follow up task - not found");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate HCP follow up task " + e.getMessage());
		}
	}

	/**
	 * Function: Validate PA required input values
	 * 
	 * @author Trupti Zure
	 **/

	public void validatePARequiredInputValues(String processor, String electronicSite, String phoneNum, String fax) {
		try {
			String[] inputFieldsLabels = { "PA/Appeal processor", "PA/Appeal electronic site",
					"PA/Appeal processor's phone number", "PA/Appeal processor's fax number" };
			String[] inputFieldsValues = { processor, electronicSite, phoneNum, fax };

			for (int i = 0; i < inputFieldsLabels.length; i++) {
				String inputLabel = inputFieldsLabels[i];
				By inputBox = getDynamicElement(strInputBox, inputLabel);
				waitAndVerifyElement(inputBox);
				scrollToElement(inputBox);
				verifyHardAssertInputFieldBox(inputBox, inputFieldsValues[i], inputLabel);
				setTimeOut(1000);

			}
		} catch (Exception e) {
			Log.error("Failed to validate PA Required Pending Values " + e.getMessage());
			Assert.fail("Failed to validate PA Required Pending Values  " + e.getMessage());
		}
	}

	/**
	 * Function: Validate PA required drop down values
	 * 
	 * @author Trupti Zure
	 **/
	public void validatePARequiredDropDownValues(String pendingReason, String additionalDoc, String outcome) {
		try {
			String[] dropDownFieldsLabels = { "Outcome Reason", "Additional documents required", "Outcome" };
			String[] dropDownFieldsValues = { pendingReason, additionalDoc, outcome };

			for (int i = 0; i < dropDownFieldsLabels.length; i++) {
				String dropDownLabel = dropDownFieldsLabels[i];
				By dropDown = getDynamicElement(strDropDownInputBox, dropDownLabel);
				waitAndVerifyElement(dropDown);
				scrollToElement(dropDown);
				verifyHardAssertDropDown(dropDown, dropDownFieldsValues[i], dropDownLabel);
				setTimeOut(1000);

			}
		} catch (Exception e) {
			Log.error("Failed to validate PA Required Pending Values " + e.getMessage());
			Assert.fail("Failed to validate PA Required Pending Values  " + e.getMessage());
		}
	}

	/**
	 * Function: Select drop down value
	 * 
	 * @author Trupti Zure
	 **/
	public void selectDropdownValue(String label, String value) {
		try {
			By dropDown = getDynamicElement(strDropDownInputBox, label);
			waitAndVerifyElement(dropDown);
			scrollToElement(dropDown);
			click(dropDown);
			By dropDownOptions = getDynamicElement(strDropDownOptions, label);
			waitAndVerifyElement(dropDownOptions);
			selectItemFromList(dropDown, dropDownOptions, value, label);
		} catch (Exception e) {
			Log.error("Failed to select dropdown value " + e.getMessage());
			Assert.fail("Failed to select dropdown value-  " + e.getMessage());
		}
	}

	/**
	 * Function: Validate reasons to follow up values
	 * 
	 * @author Trupti Zure
	 **/
	public void validateReasonToFollowUpValues(String pendingReason, String additionalDoc, String outcome) {
		try {
			String[] dropDownFieldsLabels = { "Outcome Reason", "Additional Documents Required", "Outcome" };
			String[] dropDownFieldsValues = { pendingReason, additionalDoc, outcome };

			for (int i = 0; i < dropDownFieldsLabels.length; i++) {
				String dropDownLabel = dropDownFieldsLabels[i];
				By dropDown = getDynamicElement(strDropDownInputBox, dropDownLabel);
				waitAndVerifyElement(dropDown);
				scrollToElement(dropDown);
				verifyHardAssertDropDown(dropDown, dropDownFieldsValues[i], dropDownLabel);
				setTimeOut(1000);

			}
		} catch (Exception e) {
			Log.error("Failed to validate PA Required Pending Values " + e.getMessage());
			Assert.fail("Failed to validate PA Required Pending Values  " + e.getMessage());
		}
	}

	/**
	 * Function: Input value
	 * 
	 * @author Trupti Zure
	 **/
	public void inputValue(String label, String value) {
		try {
			By input = getDynamicElement(strInputBox, label);
			waitAndVerifyElement(input);
			scrollToElement(input);
			inputText(input, value);
		} catch (Exception e) {
			Log.error("Failed to select dropdown value " + e.getMessage());
			Assert.fail("Failed to select dropdown value-  " + e.getMessage());
		}
	}

	/**
	 * Function: Validate outcome and outcome reason
	 * 
	 * @author Trupti Zure
	 **/

	public void validateOutcomeAndOutcomeReason(String outcome, String outcomeReason) {
		try {
			// outcome
			By outcomedropDown = getDynamicElement(strDropDownInputBox, "Outcome");
			waitAndVerifyElement(outcomedropDown);
			scrollToElement(outcomedropDown);
			verifyHardAssertDropDown(outcomedropDown, outcome, "Outcome");

			// OutcomeReason
			By outcomeReasondropDown = getDynamicElement(strDropDownInputBox, "Outcome Reason");
			waitAndVerifyElement(outcomeReasondropDown);
			scrollToElement(outcomeReasondropDown);
			verifyHardAssertDropDown(outcomeReasondropDown, outcomeReason, "Outcome Reason");

		} catch (Exception e) {
			Log.error("Failed to validate Outcome And Outcome Reason" + e.getMessage());
			Assert.fail("Failed to validate Outcome And Outcome Reason-  " + e.getMessage());
		}
	}

	/**
	 * Function: Enter value for drop down box
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyValueOfDropDownBox(String label, String value) {
		try {
			By fieldName = getDynamicElement(strDropDownInputBox, label);
			waitAndVerifyElement(fieldName);
			scrollToElement(fieldName);
			verifyHardAssertDropDown(fieldName, value, label);
		} catch (Exception e) {
			Log.error("Failed to validate Outcome And Outcome Reason" + e.getMessage());
			Assert.fail("Failed to validate Outcome And Outcome Reason-  " + e.getMessage());
		}
	}

	/**
	 * Function: Enter values for PA denial section
	 * 
	 * @author Trupti Zure
	 **/

	public void enterValuesForPADenial(String denialDate, String appeal, String nextStep, String levels,
			String notified) {
		try {

			// Denial Date
			By eleDenialDate = getDynamicElement(strInputBox, "Denial Date");
			waitAndVerifyElement(eleDenialDate);
			scrollToElement(eleDenialDate);
			inputText(eleDenialDate, denialDate);

			String[] dropDownFieldsLabels = { "Provider notified of the denial?", "Appeal needed?",
					"Next steps after denial", "Level of Appeal allowed?" };
			String[] dropDownFieldsValues = { notified, appeal, nextStep, levels };

			for (int i = 0; i < dropDownFieldsLabels.length; i++) {
				String dropDownLabel = dropDownFieldsLabels[i];
				By dropDown = getDynamicElement(strDropDownInputBox, dropDownLabel);
				waitAndVerifyElement(dropDown);
				scrollToElement(dropDown);
				clickByJavascript(dropDown);
				By dropDownOptions = getDynamicElement(strDropDownOptions, dropDownLabel);
				waitAndVerifyElement(dropDownOptions);
				selectItemFromList(dropDown, dropDownOptions, dropDownFieldsValues[i], dropDownLabel);
				setTimeOut(1000);
			}

		} catch (Exception e) {
			Log.error("Failed to enter optional fields" + e.getMessage());
			Assert.fail("Failed to enter optional fields " + e.getMessage());
		}
	}

	/**
	 * Function: Validate values for when PA outcome is selected as Denial
	 * 
	 * @author Trupti Zure
	 **/
	public void validateValuesForPADenial(String denialDate, String appeal, String nextStep, String levels,
			String notified) {
		try {

			// Denial Date
			By eleDenialDate = getDynamicElement(strInputBox, "Denial Date");
			waitAndVerifyElement(eleDenialDate);
			scrollToElement(eleDenialDate);
			verifyHardAssertInputFieldBox(eleDenialDate, denialDate, "Denial Date");

			String[] dropDownFieldsLabels = { "Provider notified of the denial?", "Appeal needed?",
					"Next steps after denial", "Level of Appeal allowed?", };
			String[] dropDownFieldsValues = { notified, appeal, nextStep, levels };

			for (int i = 0; i < dropDownFieldsLabels.length; i++) {
				String dropDownLabel = dropDownFieldsLabels[i];
				By dropDown = getDynamicElement(strDropDownInputBox, dropDownLabel);
				waitAndVerifyElement(dropDown);
				scrollToElement(dropDown);
				verifyHardAssertDropDown(dropDown, dropDownFieldsValues[i], dropDownLabel);
				setTimeOut(1000);
			}

		} catch (Exception e) {
			Log.error("Failed to verify  fields" + e.getMessage());
			Assert.fail("Failed to verify  fields " + e.getMessage());
		}
	}

	/**
	 * Function: Verify drop down value
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyDropdownValue(String label, String value) {
		try {
			By dropDown = getDynamicElement(strDropDownInputBox, label);
			waitAndVerifyElement(dropDown);
			scrollToElement(dropDown);
			verifyHardAssertDropDown(dropDown, value, label);
		} catch (Exception e) {
			Log.error("Failed to select dropdown value " + e.getMessage());
			Assert.fail("Failed to select dropdown value-  " + e.getMessage());
		}
	}

	public void selectPAAppealsService() {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			selectItemFromList(eleSelectDropDown, "PA/ Appeals");
			LoggingInfo("Selected Service as IAP");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Service " + e.getMessage());
			Assert.fail("Failed to select Service " + e.getMessage());
		}
	}

	public void selectPAAppealsReason() {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			String reason = "New Insurance";
			selectItemFromList(eleSelectDropDown, reason);
			LoggingInfo("Selected Reason as-" + reason);
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Reason " + e.getMessage());
			Assert.fail("Failed to select Reason " + e.getMessage());
		}
	}

	/**
	 * Function: Verify input value
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyinputValue(String label, String value) {
		try {
			By input = getDynamicElement(strInputBox, label);
			waitAndVerifyElement(input);
			scrollToElement(input);
			verifyHardAssertInputFieldBox(input, value, label);
		} catch (Exception e) {
			Log.error("Failed to validate input value " + e.getMessage());
			Assert.fail("Failed to validate input value-  " + e.getMessage());
		}
	}

	public void enterHCPFollowUp(String status, String contactSuccessful, String hcpName, String attempt,
			String intentOfSub) {
		try {

			// Status
			By eleStatus = getDynamicElement(strDropDownInputBox, "Status");
			waitAndVerifyElement(eleStatus);
			click(eleStatus);
			By eleStatusOptions = getDynamicElement(strDropDownOptions, "Status");
			waitAndVerifyElement(eleStatusOptions);
			selectItemFromList(eleStatus, eleStatusOptions, status, "Status");
			setTimeOut(1000);

			// HCP Contact Successful?
			By eleHCPContactSuccessful = getDynamicElement(strDropDownInputBox, "HCP Contact Successful?");
			waitAndVerifyElement(eleHCPContactSuccessful);
			click(eleHCPContactSuccessful);
			By eleHCPContactSuccessfulOptions = getDynamicElement(strDropDownOptions, "HCP Contact Successful?");
			waitAndVerifyElement(eleHCPContactSuccessfulOptions);
			selectItemFromList(eleHCPContactSuccessful, eleHCPContactSuccessfulOptions, contactSuccessful,
					"HCP Contact Successful?");
			if (contactSuccessful.equalsIgnoreCase("Yes")) {
				// HCP Office Contact Name
				By elehcpContact = getDynamicElement(strInputBox, "HCP Office Contact Name");
				waitAndVerifyElement(elehcpContact);
				scrollToElement(elehcpContact);
				inputText(elehcpContact, hcpName);
			}

			By eleAttempts = getDynamicElement(strDropDownInputBox, "# Attempts");
			waitAndVerifyElement(eleAttempts);
			scrollToElement(eleAttempts);
			click(eleAttempts);
			By eleAttemptsOptions = getDynamicElement(strDropDownOptions, "# Attempts");
			waitAndVerifyElement(eleAttemptsOptions);
			selectItemFromList(eleAttempts, eleAttemptsOptions, attempt, "# Attempts");
			setTimeOut(1000);

			By eleIntentofSub = getDynamicElement(strPriorAuth, "Intent of Submission");
			click(eleIntentofSub);
			waitAndVerifyElement(eleIntentofSub);
			By eleIntentofSubOptions = getDynamicElement(strPriorAuthDropdown, "Intent of Submission");
			selectItemFromList(eleIntentofSub, eleIntentofSubOptions, intentOfSub, "Intent of Submission");
			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to enter details of HCP Follow up " + e.getMessage());
			Assert.fail("Failed to enter details of HCP Follow up " + e.getMessage());
		}
	}

	public void validateTaskStatus() {
		try {

			waitAndVerifyElement(eleNotStartedStatus);
			setTimeOut(1000);
			LoggingInfo("communicate Results and Send SOB Task status verified");

		} catch (Exception e) {
			Log.error("Failed to verify communicate Results and Send SOB Task " + e.getMessage());
			Assert.fail("Failed to verify communicate Results and Send SOB Task   " + e.getMessage());
		}
	}

	public void enterHCPFollowUp(String hcpSuccessful, String attempts, String hcpName, String intentOfSub,
			String subChannel, String followUpTime, String intendedDate) {
		try {

			// hcpSuccessful
			By eleHCPContact = getDynamicElement(strDropDownInputBox, "HCP Contact Successful?");
			scrollToElement(eleHCPContact);
			click(eleHCPContact);
			waitAndVerifyElement(eleHCPContact);
			By eleHCPContactDropdown = getDynamicElement(strDropDownOptions, "HCP Contact Successful?");
			waitAndVerifyElement(eleHCPContactDropdown);
			selectItemFromList(eleHCPContact, eleHCPContactDropdown, hcpSuccessful, "HCP Contact Successful?");

			// # Attempts
			By eleAttempts = getDynamicElement(strDropDownInputBox, "# Attempts");
			waitAndVerifyElement(eleAttempts);
			click(eleAttempts);
			By eleAttemptsDropdown = getDynamicElement(strDropDownOptions, "# Attempts");
			selectItemFromList(eleAttempts, eleAttemptsDropdown, attempts, "# Attempts");
			setTimeOut(1000);

			// HCP Office Contact Name
			By eleHCPOfficeContact = getDynamicElement(strInputBox, "HCP Office Contact Name");
			waitAndVerifyElement(eleHCPOfficeContact);
			inputText(eleHCPOfficeContact, hcpName);

			// Intent of Submission
			By eleIntentofSub = getDynamicElement(strDropDownInputBox, "Intent of Submission");
			click(eleIntentofSub);
			waitAndVerifyElement(eleIntentofSub);
			By eleIntentofSubOptions = getDynamicElement(strDropDownOptions, "Intent of Submission");
			selectItemFromList(eleIntentofSub, eleIntentofSubOptions, intentOfSub, "Intent of Submission");
			setTimeOut(1000);

			if (intentOfSub.equalsIgnoreCase("Yes")) {
				// Intended Date of Submission
				By eleDateOfSub = getDynamicElement(strInputBox, "Intended Date of Submission");
				waitAndVerifyElement(eleDateOfSub);
				String date = getDate();
				inputText(eleDateOfSub, date);
			}
			// Submission Channel
			By eleSubChannel = getDynamicElement(strDropDownInputBox, "Submission Channel");
			click(eleSubChannel);
			waitAndVerifyElement(eleSubChannel);
			By eleSubChannelOptions = getDynamicElement(strDropDownOptions, "Submission Channel");
			selectItemFromList(eleSubChannel, eleSubChannelOptions, subChannel, "Submission Channel");
			setTimeOut(1000);

			// Next Follow up Time
			if (followUpTime != null) {
				By elefollowUpTime = getDynamicElement(strInputBox, "Next Follow up Time");
				click(elefollowUpTime);
				waitAndVerifyElement(elefollowUpTime);
				By elefollowUpTimeOptions = getDynamicElement(strDropDownOptions, "Next Follow up Time");
				selectItemFromList(eleIntentofSub, elefollowUpTimeOptions, followUpTime, "Next Follow up Time");
				setTimeOut(1000);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter HCP Follow up details  " + e.getMessage());
			Assert.fail("Failed to enter HCP Follow up details " + ". Error - " + e.getMessage());

		}
	}

	public void enterOutcome(String outcome) {
		try {
			// Outcome
			By eleOutcome = getDynamicElement(strDropDownInputBox, "Outcome");
			waitAndVerifyElement(eleOutcome);
			scrollToElement(eleOutcome);
			click(eleOutcome);
			By eleOutcomeOptions = getDynamicElement(strDropDownOptions, "Outcome");
			waitAndVerifyElement(eleOutcomeOptions);
			selectItemFromList(eleOutcome, eleOutcomeOptions, outcome, "Outcome");
			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to enter details of outcome and outcome reason " + e.getMessage());
			Assert.fail("Failed to enter details of outcome and outcome reason " + e.getMessage());
		}

	}

	public void validatePATaskAreNotCreated() {
		try {
			boolean found = true;
			// "Communicate Results and Send SOB"
			By communicateResultTask = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Communicate Results and Send SOB\"]");
			found = isElementPresent(communicateResultTask);
			Assert.assertFalse(found, "Communicate Results and Send SOB task is created");

			// "HCP Follow Up"
			By followupTask = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"HCP Follow Up\"]");
			found = isElementPresent(followupTask);
			Assert.assertFalse(found, "HCP Follow Up is created");

			LoggingInfo("Communicate Results and Send SOB and HCP Follow Up are not created");

		} catch (Exception e) {
			Log.error("Failed to enter details of outcome and outcome reason " + e.getMessage());
			Assert.fail("Failed to enter details of outcome and outcome reason " + e.getMessage());
		}
	}

	/**
	 * Function: Verify status of a subtask
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateStatusOfTask(String taskName, String status) throws Exception {
		By eleStatus = getDynamicElement(strStatus, taskName);
		waitAndVerifyElement(eleStatus);
		scrollToElement(eleStatus);
		String actualStatus = getText(eleStatus);
		if (actualStatus.equalsIgnoreCase(status)) {
			LoggingInfo("Status of " + taskName + " is verified as " + status);
		} else {
			Log.error("Status of " + taskName + " is not verified as " + status);
			Assert.fail("Status of " + taskName + " is not verified as " + status);
		}

	}

	/**
	 * Function: Verify if a subtask is marked as Required
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateTaskRequired(String taskName) {
		By subTaskStatusRequired = getDynamicElement(strTaskRequired, taskName);
		waitAndVerifyElement(subTaskStatusRequired);
		String reqStatus = getText(subTaskStatusRequired);
		// Assert the status of subtask
		Assert.assertEquals(reqStatus, "Required", "Follow up on Results task status required verified");

	}

}
