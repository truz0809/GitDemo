package com.sanofi.selenium.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class LoginPage extends Utility_Function {

	/************* Elements ******************************************/

	public static final By usernameTextbox= By.xpath("//*[@id='username' and @type='email']");
	public static final By passwordTextbox= By.xpath("//*[@id='password' and @type='password']");
	public static final By loginButton= By.xpath("//*[@id='Login' and @type='submit']");
	public static final By ForgotPasswordLink= By.xpath("//a[@id='forgot_password_link']");
	public static final By viewProfileBTN=By.xpath("*//button//span[@class='uiImage']");
	public static final By logOutBTN=By.xpath("*//a[text()='Log Out']");
	public static String User;
	public static String password;

	/****************** Dynamic Locators *****************************************/

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	/**
	 * Function: Login application.
	 * 
	 * @author Dipali Yadav
	 * @param userName
	 * @param password
	 * @return
	 */
	
	public HomePortal userLogin(String strUsername, String strPassword) {

		try {
//			User=strUsername;
//			password=strPassword;
			waitForPageLoaded(); //updated Yuti
			waitAndVerifyElement(usernameTextbox);
			inputText(usernameTextbox, strUsername);
			Log.info("Enter Username is-:" + strUsername);
			waitAndVerifyElement(passwordTextbox);
			inputText(passwordTextbox, strPassword);
			Log.info("Enter Password is-:" + strPassword);
			click(loginButton);
			setTimeOut(2000);
			Log.info("Clicked Login button");
			Assert.assertTrue(true, "Login operation completed");
			LoggingInfo("Login operation completed");
			WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(130));
			wait.until(ExpectedConditions.invisibilityOfElementLocated(loginButton));

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Login unsuccessfull" + ". Error - " + e.getMessage());
			Assert.fail("Login unsuccessfull" + ". Error - " + e.getMessage());
		}

		return GetInstance(HomePortal.class);
	}
	/**
	 * Function: Login application.
	 * 
	 * @author Dipali Yadav
	 * @param userName
	 * @param password
	 * @return
	 */
	
	public HomePortal userAdminLogin(String strUsername, String strPassword) {

		try {
			waitForPageLoaded(); //updated Yuti
			waitAndVerifyElement(usernameTextbox);
			inputText(usernameTextbox, strUsername);
			Log.info("Enter Username is-:" + strUsername);
			waitAndVerifyElement(passwordTextbox);
			inputText(passwordTextbox, strPassword);
			Log.info("Enter Password is-:" + strPassword);
			click(loginButton);
			Log.info("Clicked Login button");
			Assert.assertTrue(true, "Login operation completed");
			LoggingInfo("Login operation completed");
			WebDriverWait wait = new WebDriverWait(getWebDriver(), Duration.ofSeconds(130));
			wait.until(ExpectedConditions.invisibilityOfElementLocated(loginButton));

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Login unsuccessfull" + ". Error - " + e.getMessage());
			Assert.fail("Login unsuccessfull" + ". Error - " + e.getMessage());
		}

		return GetInstance(HomePortal.class);
	}

	/**
	 * Function: Log Out from iCare Connect
	 * @author skumarsahu
	 * @param
	 * @return
	 */
	public void logoutFromiCC() {

		try {
			Log.info("Logging out off iCare");
			setTimeOut(1000);
			waitForPageLoaded();
			waitAndVerifyElement(viewProfileBTN);
			actionClick(viewProfileBTN);
			setTimeOut(3000);
			waitForPresenceOfElementLocated(logOutBTN);
			waitAndVerifyElement(logOutBTN);
			clickByJavascript(logOutBTN);
			LoggingInfo("User logged out successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Log Out operation Failed" + ". Error - " + e.getMessage());
		}
	}

}
