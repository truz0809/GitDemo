package com.sanofi.selenium.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class CopayFlow extends Utility_Function {

	public CopayFlow(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	/************************* Elements *************************/

	public static By eleBVElement = By
			.xpath("(//*[local-name()='svg' and @class='slds-icon' and @data-key='work_type'])[1]");

	public static By eleErrorPopUpCrossButton = By.xpath(
			"//div[@class='modal-header slds-modal__header empty slds-modal__header_empty']//button[@title='Close this window']");
	public static By eleErrorPopUpOkButton = By.xpath("//span[text()=\"OK\"]");
	public static By elecompleteTaskButton = By.xpath("(//*[text()=\"Complete\"])[1]");
	public static By eleMemberPlanList = By.xpath(
			"(//*[text()=\"Member Plan\"]//parent::label//parent::div//following-sibling::div//following-sibling::div//child::ul//child::li)[2]");	
	public static By elePriorAuth = By.xpath("//*[text()=\"Prior Authorization\"]");
	public static By eleCoverageBenefitName = By
			.xpath("(//*[text()=\"Name\"]//parent::label//parent::div//following-sibling::div//child::input)[2]");
	public static By eleSelectDropDown = By.xpath("//*[contains(@class,\"active lafPageHost\")]//select");
	public static By eleMainTaskStatus = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//span[contains(@class,\"status-text\")]");
	public static String taskButton = "(//*[contains(@class,\"active lafPageHost\")]//*[@class=\"slds-section__title\"]//*[text()=\"{0}\"]//parent::div//span)[1]";
	
	/************************* Dynamic Elements *************************/
	public static String strBVStatus = "//*[text()=\"{0}\"]";
	public static String strCopayFieldsdropdown = "//*[text()=\"{0}\"]//parent::div//following-sibling::div//child::input";
	public static String strCopayFieldInput = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//child::input";
	public static String strCopayFieldDropDownList = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//following-sibling::div//child::ul//child::li";
	public static String eleButton = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button)[1]";
	public static String eleButton2 = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button)[2]";
	public static String strCPERecord = "(//*[contains(@class,\"wsTabset oneConsoleTabset\")]//ul[contains(@class,\"tabBarItems\")]//*[contains(@title,\"{0}\")])[1]";
	public static String strDropDownInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::*[contains(@class,\"option-text\")]";
	public static String strInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::input";
	public static String strInputDateBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//input";
	public static String button = "//*[contains(@class,\"active lafPageHost\")]//*[contains(text(),\"{0}\")]//parent::button";
	public static String strInputBox2 = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
    public static String strConsentFields = "//*[text()=\"{0}\"]";
    public static String strSubTaskStatus = "(//*[@class=\"card\"]//*[text()=\"{0}\"]//parent::div//li)[2]";
    
	public void CopayTask() {
		try {

			setTimeOut(5000);
			waitAndVerifyElement(eleBVElement);
			click(eleBVElement);
			LoggingInfo("BV Element selected");

			setTimeOut(2000);
			By eleBVCapture = getDynamicElement(strBVStatus, "BV Capture");
			waitAndVerifyElement(eleBVCapture);
			clickByJavascript(eleBVCapture);
			LoggingInfo("Clicked on BV Capture");

			By eleBVStatusReviewBenefit = getDynamicElement(strBVStatus, "Review and Finalize Benefit");
			waitAndVerifyElement(eleBVStatusReviewBenefit);
			click(eleBVStatusReviewBenefit);
			LoggingInfo("Clicked on Review and Finalize Benefits");

			// setTimeOut(5000);
			// click(eleErrorPopUpCrossButton);
			// setTimeOut(5000);
			// click(eleErrorPopUpOkButton);
			// LoggingInfo("Clear the pop up");

			setTimeOut(3000);

			By elePolicyHolderDOB = getDynamicElement(strCopayFieldsdropdown, "Policyholder DOB");
			scrollToElement(elePolicyHolderDOB);
			waitAndVerifyElement(elePolicyHolderDOB);
			enterText(elePolicyHolderDOB, "05-30-2024", "PolicyHolder DOB");
			LoggingInfo("enter Policyholder DOB");

			By elePlainID = getDynamicElement(strCopayFieldInput, "Plan ID");
			waitAndVerifyElement(elePlainID);
			enterText(elePlainID, "1029289", "Plain ID");
			LoggingInfo("Enter the Plain ID");

			By eleInsuranceAddDate = getDynamicElement(strCopayFieldsdropdown, "Insurance Add Date");
			waitAndVerifyElement(eleInsuranceAddDate);
			enterText(eleInsuranceAddDate, "04-03-2024", "Insurance Add Date");
			LoggingInfo("Enter the Insurance Add Date");

			By elePlanType = getDynamicElement(strCopayFieldInput, "Plan Type");
			By elePlanTypeDropdown = getDynamicElement(strCopayFieldDropDownList, "Plan Type");
			waitAndVerifyElement(elePlanType);
			click(elePlanType);
			selectItemFromList(elePlanType, elePlanTypeDropdown, "Private Commercial", "Plan Type");
			LoggingInfo("Enter the Plain Type");

			By eleSaveButton = getDynamicElement(eleButton, "Save");
			waitAndVerifyElement(eleSaveButton);
			click(eleSaveButton);
			LoggingInfo("Clicked on Save");

			// member plan
			By eleMemberPlan = getDynamicElement(strCopayFieldInput, "Member Plan");
			scrollToElement(eleMemberPlan);
			waitAndVerifyElement(eleMemberPlan);
			click(eleMemberPlan);
			setTimeOut(2000);
			click(eleMemberPlanList);

			// Benefit Coverage Name
			scrollToElement(eleCoverageBenefitName);
			waitAndVerifyElement(eleCoverageBenefitName);
			enterText(eleCoverageBenefitName, "Samarth", "Name");
			LoggingInfo("Enter data for Coverage Benefit Name");

			By elePharmacyDeductible = getDynamicElement(strCopayFieldInput, "Pharmacy Deductible");
			By elePharmacyDeductibleDropdown = getDynamicElement(strCopayFieldDropDownList, "Pharmacy Deductible");
			// waitAndVerifyElement(elePharmacyDeductible);
			click(elePharmacyDeductible);
			selectItemFromList(elePharmacyDeductible, elePharmacyDeductibleDropdown, "YES", "Pharmacy Deductible");
			LoggingInfo("Enter the Pharmacy Deductible");

			By eleCoverageStatus = getDynamicElement(strCopayFieldInput, "Coverage Status");
			By eleCoverageStatusDropdown = getDynamicElement(strCopayFieldDropDownList, "Coverage Status");
			// waitAndVerifyElement(elePharmacyDeductible);
			click(eleCoverageStatus);
			selectItemFromList(eleCoverageStatus, eleCoverageStatusDropdown, "Covered", "Coverage Status");
			LoggingInfo("Enter the Pharmacy Deductible");

			By elePrescriptionServiceID = getDynamicElement(strCopayFieldInput, "Prescription Service ID");
			waitAndVerifyElement(elePrescriptionServiceID);
			enterText(elePrescriptionServiceID, "ID303", "Prescription Service ID");
			LoggingInfo("Enter the Prescription Service ID");

			By elePatientMedicarePart = getDynamicElement(strCopayFieldInput, "Patient has Medicare Part D? (Y/N)");
			By elePatientMedicarePartDropdown = getDynamicElement(strCopayFieldDropDownList,
					"Patient has Medicare Part D? (Y/N)");
			// waitAndVerifyElement(elePharmacyDeductible);
			click(elePatientMedicarePart);
			selectItemFromList(elePatientMedicarePart, elePatientMedicarePartDropdown, "YES",
					"Patient has Medicare Part D? (Y/N)");
			LoggingInfo("Enter the Patient has Medicare Part D? (Y/N)");

			By elePArequired = getDynamicElement(strCopayFieldInput, "PA required?");
			By elePArequiredDropdown = getDynamicElement(strCopayFieldDropDownList, "PA required?");
			// waitAndVerifyElement(elePharmacyDeductible);
			click(elePArequired);
			selectItemFromList(elePArequired, elePArequiredDropdown, "YES", "PA required?");
			LoggingInfo("Enter the PA required");

			click(elePriorAuth);
			By elePriorAuthorization = getDynamicElement(strCopayFieldInput, "PA Outcome");
			By elePriorAuthorizationDropdown = getDynamicElement(strCopayFieldDropDownList, "PA Outcome");
			// waitAndVerifyElement(elePharmacyDeductible);
			click(elePriorAuthorization);
			selectItemFromList(elePriorAuthorization, elePriorAuthorizationDropdown, "Not on File", "PA Outcome");
			LoggingInfo("Enter the PA Outcome");

			setTimeOut(2000);
			By eleSaveButton2 = getDynamicElement(eleButton2, "Save");
			waitAndVerifyElement(eleSaveButton2);
			click(eleSaveButton2);
			LoggingInfo("Clicked on Save");

			setTimeOut(3000);
			waitAndVerifyElement(elecompleteTaskButton);
			click(elecompleteTaskButton);
			LoggingInfo("Clicked on Complete");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed search record" + e.getMessage());

		}
	}

	public void navigateToCPERecord(String patientName) {
		try {
			By cpeRecord = getDynamicElement(strCPERecord, patientName);
			waitAndVerifyElement(cpeRecord);
			scrollToElement(cpeRecord);
			click(cpeRecord);
			setTimeOut(2000);
			LoggingInfo("Navigated to Care program enrollee record");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to navigate to CPE record-" + e.getMessage());
			Assert.fail("Failed to navigate to CPE record-" + e.getMessage());
		}
	}

	public void checkCopayIntiation() {
		try {
			setTimeOut(3000);
			By copayStartButton = getDynamicElement(eleButton, "Copay");
			waitAndVerifyElement(copayStartButton);
			scrollToElement(copayStartButton);
			click(copayStartButton);
			String buttonState = getAttributeValue(copayStartButton, "aria-pressed");
			// Assert the state of the button
			Assert.assertEquals(buttonState, "true", "Copay flow is initialized");
			LoggingInfo("Copay flow is initialized");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to check the status of Copay intiation " + e.getMessage());
			Assert.fail("Failed to check the status of Copay intiation " + e.getMessage());
		}
	}

	/**
	 * Function:enter Eligibility Criteria
	 * 
	 * @author Trupti
	 **/
	public void enterEligibilityCriteria() {
		String[] dropdownLabels = { "Private commercial insurance?", "Patient resides in US/PR?", "HCP in US/PR?",
				"FDA approved indication?", "Consent to enroll in Program/ Copay", "Text opt in?" };
		try {
			for (String dropdownLabel : dropdownLabels) {
				By dropdownInputBox = getDynamicElement(strDropDownInputBox, dropdownLabel);
				waitAndVerifyElement(dropdownInputBox);
				scrollToElement(dropdownInputBox);
				click(dropdownInputBox);
				By dropdownOptions = getDynamicElement(strDropDownOptions, dropdownLabel);
				waitAndVerifyElement(dropdownOptions);
				selectItemFromList(dropdownInputBox, dropdownOptions, "Yes", dropdownLabel);
				LoggingInfo("Selected " + dropdownLabel + " as- Yes");
				setTimeOut(3000);
			}
		} catch (Exception e) {
			Log.error("Failed enter Eligibility Criteria- " + e.getMessage());
			Assert.fail("Failed enter Eligibility Criteria- " + e.getMessage());
		}
	}

	/**
	 * Function:enter Request outcome
	 * 
	 * @author Trupti
	 **/

	public void enterRequestOutcome(String outcome, String outcomeDate) {
		try {
			// Outcome
			By outcomeBox = getDynamicElement(strDropDownInputBox, "Outcome");
			waitAndVerifyElement(outcomeBox);
			verifyHardAssertDropDown(outcomeBox, outcome, "Outcome");

			// Outcome date
			By outcomeDateBox = getDynamicElement(strInputDateBox, "Outcome Date");
			waitAndVerifyElement(outcomeDateBox);
			verifyHardAssertCalendarDate(outcomeDateBox, outcomeDate, "Outcome Date");

			// Card Number
			By cardnumInputBox = getDynamicElement(strInputBox2, "Card Number");
			String value = getAttributeValue(cardnumInputBox, "value");
			boolean verifyValue = !value.isEmpty();
			Assert.assertTrue(verifyValue, "-is not empty");
			LoggingInfo("Card detail is not empty");

		} catch (Exception e) {
			Log.error("Failed enter Request Outcome- " + e.getMessage());
			Assert.fail("Failed enter Request Outcome- " + e.getMessage());
		}
	}
	
	/**
	 * Function: Validate Workorder status
	 * 
	 * @author  Shanavaz Nishani
	 **/
	public void verifyWorkOrderStatus(String WOname, String status) throws Exception {
		String strWO = "//*[contains(@class,\"active lafPageHost\")]//button[@title=\"{0}\"]//child::div[@role=\"progressbar\"]";
		By ele = getDynamicElement(strWO, WOname);
		scrollToElement(ele);
		String actualStatus = getAttributeValue(ele, "title");
		if (actualStatus.equalsIgnoreCase(status)) {
			LoggingInfo(WOname + " is in expected status " + status);

		} else {
			Assert.fail(WOname + " is not as expected status " + status);
			LoggingInfo(WOname + " is not as expected status " + status);
		}

	}

	/**
	 * Function: check status of work order i.e Completed , in progress
	 * 
	 * @author Trupti Zure
	 **/
	public void checkCPEWorkOrderData(String careProduct, String patientName, List<String> workOrders, String status) {
		careProduct = careProduct.split(" -")[0];
		By tableRows = By.xpath(
				"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-border_left\")]//*[@class=\"slds-data-table-row tableRow\"]");

		ArrayList<String> allData = getWorkTableData(tableRows, "CareProgrameeEnrolleeName", "Name", "Status");
//		logData("Actual Data:", allData);

		ArrayList<String> expectedData = new ArrayList<>();
		for (String workOrder : workOrders) {
			expectedData.add(patientName + " - " + careProduct + ", " + workOrder + ", " + status);
		}
//		logData("Expected Data:", expectedData);

		boolean allExpectedFound = true;
		for (String expected : expectedData) {
			if (!allData.contains(expected)) {
				allExpectedFound = false;
				break;
			}
		}
		if (!allExpectedFound) {
			throw new AssertionError("Not all expected data is present in allData.");
		}
	}

	/**
	 * Function: Select service
	 * 
	 * @author Trupti Zure
	 **/

	public void selectService(String serviceName) {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			selectItemFromList(eleSelectDropDown, serviceName);
			LoggingInfo("Selected Service as -" + serviceName);
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Service " + e.getMessage());
			Assert.fail("Failed to select Service " + e.getMessage());
		}
	}

	/**
	 * Function: Select reason
	 * 
	 * @author Trupti Zure
	 **/
	public void selectReason(String reason) {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			selectItemFromList(eleSelectDropDown, reason);
			LoggingInfo("Selected Reason as-" + reason);
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Reason " + e.getMessage());
			Assert.fail("Failed to select Reason " + e.getMessage());
		}
	}

	/**
	 * Function:Verify review outcome screen is visible
	 * 
	 * @author Trupti
	 **/
	public boolean verifyReviewOutcomeScreen() {
		boolean screenFound = false;
		try {
			Log.info("Verify review outcome screen is visible");

			By reviewOutcomeScreen = By
					.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Request Outcome\"]");
			if (isElementPresent(reviewOutcomeScreen)) {
				screenFound = true;
			}

		} catch (Exception e) {
			Log.error("Failed to select Reason " + e.getMessage());
			Assert.fail("Failed to select Re,ason " + e.getMessage());
		}
		return screenFound;
	}

	/**
	 * Function:enter outcome details
	 * 
	 * @author Trupti
	 **/
	public void enterOutcomeDetails(String outcome, String date) {
		try {
			Log.info("Enter outcome and outcome details");

			// "Outcome"
			By outcomeBox = getDynamicElement(strDropDownInputBox, "Outcome");
			waitAndVerifyElement(outcomeBox);
			scrollToElement(outcomeBox);
			click(outcomeBox);

			By outcomeOptions = getDynamicElement(strDropDownOptions, "Outcome");
			waitAndVerifyElement(outcomeOptions);
			selectItemFromList(outcomeBox, outcomeOptions, outcome, "Outcome");

			// OutcomeDate
			By outcomeDateField = getDynamicElement(strInputDateBox, "Outcome Date");
			waitAndVerifyElement(outcomeDateField);
			inputText(outcomeDateField, date);

			LoggingInfo("Entered outcome and outcome date");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Re Assess Button " + e.getMessage());
			Assert.fail("Failed to click on Re Assess Button " + e.getMessage());
		}
	}

	/**
	 * Function: Click on re assess button
	 * 
	 * @author Trupti
	 **/
	public void clickOnReAssessButton() {
		try {
			Log.info("Verify user is able to click on Re Assess button");
			By eleReAssessButton = getDynamicElement(button, "Re Assess");
			waitAndVerifyElement(eleReAssessButton);
			scrollToElement(eleReAssessButton);
			click(eleReAssessButton);
			setTimeOut(2000);
			LoggingInfo("User clicks on Re Assess button");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Re Assess Button " + e.getMessage());
			Assert.fail("Failed to click on Re Assess Button " + e.getMessage());
		}
	}

	/**
	 * Function:Click on finish button
	 * 
	 * @author Trupti
	 **/
	public void clickOnFinishButton() {
		try {
			Log.info("Verify user is able to click on Finish button");
			By eleFinishButton = getDynamicElement(button, "Finish");
			waitAndVerifyElement(eleFinishButton);
			scrollToElement(eleFinishButton);
			click(eleFinishButton);
			setTimeOut(2000);
			LoggingInfo("User clicks on Finish button");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on Finish Button " + e.getMessage());
			Assert.fail("Failed to click on Finish Button " + e.getMessage());
		}
	}
	
	/**
	 * Function: Validate Consent to enroll in Copay field
	 * 
	 * @author Sonica P
	 **/
	public void validateConsentCopayField() {
		try {
			Log.info("Verify Consent to enroll in Copay field is present");
			By consentEnrollField = getDynamicElement(strConsentFields, "Consent to enroll in Copay?");
			scrollToElement(consentEnrollField);
			waitAndVerifyElement(consentEnrollField);
			LoggingInfo("User is able to verify Consent to enroll in Copay field");
		}catch(Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Consent to enroll in Copay field" + e.getMessage());
			Assert.fail("Failed to click Consent to enroll in Copay field" + e.getMessage());
		}
	}
	
	/**
	 * Function: Validate Request Outcome fields
	 * 
	 * @author Sonica P
	 **/
	public void validateRequestOutcomeFields() {
		try {
			By outcome = getDynamicElement(strConsentFields, "Outcome");
			waitAndVerifyElement(outcome);
			
			By outcomeDate = getDynamicElement(strConsentFields, "Outcome Date");
			waitAndVerifyElement(outcomeDate);
			
			By cardNumber = getDynamicElement(strConsentFields, "Card Number");
			waitAndVerifyElement(cardNumber);
			LoggingInfo("User is able to verify request outcome fields");
		}catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Request Outcome fields" + e.getMessage());
			Assert.fail("Failed to verify Request Outcome fields" + e.getMessage());
		}
	}
	
	/**
	 * Function:Check Copay Main task completion
	 * 
	 * @author Shraddha
	 **/

	public boolean checkCopayMainTaskCompletion() {
		try {
			waitAndVerifyElement(eleMainTaskStatus);
			String mainTaskStatus = getText(eleMainTaskStatus);
			if(mainTaskStatus.equalsIgnoreCase("Done")){
				Log.info("Copay task completed successfully");
				return true;
			}else {
				Log.info("Copay task not completed successfully");
				return false;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to check Copay Task Completion " + e.getMessage());
			Assert.fail("Failed to check Copay Task Completion " + e.getMessage());
		}
		return true;
	}

}
