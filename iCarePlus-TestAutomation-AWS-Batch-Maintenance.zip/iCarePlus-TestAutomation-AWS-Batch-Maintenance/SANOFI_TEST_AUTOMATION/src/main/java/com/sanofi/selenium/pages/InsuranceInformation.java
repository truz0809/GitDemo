package com.sanofi.selenium.pages;

import java.util.List;
import java.util.Random;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.sanofi.selenium.constants.TestData;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class InsuranceInformation extends Utility_Function implements TestData {
	Random random = new Random();
	String Source;
	String[] firstNames = TestData.firstNames;
	String[] lastNames = TestData.lastNames;
	String firstName = firstNames[random.nextInt(firstNames.length)];
	String lastName = lastNames[random.nextInt(lastNames.length)];

	// Static Elements****************/

	public static By elePrimaryRxPhone = By
			.xpath("(//*[text()=\"Phone\"]//parent::label//parent::div//following-sibling::div//input)[1]");

	public static By elePrimaryRxPolicyID1 = By
			.xpath("(//*[text()=\"Policy ID #\"]//parent::label//parent::div//following-sibling::div//input)[1]");

	public static By elePrimaryRxGroup = By
			.xpath("(//*[text()=\"Group #\"]//parent::label//parent::div//following-sibling::div//input)[1]");

	public static By elePrimaryRxPayerName = By.xpath(
			"(//*[contains(@class,'active lafPageHost')]//*[text()='Payer Name']//ancestor::runtime_omnistudio_omniscript-omniscript-text-block//following-sibling::runtime_omnistudio_omniscript-omniscript-text//runtime_omnistudio_common-input//following-sibling::div//input)[1]");

	public static By elePrimaryMedicalPhone = By
			.xpath("(//*[text()=\"Phone\"]//parent::label//parent::div//following-sibling::div//input)[2]");

	public static By elePrimaryMedicalPolicyID = By
			.xpath("(//*[text()=\"Policy ID #\"]//parent::label//parent::div//following-sibling::div//input)[2]");

	public static By elePrimaryMedicalGroup = By
			.xpath("(//*[text()=\"Group #\"]//parent::label//parent::div//following-sibling::div//input)[2]");

	public static By elePrimaryMedicalPayerName = By.xpath(
			"(//*[contains(@class,'active lafPageHost')]//*[text()='Payer Name']//ancestor::runtime_omnistudio_omniscript-omniscript-text-block//following-sibling::runtime_omnistudio_omniscript-omniscript-text//runtime_omnistudio_common-input//following-sibling::div//input)[2]");

	public static By eleBVPrefferedSP = By
			.xpath("//*[contains(@class,'active lafPageHost')]//*[text()='Preferred Specialty Pharmacy']");

	public static String eleSaveForLater = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button";

	public static By elePreferedSpecialtyPharmChkbox = By.xpath(
			"//*[contains(@class,'active lafPageHost')]//input[@type='checkbox']//parent::div//span[text()='Preferred Specialty Pharmacy']//preceding-sibling::span");

	public static By eleBVPhone = By
			.xpath("(//*[text()=\"Phone\"]//parent::label//parent::div//following-sibling::div//input)[3]");

	public static By eleDupixentChkbox = By.xpath("//span[text()='DUPIXENT MyWay']//preceding-sibling::span");

	public static By elePageTitle = By.xpath(
			"//*[contains(@class,'active lafPageHost')]//*[contains(@class,\"omniscript-body\")]//*[text()=\"Insurance Information\"]");
	public static By elePharmacySource = By.xpath(
			"(//*[text()='TestAutomation Payer Pharmacy']//ancestor::td//following-sibling::*[@data-label='Source System'])[1]");
	public static By eleMedicalSource = By.xpath(
			"(//*[text()='TestAutomation Payer Medical']//ancestor::td//following-sibling::*[@data-label='Source System'])[1]");
	public static By eleSPSource = By.xpath(
			"(//*[text()='Automation Specialty Pharmacy']//ancestor::td//following-sibling::*[@data-label='Source System'])[1]");
	public static String icareplusRecordsRadioBox2 = "(//*[contains(@class,\"active lafPageHost\")]//td[@data-cell-value=\"{0}\"]//preceding-sibling::th//child::button)[2]";

	public static By eleSelectPharmacyPayer = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[lightning-base-formatted-text=\"TestAutomation Payer Pharmacy\"]//parent::div//parent::span//parent::lightning-primitive-cell-factory//parent::td//preceding-sibling::th//lightning-primitive-cell-factory//button)[1]");
	public static By eleSelectMedicalPayer = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[lightning-base-formatted-text=\"TestAutomation Payer Medical\"]//parent::div//parent::span//parent::lightning-primitive-cell-factory//parent::td//preceding-sibling::th//lightning-primitive-cell-factory//button)[1]");

	/************* Dynamic Elements ******************************************/

	public static String strDropdown = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//child::input";
	public static String strInputField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::*//input";
	public static String prevNextButtons = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"omniscript-button-position\")]//*[text()=\"{0}\"]//parent::button";
	public static String strdropDownXpath = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::*//input";
	public static String strPayerName = "//*[contains(@class,\"active lafPageHost\")]//*[@data-omni-key=\"{0}\"]//input[1]";
	public static String strPayerSearch = "//*[contains(@class,\"active lafPageHost\")]//*[@data-omni-key=\"{0}\"]/following::button[1]";
	public static String strPayerRadio = "(//*[contains(@class,\"active lafPageHost\")]//*[@data-omni-key=\"{0}\"]//ancestor::div[@class=\"slds-accordion\"]//label[@class=\"slds-radio__label\"])[1]";
	public static String elePrevNextButtons = "//*[contains(@class,\"omniscript-button-position\")]//*[text()=\"{0}\"]";
	public static String checkBox = "//*[contains(@class,\"active lafPageHost\")]//*[@data-omni-key=\"{0}\"]//input";
	public static String eleRelationlist = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//child::span//child::span";
	public static String payerRadioBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::tbody//span[contains(@class,\"slds-grid_align-spread\")]";
	public static String icareplusRecordsRadioBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::tr//lightning-button//button[@title=\"Select\"]";
	public static String accredoRadioBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Accredo Health Group, Inc\"]//ancestor::tbody//td[@data-cell-value=\"8445163319\"]//ancestor::tr//span[contains(@class,\"slds-grid_align-spread\")]";
	public static String walsgreenRadioBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Walgreen Co\"]//ancestor::tbody//td[@data-cell-value=\"1234567890\"]//ancestor::tr//span[contains(@class,\"slds-grid_align-spread\")]";
	public static String cvsRadioBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"CVS\"]//ancestor::tbody//td[@data-cell-value=\"1234567890\"]//ancestor::tr//span[contains(@class,\"slds-grid_align-spread\")]";
	public static String optumRadioBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Optum\"]//ancestor::tbody//td[@data-cell-value=\"1234567890\"]//ancestor::tr//span[contains(@class,\"slds-grid_align-spread\")]";
	public static String centerWellRadioBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"CenterWell\"]//ancestor::tbody//td[@data-cell-value=\"4312438324\"]//ancestor::tr//span[contains(@class,\"slds-grid_align-spread\")]";
	public static String senderraRadioBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Senderra\"]//ancestor::tbody//td[@data-cell-value=\"1231423425\"]//ancestor::tr//span[contains(@class,\"slds-grid_align-spread\")]";
	public static String correspondenceRadioBox = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Automation Correspondence SP\"]//ancestor::tbody//td[@data-cell-value=\"ICARE+\"]//ancestor::tr//span[contains(@class,\"slds-grid_align-spread\")])[1]";
	public static String elixirRadioBox = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Elixir Pharmacy\"]//ancestor::tbody//span[contains(@class,\"slds-grid_align-spread\")]//button)[1]";
	public static String strDropDownXpath = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String dropDownOptions = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]";
	public static String strAccountObjectDetails = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"label-inline\")]//lightning-formatted-text";
	public static String strSelectButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::tbody//*[@title=\"Select\"]";

	public InsuranceInformation(WebDriver driver) {
		super(driver);

	}

	public void verifyInsuranceInfoPageTitle() {
		try {
			setTimeOut(5000);
			waitForPageLoaded();
			Log.info("Verify Insurance Information Page Present");
			waitAndVerifyElement(elePageTitle);
			LoggingInfo("Insurance Information Page is loaded");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Page load has Failed" + ". Error - " + e.getMessage());

		}
	}

	
	/*
	 * @Author - Anand Pawar
	 */
	public void clickOnSaveForLater() {
		try {
			By saveForLater = getDynamicElement(eleSaveForLater, "Save for later");
			waitAndVerifyElement(saveForLater);
			scrollToElement(saveForLater);
			click(saveForLater);
			Log.info("Clicked on save for later Button");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click" + "Error - " + e.getMessage());
		}
	}
	/*
	 * @Author - Anand Pawar
	 */
	public void clickOnOK() {
		try {
			By okBtn = By.xpath("//button[text()=\"OK\"]");
			waitAndVerifyElement(okBtn);
			scrollToElement(okBtn);
			click(okBtn);
			Log.info("Clicked on Ok  Button");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click" + "Error - " + e.getMessage());
		}
	}
	
	public void clickOnLink() {
		try {
			By link = By.xpath("//*[text()=\"To resume, please click or bookmark the following link\"]//parent::div//child::a");
			waitAndVerifyElement(link);
			scrollToElement(link);
			click(link);
			Log.info("Clicked on Omni Link  Button");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click" + "Error - " + e.getMessage());
		}
	}
	
	/*
	 * @Author - Anand Pawar
	 */
	public void switchToOmniLink() {
		try {
			
	        String originalWindow = getWebDriver().getWindowHandle();

	        clickOnLink();
	        
	        // Step 4: Wait for the new window and switch to it
	        Set<String> allWindows = getWebDriver().getWindowHandles();

	        for (String windowHandle : allWindows) {
	            if (!windowHandle.equals(originalWindow)) {
	                getWebDriver().switchTo().window(windowHandle);
	                break;
	            }
	        }

	        //Close the original window
	        getWebDriver().switchTo().window(originalWindow);
	        getWebDriver().close(); // Closes the old window
	        
	        
	        for (String windowHandle : getWebDriver().getWindowHandles()) {
	        	getWebDriver().switchTo().window(windowHandle);
	            break;
	        }

			Log.info("Navigated to Link");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click" + "Error - " + e.getMessage());
		}
	}
	public void verifyRxInsuranceInfo(String noInsurance, String PrimaryRxInsPhn, String PrimaryRxInsPolicyID,
			String PrimaryRxInsGroup, String PrimaryRxInsRxBIN, String PrimaryRxInsRxPCN) {
		try {

			Log.info("Verify Rx Insurance Information details");

			waitAndVerifyElement(elePrimaryRxPhone);
			verifyHardAssertInputFieldBox(elePrimaryRxPhone, PrimaryRxInsPhn, rxPhone);

			waitAndVerifyElement(elePrimaryRxPolicyID1);
			verifyHardAssertInputFieldBox(elePrimaryRxPolicyID1, PrimaryRxInsPolicyID, rxPolicyID);

			waitAndVerifyElement(elePrimaryRxGroup);
			verifyHardAssertInputFieldBox(elePrimaryRxGroup, PrimaryRxInsGroup, rxGroup);

			By elePrimaryRxBIN = getDynamicElement(strInputField, "Rx BIN #");
			waitAndVerifyElement(elePrimaryRxBIN);
			verifyHardAssertInputFieldBox(elePrimaryRxBIN, PrimaryRxInsRxBIN, rxBIN);

			By elePrimaryRxPCN = getDynamicElement(strInputField, "Rx PCN #");
			waitAndVerifyElement(elePrimaryRxPCN);
			verifyHardAssertInputFieldBox(elePrimaryRxPCN, PrimaryRxInsRxPCN, rxPCN);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Rx insurance verification has failed" + ". Error - " + e.getMessage());
		}

	}

	public void enterRxInsuranceInfo(String noInsurance, String PrimaryRxInsPhn, String PrimaryRxInsPolicyID,
			String PrimaryRxInsGroup, String PrimaryRxInsRxBIN, String PrimaryRxInsRxPCN) {
		try {

			Log.info("Verify Rx Insurance Information details");

			waitAndVerifyElement(elePrimaryRxPhone);
			// click(elePrimaryRxPhone);
			verifyAndInputTextWithActionClass(elePrimaryRxPhone, PrimaryRxInsPhn);

			waitAndVerifyElement(elePrimaryRxPolicyID1);
			verifyAndEnterInfoInputField(elePrimaryRxPolicyID1, PrimaryRxInsPolicyID, rxPolicyID);

			waitAndVerifyElement(elePrimaryRxGroup);
			verifyAndEnterInfoInputField(elePrimaryRxGroup, PrimaryRxInsGroup, rxGroup);

			By elePrimaryRxBIN = getDynamicElement(strInputField, "Rx BIN #");
			waitAndVerifyElement(elePrimaryRxBIN);
			verifyAndEnterInfoInputField(elePrimaryRxBIN, PrimaryRxInsRxBIN, rxBIN);

			By elePrimaryRxPCN = getDynamicElement(strInputField, "Rx PCN #");
			waitAndVerifyElement(elePrimaryRxPCN);
			verifyAndEnterInfoInputField(elePrimaryRxPCN, PrimaryRxInsRxPCN, rxPCN);

			LoggingInfo("Pharmacy RX insurance information has been entered/verified successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Rx insurance verification has failed" + ". Error - " + e.getMessage());
		}

	}

	public void selectPayerPharmacy() {
		try {

			Log.info("Select payer pharmacy record");
			setTimeOut(2000);
			selectPayerInfo("TestAutomation Payer Pharmacy", "iccRxPayerName");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select pharamcy record" + ". Error - " + e.getMessage());
		}
	}

	public void verifyMedicalInsuranceInfo(String PrimaryMedicalPhn, String PrimaryMedicalPolicID,
			String PrimaryMedicalGrp, String PrimaryPolicyholderNm, String relationToPatient) {
		try {
			Log.info("Verify Medical Insurance Information details");
			waitAndVerifyElement(elePrimaryMedicalPhone);
			scrollToElement(elePrimaryMedicalPhone);
			verifyHardAssertInputFieldBox(elePrimaryMedicalPhone, PrimaryMedicalPhn, medicalPhone);

			waitAndVerifyElement(elePrimaryMedicalPolicyID);
			verifyHardAssertInputFieldBox(elePrimaryMedicalPolicyID, PrimaryMedicalPolicID, medicalPolicyID);

			waitAndVerifyElement(elePrimaryMedicalGroup);
			verifySoftAssertInputFieldBox(elePrimaryMedicalGroup, PrimaryMedicalGrp, medicalGroup);

			By elePrimaryMedicalPolicyHolderName = getDynamicElement(strInputField, "Policyholder Name");
			waitAndVerifyElement(elePrimaryMedicalPolicyHolderName);
			verifyHardAssertInputFieldBox(elePrimaryMedicalPolicyHolderName, PrimaryPolicyholderNm, policyholderName);

			By eleRelationshipToPatientInput = getDynamicElement(strdropDownXpath, "Relationship to Patient");
			waitAndVerifyElement(eleRelationshipToPatientInput);
			verifyHardAssertDropDown(eleRelationshipToPatientInput, relationToPatient, legalrelationship);

		} catch (

		Exception e) {
			e.printStackTrace();
			Assert.fail("Medical insurance verification has failed" + ". Error - " + e.getMessage());
		}
	}

	public void enterMedicalInsuranceInfo(String PrimaryMedicalPhn, String PrimaryMedicalPolicID,
			String PrimaryMedicalGrp, String PrimaryPolicyholderNm, String relationToPatient) {
		try {
			Log.info("Verify Medical Insurance Information details");
			waitAndVerifyElement(elePrimaryMedicalPhone);
			scrollToElement(elePrimaryMedicalPhone);
			// click(elePrimaryMedicalPhone);
			verifyAndInputTextWithActionClass(elePrimaryMedicalPhone, PrimaryMedicalPhn);

			waitAndVerifyElement(elePrimaryMedicalPolicyID);
			verifyAndEnterInfoInputField(elePrimaryMedicalPolicyID, PrimaryMedicalPolicID, medicalPolicyID);

			waitAndVerifyElement(elePrimaryMedicalGroup);
			verifyAndEnterInfoInputField(elePrimaryMedicalGroup, PrimaryMedicalGrp, medicalGroup);

			By elePrimaryMedicalPolicyHolderName = getDynamicElement(strInputField, "Policyholder Name");
			waitAndVerifyElement(elePrimaryMedicalPolicyHolderName);
			scrollToElement(elePrimaryMedicalPolicyHolderName);
			verifyAndEnterInfoInputField(elePrimaryMedicalPolicyHolderName, PrimaryPolicyholderNm, policyholderName);

			By eleRelationshipToPatientInput = getDynamicElement(strdropDownXpath, "Relationship to Patient");
			waitAndVerifyElement(eleRelationshipToPatientInput);
			String relation = getAttributeValue(eleRelationshipToPatientInput, "value");
			if (relation.equalsIgnoreCase(relationToPatient)) {
				click(eleRelationshipToPatientInput);
				By eleRelationshipToPatientList = getDynamicElement(eleRelationlist, "Relationship to Patient");
				selectItemFromList(eleRelationshipToPatientInput, eleRelationshipToPatientList, relationToPatient,
						legalrelationship);
			} else {
				highLightElement(eleRelationshipToPatientInput);
				Log.info("Actual text " + relation + " matches with expected text " + relationToPatient);

			}
			LoggingInfo("Medical insurance information has been entered/verified successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Medical insurance verification has failed" + ". Error - " + e.getMessage());
		}
	}

	public void selectMedicalPayer() {
		try {
			Log.info("Select medical payer record");
			setTimeOut(2000);
			selectPayerInfo("TestAutomation Payer Medical", "iccMedicalPayerName");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select medical payer record" + ". Error - " + e.getMessage());
		}
	}

	public void selectSpecialtyPharmacy() {
		try {
			Log.info("Select specialty pharamcy record");
			setTimeOut(2000);
			selectPayerInfo("20th Medical Support", "iccSPName");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select speciality pharmacy record" + ". Error - " + e.getMessage());
		}
	}

	public void verifySpecialtyPharmacyInformation(String preferredSP, String BVphn, String BVfx, String dupixent) {
		try {

			Log.info("Verify specialty pharamcy information");

			By preferredSPCheckbox = getDynamicElement(checkBox, "iccPreferredSP");
			waitAndVerifyElement(preferredSPCheckbox);
			verifySoftAssertCheckBox(preferredSPCheckbox, preferredSP, "Preferred Specialty Pharmacy");

			waitAndVerifyElement(eleBVPhone);
			scrollToElement(eleBVPhone);
			verifyHardAssertInputFieldBox(eleBVPhone, BVphn, pharmacyPhone);

			By eleBVFax = getDynamicElement(strInputField, "Fax");
			waitAndVerifyElement(eleBVFax);
			verifySoftAssertInputFieldBox(eleBVFax, BVfx, pharmacyfax);

			By dupixentCheckbox = getDynamicElement(checkBox, "Dupixent_MyWay");
			waitAndVerifyElement(dupixentCheckbox);
			verifySoftAssertCheckBox(dupixentCheckbox, dupixent, "Dupixent_MyWay CheckBox");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify specialty pharamcy information " + ". Error - " + e.getMessage());
		}
	}

	public void enterSpecialtyPharmacyInformation(String preferredSP, String BVphn, String BVfx, String dupixent) {
		try {

			Log.info("Verify specialty pharamcy information");

			waitAndVerifyElement(eleBVPhone);
			scrollToElement(eleBVPhone);
			// click(eleBVPhone);
			verifyAndInputTextWithActionClass(eleBVPhone, BVphn);

			By eleBVFax = getDynamicElement(strInputField, "Fax");
			waitAndVerifyElement(eleBVFax);
			scrollToElement(eleBVFax);
			verifyAndInputTextWithActionClass(eleBVFax, BVfx);

			LoggingInfo("SP Pharmacy information has been entered/verified successfully.");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify specialty pharamcy information " + ". Error - " + e.getMessage());
		}
	}

	public void selectSpecialityPharmacyCheckbox(String spCheckBox) {
		try {
			By spDropdownLocator = getDynamicElement(strDropDownXpath, "Preferred Specialty Pharmacy");
			waitAndVerifyElement(spDropdownLocator);
			scrollToElement(spDropdownLocator);

			String currentValue = getAttributeValue(spDropdownLocator, "value");
			String expectedValue = (spCheckBox != null && spCheckBox.equalsIgnoreCase("True")) ? "Yes" : "No";

			if (currentValue == null || !currentValue.equalsIgnoreCase(expectedValue)) {
				click(spDropdownLocator);
				By dropdownOptionsLocator = getDynamicElement(dropDownOptions, "Preferred Specialty Pharmacy");
				waitAndVerifyElement(dropdownOptionsLocator);
				verifyAndEnterInfoDropDownField(spDropdownLocator, dropdownOptionsLocator, expectedValue,
						"Preferred Specialty Pharmacy");
				LoggingInfo("Preferred Specialty Pharmacy updated to '" + expectedValue + "'");
			} else {
				LoggingInfo("Preferred Specialty Pharmacy is already set to '" + expectedValue + "'");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to enter sp record" + ". Error - " + e.getMessage());
		}
	}

	public void selectDupixentMyWay(String DupixentMyWay) {
		try {

			// "Dupixent MyWay"
			By dupixentDropdownLocator = getDynamicElement(strDropDownXpath, "Dupixent MyWay");
			waitAndVerifyElement(dupixentDropdownLocator);
			scrollToElement(dupixentDropdownLocator);

			String currentValue = getAttributeValue(dupixentDropdownLocator, "value");
			String expectedValue = (DupixentMyWay != null && DupixentMyWay.equalsIgnoreCase("True")) ? "Yes" : "No";

			if (currentValue == null || !currentValue.equalsIgnoreCase(expectedValue)) {
				click(dupixentDropdownLocator);
				By dropdownOptionsLocator = getDynamicElement(dropDownOptions, "Dupixent MyWay");
				waitAndVerifyElement(dropdownOptionsLocator);
				verifyAndEnterInfoDropDownField(dupixentDropdownLocator, dropdownOptionsLocator, expectedValue,
						"Dupixent MyWay");
				LoggingInfo("Dupixent MyWay updated to '" + expectedValue + "'");
			} else {
				LoggingInfo("Dupixent MyWay is already set to '" + expectedValue + "'");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to enter Dupixent MyWay " + ". Error - " + e.getMessage());

		}
	}

	public void selectPayerInfo(String memberPlan, String fieldValue) {
		try {

			By PayerNameInput = getDynamicElement(strPayerName, fieldValue);
			waitAndVerifyElement(PayerNameInput);
			scrollToElement(PayerNameInput);
			inputText(PayerNameInput, memberPlan);
			By PayerSearchBtn1 = getDynamicElement(strPayerSearch, fieldValue);
			waitAndVerifyElement(PayerSearchBtn1);
			setTimeOut(1000);
			click(PayerSearchBtn1);
			setTimeOut(1000);
			// click(PayerSearchBtn1);

			if (memberPlan.equalsIgnoreCase("Automation Correspondence SP")) {
				By payerRadiobutton = getDynamicElement(correspondenceRadioBox, memberPlan);
				scrollToElement(payerRadiobutton);
				waitAndVerifyElement(payerRadiobutton);
				click(payerRadiobutton);
			} else {
				By payerRadiobutton = getDynamicElement(icareplusRecordsRadioBox, memberPlan);
				waitAndVerifyElement(payerRadiobutton);
				scrollToElement(payerRadiobutton);
				setTimeOut(2000);
				clickByJavascript(payerRadiobutton);
				setTimeOut(2000);

			}
			LoggingInfo("Selected member plan as- " + memberPlan);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select payer information " + ". Error - " + e.getMessage());
		}
	}

	public void searchPayerInfo(String memberPlan, String fieldValue) {
		try {

			By PayerNameInput = getDynamicElement(strPayerName, fieldValue);
			waitAndVerifyElement(PayerNameInput);
			scrollToElement(PayerNameInput);
			inputText(PayerNameInput, memberPlan);
			By PayerSearchBtn1 = getDynamicElement(strPayerSearch, fieldValue);
			waitAndVerifyElement(PayerSearchBtn1);
			setTimeOut(1000);
			click(PayerSearchBtn1);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select payer information " + ". Error - " + e.getMessage());
		}
	}

	// Anand P
	public void validateErrorMessage() {
		try {

			By PayerNameInput = getDynamicElement(strPayerName, "iccSPName");
			waitAndVerifyElement(PayerNameInput);
			scrollToElement(PayerNameInput);
			inputText(PayerNameInput, "No records");
			By PayerSearchBtn1 = getDynamicElement(strPayerSearch, "iccSPName");
			waitAndVerifyElement(PayerSearchBtn1);
			click(PayerSearchBtn1);

			By errorMsg = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[@data-omni-key=\"iccSPAccountSearchComponent\"]//*[text()=\"No records to display\"]");
			waitAndVerifyElement(errorMsg);
			highLightElement(errorMsg);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate error message " + ". Error - " + e.getMessage());
		}

	}

	// Anand P
	public void enterNewSpecialtyPharmacy() {
		try {

			By PayerNameInput = getDynamicElement(strPayerName, "iccSPName");
			waitAndVerifyElement(PayerNameInput);
			scrollToElement(PayerNameInput);
			inputText(PayerNameInput, "spe pharmacy");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to validate error message " + ". Error - " + e.getMessage());
		}

	}

	public void clickOnNextButton() {
		try {
			By nextButton = getDynamicElement(elePrevNextButtons, "Next");
			waitAndVerifyElement(nextButton);
			scrollToElement(nextButton);
			click(nextButton);
			Log.info("Clicked on Next Button");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on Next Button-" + "Error - " + e.getMessage());
		}
	}

	public void clickOnPreviousButton() {
		try {
			By nextButton = getDynamicElement(elePrevNextButtons, "Previous");
			waitAndVerifyElement(nextButton);
			scrollToElement(nextButton);
			click(nextButton);
			Log.info("Clicked on Previous Button");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on Previous Button-" + "Error - " + e.getMessage());
		}
	}

	public void validateSourceSystem(String Payer) {

		try {
			setTimeOut(2000);
			Log.info("Verify Source System Displayed");
			switch (Payer) {
			case "Pharmacy":
				waitAndVerifyElement(elePharmacySource);
				Source = getAttributeValue(elePharmacySource, "data-cell-value");
				verifySourceType(Source);
				setTimeOut(2000);
				break;
			case "Medical":
				waitAndVerifyElement(eleMedicalSource);
				Source = getAttributeValue(eleMedicalSource, "data-cell-value");
				verifySourceType(Source);
				setTimeOut(2000);
				break;
			case "Speciality Pharmacy":
				waitAndVerifyElement(eleSPSource);
				Source = getAttributeValue(eleSPSource, "data-cell-value");
				verifySourceType(Source);
				setTimeOut(2000);
				break;
			}
			LoggingInfo("Verified Source System ");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Verification of source system failed " + e.getMessage());
			Assert.fail("Verification of source system failed" + ". Error - " + e.getMessage());

		}

	}

	public void verifySourceType(String source) {
		try {
			if (source == "ICARE+" || source == "RCM") {
				LoggingInfo("Verified Source System ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Verification of source system failed " + e.getMessage());
			Assert.fail("Verification of source system failed" + ". Error - " + e.getMessage());

		}
	}

	/**
	 * Function: Select SP with name
	 * 
	 * @author Trupti
	 **/

	public void selectSpecialtyPharmacy(String pharamcyName) {
		try {
			Log.info("Select specialty pharamcy record");
			setTimeOut(2000);
			selectPayerInfo(pharamcyName, "iccSPName");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select speciality pharmacy record" + ". Error - " + e.getMessage());
		}

		setTimeOut(5000);
	}

	/**
	 * Function: Return random string
	 * 
	 * @author Trupti
	 **/

	public String returnRandomString() {
		String memberplanname = null;
		try {

			memberplanname = (firstName != null ? firstName : "") + " " + (lastName != null ? lastName : "") + " ";

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to return random string name" + ". Error - " + e.getMessage());
		}
		return memberplanname;
	}

	/**
	 * Function: Enter payer pharamcy name
	 * 
	 * @author Trupti
	 **/
	public void enterPayerPharmacy(String rxMemberPlan) {
		try {
			Log.info("Select payer pharmacy record");
			setTimeOut(2000);
			By PayerNameInput = getDynamicElement(strPayerName, "iccRxPayerName");
			waitAndVerifyElement(PayerNameInput);
			scrollToElement(PayerNameInput);
			inputText(PayerNameInput, rxMemberPlan);
			LoggingInfo("Entered RX memberplan- " + rxMemberPlan);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to enter pharamcy record" + ". Error - " + e.getMessage());
		}
	}

	/**
	 * Function: Enter payer medical name
	 * 
	 * @author Trupti
	 **/
	public void enterPayerMedical(String medMemberPlan) {
		try {
			Log.info("Select payer pharmacy record");
			setTimeOut(2000);
			By PayerNameInput = getDynamicElement(strPayerName, "iccMedicalPayerName");
			waitAndVerifyElement(PayerNameInput);
			scrollToElement(PayerNameInput);
			inputText(PayerNameInput, medMemberPlan);
			LoggingInfo("Entered Medical memberplan- " + medMemberPlan);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to enter medical record" + ". Error - " + e.getMessage());
		}
	}

	// Anand P
	public void verifySourceColumn() {
		try {

			boolean nameFound = false;

			By colmnSource = By.xpath("//th//*[text()='Source System']");
			scrollToElement(colmnSource);
			highLightElement(colmnSource);
			Log.info("Verified source column is visible");

			By eleRows = By.xpath("//th//*[text()='Source System']//ancestor::thead//following-sibling::tbody//tr");
			List<WebElement> rows = getWebDriver().findElements(eleRows);
			scrollToElement(eleRows);
			for (WebElement row : rows) {
				WebElement sourceName = row.findElement(By.xpath(".//td[4]"));
				String ele = sourceName.getText();
				if (ele.contains("ICARE+") || ele.contains("RCM")) {
					nameFound = true;
					break;
				}
			}

			Log.info("Veried source column having data as 'ICARE+' and 'RCM");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify source column-" + "Error - " + e.getMessage());
		}
	}

	// Anand P
	public void verifySourceColumnHCP() {
		try {

			boolean nameFound = false;

			By colmnSource = By.xpath("//th//*[text()='Source System']");
			scrollToElement(colmnSource);
			highLightElement(colmnSource);
			Log.info("Verified source column is visible");

			By eleRows = By.xpath("//th//*[text()='Source System']//ancestor::thead//following-sibling::tbody//tr");
			List<WebElement> rows = getWebDriver().findElements(eleRows);
			scrollToElement(eleRows);
			for (WebElement row : rows) {
				WebElement sourceName = row.findElement(By.xpath(".//td[4]"));
				String ele = sourceName.getText();
				if (ele.contains("ICARE+") || ele.contains("RCM")) {
					nameFound = true;
					break;
				}
			}

			Log.info("Veried source column having data as 'ICARE+' and 'RCM");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify source column-" + "Error - " + e.getMessage());
		}
	}

	public void validateSPsearch() throws Exception {
		try {
			By PayerNameInput = getDynamicElement(strPayerName, "iccSPName");
			waitAndVerifyElement(PayerNameInput);
			scrollToElement(PayerNameInput);
			LoggingInfo("SP search is displayed below Payer name.");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify SP search Field" + e.getMessage());
		}

	}

	public void searchPayerPharmacy(String payerName) {
		try {

			Log.info("Select payer pharmacy record");
			setTimeOut(2000);
			selectPayerInfo(payerName,"iccRxPayerName");
			//searchPayerInfo(payerName, "iccRxPayerName");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select pharamcy record" + ". Error - " + e.getMessage());
		}
	}

	public void searchPayerMedical(String payerName) {
		try {

			Log.info("Select payer medical record");
			setTimeOut(2000);
			selectPayerInfo(payerName, "iccMedicalPayerName");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select pharamcy record" + ". Error - " + e.getMessage());
		}
	}

	public void selectRCMRecord(String name, String patinetName, int index) {
		try {

			// Verify Source system using show details and then select RCM HCP
			By showAction = By.xpath(
					"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Show actions\"]//ancestor::button)["
							+ index + "]");
			waitAndVerifyElement(showAction);
			scrollToElement(showAction);
			clickByJavascript(showAction);

			By showDetails = By
					.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Show details\"])[" + index + "]");
			waitAndVerifyElement(showDetails);
			scrollToElement(showDetails);
			clickByJavascript(showDetails);
			setTimeOut(2000);

			// Check source system
			By soyrceSystem = getDynamicElement(strAccountObjectDetails, "Source System");
			waitAndVerifyElement(soyrceSystem);
			scrollToElement(soyrceSystem);
			String source = getText(soyrceSystem);
			Assert.assertEquals(source, "RCM", "Source system does not match");

			// navigate back to patient EF wizard
			missingInformatioPage.navigateToCPERecord(patinetName);
			setTimeOut(2000);

			// Select Record
			By selectbutton = getDynamicElement(strSelectButton, name);
			waitAndVerifyElement(selectbutton);
			scrollToElement(selectbutton);
			click(selectbutton);
			LoggingInfo("Selected Record as- " + name);
			setTimeOut(1000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select information " + ". Error - " + e.getMessage());
		}
	}

	public void sarchSpecialtyPharmacy(String pharamcyName) {
		try {
			Log.info("Select specialty pharamcy record");
			setTimeOut(2000);
			selectPayerInfo(pharamcyName, "iccSPName");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to select speciality pharmacy record" + ". Error - " + e.getMessage());
		}

		setTimeOut(5000);
	}
}
