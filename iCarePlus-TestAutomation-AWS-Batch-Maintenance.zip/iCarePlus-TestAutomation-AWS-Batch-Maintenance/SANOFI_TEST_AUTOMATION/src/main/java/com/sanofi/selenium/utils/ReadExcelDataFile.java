/*
 * package com.sanofi.selenium.utils;
 * 
 * import java.io.FileInputStream; import java.io.FileOutputStream; import
 * java.io.IOException; import java.util.ArrayList; import java.util.Calendar;
 * import java.util.HashMap; import java.util.Iterator; import java.util.List;
 * import java.util.Map;
 * 
 * import org.apache.poi.hssf.usermodel.HSSFDateUtil; import
 * org.apache.poi.hssf.util.HSSFColor; import org.apache.poi.ss.usermodel.Cell;
 * import org.apache.poi.ss.usermodel.CellStyle; import
 * org.apache.poi.ss.usermodel.DataFormatter; import
 * org.apache.poi.ss.usermodel.Row; import org.apache.poi.xssf.usermodel.*;
 * 
 * public class ReadExcelDataFile {
 * 
 * public String path; public FileInputStream fis = null; public
 * FileOutputStream fileOut = null; private XSSFWorkbook workbook = null;
 * private XSSFSheet sheet = null; private XSSFRow row = null; private XSSFCell
 * cell = null;
 * 
 *//****************** Constructor ***********************/
/*
 * public ReadExcelDataFile(String path) {
 * 
 * this.path = path; try { fis = new FileInputStream(path); workbook = new
 * XSSFWorkbook(fis); sheet = workbook.getSheetAt(0); fis.close(); } catch
 * (Exception e) { // TODO Auto-generated catch block e.printStackTrace(); }
 * 
 * }
 * 
 * public ArrayList<String> getExcelData(String SheetName) {
 * 
 * ArrayList<String> a = new ArrayList<String>();
 * 
 * int sheets = workbook.getNumberOfSheets(); for (int i = 0; i < sheets; i++) {
 * if (workbook.getSheetName(i).equalsIgnoreCase(SheetName)) { XSSFSheet sheet =
 * workbook.getSheetAt(i); // Identify Testcases coloum by scanning the entire
 * 1st row
 * 
 * Iterator<Row> rows = sheet.iterator();// sheet is collection of rows
 * 
 * //// once coloumn is identified then scan entire testcase coloum to identify
 * //// purcjhase testcase row while (rows.hasNext()) {
 * 
 * Row r = rows.next();
 * 
 * Iterator<Cell> cv = r.cellIterator(); while (cv.hasNext()) { Cell c =
 * cv.next(); DataFormatter formatter = new DataFormatter();
 * a.add(formatter.formatCellValue(c));
 * 
 * }
 * 
 * }
 * 
 * }
 * 
 * } return a; }
 * 
 * 
 * public String getExcelCellvalue(String sSheetName, int iRowNum, int
 * iColumnNum) { String cell = null; try {
 * 
 * cell = workbook.getSheet(sSheetName).getRow(iRowNum).getCell(iColumnNum).
 * getStringCellValue();
 * 
 * } catch (Exception e) { { // sCellValue=""; e.printStackTrace(); } } return
 * cell; }
 * 
 *//****************** Returns the row count in a sheet ***********************//*
																				 * public int getRowCount(String
																				 * sheetName) { int index =
																				 * workbook.getSheetIndex(sheetName); if
																				 * (index == -1) return 0; else { sheet
																				 * = workbook.getSheetAt(index); int
																				 * number = sheet.getLastRowNum() + 1;
																				 * return number; }
																				 * 
																				 * }
																				 * 
																				 * 
																				 * public Map<String, Map<String,
																				 * String>> getExcelAsMap() throws
																				 * IOException { XSSFSheet sheet =
																				 * getSheet(); Map<String, Map<String,
																				 * String>> completeSheetData = new
																				 * HashMap<String, Map<String,
																				 * String>>(); List<String> columnHeader
																				 * = new ArrayList<String>(); Row row =
																				 * sheet.getRow(0); Iterator<Cell>
																				 * cellIterator = row.cellIterator();
																				 * while (cellIterator.hasNext()) {
																				 * columnHeader.add(cellIterator.next().
																				 * getStringCellValue()); } int rowCount
																				 * = sheet.getLastRowNum(); int
																				 * columnCount = row.getLastCellNum();
																				 * for (int i = 1; i <= rowCount; i++) {
																				 * Map<String, String> singleRowData =
																				 * new HashMap<String, String>(); Row
																				 * row1 = sheet.getRow(i); for (int j =
																				 * 0; j < columnCount; j++) { Cell cell
																				 * = row1.getCell(j);
																				 * singleRowData.put(columnHeader.get(j)
																				 * , getCellValueAsString(cell)); }
																				 * completeSheetData.put(
																				 * getCellValueAsString(row1.getCell(0))
																				 * , singleRowData); } return
																				 * completeSheetData; }
																				 * 
																				 * public Map<String, Map<String,
																				 * String>> getExcelRow(int rowNo)
																				 * throws IOException { XSSFSheet sheet
																				 * = getSheet(); Map<String, Map<String,
																				 * String>> completeSheetData = new
																				 * HashMap<String, Map<String,
																				 * String>>(); List<String> columnHeader
																				 * = new ArrayList<String>(); Row row =
																				 * sheet.getRow(0); Iterator<Cell>
																				 * cellIterator = row.cellIterator();
																				 * while (cellIterator.hasNext()) {
																				 * columnHeader.add(cellIterator.next().
																				 * getStringCellValue()); } Map<String,
																				 * String> singleRowData = new
																				 * HashMap<String, String>(); Row row1 =
																				 * sheet.getRow(rowNo); int columnCount
																				 * = row.getLastCellNum(); for (int j =
																				 * 0; j < columnCount; j++) { Cell cell
																				 * = row1.getCell(j);
																				 * singleRowData.put(columnHeader.get(j)
																				 * , getCellValueAsString(cell)); }
																				 * completeSheetData.put(
																				 * getCellValueAsString(row1.getCell(0))
																				 * , singleRowData);
																				 * 
																				 * return completeSheetData; }
																				 * 
																				 * public String getMapData(String key,
																				 * String testId) throws IOException {
																				 * 
																				 * if (map == null) { map =
																				 * getExcelAsMap().get(testId); value =
																				 * map.get(key); } else { value =
																				 * map.get(key); }
																				 * 
																				 * return value;
																				 * 
																				 * }
																				 * 
																				 * 
																				 * 
																				 * }
																				 */