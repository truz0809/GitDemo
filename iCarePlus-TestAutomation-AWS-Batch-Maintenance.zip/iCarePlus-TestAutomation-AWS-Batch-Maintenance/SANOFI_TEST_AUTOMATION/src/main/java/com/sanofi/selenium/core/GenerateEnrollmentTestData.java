package com.sanofi.selenium.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.WebDriver;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.sanofi.selenium.constants.TestData;

import java.util.Random;
import org.apache.poi.ss.usermodel.*;

public class GenerateEnrollmentTestData extends Utility_Function implements TestData {

	public GenerateEnrollmentTestData(WebDriver driver) {
		super(driver);
	}

	String testDataFilePath = System.getProperty("user.dir") + "/TestData/";
	String testDataFileName = "EnrollmentFormTestData.xlsx";

	public void generateEFTestData() {
		String[] functionalities = { "Enrollment", "Consent Management", "MissingInformation", "Free Goods",
				"DocumentManagement", "Fax", "AdminSetup", "BenefitVerification", "CareProgram", "CopayWorkflow",
				"DocDropPortal", "PARenewAppeal", "PatientEducation", "PatientEnrollment", "ProgramAndCareTeamMGMNT",
				"ReportsDashboard", "RGNAlerts", "RGNAM", "RGNPhone", "RGNTTP", "SecurityAccessMgmnt",
				"SpecialtyPharmacyDataDispenses", "TriageToPharmacy", "BenefitsVerificationWorkflow", "IAPWorkflow",
				"MissingInformationManagement", "PAPWorkflow", "PriorAuthorizationWorkflow", "QuickStartWorkFlow" };

		Map<String, String> sheetNames = new HashMap<>();
		sheetNames.put("Enrollment", "PDF_Data");
		sheetNames.put("Consent Management", "Consent_Management");
		sheetNames.put("MissingInformation", "MI_Management");
		sheetNames.put("Free Goods", "Free_Goods");
		sheetNames.put("DocumentManagement", "Doc_MGMNT");
		sheetNames.put("Fax", "Fax");
		sheetNames.put("AdminSetup", "AdminSetup");
		sheetNames.put("BenefitVerification", "BenefitVerification");
		sheetNames.put("CareProgram", "CareProgram");
		sheetNames.put("CopayWorkflow", "CopayWorkflow");
		sheetNames.put("DocDropPortal", "DocDropPortal");
		sheetNames.put("PARenewAppeal", "PARenewAppeal");
		sheetNames.put("PatientEducation", "PatientEducation");
		sheetNames.put("PatientEnrollment", "PatientEnrollment");
		sheetNames.put("ProgramAndCareTeamMGMNT", "ProgramAndCareTeamMGMNT");
		sheetNames.put("ReportsDashboard", "ReportsDashboard");
		sheetNames.put("RGNAlerts", "RGNAlerts");
		sheetNames.put("RGNAM", "RGNAM");
		sheetNames.put("RGNPhone", "RGNPhone");
		sheetNames.put("RGNTTP", "RGNTTP");
		sheetNames.put("SecurityAccessMgmnt", "SecurityAccessMgmnt");
		sheetNames.put("SpecialtyPharmacyDataDispenses", "SpecialtyPharmacyDataDispenses");
		sheetNames.put("TriageToPharmacy", "TriageToPharmacy");
		sheetNames.put("BenefitsVerificationWorkflow", "BenefitsVerificationWorkflow");
		sheetNames.put("IAPWorkflow", "IAPWorkflow");
		sheetNames.put("MissingInformationManagement", "MissingInformationManagement");
		sheetNames.put("PAPWorkflow", "PAPWorkflow");
		sheetNames.put("PriorAuthorizationWorkflow", "PriorAuthorizationWorkflow");
		sheetNames.put("QuickStartWorkFlow", "QuickStartWorkFlow");

		try {
			FileInputStream fileInputStream = new FileInputStream(new File(testDataFilePath + testDataFileName));
			Workbook workbook = new XSSFWorkbook(fileInputStream);

			for (String functionality : functionalities) {
				String sheetToCreate = sheetNames.get(functionality);
				if (sheetToCreate == null) {
					System.out.println("Skipping unsupported functionality: " + functionality);
					continue;
				}

				// Remove existing sheet
				Sheet sheet = workbook.getSheet(sheetToCreate);
				if (sheet != null) {
					workbook.removeSheetAt(workbook.getSheetIndex(sheet));
				}
				sheet = workbook.createSheet(sheetToCreate);

				// Create header row
				Row headerRow = sheet.createRow(0);
				for (int i = 0; i < TestData.headers.length; i++) {
					Cell cell = headerRow.createCell(i);
					cell.setCellValue(TestData.headers[i]);
				}

				// Generate and fill test data
				for (int rowNum = 1; rowNum <= 60; rowNum++) {
					Row row = sheet.createRow(rowNum);
					fillTestDataRow(row, rowNum); // Your same test data generation logic extracted into a method
				}

				System.out.println("Sheet created: " + sheetToCreate);
			}

			fileInputStream.close();

			// Write back to file
			FileOutputStream fileOut = new FileOutputStream(testDataFilePath + testDataFileName);
			workbook.write(fileOut);
			fileOut.close();
			workbook.close();

			System.out.println("All test data sheets generated successfully.");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void fillTestDataRow(Row row, int rowNum) {
		Random random = new Random();
		String[] firstNames = TestData.firstNames;
		String[] lastNames = TestData.lastNames;
		String[] domains = TestData.domains;
		String[] genders = TestData.genders;
		String[] languages = TestData.languages;
		String[] address = TestData.address;
		String[] cityNames = TestData.cityNames;
		String[] States = TestData.statesAndTerritories;
		String[] checkboxes = TestData.checkboxes;
		String[] legalRepfirstNames = TestData.legalRepfirstNames;
		String[] legalReplastNames = TestData.legalReplastNames;
		String[] relationship = TestData.relationship;
		String[] relationshipToPatient = TestData.relationshipToPatient;
		String[] specialties = TestData.preSpecialties;
		String[] facilityNames = TestData.facilityNames;
		String[] officeFirstNames = TestData.officeFirstNames;
		String[] officeLastNames = TestData.officeLastNames;
		String[] dupixentOptions = TestData.dupixentOptions;
		String[] drugAllergies = TestData.drugAllergies;
		String[] collaboratingMDFirstNames = TestData.collaboratingMDFirstNames;

		row.createCell(0).setCellValue("TC" + rowNum); // TestCaseID
		int randomNum = random.nextInt(999);
		String firstName = firstNames[random.nextInt(firstNames.length)];
		String midName = firstNames[random.nextInt(firstNames.length)];
		String lastName = lastNames[random.nextInt(lastNames.length)];

		String fullName = "Automation" + firstName + " " + midName + " " + lastName;

		row.createCell(1).setCellValue(fullName); // PatientName

		// Generating a random DOB (date of birth)
		int year = 1950 + random.nextInt(50); // Random year between 1950 and 2000
		int month = 1 + random.nextInt(12);
		int day = 1 + random.nextInt(28);
		String dob = String.format("%02d-%02d-%02d", month, day, year);
		row.createCell(2).setCellValue(dob); // PatientDOB

		// Generating a random phone number
		String phoneNumber = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
				+ (1000 + random.nextInt(9000));
		row.createCell(3).setCellValue(phoneNumber); // PatientPrimaryPhone

		// Generating a random email id
		String email = firstName.toLowerCase() + lastName.toLowerCase() + "@" + domains[random.nextInt(domains.length)];
		row.createCell(4).setCellValue(email);

		// Generating a random gender
		String gender = genders[random.nextInt(genders.length)];
		row.createCell(5).setCellValue(gender);

		// Generating language
		String language = languages[random.nextInt(languages.length)];
		row.createCell(6).setCellValue(language);

		// Generating patient Address
		String patientAdd = (100 + random.nextInt(900)) + " " + address[random.nextInt(address.length)];
		row.createCell(7).setCellValue(patientAdd);

		// Generating City
		String city = cityNames[random.nextInt(cityNames.length)];
		row.createCell(8).setCellValue(city);

		// Generating State
		String state = States[random.nextInt(States.length)];
		row.createCell(9).setCellValue(state);

		// Generating zip
		int zip = 10000 + random.nextInt(9999);
		row.createCell(10).setCellValue(zip);

		// Generating a random phone number
		String secphoneNumber = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
				+ (1000 + random.nextInt(9000));
		row.createCell(11).setCellValue(secphoneNumber); // PatientSechone

		// generating Patient Authorization Date
		String authDate = getNthDayFromToday(0);
		row.createCell(12).setCellValue(authDate); // PatientAuthDate

		// generating Patient Certifications Date
		String certDate = getNthDayFromToday(0);
		row.createCell(13).setCellValue(certDate); // PatientCertDate

		String checkbox = checkboxes[random.nextInt(checkboxes.length)];
		for (int i = 14; i <= 19; i++) {
			row.createCell(i).setCellValue(checkbox);
		}

		// Legal Representative Names
		int randomNumLegalRep = random.nextInt(999);
		String legalRepfirstName = legalRepfirstNames[random.nextInt(legalRepfirstNames.length)];
		String legalReplastName = legalReplastNames[random.nextInt(legalReplastNames.length)];

		String legalRepName = legalRepfirstName + " " + legalReplastName;
		row.createCell(20).setCellValue(legalRepName); // LegalRepLastName

		// Legal Representative Relationship
		String rel = relationship[random.nextInt(relationship.length)];
		row.createCell(21).setCellValue(rel);

		// patient has no insurance
		row.createCell(22).setCellValue(checkbox);

		// RX payer name

		row.createCell(23).setCellValue("TestAutomation Payer Pharmacy");

		// Rx Phone
		String rxphoneNumber = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
				+ (1000 + random.nextInt(9000));
		row.createCell(24).setCellValue(rxphoneNumber); // RX phone num

		// RX policy ID
		int rxPolicyID = 10000 + random.nextInt(99999);
		row.createCell(25).setCellValue(rxPolicyID);

		// RX group ID
		int rxGrpID = 10000 + random.nextInt(999999);
		row.createCell(26).setCellValue(rxGrpID);

		// RX BIN
		int rxBIN = 200000 + random.nextInt(99999);
		row.createCell(27).setCellValue(rxBIN);

		// RX PCN
		int rxPCN = 1000000000 + random.nextInt(999999999);
		row.createCell(28).setCellValue(rxPCN);

		// Medical Payer Name
		row.createCell(29).setCellValue("TestAutomation Payer Medical");

		// Medical Phone
		String medicalPhoneNumber = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
				+ (1000 + random.nextInt(9000));
		row.createCell(30).setCellValue(medicalPhoneNumber); // Medical phone num

		// Medical policy ID
		int medPolicyID = 50000 + random.nextInt(99999);
		row.createCell(31).setCellValue(medPolicyID);

		// Medical group
		int medgrp = 60000 + random.nextInt(999999);
		row.createCell(32).setCellValue(medgrp);

		// Policy Holder Name

		int randomNumPolicyHolder = random.nextInt(900);
		String policyHolderName = legalRepfirstNames[random.nextInt(legalRepfirstNames.length)] + randomNumPolicyHolder
				+ " " + firstNames[random.nextInt(firstNames.length)] + " "
				+ legalReplastNames[random.nextInt(legalReplastNames.length)];
		row.createCell(33).setCellValue(policyHolderName);

		// relationship To Patient
		String reltoPatient = relationshipToPatient[random.nextInt(relationshipToPatient.length)];
		row.createCell(34).setCellValue(reltoPatient);

		// Preferred Specialty Pharmacy
		row.createCell(35).setCellValue(checkbox);

		// Specialty Pharmacy Name
		row.createCell(36).setCellValue("Automation Specialty Pharmacy");

		// BV Phone
		String BVPhoneNumber = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
				+ (1000 + random.nextInt(9000));
		row.createCell(37).setCellValue(BVPhoneNumber); // BV phone number

		// BV FAX

		String BVFax = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
				+ (1000 + random.nextInt(9000));
		row.createCell(38).setCellValue(BVFax); // BV Fax

		// DUPIXENT MyWay
		row.createCell(39).setCellValue(checkbox);

		// Prescriber name
		int randomNumpre = random.nextInt(999);
		String presfirstName = firstNames[random.nextInt(firstNames.length)];
		String preslastName = lastNames[random.nextInt(lastNames.length)];
		String presName = presfirstName + " " + preslastName;

		row.createCell(40).setCellValue(presName); // PrescriberLastName

		// specialties
		String prspecialties = specialties[random.nextInt(specialties.length)];
		row.createCell(41).setCellValue(prspecialties); // PrescriberLastName

		// Generating Prescriber Address
		String preAdd = (100 + random.nextInt(900)) + " " + address[random.nextInt(address.length)];
		row.createCell(42).setCellValue(preAdd);

		// Generating Prescriber City
		String precity = cityNames[random.nextInt(cityNames.length)];
		row.createCell(43).setCellValue(precity);

		// Generating Prescriber State
		String prstate = States[random.nextInt(States.length)];
		row.createCell(44).setCellValue(prstate);

		// Generating Prescriber zip
		int preszip = 10000 + random.nextInt(9999);
		row.createCell(45).setCellValue(preszip);

		// Prescriber NPI
		String presNPI = generateRandom10DigitNumber();
		row.createCell(46).setCellValue(presNPI);

		// facilityNames
		String facilityName = facilityNames[random.nextInt(facilityNames.length)];
		row.createCell(47).setCellValue(facilityName);

		// Office name
		int randomNumOfc = random.nextInt(999);
		String ofcFName = officeFirstNames[random.nextInt(officeFirstNames.length)];
		String ofcLName = officeLastNames[random.nextInt(officeLastNames.length)];
		String ofcName = ofcFName + " " + ofcLName;
		row.createCell(48).setCellValue(ofcName);

		// office contcat email
		String offemail = ofcFName.toLowerCase() + ofcLName.toLowerCase() + "@"
				+ domains[random.nextInt(domains.length)];
		row.createCell(49).setCellValue(offemail);

		// Office Phone
		String offPhoneNumber = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
				+ (1000 + random.nextInt(9000));
		row.createCell(50).setCellValue(offPhoneNumber); // office phone number

		// office fax

		String offFax = "(" + (100 + random.nextInt(900)) + ") " + (100 + random.nextInt(900)) + "-"
				+ (1000 + random.nextInt(9000));
		row.createCell(51).setCellValue(offFax); // BV Fax

		// tax id
		int tax = 100000000 + random.nextInt(99999999);
		row.createCell(52).setCellValue(tax);

		// Date Of Diagnosis
		year = 2000 + random.nextInt(23); // Random year between 2000 and 2023
		month = 1 + random.nextInt(12);
		day = 1 + random.nextInt(28);
		String datOfDiagnosis = String.format("%02d-%02d-%02d", month, day, year);
		row.createCell(53).setCellValue(datOfDiagnosis);

		// Diagnosis Code
		row.createCell(54).setCellValue("");

		// Prescriber State License
		if (prstate.equalsIgnoreCase("Puerto Rico")) {
			int license = 10000 + random.nextInt(999999);
			row.createCell(55).setCellValue(license);
		}

		// A Sample Provided
		row.createCell(56).setCellValue(checkbox);

		// A Sample Provided Date

		year = 2022 + random.nextInt(1); // Random year between 2022 and 2023
		month = 1 + random.nextInt(12);
		day = 1 + random.nextInt(28);
		String sampleProvidedDate = String.format("%02d-%02d-%02d", month, day, year);
		row.createCell(57).setCellValue(sampleProvidedDate);

		// A Prefilled Syringe
		row.createCell(58).setCellValue(checkbox);

		// A Prefilled Pen
		row.createCell(59).setCellValue(checkbox);

		// Prescription-A RefillCaptured
		int arefill = 1 + random.nextInt(10);
		row.createCell(60).setCellValue(arefill);

		// Prescription-5A Dose
		String dupixentOption = dupixentOptions[random.nextInt(dupixentOptions.length)];
		row.createCell(61).setCellValue(dupixentOption);

		// A-Known Drug Allergies
		String drugAllergie = drugAllergies[random.nextInt(drugAllergies.length)];
		row.createCell(62).setCellValue(drugAllergie);

		// A-weight

		int aweight = 20 + random.nextInt(100);
		row.createCell(63).setCellValue(aweight);

		// A -Initial And Maintenance Doses
		row.createCell(64).setCellValue(checkbox);

		// Prescription 5B Quick Start
		row.createCell(65).setCellValue(checkbox);

		// B Sample Provided
		row.createCell(66).setCellValue(checkbox);

		// b Sample Provided Date

		year = 2022 + random.nextInt(1); // Random year between 2022 and 2023
		month = 1 + random.nextInt(12);
		day = 1 + random.nextInt(28);
		String bsampleProvidedDate = String.format("%02d-%02d-%02d", month, day, year);
		row.createCell(67).setCellValue(bsampleProvidedDate);

		// B Prefilled Syringe
		row.createCell(68).setCellValue(checkbox);

		// B Prefilled Pen
		row.createCell(69).setCellValue(checkbox);

		// Prescription-B RefillCaptured
		int brefill = 1 + random.nextInt(10);
		row.createCell(70).setCellValue(brefill);

		// Prescription-5B Dose
		String bdupixentOption = dupixentOptions[random.nextInt(dupixentOptions.length)];
		row.createCell(71).setCellValue(bdupixentOption);

		// B-Known Drug Allergies
		String bdrugAllergie = drugAllergies[random.nextInt(drugAllergies.length)];
		row.createCell(72).setCellValue(bdrugAllergie);

		// b-weight

		int bweight = 20 + random.nextInt(100);
		row.createCell(73).setCellValue(bweight);

		// A -Initial And Maintenance Doses
		row.createCell(74).setCellValue(checkbox);

		// Prescriber Signature Date
		String prescribersignDate = getNthDayFromToday(0);
		row.createCell(75).setCellValue(prescribersignDate);

		// Substitutions Date
		year = 2022 + random.nextInt(1); // Random year between 2022 and 2023
		month = 1 + random.nextInt(12);
		day = 1 + random.nextInt(28);
		String substitutionsDate = String.format("%02d-%02d-%02d", month, day, year);
		row.createCell(76).setCellValue(substitutionsDate);

		// collaborating MD Names
		int randomNumMD = random.nextInt(999);
		String mdFirstName = collaboratingMDFirstNames[random.nextInt(collaboratingMDFirstNames.length)];

		String mdlastName = lastNames[random.nextInt(lastNames.length)];

		String mdName = mdFirstName + " " + mdlastName;
		row.createCell(77).setCellValue(mdName);

		// Nurse Practitioner NPI
		String nurseNPI = generateRandom10DigitNumber();
		row.createCell(78).setCellValue(nurseNPI);

		// Eosinophil count
		int count = 1 + random.nextInt(50);
		row.createCell(79).setCellValue(count);
	}

}
