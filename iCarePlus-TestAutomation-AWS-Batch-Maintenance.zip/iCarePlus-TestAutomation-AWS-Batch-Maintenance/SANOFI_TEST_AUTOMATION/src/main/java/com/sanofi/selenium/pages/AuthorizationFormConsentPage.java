package com.sanofi.selenium.pages;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.sanofi.selenium.constants.TestData;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class AuthorizationFormConsentPage extends Utility_Function implements TestData {

	public AuthorizationFormConsentPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	Random random = new Random();

	String[] firstNames = TestData.firstNames;
	String[] lastNames = TestData.lastNames;
	String firstName = firstNames[random.nextInt(firstNames.length)];
	String midName = firstNames[random.nextInt(firstNames.length)];
	String lastName = lastNames[random.nextInt(lastNames.length)];
	String fullName = firstName + " " + midName + " " + lastName;

	public static String recName = "James Bob";

	/************* Static Elements ******************************************/

	// public static By eleNewBtn = By.xpath("//div[text()='New']");
	public static By eleNewBtn = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"New\"]//parent::a");
	public static By eleNameAuthorizationConsent = By.xpath("//label[text()='Name']");

	// For Values
	public static By eleAuthrizationFieldsValueName = By.xpath("//input[@name='Name']");

	public static By eleAuthorizationFormRelatedRecValue = By.xpath("(//input[@placeholder='Search...'])[1]");
	public static By eleAuthorizationFormConsentGiverValue = By.xpath("(//input[@placeholder='Search...'])[2]");
	public static By eleAuthorizationRelatedRecordList = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()='Related Record']//following-sibling::div//child::div//child::lightning-base-combobox//child::div//child::div//child::div[@role='listbox'])[2]");
	public static By eleAuthorizationFormConsentGiverList = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()='Consent Giver']//following-sibling::div//child::div//child::lightning-base-combobox//child::div//child::div//child::div[@role='listbox'])[2]");

	public static By eleAuthorizationConsentCapInput = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()='Consent Capture Date']//following-sibling::div//input");
	public static By eleAuthorizationConsentExpInput = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()='Consent Expiration Date Time']//following-sibling::div//child::div//child::div//following-sibling::div//child::input[@name='ConsentExpirationDateTime'])[1]");
	public static By eleAccount = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Related Record\"]//ancestor::div[contains(@class,\"test-id\")]//li//span[contains(@class,\"option-text\")]//lightning-base-combobox-formatted-text)[1]");

	public static By strSearchDropDownOptions2 = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Program Role\"]//following-sibling::div//lightning-base-combobox//span[@class=\"slds-media__body\"]");

	/************* Dynamic Elements ******************************************/
	public static String strTextConsentForm = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//a//span//slot//span//span";
	public static String strAccountObjectDetails = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-text";
	public static String strCareProgramField = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//ancestor::div[2]//dd//descendant::a/span/slot/span/slot";

	public static String strRecentlyViewed = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]";

	public static String strAuthorizationFormFields = "//label[text()=\"{0}\"]";

	public static String strAuthorizationFieldsDateTime = "//*[text()=\"{0}\"]";

	public static String strAuthorizationieldButtons = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::button" ;

	public static String strAuthorizationFormTextList = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::lightning-base-combobox//child::div//child::div//child::div//following-sibling::div[@role='listbox']";
	public static String strAuthorizationStatusList = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]";

	public static String startDate = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Date\"]//parent::label//parent::div//following-sibling::div//input)[1]";
	public static String endDate = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Date\"]//parent::label//parent::div//following-sibling::div//input)[2]";
	public static String startTime = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Time\"]//parent::label//following-sibling::div//input)[1]";
	public static String endTime = "(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Time\"]//parent::label//following-sibling::div//input)[2]";

	// DropdownList Values
	public static String strStatusListValue = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[text()=\"Active\"]";
	public static String strConsentCapListValue = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[text()=\"Written\"]";
	public static String strDataUsePurListVal = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[text()=\"HIPAA Authorization\"]";
	public static String strCarePrgmListVal = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[text()=\"DMW EoE\"]";
	public static String strAuthorizationFormTxtListVal = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[text()=\"Dupixent Patient Authorization Form Text\"]";
	public static String strRelatedRec = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[@title=\"James Bob\"]";
	public static String strRelatedMem = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Member\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[@title=\"SR-0047\"]";

	public static String eleConsentName="//*[contains(@class,\"active lafPageHost\")]//div[@role=\"cell\" and text()=\"{0}\"]";
	
	// For Values
	public static String strAuthorizationConsentCapturedDateValue = "(//input[@name=\"{0}\"])[1]";
	// ConsentCapturedDateTime
	// ConsentExpirationDateTime

	public static String strAuthorizationFormStatusValue = "//button[@aria-label=\"{0}\"]";
	// Status
	// Consent Captured Source Type
	public static String strSearchMem = "(//input[@placeholder=\"{0}\"])";
	// public static String strAuthorizationFormTextValue =
	// "//input[@placeholder=\"{0}\"]";
	public static String strSearchList = "//label[text()=\"{0}\"]";
	public static String serachDropDownListBox = "//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"test-id\")]//*[text()=\"{0}\"]//following-sibling::div//input";
	public static String strSearchDropDownOptions1 = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"test-id\")]//li//span[contains(@class,\"option-text\")]//lightning-base-combobox-formatted-text";
	public static String searchDropDownListBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//following-sibling::div//lightning-base-combobox//button";
	public static String strRelatedRec1 = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[@title=\"{1}\"]";
	public static String strStatusListValue1 = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[text()=\"{1}\"]";
	public static By eleShowMoreResult = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//span[contains(text(),\"Show more results for\")]");
	public static By eleSelectFirstHC = By
			.xpath("//span[text()=\"Select Item 1\"]//parent::label//span[@class=\"slds-radio_faux\"]");
	public static By eleSelectButton = By.xpath("//button[text()=\"Select\"]");

	
	//author Tejal
		public void createAuthorizationConsent() {
		    try {
		        Log.info("Creating new Authorization Consent");

		   
		        getWebDriver().findElement(By.xpath(
		            "//button[span[normalize-space()='New']]")).click();
		        Log.info("'New' button clicked");
	getWebDriver().findElement(By.xpath(
		            "//span[normalize-space()='Authorization Consent']" +
		            "/preceding-sibling::span[contains(@class,'slds-radio--faux')]"
		        )).click();
		        Log.info("'Authorization Consent' radio button selected");
	getWebDriver().findElement(By.xpath(
		            "//button[span[normalize-space()='Next']]"
		        )).click();
		        Log.info("'Next' button clicked");

		    } catch (Exception e) {
		        e.printStackTrace();
		        Log.error("Failed to create Authorization Consent: " + e.getMessage());
		        Assert.fail("Failed to create Authorization Consent: " + e.getMessage());
		    }
		}


	public void verifyAuthorizationConsentPage() {
		try {

			Log.info("Verify  authorization form consent page");
			waitForPageLoaded();
			setTimeOut(2000);
			LoggingInfo("Authorization form consent page is displayed.");
			By RecentlyViewedBtn = getDynamicElement(strRecentlyViewed, "Recently Viewed");
			waitAndVerifyElement(RecentlyViewedBtn);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Authorization form consent page " + e.getMessage());
			Assert.fail("Failed to verify Authorization form consent page " + e.getMessage());
		}
	}
	
	
	/*
	 * @author - Anand Pawar
	 */
	public void enterConsentWithdrawlDate(String date) {
		try {

			By eleConsentWithdrawlDate=By.xpath("//*[contains(@class,'active lafPageHost')]//input[@aria-label='Consent Withdrawn Date']");
			waitAndVerifyElement(eleConsentWithdrawlDate);
			inputText(eleConsentWithdrawlDate,date);
			setTimeOut(2000);
		}
		catch(Exception e) {
			e.printStackTrace();
			Log.error("Failed to enter " + e.getMessage());
			Assert.fail("Failed to enter" + e.getMessage());
		}
	}
	
	/*
	 * @author - Anand Pawar
	 */
	public String selectConsenCheckbox() {
		String textConsent="";
		try {

			By checkBox=By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"checkbox_faux\")]");
			waitAndVerifyElement(checkBox);
			clickByJavascript(checkBox);
			setTimeOut(2000);
			
			By firstConsent=By.xpath("(//*[contains(@class,\"active lafPageHost\")]//div[@role=\"cell\"])[2]");
			waitAndVerifyElement(firstConsent);
			 textConsent=getText(firstConsent);

		}
		catch(Exception e) {
			e.printStackTrace();
			Log.error("Failed to click " + e.getMessage());
			Assert.fail("Failed to click" + e.getMessage());
		}
		return textConsent;
	}
	
	/*
	 * @author - Anand Pawar
	 */
	public void verifyConsentConfirmationErrorMessage() {
		try {

			By errMsg=By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Select at least one consent record to proceed further.\"]");
			waitAndVerifyElement(errMsg);
			highLightElement(errMsg);
			
			LoggingInfo("Verified error message");

			copayFlow.clickOnFinishButton();


		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
			Assert.fail("Failed to verify " + e.getMessage());
		}
	}
	

	/*
	 * @author - Anand Pawar
	 */
	public void verifyConsentConfirmationMessage() {
		try {

			By successMsg=By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Patient has been withdrawn from selected consent(s).\"]");
			waitAndVerifyElement(successMsg);
			highLightElement(successMsg);
			
			
			LoggingInfo("Verified success message");

			copayFlow.clickOnFinishButton();


		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify " + e.getMessage());
			Assert.fail("Failed to verify " + e.getMessage());
		}
	}
	
	/*
	 * Function - Verify consent withdraw page header 
	 * 
	 * @author - Anand Pawar
	 */
	public void verifyConsentWithdrawHeaderAndSubheader() {
		try {

			Log.info("Verify Consent withdraw header and Subheader");
			
			By eleHeader=By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Withdraw Consent\" and @role=\"heading\"]");
			waitAndVerifyElement(eleHeader);
			highLightElement(eleHeader);

			By eleSubHeader=By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Select at least one consent record to proceed further\"]");
			waitAndVerifyElement(eleSubHeader);
			highLightElement(eleSubHeader);
			
			LoggingInfo("Verified Withdraw Consent Header");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify  " + e.getMessage());
			Assert.fail("Failed to verify  " + e.getMessage());
		}
	}
	
	
	/*
	 * @author - Anand Pawar
	 */
	public boolean compareTableColumnNames() {
	    try {
	        List<String> expectedFields = Arrays.asList("SELECT", "CONSENT TYPE", "CONSENT CAPTURE DATE", "EXPIRATION DATE TIME");

	        List<WebElement> elements = getWebDriver().findElements(By.xpath("//*[contains(@class,'active lafPageHost')]//div[@role='columnheader']//strong"));

	        List<String> actualFields = elements.stream()
	                                            .map(WebElement::getText)
	                                            .map(String::trim)
	                                            .collect(Collectors.toList());

	        return actualFields.equals(expectedFields);

	    } catch (Exception e) {
	        // Log exception for debugging
	    	Log.error("Error during field name comparison: " + e.getMessage());
	        e.printStackTrace();
	        return false;
	    }
	}
	
	
	/*
	 * @author - Anand Pawar
	 */
	public void verifyAllConsentsPresent() {
		try {
			
	        List<String> fieldNames = Arrays.asList("Patient Program Authorization", "General Marketing Consent",
					"Email Communication Consent", "Telephone Communication Consent", "Written/Mail Communication Consent",
					"Text Messaging Consent", "HIPAA Authorization", "HCP Authorization");
	        
	        for (String field : fieldNames) {
				By eleStatus =getDynamicElement(eleConsentName,field);
                waitAndVerifyElement(eleStatus);
                highLightElement(eleStatus);
	            System.out.println(getText(eleStatus));
	        }
			LoggingInfo("Verified all consents present");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to validate" + e.getMessage());
			Assert.fail("Failed to validate" + e.getMessage());
		}
	}



	public void verifyClickNewButton() {
		try {
			Log.info("Verify user is able to click on new button");
			//By eleNewButton = By.xpath("//*[contains(@class,\"active lafPageHost\")]//button//span[text()=\"New\"]");
			By eleNewButton = By.xpath("//*[contains(@class,\"active lafPageHost\")]//div[text()=\"New\"]");
			scrollToElement(eleNewButton);
			waitAndVerifyElement(eleNewButton);
			clickByJavascript(eleNewButton);
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify and click on new button " + e.getMessage());
			Assert.fail("Failed to verify and click on new button " + e.getMessage());
		}
	}

	public void verifyConsentRecords() {
		try {
			Log.info("Verify consent records");
			By AuthorizationConsentRec = getDynamicElement(strRecentlyViewed, "Authorization Consent");
			waitAndVerifyElement(AuthorizationConsentRec);
			By ContactConsentRec = getDynamicElement(strRecentlyViewed, "Contact Consent");
			waitAndVerifyElement(ContactConsentRec);
			LoggingInfo("Authorization consent and contact consent verified");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify consent records " + e.getMessage());
			Assert.fail("Failed to verify consent records " + e.getMessage());
		}
	}

	public void selectAuthorizationConsent() {
		try {
			Log.info("Verify that user is able to select Authorization Consent record type.");
			By AuthorizationConsentRec = getDynamicElement(strRecentlyViewed, "Authorization Consent");
			waitAndVerifyElement(AuthorizationConsentRec);
			click(AuthorizationConsentRec);
			LoggingInfo("selected Authorization Consent record type");
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select consent record " + e.getMessage());
			Assert.fail("Failed to select consent record " + e.getMessage());
		}
	}

	public void verifyNextButton() {
		try {
			Log.info("Verify that user is able to click on next button");
			By NextBtn = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Next\"]//parent::button");
			click(NextBtn);
			setTimeOut(2000);
			LoggingInfo("User clicks on Next Button");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to click on next button " + e.getMessage());
			Assert.fail("Failed to click on next button " + e.getMessage());
		}
	}

	public void verifyPageFields() {
		try {
			// Verify all the Authorization Form Consent Fields
			By authorizationFieldName = getDynamicElement(strAuthorizationFormFields, "Name");
			waitAndVerifyElement(authorizationFieldName);
			LoggingInfo("User enters name in the textbox field");

			By authorizationFieldAuthrizationText = getDynamicElement(strAuthorizationFormFields,
					"Authorization Form Text");
			waitAndVerifyElement(authorizationFieldAuthrizationText);
			LoggingInfo("User verifies Authorization Form Text field");

			By authorizationFieldConsentGiver = getDynamicElement(strAuthorizationFormFields, "Consent Giver");
			waitAndVerifyElement(authorizationFieldConsentGiver);
			LoggingInfo("User verifies Consent Giver field");

			By authorizationFieldConsentCapturedSrc = getDynamicElement(strAuthorizationFormFields,
					"Consent Captured Source Type");
			waitAndVerifyElement(authorizationFieldConsentCapturedSrc);
			LoggingInfo("User verifies Consent Captured Source Type field");

			By authorizationFieldDataUsePurpose = getDynamicElement(strAuthorizationFormFields, "Data Use Purpose");
			waitAndVerifyElement(authorizationFieldDataUsePurpose);
			LoggingInfo("User verifies Data Use Purpose field");

			By authorizationFieldCarePgm = getDynamicElement(strAuthorizationFormFields, "Care Program");
			waitAndVerifyElement(authorizationFieldCarePgm);
			LoggingInfo("User verifies Care Program field");

			scrollToDocumentHeight();
			setTimeOut(1000);
			By authorizationFieldStatus = getDynamicElement(strAuthorizationFormFields, "Status");
			waitAndVerifyElement(authorizationFieldStatus);
			LoggingInfo("User verifies Status field");

			By authorizationFieldRelatedRec = getDynamicElement(strAuthorizationFormFields, "Related Record");
			waitAndVerifyElement(authorizationFieldRelatedRec);
			LoggingInfo("User verifies Related Record");

			// By authorizationFieldConsentCapturedDateTime =
			// getDynamicElement(strAuthorizationFieldsDateTime,
			// "Consent Captured Date Time");
			// waitAndVerifyElement(authorizationFieldConsentCapturedDateTime);
			// LoggingInfo("User verifies Consent Captured Date Time");

			By authorizationFieldConsentExpDateTime = getDynamicElement(strAuthorizationFieldsDateTime,
					"Consent Expiration Date Time");
			waitAndVerifyElement(authorizationFieldConsentExpDateTime);
			LoggingInfo("User verifies Consent Expiration Date Time");

			scrollToElement(authorizationFieldConsentExpDateTime);
			setTimeOut(500);
			By authorizationFieldCreatedBy = getDynamicElement(strRecentlyViewed, "Created By");
			waitAndVerifyElement(authorizationFieldCreatedBy);
			LoggingInfo("User verifies Created By");

			By authorizationFieldLastModifiedBy = getDynamicElement(strRecentlyViewed, "Last Modified By");
			waitAndVerifyElement(authorizationFieldLastModifiedBy);
			LoggingInfo("User verifies Last Modified By");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify fields " + e.getMessage());
			Assert.fail("Failed to verify fields " + e.getMessage());
		}
	}

	public void verifySaveNewCancelButton() {
		try {
			Log.info("Verify user is able to view Save, Save & New and Cancel button");
			By authorizationFieldCancel = getDynamicElement(strAuthorizationieldButtons, "Cancel");
			waitAndVerifyElement(authorizationFieldCancel);
			LoggingInfo("User verifies Cancel field");

			By authorizationFieldSave = getDynamicElement(strAuthorizationieldButtons, "Save");
			waitAndVerifyElement(authorizationFieldSave);
			LoggingInfo("User verifies Save field");

			By authorizationFieldSaveNew = getDynamicElement(strAuthorizationieldButtons, "Save & New");
			waitAndVerifyElement(authorizationFieldSaveNew);
			LoggingInfo("User verifies Save & New");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify buttons " + e.getMessage());
			Assert.fail("Failed to verify buttons " + e.getMessage());
		}
	}

	// Anand P
	public void addCPETeamMember() {
		try {
			// Member
			By member = getDynamicElement(strSearchMem, "Search Service Resources...");
			scrollToElement(member);
			waitAndVerifyElement(member);
			setTimeOut(1000);
			inputText(member, "SR-");
			Actions act = new Actions(getWebDriver());
			act.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).perform();
			setTimeOut(2000);
			act.sendKeys(Keys.ENTER).perform();

			By button = By.xpath("//span[@class='slds-radio_faux']");
			click(button);
			setTimeOut(2000);

			By selectButton = By.xpath("//button[text()=\"Select\"]");
			click(selectButton);
			LoggingInfo("User selects Consent Giver");
			setTimeOut(2000);

			By role = getDynamicElement(searchDropDownListBox, "Program Role");
			waitAndVerifyElement(role);
			setTimeOut(1000);
			click(role);
			setTimeOut(2000);
			selectItemFromDropDown(role, strSearchDropDownOptions2, "Case Manager");
			LoggingInfo("User selects program role");

			String effectiveDate = Utility_Function.getNthDayFromTodayFormatted(10);
			String expirationDate = Utility_Function.getNthDayFromTodayFormatted(15);

			By startingDate = By.xpath(startDate);
			waitAndVerifyElement(startingDate);
			scrollToElement(startingDate);
			inputText(startingDate, effectiveDate);
			setTimeOut(2000);

			By startingTime = By.xpath(startTime);
			waitAndVerifyElement(startingTime);
			clickByJavascript(startingTime);
			inputText(startingTime, "1:15 AM");
			setTimeOut(2000);
   //end date not mandatory now
//			By endingDate = By.xpath(endDate);
//			waitAndVerifyElement(endingDate);
//			scrollToElement(endingDate);
//			inputText(endingDate, expirationDate);
//			setTimeOut(2000);
//
//			By endingTime = By.xpath(endTime);
//			waitAndVerifyElement(endingTime);
//			clickByJavascript(endingTime);
//			inputText(endingTime, "1:15 AM");
//			setTimeOut(2000);

			// Save
			By authorizationFieldSave = getDynamicElement(strAuthorizationieldButtons, "Save");
			waitAndVerifyElement(authorizationFieldSave);
			click(authorizationFieldSave);
			setTimeOut(4000);
			LoggingInfo("User clicks on Save button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to add CPE team member " + e.getMessage());
			Assert.fail("Failed to add CPE team member " + e.getMessage());
		}
	}

	public void saveAuthorizationFormConsentRecord() {

		try {

			// Name
			inputText(eleAuthrizationFieldsValueName, fullName);
			setTimeOut(2000);
			LoggingInfo("User enters name in the authorization form consent page");

			// Consent Giver
			By consentGiverRec = getDynamicElement(strSearchList, "Consent Giver");
			scrollToElement(consentGiverRec);
			waitAndVerifyElement(eleAuthorizationFormConsentGiverValue);
			setTimeOut(1000);
			inputText(eleAuthorizationFormConsentGiverValue, recName);
			setTimeOut(500);
			selectItemFromDropdown(strSearchList, strRelatedRec, "Consent Giver", "James Bob");
			LoggingInfo("User selects Consent Giver");
			setTimeOut(2000);

			// Authorization Form Text
			selectItemFromDropdown(strSearchList, strAuthorizationFormTxtListVal, "Authorization Form Text",
					"Dupixent Patient Authorization Form Text");
			LoggingInfo("User selects Authorization Form Text option from dropdown");
			setTimeOut(2000);

			// Consent Captured Source Type
			String[] sourceType = { "Written", "eSign", "Verbal" };
			String consentSourceType = sourceType[random.nextInt(sourceType.length)];
			selectItemFromDropdown(strAuthorizationFormStatusValue, strConsentCapListValue,
					"Consent Captured Source Type", consentSourceType);
			LoggingInfo("User selects Consent Captured Source Type option from dropdown");
			setTimeOut(2000);

			// Consent Captured Date Time

			int year = 2000 + random.nextInt(23);
			int month = 1 + random.nextInt(12);
			int day = 1 + random.nextInt(28);
			String consentCaptureDate = String.format("%02d/%02d/%02d", month, day, year);

			scrollToElement(eleAuthorizationConsentCapInput);
			setTimeOut(500);
			inputText(eleAuthorizationConsentCapInput, consentCaptureDate);
			setTimeOut(2000);
			LoggingInfo("User enters Consent Captured date");

			// Data Use Purpose
			selectItemFromDropdown(strSearchList, strDataUsePurListVal, "Data Use Purpose", "HIPAA Authorization");
			LoggingInfo("User selects Data Use Purpose option from dropdown");
			setTimeOut(2000);

			// Consent Expiration Date Time

			int yearE = 2000 + random.nextInt(23);
			int monthE = 1 + random.nextInt(12);
			int dayE = 1 + random.nextInt(28);
			String consentExpDate = String.format("%02d/%02d/%02d", monthE, dayE, yearE);

			inputText(eleAuthorizationConsentExpInput, consentExpDate);
			setTimeOut(2000);
			LoggingInfo("User enters Consent Expiration date");

			// Care Program
			By careProgram = getDynamicElement(serachDropDownListBox, "Care Program");
			scrollToElement(careProgram);
			setTimeOut(1000);
			click(careProgram);
			inputText(careProgram, "DMW EoE");
			setTimeOut(500);
			selectItemFromDropdown(serachDropDownListBox, strSearchDropDownOptions1, "Care Program", "DMW EoE");
			LoggingInfo("User selects care program");

			setTimeOut(2000);
			// Status
			By authorizationStatus = getDynamicElement(strAuthorizationFormStatusValue, "Status");
			scrollToElement(authorizationStatus);
			setTimeOut(1000);
			String[] status = {"Active","Withdrawn"};
			String consentStatus = status[random.nextInt(status.length)];
			selectItemFromDropdown(strAuthorizationFormStatusValue, strStatusListValue, "Status", consentStatus);
			LoggingInfo("User selects status option from dropdown");
			setTimeOut(2000);

			// Related Record
			By relatedRec = getDynamicElement(strSearchList, "Related Record");
			scrollToElement(relatedRec);
			setTimeOut(500);
			inputText(eleAuthorizationFormRelatedRecValue, "Automation");
			setTimeOut(500);
			click(eleAccount);
			LoggingInfo("User selects related record from the dropdown");
			setTimeOut(2000);

			// Save
			By authorizationFieldSave = getDynamicElement(strAuthorizationieldButtons, "Save");
			waitAndVerifyElement(authorizationFieldSave);
			click(authorizationFieldSave);
			setTimeOut(4000);
			LoggingInfo("User clicks on Save button");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Authorization page " + e.getMessage());
			Assert.fail("Failed to verify Authorization page " + e.getMessage());
		}
	}

	/**
	 * Function: verify TextMessaging Consent Record page field values
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void verifyTextMessagingConsentPageData(String patientName, String cpeRecord) {
		try {
			LoggingInfo("Verify the Text Messaging Consent page details");
			By fieldAuthFormText = getDynamicElement(strTextConsentForm, "Authorization Form Text");
			scrollToElement(fieldAuthFormText);
			String formtext = getText(fieldAuthFormText);
			Assert.assertEquals(formtext, "Dupixent Patient Authorization Form Text");

			By fieldConsentGiver = getDynamicElement(strTextConsentForm, "Consent Giver");
			scrollToElement(fieldConsentGiver);
			String givername = getText(fieldConsentGiver);
			Assert.assertEquals(givername, patientName);

			By fieldConsentType = getDynamicElement(strAccountObjectDetails, "Consent Captured Source Type");
			scrollToElement(fieldConsentType);
			String consentType = getText(fieldConsentType);
			Assert.assertEquals(consentType, "Verbal");

			By fieldRelatedRecord = getDynamicElement(strTextConsentForm, "Related Record");
			scrollToElement(fieldRelatedRecord);
			String relatedRecord = getText(fieldRelatedRecord);
			Assert.assertEquals(relatedRecord, patientName);

			By fieldDataUsePurpose = getDynamicElement(strTextConsentForm, "Data Use Purpose");
			scrollToElement(fieldDataUsePurpose);
			String dataUsePurpose = getText(fieldDataUsePurpose);
			Assert.assertEquals(dataUsePurpose, "Text Messaging Consent");

			By fieldName = getDynamicElement(strAccountObjectDetails, "Name");
			scrollToElement(fieldName);
			String nameFieldText = getText(fieldName);
			Assert.assertEquals(nameFieldText, patientName + " : Text Messaging Consent");

			By fieldStatus = getDynamicElement(strAccountObjectDetails, "Status");
			scrollToElement(fieldStatus);
			String status = getText(fieldStatus);
			Assert.assertEquals(status, "Active");

			By fieldCareProgram1 = getDynamicElement(strTextConsentForm, "Care Program");
			scrollToElement(fieldCareProgram1);
			String careProgramText = getText(fieldCareProgram1);
			Assert.assertEquals(careProgramText, cpeRecord);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify fields " + e.getMessage());
			Assert.fail("Failed to verify fields " + e.getMessage());
		}
	}

	/**
	 * Function: verify Copay Consent Record page field values
	 * 
	 * @author Sonica P
	 **/
	public void verifyCopayConsentPageData(String patientName, String cpeRecord) {
		try {
			LoggingInfo("Verify the Text Messaging Consent page details");
			By fieldAuthFormText = getDynamicElement(strTextConsentForm, "Authorization Form Text");
			scrollToElement(fieldAuthFormText);
			String formtext = getText(fieldAuthFormText);
			Assert.assertEquals(formtext, "Dupixent Patient Authorization Form Text");

			By fieldConsentGiver = getDynamicElement(strTextConsentForm, "Consent Giver");
			scrollToElement(fieldConsentGiver);
			String givername = getText(fieldConsentGiver);
			Assert.assertEquals(givername, patientName);

			By fieldConsentType = getDynamicElement(strAccountObjectDetails, "Consent Captured Source Type");
			scrollToElement(fieldConsentType);
			String consentType = getText(fieldConsentType);
			Assert.assertEquals(consentType, "Verbal");

			By fieldRelatedRecord = getDynamicElement(strTextConsentForm, "Related Record");
			scrollToElement(fieldRelatedRecord);
			String relatedRecord = getText(fieldRelatedRecord);
			Assert.assertEquals(relatedRecord, patientName);

			By fieldDataUsePurpose = getDynamicElement(strTextConsentForm, "Data Use Purpose");
			scrollToElement(fieldDataUsePurpose);
			String dataUsePurpose = getText(fieldDataUsePurpose);
			Assert.assertEquals(dataUsePurpose, "Copay Consent");

			By fieldName = getDynamicElement(strAccountObjectDetails, "Name");
			scrollToElement(fieldName);
			String nameFieldText = getText(fieldName);
			Assert.assertEquals(nameFieldText, patientName + " : Copay Consent");

			By fieldConsentCapturedDt = getDynamicElement(strAccountObjectDetails, "Consent Capture Date");
			scrollToElement(fieldConsentCapturedDt);
			String consentCapFieldText = getText(fieldConsentCapturedDt);
			Assert.assertEquals(consentCapFieldText, consentCapFieldText);

			By fieldConsentExpDt = getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time");
			scrollToElement(fieldConsentExpDt);
			String consentExpFieldText=getWebDriver().findElement(fieldConsentExpDt).getText();
		//	String consentExpFieldText = getText(fieldConsentExpDt);
		//	Assert.assertEquals(consentExpFieldText, "");

			By fieldStatus = getDynamicElement(strAccountObjectDetails, "Status");
			scrollToElement(fieldStatus);
			String status = getText(fieldStatus);
			Assert.assertEquals(status, "Active");

			By fieldCareProgram1 = getDynamicElement(strTextConsentForm, "Care Program");
			scrollToElement(fieldCareProgram1);
			String careProgramText = getText(fieldCareProgram1);
			Assert.assertEquals(careProgramText, cpeRecord);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify fields " + e.getMessage());
			Assert.fail("Failed to verify fields " + e.getMessage());
		}
	}

	/**
	 * Function: Create Authorization Consent Records for Open MI cases.
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void createAuthorizationRec(String name, String careprogram, String status, String dataUsePurpose,
			String consentGiver, String relatedRecName) {

		try {

			// // Name
			inputText(eleAuthrizationFieldsValueName, name);
			setTimeOut(2000);

			// Consent Giver
			By consentGiverRec = getDynamicElement(strSearchList, "Consent Giver");
			scrollToElement(consentGiverRec);
			waitAndVerifyElement(eleAuthorizationFormConsentGiverValue);
			setTimeOut(1000);
			inputText(eleAuthorizationFormConsentGiverValue, consentGiver);
			setTimeOut(500);
			selectItemFromDropdown(strSearchList, strRelatedRec1, "Consent Giver", consentGiver);
			setTimeOut(2000);

			// Authorization Form Text
			selectItemFromDropdown(strSearchList, strAuthorizationFormTxtListVal, "Authorization Form Text",
					"Dupixent Patient Authorization Form Text");
			setTimeOut(2000);

			// Consent Captured Source Type
			String[] sourceType = { "Written", "eSign", "Verbal" };
			String consentSourceType = sourceType[random.nextInt(sourceType.length)];
			selectItemFromDropdown(strAuthorizationFormStatusValue, strConsentCapListValue,
					"Consent Captured Source Type", consentSourceType);
			setTimeOut(2000);

			// Consent Captured Date Time

			int year = 2000 + random.nextInt(23);
			int month = 1 + random.nextInt(12);
			int day = 1 + random.nextInt(28);
			String consentCaptureDate = String.format("%02d/%02d/%02d", month, day, year);

			scrollToElement(eleAuthorizationConsentCapInput);
			setTimeOut(500);
			inputText(eleAuthorizationConsentCapInput, consentCaptureDate);
			setTimeOut(2000);
			// LoggingInfo("User enters Consent Captured date");

			// Data Use Purpose
			By xp = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//input[@placeholder='Search Data Use Purposes...']");
			inputText(xp, dataUsePurpose);
			setTimeOut(3000);
			String xppp = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//following-sibling::div//child::div//child::div//following-sibling::div[@role=\"listbox\"]//*[contains(text(),\"{1}\")]";
			selectItemFromDropdown(strSearchList, xppp, "Data Use Purpose", "Show");
			waitAndVerifyElement(eleSelectFirstHC);
			click(eleSelectFirstHC);
			scrollToElement(eleSelectButton);
			click(eleSelectButton);
			setTimeOut(2000);

			// Consent Expiration Date Time

			int yearE = 2000 + random.nextInt(23);
			int monthE = 1 + random.nextInt(12);
			int dayE = 1 + random.nextInt(28);
			String consentExpDate = String.format("%02d/%02d/%02d", monthE, dayE, yearE);

			inputText(eleAuthorizationConsentExpInput, consentExpDate);
			setTimeOut(2000);

			// Care Program
			By careProgram = getDynamicElement(serachDropDownListBox, "Care Program");
			scrollToElement(careProgram);
			setTimeOut(1000);
			click(careProgram);
			inputText(careProgram, careprogram);
			setTimeOut(500);
			selectItemFromDropdown(serachDropDownListBox, strSearchDropDownOptions1, "Care Program", careprogram);

			setTimeOut(2000);
			// Status
			By authorizationStatus = getDynamicElement(strAuthorizationFormStatusValue, "Status");
			scrollToElement(authorizationStatus);
			setTimeOut(1000);
			selectItemFromDropdown(strAuthorizationFormStatusValue, strStatusListValue1, "Status", status);
			setTimeOut(2000);

			// Related Record
			By relatedRec = getDynamicElement(strSearchList, "Related Record");
			scrollToElement(relatedRec);
			setTimeOut(500);
			inputText(eleAuthorizationFormRelatedRecValue, relatedRecName);
			setTimeOut(500);
			click(eleAccount);
			setTimeOut(2000);

			// Save
			By authorizationFieldSave = getDynamicElement(strAuthorizationieldButtons, "Save");
			waitAndVerifyElement(authorizationFieldSave);
			click(authorizationFieldSave);
			setTimeOut(4000);
			LoggingInfo(dataUsePurpose + " Consent record created successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to create Consent record " + e.getMessage());
			Assert.fail("Failed to create Consent record " + e.getMessage());
		}
	}

	/**
	 * Function: Update Gender in the Patient Account - details page
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void updateGender(String gender) throws Exception {
		try {
			By eleGender = getDynamicElement(strAuthorizationFormStatusValue, "Gender");
			scrollToElement(eleGender);
			setTimeOut(1000);
			selectItemFromDropdown(strAuthorizationFormStatusValue, strStatusListValue1, "Gender",
					gender);
			setTimeOut(2000);
			LoggingInfo("Gender is updated successfully");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to update Gender details " + e.getMessage());
			Assert.fail("Failed to update Gender details " + e.getMessage());
		}

	}

}
