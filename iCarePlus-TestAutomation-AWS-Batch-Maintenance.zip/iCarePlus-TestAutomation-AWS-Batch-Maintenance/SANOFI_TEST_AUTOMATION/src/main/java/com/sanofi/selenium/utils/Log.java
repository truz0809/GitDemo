package com.sanofi.selenium.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

public class Log {

	// Initialize Log4j logs
	private static Logger Log = (Logger) LogManager.getLogger(Log.class.getName());
	
	// *********************************************************************************************************
	// Function name: startTestCase()
	// Description: To print the Start of any test case in logs.
	// *********************************************************************************************************
	public static void startTestCase(String sTestCaseName) {

		Log.info("****************************************************************************************");
		Log.info("****************************************************************************************");
		Log.info("$$$$$$$$$$$$$$$$$$$$$                 " + sTestCaseName + "       $$$$$$$$$$$$$$$$$$$$$$$$$");
		Log.info("****************************************************************************************");
		Log.info("****************************************************************************************");

	}

	// *********************************************************************************************************
	// Function name: endTestCase()
	// Description: To print End of any test case in logs
	// *********************************************************************************************************
	public static void endTestCase(String sTestCaseName) {
		Log.info("XXXXXXXXXXXXXXXXXXXXXXX             " + "-E---N---D-" + "             XXXXXXXXXXXXXXXXXXXXXX");
		Log.info("X");
		Log.info("X");
		Log.info("X");
		Log.info("X");

	}

	// *********************************************************************************************************
	// Function name: endTestCase()
	// Description:  To print any information in the logs
	// *********************************************************************************************************
	public static void info(String message) {
		Log.info(message);
	}

	// *********************************************************************************************************
	// Function name: endTestCase()
	// Description: To print any warning messages in the logs
	// *********************************************************************************************************
	public static void warn(String message) {
		Log.warn(message);
	}

	// *********************************************************************************************************
	// Function name: endTestCase()
	// Description: To print the error messages in the logs
	// *********************************************************************************************************
	public static void error(String message) {
		Log.error(message);
	}

	// *********************************************************************************************************
	// Function name: endTestCase()
	// Description: To print any failue messages in the logs
	// *********************************************************************************************************
	public static void fatal(String message) {
		Log.fatal(message);
	}

	// *********************************************************************************************************
	// Function name: endTestCase()
	// Description: To print any debug messages in the logs
	// *********************************************************************************************************
	public static void debug(String message) {
		Log.debug(message);
	}

}

