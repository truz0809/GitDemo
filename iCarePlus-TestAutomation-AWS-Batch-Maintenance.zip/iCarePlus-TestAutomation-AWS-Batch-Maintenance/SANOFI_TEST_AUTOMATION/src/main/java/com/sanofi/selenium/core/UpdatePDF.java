package com.sanofi.selenium.core;

import com.itextpdf.forms.PdfAcroForm;
import com.itextpdf.forms.fields.PdfFormCreator;
import com.itextpdf.forms.fields.properties.CheckBoxType;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.forms.fields.PdfFormField;
import com.sanofi.selenium.constants.EnrollmentFormPDFConstants;
import com.sanofi.selenium.constants.EnrollmentFormExcelConstants;
import com.sanofi.selenium.constants.ExcelTestDataConstants;
import com.sanofi.selenium.utils.Log;
import com.sanofi.selenium.utils.ReadExcel;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

public class UpdatePDF extends Utility_Function
		implements ExcelTestDataConstants, EnrollmentFormPDFConstants, EnrollmentFormExcelConstants {

	public ReadExcel excel;
	public String currentDateTime;
	String enrollmentForm;

	private static final ThreadLocal<String> threadLocalUpdateName = new ThreadLocal<>();
	private static final ThreadLocal<String> threadLocalSrc = new ThreadLocal<>();
	private static final ThreadLocal<String> threadLocalDest = new ThreadLocal<>();
	private static final ThreadLocal<String> threadLocalTestCaseID = new ThreadLocal<>();
	private static final ThreadLocal<String> threadLocalEnrollmentForm = new ThreadLocal<>();
	private static final ThreadLocal<Map<String, String>> threadLocalExcelTestData = new ThreadLocal<>();
	private static final ThreadLocal<Map<String, String>> threadLocalTestData = new ThreadLocal<>();

	private static final Map<String, String> formTypeToFileNameMap = new HashMap<>();
	static {
		formTypeToFileNameMap.put("Nasal Polyps", "DMW-Nasal-Polyps-Enrollment-Form-English.pdf");
		formTypeToFileNameMap.put("Asthma", "DMW-Asthma-Enrollment-Form-English.pdf");
		formTypeToFileNameMap.put("EOE", "DMW-EoE-Enrollment-Form-English.pdf");
		formTypeToFileNameMap.put("Prurigo Nodularis", "DMW-Prurigo-Nodularis-Enrollment-Form-English.pdf");
		formTypeToFileNameMap.put("Atopic Dermatitis", "DMW-Atopic-Dermatitis-Enrollment-Form-English.pdf");
		formTypeToFileNameMap.put("COPD", "DMW-COPD-Enrollment-Form.pdf");
		formTypeToFileNameMap.put("BP", "DMW-BP-Enrollment-Form.pdf");
		formTypeToFileNameMap.put("CSU", "CSU-Enrollment-Form.pdf");
		
	}

	public UpdatePDF(WebDriver driver) {
		super(driver);

	}

	public void cleanupThreadLocals() {
		try {
			if (threadLocalTestCaseID != null) {
				threadLocalTestCaseID.remove();
			}
			if (threadLocalExcelTestData != null) {
				threadLocalExcelTestData.remove();
			}
			if (threadLocalUpdateName != null) {
				threadLocalUpdateName.remove();
			}
			if (threadLocalDest != null) {
				threadLocalDest.remove();
			}
		} catch (Exception e) {
			Log.warn("Error during ThreadLocal cleanup: " + e.getMessage());
		}
	}

	public String selectEnrollmentForm(String formType) {
		try {
			String fileName = formTypeToFileNameMap.get(formType);
			if (fileName != null) {
				String filePath = createFilePath(fileName);
				threadLocalSrc.set(filePath); // Use ThreadLocal
				threadLocalEnrollmentForm.set(formType); // Use ThreadLocal
				enrollmentForm = formType;
				return enrollmentForm;
			} else {
				Log.error("Enrollment form not selected. Form type not found: " + formType);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to select enrollment form. Error: " + e.getMessage());
		}
		return null;
	}

	private String createFilePath(String fileName) {
		return System.getProperty("user.dir") + "/TestData/Enrollment Forms/" + fileName;
	}

	public synchronized String PDFCreation(String testCaseID, String functionality) {
		try {
			// IMPORTANT: Clean ThreadLocals at the start of each test case
			cleanupThreadLocals();

			// Set current test case ID
			threadLocalTestCaseID.set(testCaseID);

			Map<String, String> functionalityToSheetName = createFunctionalityMap();
			String sheetName = functionalityToSheetName.get(functionality);
			excel = new ReadExcel(sheetName);
			Map<String, String> ExcelTestData = excel.getExcelInputData(testCaseID);
			threadLocalExcelTestData.set(ExcelTestData);

			// Validate that we got data for the correct test case
			if (ExcelTestData == null || ExcelTestData.isEmpty()) {
				throw new IllegalStateException(
						"No data found for testCaseID: " + testCaseID + " in sheet: " + sheetName);
			}

			// Log the patient name for verification
			String patientNameValue = ExcelTestData.get(patientName);
			Log.info("Retrieved data for testCaseID: " + testCaseID + ", Patient: " + patientNameValue);

			String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
			String patientFirstName = name[0];
			String patientLastName = name[2];
			String updateName = patientFirstName + patientLastName;
			threadLocalUpdateName.set(updateName);

			String value = getCurrentDateTime();
			String threadName = Thread.currentThread().getName().replaceAll("[^a-zA-Z0-9]", "_");
			String updatedValue = updateName + "_" + testCaseID + "_" + threadName + "_" + value;
			String dest = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
					+ "Updated Enrollment Forms" + File.separator + updatedValue + ".pdf";

			threadLocalDest.set(dest);
			Log.info("File created for testCaseID: " + testCaseID + dest);
			return dest;
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to update PDF name for testCaseID: " + testCaseID + " Error - " + e.getMessage());
			return null;
		}
	}
	
	public synchronized void updatePDFFormWithoutEdit(String testCaseID, String functionality) throws Exception {
		try {
			String currentTestCaseID = threadLocalTestCaseID.get();
			if (currentTestCaseID == null || !currentTestCaseID.equals(testCaseID)) {
				Log.warn("ThreadLocal testCaseID mismatch. Expected: " + testCaseID + ", Found: " + currentTestCaseID);
				PDFCreation(testCaseID, functionality);
			}

			String enrollmentformType = threadLocalEnrollmentForm.get();
			String dest = threadLocalDest.get();
			String src = threadLocalSrc.get();

			// Validate that all required ThreadLocal data is present
			if (enrollmentformType == null || dest == null || src == null) {
				throw new IllegalStateException("Missing ThreadLocal data for testCaseID: " + testCaseID
						+ ". enrollmentformType: " + enrollmentformType + ", dest: " + dest + ", src: " + src);
			}

			File file = new File(dest);
			file.getParentFile().mkdirs();

			Map<String, String> functionalityToSheetName = createFunctionalityMap();
			String sheetName = functionalityToSheetName.get(functionality);

			excel = new ReadExcel(sheetName);
			Map<String, String> testData = excel.getExcelInputData(testCaseID);
			threadLocalTestData.set(testData);

			// Log the patient name being processed for verification
			String patientNameFromData = testData.get(patientName);
			Log.info("Processing patient: " + patientNameFromData + " for testCaseID: " + testCaseID);

			PdfDocument pdfDoc = new PdfDocument(new PdfReader(src), new PdfWriter(dest));
			PdfAcroForm form = PdfFormCreator.getAcroForm(pdfDoc, true);

			form.setGenerateAppearance(true);
		//	updatePatientInformation(form);

			pdfDoc.close();

			Log.info("PDF updated successfully for testCaseID: " + testCaseID);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to update PDF form for testCaseID: " + testCaseID + " Error - " + e.getMessage());
			throw e;
		} finally {
			cleanupThreadLocals();
		}
	}

	public String getCurrentDateTime() {
		try {

			Date currentDate = new Date();

			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd mm_ss");

			currentDateTime = dateFormat.format(currentDate);
			// Log.info(currentDateTime);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to get current date and time" + "Error - " + e.getMessage());
		}

		return currentDateTime;

	}

	public synchronized void updatePDFForm(String testCaseID, String functionality) throws Exception {
		try {
			String currentTestCaseID = threadLocalTestCaseID.get();
			if (currentTestCaseID == null || !currentTestCaseID.equals(testCaseID)) {
				Log.warn("ThreadLocal testCaseID mismatch. Expected: " + testCaseID + ", Found: " + currentTestCaseID);
				PDFCreation(testCaseID, functionality);
			}

			String enrollmentformType = threadLocalEnrollmentForm.get();
			String dest = threadLocalDest.get();
			String src = threadLocalSrc.get();

			// Validate that all required ThreadLocal data is present
			if (enrollmentformType == null || dest == null || src == null) {
				throw new IllegalStateException("Missing ThreadLocal data for testCaseID: " + testCaseID
						+ ". enrollmentformType: " + enrollmentformType + ", dest: " + dest + ", src: " + src);
			}

			File file = new File(dest);
			file.getParentFile().mkdirs();

			Map<String, String> functionalityToSheetName = createFunctionalityMap();
			String sheetName = functionalityToSheetName.get(functionality);

			excel = new ReadExcel(sheetName);
			Map<String, String> testData = excel.getExcelInputData(testCaseID);
			threadLocalTestData.set(testData);

			// Log the patient name being processed for verification
			String patientNameFromData = testData.get(patientName);
			Log.info("Processing patient: " + patientNameFromData + " for testCaseID: " + testCaseID);

			PdfDocument pdfDoc = new PdfDocument(new PdfReader(src), new PdfWriter(dest));
			PdfAcroForm form = PdfFormCreator.getAcroForm(pdfDoc, true);

			form.setGenerateAppearance(true);
			updatePatientInformation(form);
			updateInsuranceInformation(form);
			updatePrescriberInformation(form);
			updateDiagnosisInformation(form);
			updatePrescriptionInformation(form);
			pdfDoc.close();

			Log.info("PDF updated successfully for testCaseID: " + testCaseID);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to update PDF form for testCaseID: " + testCaseID + " Error - " + e.getMessage());
			throw e;
		} finally {
			cleanupThreadLocals();
		}
	}

	private Map<String, String> createFunctionalityMap() {
		Map<String, String> functionalityToSheetName = new HashMap<>();
		functionalityToSheetName.put("Enrollment", "PDF_Data");
		functionalityToSheetName.put("Consent Management", "Consent_Management");
		functionalityToSheetName.put("MissingInformation", "MI_Management");
		functionalityToSheetName.put("Free Goods", "Free_Goods");
		functionalityToSheetName.put("DocumentManagement", "Doc_MGMNT");
		functionalityToSheetName.put("Fax", "Fax");
		functionalityToSheetName.put("AdminSetup", "AdminSetup");
		functionalityToSheetName.put("BenefitVerification", "BenefitVerification");
		functionalityToSheetName.put("CareProgram", "CareProgram");
		functionalityToSheetName.put("CopayWorkflow", "CopayWorkflow");
		functionalityToSheetName.put("DocDropPortal", "DocDropPortal");
		functionalityToSheetName.put("PARenewAppeal", "PARenewAppeal");
		functionalityToSheetName.put("PatientEducation", "PatientEducation");
		functionalityToSheetName.put("PatientEnrollment", "PatientEnrollment");
		functionalityToSheetName.put("ProgramAndCareTeamMGMNT", "ProgramAndCareTeamMGMNT");
		functionalityToSheetName.put("ReportsDashboard", "ReportsDashboard");
		functionalityToSheetName.put("RGNAlerts", "RGNAlerts");
		functionalityToSheetName.put("RGNAM", "RGNAM");
		functionalityToSheetName.put("RGNPhone", "RGNPhone");
		functionalityToSheetName.put("RGNTTP", "RGNTTP");
		functionalityToSheetName.put("SecurityAccessMgmnt", "SecurityAccessMgmnt");
		functionalityToSheetName.put("SpecialtyPharmacyDataDispenses", "SpecialtyPharmacyDataDispenses");
		functionalityToSheetName.put("TriageToPharmacy", "TriageToPharmacy");
		functionalityToSheetName.put("BenefitsVerificationWorkflow", "BenefitsVerificationWorkflow");
		functionalityToSheetName.put("IAPWorkflow", "IAPWorkflow");
		functionalityToSheetName.put("MissingInformationManagement", "MissingInformationManagement");
		functionalityToSheetName.put("PAPWorkflow", "PAPWorkflow");
		functionalityToSheetName.put("PriorAuthorizationWorkflow", "PriorAuthorizationWorkflow");
		functionalityToSheetName.put("QuickStartWorkFlow", "QuickStartWorkFlow");
		return functionalityToSheetName;
	}

	protected Map<String, String> getCurrentTestData() {
		return threadLocalTestData.get();
	}

	protected String getCurrentTestCaseID() {
		return threadLocalTestCaseID.get();
	}

	public void updatePatientInformation(PdfAcroForm form) {

		Map<String, String> data = threadLocalTestData.get();

		/******* PATIENT INFORMATION & AUTHORIZATIONS *******/
		List<String> inputBoxesToUse = enrollmentForm.equals("COPD") ? patientInfoInputBoxesCOPD
				: patientInfoInputBoxes;
		for (int i = 0; i < patientInfoInputBoxesExcel.size(); i++) {
			String excelValue = data.get(patientInfoInputBoxesExcel.get(i));
			if (excelValue != null && !excelValue.trim().isEmpty()) {
				form.getField(inputBoxesToUse.get(i)).setValue(excelValue);
			}
		}

		String genderValue = data.get(gender);
		List<String> genderListToUse = enrollmentForm.equals("COPD") ? patientGenderCOPD : patientGender;
		int genderIndex = genderValue.equalsIgnoreCase("Male") ? 0 : 1;
		PdfFormField field = form.getField(genderListToUse.get(genderIndex));
		field.setCheckType(CheckBoxType.CHECK);
		field.setValue(genderListToUse.get(genderIndex), true);
		String checkbox;
		for (int i = 0; i < patientInfoCheckBoxesExcel.size(); i++) {
			if (enrollmentForm.equals("COPD")) {
				checkbox = patientInfoChecktBoxesCOPD.get(i);
			} else {
				checkbox = patientInfoChecktBoxes.get(i);
			}
			String excelValue = data.get(patientInfoCheckBoxesExcel.get(i));

			if (excelValue != null && excelValue.trim().equalsIgnoreCase("True")) {
				setCheckBoxValue(form, checkbox);
			}

		}

		String patientDOBdt = data.get(patientDOB);
		String patientAuthorizationdt = data.get(patientAuthorizationDate);
		String patientCertificationsdt = data.get(patientCertificationsDate);

		if (patientDOBdt != null && !patientDOBdt.isEmpty()) {
			String[] patientDOBdate = updatepdf.splitDate(patientDOBdt);
			if (enrollmentForm.equals("COPD")) {
				updatepdf.setFieldValues(form, patientInformationDOBCOPD, patientDOBdate);
			} else {
				updatepdf.setFieldValues(form, patientInformationDOB, patientDOBdate);
			}
		}

		if (patientAuthorizationdt != null && !patientAuthorizationdt.isEmpty()) {
			String[] patientAuthoDT = updatepdf.splitDate(patientAuthorizationdt);
			if (enrollmentForm.equals("COPD")) {
				updatepdf.setFieldValues(form, patientInformationAuthSignCOPD, patientAuthoDT);
			} else {
				updatepdf.setFieldValues(form, patientInformationAuthSign, patientAuthoDT);
			}
		}

		if (patientCertificationsdt != null && !patientCertificationsdt.isEmpty()) {
			String[] patientCertiDT = updatepdf.splitDate(patientCertificationsdt);
			if (enrollmentForm.equals("COPD")) {
				updatepdf.setFieldValues(form, patientInformationCertSignCOPD, patientCertiDT);
			} else {
				updatepdf.setFieldValues(form, patientInformationCertSign, patientCertiDT);
			}
		}

		String primaryPhn = formatPhoneNumber(data.get(patientPrimaryphone));
		String seconPhn = formatPhoneNumber(data.get(patientSecondaryphone));

		if (primaryPhn != null && !primaryPhn.isEmpty()) {
			String[] primaryPHN = updatepdf.splitPhoneNumber(primaryPhn);
			if (enrollmentForm.equals("COPD")) {
				updatepdf.setFieldValues(form, patientPriPhnCOPD, primaryPHN);
			} else {
				updatepdf.setFieldValues(form, patientPriPhn, primaryPHN);
			}
		}

		if (seconPhn != null && !seconPhn.isEmpty()) {
			String[] secPHN = updatepdf.splitPhoneNumber(seconPhn);
			if (enrollmentForm.equals("COPD")) {
				updatepdf.setFieldValues(form, patientSecPhnCOPD, secPHN);
			} else {
				updatepdf.setFieldValues(form, patientSecPhn, secPHN);
			}
		}
	}

	public void updateInsuranceInformation(PdfAcroForm form) {
		Map<String, String> data = threadLocalTestData.get();
		/******* INSURANCE INFORMATION *******/

		List<String> inputBoxesToUse = enrollmentForm.equals("COPD") ? patientInsInputBoxesCOPD : patientInsInputBoxes;

		for (int i = 0; i < patientInsuranceInputBoxesExcel.size(); i++) {
			String excelKey = patientInsuranceInputBoxesExcel.get(i);
			String excelValue = data.get(excelKey);

			if (excelValue != null && !excelValue.trim().isEmpty()) {
				form.getField(inputBoxesToUse.get(i)).setValue(excelValue);
			} else {
				Log.info("Skipped null/empty field: " + excelKey);
			}
		}

		// RX Phone
		String rxPhn = formatPhoneNumber(data.get(rxPhone));
		if (rxPhn != null && !rxPhn.trim().isEmpty()) {
			String[] rxPHN = updatepdf.splitPhoneNumber(rxPhn);
			if (enrollmentForm.equals("COPD")) {
				updatepdf.setFieldValues(form, rxphoneCOPD, rxPHN);
			} else {
				updatepdf.setFieldValues(form, rxphone, rxPHN);
			}
		} else {
			Log.info("Skipped null/empty RX Phone");
		}

		// Medical Phone
		String medPhn = formatPhoneNumber(data.get(medicalPhone));
		if (medPhn != null && !medPhn.trim().isEmpty()) {
			String[] medPHN = updatepdf.splitPhoneNumber(medPhn);
			if (enrollmentForm.equals("COPD")) {
				updatepdf.setFieldValues(form, medphoneCOPD, medPHN);
			} else {
				updatepdf.setFieldValues(form, medphone, medPHN);
			}
		} else {
			Log.info("Skipped null/empty Medical Phone");
		}

		// Pharmacy Phone
		String pharmacyPhn = formatPhoneNumber(data.get(pharmacyPhone));
		if (pharmacyPhn != null && !pharmacyPhn.trim().isEmpty()) {
			String[] pharmacyPHN = updatepdf.splitPhoneNumber(pharmacyPhn);
			if (enrollmentForm.equals("COPD")) {
				updatepdf.setFieldValues(form, pharmphoneCOPD, pharmacyPHN);
			} else {
				updatepdf.setFieldValues(form, pharmphone, pharmacyPHN);
			}
		} else {
			Log.info("Skipped null/empty Pharmacy Phone");
		}

		// Pharmacy Fax
		String pharmacyFax = formatPhoneNumber(data.get(pharmacyfax));
		if (pharmacyFax != null && !pharmacyFax.trim().isEmpty()) {
			String[] pharmacyFAX = updatepdf.splitPhoneNumber(pharmacyFax);
			if (enrollmentForm.equals("COPD")) {
				updatepdf.setFieldValues(form, pharmfaxCOPD, pharmacyFAX);
			} else {
				updatepdf.setFieldValues(form, pharmfax, pharmacyFAX);
			}
		} else {
			Log.info("Skipped null/empty Pharmacy Fax");
		}

		// Checkboxes
		for (int i = 0; i < patientInsuranceCheckBoxesExcel.size(); i++) {
			String excelValue = data.get(patientInsuranceCheckBoxesExcel.get(i));
			String checkbox = enrollmentForm.equals("COPD") ? patientInsuranceCheckBoxesCOPD.get(i)
					: patientInsuranceCheckBoxes.get(i);

			if (excelValue != null && excelValue.trim().equalsIgnoreCase("True")) {
				setCheckBoxValue(form, checkbox);
			} else {
				Log.info("Skipped checkbox (not true or null): " + patientInsuranceCheckBoxesExcel.get(i));
			}
		}
	}

	public void updatePrescriberInformation(PdfAcroForm form) {
		Map<String, String> data = threadLocalTestData.get();

		/******* PRESCRIBER INFORMATION *******/

		List<String> inputBoxesToUse = enrollmentForm.equals("COPD") ? prescriberInfoInputBoxesCOPD
				: prescriberInfoInputBoxes;

		for (int i = 0; i < prescriberInputBoxesExcel.size(); i++) {
			String fieldName = inputBoxesToUse.get(i);
			String value = data.get(prescriberInputBoxesExcel.get(i));

			if (value != null && !value.trim().isEmpty()) {
				PdfFormField field = form.getField(fieldName);
				if (field != null) {
					field.setValue(value.trim());
				} else {
					Log.info("Field not found: " + fieldName);
				}
			} else {
				Log.info("Skipped null/empty field: " + prescriberInputBoxesExcel.get(i));
			}
		}

		// Office Phone
		String prescriberPhn = formatPhoneNumber(data.get(officePhone));
		if (prescriberPhn != null && !prescriberPhn.isEmpty()) {
			String[] prescriberPHN = updatepdf.splitPhoneNumber(prescriberPhn);
			if (enrollmentForm.equals("COPD")) {
				updatepdf.setFieldValues(form, prescriberphoneCOPD, prescriberPHN);
			} else {
				updatepdf.setFieldValues(form, prescriberphone, prescriberPHN);
			}
		} else {
			Log.info("Skipped null/empty Office Phone");
		}

		// Office Fax
		String prescriberFax = formatPhoneNumber(data.get(officeFax));
		if (prescriberFax != null && !prescriberFax.isEmpty()) {
			String[] prescriberFAX = updatepdf.splitPhoneNumber(prescriberFax);
			if (enrollmentForm.equals("COPD")) {
				updatepdf.setFieldValues(form, prescriberfaxCOPD, prescriberFAX);
			} else {
				updatepdf.setFieldValues(form, prescriberfax, prescriberFAX);
			}
		} else {
			Log.info("Skipped null/empty Office Fax");
		}
	}

	public void updateDiagnosisInformation(PdfAcroForm form) {

	    Map<String, String> data = threadLocalTestData.get();
	    
	    if (data == null) {
	        System.out.println("ThreadLocal data is null, skipping diagnosis information update");
	        return;
	    }

	    /******* DIAGNOSIS INFORMATION *******/

	    String diagnosisdt = data.get(dateOfDiagnosis);
	    if (diagnosisdt != null && !diagnosisdt.trim().isEmpty()) {
	        String[] diagnosisdate = updatepdf.splitDate(diagnosisdt.trim());
	        if (enrollmentForm.equals("COPD")) {
	            updatepdf.setFieldValues(form, diagnosisDateCOPD, diagnosisdate);
	        } else {
	            updatepdf.setFieldValues(form, diagnosisDate, diagnosisdate);
	        }
	    }

	    String diagnosisCODE = data.get(diagnosisCode);
	    
	    if (diagnosisCODE == null || diagnosisCODE.trim().isEmpty()) {
	        Log.info("Diagnosis Code is null or empty, skipping diagnosis code processing");
	    } else {
	        diagnosisCODE = diagnosisCODE.trim();

	        switch (enrollmentForm) {
	            case "Nasal Polyps":
	                if (diagnosisCODE.equalsIgnoreCase("J33.9 - Nasal polyps, unspecified")) {
	                    setCheckBoxValue(form, nasalDiagnoisCode.get(0));
	                } else if (diagnosisCODE.equalsIgnoreCase("J33.0 - Polyp of nasal cavity")) {
	                    setCheckBoxValue(form, nasalDiagnoisCode.get(1));
	                } else {
	                    setCheckBoxValue(form, nasalDiagnoisCode.get(2));
	                    if (form.getField(nasalDiagnoisCode.get(3)) != null) {
	                        form.getField(nasalDiagnoisCode.get(3)).setValue(diagnosisCODE);
	                    }
	                }
	                break;

	            case "Asthma":
	                if (diagnosisCODE.equalsIgnoreCase("J45.50 - Severe persistent asthma, uncomplicated")) {
	                    setCheckBoxValue(form, asthamaDiagnoisCode.get(0));
	                } else if (diagnosisCODE.equalsIgnoreCase("J45.40 - Moderate persistent asthma, uncomplicated")) {
	                    setCheckBoxValue(form, asthamaDiagnoisCode.get(1));
	                } else if (diagnosisCODE.equalsIgnoreCase("Z79.51 - Oral Corticosteroid")) {
	                    setCheckBoxValue(form, asthamaDiagnoisCode.get(2));
	                } else if (diagnosisCODE.equalsIgnoreCase("L82.89 - Eosinophilic Phenotype")) {
	                    setCheckBoxValue(form, asthamaDiagnoisCode.get(3));
	                } else {
	                    setCheckBoxValue(form, asthamaDiagnoisCode.get(4));
	                    if (form.getField(asthamaDiagnoisCode.get(5)) != null) {
	                        form.getField(asthamaDiagnoisCode.get(5)).setValue(diagnosisCODE);
	                    }
	                }
	                break;

	            case "EOE":
	                if (diagnosisCODE.equalsIgnoreCase("K20.0 - Eosinophilic esophagitis")) {
	                    setCheckBoxValue(form, eoeDiagnoisCode.get(0));
	                } else {
	                    setCheckBoxValue(form, eoeDiagnoisCode.get(1));
	                    if (form.getField(eoeDiagnoisCode.get(2)) != null) {
	                        form.getField(eoeDiagnoisCode.get(2)).setValue(diagnosisCODE);
	                    }
	                }
	                break;

	            case "Prurigo Nodularis":
	                if (diagnosisCODE.equalsIgnoreCase("L28.1 - Prurigo nodularis")) {
	                    setCheckBoxValue(form, nodularisDiagnoisCode.get(0));
	                } else {
	                    setCheckBoxValue(form, nodularisDiagnoisCode.get(1));
	                    if (form.getField(nodularisDiagnoisCode.get(2)) != null) {
	                        form.getField(nodularisDiagnoisCode.get(2)).setValue(diagnosisCODE);
	                    }
	                }
	                break;

	            case "Atopic Dermatitis":
	                if (diagnosisCODE.equalsIgnoreCase("L20.9 - Atopic dermatitis, unspecified")) {
	                    setCheckBoxValue(form, dermatisDiagnoisCode.get(0));
	                } else if (diagnosisCODE.equalsIgnoreCase("L20.89 - Other atopic dermatitis")) {
	                    setCheckBoxValue(form, dermatisDiagnoisCode.get(1));
	                } else {
	                    setCheckBoxValue(form, dermatisDiagnoisCode.get(2));
	                    if (form.getField(dermatisDiagnoisCode.get(3)) != null) {
	                        form.getField(dermatisDiagnoisCode.get(3)).setValue(diagnosisCODE);
	                    }
	                }
	                break;

	            case "COPD":
	                if (diagnosisCODE.equalsIgnoreCase("J44 Other chronic obstructive pulmonary disease")) {
	                    setCheckBoxValue(form, copdDiagnoisCode.get(0));
	                } else {
	                    setCheckBoxValue(form, copdDiagnoisCode.get(1));
	                    if (form.getField(copdDiagnoisCode.get(2)) != null) {
	                        form.getField(copdDiagnoisCode.get(2)).setValue(diagnosisCODE);
	                    }
	                }
	                break;
	        }
	    }

	    // Eosinophil count - only for COPD
	    if (enrollmentForm.equals("COPD")) {
	        String countValue = data.get(count);
	        if (countValue != null && !countValue.trim().isEmpty()) {
	            PdfFormField countField = form.getField("Eosinophil count - Page 2");
	            if (countField != null) {
	                countField.setValue(countValue.trim());
	            } else {
	            	Log.info("Missing field: Eosinophil count - Page 2");
	            }
	        }
	    }
	}

	public void updatePrescriptionInformation(PdfAcroForm form) {

		Map<String, String> data = threadLocalTestData.get();

		/******* PRESCRIPTION INFORMATION *******/

		// Process input boxes
		for (int i = 0; i < prescriptionInfoInputBoxesExcel.size(); i++) {
			String excelValue = data.get(prescriptionInfoInputBoxesExcel.get(i));
			if (excelValue != null && !excelValue.trim().isEmpty()) {
				if (enrollmentForm.equals("Nasal Polyps")) {
					form.getField(prescriptionInfoInputBoxesNasal.get(i)).setValue(excelValue.trim());
				} else if (enrollmentForm.equals("Asthma")) {
					form.getField(prescriptionInfoInputBoxesAsthama.get(i)).setValue(excelValue.trim());
				} else if (enrollmentForm.equals("EOE")) {
					form.getField(prescriptionInfoInputBoxesEOE.get(i)).setValue(excelValue.trim());
				} else if (enrollmentForm.equals("Prurigo Nodularis")) {
					form.getField(prescriptionInfoInputBoxesNodularis.get(i)).setValue(excelValue.trim());
				} else if (enrollmentForm.equals("Atopic Dermatitis")) {
					form.getField(prescriptionInfoInputBoxesdermatis.get(i)).setValue(excelValue.trim());
				} else if (enrollmentForm.equals("COPD")) {
					form.getField(prescriptionInfoInputBoxesCOPD.get(i)).setValue(excelValue.trim());
				}
			}
		}

		// Process checkboxes
		for (int i = 0; i < prescriptionInfoCheckBoxesExcel.size(); i++) {
			String excelValue = data.get(prescriptionInfoCheckBoxesExcel.get(i));
			if ("True".equalsIgnoreCase(excelValue)) {
				if (enrollmentForm.equals("Nasal Polyps")) {
					setCheckBoxValues(form, prescriptionInfoCheckBoxesNasal, prescriptionInfoCheckBoxesNasal);
				} else if (enrollmentForm.equals("Asthma")) {
					setCheckBoxValues(form, prescriptionInfoCheckBoxesAstma, prescriptionInfoCheckBoxesNasal);
				} else if (enrollmentForm.equals("EOE")) {
					setCheckBoxValues(form, prescriptionInfoCheckBoxesEOE, prescriptionInfoCheckBoxesNasal);
				} else if (enrollmentForm.equals("Prurigo Nodularis")) {
					setCheckBoxValues(form, prescriptionInfoCheckBoxesNodularis, prescriptionInfoCheckBoxesNodularis);
				} else if (enrollmentForm.equals("Atopic Dermatitis")) {
					setCheckBoxValues(form, prescriptionInfoCheckBoxesdermatis, prescriptionInfoCheckBoxesdermatis);

				}
			}

			// Process sample provided dates
			String aSampleDate = data.get(aSampleProvidedDate);
			if (aSampleDate != null && !aSampleDate.trim().isEmpty()) {
				String[] aSampleDT = updatepdf.splitDate(aSampleDate.trim());
				if (enrollmentForm.equals("Nasal Polyps")) {
					updatepdf.setFieldValues(form, sampleProvidedDateANasal, aSampleDT);
				} else if (enrollmentForm.equals("Asthma")) {
					updatepdf.setFieldValues(form, sampleProvidedDateAAsthma, aSampleDT);
				} else if (enrollmentForm.equals("EOE")) {
					updatepdf.setFieldValues(form, sampleProvidedDateAEOE, aSampleDT);
				} else if (enrollmentForm.equals("Prurigo Nodularis")) {
					updatepdf.setFieldValues(form, sampleProvidedDateANodularis, aSampleDT);
				} else if (enrollmentForm.equals("Atopic Dermatitis")) {
					updatepdf.setFieldValues(form, sampleProvidedDateAdermatis, aSampleDT);
				}
			}

			String bSampleDate = data.get(bSampleProvidedDate);
			if (bSampleDate != null && !bSampleDate.trim().isEmpty()) {
				String[] bSampleDT = updatepdf.splitDate(bSampleDate.trim());
				if (enrollmentForm.equals("Nasal Polyps")) {
					updatepdf.setFieldValues(form, sampleProvidedDateBNasal, bSampleDT);
				} else if (enrollmentForm.equals("Asthma")) {
					updatepdf.setFieldValues(form, sampleProvidedDateBAsthma, bSampleDT);
				} else if (enrollmentForm.equals("EOE")) {
					updatepdf.setFieldValues(form, sampleProvidedDateBEOE, bSampleDT);
				} else if (enrollmentForm.equals("Prurigo Nodularis")) {
					updatepdf.setFieldValues(form, sampleProvidedDateBNodularis, bSampleDT);
				} else if (enrollmentForm.equals("Atopic Dermatitis")) {
					updatepdf.setFieldValues(form, sampleProvidedDateBdermatis, bSampleDT);

				}
			}

			// Process prescriber signature date
			String presSign = data.get(prescriberSignatureDate);
			if (presSign != null && !presSign.trim().isEmpty()) {
				String[] presSignDT = updatepdf.splitDate(presSign.trim());
				if (enrollmentForm.equals("Nasal Polyps")) {
					updatepdf.setFieldValues(form, presSIGNNasal, presSignDT);
				} else if (enrollmentForm.equals("Asthma")) {
					updatepdf.setFieldValues(form, presSIGNAsthma, presSignDT);
				} else if (enrollmentForm.equals("EOE")) {
					updatepdf.setFieldValues(form, presSIGNEOE, presSignDT);
				} else if (enrollmentForm.equals("Prurigo Nodularis")) {
					updatepdf.setFieldValues(form, presSIGNNodularis, presSignDT);
				} else if (enrollmentForm.equals("Atopic Dermatitis")) {
					updatepdf.setFieldValues(form, presSIGNdermatis, presSignDT);
				} else if (enrollmentForm.equals("COPD")) {
					updatepdf.setFieldValues(form, presSIGNCOPD, presSignDT);
				}
			}

			// Process substitution signature date
			String subSign = data.get(substitutionsDate);
			if (subSign != null && !subSign.trim().isEmpty()) {
				String[] subSignDT = updatepdf.splitDate(subSign.trim());
				if (enrollmentForm.equals("Nasal Polyps")) {
					updatepdf.setFieldValues(form, subSIGNNasal, subSignDT);
				} else if (enrollmentForm.equals("Asthma")) {
					updatepdf.setFieldValues(form, subSIGNAsthma, subSignDT);
				} else if (enrollmentForm.equals("EOE")) {
					updatepdf.setFieldValues(form, subSIGNEOE, subSignDT);
				} else if (enrollmentForm.equals("Prurigo Nodularis")) {
					updatepdf.setFieldValues(form, subSIGNNodularis, subSignDT);
				} else if (enrollmentForm.equals("Atopic Dermatitis")) {
					updatepdf.setFieldValues(form, subSIGNdermatis, subSignDT);
				}
			}
		}
	}

}
