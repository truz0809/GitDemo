package com.sanofi.selenium.testutils;

import io.github.classgraph.ClassGraph;
import io.github.classgraph.ClassInfo;
import io.github.classgraph.ScanResult;
import org.testng.annotations.Test;

import java.lang.reflect.Method;

public class TestNGReflection {

    public static void main(String[] args) {
        String packageName = "com.sanofi.selenium.Regression";

        try (ScanResult scanResult = new ClassGraph()
                .enableAllInfo()
                .acceptPackages(packageName)
                .scan()) {

            for (ClassInfo classInfo : scanResult.getAllClasses()) {
                Class<?> clazz = classInfo.loadClass();
                System.out.println(clazz.getName());

                for (Method method : clazz.getDeclaredMethods()) {
                    if (method.isAnnotationPresent(Test.class)) {
                        System.out.println(method.getName());
                    }
                }
            }
        }
    }
}
