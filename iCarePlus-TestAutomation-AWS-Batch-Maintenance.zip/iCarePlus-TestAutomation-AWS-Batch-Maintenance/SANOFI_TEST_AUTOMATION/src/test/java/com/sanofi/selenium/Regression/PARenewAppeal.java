package com.sanofi.selenium.Regression;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.utils.ReadExcel;

public class PARenewAppeal extends BaseTest {
	private static ThreadLocal<String> filePath = new ThreadLocal<>();
	public ReadExcel excel;
	public String fileName;
	String functionality = "PARenewAppeal";

	@BeforeMethod
	public void setUp() {
		docMgmt = GetInstance(DocumentManagementPage.class);
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		sheetName = "PARenewAppeal";
		excel = new ReadExcel(sheetName);
		uploadDocs = GetInstance(UploadDocument.class);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	@Test(description = "SIT_Prior Authorization Workflow Patient Enrollment Prerequisites", enabled = true, priority = 27)
	public String PriorAuthorizationWorkflow_PatientEnrollment_Prerequisites_QuickStartYes(String testCaseNumber)
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testCaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 3.1:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 2.3:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.2:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.3:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.verifyAndClickOnRecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		// homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		return ID;

	}

	@Test(description = "SIT_Prior Authorization Workflow Patient Enrollment Prerequisites", enabled = true, priority = 27)
	public String PriorAuthorizationWorkflow_PatientEnrollment_Prerequisites_DMWYES_SPNO_QuickStartNO(
			String testCaseNumber) throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testCaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		String removeColumnData[] = { "Prescription-B RefillCaptured", "Prescription-5B Dose" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 3.1:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 2.3:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.2:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.3:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.verifyAndClickOnRecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		// homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		return ID;

	}

	@Test(description = "SIT_Prior Authorization Workflow Patient Enrollment Prerequisites", enabled = true)
	public String PAWorkflow_PatientEnrollment_Prerequisites(String testcaseNumber) throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 3.1:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 2.3:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.2:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.3:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects a valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String CPEURL = getCurrentPageURL();
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();

		Logger("STEP 16: Search CPE");
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		return CPEURL;

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-3137 Validate the Mark the PA/Appeal CPE Work Order
	 * Outcome as Withdrawn From PA Task
	 * 
	 * @author Anand Pawar
	 *         ====================================================================================================================
	 * @throws Exception
	 */

	@Test(description = "ICARE-8479_Regression-PA,Renew,Appeal:Automate ICARE-3137 - Validate the Mark the PA/Appeal CPE Work Order Outcome as Withdrawn From PA Task", enabled = true)
	public void PA01_IC3137_Validate_Mark_PAAppeal_CPE_Work_Order_Outcome_as_Withdrawn_From_PATask() throws Exception {

		String TestCaseNumber = "TC1";

		// Prerequisites
		String ID = PAWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("STEP 1:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String name = ExcelTestData.get(patientName);
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		Logger("Pre-requisites 2.5: Verify BV Task is initiated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 11: User Logout the Application.");
		documentsPage.logout();

		// case manager
		Logger("STEP 12: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 15: Validate user is able to access PA/Appeals CPE work order, Record is on PA/Appeals Work Order");
		paAppealsPage.verifyPATaskInitiated();

		Logger("STEP 16: Validate that user is able to view the below mentioned tasks on the right side of the page");
		paAppealsPage.checkPATaskInitiation();
		paAppealsPage.clickOnTask();

		Logger("STEP 17.: Validate that user is able to fill all the mandatory fields in PAAppeal details");
		paAppealsPage.enterPAAppealDetails(StatusCheck.get(1), payerContact.get(0), receiptRequired.get(0),
				attempts.get(0), ExcelTestData.get(rxPayerName), pAOutcomeOptions.get(1), PAOutcomeReason.get(0), "",
				hcpFollowUpRequired.get(0));
		paAppealsPage.validatePAAppealSection(true);

		Logger("STEP 17.1: Fill all the mandatory fields and click on SAVE button.");
		paAppealsPage.selectOutcomeReason(PAOutcomeReason.get(0));
		paAppealsPage.enterPAAppealAndApprovedDetails(numberOfInjectionsUsed, paEffectiveDate, paDosage.get(0),
				paExpirationDate, numberOfInjectionsApproved);
		paAppealsPage.clickOnSave();
		refresh();

		Logger("STEP 18: Navigate to Prior Auth task and click on the HCP Follow up Task and fill the details Outcome as Withdrawn");
		paAppealsPage.clickOnPATask();
		paAppealsPage.clickOnHCPTask();
		paAppealsPage.enterReasonForFollowUpDetails(StatusCheck.get(1), reasonForHCPFollowupOutcomeOptions.get(4),
				reasonForHCPFollowupOutcomeReason.get(1), null);

		paAppealsPage.enterHCPFollowUpDetailsIntent(hcpContact.get(0), attempts.get(0), hcpOfficeContactName,
				intentOfSubmission.get(1));

		Logger("STEP 19: User click on Save.");
		paAppealsPage.clickOnSave();
		refresh();

		Logger("STEP 20: User click on PA/Appeal Task");
		paAppealsPage.clickOnPATask();

		Logger("STEP 21: Navigate PA Summary task and verify subtask is not generated");
		paAppealsPage.verifyPASummarySectionNotGenerated();

		Logger("STEP 22: Logout as a case manager.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-2811 Validate User can initiate 3rd Level appeal
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "TC01 - Validate User can initiate 3rd Level appeal", enabled = true)
	public void PA02_IC2811_Validate_User_can_initiate_3rd_Level_appeal() throws Exception {

		String TestCaseNumber = "TC2";

		// Prerequisites
		String CPEUrl = PAWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("STEP 19: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		navigateToUrl(CPEUrl);
//
//		Logger("STEP 20: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
//		homeportalPage.closeTabs();
//		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

//		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecordByLink();
//		assessmentTasksPage.openCPETask(createdDate);

//		String url = "https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf0000005c7tCAA/view";
//		navigateToUrl(url);

		// Benefits Verification
		Logger("STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		Logger("STEP 28: Click on PA/Appeal work order ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 29: Enter and details on PA/ Appeal Details section ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(1), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(1), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReasonAddInfo(pAOutcomeOptions.get(1), PAOutcomeReason.get(0),
				AdditionalInfoRequired.get(1));

		String effectiveDate = Utility_Function.getNthDayFromToday(10);
		String expirationDate = Utility_Function.getNthDayFromToday(15);
		paAppealsPage.enterMandatoryPAApprovedDetails(effectiveDate, paDosage.get(0), expirationDate);
		careProgram.clickOnSave();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 9: Logout as a BV specialist from the Org..");
		documentsPage.logout();

		Logger("STEP 10: Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 35: Navigate to PA summary task \"Communicate Results & Send SOB\" ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(1));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 36: Enter details in HCP Contact details section ");
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		String intendedDate = Utility_Function.getNthDayFromToday(10);
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));

		Logger("STEP 37: Select Outcome as \"Denied \" and \"Proceed with Appeals\" is marked as \"Yes\" click on save button");
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 38: Navigate to 1st level of appeals Tasks \"Follow up on results\"");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(2));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 39: Enter and save details in follow up on results task");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(1), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(1), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(1), PAOutcomeReason.get(0));
		paAppealsPage.enterMandatoryPAApprovedDetails(effectiveDate, paDosage.get(0), expirationDate);
		careProgram.clickOnSave();
		refresh();

		Logger("STEP 40: Navigate to 1st level of appeals Tasks \"Communicate Results & Send SOB\" ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(3));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 41: Select Outcome as \"Denied \" and \"Proceed with Appeals\" is marked as \"Yes\" click on save button ");
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 42: Navigate to 2nd level of appeals Tasks \"Follow up on results\"");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(4));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 43: Enter details on Follow-up on Results ");
		paAppealsPage.enterMandatoryPAAppealDetailsfor2ndAppeal(paStatus.get(1), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(1), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(1), PAOutcomeReason.get(0));
		paAppealsPage.enterMandatoryPAApprovedDetails(effectiveDate, paDosage.get(0), expirationDate);
		careProgram.clickOnSave();
		refresh();

		Logger("STEP 44: Navigate to 2nd level of appeals Tasks \"Communicate Results & Send SOB\"");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(5));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 45: Select Outcome as \"Denied \" and \"Proceed with Appeals\" is marked as \"Yes\" click on save button");
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 46: Verify that when the 3rd level Appeals Tasks are created");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(6));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 47: \"Follow-up on Results\" task has \"Next Follow Up Date\" of 10 business days from the completion of \"Communicate Results and Send SOB\" step of 2nd Level of Appeal tasks");
		paAppealsPage.validateNextFollowUpDate();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-2918 Initiation of 1st Appeal task form BV flow
	 * 
	 * @author Kavyashree , Test case - Updated by Trupti
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "TC03-Initiation of 1st Appeal task form BV flow", enabled = true)
	public void PA03_IC2918_validate_Initiation_Of_1stAppeal_Task_From_BV_Flow() throws Exception {

		String TestCaseNumber = "TC3";

		// Prerequisites
		String ID = PAWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("STEP 19: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 20: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

//		String url2 = "https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf0000005GovCAE/view";
//		navigateToUrl(url2);

		// Benefits Verification
		Logger("STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(2));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		Logger("STEP 28: Navigate to PA/Appeal task and validate 1st level appeal task are created ");
		paAppealsPage.verifyPATaskInitiated();
		careProgram.checkTaskInitiation(paMainTaskNames.get(2), paSubTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 28: Verify the \"Follow-up on Results\"  task has next follow up date as 10 business days.");
		paAppealsPage.validateNextFollowUpDate();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 11: User Logout the Application.");
		documentsPage.logout();

		// case manager
		Logger("STEP 12: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);

		Logger("STEP 28: Validate PA tasks are not created , all task are created and are of 1st level appeal.");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(2));
		careProgram.clickOnMainTask(paMainTaskNames.get(3));
		paAppealsPage.validatePATaskAreNotCreated();

		Logger("STEP 11: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-3056 Validate BV user can mark PA/Appeals CPE workorder as
	 * Completed form Follow up on Result task on PA
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "ICARE-8480-Regression-PA,Renew,Appeal: Automate ICARE-3056 - Validate BV user can mark PA/Appeals CPE workorder as Completed form Follow up on Result task on PA", enabled = true)
	public void PA04_IC3056_ValidateBVUser_Mark_PAAppeal_CPEWork_Order_Complete_From_Follow_Up_On_ResultTask()
			throws Exception {

		String TestCaseNumber = "TC4";

		// Prerequisites
		String CPEURL = PAWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("STEP 1: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		navigateToUrl(CPEURL);

//		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
//		homeportalPage.closeTabs();
//		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);
//
//		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);

		// Benefits Verification
		Logger("STEP 5: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 6: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 5: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 26: Login to the QA_SIT Org as 'Case manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		// PA-Appeal
		Logger("STEP 8: Click on PA/Appeal work order and select Prior Auth ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 9: Validate that user is able to validate outcome 'unable to determine outcome' option and 'Payer Outcome Not available' as outcome reason ");
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(6), PAOutcomeReason.get(2)); // method
		refresh();

		Logger("STEP 11: Click on PA/Appeal work order and select Prior Auth ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 11.1: Enter and details on PA/ Appeal Details section with attempt as 1 and status in progress ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(1), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(0), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(0), PAOutcomeReason.get(0));
		paAppealsPage.clickOnSave();
		refresh();

		Logger("STEP 11.2: Click on PA/Appeal work order and select Prior Auth ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 11.3: Enter and details on PA/ Appeal Details section with attempt as 2 and status in progress ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(1), attempts.get(1),
				hcpFollowUpRequired.get(0), receiptRequired.get(0), ExcelTestData.get(policyholderName));
		paAppealsPage.clickOnSave();
		refresh();

		Logger("STEP 11.4: Click on PA/Appeal work order and select Prior Auth ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 11.5: Enter and details on PA/ Appeal Details section with attempt as 3 and status in progress/complete ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(1), payerContact.get(1), attempts.get(2),
				hcpFollowUpRequired.get(0), receiptRequired.get(0), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(6), PAOutcomeReason.get(2));
		paAppealsPage.clickOnSave();
		refresh();

		Logger("STEP 12: Click on PA/Appeal work order ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));

		Logger("STEP 13: Navigate PA Summary task and verify subtask is not generated");
		paAppealsPage.verifyPASummarySectionNotGenerated();

		Logger("STEP 14: Validate the PA/Appeal Work Order is marked as Completed");
		paAppealsPage.verifyPACompleteStatus();

		Logger("STEP 19: Validate for HCP follow up Task created when user have marked 'HCP follow up required' is marked as yes");
		paAppealsPage.validateHCPTaskCreated();

		Logger("STEP 20: Logout as a case manager.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-2878 Validate “Follow-Up on Results” task is created as
	 * part of the Appeal Tasks in the PA/ Appeals CPE Work Order
	 * 
	 * @author Shanavaz N
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "ICARE-TC01_Validate “Follow-Up on Results” task is created as part of the Appeal Tasks in the PA/ Appeals CPE Work Order", enabled = true)
	public void PA05_IC2878_Validate_Follow_Up_on_Results_task_is_created_as_part_of_the_AppealTasks_in_the_PAAppeals_CPE_Work_Order()
			throws Exception {

		String TestCaseNumber = "TC5";

		// Prerequisites
		String CPEURL = PAWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("STEP 19: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		navigateToUrl(CPEURL);

//		Logger("STEP 20: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
//		homeportalPage.closeTabs();
//		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);
//
//		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);

		// Benefits Verification
		Logger("STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 26: Login to the QA_SIT Org as 'Case manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);
		Logger("STEP 28: Click on PA/Appeal work order ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 29: Enter and details on PA/ Appeal Details section ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(1), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(1), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(1), PAOutcomeReason.get(0));
		String effectiveDate = Utility_Function.getNthDayFromToday(10);
		String expirationDate = Utility_Function.getNthDayFromToday(15);
		paAppealsPage.enterMandatoryPAApprovedDetails(effectiveDate, paDosage.get(0), expirationDate);
		careProgram.clickOnSave();
		refresh();

		// CPE URL
		String url1 = getCurrentPageURL();

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 26: Login to the QA_SIT Org as 'Case manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url1);
		Thread.sleep(4000);

		// Validation for 1st 2nd and 3rd Level Appeal Tasks
		for (int i = 0; i < 3; i++) {
			Logger(" STEP 4: Navigate to PA summary task \"Communicate Results & Send SOB\" ");

			careProgram.clickOnWorkOrderTask(workOrderName.get(1));
			careProgram.clickOnMainTask(paAppealSummaryTasks.get(i));
			careProgram.clickOnSubTask(paSubTaskNames.get(1));

			Logger("STEP 4.1: Enter details in HCP Contact details section ");
			paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
					attempts.get(0), intentOfSubmission.get(0));
			String intendedDate = Utility_Function.getNthDayFromToday(10);
			paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));

			Logger("STEP 5: Select Outcome as \"Denied \" and \"Proceed with Appeals\" is marked as \"Yes\" click on save button");
			paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(1));
			careProgram.clickOnSave();
			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
			refresh();

			Logger("STEP 5.1: Navigate to 1st level of appeals Tasks \"Follow up on results\"");
			careProgram.clickOnWorkOrderTask(workOrderName.get(1));
			careProgram.clickOnMainTask(paAppealTasks.get(i));
			careProgram.clickOnSubTask(paSubTaskNames.get(0));

			Logger("STEP 6: Enter and save details in follow up on results task");
			paAppealsPage.validatePAAppealFollowUpResultSection(true);

			Logger("Step 7: Verify When 'Outcome' is Approved, PA/ Appeals Approved section would appear");
			paAppealsPage.selectOutcome(pAOutcomeOptions.get(1));
			paAppealsPage.validatePAAppealSection(true);

			Logger("Step 8: Verify When 'Outcome' is Denied, PA/ Appeals Denied section would appear");
			paAppealsPage.selectOutcome(pAOutcomeOptions.get(2));
			paAppealsPage.validatePAAppealDeniedSection(true);

			Logger("Step 9: Verify When 'Outcome'is Pending, PA/ Appeals Pending section would appear");
			paAppealsPage.selectOutcome(pAOutcomeOptions.get(3));
			paAppealsPage.validatePAAppealPendingSection(true);

			Logger("Step 10: Validate CM can view Patient & HCP/HCO Information cards while performing the ‘Follow up on Results’ step.");
			paAppealsPage.validateHCPInformationCardPresent();
			paAppealsPage.validateHCOInformationCardPresent();

			Logger("Step 11: Validate that when \"Outcome\" is Pending in the \"PA/ Appeals details\" section, CM User is not able to mark the task as complete.");
			paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(1), payerContact.get(0), attempts.get(0),
					hcpFollowUpRequired.get(0), receiptRequired.get(1), ExcelTestData.get(policyholderName));
			paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(3), PAOutcomeReason.get(0));
			paAppealsPage.clickOnSave();
			paAppealsPage.verifyErrorMessage();

			Logger("Step 12:Validate when user marks HCP follow up as required new task of HCP follow up is created. ");
			paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(1), PAOutcomeReason.get(0));
			paAppealsPage.enterMandatoryPAApprovedDetails(effectiveDate, paDosage.get(0), expirationDate);
			careProgram.clickOnSave();
			refresh();

			Logger("STEP 12.1: Navigate to \"HCP Follow Up\" tasks");
			careProgram.clickOnWorkOrderTask(workOrderName.get(1));
			careProgram.clickOnMainTask(paAppealTasks.get(i));
			careProgram.clickOnSubTask(paSubTaskNames.get(2));
			paAppealsPage.validateHCPTaskCreated();

			Logger("Step 13: Verify the fields and layout of HCP Follow up Layout ");
			paAppealsPage.validateHCPFollowUpSection(true);

			Logger("STEP 14: Enter and save details in HCP follow up task");
			paAppealsPage.enterHCPFollowUpDetails(paStatus.get(1), attempts.get(0), hcpContact.get(1));
			careProgram.clickOnSave();

		}

		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5721 Triggering BV flow via Start New Service button when
	 * (PA Outcome is Approved and Outcome is Covered with restrictions, Outcome
	 * reason is PA required)
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "ICARE-8484-Regression-PA,Renew,Appeal: Automate ICARE-5721 - Triggering BV flow via Start New Service button when (PA Outcome is Approved and Outcome is Covered with restrictions, Outcome reason is PA required)", enabled = true, priority = 23)
	public void PA06_IC5721_Triggering_BV_flow_via_Start_New_Service_Button_When_PAOutcome_Approved_Outcome_Covered_With_Restrictions_OutcomeReasonPARequired()
			throws Exception {

		String TestCaseNumber = "TC6";

		// Prerequisites
		String CPEURL = PAWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("STEP 1: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

//		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
//		homeportalPage.closeTabs();
//		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);
//
//		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);

		navigateToUrl(CPEURL);

		// Benefits Verification
		Logger("STEP 5: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 6: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 7: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(1));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 26: Login to the QA_SIT Org as 'Case manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 14: Click on start new service and select service as PA/Appeal and select reason");
		iapPage.clickOnStartNewService();
		iapPage.verifyServiceTitle();
		paAppealsPage.selectPAAppealsService();
		missingInformatioPage.clickNextButton();
		paAppealsPage.selectPAAppealsReason();

		Logger("STEP 15: Click on save and refresh the page");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 16: Navigate to PA/Appeals and verify subtasks Prior Auth and PA Summary");
		paAppealsPage.verifyPATaskInitiated();
		paAppealsPage.checkPATaskInitiation();
		refresh();

		Logger("STEP 17: Click on PA/Appeal work order and select Prior Auth ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 18: Enter and details on PA/ Appeal Details and status in progress ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(1), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(0), ExcelTestData.get(policyholderName));
		String DenialDate = Utility_Function.getNthDayFromToday(0);
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));

		Logger("STEP 19: Enter Denial details on PA/ Appeal Details ");
		paAppealsPage.enterMandatoryPAAppealDeniedDetails(proceedWithAppeal.get(1), DenialDate);

		Logger("STEP 20: Save PA/ Appeal Details ");
		careProgram.clickOnSave();
		refresh();

		Logger("STEP 21: Click on PA/Appeal work order and select Prior Auth ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 22: Enter and details on PA/ Appeal Details and status as completed ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(1), payerContact.get(1), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(0), ExcelTestData.get(policyholderName));

		Logger("STEP 23: Save PA/ Appeal Prior Auth Details ");
		careProgram.clickOnSave();
		refresh();

		Logger("STEP 24: Validate for HCP follow up Task created when user have marked 'HCP follow up required' is marked as yes");
		paAppealsPage.validateHCPTaskInitiatedStatusAsNotStarted();
		refresh();

		Logger("STEP 25: Click on PA/Appeals ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));

		Logger("STEP 26: Validate outcome 'Denied' and Outcome Reason 'Medical Necessity' is auto populated");
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		refresh();

		Logger("STEP 27: Click on PA/Appeal work ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));

		Logger("STEP 28: Enter HCP Follow Up section details and Save it");
		paAppealsPage.verifyAndEnterHCPFollowUpDetails(StatusCheck.get(1), attempts.get(0), hcpContact.get(1));

		Logger("STEP 29: Logout as a case manager.");
		documentsPage.logout();

		// BV User
		Logger("Validate that HCP Follow up task is created every time the BV specialist marks \"HCP Follow up Required\" as yes");

		Map<String, String> ExceltestData = new HashMap<String, String>();
		String TestcaseNumber = "TC7";
		String CPEURL2 = PAWorkflow_PatientEnrollment_Prerequisites(TestcaseNumber);
		ExceltestData = excel.getExcelInputData(TestcaseNumber);
		String accontName = ExceltestData.get(patientName);
		String cpEName = accontName + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("STEP 30: Login as 'BV Specialist' User ");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
//
//		Logger("STEP 31: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
//		homeportalPage.closeTabs();
//		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);
//
//		Logger("STEP 32: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 33: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createDate = assessmentTasksPage.verifyAndAssignCPERecord(ID2);
//		assessmentTasksPage.openCPETask(createDate);

		navigateToURL(CPEURL2);

		// Benefits Verification
		Logger("STEP 34: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 35.1: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 35.2: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		refresh();

		Logger("STEP 35.3: Open BV summary section");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(1));
		careProgram.clickOnSubTask(bvSubTaskNames.get(1));

		Logger("STEP 35.4: Enter details in Review and Send Summary of Benefits");
		bvPage.enterDetailsOnBVOutcome(outComeOptions.get(1), outComeReasonOptions.get(1));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExceltestData.get(patientName));
		refresh();

		// PA-Appeal starts here
		Logger("STEP 36: Click on PA/Appeal work order and select Prior Auth ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 37: Enter and details on PA/ Appeal Details section with attempt as 1 and status in progress ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(1), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(0), ExceltestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(0), PAOutcomeReason.get(0));
		paAppealsPage.clickOnSave();
		refresh();

		Logger("STEP 37.1: Click on PA/Appeal work order and select Prior Auth ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 37.2: Enter and details on PA/ Appeal Details section with attempt as 2 and status in progress ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(1), attempts.get(1),
				hcpFollowUpRequired.get(0), receiptRequired.get(0), ExceltestData.get(policyholderName));
		paAppealsPage.clickOnSave();
		refresh();

		Logger("STEP 37.3 Click on PA/Appeal work order and select Prior Auth ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 37.4: Enter and details on PA/ Appeal Details section with attempt as 3 and status in progress ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(1), attempts.get(2),
				hcpFollowUpRequired.get(0), receiptRequired.get(0), ExceltestData.get(policyholderName));
		paAppealsPage.clickOnSave();
		refresh();

		Logger("STEP 37.5: Validate no HCP Follow up task present/visible as BV User ");
		paAppealsPage.validateHCPTaskNotInitiated();

		Logger("STEP 38: Logout as a BV user.");
		documentsPage.logout();

		// cm user
		Logger("STEP 39: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 40: Open ICARE Connect App from the App launcher.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 41: User should be able to view the Recently View List of care program enrollees.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		documentsPage.searchDocument(cpEName);
		missingInformatioPage.clickOnRecord(cpEName);

		Logger("STEP 42:User should be able to validate multiple HCP Follow Up tasks created ");
		paAppealsPage.validateMultipleHCPFollowUpTaskCreated();
		refresh();

		Logger("STEP 43:Click on PA/Appeal ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));

		Logger("STEP 44: User should be able to complete HCP Follow up task only as a CM user ");
		paAppealsPage.verifyAndEnterHCPFollowUpDetails(StatusCheck.get(1), attempts.get(0), hcpContact.get(1));
		refresh();
		paAppealsPage.checkPATaskCompletion(paMainTaskNames.get(0), paSubTaskNames.get(3));

		Logger("STEP 45: Logout as CM user");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-3809 Validate Appeal task's are mapped from the value
	 * populated in PA task when PA outcome is Not on file
	 * 
	 * @author Trupti Zure
	 *         ====================================================================================================================
	 */

	@Test(description = "TC07 -Validate Appeal task's are mapped from the value populated in PA task when outcome is not on file ", enabled = true)
	public void PA07_IC3809_Validate_Appeal_tasks_are_mapped_from_the_value_populated_in_PA_task_PAOutcome_NotOnFile()
			throws Exception {

		String TestCaseNumber = "TC7";

		// Prerequisites
		String ID = PAWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("STEP 19: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 20: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		// Benefits Verification
		Logger("STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));

		Logger("STEP 25: fill in the details on below mentioned fields PA required as yes and when Outcome is not on file below are the Fields visible on BV");
		bvPage.openSection(sectionNames.get(1));
		bvPage.enterDataInPARequiredNotOnFile(processor, method.get(0), electronicsite, submissionChannel.get(0),
				ExcelTestData.get(officePhone), faxedToMDO.get(0), ExcelTestData.get(officeFax), turnAroundTime.get(0),
				additionalDocReq.get(0), submissionChannel.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		Logger("STEP 28: Click on PA/Appeal work order ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 29: Open \"Follow up on Results\" task and validate below mentioned fields are pre populated as given in BV taskMark status as in progress and HCP follow up required as Yes and click on save ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.selectOutcomeReason(PAOutcomeReason.get(0));
		paAppealsPage.validatePARequiredInputValues(processor, electronicsite, ExcelTestData.get(officePhone),
				ExcelTestData.get(officeFax));
		paAppealsPage.verifyDropdownValue("Method for obtaining form", method.get(0));
		paAppealsPage.verifyDropdownValue("Submission Channel", submissionChannel.get(0));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(0), PAOutcomeReason.get(0));
		careProgram.clickOnSave();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 30: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 31: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 35: open HCP follow up task ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));

		Logger("STEP 35: validate below values are mapped from follow up on result task Additional documents required(visible on follow up on result outcome is pending) Pending Reason (Outcome Reason) ");
		paAppealsPage.validateReasonToFollowUpValues(PAOutcomeReason.get(0), additionalDocReq.get(0),
				pAOutcomeOptions.get(0));
		paAppealsPage.selectDropdownValue("Status", paStatus.get(1));
		paAppealsPage.enterHCPFollowUpDetailsIntent(hcpContact.get(1), attempts.get(0),
				ExcelTestData.get(officeContactName), intentOfSubmission.get(1));
		careProgram.clickOnSave();

		Logger("STEP 36: Follow up on result task and change status to completed with outcome as denied ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));
		paAppealsPage.changeStatusToCompleted(StatusCheck.get(1));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		String deniedDate = Utility_Function.getNthDayFromToday(10);
		paAppealsPage.enterValuesForPADenial(deniedDate, proceedWithAppeal.get(0), nextSteps.get(0),
				levelOfAppeal.get(2), notifiedDenial.get(0));
		careProgram.clickOnSave();

		Logger("STEP 37: Navigate to PA summary task \"Communicate Results & Send SOB\" ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(1));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 38: On Communication Results and send SOB task of PA validate below values are mapped from follow up on result task Provider notified of the denial? (visible on follow up on result task when outcome is denied ) Outcome Reason");
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.verifyValueOfDropDownBox("Provider notified of the denial?", notifiedDenial.get(0));
		String intendedDate = Utility_Function.getNthDayFromToday(10);
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 39: Open \"Follow up on Results\" task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(2));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 40: validate below mentioned fields are pre populated as given in PA task to 1 level appeal mark status as in progress outcome as pending click on save ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.selectOutcomeReason(PAOutcomeReason.get(0));
		paAppealsPage.validatePARequiredInputValues(processor, electronicsite, ExcelTestData.get(officePhone),
				ExcelTestData.get(officeFax));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(0), PAOutcomeReason.get(0));
		careProgram.clickOnSave();

		Logger("STEP 41: Create a HCP follow up task and validate below values are mapped from follow up on result task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(2));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));
		paAppealsPage.validateReasonToFollowUpValues(PAOutcomeReason.get(0), additionalDocReq.get(0),
				pAOutcomeOptions.get(0));
		paAppealsPage.selectDropdownValue("Status", paStatus.get(1));
		paAppealsPage.enterHCPFollowUpDetailsIntent(hcpContact.get(1), attempts.get(0),
				ExcelTestData.get(officeContactName), intentOfSubmission.get(1));
		careProgram.clickOnSave();

		Logger("STEP 42: Open follow up on result task of 1 level appeal and select outcome as Denied and status as Completed click on Save button");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(2));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));
		paAppealsPage.changeStatusToCompleted(StatusCheck.get(1));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.enterValuesForPADenial(deniedDate, proceedWithAppeal.get(0), nextSteps.get(0),
				levelOfAppeal.get(2), notifiedDenial.get(0));
		paAppealsPage.selectDropdownValue("Submission Channel", submissionChannel.get(1));
		paAppealsPage.inputValue("Average Outcome Time (in days)", avgOutcomeTime.get(2));
		careProgram.clickOnSave();

		Logger("STEP 43: Open Communication Results and send SOB task ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(3));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 44: On Communication Results and send SOB task of PA validate below values are mapped from follow up on result task Provider notified of the denial? (visible on follow up on result task when outcome is denied ) Outcome Reason");
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.verifyValueOfDropDownBox("Provider notified of the denial?", notifiedDenial.get(0));
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 45: Open \"Follow up on Results\" task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(4));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 46: validate below mentioned fields are pre populated as given in 1st level appeal to 2nd level appeal");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.validatePARequiredInputValues(processor, electronicsite, ExcelTestData.get(officePhone),
				ExcelTestData.get(officeFax));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.validateValuesForPADenial(deniedDate, proceedWithAppeal.get(0), nextSteps.get(0),
				levelOfAppeal.get(2), notifiedDenial.get(0));
		careProgram.clickOnSave();

		Logger("STEP 47: Create a HCP follow up task and validate below values are mapped from follow up on result task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(4));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.selectDropdownValue("Status", paStatus.get(1));
		paAppealsPage.enterHCPFollowUpDetailsIntent(hcpContact.get(1), attempts.get(0),
				ExcelTestData.get(officeContactName), intentOfSubmission.get(1));
		careProgram.clickOnSave();

		Logger("STEP 48: Open follow up on result task and mark status as completed");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(4));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));
		paAppealsPage.changeStatusToCompleted(StatusCheck.get(1));
		careProgram.clickOnSave();

		Logger("STEP 49: Open Communication Results and send SOB task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(5));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 50: On Communication Results and send SOB task of PA validate below values are mapped from follow up on result task Provider notified of the denial? (visible on follow up on result task when outcome is denied ) Outcome Reason");
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.verifyValueOfDropDownBox("Provider notified of the denial?", notifiedDenial.get(0));
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 51: Open \"Follow up on Results\" task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(6));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 52: validate below mentioned fields are pre populated as given in 2nd level appeal to 3rd level appeal");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.validatePARequiredInputValues(processor, electronicsite, ExcelTestData.get(officePhone),
				ExcelTestData.get(officeFax));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.validateValuesForPADenial(deniedDate, proceedWithAppeal.get(0), nextSteps.get(0),
				levelOfAppeal.get(2), notifiedDenial.get(0));
		careProgram.clickOnSave();

		Logger("STEP 53: Create a HCP follow up task and validate below values are mapped from follow up on result task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(6));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.selectDropdownValue("Status", paStatus.get(1));
		paAppealsPage.enterHCPFollowUpDetailsIntent(hcpContact.get(1), attempts.get(0),
				ExcelTestData.get(officeContactName), intentOfSubmission.get(1));
		careProgram.clickOnSave();

		Logger("STEP 54: Open follow up on result mark status as completed");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(6));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));
		paAppealsPage.changeStatusToCompleted(StatusCheck.get(1));
		careProgram.clickOnSave();

		Logger("STEP 55: Open Communication Results and send SOB task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(7));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 56: On Communication Results and send SOB task of PA validate below values are mapped from follow up on result task Provider notified of the denial? (visible on follow up on result task when outcome is denied ) Outcome Reason");
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.verifyValueOfDropDownBox("Provider notified of the denial?", notifiedDenial.get(0));
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 57: User Logout the Application.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-3809 Validate Appeal task's are mapped from the value
	 * populated in PA task when PA outcome is pending
	 * 
	 * @author Trupti Zure
	 *         ====================================================================================================================
	 */
	@Test(description = "TC07 -Validate Appeal task's are mapped from the value populated in PA task ", enabled = true)
	public void PA08_IC3809_Validate_Appeal_tasks_are_mapped_from_the_value_populated_in_PA_task_PAOutcome_Pending()
			throws Exception {

		String TestCaseNumber = "TC8";

		// Prerequisites
		String ID = PAWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("STEP 19: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 20: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		// Benefits Verification
		Logger("STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(3));

		Logger("STEP 25: fill in the details on below mentioned fields PA required as yes and when Outcome is Pending below are the Fields visible on BV");
		bvPage.openSection(sectionNames.get(0));
		bvPage.enterDataInPARequiredPending(processor, authorization, electronicsite, ExcelTestData.get(officePhone),
				ExcelTestData.get(officeFax), pendingReason.get(0), additionalDocReq.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		Logger("STEP 28: Click on PA/Appeal work order ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 29: Open \"Follow up on Results\" task and validate below mentioned fields are pre populated as given in BV taskMark status as in progress and HCP follow up required as Yes and click on save ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.validatePARequiredInputValues(processor, electronicsite, ExcelTestData.get(officePhone),
				ExcelTestData.get(officeFax));
		paAppealsPage.validatePARequiredDropDownValues(pendingReason.get(0), additionalDocReq.get(0),
				pAOutcomeOptions.get(3));
		paAppealsPage.selectDropdownValue("Next Follow up Time", nextFollowupTime.get(0));
		careProgram.clickOnSave();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 30: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 31: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 35: open HCP follow up task ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));

		Logger("STEP 35: validate below values are mapped from follow up on result task Additional documents required(visible on follow up on result outcome is pending) Pending Reason (Outcome Reason) ");
		paAppealsPage.validateReasonToFollowUpValues(pendingReason.get(0), additionalDocReq.get(0),
				pAOutcomeOptions.get(3));
		paAppealsPage.selectDropdownValue("Status", paStatus.get(1));
		paAppealsPage.enterHCPFollowUpDetailsIntent(hcpContact.get(1), attempts.get(0),
				ExcelTestData.get(officeContactName), intentOfSubmission.get(1));
		careProgram.clickOnSave();

		Logger("STEP 36: Follow up on result task and change status to completed with outcome as denied ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));
		paAppealsPage.changeStatusToCompleted(StatusCheck.get(1));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		String deniedDate = Utility_Function.getNthDayFromToday(10);
		paAppealsPage.enterValuesForPADenial(deniedDate, proceedWithAppeal.get(0), nextSteps.get(0),
				levelOfAppeal.get(2), notifiedDenial.get(0));
		paAppealsPage.selectDropdownValue("Submission Channel", submissionChannel.get(1));
		paAppealsPage.inputValue("Average Outcome Time (in days)", avgOutcomeTime.get(2));
		careProgram.clickOnSave();

		Logger("STEP 37: Navigate to PA summary task \"Communicate Results & Send SOB\" ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(1));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 38: On Communication Results and send SOB task of PA validate below values are mapped from follow up on result task Provider notified of the denial? (visible on follow up on result task when outcome is denied ) Outcome Reason");
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.verifyValueOfDropDownBox("Provider notified of the denial?", notifiedDenial.get(0));
		String intendedDate = Utility_Function.getNthDayFromToday(10);
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 39: Open \"Follow up on Results\" task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(2));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 40: validate below mentioned fields are pre populated as given in PA task to 1 level appeal mark status as in progress outcome as pending click on save ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.validatePARequiredInputValues(processor, electronicsite, ExcelTestData.get(officePhone),
				ExcelTestData.get(officeFax));
		paAppealsPage.validatePARequiredDropDownValues(pendingReason.get(0), additionalDocReq.get(0),
				pAOutcomeOptions.get(3));
		paAppealsPage.selectDropdownValue("Next Follow up Time", nextFollowupTime.get(0));
		careProgram.clickOnSave();

		Logger("STEP 41: Create a HCP follow up task and validate below values are mapped from follow up on result task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(2));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));
		paAppealsPage.validateReasonToFollowUpValues(pendingReason.get(0), additionalDocReq.get(0),
				pAOutcomeOptions.get(3));
		paAppealsPage.selectDropdownValue("Status", paStatus.get(1));
		paAppealsPage.enterHCPFollowUpDetailsIntent(hcpContact.get(1), attempts.get(0),
				ExcelTestData.get(officeContactName), intentOfSubmission.get(1));
		careProgram.clickOnSave();

		Logger("STEP 42: Open follow up on result task of 1 level appeal and select outcome as Denied and status as Completed click on Save button");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(2));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));
		paAppealsPage.changeStatusToCompleted(StatusCheck.get(1));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.enterValuesForPADenial(deniedDate, proceedWithAppeal.get(0), nextSteps.get(0),
				levelOfAppeal.get(2), notifiedDenial.get(0));
		paAppealsPage.selectDropdownValue("Submission Channel", submissionChannel.get(1));
		paAppealsPage.inputValue("Average Outcome Time (in days)", avgOutcomeTime.get(2));
		careProgram.clickOnSave();

		Logger("STEP 43: Open Communication Results and send SOB task ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(3));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 44: On Communication Results and send SOB task of PA validate below values are mapped from follow up on result task Provider notified of the denial? (visible on follow up on result task when outcome is denied ) Outcome Reason");
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.verifyValueOfDropDownBox("Provider notified of the denial?", notifiedDenial.get(0));
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 45: Open \"Follow up on Results\" task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(4));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 46: validate below mentioned fields are pre populated as given in 1st level appeal to 2nd level appeal");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.validatePARequiredInputValues(processor, electronicsite, ExcelTestData.get(officePhone),
				ExcelTestData.get(officeFax));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.validateValuesForPADenial(deniedDate, proceedWithAppeal.get(0), nextSteps.get(0),
				levelOfAppeal.get(2), notifiedDenial.get(0));
		careProgram.clickOnSave();

		Logger("STEP 47: Create a HCP follow up task and validate below values are mapped from follow up on result task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(4));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.selectDropdownValue("Status", paStatus.get(1));
		paAppealsPage.enterHCPFollowUpDetailsIntent(hcpContact.get(1), attempts.get(0),
				ExcelTestData.get(officeContactName), intentOfSubmission.get(1));
		careProgram.clickOnSave();

		Logger("STEP 48: Open follow up on result task and mark status as completed");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(4));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));
		paAppealsPage.changeStatusToCompleted(StatusCheck.get(1));
		careProgram.clickOnSave();

		Logger("STEP 49: Open Communication Results and send SOB task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(5));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 50: On Communication Results and send SOB task of PA validate below values are mapped from follow up on result task Provider notified of the denial? (visible on follow up on result task when outcome is denied ) Outcome Reason");
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.verifyValueOfDropDownBox("Provider notified of the denial?", notifiedDenial.get(0));
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 51: Open \"Follow up on Results\" task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(6));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 52: validate below mentioned fields are pre populated as given in 2nd level appeal to 3rd level appeal");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.validatePARequiredInputValues(processor, electronicsite, ExcelTestData.get(officePhone),
				ExcelTestData.get(officeFax));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.validateValuesForPADenial(deniedDate, proceedWithAppeal.get(0), nextSteps.get(0),
				levelOfAppeal.get(2), notifiedDenial.get(0));
		careProgram.clickOnSave();

		Logger("STEP 53: Create a HCP follow up task and validate below values are mapped from follow up on result task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(6));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.selectDropdownValue("Status", paStatus.get(1));
		paAppealsPage.enterHCPFollowUpDetailsIntent(hcpContact.get(1), attempts.get(0),
				ExcelTestData.get(officeContactName), intentOfSubmission.get(1));
		careProgram.clickOnSave();

		Logger("STEP 54: Open follow up on result mark status as completed");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(6));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));
		paAppealsPage.changeStatusToCompleted(StatusCheck.get(1));
		careProgram.clickOnSave();

		Logger("STEP 55: Open Communication Results and send SOB task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(7));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 56: On Communication Results and send SOB task of PA validate below values are mapped from follow up on result task Provider notified of the denial? (visible on follow up on result task when outcome is denied ) Outcome Reason");
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		paAppealsPage.verifyValueOfDropDownBox("Provider notified of the denial?", notifiedDenial.get(0));
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 57: User Logout the Application.");
		documentsPage.logout();
	}

	@Test(description = "TC 01- PA outcome is determined as withdrawn since HCP withdraws intent of submission during HCP Follow up Task", enabled = true)
	public void PA09_IC4938_validate_PA_Outcome_Is_Determined_As_Withdrawn() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC9";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "FALSE" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 3.1:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 3.2:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.2:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.3:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		// homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		documentsPage.searchDocument(cpeName);
		missingInformatioPage.clickOnRecord(cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 20: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		// Benefits Verification
		Logger("STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		Logger("STEP 28: Click on PA/Appeal work order ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 29: Enter and details on PA/ Appeal Details section ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(1), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(0), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(1), PAOutcomeReason.get(0));
		String effectiveDate = Utility_Function.getNthDayFromToday(10);
		String expirationDate = Utility_Function.getNthDayFromToday(15);
		paAppealsPage.enterMandatoryPAApprovedDetails(effectiveDate, paDosage.get(0), expirationDate);
		careProgram.clickOnSave();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 30: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 31: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 35: Navigate to HCP Follow up task ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));

		Logger("STEP 36: Enter details in HCP follow up details section ");
		paAppealsPage.enterHCPFollowUp(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(1));
		careProgram.clickOnSave();

		Logger("STEP 37: Navigate to PA summary task \"Communicate Results & Send SOB\" ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));

		Logger("STEP 38: Validate the communicate Results and Send SOB Task status marked as not started or does not exist");
		// paAppealsPage.validateTaskStatus();
		paAppealsPage.verifyPASummarySectionNotGenerated();

		Logger("STEP 39: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-5707 - HCP Summary of Benefits Correspondence
	 * generation in the Prior Authorization workflow create Correspondece and
	 * validate PDF data
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "TC01: HCP Summary of Benefits Correspondence generation in the Prior Authorization workflow", enabled = true)
	public void PA10_IC5707_HCP_Summary_of_Benefits_Correspondence_generation_in_the_Prior_Authorization_workflow()
			throws Exception {

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 1.2: Navigate to the Care program Enrollees object");
		homeportalPage.closeTabs();
		missingInformatioPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7),
				MissingInformatioPage.class);
		refresh();

		Logger("STEP 1.3: User should be able to view the Recently View List of care program enrollees.");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 2: Navigate to CPE Object → Open any record from CPE Object");
		documentsPage.searchDocument("Automation");
		String recordName = missingInformatioPage.searchAndOpenRecord();
		String patientName = recordName.split(" -")[0];
		String firstName = patientName.split(" ")[0];
		String facilityName = docMgmt.getPatientDetailsFromCPEPage("Facility Name");
		String facilityAddress = docMgmt.getPatientDetailsFromCPEPage("Facility Address");

		Logger("STEP 3: Click on the correspondence Button present on the Top right corner of CPE Record.");
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 4: Fill the information Process Name = PA,Select items to send = Select any value from the Picklist, DMW Summary of Benefits (PA) - MD Fax→ Click on Next button");
		docMgmt.selectProcessName(selectProcessName.get(1));
		docMgmt.selectItemsToSend(itemToSend.get(2));
		missingInformatioPage.clickNextButton();
		String fileName = patientName;

		// Path for PDF in default downloaded folder(change the folder name as per
		// systems default download location)
		String DEST = System.getProperty("user.home") + File.separator + "Downloads" + File.separator + "my" + fileName
				+ ".pdf";

		Logger("Step 5: Wait for few seconds on the Generate Document(s) Screen to load the DMW Summary of Benefit PDF → Match the field mapping");
		docMgmt.savePdfFromCorrespondencePage(fileName);
		docMgmt.validatePDFData(DEST, facilityName, 2);
		docMgmt.validatePDFData(DEST, facilityAddress, 2);
		docMgmt.deletePDF(DEST);
		docMgmt.clickSendButton();

		Logger("Step 6: Click on Finish button on confirmation page");
		docMgmt.clickonFinishButton();

		Logger("Step 7: Navigate to Related List of CPE record → Validate correspondence record → Validate Files record");
		missingInformatioPage.navigateToCPERecord(patientName);
		accountObject.clickOnTab(tabsName.get(1));

		Logger("Step 8: Open the correspondence record → Validate fields");
		docMgmt.navigateToCorrespondenceTable();
		docMgmt.verifyCorrespondenceRecord(processName.get(2));
		docMgmt.clickOnCorrespondenceRecord(processName.get(2));
		docMgmt.validateCorrespondenceFields(true);
		missingInformatioPage.navigateToCPERecord(patientName);
		String winName = getWebDriver().getTitle();

		Logger("Step 9: Open the PDF from the Files → Validate fields from PDF");
		docMgmt.verifyFilesRecord(itemToSend.get(2));
		String pdfName = patientName + "DMW Summary of Benefits".trim();
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);
		// default path for downloads in our project structure (folder Downloads)
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.validatePDFData(downloadPath, facilityName, 2);
		docMgmt.validatePDFData(downloadPath, facilityAddress, 2);
		docMgmt.deletePDF(downloadPath);
		utilityPage.switchToWindow(winName);

		Logger("Step 10: Logout from Application");
		docMgmt.closeButton();
		documentsPage.logout();

	}

	@Test(description = "TC02-Initiation and Configuration the 'Follow up on Results' screen of the PA Tasks in the PA/ Appeals CPE Work Order as a Case Manager user", enabled = true, priority = 29)
	public void PA11_IC2224_InitiationOfPAAppealsScreenAsCaseManagerUser() throws Exception {
		String TestCaseNumber = "TC11";

		// Prerequisites
		String ID = PriorAuthorizationWorkflow_PatientEnrollment_Prerequisites_DMWYES_SPNO_QuickStartNO(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("STEP 1:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String name = ExcelTestData.get(patientName);
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		// Benefits Verification
		Logger("STEP 5: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 6: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

//		Logger("STEP 26: Open BV summary section");
//		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
//		careProgram.clickOnMainTask(bvMainTaskNames.get(1));
//		careProgram.clickOnSubTask(bvSubTaskNames.get(1));
//
//		Logger("STEP 27: Enter details in Review and Send Summary of Benefits");
//		bvPage.enterDetailsOnBVOutcome(outComeOptions.get(1), outComeReasonOptions.get(1));
//		careProgram.clickOnSave();
//		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
//		refresh();

		// PA Initialization
		Logger("STEP 3: Validate user is able to access PA/Appeals CPE work order.");
		paAppealsPage.verifyPATaskInitiated();

		Logger("STEP 4: Validate that user is able to view the below mentioned tasks on the right side of the page");
		paAppealsPage.checkPATaskInitiation();
		paAppealsPage.clickOnTask();

		Logger("STEP 22: Populate the mandatory field values on PA/Appeal Details section. ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));
		String intendedDate = Utility_Function.getNthDayFromToday(10);
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		paAppealsPage.clickOnSave();

		Logger("STEP 22: Now again open the same record and try editing now keep the status as 'Completed' and save the record.");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));
		paAppealsPage.changeStatusToCompleted(StatusCheck.get(1));
		careProgram.clickOnSave();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 26: Login to the QA_SIT Org as 'Case manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 26: Veirfy that HCP Follow up Task is created when \"HCP Follow up Task Required?\" field on the Follow up On Results Tasks is marked as \"Yes\".");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));
		paAppealsPage.validateHCPTaskCreated();

		Logger("STEP 30: Validate HCP Follow Up section  Fields");
		paAppealsPage.clickOnPATask();
		paAppealsPage.verifyAndEnterHCPFollowUpDetails(StatusCheck.get(1), attempts.get(0), hcpContact.get(1));

	}

	@Test(description = "TC-04- Configure the 'Communicate Results & Send SOB' screen of the PA Tasks in the PA/ Appeals CPE Work Order as a BV Specialist.", enabled = true)
	public void PA12_IC2216_ConfigureTheCommunicateResultsAndSendSOBAsBVSpecialist() throws Exception {
		String TestCaseNumber = "TC12";

		// Prerequisites
		String ID = PriorAuthorizationWorkflow_PatientEnrollment_Prerequisites_DMWYES_SPNO_QuickStartNO(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = accountName + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("STEP 1:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String name = ExcelTestData.get(patientName);
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		// Benefits Verification
		Logger("STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 20: verify  PA/Appeal task is initiated");
		paAppealsPage.verifyPATaskInitiated();

		Logger("STEP 21: verify to click on PA/Appeal Icon");
		paAppealsPage.verifyPAAppealTask();

		Logger("STEP 22: Click on Prior Auth section and validate PA Follow up on results fields");
		paAppealsPage.verifyToEnterOnPriorAuthForDeniedOutcome(StatusCheck.get(0), payerContact.get(0),
				receiptRequired.get(0), attempts.get(0), PayerName, pAOutcomeOptions.get(2), PAOutcomeReason.get(1),
				nextFollowUpDate, hcpFollowUpRequired.get(0), denialDate, appealNeeded.get(0));

		Logger("STEP 23: verify to save the details");
		paAppealsPage.clickOnSave();
		refresh();

		Logger("STEP 24: Click on Prior Auth section and verify to change status as completed");
		paAppealsPage.verifyPATaskInitiated();
		paAppealsPage.verifyPAAppealTask();
		paAppealsPage.changeStatusToCompleted(StatusCheck.get(1));
		paAppealsPage.clickOnSave();
		refresh();

		Logger("STEP 25: Validate HCP Follow Up section  Fields");
		paAppealsPage.clickOnPATask();
		paAppealsPage.verifyHCPFollowUp(StatusCheck.get(1), attempts.get(0), hcpContact.get(1));

		Logger("STEP 26: verify PA Summary section Fields");
		paAppealsPage.clickOnPATask();
		paAppealsPage.verifyPASummarySection(StatusCheck.get(1), hcpContact.get(0), hcpOfficeContactName,
				pAOutcomeOptions.get(1), PAOutcomeReason.get(1), proceedWithAppeal.get(1), intendedDate,
				appealPacked.get(0));
		refresh();

	}

	@Test(description = "SIT_TC-01:Prior Authorization Workflow Benefit Verification Prerequisites", enabled = true, priority = 28)
	public void PA13_IC2208_SIT_PA_Renewals_and_Appeals_SF() throws Exception {

		String TestCaseNumber = "TC13";

		// Prerequisites
		String ID = PriorAuthorizationWorkflow_PatientEnrollment_Prerequisites_QuickStartYes(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-requisites 2.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 2.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 2.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 2.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		// BV Initialization code starts here
		Logger("Pre-requisites 2.5: Verify BV Task is initiated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// PA Initialization
		Logger("STEP 3: Validate user is able to access PA/Appeals CPE work order.");
		paAppealsPage.verifyPATaskInitiated();

		Logger("STEP 4: Validate that user is able to view the below mentioned tasks on the right side of the page");
		paAppealsPage.checkPATaskInitiation();
		paAppealsPage.clickOnTask();

		Logger("STEP 5: Validate that user is able to fill all the mandatory fields  on Follow up on Results task , click on save and validate user is able to see error message");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(1), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(1), receiptRequired.get(0), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(0), PAOutcomeReason.get(0));
		paAppealsPage.clickOnSave();
		paAppealsPage.verifyErrorMessage();

		Logger("STEP 6: Validate that When ‘Outcome' is selected as 'Approved’ ,PA/ Appeals Approved section would appear.");
		paAppealsPage.selectOutcome(pAOutcomeOptions.get(1));
		paAppealsPage.validatePAAppealSection(true);

		Logger("STEP 7: Verify When ‘Outcome’ is selected as ‘Denied’,PA/ Appeals Denied section would appear.");
		paAppealsPage.selectOutcome(pAOutcomeOptions.get(2));
		paAppealsPage.validatePAAppealDeniedSection(true);

		Logger("STEP 8: Verify When ‘Outcome’ is selected as ‘Pending’,PA/ Appeals Pending section would appear.");
		paAppealsPage.selectOutcome(pAOutcomeOptions.get(3));
		paAppealsPage.validatePAAppealPendingSection(true);

		Logger("STEP 9: Verify When ‘Outcome’ is selected as 'Not on File',No section would appear.");
		paAppealsPage.selectOutcome(pAOutcomeOptions.get(0));
		paAppealsPage.validateNoSectionAppears(paSections);

		Logger("STEP 10: Select Outcome as ‘Approved’. Verify Outcome Reason is enabled, and user selects Outcome Reason from the drop-down and save the record.");
		paAppealsPage.selectOutcome(pAOutcomeOptions.get(1));
		paAppealsPage.selectOutcomeReason(PAOutcomeReason.get(0));
		paAppealsPage.enterPAAppealAndApprovedDetails(numberOfInjectionsUsed, paEffectiveDate, paDosage.get(0),
				paExpirationDate, numberOfInjectionsApproved);

		Logger("STEP 11: Verify the PA/ Appeals CPE Work Oder is created, \"Follow-up on Results\" task as part of PA Tasks has \"Next Follow Update\" of 10 business days from the completion of Review & Send Summary of Benefits task in the BV CPE Work Order.");
		paAppealsPage.validateNextFollowUpDate();
		paAppealsPage.clickOnSave();

		Logger("STEP 12: Validate that HCP Follow Up task is not initiated.");
		paAppealsPage.validateHCPTaskNotInitiated();

		Logger("STEP 13: To validate BV specialist can view Patient & HCP/HCO Information cards while performing the ‘Follow up on Results’ step.");
		paAppealsPage.validateHCPInformationCardPresent();
		paAppealsPage.validateHCOInformationCardPresent();

		Logger("STEP 14: Logout of the application as BV Specialist user. ");
		documentsPage.logout();

	}

	@Test(description = "SIT- TC-03 - Ability to create HCP Follow-Up task while performing a PA/ Appeal as a Case Manager user", enabled = true, priority = 30)
	public void PA14_IC2207_Ability_To_create_HCP_FollowUp_task_while_performing_PA_Appeal_as_CaseManager_user()
			throws Exception {
		String TestCaseNumber = "TC14";

		// Prerequisites
		String ID = PriorAuthorizationWorkflow_PatientEnrollment_Prerequisites_DMWYES_SPNO_QuickStartNO(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = accountName + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-requisites 2.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 2.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 2.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 2.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		// Benefits Verification
		Logger("STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 36: Enter details in HCP Contact details section ");
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		String intendedDate = Utility_Function.getNthDayFromToday(10);
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));

		Logger("STEP 37: Select Outcome as \"Denied \" and \"Proceed with Appeals\" is marked as \"Yes\" click on save button");
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// PA Initialization
		Logger("STEP 3: Validate user is able to access PA/Appeals CPE work order.");
		paAppealsPage.verifyPATaskInitiated();

		Logger("STEP 4: Validate that user is able to view the below mentioned tasks on the right side of the page");
		paAppealsPage.checkPATaskInitiation();
		paAppealsPage.clickOnTask();

		Logger("STEP 5: Validate that user is able to fill all the mandatory fields  on Follow up on Results task , click on save and validate user is able to see error message");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.verifyDropdownValue("Outcome", pAOutcomeOptions.get(0));
		paAppealsPage.selectOutcomeReason(PAOutcomeReason.get(0));
		paAppealsPage.clickOnSave();

		Logger("STEP 20: Save PA/ Appeal Details ");
		careProgram.clickOnSave();
		refresh();
//1st appeal summary
		Logger("STEP 21: Click on PA/Appeal work order and select Prior Auth ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(3));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 36: Enter details in HCP Contact details section ");
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		String intendedDate2 = Utility_Function.getNthDayFromToday(10);
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));

		Logger("STEP 37: Select Outcome as \"Denied \" and \"Proceed with Appeals\" is marked as \"Yes\" click on save button");
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate2, appealPacked.get(0));
		careProgram.clickOnSave();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
//2nd appeal
		Logger("STEP 21: Click on PA/Appeal work order and select Prior Auth ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(4));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 18: Enter and details on PA/ Appeal Details and status in progress ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(1), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(1), receiptRequired.get(0), ExcelTestData.get(policyholderName));
		String DenialDate3 = Utility_Function.getNthDayFromToday(0);
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));

		Logger("STEP 19: Enter Denial details on PA/ Appeal Details ");
		paAppealsPage.enterMandatoryPAAppealDeniedDetails(proceedWithAppeal.get(0), DenialDate3);

		Logger("STEP 20: Save PA/ Appeal Details ");
		careProgram.clickOnSave();
		refresh();
//2nd appeal summary
		Logger("STEP 21: Click on PA/Appeal work order and select Prior Auth ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(5));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 36: Enter details in HCP Contact details section ");
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		String intendedDate3 = Utility_Function.getNthDayFromToday(10);
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));

		Logger("STEP 37: Select Outcome as \"Denied \" and \"Proceed with Appeals\" is marked as \"Yes\" click on save button");
		paAppealsPage.enterPAAppealDeniedDetailsForFirstLevelAppeal("No");
		careProgram.clickOnSave();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		paAppealsPage.verifyPACompleteStatus();
		documentsPage.logout();

	}
	
	/**
	 * ====================================================================================================================
	 * @author Tejal
	 * 18079
	 * PatientEnrollment_Prerequisites_PA QS-NO,HCP-Yes
	 * Prior Authorization Workflow-SIT- TC-05- Initiation of 1st, 2nd and 3rd Level Appeals Tasks as a BV Specialist user.
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Prior Authorization Workflow-SIT- TC-05- Initiation of 1st, 2nd and 3rd Level Appeals Tasks as a BV Specialist user.", enabled = true)
	public void PA_IC18079_3515_Initiation_of_1st_2nd_3rd_Level_Appeals_Tasks_as_BV_user() throws Exception {
		String TestCaseNumber = "TC4";
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.1:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.2:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 5:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(2));

		Logger("Pre-Requisite STEP 6: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 7: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();


		Logger("Pre-Requisite STEP 8:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();


		Logger("Pre-Requisite STEP 9:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 10:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

	// Diagnosis information-Page
		Logger("Pre-Requisite STEP 11:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 11.1:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 12:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Pre-Requisite STEP 13: OPen CPE record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		documentsPage.logout();
	
		
		Logger("Pre-Requisite STEP 14: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		homeportalPage.closeTabs();
		navigateToURL(CPEURL);

		Logger("Pre-Requisite STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();
         
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		

		documentsPage.logout();
	
		
		Logger("Pre-Requisite STEP 14: Login as CM User");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();
		navigateToURL(CPEURL);

		//Prior auth
		Logger("STEP 28: Click on PA/Appeal work order ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 18: Enter and details on PA/ Appeal Details and status in progress ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(1), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(1), receiptRequired.get(0), ExcelTestData.get(policyholderName));
		String DenialDate = Utility_Function.getNthDayFromToday(0);
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));

		Logger("STEP 19: Enter Denial details on PA/ Appeal Details ");
		paAppealsPage.enterMandatoryPAAppealDeniedDetails(proceedWithAppeal.get(0), DenialDate);

		Logger("STEP 20: Save PA/ Appeal Details ");
		careProgram.clickOnSave();
        refresh();
//pa summary
		Logger("STEP 21: Click on PA/Appeal work order and select Prior Auth ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(1));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 36: Enter details in HCP Contact details section ");
		//paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName));
		String intendedDate = Utility_Function.getNthDayFromToday(10);
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));

		Logger("STEP 37: Select Outcome as \"Denied \" and \"Proceed with Appeals\" is marked as \"Yes\" click on save button");
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
	
		//1st appeal
		Logger("STEP 21: Click on PA/Appeal work order and select Prior Auth ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(2));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));
		
		Logger("STEP 18: Enter and details on PA/ Appeal Details and status in progress ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(1), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(1), receiptRequired.get(0), ExcelTestData.get(policyholderName));
		String DenialDate2 = Utility_Function.getNthDayFromToday(0);
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));

		Logger("STEP 19: Enter Denial details on PA/ Appeal Details ");
		paAppealsPage.enterMandatoryPAAppealDeniedDetails(proceedWithAppeal.get(0), DenialDate2);

		Logger("STEP 20: Save PA/ Appeal Details ");
		careProgram.clickOnSave();
refresh();
//1st appeal summary
Logger("STEP 21: Click on PA/Appeal work order and select Prior Auth ");
careProgram.clickOnWorkOrderTask(workOrderName.get(1));
careProgram.clickOnMainTask(paMainTaskNames.get(3));
careProgram.clickOnSubTask(paSubTaskNames.get(1));	

Logger("STEP 36: Enter details in HCP Contact details section ");
//paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName));
String intendedDate2 = Utility_Function.getNthDayFromToday(10);
paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));

Logger("STEP 37: Select Outcome as \"Denied \" and \"Proceed with Appeals\" is marked as \"Yes\" click on save button");
paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate2, appealPacked.get(0));
careProgram.clickOnSave();
refresh();
missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
refresh();
//2nd appeal
Logger("STEP 21: Click on PA/Appeal work order and select Prior Auth ");
careProgram.clickOnWorkOrderTask(workOrderName.get(1));
careProgram.clickOnMainTask(paMainTaskNames.get(4));
careProgram.clickOnSubTask(paSubTaskNames.get(0));

Logger("STEP 18: Enter and details on PA/ Appeal Details and status in progress ");
paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(1), payerContact.get(0), attempts.get(0),
		hcpFollowUpRequired.get(1), receiptRequired.get(0), ExcelTestData.get(policyholderName));
String DenialDate3 = Utility_Function.getNthDayFromToday(0);
paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));

Logger("STEP 19: Enter Denial details on PA/ Appeal Details ");
paAppealsPage.enterMandatoryPAAppealDeniedDetails(proceedWithAppeal.get(0), DenialDate3);

Logger("STEP 20: Save PA/ Appeal Details ");
careProgram.clickOnSave();
refresh();
//2nd appeal summary
Logger("STEP 21: Click on PA/Appeal work order and select Prior Auth ");
careProgram.clickOnWorkOrderTask(workOrderName.get(1));
careProgram.clickOnMainTask(paMainTaskNames.get(5));
careProgram.clickOnSubTask(paSubTaskNames.get(1));	

Logger("STEP 36: Enter details in HCP Contact details section ");
//paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName));
String intendedDate3 = Utility_Function.getNthDayFromToday(10);
paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(2), PAOutcomeReason.get(1));

Logger("STEP 37: Select Outcome as \"Denied \" and \"Proceed with Appeals\" is marked as \"Yes\" click on save button");
paAppealsPage.enterPAAppealDeniedDetailsForFirstLevelAppeal("No");
careProgram.clickOnSave();
refresh();
missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
refresh();
paAppealsPage.verifyPACompleteStatus();
documentsPage.logout();	

	}

}