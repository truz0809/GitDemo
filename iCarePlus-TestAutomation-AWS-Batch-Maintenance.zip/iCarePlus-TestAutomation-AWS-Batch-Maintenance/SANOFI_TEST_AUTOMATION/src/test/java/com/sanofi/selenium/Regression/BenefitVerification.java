package com.sanofi.selenium.Regression;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.PAPPage;

public class BenefitVerification extends BaseTest {

	public static String CPEURL;

	private static ThreadLocal<String> filePath = new ThreadLocal<>();
	public ReadExcel excel;
	public String fileName;
	String functionality = "BenefitVerification";

	public static double getRandomNumber(double min, double max) {
		double x = (int) (Math.random() * ((max - min) + 1)) + min;
		return x;
	}

	double randomNum = getRandomNumber(1111, 9999);

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		sheetName = "BenefitVerification";
		excel = new ReadExcel(sheetName);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		uploadDocs = GetInstance(UploadDocument.class);
		triagePage = GetInstance(TriagePage.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		papPage = GetInstance(PAPPage.class);

	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	@Test(description = "SIT_Prior Authorization Workflow Patient Enrollment Prerequisites", enabled = true)
	public String BenefitVerificationWorkflow_PatientEnrollment_Prerequisites2(String testcaseNumber) throws Exception {

		String cpeUrl = null;
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax", "Diagnosis Code",
				"DUPIXENT MyWay", "Preferred Specialty Pharmacy", "Office Fax" };
		// String columnValue[] = { "Automation Correspondence SP", "(954) 312-1432",
		// "(166) 254-1171",
		// "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE", "(166) 254-1171"
		// };
		String columnValue[] = { "Automation Correspondence SP", "(954) 312-1432", "(166) 254-1171",
				"J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "FALSE", "(166) 254-1171" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		accountObject.globalSearch(searchFilter.get(1), cpeName);
		cpeUrl = getCurrentPageURL();

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		return cpeUrl;

	}

	@Test(description = "SIT_Prior Authorization Workflow Patient Enrollment Prerequisites", enabled = true)
	public String BenefitVerificationWorkflow_PatientEnrollment_Prerequisites(String testcaseNumber) throws Exception {

		String cpeUrl = null;
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax", "Diagnosis Code",
				"DUPIXENT MyWay", "Preferred Specialty Pharmacy", "Office Fax" };
		String columnValue[] = { "Automation Correspondence SP", "(954) 312-1432", "(166) 254-1171",
				"L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE", "(166) 254-1171" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		return ID;

	}

	@Test(description = "UAT_Document Management Workflow Patient Enrollment Prerequisites", enabled = true)
	public String PatientEnrollment_Prerequisites(String testcaseNumber) throws Exception {

		String url = null;
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Prescriber NPI", "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "370864" + randomNum, "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE",
				"FALSE" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.1: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.2: Once the Document is opened, Click on refresh until the OCR status is updated to Success.");

		Logger("STEP 4: On Classify document page select Doc type = Enrollment Form > Click on submit.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(2));

		Logger("STEP 4.1: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4.2: Enter the CARE PROGRAM PRODUCT > Click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 4.3: In Patient Information & Authorizations pg enter all the mandatory details of the patient.");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 4.4: Enter all the mandatory details in the Insurance Information section > Click on next.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 4.5: In the Prescriber Information section fill the HCP Speciality and HCo Zip code and other details > click on next.");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		System.out.println(ExcelTestData.get(prescriberZip));
		System.out.println(ExcelTestData.get(specialty));
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.updateZipandSpeciality("ALLERGY", "32839");
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 4.6: In the Diagnosis Information fill all the mandatory details > click on next.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 4.7:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 5: Click on Submit and Enrollment Form should be submitted");
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		url = getCurrentPageURL();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'BV'");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		navigateToUrl(url);
		Thread.sleep(4000);

		// Bv start
		Logger("STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		Logger("STEP 26: Open BV summary section");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(1));
		careProgram.clickOnSubTask(bvSubTaskNames.get(1));

		// pa start
		Logger("STEP 28: Click on PA/Appeal work order ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 29: Open \"Follow up on Results\" task and enter mandatory details and outcome as approved and click on save ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(0), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(0), PAOutcomeReason.get(0));
		String effectiveDate = Utility_Function.getNthDayFromToday(10);
		String expirationDate = Utility_Function.getNthDayFromToday(15);
		// paAppealsPage.enterMandatoryPAApprovedDetails(effectiveDate, paDosage.get(0),
		// expirationDate);
		careProgram.clickOnSave();

		url = getCurrentPageURL();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		navigateToUrl(url);
		Thread.sleep(4000);
		// pa start 2
		Logger("STEP 32: open HCP follow up task ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));

		Logger("STEP 33: Mark status as completed and enter mandatory details click on save");
		paAppealsPage.selectDropdownValue("Status", paStatus.get(1));

		paAppealsPage.enterHCPFollowUp(hcpContact.get(0), attempts.get(0), ExcelTestData.get(officeContactName),
				intendedDate, submissionChannel.get(0), intentOfSubmission.get(0), nextFollowupTime.get(0));

		careProgram.clickOnSave();

		Logger("STEP 34: Follow up on result task and change status to completed ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));
		paAppealsPage.changeStatusToCompleted(StatusCheck.get(1));
		paAppealsPage.enterOutcome(pAOutcomeOptions.get(7));
		careProgram.clickOnSave();

		Logger("STEP 35: Navigate to PA summary task \"Communicate Results & Send SOB\" enter hcp contact details and save");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(1));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		paAppealsPage.enterOutcome(pAOutcomeOptions.get(1));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// PAP start Initialization and completion////////////
		Logger("STEP 41 :PAP work order initialization.");
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		papPage.selectReason("PAP Appeal");
		Logger("STEP 42 : Click on save and refresh the page");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnSubmitButton();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterOutcome(iapoutcome.get(0));
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();

		// quick start start/////////////
		Logger("STEP 12: Navigate to Quick Start and verify flow has initiated");
		refresh();
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();

		Logger("STEP 13: Click on Enrollment task");
		quickStartPage.clickOnTask();

		Logger("STEP 14: Enter Eligibility Criteria and click on Next button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 15: Enter Eligibility outcome and click on next button ");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 17: Enter order details and click on submit button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 18: Click on quick start button and verify task compltion status");
		quickStartPage.clickOnQuickStart();
		quickStartPage.checkQuickStartTaskComplition();

		// Copay start work order/////////////////////////
		Logger("STEP 16: Open Copay work order");
		careProgram.clickOnWorkOrderTask(workOrderName.get(3));
		careProgram.clickOnMainTask(copayMainTaskNames.get(0));
		careProgram.clickOnSubTask(copaySubTaskNames.get(0));

		Logger("STEP 17: Enter Eligibility Criteria and click on submit button");
		String outcomeDate = Utility_Function.getNthDayFromToday(0);
		boolean outcomeScreen = copayFlow.verifyReviewOutcomeScreen();
		if (outcomeScreen) {
			copayFlow.enterOutcomeDetails(copayOutcome.get(0), outcomeDate);
			copayFlow.clickOnReAssessButton();
		}
		copayFlow.enterEligibilityCriteria();
		quickStartPage.clickOnSubmitButton();
		copayFlow.enterRequestOutcome(copayOutcome.get(0), outcomeDate);
		copayFlow.clickOnFinishButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// triage start////////
		Logger("STEP 35: Navigate to Traige and verify flow has initiated");
		triagePage.checkTraigeIntiation();
		triagePage.checkTriageTaskInitiation();

		Logger("STEP 36: Click on Traige task");
		triagePage.clickOnTask();

		Logger("STEP 37: Verify task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(5));
		String selectedSP = triagePage.verifySelectedPharmacy(alliancePharmacy.get(0));
		Logger("STEP 38: Verify review information and click on next button");
		triagePage.verifyReviewTask(selectedSP, SPtype.get(1), expedited.get(1));
		missingInformatioPage.clickNextButton();

		Logger("STEP 39: Verify order details task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));

		Logger("STEP 40: Enter order details and click on submit");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 41: Click on Triage button and verify task compltion status");
		triagePage.clickOnTraige();
		triagePage.checkTraigeTaskComplition();

		//////////// iap start
		Logger("STEP 38: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 39: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 40: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.selectReason();

		Logger("STEP 41: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 42: Validate that in the right side of the UI there are two tasks:IAP Summary,Extend/Discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();
		iapPage.checkIAPSecondTask();

		Logger("STEP 43: Expand the IAP Summary section and Click on IAP Enrollment Task");
		iapPage.clickOnTask();

		Logger("STEP 44: Verify Users selects Enrollment Reason as Below Enrollment End Date populates accordingly");
		iapPage.verifyTaskIsLoaded(taskTitle.get(0));
		iapPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 45: Validate if User is navigated to the eligibility screen");
		iapPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 46: Verify Correspondence task is loaded and click on next button");
		// iapPage.verifyCorrespondenceScreen(); // does not exist anymore

		Logger("STEP 47: On Order Section Select the Prescription which were updated at the time of patient enrollment.");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		url = getCurrentPageURL();
		url = Utility_Function.removeQueryString(url);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		return url;
	}

	/**
	 * *
	 * ==================================================================================
	 * ================================== * Test Case Id: ICARE-8475 Validate that
	 * in the MP section of BV task 1 there is only active MP is present * @author
	 * Anand Pawar *
	 * =====================================================================================
	 * ==============================
	 */
	@Test(description = "Validate that in the MP section of BV task 1 there is only active MP is present", enabled = true)

	public void BV01_IC7270_Validate_MP_Section_of_BVTask_1_Only_Active_MP_Present() throws Exception {

		Map<String, Map<String, String>> testCaseData = new HashMap<>();
		String testCaseNumber = "TC18";

		testCaseData.put(testCaseNumber,
				excelDataUpdate.createTestData(Map.of("Preferred Specialty Pharmacy", "FALSE", "DUPIXENT MyWay", "TRUE",
						"Text Messaging Consent", "TRUE", "Voicemail", "TRUE", "Text", "TRUE", "Best Timing AM", "TRUE",
						"Best Timing Afternoon", "TRUE", "Best Timing PM", "TRUE", "Diagnosis Code",
						"L20.9 - Atopic dermatitis, unspecified")));
		Map<String, String> ExcelTestData = testCaseData.get(testCaseNumber);

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement for TestCaseNumber: "
				+ testCaseNumber);
		excelDataUpdate.updateExcelTestData(testCaseNumber, ExcelTestData, functionality);
		ExcelTestData = excel.getExcelInputData(testCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(testCaseNumber, functionality));
			updatepdf.updatePDFForm(testCaseNumber, functionality);
		}
		// updatepdf.updatePDFForm(testCaseNumber, functionality);
		System.out.println(filePath.get());
		fileName = documentsPage.getFileName(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 12: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 13: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 14:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 15:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 16:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 17:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 18:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 19:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 20: Open ICARE Connect App from the App launcher and select Member Plans.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(9), DocumentPage.class);

		Logger("STEP 21: Navigate to the Received Document Object from the app launcher.");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 22: Navigate and click on pharamacy record of recently created EF form");
		String pName = ExcelTestData.get(patientName);
		documentsPage.verifyRecord(pName);
		documentsPage.clickOnPharmacyRecord(pName);

		Logger("STEP 23: Edit Effective To date as 'Future date' and add other mandatory details and Save");
		documentsPage.editPharmacyEffectiveToDate();
		documentsPage.inputInsuranceAddDate();
		documentsPage.inputPolicyHolderDOB();
		documentsPage.inputPlanID();
		documentsPage.clickOnSave();

		refresh();

		Logger("STEP 24: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 25: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 26: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 27:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);

		Logger("STEP 28: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();
		refresh();

		Logger("STEP 29: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 30: Validate that in the Member plan section there is only active member plan(medical) are present.");
		bvPage.checkActiveMemberPlan(memberPlan.get(0));

		Logger("STEP 31: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-4512 To Validate SP Assignment Logic when HCP Specialty
	 * Pharmacy is preferred(Alliance)
	 * 
	 * @author Kavyashree MB
	 *         ====================================================================================================================
	 */
	@Test(description = "TC02 -To Validate SP Assignment Logic when HCP Specialty Pharmacy is preferred(Alliance) ", enabled = true)
	public void BV03_IC4512_To_Validate_SP_Assignment_Logic_when_HCP_Specialty_Pharmacy_is_preferred_Alliance()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC2";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "K20.0 - Eosinophilic esophagitis", "TRUE", "FALSE" };
		// String removeColumnData[] = { "Prescription-B RefillCaptured",
		// "Prescription-5B Dose" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			// excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(4).split(" -")[0];
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("EOE");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());
		// fileName = documentsPage.getFileName(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.2:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 2.3:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.1:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.2: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Bioplus Specialty Pharmacy Services, Llc");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11: Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		// homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP  19:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 20:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String acctname = ExcelTestData.get(patientName);
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(acctname);

		Logger("STEP 23: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("STEP 24: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 25: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 26: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));

		Logger("STEP 27: Validate that the HCP Preferred Specialty Pharmacy field on coverage benefit section should be fetched from Enrollment form.");
		bvPage.verifyHCPPreferredSPInBenifitTask("Bioplus Specialty Pharmacy Services, Llc");

		Logger("STEP 28: Save the details");
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 31: Verify HCP Preferred Specialty Pharmacy is populated as Selected Specialty Pharmacy on CPE record");
		accountObject.clickOnTab(tabsName.get(0));
		String selectedSP = triagePage.verifyPharmacyType("Bioplus Specialty Pharmacy Services, Llc");

		Logger("STEP 32: Verify SP type is populated as Alliance.");
		triagePage.verifySPType(SPtype.get(1));

		Logger("STEP 33: User Logout the Application.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5833-HCP Summary of Benefits Correspondence generation at
	 * the end of Benefits Verification
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "ICARE-5833s_HCP Summary of Benefits Correspondence generation at the end of Benefits Verification", enabled = true)
	public void BV02_IC5833_HCP_Summary_of_Benefits_Correspondence_generation_at_the_end_of_Benefits_Verification()
			throws Exception {

		String TestCaseNumber = "TC1";
		// Prerequisites
		String cpeUrl = BenefitVerificationWorkflow_PatientEnrollment_Prerequisites2(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		// BV task
		Logger("STEP 1:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(cpeUrl);
		Thread.sleep(4000);

		Logger("STEP 2: Click on the correspondence Button present on the Top right corner of CPE Record.");
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 3: Fill Process name and select items to send information");
		docMgmt.selectProcessName(processName.get(1));
		docMgmt.selectItemsToSend(bvitemsToSend.get(3));
		missingInformatioPage.clickNextButton();
		missingInformatioPage.clickNextButton();

		Logger("STEP 4: Wait for few seconds on the Generate Document(s) Screen to load the DMW Summary of Benefit PDF → Match the field mapping → Click on Send");
		docMgmt.clickSendButtonUntilFinish();

		Logger("STEP 5: Click on Finish button on confirmation page");
		docMgmt.clickonFinishButton();

		Logger("STEP 6: Navigate to Related List of CPE record → Validate correspondence record → Validate Files record");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();
		careProgram.clickOnViewAll("Correspondences");
		docMgmt.verifyCorrespondenceRecord(processName.get(1));
		docMgmt.clickOnCorrespondenceRecord(processName.get(1));

		Logger("STEP 7: Open the correspondence record → Validate Recipient lookup fields as well as other fields");
		// docMgmt.validateCorrespondenceFields(channel.get(0), recipientType.get(0),
		// serviceArea.get(0),correspondencestatus.get(0));
		docMgmt.validateCorrespondenceFieldsnew(channel.get(0), recipientType.get(0), serviceArea.get(0));
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 8: Validate PDF Files present in Related List of Correspondence ");
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecord(bvitemsToSend.get(3));
		String pdfName = bvitemsToSend.get(3).trim();
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.deleteExistingFile(downloadPath);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);

		// Data validation
		String currentDate = Utility_Function.getNthDayFromTodayFormatyyyyMMdd(0);
		String patientDob = Utility_Function.changeDateFormatyyyyMMdd(ExcelTestData.get(patientDOB));
		String pharamacyNumber = Utility_Function.formatNumber(ExcelTestData.get(rxPhone));
		String spPharamacyNumber = Utility_Function.formatNumber(ExcelTestData.get(pharmacyPhone));
		String spPharamacyFax = Utility_Function.formatNumber(ExcelTestData.get(pharmacyfax));

		Map<String, Integer> fieldsToValidate = new HashMap<>();
		fieldsToValidate.put("To: " + ExcelTestData.get(prescriberName), 1);
		fieldsToValidate.put(currentDate, 1);
		fieldsToValidate.put("Subject: " + bvitemsToSend.get(3), 1);
		fieldsToValidate.put(currentDate, 2);
		fieldsToValidate.put(ExcelTestData.get(prescriberName), 2);
		fieldsToValidate.put(ExcelTestData.get(officeContactName), 2);
		fieldsToValidate.put(ExcelTestData.get(sitefacilityname), 2);
		fieldsToValidate.put(ExcelTestData.get(prescriberAddress), 2);
		fieldsToValidate.put(ExcelTestData.get(prescriberCity) + ", " + ExcelTestData.get(prescriberState) + " "
				+ ExcelTestData.get(prescriberZip), 2);
		fieldsToValidate.put(ExcelTestData.get(patientName), 2);
		fieldsToValidate.put("Date of Birth: " + patientDob, 2);
		fieldsToValidate.put(ExcelTestData.get(prescriberName), 2);
		fieldsToValidate.put(ExcelTestData.get(specialty), 2);
		fieldsToValidate.put("We have been unable to obtain coverage information for DUPIXENT® (dupilumab) from "
				+ ExcelTestData.get(rxPayerName)
				+ " on behalf of the patient referenced above due to third party restrictions. If you need to reach "
				+ ExcelTestData.get(rxPayerName) + " to discuss this information, please call " + pharamacyNumber, 2);
		fieldsToValidate.put(
				"To ensure you are able to obtain coverage information and your patient receives DUPIXENT as soon as possible, the prescription has been transferred to "
						+ ExcelTestData.get(specialtyPharmacyName),
				2);
		fieldsToValidate.put("Specialty Pharmacy: " + ExcelTestData.get(specialtyPharmacyName), 2);
		fieldsToValidate.put("Phone: " + spPharamacyNumber, 2);
		fieldsToValidate.put("Fax: " + spPharamacyFax, 2);

		Logger("STEP 8: Open recently created PDF from the Files → Validate fields from PDF ");
		docMgmt.validateMultiplePDFFields(downloadPath, fieldsToValidate);

	}

	/**
	 * *
	 * ==================================================================================
	 * = Test Case Id: ICARE-5100 -BV Task should not get created when under BV
	 * Capture as BV Specialist user when DMW is 'No', SP is 'Yes', QS is 'No' and
	 * HCP Authorization is 'No'(Negative Scenario) * @author Anand Pawar *
	 * =====================================================================================
	 * ==============================
	 */
	@Test(description = "BV Task should not get created when under BV Capture as BV Specialist user when DMW is 'No', SP is 'Yes', QS is 'Yes' and HCP Authorization is 'No'(Negative Scenario)", enabled = true)
	public void BV03_IC5100_BV_Task_should_not_get_created_when_under_BV_Capture_as_BV_Specialist_user_when_DMW_is_No_SP_is_Yes_QS_is_Yes_and_HCP_Authorization_is_No()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC27";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy",
				"Prescription 5B Quick Start", "Prescription 5B Initial And Maintenance Doses" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "FALSE", "TRUE", "FALSE", "TRUE" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = accountName + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//			Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//			documentsPage.navigateToReceiveddocument();
//			documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(1), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		homeportalPage.closeTabs();

		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		// CPE URL
		String url = getCurrentPageURL();
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 1.10: Logout of the application as CM user.");
		documentsPage.logout();

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		// BV Initialization
		Logger("Pre-requisites 1.5: Verify BV Task is not initiated");
		bvPage.verifytheBVTaskNotInitiated();

		Logger("STEP 1.6: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-4512 To Validate SP Assignment Logic when HCP Specialty
	 * Pharmacy is preferred(Alliance)
	 * 
	 * @author Kavyashree MB
	 *         ====================================================================================================================
	 */
	@Test(description = "TC02 -To Validate SP Assignment Logic when HCP Specialty Pharmacy is preferred(Alliance) ", enabled = true)
	public void BV04_IC4512_To_Validate_SP_Assignment_Logic_when_HCP_Specialty_Pharmacy_is_preferred_Alliance()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC12";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "K20.0 - Eosinophilic esophagitis", "TRUE", "FALSE" };
		// String removeColumnData[] = { "Prescription-B RefillCaptured",
		// "Prescription-5B Dose" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			// excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(4).split(" -")[0];
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("EOE");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.2:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 2.3:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.1:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.2: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Bioplus Specialty Pharmacy Services, Llc");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11: Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		// homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP  19:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 20:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String acctname = ExcelTestData.get(patientName);
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(acctname);

		Logger("STEP 23: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("STEP 24: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 25: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 26: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));

		Logger("STEP 27: Validate that the HCP Preferred Specialty Pharmacy field on coverage benefit section should be fetched from Enrollment form.");
		bvPage.verifyHCPPreferredSPInBenifitTask("Bioplus Specialty Pharmacy Services, Llc");

		Logger("STEP 28: Save the details");
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 31: Verify HCP Preferred Specialty Pharmacy is populated as Selected Specialty Pharmacy on CPE record");
		accountObject.clickOnTab(tabsName.get(0));
		String selectedSP = triagePage.verifyPharmacyType("Bioplus Specialty Pharmacy Services, Llc");

		Logger("STEP 32: Verify SP type is populated as Alliance.");
		triagePage.verifySPType(SPtype.get(1));

		Logger("STEP 33: User Logout the Application.");
		documentsPage.logout();
	}

	/***
	 * ===============================================
	 * 
	 * Test Case Id: ICARE-3885 Verify the “Pharmacy NCPDP” field length on Claims
	 * object
	 * 
	 * @author Anand Pawar
	 *         =======================================================================================
	 * 
	 */
	@Test
	public void BV05_IC3885_Verify_Pharmacy_NCPDP_Field_Length_On_Claims_Object() throws Exception {

		String TestCaseNumber = "TC3";

		// Prerequisites
		String url = BenefitVerificationWorkflow_PatientEnrollment_Prerequisites2(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		// BV User
		Logger("STEP  20:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 21:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

//		Logger("STEP 22: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 23: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String acctname = ExcelTestData.get(patientName);
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);

		navigateToUrl(url);

		Logger("STEP 24: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("STEP 25: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 26: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 27: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();

		Logger("STEP 28: Check and uncheck the checkbox and verify show detail button is visible to user.");
		bvPage.checkShowDetailsButton();

		Logger("STEP 29: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7214:SIT:TC07: To Validate to Round Robin Logic with Payer
	 * Selected pharmacies Round robin fields is false
	 * 
	 * @author Sonica P
	 *         ====================================================================================================================
	 */
	@Test(description = "ICARE-7214:SIT:TC07: To Validate to Round Robin Logic with Payer Selected pharmacies Round robin fields is false", enabled = true)
	public void BV06_IC13319_SIT_TC07_To_Validate_to_Round_Robin_Logic_with_Payer_Selected_pharmacies_Round_robin_fields_is_false()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC12";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "K20.0 - Eosinophilic esophagitis", "TRUE", "FALSE" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			// excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(4).split(" -")[0];
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("EOE");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.2:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 2.3:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.1:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.2: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Bioplus Specialty Pharmacy Services, Llc");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11: Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP  19:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 20:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String acctname = ExcelTestData.get(patientName);
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(acctname);

		Logger("STEP 23: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("STEP 24: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 25: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 26: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));

		Logger("STEP 28: Save the details");
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 32: Verify SP type is populated as Alliance.");
		triagePage.verifySelectedSP();

		Logger("STEP 33: User Logout the Application.");
		documentsPage.logout();
	}

	
	/**
	 * *
	 * ==================================================================================
	 *TC01-ICARE-27675 - INC2115743-Payer Rep Name and Call Reference Number fields are saved correctly during the BV process
	 * @author Navita
	 * =====================================================================================
	 * ==============================
	 */
	@Test(description = "TC01-INC2115743-Payer Rep Name and Call Reference Number fields are saved correctly during the BV process", enabled = true)
 
	public void BV01_ICARE_27675_TC01_INC2115743_Payer_Rep_Name_and_Call_Reference_Number_fields_are_saved_correctly_during_the_BV_process() throws Exception {
 
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC5";
 
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "K20.0 - Eosinophilic esophagitis", "TRUE", "FALSE" };
 
		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement for TestCaseNumber: "
				+ TestCaseNumber);
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			// excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
			ExcelTestData = excel.getExcelInputData(TestCaseNumber);
			String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(4).split(" -")[0];
 
		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());
		fileName = documentsPage.getFileName(filePath.get());
 
		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
 
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
 
		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);
 
		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();
 
		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));
 
		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));
 
		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
 
		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
 
		Logger("STEP 12: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
 
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];
 
		Logger("STEP 13: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();
 
		// patientinfoAndauthorization-Page
		Logger("STEP 14:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];
 
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();
 
		// Patient Insurance - Page
		Logger("STEP 15:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();
 
		Logger("STEP 16:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];
 
		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];
 
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();
 
		// Diagnosis information-Page
		Logger("STEP 17:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();
 
		Logger("STEP 18:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];
 
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();
 
		Logger("STEP 19:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		
		Logger("STEP 14:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		
		Logger("STEP 6: Change member plan to active");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.verifyPrimaryRecordMemberPlansSection();
		docMgmt.changeMemberPlanStatusActive(pharamcyMember.get(4));
		docMgmt.clickSaveButton();
		String policyholderdob = docMgmt.getNthPastDayFromToday(1000);
		String insuadddate = docMgmt.getDateNDaysFromToday(0);
				
		Logger("STEP 31: User Logout the Application.");
		documentsPage.logout();
			
		Logger("STEP 25: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
 
		Logger("STEP 26: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
 
		Logger("STEP 27:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);
		
		String url = getCurrentPageURL();
 
		Logger("STEP 28: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();
		refresh();
		
		Logger("STEP 31: User Logout the Application.");
		documentsPage.logout();	
		
		Logger("STEP 1:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		
		accountObject.navigate(url);
		Thread.sleep(4000);
	
		Logger("STEP 29: Open Review and finalize task under Benefits Verification ");
		bvPage.verifytheBVTaskInitiated();
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));
		
		Logger("STEP 24: Verify and enter call information section");
		String callRefNo = bvPage.enterCallNoCallInformationSectionBV();
		String payerName = bvPage.enterPayerNameCallInformationSectionBV();
		Logger("STEP 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();
 
		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnAttemptOutreachForConsents();
		bvPage.clickOnCompleteButton();
 
		missingInformatioPage.navigateToCPERecord(cpeName);
		refresh();
 
		Logger("STEP 31: Navigate to timelines tab and click on the Review and finalize benefit button/hyperlink");
		accountObject.clickOnTab(tabsName.get(5));
		accountObject.clickOnTab(tabsName.get(4));
		bvPage.clickOnReviewAndFinalizeBenefit();
		bvPage.validateFieldsInReviewAndFinalizeBenefit(callRefNo,payerName);
		
		Logger("STEP 11: Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		
		Logger("STEP 16: Navigate to Member Plan Object → Validate Primary Medical Insurance record and Primary Rx Insurance record created in previous step (6,7) ");
		accountObject.clickOnMemberPlan();
		accountObject.validateMemberPlans(ExcelTestData.get(rxPayerName), ExcelTestData.get(medicalPayerName));
		accountObject.clickOnMemberPlanRecord(ExcelTestData.get(rxPayerName));
		accountObject.validateMemberPlanDetails(insuadddate, policyholderdob, "plan");
		
		Logger("STEP 31: User Logout the Application.");
		documentsPage.logout();
 
	}
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-21157:Verify All BV Worklist and All PA/Appeal Worklist
	 * List views on Assessment Task Object
	 * 
	 * @author Trupti Zure
	 * @author Trupti Zure
	 *         ====================================================================================================================
	 */
	@Test(description = "ICARE-21157:SIT:TC07: Verify All BV Worklist and All PA/Appeal Worklist List views on Assessment Task Object", enabled = true)
	public void BV07_IC21157_Verify_All_BV_Worklist_and_All_PAAppeal_Worklist_List_views_on_Assessment_Task_Object()
			throws Exception {

		int numberOfUsers = 4;

		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
				case 0:
					Logger("STEP 1: Login to the QA_SIT Org as 'BV User'.");
					homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
					break;
				case 1:
					Logger("STEP 1: Login to the QA_SIT Org as 'CM User'.");
					homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
					break;
				case 2:
					Logger("STEP 1: Login to the QA_SIT Org as 'PM User'.");
					homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
					break;
				case 3:
					Logger("STEP 1: Login to the QA_SIT Org as 'BusimessOps User'.");
					homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
					break;
				}

				

				Logger("STEP 2: Navigate to Assessment Task Object and select the \"All BV Worklist\"");
				homeportalPage.closeTabs();
				documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2),
						DocumentPage.class);

				Logger("STEP 3: Verify the mentioned columns are displayed in order in the \" All BV Worklist\" List View");
				assessmentTasksPage.navigateToAllBVWorklist();
				List<String> expectedColumns = Arrays.asList("Created", "Assessment Task Name", "CPE", "CPE WO",
						"Owner", "Status", "Pharmacy Payer");
				bvPage.verifyCoulumns(expectedColumns);

				Logger("STEP 4: Verify Assessment Tasks column contains all the BV related Assessment Tasks: Review and Finalize Benefit;  and *‘Review and Send Summary of Benefits*’ Tasks");
				List<String> expectedTasks = Arrays.asList("Review and Finalize Benefit",
						"Review and Send Summary of Benefits");
				bvPage.verifyTaskName(expectedTasks);

				Logger("STEP 5: Select any Task > Click on Assign to me> Verify the user is navigated to My Assessment Task List view> Verify the Task is displayed in My Assessment Tasks List view");
				String createdDate = assessmentTasksPage.assignFirstCPERecord();
				bvPage.verifyMyAssessmentTaskListView();
				assessmentTasksPage.verifyCPETaskDisplayed(createdDate);

				Logger("STEP 6: The \"All PA/Appeal Worklist\" is displayed");
				bvPage.navigateToAllPAOrAppealWorklist();
				refresh();

				Logger("STEP 7: Verify the below mentioned columns are displayed in order in the \"All PA/Appeal Worklist\" List View Created, Assessment Task Name, CPE, CPE WO, Owner, Status, Pharmacy Payer, Next Follow Up Date (Note: Keep the same columns as in ‘All BVS Worklist’ list view currently)");
				bvPage.verifyCoulumns(expectedColumns);

				Logger("STEP 8: Verify Assessment Tasks column contains PA/Appeal Assessment Task: ‘Follow up on Results’ Tasks");
				expectedTasks = Arrays.asList("Follow up on Results");
				bvPage.verifyTaskName(expectedTasks);

				Logger("STEP 9: Select any Task > Click on Assign to me> Verify the user is navigated to My Assessment Task List view> Verify the Task is displayed in My Assessment Tasks List view");
				createdDate = assessmentTasksPage.assignFirstCPERecord();
				bvPage.verifyMyAssessmentTaskListView();
				assessmentTasksPage.verifyCPETaskDisplayed(createdDate);

				Logger("STEP 10: Navigate to App Launcher> Select the Accounts Object> Select the All Facilities List View > Verify the HCO/Facility Records are displayed");
				documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(3),
						DocumentPage.class);
				accountObject.navigateToListView(accountListView.get(5));
				accountObject.clickonFirstAccount();

				Logger("STEP 11: Select any HCO record, Verify ‘No Contact’ picklist field (Optional field) is displayed on the HCO Account page layout with Picklist Values as follows: Default value = blank LOVs: No Call, No Email, No Fax, No Contact");
				accountObject.validateNoContactPicklistValues();
				

				Logger("STEP 12: User Logout the Application.");
				documentsPage.logout();

			} catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				documentsPage.logout();
			}
		}
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-27679:Insurance Add Date, Policy Holder DOB, and Plan ID fields are not wiped out after saving completing the BV capture process
	 * 
	 * @author Trupti Zure
	 *         ====================================================================================================================
	 */
	@Test(description = "ICARE-27679: Insurance Add Date, Policy Holder DOB, and Plan ID fields are not wiped out after saving completing the BV capture process", enabled = true)
	public void BV08_IC27679_Insurance_Add_Date_PolicyHolder_DOB_and_PlanID_fields_are_not_wiped_out_after_saving_completing_the_BV_capture_process()
			throws Exception {

		Logger("STEP 1: Login to the QA_SIT Org as 'BV User'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2: Navigate to Assessment Task Object and select the \"All BV Worklist\"");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);
		homeportalPage.closeTabs();

		Logger("STEP 3: Navigate to Assessment Task Object and select the \"All BV Worklist\"");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 4: Open the \"Review and Finalize Benefit\" task CPE .");
		String createdDate = assessmentTasksPage.assignFirstCPERecord();
		assessmentTasksPage.openCPETask(createdDate);
		String cpeName = accountObject.getCPEName();

		Logger("STEP 5: Go to patient account");
		docMgmt.navigateToAccount();

		Logger("STEP 6: In person account go to related ta b and open the pharmacy member plan details.");
		accountObject.clickOnTab(tabsName.get(1));
		careProgram.clickOnViewAll("Member Plans");
		accountObject.clickOnPharamcyRecord();

		Logger("STEP 7: Verify the fields  Insurance Add Date, Policy Holder DOB, and Plan ID are present with values in member plan details.");
		String date = Utility_Function.getDateNDaysFromToday(0);
//		String dob = Utility_Function.getBirthDate(40);
//		accountObject.verifyAndEditMemberPlanDetailsFields(date, dob, "Automation Plan");
		refresh();

		Logger("STEP 8: Navigate back to the CPE record.");
		missingInformatioPage.navigateToCPERecord(cpeName);

		Logger("STEP 9: Verify that user is able to click on the benefits verification on the lightning path.");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 10: Enter all the mandatory details and save the BV form and click on complete.");
		String patientName=cpeName.split("-")[0].trim();
		bvPage.selectMemberPlan(patientName);
		bvPage.clickOnSavePharmacy();
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		refresh();
		refresh();

		Logger("STEP 11: Navigate to patient account and Reopen the member plan details section.Section should  load without any issues and the mentioned fields should be present and it should not get wiped off after the BV process.");
		Thread.sleep(2000);
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.clickOnPharamcyRecord();
		accountObject.verifyMemberPlanDetailsFields();
	}
}


