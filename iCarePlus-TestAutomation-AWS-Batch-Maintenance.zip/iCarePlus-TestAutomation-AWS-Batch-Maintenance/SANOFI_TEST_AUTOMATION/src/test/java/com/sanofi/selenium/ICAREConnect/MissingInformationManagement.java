package com.sanofi.selenium.ICAREConnect;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.AuthorizationFormConsentPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.ConsentCaptureDate;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.utils.ReadExcel;

public class MissingInformationManagement extends BaseTest {

	public String filePath;
	public ReadExcel excel;
	public String fileName;
	String functionality = "MissingInformationManagement";
	

	@BeforeMethod
	public void setUp() {

		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		authorizationConsentPage = GetInstance(AuthorizationFormConsentPage.class);
		consentCaptureDate = GetInstance(ConsentCaptureDate.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		sheetName = "MissingInformationManagement";
		excel = new ReadExcel(sheetName);
		uploadDocs = GetInstance(UploadDocument.class);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);


	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}
	
	@Test(description = "Missing Information Management - SIT - TC02- Tracking records for the Missing Information.", enabled = true, priority = 33)
	public void MI02_IC2068_TrackingRecordsForMissingInformation() throws Exception {
		Logger("STEP 1: Login as a Case Manager  in the Org.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Navigate to Cases Object from the App Launcher.");
		homeportalPage.closeTabs();
		missingInformatioPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5),
				MissingInformatioPage.class);
		Logger("STEP 3: Click on the New Button at the top right corner.");
		missingInformatioPage.clickOnNewButton();

		Logger("STEP 4:  validate whether the MI record has following fields on the Layout or not.");
		missingInformatioPage.selectNewCase();
		// missingInformatioPage.clickNextButton();
		missingInformatioPage.validateMIRecordFields();
		Logger("STEP 5: Navigate to the Care program Enrollees object");
		homeportalPage.closeTabs();
		missingInformatioPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7),
				MissingInformatioPage.class);

		Logger("STEP 6: User should be able to view the Recently View List of care program enrollees.");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 7: Open the related list of any existing records. ");
		String recordName = missingInformatioPage.searchAndOpenRecord();
		Logger("STEP 8: User validates whether Missing Information (MI) records are linked  for that patient and that open MI records are visible.");
		// missingInformatioPage.navigateToCPERecord(accountName);
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.verifyOpenMIRecordsVisibility();

	}

	@Test(description = "SIT_Patient Enrollment-SF-Scenario 2-Creation of MI Records as BV Specialist, DIS and Case Manager User.", enabled = true, priority = 34)
	public void MI02_IC2004_CreationOfMIRecords_BVSpecialistDISCaseMangerUser() throws Exception {
		Logger("STEP 1: Login as a BV Specialist  in the Org.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2: Navigate to the Care program Enrollees object");
		homeportalPage.closeTabs();
		missingInformatioPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7),
				MissingInformatioPage.class);

		Logger("STEP 3: User should be able to view the Recently View List of care program enrollees.");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4: Open the related list of any existing records. ");
		String recordName = missingInformatioPage.searchAndOpenRecord();

		Logger("STEP 5: Navigate to the 'Missing Information' and create a new case.");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.clickNewButton();

		Logger("STEP 6: On the 'New Case' Page, Select ‘Missing Information’");
		//missingInformatioPage.selectNewCase();
		//missingInformatioPage.verifyMissingInformationPageTitle();

		Logger("STEP 7: Click on Create and add the Missing fields in MI Piece layout.");
		missingInformatioPage.searchMissingFieldOnMILayout(recordName);
		missingInformatioPage.selectMissingFieldOnMILayout();
		missingInformatioPage.enterMissingInformation(recordName);

		Logger("STEP 8: Click on Save and verify MI Case");
		missingInformatioPage.clickOnSaveButton();
		String accountName = missingInformatioPage.verifyCaseInformation();
		String caseNumber = missingInformatioPage.getCaseNumber();

		Logger("STEP 9: CNow navigate to the MI section of the CPE record and verify the same MI case has been added to the list.");
		missingInformatioPage.navigateToCPERecord(accountName);
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.verifyMIRecord(caseNumber);

	}

	@Test(description = "SIT_Patient Enrollment-SF-Scenario 2-TC03-Validate MI record is created on submission of Enrollment form with some missing fields.", enabled = true)
	public void MI03_IC3514_CreationOfMIRecords_SubmissionOFEnrollmentFormWithSomeMissingFields() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC1";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified" };
		String removeColumnData[] = { "Address" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 10: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 11: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 12:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 13:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 15:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 16:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 17:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 12: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 13: Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 14: Open ICARE Connect App from the App launcher.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 16: Search record and click on Care program enrollee list");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);

		Logger("STEP 17: Navigate to Care Program Enrollee tab and open the newly created Care Program Enrollee and Validate that the status = Active.");
		String status = "Active";
		careProgram.checkStatusOfCPERecord(status);

		Logger("STEP 18: Navigate to the MI section in the CPE record and validate that the Missing information is created for the fields missing in the Enrollment form i.e. Patient Address.");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.verifyMIRecordCreated("Patient Address Street",statusOptionsMIOpenCases.get(0));

		Logger("STEP 19: Validate that the user is able to edit the existing MI record and mark it as Collected.");
		missingInformatioPage.changeStatusOfCreatedMICase("Patient Address Street");

		Logger("STEP 20: Now click on the \"New\" Button at the top right corner of the MI section.");
		missingInformatioPage.clickNewButton();
		missingInformatioPage.selectNewCase();

		Logger("STEP 21: Click on Create and add the Missing fields in MI Piece layout.");
		missingInformatioPage.searchMissingField(cpeName);
		missingInformatioPage.enterMissingInformation(cpeName);

		Logger("STEP 22: Click on Save and verify MI Case");
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 23: Validate MI Case");
		String accountName = missingInformatioPage.verifyMICaseInformation(cpeName);
		missingInformatioPage.verifyStepblocked();
		missingInformatioPage.verifyHCPAccountName(ExcelTestData.get(prescriberName));
		String caseNumber = missingInformatioPage.getCaseNumber();

		Logger("STEP 24: Now navigate to the MI section of the CPE record and verify the same MI case has been added to the list.");
		missingInformatioPage.navigateToCPERecord(accountName);
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.verifyMIRecord(caseNumber);

		Logger("STEP 25: Now navigate to the CPE record and Validate that based on the given table \"Blocked my MI\" section is populated..");
		missingInformatioPage.verifyStepsBlockedDutToMI(caseNumber);

		Logger("STEP 26: User Logout the Application.");
		documentsPage.logout();

	}

}
