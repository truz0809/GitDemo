package com.sanofi.selenium.testutils;
import org.testng.annotations.*;
import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.GenerateEnrollmentTestData;

public class GenerateEnrollmentFormTestData extends BaseTest {

	private GenerateEnrollmentTestData generateEFTestData;

	@Test
	public void setupTestData() throws Exception {
		Logger("Generating Enrollment Form test data...");
		generateEFTestData = new GenerateEnrollmentTestData(getWebDriver());
		generateEFTestData.generateEFTestData();
		Logger("Test data generation completed.");
	}
}
