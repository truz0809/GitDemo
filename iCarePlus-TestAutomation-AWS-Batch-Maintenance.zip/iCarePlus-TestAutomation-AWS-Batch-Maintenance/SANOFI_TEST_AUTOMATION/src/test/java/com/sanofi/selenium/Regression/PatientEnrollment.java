package com.sanofi.selenium.Regression;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.ConsentCaptureDate;
import com.sanofi.selenium.pages.CopayFlow;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.HomePortal;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PAPPage;
import com.sanofi.selenium.pages.PSQAPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;

public class PatientEnrollment extends BaseTest {
	private static ThreadLocal<String> filePath = new ThreadLocal<>();	
	public ReadExcel excel;
	public String fileName;
	public PSQAPage psqaPage;
	String functionality = "PatientEnrollment";
	private static ThreadLocal<String> filePath1 = new ThreadLocal<>();	
	public static String PatientName, PatientDoB, PatientEmail;

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		uploadDocs = GetInstance(UploadDocument.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		copayFlow = GetInstance(CopayFlow.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		consentCaptureDate = GetInstance(ConsentCaptureDate.class);
		iapPage = GetInstance(IAPPage.class);
		triagePage = GetInstance(TriagePage.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		papPage = GetInstance(PAPPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		sheetName = "PatientEnrollment";
		excel = new ReadExcel(sheetName);
		psqaPage = GetInstance(PSQAPage.class);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		homeportalPage = GetInstance(HomePortal.class);
	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE- 21664 : Automate ICARE-15079: SAT: TC01:
	 * To Validate DCR Notes functionality when HCP/HCO account is created through enrollment process
	 * 
	 * @author Amrut Chandak
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description ="ICARE-21664: SAT: TC01: To Validate DCR Notes functionality when HCP/HCO account is created through enrollment process.", enabled = true)
	public void PE39_IC15079_To_validate_DCR_Notes_Functionality_Through_Enrollment_Process() throws Exception 
	{
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC2";
		
		Logger("Pre-Requisite : Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Specialty", "Diagnosis Code" };
		String columnValue[] = { "ALLERGY","J45.40 - Moderate persistent asthma" };
		synchronized(excelDataUpdate) {
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];
		System.out.println("CPEName -- " +cpeName);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Asthma");
		filePath1.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		
		}
		System.out.println(filePath1.get());
		
		Logger("STEP 1: Login the application as DIS User..");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
		homeportalPage.closeTabs();

		Logger("STEP 1.1: Navigate to Received Documents object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

		Logger("STEP 1.2: Click on \"Select a List View\" icon and Navigate to \"Received Document Worklist\"");
		documentsPage.navigateToReceiveddocument();
		
		Logger("STEP 2: Click on Assign to me button → Open the document and classify as enrollment form and Click on Submit");
		documentsPage.clickOnAssignToMe();
		documentsPage.verifyMyReceivedDocumentsList();
		careProgram.checkNameColumnSorting();
		documentsPage.verifyDocumentName();
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(2));
		
		Logger("STEP 3: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
			String patientFirstName = name[0];
			String patientMidName = name[1];
			String patientLastName = name[2];

		Logger("STEP 3.1: Enter the CARE PROGRAM PRODUCT > Click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();
				
		Logger("STEP 3.2: In Patient Information & Authorizations pg enter all the mandatory details of the patient.");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
			String legalRepFirstName = legalRepName[0];
			String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
			ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
			ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
			ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
		patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
			ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 4: Enter all the mandatory details in the Insurance Information section > Click on next.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
				System.out.println(ExcelTestData.get(pharmacyfax));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.clickOnNextButton();		

		//Prescriber Info - Page
		Logger("STEP 5: In the Prescriber Information section fill the HCP Speciality and HCo Zip code and other details > click on next.");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];
		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
			System.out.println(ExcelTestData.get(prescriberZip));
			System.out.println(ExcelTestData.get(specialty));
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
			ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
			ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
			ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
			ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
			ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
			ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		//prescriberInformationPage.updateZipandSpeciality("ALLERGY", "21211");
		prescriberInformationPage.clickOnNextButton();
				
		// Diagnosis information-Page
		Logger("STEP 6: In the Diagnosis Information fill all the mandatory details > click on next.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
	//	diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();	

		//Prescription Information - Page
		Logger("STEP 7.1:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];		

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
		prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();
				
		Logger("STEP 7.2:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnOKConfirmation();
		
		Logger("STEP 8:Navigate to Details section --> Verify the CPE record is created and the Status is in Needs Review");
		documentsPage.verifyRecentlyViewDocumentList(); 
		documentsPage.switchToChildWindow("Enrollment Form_2025");
		documentsPage.clickOnDetailsTabChildRecord("Details");
		documentsPage.verifyFieldValue("Status", "Needs Review");
		documentsPage.verifyTheFieldValueAndClickOnTheFieldValueLink("Care Program Enrollee"); 
		
		Logger("STEP 9 , 10 & 11:Verify Prescriber and Site link is displayed on the CPE details page");		
		documentsPage.verifyFieldValue("Site", ExcelTestData.get(sitefacilityname));
		documentsPage.verifyTheFieldValueAndClickOnTheFieldValueLink("Prescriber"); 
		documentsPage.verifyFieldValue("DCR Notes", "Source of Enrollment Form");
				
		Logger("STEP 12:Navigate to Data Change Requests section ->Click on any of the DCR Record -> Verify the Type=New");
		documentsPage.goToParticularSectionInRelatedTabAndClickViewAll("Related", "Data Change Requests");
		documentsPage.clickOnDCRLink("Data Change Requests", "Name");
		documentsPage.verifyFieldValue("Type", "New");
		
		Logger("STEP 13 : Verify the picklist Value ->Partially Approved is added on the Result Field in DCR Record"); 
		documentsPage.VerifyTheDropDownValue("Result", "Partially Approved");
		documentsPage.clickOnCancel();
		
		Logger("STEP 15 : Go to Related Tab -> DCR Line Item is displayed -> Verify the value of the field is First Name ");
		documentsPage.goToParticularSectionInRelatedTabAndClickViewAll("Related","Data Change Request Line Items");
		documentsPage.clickOnDCRLineItemLink("Data Change Request Line Items", "Name");
		documentsPage.verifyFieldValue("Field Name", "First Name");
		
		Logger("STEP 16 & 17:  Verify the picklist Value ->Partially Approved is added on the Result Field in DCRL Item Record ");
		documentsPage.VerifyTheDropDownValue("Result", "Partially Approved");
		documentsPage.clickOnCancel();
		
		
		Logger("STEP 18 : Open Account Object -> Click on the HCP Record Type -> Select the value of DCR Notes as ‘None' -> Verify the DCR Notes field is marked as made as mandatory field"); 
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(3), DocumentPage.class);
		documentsPage.verifyRecentlyViewDocumentList(); 
		System.out.println(ExcelTestData.get(prescriberName));
		documentsPage.clickOnTheHCPLink("Recently Viewed", "Account Name", ExcelTestData.get(prescriberName));
		documentsPage.selectTheDropDownValue("DCR Notes" , "--None--"); 
		documentsPage.clickOnButton("Save");
		documentsPage.validateErrorMessage("DCR Notes");
		documentsPage.clickOnCancel();
		
		Logger("STEP 19 : Navigate to CPE record --> Click on the Site Link --> Verify that HCO/Facility record is displayed");
		documentsPage.goToParticularSectionInRelatedTab("Related","Patient Accounts");
		documentsPage.clickOnCPERecordLink("Datatable", "CPE");
		documentsPage.verifyTheFieldValueAndClickOnTheFieldValueLink("Site"); 
		documentsPage.verifyFieldValue("Record Type", "Facility");
		
		Logger("STEP 20 : Verify the DCR Notes field is auto Populated with the value --> Source of Enrollment Form");
		documentsPage.verifyFieldValue("DCR Notes", "Source of Enrollment Form");
		
		Logger("STEP 21 :Select the value of DCR Notes as ‘None’ --> Verify the DCR Notes field is marked as made as mandatory field"); 
		documentsPage.selectTheDropDownValue("DCR Notes" , "--None--"); 
		documentsPage.clickOnButton("Save");
		documentsPage.validateErrorMessage("DCR Notes");
		documentsPage.clickOnCancel();
		
		Logger("STEP 22 : Go to Related Tab --> Navigate to Data Change Request Section --> Verify DCR Type of Account Name is created");
		documentsPage.goToParticularSectionInRelatedTabAndClickViewAll("Related", "Data Change Requests");
		documentsPage.clickOnDCRLink("Data Change Requests", "Name");
		documentsPage.verifyFieldValue("Type", "New");
		
		Logger("STEP 23 : Verify the picklist Value ->Partially Approved is added on the Result Field in DCR Record");
		documentsPage.VerifyTheDropDownValue("Result", "Partially Approved");
		documentsPage.clickOnCancel();
		
		
		Logger("STEP 24 : Go to Related Tab -> DCR Line Item is displayed -> Verify the picklist Value ->Partially Approved is added on the Result Field in DCRL Item Record"); 
		documentsPage.goToParticularSectionInRelatedTabAndClickViewAll("Related","Data Change Request Line Items");
		documentsPage.clickOnDCRLineItemLink("Data Change Request Line Items", "Name");
		documentsPage.VerifyTheDropDownValue("Result", "Partially Approved");
		documentsPage.clickOnCancel();
		
		Logger("STEP 25 : Logout from the application");
		documentsPage.logout();				
		}
	}



	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-15216 Verify Patient Search Functionality(using
	 * FN+LN+Zip+Email) with Fuzzy Logic in Enrollment Omniscript *
	 * Need to include dob as dob is mandatory for patient search 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "ICARE-15216 - Verify Patient Search Functionality(using FN+LN+Zip+Email) with Fuzzy Logic in Enrollment Omniscript", enabled = true, priority = 5)
	public void PE01_IC15216_Verify_Patient_Search_Functionality_using_FN_LN_Zip_Email_with_Fuzzy_Logic()
			throws Exception {

		Logger("Pre-Requisite : Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC13";

		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L28.1 - Prurigo nodularis" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);
		
		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 4:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));
		
		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
		Logger("STEP 10: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		Logger("STEP 11: Enter first name, last name , zip and email and Search patient");
		patientSearch.clearExistingFields();
		patientSearch.enterCareProgram(careProgramProduct.get(0));
		patientSearch.verifyFuzzyLogicExistingPatient(firstName.get(0), lastName.get(0), emails.get(0), null,
				zips.get(0), dobs.get(0));

		Logger("STEP 12: Verify that the search functionality works with Fuzzy Logic at High Precision (matches nicknames, punctuation, international characters, and cultural spellings).");
		patientSearch.validateSearchResult(existingAccNames.get(5));

		Logger("STEP 13: Enter first name, last name,zip and mail and Search patient");
		patientSearch.clearExistingFields();
		patientSearch.enterCareProgram(careProgramProduct.get(0));
		patientSearch.verifyFuzzyLogicExistingPatient(firstName.get(1), lastName.get(0), emails.get(0), null,
				zips.get(0), dobs.get(0));

		Logger("STEP 14: Verify that the search functionality works with Fuzzy Logic at Medium Precision (matches initials, gender variants, shuffled names, and common nicknames).");
		patientSearch.validateSearchResult(existingAccNames.get(5));

		Logger("STEP 15: Enter first name, last name , zip and email and Search patient");
		patientSearch.clearExistingFields();
		patientSearch.enterCareProgram(careProgramProduct.get(1));
		patientSearch.verifyFuzzyLogicExistingPatient(firstName.get(2), lastName.get(2), emails.get(1), null,
				zips.get(0), dobs.get(0));

		Logger("STEP 16: Verify that the search functionality works with Fuzzy Logic at Low Precision (matches loose similarities).");
		patientSearch.validateSearchResult(existingAccNames.get(4));
		patientSearch.clickOnNextButton();

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.clickOnNextButton();

		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		prescriberInformationPage.clickOnNextButton();
		diagnosisinformation.clickOnNextButton();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 17: Verify that the search functionality works with Confirm page->Navigate to Confirm page → Click on Search button");
		patientSearch.validateSearchResult(existingAccNames.get(4));

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-10064: SIT: TC06-Verify Patient Search Functionality
	 * (using FN+LN+Zip+DOB+Phone +Email) with Fuzzy Logic in Enrollment Omniscript
	 * 
	 * @author Sonica P
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "ICARE_15204_-10064: SIT: TC06-Verify Patient Search Functionality (using FN+LN+Zip+DOB+Phone +Email) with Fuzzy Logic in Enrollment Omniscript", enabled = true)
	public void PE02_ICARE_15204_Verify_Patient_Search_Functionality_with_Fuzzy_Logic_in_Enrollment_Omniscript()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC2";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		excelDataUpdate.selectExcelSheet(functionality);

		String columnName[] = { "Patient Name", "Zip", "Patient Email", "Patient DOB", "Patient Primary phone" };
		String columnValue[] = { fuzzyPatientData5.get(0), fuzzyPatientData5.get(2), fuzzyPatientData5.get(3),
				fuzzyPatientData5.get(4), fuzzyPatientData5.get(5) };

		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_fuzzySearch);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Nasal Polyps");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		

		Logger("STEP 10: Enter First Name, Last Name, Zip Code and Phone → Search Patient");
		patientSearch.verifyPatientSearchPageTitle();
		patientSearch.clearExistingFields();
		patientSearch.enterCareProgram(careProgramProduct.get(2));
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData5.get(0), fuzzyPatientData5.get(1),
				fuzzyPatientData5.get(3), fuzzyPatientData5.get(5), fuzzyPatientData5.get(2), fuzzyPatientData5.get(4));

		Logger("STEP 11: Verify that the search functionality works with Fuzzy Logic at High Precision (matches nicknames, punctuation, international characters, and cultural spellings).");
		patientSearch.validateSearchResult(existingPatientData5.get(0));

		Logger("STEP 12: Enter First Name, Last Name, Zip Code and Phone Number → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData6.get(0), fuzzyPatientData6.get(1),
				fuzzyPatientData6.get(3), fuzzyPatientData6.get(5), fuzzyPatientData6.get(2), fuzzyPatientData6.get(4));

		Logger("STEP 13: Verify that the search functionality works with Fuzzy Logic at Medium Precision (matches initials, gender variants, shuffled names, and common nicknames)");
		patientSearch.validateSearchResult(existingPatientData5.get(1));

		Logger("STEP 14:Enter First Name, Last Name, Zip Code and Phone Number → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData7.get(0), fuzzyPatientData7.get(1),
				fuzzyPatientData7.get(3), fuzzyPatientData7.get(5), fuzzyPatientData7.get(2), fuzzyPatientData7.get(4));

		Logger("STEP 15: Verify that the search functionality works with Fuzzy Logic at Low Precision (matches initials, gender variants, shuffled names, and common nicknames)");
		patientSearch.validateSearchResult(existingPatientData5.get(2));

		Logger("STEP 16: Click on next button");
		patientSearch.clickOnNextButton();

		Logger("STEP 17:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(fuzzyPatientData1.get(0), fuzzyPatientData1.get(1), fuzzyPatientData1.get(1),
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));	
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 18:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 19:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 20:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 21:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 22: Verify that the search functionality works with Confirm page");
		patientSearch.validateSearchResult(existingPatientData5.get(2));

		Logger("STEP 23: User Logout the Application.");
		documentsPage.logout();

	}

/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE- 24604 : Automate iCare18054: SIT:TC03: Verify the Med D AR Case Flow with the AR Specialist User
	 * 
	 * @author Amrut Chandak
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description ="ICARE-24604: SAT: TC03: To  Verify the Med D AR Case Flow with the AR Specialist User.", enabled = true)
	public void PE40_IC24604_To_Verify_The_Med_D_AR_Case_Flow_With_The_AR_Specialist_User() throws Exception 
	{
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC6";
		
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];
		System.out.println("CPEName "+cpeName);

		Logger("Pre-Requisites - STEP 1 : User updates the Patient Form");
		synchronized (updatepdf) 
		{
		updatepdf.selectEnrollmentForm("Asthma");
		//updatepdf.selectEnrollmentForm("COPD");
		filePath1.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		
		}
		System.out.println(filePath1.get());
		
		System.out.println("The Sheet is created");

		Logger("Pre-Requisites - STEP 2 : Login to the Dupixient portal as 'Program Manager'");
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-Requisites - STEP 3 : Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath1.get(), cpeDetails);
		
		Logger ("Pre-Requisites - STEP 4 : Login as 'PSR User'");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(PSRUserName, UserPassword);
		
		//Logger("Pre-Requisites - STEP 5 : Navigate To Recently View Document list");
		//homeportalPage.closeTabs();
		//documentsPage.verifyRecentlyViewDocumentList();
		
		Logger("Pre-Requisites - STEP 5 : User will be redirected to the 'My Received Document' list view, Open the Document.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));  
		
		Logger("Pre-Requisites - STEP 6 : Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(2));
		documentsPage.submitDocument();
		//documentsPage.verifyOCRStatus(documentOCRstatus.get(2));
		
		Logger("Pre-Requisites - STEP 7 : Enter the patient details --> search & select the details");
		patientSearch.verifyPatientSearchPageTitle();
		//patientSearch.selectExistingPatient2(careProgramProduct.get(2));
		patientSearch.SearchAndSelectActivePatientDetails();
		   
		Logger("Pre-Requisites - STEP 8 : Fill the mandatory fields in the PSQA Review Page and click on submit"); 
		psqaPage.verifyPSQAReviewPageTitle(); 
		psqaPage.selectPSQAReviewCheckbox("Product Technical Complaint");
		psqaPage.enterCaseManagerName("Case Manager2");
		psqaPage.clickOnSubmitButton();
						
		Logger("STEP 1: Login the application as AR Specialist User..");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(ARSUserName, UserPassword);
		homeportalPage.closeTabs();
		
		Logger("STEP 2: Navigate to the Cases object and go to the 'AR Specialist Queue' list view");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5), DocumentPage.class);
		documentsPage.navigateToRecentlyViewedListView(); 
		documentsPage.verifyRecentlyViewDocumentList();
		documentsPage.navigateToCaseListView(); 
		
		Logger("STEP 3: Click on Assign to me button → Open the document and classify as enrollment form and Click on Submit");
		documentsPage.clickOnAssignToMe();
		careProgram.sortTheRespectiveColumn("Date/Time Opened");
		documentsPage.navigateToRecentlyViewedListView();
		documentsPage.clickOnTheDocumentName("Record Type", "Med D AR", "In Progress");
		//documentsPage.verifyDocumentName();
	
		Logger("STEP 4: Verify the Status of the Case is updated to - In progress");
		documentsPage.verifyFieldValue("Status", "In Progress");
		//documentsPage.verifyAndCLickOnLink("Care Program Enrollee");
		
		
		Logger("STEP 5 & 6 : Click on the CPE link --> Verfiy the AR Specialist field is auto-populated as AR Specialist User");
		documentsPage.verifyTheFieldValueAndClickOnTheFieldValueLink("Care Program Enrollee");
		documentsPage.verifyFieldValue("AR Specialist", "Abhijeet Gurjat CM");
		
		Logger("STEP 8 : Click on the related tab --> Go to the Cases related list --> Open the MED D AR case"); 
		//documentsPage.goToParticularSectionInRelatedTab("Related", "Cases ");
		documentsPage.goToParticularSectionInRelatedTabAndClickViewAll("Related", "Cases");
		documentsPage.clickOnRecordBasedOnRecordTypeAndStatus("Cases", "Record Type", "Med D AR" , "Status", "In Progress");
	
		Logger("STEP 9 : Update the status field as closed");
		documentsPage.verifyFieldValue("Status", "In Progress");	
		documentsPage.EditAndUpdateTheCaseFields("Status" , "Closed");
		documentsPage.UpdateTheCaseFields("Change in Insurance Plan?" , "Yes");
		documentsPage.UpdateTheCaseFields("Outcome" , "Cancelled");
		documentsPage.clickOnSave();
	
		Logger("STEP 10 & 11: Click on CPE Link --> Valdiate the AR Specialist field is blank ");
		documentsPage.verifyTheFieldValueAndClickOnTheFieldValueLink("Care Program Enrollee");
		documentsPage.verifyFieldValue("AR Specialist", " ");
		documentsPage.verifyCheckBoxIsCheckedOrNot("AR in Progress");
		
		Logger("STEP 12 : Click on Logout"); 
		documentsPage.logout();		
	}	



	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-15203 Verify Patient Search Functionality (using
	 * FN+LN+Zip+Phone +Email) with Fuzzy Logic in Enrollment Omniscript *
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "ICARE-15203-Verify Patient Search Functionality (using FN+LN+Zip+Phone +Email) with Fuzzy Logic in Enrollment Omniscript'", enabled = true, priority = 5)
	public void PE03_IC15203_Verify_Patient_Search_Functionality_using_FN_LN_Zip_Phone_Email_with_Fuzzy_Logic()
			throws Exception {

		Logger("Pre-Requisite : Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC19";

		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L28.1 - Prurigo nodularis" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get()); 

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 4:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
	
		Logger("STEP 10: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		Logger("STEP 11: Enter First Name, Last Name, Zip Code, Phone, Email  → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.enterCareProgram(careProgramProduct.get(1));
    	patientSearch.verifyFuzzyLogicExistingPatient(firstName.get(0), lastName.get(0), emails.get(0),
				phoneNumbers.get(0), zips.get(0), dobs.get(0));

		Logger("STEP 12: Verify that the search functionality works with Fuzzy Logic at High Precision (matches nicknames, punctuation, international characters, and cultural spellings).");
		patientSearch.validateSearchResult(existingAccNames.get(5));

		Logger("STEP 13: Enter First Name, Last Name, Zip Code, Phone, Email  → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.enterCareProgram(careProgramProduct.get(1));
		patientSearch.verifyFuzzyLogicExistingPatient(firstName.get(5), lastName.get(4), emails.get(2),
				phoneNumbers.get(1), zips.get(1), dobs.get(1));

		Logger("STEP 14:Verify that the search functionality works with Fuzzy Logic at Medium Precision (matches initials, gender variants, shuffled names, and common nicknames).");
		patientSearch.validateSearchResult(existingAccNames.get(3));

		Logger("STEP 15: Enter first name, last name , zip and email and Search patient");
		patientSearch.clearExistingFields();
		patientSearch.enterCareProgram(careProgramProduct.get(1));
		patientSearch.verifyFuzzyLogicExistingPatient(firstName.get(2), lastName.get(2), emails.get(1),
				phoneNumbers.get(0), zips.get(0), dobs.get(0));

		Logger("STEP 16: Verify that the search functionality works with Fuzzy Logic at Low Precision (matches loose similarities).");
		patientSearch.validateSearchResult(existingAccNames.get(4));
		patientSearch.clickOnNextButton();

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(fuzzyPatientData1.get(0), fuzzyPatientData1.get(1), fuzzyPatientData1.get(1),
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.clickOnNextButton();

		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		prescriberInformationPage.clickOnNextButton();
		diagnosisinformation.clickOnNextButton();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 17: Verify that the search functionality works with Confirm page->Navigate to Confirm page → Click on Search button");
		patientSearch.validateSearchResult(existingAccNames.get(4));

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-15202 Verify Patient Search Functionality (using
	 * FN+LN+Zip+Patient DOB+Email) with Fuzzy Logic in Enrollment Omniscript
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Verify Patient Search Functionality (using FN+LN+Zip+Patient DOB+Email) with Fuzzy Logic in Enrollment Omniscriptb", enabled = true)
	public void PE04_IC15202_Verify_Patient_Search_Functionality_with_Fuzzy_Logic_in_Enrollment_Omniscript()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC4";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		excelDataUpdate.selectExcelSheet(functionality);

		String columnName[] = { "Patient Name", "Zip", "Patient Email" };
		String columnValue[] = { fuzzyPatientData1.get(0), fuzzyPatientData1.get(2), fuzzyPatientData1.get(3) };

		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_fuzzySearch);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Nasal Polyps");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
		Logger("STEP 10: Enter First Name, Last Name, Zip Code, Patient DOB, Email  → Search Patient");
		patientSearch.verifyPatientSearchPageTitle();
		patientSearch.clearExistingFields();
		patientSearch.enterCareProgram(careProgramProduct.get(2));
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData1.get(0), fuzzyPatientData1.get(1),
				fuzzyPatientData1.get(3), null, fuzzyPatientData1.get(2), fuzzyPatientData1.get(4));

		Logger("STEP 11: Verify that the search functionality works with Fuzzy Logic at High Precision (matches nicknames, punctuation, international characters, and cultural spellings).");
		patientSearch.validateSearchResult(existingPatientData.get(0));

		Logger("STEP 12: Enter First Name, Last Name, Zip Code and Phone Number → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData2.get(5), fuzzyPatientData2.get(1),
				fuzzyPatientData2.get(3), null, fuzzyPatientData2.get(2), fuzzyPatientData2.get(4));

		Logger("STEP 13: Verify that the search functionality works with Fuzzy Logic at Medium Precision (matches initials, gender variants, shuffled names, and common nicknames)");
		patientSearch.validateSearchResult(existingPatientData.get(3));

		Logger("STEP 14:Enter First Name, Last Name, Zip Code, Patient DOB, Email  → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData3.get(0), fuzzyPatientData3.get(1),
				fuzzyPatientData3.get(3), null, fuzzyPatientData3.get(2), fuzzyPatientData3.get(4));

		Logger("STEP 15: Verify that the search functionality works with Fuzzy Logic at Low Precision (matches initials, gender variants, shuffled names, and common nicknames)");
		patientSearch.validateSearchResult(existingPatientData.get(1));

		Logger("STEP 16: Click on next button");
		patientSearch.clickOnNextButton();

		Logger("STEP 17:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(fuzzyPatientData1.get(0), fuzzyPatientData1.get(1), fuzzyPatientData1.get(1),
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 18:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));	
		insuranceinfo.clickOnNextButton();

		Logger("STEP 19:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 20:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 21:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 22: Verify that the search functionality works with Confirm page");
		patientSearch.validateSearchResult(existingPatientData.get(1));

		Logger("STEP 23: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-18009 RGN-PE: Automate ICARE-10064: SIT: TC03-Verify
	 * Patient Search Functionality (using FN+LN+Zip+Patient DOB+Phone) with Fuzzy
	 * Logic in Enrollment Omniscript
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE-10064: SIT: TC03-Verify Patient Search Functionality (using FN+LN+Zip+Patient DOB+Phone) with Fuzzy Logic in Enrollment Omniscript", enabled = true)
	public void PE05_IC15198_Verify_Patient_Search_Functionality_using_FN_LN_Zip_Patient_DOB_Phone_with_Fuzzy_Logic_in_Enrollment_Omniscript()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC5";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		excelDataUpdate.selectExcelSheet(functionality);

		String columnName[] = { "Patient Name", "Zip", "Patient Primary phone", "Patient DOB" };
		String columnValue[] = { fuzzyPatientData1.get(0), fuzzyPatientData1.get(2), fuzzyPatientData1.get(6),
				fuzzyPatientData1.get(4) };

		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_fuzzySearch);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Nasal Polyps");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
		Logger("STEP 10: Enter First Name, Last Name, Zip Code, Patient DOB and Phone → Search Patient");
		patientSearch.verifyPatientSearchPageTitle();
		patientSearch.clearExistingFields();
		patientSearch.enterCareProgram(careProgramProduct.get(2));
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData1.get(0), fuzzyPatientData1.get(1), null,
				fuzzyPatientData1.get(6), fuzzyPatientData1.get(2), fuzzyPatientData1.get(4));

		Logger("STEP 11: Verify that the search functionality works with Fuzzy Logic at High Precision (matches nicknames, punctuation, international characters, and cultural spellings).");
		patientSearch.validateSearchResult(existingPatientData.get(0));

		Logger("STEP 12: Enter First Name, Last Name, Zip Code and Phone Number → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData2.get(5), fuzzyPatientData2.get(1), null,
				fuzzyPatientData2.get(6), fuzzyPatientData2.get(2), fuzzyPatientData2.get(4));

		Logger("STEP 13: Verify that the search functionality works with Fuzzy Logic at Medium Precision (matches initials, gender variants, shuffled names, and common nicknames)");
		patientSearch.validateSearchResult(existingPatientData.get(3));

		Logger("STEP 14:Enter First Name, Last Name, Zip Code and Phone Number → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData3.get(0), fuzzyPatientData3.get(1), null,
				fuzzyPatientData3.get(6), fuzzyPatientData3.get(2), fuzzyPatientData3.get(4));

		Logger("STEP 15: Verify that the search functionality works with Fuzzy Logic at Low Precision (matches initials, gender variants, shuffled names, and common nicknames)");
		patientSearch.validateSearchResult(existingPatientData.get(1));

		Logger("STEP 16: Click on next button");
		patientSearch.clickOnNextButton();

		Logger("STEP 17:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(fuzzyPatientData1.get(0), fuzzyPatientData1.get(1), fuzzyPatientData1.get(1),
				fuzzyPatientData1.get(4), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 18:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));	
		insuranceinfo.clickOnNextButton();

		Logger("STEP 19:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 20:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 21:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 22: Verify that the search functionality works with Confirm page");
		patientSearch.validateSearchResult(existingPatientData.get(1));

		Logger("STEP 23: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-15186 TC07-Verify Patient Search Functionality (using
	 * FN+LN+Zip) with Fuzzy Logic in Enrollment Omniscript
	 * @MaintainanceAuthor  Navita - Need to include DOB field in patient search
	 * @author Tejal
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "To validate List Views are updated on Received Document", enabled = true)
	public void PE06_IC15186_IC_18010_Verify_Patient_Search_Functionality_with_Fuzzy_Logic_in_Enrollment_Omniscript()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC6";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		excelDataUpdate.selectExcelSheet(functionality);

		String columnName[] = { "Patient Name", "Zip" };
		String columnValue[] = { fuzzyPatientData1.get(7), fuzzyPatientData1.get(2) };

		// excelDataUpdate.removeExcelData(TestCaseNumber,
		// removeColumnData_fuzzySearch_15186);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_fuzzySearch);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Nasal Polyps");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 10: Enter First Name, Last Name, Zip Code and Phone → Search Patient");
		patientSearch.verifyPatientSearchPageTitle();
		patientSearch.clearExistingFields();
		patientSearch.enterCareProgram(careProgramProduct.get(2));
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData1.get(7), fuzzyPatientData1.get(1), null, null,
				fuzzyPatientData1.get(2), fuzzyPatientData1.get(4));
		Thread.sleep(2000);

		Logger("STEP 11: Verify that the search functionality works with Fuzzy Logic at High Precision (matches nicknames, punctuation, international characters, and cultural spellings).");
		patientSearch.validateSearchResult(existingPatientData.get(0));

		Logger("STEP 12: Enter First Name, Last Name, Zip Code and Phone Number → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData3.get(5), fuzzyPatientData3.get(1), null, null,
				fuzzyPatientData3.get(2), fuzzyPatientData3.get(4));

		Logger("STEP 13: Verify that the search functionality works with Fuzzy Logic at Medium Precision (matches initials, gender variants, shuffled names, and common nicknames)");
		patientSearch.validateSearchResult(existingPatientData.get(1));

		Logger("STEP 14:Enter First Name, Last Name, Zip Code and Phone Number → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData3.get(7), fuzzyPatientData3.get(8), null, null,
				fuzzyPatientData3.get(2), fuzzyPatientData3.get(4));

		Logger("STEP 15: Verify that the search functionality works with Fuzzy Logic at Low Precision (matches initials, gender variants, shuffled names, and common nicknames)");
		patientSearch.validateSearchResult(existingPatientData.get(1));

		Logger("STEP 16: Click on next button");
		patientSearch.clickOnNextButton();

		Logger("STEP 17:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(fuzzyPatientData1.get(0), fuzzyPatientData1.get(1), fuzzyPatientData1.get(1),
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 18:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 19:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 20:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 21:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 22: Verify that the search functionality works with Confirm page");
	//	formConfirmation.searchPatientConfirmPage();
		patientSearch.validateSearchResult(existingPatientData.get(1));

		Logger("STEP 23: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-18024 RGN-PE: Automate ICARE-10064: SIT: TC01-Verify
	 * Patient Search Functionality(using FN+LN+Zip+Patient DOB) with Fuzzy Logic in
	 * Enrollment Omniscript
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SIT: TC01-Verify Patient Search Functionality(using FN+LN+Zip+Patient DOB) with Fuzzy Logic in Enrollment Omniscript", enabled = true)
	public void PE07_IC13314_Verify_Patient_Search_Functionality_using_FN_LN_Zip_PatientDOB_with_Fuzzy_Logic_in_Enrollment_Omniscript()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC7";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		excelDataUpdate.selectExcelSheet(functionality);

		String columnName[] = { "Patient Name", "Zip", "Patient DOB" };
		String columnValue[] = { fuzzyPatientData1.get(0), fuzzyPatientData1.get(2), fuzzyPatientData1.get(4) };

		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_fuzzySearch);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Nasal Polyps");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 10: Enter First Name, Last Name, Zip Code, Patient DOB → Search Patient");
		patientSearch.verifyPatientSearchPageTitle();
		patientSearch.clearExistingFields();
		patientSearch.enterCareProgram(careProgramProduct.get(2));
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData1.get(0), fuzzyPatientData1.get(1), null, null,
				fuzzyPatientData1.get(2), fuzzyPatientData1.get(4));

		Logger("STEP 11: Verify that the search functionality works with Fuzzy Logic at High Precision (matches nicknames, punctuation, international characters, and cultural spellings).");
		patientSearch.validateSearchResult(existingPatientData.get(0));

		Logger("STEP 12: Enter First Name, Last Name, Zip Code and DOB → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData2.get(5), fuzzyPatientData2.get(1), null, null,
				fuzzyPatientData2.get(2), fuzzyPatientData2.get(4));

		Logger("STEP 13: Verify that the search functionality works with Fuzzy Logic at Medium Precision (matches initials, gender variants, shuffled names, and common nicknames)");
		patientSearch.validateSearchResult(existingPatientData.get(1));

		Logger("STEP 14:Enter First Name, Last Name, Zip Code and DOB → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData3.get(0), fuzzyPatientData3.get(1), null, null,
				fuzzyPatientData3.get(2), fuzzyPatientData3.get(4));

		Logger("STEP 15: Verify that the search functionality works with Fuzzy Logic at Low Precision (matches initials, gender variants, shuffled names, and common nicknames)");
		patientSearch.validateSearchResult(existingPatientData.get(1));

		Logger("STEP 16: Click on next button");
		patientSearch.clickOnNextButton();

		Logger("STEP 17:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(fuzzyPatientData1.get(0), fuzzyPatientData1.get(1), fuzzyPatientData1.get(1),
				fuzzyPatientData1.get(4), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 18:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 19:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 20:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 21:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 22: Verify that the search functionality works with Confirm page");
	//	formConfirmation.searchPatientConfirmPage();
		patientSearch.validateSearchResult(existingPatientData.get(1));

		Logger("STEP 23: Negative Scenario: Enter incorrect First Name and Last Name (e.g., totally unrelated names) → Search Patient");
		patientSearch.navigateToInprogressEFpages("Patient Search");
		patientSearch.clearExistingFields();
		patientSearch.verifyFuzzyLogicExistingPatient("ABC", "XYZ", null, fuzzyPatientData1.get(6),
				fuzzyPatientData1.get(2), fuzzyPatientData1.get(4));
		patientSearch.verifyNorecords();

		Logger("STEP 24: Negative Scenarios: Enter only Zip Code without First Name and Last Name → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData1.get(0), fuzzyPatientData1.get(1), null, null,
				null, fuzzyPatientData1.get(4));
		patientSearch.verifyMinCriteriaNotMet();

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-15674 Regression Enroll: Automate ICARE-10793: SIT: TC02:
	 * To validate that CM, NE, PM, BO and System Admin users should access to all
	 * List Views from Received Document Object
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE-10793: SIT: TC02: To validate that CM, NE, PM, BO and System Admin users should access to all List Views from Received Document Object.", enabled = true)
	public void PE08_IC11810_To_validate_that_CM_NE_PM_BO_and_System_Admin_users_should_access_to_all_List_Views_from_Received_Document_Object()
			throws Exception {

		Logger("STEP 1: Login the application as CM User..");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Navigate to Received Documents object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

		Logger("STEP 3: Click on \"Select a List View\" icon and verify that \"All Received Documents\",\" Recently Viewed (pinned list)\",\" Recently Viewed Received Documents\", \"Received Document Worklist\" and \"My Received Documents \"list views are accessible from Received Document object List view.	");
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		for (String listView : RecivedlistViewFilters) {
			docMgmt.validateListViewFilters(listView);
		}

		Logger("STEP 4: Logout out the application as CM User.");
		documentsPage.logout();

		Logger("STEP 5: Login the application as PM user");
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);

		Logger("STEP 5.1: Navigate to Received document worklist and validate all list views are present and accessible by PM user. All Received documents, My Received Documents, PSQA Review Worklist, Recently Viewed (Pinned List),Recently Viewed Received Documents, Received Document Worklist");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		for (String listView : RecivedlistViewFilters) {
			docMgmt.validateListViewFilters(listView);
		}
		docMgmt.validateListViewFilters("PSQA Review Worklist");
		documentsPage.logout();

		Logger("STEP 6: Login the application as NE user");
		homeportalPage = loginPage.userLogin(NurseEduUserName, UserPassword);

		Logger("STEP 6.1: Navigate to Received document worklist and validate all list views are present and accessible by NE user. All Received documents, My Received Documents, Recently Viewed (Pinned List),Recently Viewed Received Documents.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		for (String listView : ListViewFilters_BO_NE) {
			docMgmt.validateListViewFilters(listView);
		}
		documentsPage.logout();

		Logger("STEP 7: Login the application as BO user");
		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);

		Logger("STEP 7.1: Navigate to Received document worklist and validate all list views are present and accessible by BO user. All Received documents, My Received Documents, Recently Viewed (Pinned List),Recently Viewed Received Documents.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		for (String listView : ListViewFilters_BO_NE) {
			docMgmt.validateListViewFilters(listView);
		}
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-10879 To validate List Views are updated on Received
	 * Document
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "To validate List Views are updated on Received Document", enabled = true)
	public void PE09_IC10879_To_validate_List_Views_are_updated_on_Received_Document() throws Exception {

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));

		
		Logger("STEP 3: Click on Select a List View icon and verify that All Received Documents list views are hidden from Received Document object List view.");

		documentsPage.verifyAllReceivedDocumentIsHidden();
		documentsPage.clickOnListView();

		Logger("STEP 4: Verify that DIS user is able to access Received Document Worklist,Recently Viewed pinned list,Recently Viewed Received Documents and My Received Documents List Views");
		documentsPage.verifyListViewAsDISUser();

		Logger("STEP 5: Logout the application as DIS User.");
		documentsPage.logout();

		Logger("STEP 6: Login the application as ‘Program Coordinator’ User.");
		homeportalPage = loginPage.userLogin(PCUserName, UserPassword);

		Logger("STEP 7:Navigate to Received Documents object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		Logger("STEP 8:Click on Select a List View icon and verify that All Received Documents  list views are hidden from Received Document object List view.");
		
		documentsPage.verifyAllReceivedDocumentIsHidden();
		

		Logger("STEP 9: Verify that PC user is able to access My Received Documents, PSQA Review Worklist, Recently Viewed Pinned List and Recently Viewed Received Documents List Views.");
		documentsPage.verifyListViewAsPCUser();

		Logger("STEP 10: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7346 Triggering Validation Rules when editing an HCP type
	 * Account Record
	 * 
	 * @author Anand Pawar
	 * @throws Exception
	 * 
	 *                   ====================================================================================================================
	 */
	@Test(description = "Triggering Validation Rules when editing a Facilities type Account Record", enabled = true)
	public void PE10_IC7346_Triggering_Validation_Rules_when_editing_an_HCP_type_Account_Record() throws Exception {

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		homeportalPage.closeTabs();

		Logger("STEP 2: Navigate to the Accounts object via the App Launcher.");
		accountObject.navigateToAccount();

		documentsPage.navigateToAllHCPS();

		Logger("STEP 4: Select an existing record.");
		accountObject.clickFacility();

		Logger("STEP 7:Enter a 11-digit number for the Phone field then click Save.'");
		docMgmt.clickEditBtn();
		docMgmt.editAndPassPhone();
		docMgmt.enterCredentials();
		docMgmt.selectDCRNotes("Source of Enrollment Form");
		docMgmt.clickSave();

		Logger("STEP 8:Validate error is encountered stating 'ACC-VR37: Phone only accepts 10-digit number.'");
		docMgmt.validatePhoneErrorMsg();

		Logger("STEP 9:Enter a 6-digit number for the Billing Zip/Postal Code field then click Save.'");
		docMgmt.editZip();
		docMgmt.clickSave();

		Logger("STEP 10:Validate error is encountered stating 'ACC-VR39: Billing Zip/Postal Code only accepts 5-digit number'");
		docMgmt.validateZipErrorMsg();
//		docMgmt.clickCancel();

		// Validate NPI
		Logger("STEP 9:Enter a 6-digit number for the Billing Zip/Postal Code field then click Save.'");
		docMgmt.editNPI();
		docMgmt.clickSave();

		Logger("STEP 10:Validate error is encountered stating 'ACC-VR39: Billing Zip/Postal Code only accepts 5-digit number'");
		docMgmt.validateNPIErrorMsg();
		docMgmt.clickCancel();

		Logger("STEP 11: User Logout the Application.");
		documentsPage.logout();

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC10";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//					Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//					documentsPage.navigateToReceiveddocument();
//					documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		prescriptioninformation.verifyPrescriptionInfoPageTitle();

		Logger("STEP 10:Enter 11 digit NPI and validate error message");
		prescriptioninformation.enterIncorrectNPI();
		prescriptioninformation.clickOnNextButton();
		prescriptioninformation.validateNPIError();

		Logger("STEP 46: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7345 Triggering Validation Rules when editing a Facilities
	 * type Account Record
	 * 
	 * @author Anand Pawar
	 * @throws Exception
	 * 
	 *                   ====================================================================================================================
	 */
	@Test(description = "Triggering Validation Rules when editing a Facilities type Account Record", enabled = true)
	public void PE11_IC7345_Triggering_Validation_Rules_when_editing_a_Facilities_type_Account_Record() {

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		homeportalPage.closeTabs();

		Logger("STEP 2: Navigate to the Accounts object via the App Launcher.");
		accountObject.navigateToAccount();

		Logger("STEP 3: Switch to the All Facilities list view.");
		documentsPage.navigateToAllFacilities();


		Logger("STEP 4: Select an existing record.");
		accountObject.clickFacility();

		Logger("STEP 5: Click the Edit Fax button,Enter a 11-digit number for the Fax field then click Save");
		docMgmt.editAndPassFax();
		docMgmt.selectDCRNotes("Source of Enrollment Form");
		docMgmt.clickSave();

		Logger("STEP 6:Validate error is encountered stating 'ACC-VR36: Fax only accepts 10-digit number.'");
		docMgmt.validateFaxErrorMsg();

		Logger("STEP 7:Enter a 11-digit number for the Phone field then click Save.'");
		docMgmt.editAndPassPhone();
		docMgmt.clickSave();

		Logger("STEP 8:Validate error is encountered stating 'ACC-VR37: Phone only accepts 10-digit number.'");
		docMgmt.validatePhoneErrorMsg();

		Logger("STEP 9:Enter a 6-digit number for the Billing Zip/Postal Code field then click Save.'");
		docMgmt.editZip();
		docMgmt.clickSave();

		Logger("STEP 10:Validate error is encountered stating 'ACC-VR39: Billing Zip/Postal Code only accepts 5-digit number'");
		docMgmt.validateZipErrorMsg();
		docMgmt.clickCancel();

		Logger("STEP 11: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7343 Automate Triggering Validation Rules for a New
	 * Patient type Account Record.
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Automate Triggering Validation Rules for a New Patient type Account Record.", enabled = true)
	public void PE12_IC7343_Automate_Triggering_Validation_Rules_for_a_New_Patient_type_Account_Record()
			throws Exception {

		Logger("STEP 1: Login to the QA_SIT Org as 'Case manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Navigate to the Accounts object via the App Launcher.");
		accountObject.navigateToAccount();

		Logger("STEP 3:Click the New button.");
		accountObject.clickOnNew();
		refresh();

		Logger("STEP 4: Select Patient and then click Next.");
		Thread.sleep(6000);
		accountObject.selectPatient();

		Logger("STEP 5: Enter an 11-digit number for the Phone field then click Save ");
		accountObject.verifyPhoneField();
		accountObject.clickOnSave();

		Logger("STEP 6: Verify validation Error is encountered  stating \"ACC-VR37: Phone only accepts 10-digit number.\"");
		accountObject.validatedErrorMessageForPhone();

		Logger("STEP 7: Enter an 11-digit number for the Other Phone field then click Save.");
		accountObject.verifyOtherPhoneField();
		accountObject.clickOnSave();

		Logger("STEP 8: Verify validation Error is encountered  stating \"ACC-VR38: Other Phone only accepts 10-digit number.\" ");
		accountObject.validatedErrorMessageForOtherPhone();

		Logger("STEP 9: Enter a 6-digit number for the Mailing Zip/Postal Code then click Save.");
		accountObject.verifyMailingZipField();
		accountObject.clickOnSave();

		Logger("STEP 10: Verify validation Error is encountered  statingstating \"ACC-VR40: Mailing Zip/Postal Code only accepts 5-digit number. ");
		accountObject.validatedErrorMessageForMailingZip();

		Logger("STEP 11: Logout as a case manager.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7344 Automate Triggering Validation Rules for a New Office
	 * Contact type Account Record.
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Automate Triggering Validation Rules for a New Office Contact type Account Record.", enabled = true)
	public void PE13_IC7344_Automate_Triggering_Validation_Rules_for_a_New_Office_Contact_type_Account_Record()
			throws Exception {

		Logger("STEP 1: Login to the QA_SIT Org as 'Case manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Navigate to the Accounts object via the App Launcher.");
		accountObject.navigateToAccount();

		Logger("STEP 3:Click the New button.");
		accountObject.clickOnNew();
		refresh();

		Logger("STEP 4: Select office contact and then click Next.");
		accountObject.selectOfficeContact();

		Logger("STEP 5: Enter a 6-digit number for the Billing Zip/Postal Code then click Save. ");
		accountObject.verifyBillingZipField();
		accountObject.clickOnSave();

		Logger("STEP 6: Verify validation Error is encountered  stating \"ACC-VR39: Billing Zip/Postal Code only accepts 5-digit number.\"");
		accountObject.validatedErrorMessageForBillingZip();

		Logger("STEP 7: Logout as a case manager.");
		documentsPage.logout();

	}

	/**
	 * 
	 * ====================================================================================================================
	 * ICARE-10614: Regression-PatientEnroll: Automate the updated fields on
	 * Received Documents and Correspondence object
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "TC01_Validate the updated fields on Received Documents and Correspondence object.", enabled = true)
	public void PE14_IC7323_Validate_the_updated_fields_on_Received_Documents_and_Correspondence_object()
			throws Exception {

		int numberOfUsers = 3;
		SoftAssert softassert = new SoftAssert();
		String currentUser = "";
		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
				case 0:
					Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
					homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
					currentUser = "CM";
					break;
				case 1:
					Logger("STEP 1: Login to the QA_SIT Org as 'PC User'.");
					homeportalPage = loginPage.userLogin(PCUserName, UserPassword);
					currentUser = "PC";
					refresh();
					break;
				case 2:
					Logger("STEP 1: Login to the QA_SIT Org as 'DIS User'.");
					homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
					currentUser = "DIS";
					refresh();
					break;
				}

				Logger("STEP 2: Navigate to received documents object.");
				homeportalPage.closeTabs();
				documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0),
						DocumentPage.class);
				documentsPage.navigateToAllReceivedDocListView();
				Thread.sleep(6000);

				Logger("STEP 3: Open any existing document.");
				documentsPage.searchDocument("Automation");
				Thread.sleep(6000);
				docMgmt.openRecentdoc();

				Logger("STEP 4: Validate the new fields in the details pg section.");
				accountObject.clickOnTab(tabsName.get(0));
				docMgmt.ReceivedDocPageFieldValidation(currentUser, receivedDocDetailsTabSections.get(0));
				docMgmt.ReceivedDocPageFieldValidation(currentUser, receivedDocDetailsTabSections.get(1));
				docMgmt.ReceivedDocPageFieldValidation(currentUser, receivedDocDetailsTabSections.get(2));
				docMgmt.ReceivedDocPageFieldValidation(currentUser, receivedDocDetailsTabSections.get(3));

				Logger("STEP 5: Navigate to Correspondence Object.");
				homeportalPage.closeTabs();
				documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(11),
						DocumentPage.class);

				Logger("STEP 6: Open any existing record.");
				documentsPage.navigateToAllcorrspondnce();
				docMgmt.openRecentCorrspndceRec();

				Logger("STEP 7: Validate the below fields are added in the details section of the pg layout '1. Recipient Details','2. Vendor ID'");
				docMgmt.verifyCorrespondenceFields();

				Logger("STEP 8: Log out from application");
				documentsPage.logout();

			} catch (Exception e) {
				Logger("Test failed for user " + currentUser + " due to error: " + e.getMessage());
				documentsPage.logout();
			}
		}

		softassert.assertAll();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-2989 Validate DIS user is navigated to correct screens
	 * when Received Document is classified, split and rotated
	 * 
	 * @author Anand Pawar
	 * @throws Exception
	 * 
	 *                   ====================================================================================================================
	 */
	@Test(description = "Validate DIS user is navigated to correct screens when Received Document is classified, split and rotated", enabled = true)
	public void PE15_IC2989_Validate_DIS_user_is_navigated_to_correct_screens_when_Received_Document_is_classified_split_and_rotated()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC15";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "J33.9 - Nasal polyps, unspecified" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(0).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Nasal Polyps");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 5: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify document details and Now on ‘Classify Document’ section and fill Document Type as 'Enrollment Form' required field data, do not split the document and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:Child1 Document gets created where DIS is redirected to the Patient Search UI of child record and Owner of the child record automatically gets updated to the Parent’s Owner.");
		patientSearch.verifyPatientSearchPageTitle();
		accountObject.clickOnTab(tabsName.get(0));
		documentsPage.verifyChild1Record();
		documentsPage.clickParentReceivedDocument();
		accountObject.clickOnTab(tabsName.get(1));
		documentsPage.navigateToReceivedDocumentsTable();
		documentsPage.verifyOwnerName();
		documentsPage.clickChildDoc();

		patientSearch.enterCareProgram(careProgramProduct.get(0));
		patientSearch.verifyAndClickBackToClassify();

		Logger("STEP 8:Navigate to ‘My Received Documents’ list View  → Open the Parent Document form using 'Open Document’ link");
		accountObject.navigateToReceivedDocument();
		documentsPage.navigateToMyReceivedDocListView();
		refresh();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 9:Verify document details and Now on ‘Classify Document’ section and fill Document Type as  not 'Enrollment Form' required field data, do not split the document and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(5));
		documentsPage.submitDocument();
		

		Logger("STEP 10:Child2 Document gets created where DIS is redirected to the Patient Search UI of child record and Owner of the child record automatically gets updated to the Parent’s Owner.");
		patientSearch.verifyPatientSearchPageTitle();
		accountObject.clickOnTab(tabsName.get(0));
		documentsPage.verifyChild1Record();
		documentsPage.clickParentReceivedDocument();
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		documentsPage.navigateToReceivedDocumentsTable();
		documentsPage.verifyOwnerName();
		documentsPage.clickChild2Doc();
		
		patientSearch.enterCareProgram(careProgramProduct.get(0));
		patientSearch.verifyAndClickBackToClassify();

		Logger("STEP 11:Navigate to ‘My Received Documents’ list View  → Open the Parent Document form using 'Open Document’ link");
		accountObject.navigateToReceivedDocument();
		documentsPage.navigateToMyReceivedDocListView();
		refresh();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 12:Verify document details and Now on ‘Classify Document’ section and fill Document Type as 'Enrollment Form' required field data, do not split the document and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.splitDoc();
		documentsPage.submitDocument();

		Logger("STEP 13:Child3 Document gets created where DIS is redirected to the Patient Search UI of child record and Owner of the child record automatically gets updated to the Parent’s Owner.");
		patientSearch.verifyPatientSearchPageTitle();
		accountObject.clickOnTab(tabsName.get(0));
		documentsPage.verifyChild1Record();
		documentsPage.clickParentReceivedDocument();
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		documentsPage.navigateToReceivedDocumentsTable();
		documentsPage.verifyOwnerName();
		documentsPage.clickChild3Doc();

		patientSearch.enterCareProgram(careProgramProduct.get(0));
		patientSearch.verifyAndClickBackToClassify();

		Logger("STEP 14:Navigate to ‘My Received Documents’ list View  → Open the Parent Document form using 'Open Document’ link");
		accountObject.navigateToReceivedDocument();
		documentsPage.navigateToMyReceivedDocListView();
		refresh();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 15:Verify document details and Now on ‘Classify Document’ section and fill Document Type as 'Enrollment Form' required field data,split the document and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.splitDoc();
		documentsPage.clickOnAddButton();
		documentsPage.classifyAddedDocument(documentType.get(0));
		documentsPage.splitDocumentRight();
		documentsPage.submitDocument();

		Logger("STEP 16:Verify user navigated to received documents recently viewed");
		documentsPage.verifyRecentlyViewDocumentList();

		missingInformatioPage.navigateToChildRecord();
		patientSearch.enterCareProgram(careProgramProduct.get(0));
		patientSearch.verifyAndClickBackToClassify();

		Logger("STEP 17:Navigate to ‘My Received Documents’ list View  → Open the Parent Document form using 'Open Document’ link");
		accountObject.navigateToReceivedDocument();
		documentsPage.navigateToMyReceivedDocListView();
		refresh();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 18:Verify document details and Now on ‘Classify Document’ section and fill Document Type as 'Enrollment Form' required field data,split the document and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.splitDoc();
		documentsPage.submitDocument();

		Logger("STEP 19:Child6 Document gets created where DIS is redirected to the Patient Search UI of child record and Owner of the child record automatically gets updated to the Parent’s Owner.");
		patientSearch.verifyPatientSearchPageTitle();
		accountObject.clickOnTab(tabsName.get(0));
		documentsPage.verifyChild1Record();
		documentsPage.clickParentReceivedDocument();
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		documentsPage.navigateToReceivedDocumentsTable();
		documentsPage.verifyOwnerName();
		documentsPage.clickChild6Doc();

		patientSearch.enterCareProgram(careProgramProduct.get(0));
		patientSearch.verifyAndClickBackToClassify();

		Logger("STEP 20:Navigate to ‘My Received Documents’ list View  → Open the Parent Document form using 'Open Document’ link");
		accountObject.navigateToReceivedDocument();
		documentsPage.navigateToMyReceivedDocListView();
		refresh();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 21:Verify document details and Now on ‘Classify Document’ section and fill Document Type as 'Enrollment Form' required field data,split the document and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.splitDoc();
		documentsPage.clickOnAddButton();
		documentsPage.classifyAddedDocument(documentType.get(0));
		documentsPage.splitDocumentRight();
		documentsPage.submitDocument();

		Logger("STEP 22:Verify user navigated to received documents recently viewed");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 23:Navigate to child record");
		missingInformatioPage.navigateToChildRecord();
		patientSearch.enterCareProgram(careProgramProduct.get(0));
		patientSearch.verifyAndClickBackToClassify();

		Logger("STEP 24:Navigate to ‘My Received Documents’ list View  → Open the Parent Document form using 'Open Document’ link");
		accountObject.navigateToReceivedDocument();
		documentsPage.navigateToMyReceivedDocListView();
		refresh();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 25:Verify document details and Now on ‘Classify Document’ section and fill Document Type as 'Enrollment Form' required field data,split the document and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 26:Child2 Document gets created where DIS is redirected to the Patient Search UI of child record and Owner of the child record automatically gets updated to the Parent’s Owner.");
		patientSearch.verifyPatientSearchPageTitle();
		accountObject.clickOnTab(tabsName.get(0));
		documentsPage.verifyChild1Record();
		documentsPage.clickParentReceivedDocument();
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		documentsPage.navigateToReceivedDocumentsTable();
		documentsPage.verifyOwnerName();
		careProgram.clickOnViewAll("Received Documents");
		documentsPage.clickChild9Doc();

		Logger("STEP 27: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 28: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 29:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 30:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 31:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 32:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 33:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 34:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 37: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7315 To validate Validation Message for the "Prescription
	 * Signed" Field
	 * 
	 * @author Anand Pawar
	 * @throws Exception
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT - TC01:To validate Validation Message for the \"Prescription Signed\" Field", enabled = true)
	public void PE16_IC7315_To_validate_Validation_Message_for_the_Prescription_Signed_Field() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC16";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String removeColumnName[] = { "Prescriber Name" };

		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnName);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-Requisite 2: User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Information Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		// Prescriber Info
		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details ,keep prescriber first and last name as Blank");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		// prescriptioninformation.clearPrescriberName();
		insuranceinfo.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 14:Validate error message");
		prescriptioninformation.validateErrorMsg();

		Logger("STEP 15: Log out");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-6433 Validating the new EF process for COPD Indication
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT - TC02:Validating the new EF process for COPD Indication", enabled = true)
	public void PE17_IC6433_Validating_the_new_EF_process_for_COPD_Indication() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC17";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Prescriber Name", "Specialty", "Prescriber NPI", "Prescriber Zip",
				"Site/facility name", "Office Fax", "Office Phone", "Tax ID", "Diagnosis Code", "DUPIXENT MyWay",
				"Preferred Specialty Pharmacy" };
		String columnValue[] = { "Automation HCP", "Neurologist", "4105589820", "10038", "Automation HCO",
				"(987) 678-9098", "(982) 789-9378", "989098789", "J42 - Unspecified chronic bronchitis", "TRUE",
				"FALSE" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(5).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("COPD");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 5: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(5),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.searchAndSelectHCP(ExcelTestData.get(prescriberName));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.searchAndSelectHCO(ExcelTestData.get(sitefacilityname));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.enterEosCountAndPatientDepenedent(eosCount.get(2), patientDepedent.get(0));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0),ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 17: Go to related tab and validate all the records has been created and is linked to the patient record");
		// Contact Contact Relationships
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToCCR();
		 accountObject.validateCCR(ExcelTestData.get(collaboratingMDName),
		 ExcelTestData.get(prescriberName),
		 ExcelTestData.get(legalRepresentativeName),
		 ExcelTestData.get(legalrelationship));
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// Member Plans
		accountObject.clickOnMemberPlan();
		accountObject.validateMemberPlans(ExcelTestData.get(rxPayerName), ExcelTestData.get(medicalPayerName));
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// Medication Requests
		accountObject.navigateMedicationRequests();
		accountObject.validateMedicationRequests(ExcelTestData.get(prescription5BDose),
				ExcelTestData.get(prescription5ADose), ExcelTestData.get(prescriberName));
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// Health Conditions
		accountObject.navigateHealthConditions();
		accountObject.validateHealthConditions(ExcelTestData.get(diagnosisCode));
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
		String ID=assessmentTasksPage.navigateAndGetID();


		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();

		Logger("STEP 20: Navigate to MI-Tab and change status of MI cases to collected");
		navigateToUrl(cpeURL);
		Thread.sleep(2000);
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 21: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 22: Navigate to the Care program Enrollee Record and validate USer is able to perform BV and other patient journey steps");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		String accountName = ExcelTestData.get(patientName);

		Logger("STEP 22: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 23: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 24: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		// BV Initialization code starts here
		Logger("STEP 25: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("STEP 26: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 27: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 30: Click on PA/Appeal work order ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 31: Open \"Follow up on Results\" task and enter mandatory details and outcome as approved and click on save ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(1), PAOutcomeReason.get(0));
		String effectiveDate = Utility_Function.getNthDayFromToday(10);
		String expirationDate = Utility_Function.getNthDayFromToday(15);
		paAppealsPage.enterMandatoryPAApprovedDetails(effectiveDate, paDosage.get(0), expirationDate);
		careProgram.clickOnSave();

		Logger("STEP 32: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 33: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(cpeURL);
		Thread.sleep(4000);

		Logger("STEP 32: open HCP follow up task ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));

		Logger("STEP 33: Mark status as completed and enter mandatory details click on save");
		paAppealsPage.selectDropdownValue("Status", paStatus.get(1));
		paAppealsPage.enterHCPFollowUpDetailsIntent(hcpContact.get(1), attempts.get(0),
				ExcelTestData.get(officeContactName), intentOfSubmission.get(1));
		careProgram.clickOnSave();

		Logger("STEP 34: Follow up on result task and change status to completed ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));
		paAppealsPage.changeStatusToCompleted(StatusCheck.get(1));
		careProgram.clickOnSave();

		Logger("STEP 35: Navigate to PA summary task \"Communicate Results & Send SOB\" enter hcp contact details and save");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(1));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName), attempts.get(0), intentOfSubmission.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// Quick Start initialization

		Logger("STEP 36: Navigate to Quick Start and verify flow has initiated");
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();

		Logger("STEP 37: Click on start new service and select service as IAP and select reason");
		iapPage.clickOnStartNewService();
		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.selectReason();

		Logger("STEP 38: Click on save and refresh the page");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 39: Navigate to IAP and verify flow has initiated");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();

		// COPAY initialization
		Logger("STEP 40 : Copay Record initialization");
		copayFlow.checkCopayIntiation();

		// PAP Initialization
		Logger("STEP 41 :PAP work order initialization.");
		iapPage.clickOnStartNewService();
		papPage.selectService();
		missingInformatioPage.clickNextButton();
		papPage.selectReason("PAP Appeal");

		Logger("STEP 42 : Click on save and refresh the page");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 43 : Navigate to PAP and verify flow has initiated");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		// Triage Initialization
		Logger("STEP 44 : Navigate to Traige and verify flow has initiated");
		triagePage.checkTraigeIntiation();
		triagePage.checkTriageTaskInitiation();

		Logger("STEP 45 : If patient does not have EOS field filled, and the info was missing. User can manually create a case from the New button on MI tab");
		String missingCase = "DMW COPD : Eosinophil Count";
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.clickNewButton();
		missingInformatioPage.selectCareProgramMI(missingCase);
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.verifyCaseIsCreated(missingCase);

		Logger("STEP 46: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7163 Data Intake Specialist receives a document for a
	 * patient that is associated to a Care Program Enrollee record that is Active
	 * and OnHold field = TRUE for one of the Dupixent indications.
	 * 
	 * @author Sonica P
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "ICare-937- SAT-TC03: Data Intake Specialist receives a document for a patient that is associated to a Care Program Enrollee record that is Active and OnHold field = TRUE  for one of the Dupixent indications.", enabled = true)
	public void PE18_IC7163_Data_Intake_Specialist_receives_a_document_for_a_patient_that_is_associated_to_CPE_Record()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC7";
		excelDataUpdate.selectExcelSheet(functionality);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		accountObject.searchRecord("Automation");
//		accountObject.searchAndOpenRecord();
		accountObject.searchCPERecordAndOpen();

		Logger("STEP 3: Open any record and update the status as Active and OnHold field = TRUE");
//		careProgram.updateStatus(cpeStatus.get(0));
//		missingInformatioPage.clickOnSaveButton();
//		Thread.sleep(3000);
		careProgram.updateOnHoldField();

		Logger("STEP 4: On the Navigation Menu, select \"Received Documents\"");
		// Get care program product
		//String cpProduct = careProgram.getCareProgramProduct() + " - Dupixent";

		docMgmt.navigateToAccount();
		String accountDetails[] = accountObject.getCPEDetails();

		// Patient name
		String[] existingPname = updatepdf.splitFullName(accountDetails[0]);
		String patientFName = existingPname[0] + " " + existingPname[1];
		String patientLName = existingPname[2];

		// Patient DOB
		String dob = Utility_Function.changeFormatDateMMddYYYY(accountDetails[1]);

		// Patient email
		String email = accountDetails[2];

		// patient phone
		String patientPhone = Utility_Function.formatNumber(accountDetails[3]);

		// Patient Zip Code
		String zipCode = accountDetails[4];

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("STEP 5: Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 6: Navigate to the Recently view ");
		documentsPage.verifyRecentlyViewDocumentList();

//			Logger("STEP 2.2:Navigate to Received Document Worklist and Check the checkbox on the record and click on 'Assign to me' button.");
//			documentsPage.navigateToReceiveddocument();
//			documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 7:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//			Logger("STEP 2.4:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//			documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9: After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 10: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientLastName = name[2];

		patientSearch.verifyPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));

		Logger("Step 11: Click on 'search Patient' button and Select an existing patient from the search table and click on next button");
		patientSearch.searchExistingPatient2(patientFName, patientLName, dob, patientPhone, email, zipCode);

		Logger("Step 12: Validate if you can only see this message :Patient [Patient Name] is already enrolled in DMW.Document has been linked to patient:[Patient Name]");
		patientSearch.verifyDocLinkedText(accountDetails[0]);
		patientSearch.verifyDMWEnrollmentText(accountDetails[0]);
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-10610 Regression-PatientEnroll: Automate Future Date
	 * Restrictions on Enrollment
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT :TC01: To validate Future Date Restrictions on Enrollment", enabled = true)
	public void PE19_IC7234_To_validate_Future_Date_Restrictions_on_Enrollment() throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC7";

		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };

		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-Requisite 2: User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2: Navigate to the Received document object and upload the enrollment form");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("Pre-Requisite STEP 2.1: Navigate to the Recently view list ");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3: Select the uploaded document and click on assign to me --> Open the document using the open document link --> Classify the document as enrollment form and Click on submit button");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));


		Logger("Pre-Requisite STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 3.2:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-Requisite STEP 3.3: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 3.4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));

		Logger("STEP 4: Fill the CPP field and Click on Next → In the Patient Information & Authorizations section go to the below mentioned fields and validate that the user is not able to enter and/or select any date in the future.");
		patientSearch.clickOnNextButton();

		Logger("STEP 4.1: Verify User is not able to Select any Future date in the 'DOB' field");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterfutureDate("DOB");
		patientInfo.validateFutureDateDisabled();

		Logger("STEP 4.2: Verify User is not able to Select any Future date in the 'Authorization to Use and Disclose Health Information - Signature date' field");
		patientInfo.enterfutureDate("Authroziation Signature Date");
		patientInfo.validateFutureDateDisabled();

		Logger("STEP 4.3: Verify User is not able to Select any Future date in the 'Patient Certifications - Signature Date' field");
		patientInfo.enterfutureDate("Patient Certification Date");
		patientInfo.validateFutureDateDisabled();

		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.clickOnNextButton();

		Logger("STEP 5: Now click on next and navigate to the Diagnosis Information section");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		Logger("STEP 5.1: Click on next button and navigate to the Diagnosis Information section →In the \"Diagnosis Date\" field .Validate if the user is not able to enter and/or select any date in the future.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		patientInfo.enterfutureDate("Diagnosis Date");
		patientInfo.validateFutureDateDisabled();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));

		Logger("STEP 6: Click on next button and navigate to the Prescription Information section →In the \"Prescribed Date\" field .Validate if the user is not able to enter and/or select any date in the future.");
		diagnosisinformation.clickOnNextButton();
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		patientInfo.enterfutureDate("Prescriber Date");
		patientInfo.validateFutureDateDisabled();

		Logger("STEP 7: Log out");
		documentsPage.logout();

	}
	
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-10607 Regression-PatientEnroll: Automate Case Manager
	 * receives the Welcome Correpondence Case if the “Preferred Specialty Pharmacy”
	 * box is checked on the enrollment form
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT-TC01: The Case Manager receives the Welcome Correpondence Case if the “Preferred Specialty Pharmacy” box is checked on the enrollment form ", enabled = true)
	public void PE20_IC7086_Verify_The_Case_Manager_receives_the_Welcome_Correpondence_Case_if_the_PreferredSpecialtyPharmacy_box_is_checked_on_the_enrollment_form()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC20";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "Voicemail", "Text", "Patient Email", "Patient Primary phone",
				"Preferred Specialty Pharmacy", "Text Messaging Consent", "DUPIXENT MyWay" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "TRUE", "phtest01@gmail.com",
				"7898786400", "TRUE", "TRUE", "TRUE" };

		excelDataUpdate.selectExcelSheet(functionality);
		// excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_Consent);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("Pre-requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-requisite STEP 2: Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("Pre-requisite STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkboxon
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("Pre-requisite STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 5: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Pre-requisite STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-requisite STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-requisite STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-requisite STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 14:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 15:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 16:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-requisite STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-requisite STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-requisite STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		
		Logger("STEP 6: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID=assessmentTasksPage.navigateAndGetID();
		String cpeUrl = getCurrentPageURL();
		cpeUrl = Utility_Function.removeQueryString(cpeUrl);

		Logger("Pre-requisite STEP 16: Logout as a DIS User.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 3:  Verify recently view list is displayed and search the CPE Record.");
		//assessmentTasksPage.verifyRecentlyViewList();
		//careProgram.navigateToAllCPE();
		//careProgram.checkColumnSorting();
		//careProgram.clickOnCPERecord(cpeName);
		navigateToUrl(cpeUrl);	
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 4: Navigate to the \"Cases\" and verify if you are able to see the newly created Welcome Correspondence case (Subject would be empty on the list view page)");
		docMgmt.navigateToCasesTable();
		docMgmt.verifyandOpenCase();

		Logger("STEP 5: Open and validate the Welcome Correspondence Case layout");
		docMgmt.verifyCaseFileds();

		Logger("STEP 6: On the right side of the case layout, validate if you are able to select \"Welcome SMS\" on the select items to send and  send Welcome Correspondence form the embedded correspondence screen");
		docMgmt.selectItemsToSend(itemsToSend.get(4));
		missingInformatioPage.clickNextButton();
		docMgmt.waitForFinishButton();
		String successMessage = docMgmt.validateSuccessMessage();

		if (successMessage.contains(welcomeSMSsuccessMSG)) {
			Logger("Welcome SMS Success message verified.");
		} else {
			Logger("Success message not found.");
			throw new Exception("Welcome SMS Success message not found.");
		}
		docMgmt.clickonFinishButton();
		refresh();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		Logger("STEP 7: Validate if the correspondence record is created on the Correspondences section (left side of the Correspondence Case Layout)");
		docMgmt.navigateToCorrespondenceTable();
		docMgmt.verifyCorrespondenceRecord(processName.get(0));

		Logger("STEP 8: Logout as a case manager.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7218 Validate that Created Date field is added in to the
	 * coverage benefits section under the related of Member Plan object.
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "TC02: Validate that Created Date field is added in to the coverage benefits section under the related of Member Plan object.", enabled = true)
	public void PE21_IC7218_Validate_that_Created_Date_field_is_added_in_to_the_coverage_benefits_section_under_the_related_of_Member_Plan_object()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC12";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 5: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0),ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 17: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		
		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);
		
		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();;
        
		navigateToUrl(CPEURL);
				
		Logger("STEP 22: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 23: User Logout the Application.");
		documentsPage.logout();


		Logger("STEP 24: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		homeportalPage.closeTabs();
		
		navigateToUrl(CPEURL);


		// Benefits Verification
		Logger("STEP 28: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 29: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 30: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(1));
		//bvPage.checkAttemptOutreachforconsents();
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 33: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 34: Login to the QA_SIT Org as 'Case manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(CPEURL);

		Thread.sleep(5000);

		Logger("STEP 35: Navigate to Member plans object.");
		accountObject.navigateToMemberPlan();

		Logger("STEP 36: Open a recently created record which has Coverage benefit record linked to it.");
		accountObject.clickOnmemberPlan(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 37: Navigate to related section");
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 38: Click on view all on the Coverage benefit section and validate the fields are present");
		accountObject.navigateToCoverageBenefit();
		accountObject.verifyCBFields();

		Logger("STEP 39: Logout as a case manager.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5350 Revise Payer Account Search: Create New Record
	 * 
	 * @author Trupti Zure//need to cancel
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT - TC03:Revise Payer Account Search: Create New Record", enabled = true)
	public void PE22_IC5350_Revise_Payer_Account_Search_Create_New_Record() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC22";

		// Testdata - member plans
		String rxMemberplan = insuranceinfo.returnRandomString() + "RxMemberPlan";
		String medicalMemberplan = insuranceinfo.returnRandomString() + "MedMemberPlan";
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Rx Payer Name", "Medical Payer Name", "Diagnosis Code" };
		String columnValue[] = { rxMemberplan, medicalMemberplan, "L20.9 - Atopic dermatitis, unspecified" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 5: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterPayerPharmacy(ExcelTestData.get(rxPayerName));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterPayerMedical(ExcelTestData.get(medicalPayerName));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 15:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0),ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 16: Navigate to Member Plan Object → Validate Primary Medical Insurance record and Primary Rx Insurance record created in previous step (6,7) ");
		accountObject.clickOnMemberPlan();
		accountObject.validateMemberPlans(ExcelTestData.get(rxPayerName), ExcelTestData.get(medicalPayerName));
		accountObject.clickOnMemberPlan(ExcelTestData.get(rxPayerName));

		Logger("STEP 17: Navigate to Primary Medical Insurance Record Related List → Validate no DCR record is created");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyNODSRisCreated();

		Logger("STEP 18: Navigate to Primary Rx Insurance Record Related List → Validate no DCR record is created.");
		missingInformatioPage.navigateToCPERecord("Member Plans");
		accountObject.clickOnMemberPlan(ExcelTestData.get(medicalPayerName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyNODSRisCreated();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-4501 Automate Program Coordinator: Perform PSQA Review
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT: TC01: Program Coordinator: Perform PSQA Review", enabled = true)
	public void PE23_IC4501_Validate_Program_Coordinator_Perform_PSQA_Review() throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC23";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		// Logger("Pre-Requisite STEP 3: Navigate To Recently View Document list");
		// documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("Pre-Requisite STEP 2: Navigate to the Recently view list ");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("Pre-Requisite STEP 3:Once the PDF Enrollment Form is uploaded, navigate to the 'Received Document Worklist' list view of the Received Document.");

		fileName = documentsPage.getFileName(filePath.get());
		System.out.println(fileName);

		Logger("Pre-Requisite STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 5: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Pre-Requisite STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-Requisite STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		Logger("Pre-Requisite STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-Requisite STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		 insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		// insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Pre-Requisite STEP 11:Verify the Confirmation Message and Click on 'Submit' Button");
		documentsPage.logout();

		// PC code
		homeportalPage = loginPage.userLogin(PCUserName, UserPassword);

		Logger("STEP 2: Navigate to Received Document object → Validate that the Program Coordinator can assign themselves a Received Document record from the PSQA Review Queue List View by clicking an \"Assign to me\" button.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		documentsPage.verifyRecentlyViewDocumentList();
		documentsPage.navigatetoPSQAReviewWorklistView();
		String docName = fileName + " (1)";
		documentsPage.searchDocument(docName);
		documentsPage.assigntoMe(docName);

		Logger("STEP 3: Open the document from In Review List View");
		documentsPage.verifyRecordAndClick(docName);

		Logger("STEP 4: On the record validate that PC user is able to Review and update a received document record’s classification.");
		patientSearch.fieldEditButton();
		patientSearch.updateSourceChannelField("Web");
		patientSearch.selectReviewOutcome();
		utilityPage.clickOnButton("Save");

		Logger("STEP 5: On the record validate that PC user is able to Re-link the received document to an existing Patient.");
		patientSearch.fieldEditButton();
		String paName = patientSearch.updatePatientRecDoc(patientFirstName);
		missingInformatioPage.clickOnSaveButton();
		patientSearch.validateFieldsUpdated("Parent Received Document", paName);

		Logger("STEP 6: On the record validate that PC user is able to update the CPE association of a received document record.");
		patientSearch.fieldEditButton();
		String pName = patientSearch.updateCPE();
		missingInformatioPage.clickOnSaveButton();
		patientSearch.validateFieldsUpdated("Care Program Enrollee", pName);

		Logger("STEP 7: Validate PSQA Review Outcome picklist field on the Received Document detail page layout → Validate the picklist values of PSQA Review Outcome field → validate only PC User is able to Edit the field.");
		patientSearch.fieldEditButton();
		patientSearch.validatePSQAReviewOutcomeListValues();
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 8: Validate that the Program Coordinator can change the Received Document record status to \"Complete\" only after populating the PSQA Review Outcome field or it will throw an error.");
		patientSearch.fieldEditButton();
		patientSearch.errorValidation();
		patientSearch.selectReviewOutcome();
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 9: Log out");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5218 Create New HCO Record from ICARE with DCR request
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "TC02: Create New HCO Record from ICARE with DCR request", enabled = true)
	public void PE24_IC5218_Create_New_HCO_Record_from_ICARE_with_DCR_request() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC24";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_Consent);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 5: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.searchRecord();
		prescriberInformationPage.verifyNoRecordsDisplayMessage();
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Navigate to Account object");
		accountObject.globalSearch(searchFilter.get(1),ExcelTestData.get(patientName));

		Logger("STEP 17:Open recently created HCO record → Navigate to Related List of HCO record → Validate DCR record is created.");
		docMgmt.clickOnSiteRecord();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToDSR();
		accountObject.clickOnDSRRecord();
		careProgram.verifyDSRRecordIsCreated(ExcelTestData.get(sitefacilityname));

		Logger("STEP 18: Logout as a case manager.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5303 To validate the Search button functionality on
	 * Collaborating MD
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT - TC01: To validate the Search button functionality on Collaborating MD", enabled = true)
	public void PE25_IC5303_To_Validate_The_Search_Button_Functionality_On_Collaborating_MD() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC2";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite 2: User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 5: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Information Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		// Prescriber Info - Page
		Logger("STEP 12:Verify Prescriber Information Page and click on Next Button");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		insuranceinfo.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		// Prescription Info - Page
		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.verifySearchButton();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 14:Populate the \"First Name\", \"Last Name\" fields and click on Search");
		prescriptioninformation.enterCollaboratingMDNameInfo(mdFirstName, mdLastName);
		prescriptioninformation.clickSearchButton();

		Logger("STEP 15:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		documentsPage.verifyPDFVersionOfEFVisible(tabsName.get(3));

		Logger("STEP 16:Validate that incase of multiple matches are found for collaborating MD, all matched records are visible in the search table and user is able to select the matched record");
		prescriptioninformation.verifyMultipleMatchedMD(ExcelTestData.get(collaboratingMDName));

		Logger("STEP 17:Validate that the search table have a \"Source\" column which have the values as :'RCM'and 'ICARE+'");
		prescriptioninformation.verifySourceColumn();

		Logger("STEP 18:Remove the values from first name and last name and populate only the NPI#, field and click on Search again and validate that the search is getting initiated and search results are visible");
		prescriptioninformation.clearCollaboratingMDNameInfo(ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickSearchButton();

		Logger("STEP 19:Select the matched record and Click on Submit button and submit the enrollment for");
		prescriptioninformation.selectFirstMatchedRecord(ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 20:User Click on Submit and Enrollment Form should be submitted");
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 21:Validate that the selected collaborating MD record is created");
		accountObject.navigateToAccount();
		accountObject.searchAccAndClick(ExcelTestData.get(collaboratingMDName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 22: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-2190 Patient Search: Show Received Document Layout by
	 * Linked Patient
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT - TC01: Patient Search: Show Received Document Layout by Linked Patient", enabled = true)
	public void PE26_IC2190_Patient_Search_Show_Received_Document_Layout_by_Linked_Patient() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC26";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		synchronized (excelDataUpdate) {
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-Requisite 2: User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Navigate to details Tab and validate that the Parent Received Document field and Document Type are NULL");
		accountObject.clickOnTab(tabsName.get(0));
		documentsPage.verifyParentDocumentType();

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document,verify OCR status as 'Success'");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8:Validate User can search for Existing patient >> Select patient from search list >> Click on Next, Refresh and validate document Link message");
		patientSearch.selectExistingPatient2(careProgramProduct.get(2));

		Logger("STEP 9:Validate that the Patient Name is a lookup field as read-only so that the User can click on the Patient.");
		accountObject.clickOnTab(tabsName.get(0));
		documentsPage.clickParentReceivedDocument();
		accountObject.clickOnTab(tabsName.get(0));
		documentsPage.verifyPatientNameField();

		Logger("STEP 10:Validate Enrollment Form Launched and Patient Search Tab is not visible.");
		documentsPage.verifyPatietnSearchTabNotVisible();

		Logger("STEP 11: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-15214 TC07-Verify Patient Search Functionality(using
	 * FN+LN+Zip+Phone) with Fuzzy Logic in Enrollment Omniscript
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "To validate List Views are updated on Received Document", enabled = true)
	public void PE30_IC15214_Verify_Patient_Search_Functionality_with_Fuzzy_Logic_in_Enrollment_Omniscript()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC30";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		excelDataUpdate.selectExcelSheet(functionality);

		String columnName[] = { "Patient Name", "Zip", "Patient Primary phone" };
		String columnValue[] = { fuzzyPatientData1.get(0), fuzzyPatientData1.get(2), fuzzyPatientData1.get(6) };

		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_fuzzySearch);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Nasal Polyps");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
		Logger("STEP 10: Enter First Name, Last Name, Zip Code and Phone → Search Patient");
		patientSearch.verifyPatientSearchPageTitle();
		patientSearch.clearExistingFields();
		patientSearch.enterCareProgram(careProgramProduct.get(2));
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData1.get(0), fuzzyPatientData1.get(1), null,
				fuzzyPatientData1.get(6), fuzzyPatientData1.get(2), fuzzyPatientData1.get(4));

		Logger("STEP 11: Verify that the search functionality works with Fuzzy Logic at High Precision (matches nicknames, punctuation, international characters, and cultural spellings).");
		patientSearch.validateSearchResult(existingPatientData.get(0));

		Logger("STEP 12: Enter First Name, Last Name, Zip Code and Phone Number → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData2.get(5), fuzzyPatientData2.get(1), null,
				fuzzyPatientData2.get(6), fuzzyPatientData2.get(2), fuzzyPatientData2.get(4));

		Logger("STEP 13: Verify that the search functionality works with Fuzzy Logic at Medium Precision (matches initials, gender variants, shuffled names, and common nicknames)");
		patientSearch.validateSearchResult(existingPatientData.get(3));

		Logger("STEP 14:Enter First Name, Last Name, Zip Code and Phone Number → Search Patient");
		patientSearch.clearExistingFields();
		patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData3.get(0), fuzzyPatientData3.get(1), null,
				fuzzyPatientData3.get(6), fuzzyPatientData3.get(2), fuzzyPatientData3.get(4));

		Logger("STEP 15: Verify that the search functionality works with Fuzzy Logic at Low Precision (matches initials, gender variants, shuffled names, and common nicknames)");
		patientSearch.validateSearchResult(existingPatientData.get(1));

		Logger("STEP 16: Click on next button");
		patientSearch.clickOnNextButton();

		Logger("STEP 17:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(fuzzyPatientData1.get(0), fuzzyPatientData1.get(1), fuzzyPatientData1.get(1),
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 18:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 19:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 20:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 21:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 22: Verify that the search functionality works with Confirm page");
		//formConfirmation.searchPatientConfirmPage();
		patientSearch.validateSearchResult(existingPatientData.get(1));

		Logger("STEP 23: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5217 Create New HCP Record from ICARE with DCR request
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT - TC02:Create New HCP Record from ICARE with DCR request", enabled = true)
	public void PE31_IC5217_Create_New_HCP_Record_from_ICARE_with_DCR_request() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC1";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_Consent);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 5: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.searchRecord();
		prescriberInformationPage.verifyNoRecordsDisplayMessage();
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 15:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 16:Open recently created HCP record → Navigate to Related List of HCP record → Validate DCR record is created.");
		accountObject.navigateToCCR();
		accountObject.clickOnHCPRecord(ExcelTestData.get(prescriberName));
		accountObject.validateDSR();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToDSR();
		accountObject.clickOnDSRRecord();
		accountObject.validateDSRRecordIsCreated(ExcelTestData.get(prescriberName));

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:RGN-Phone: Automate ICARE-9368: SIT: Validate Upload Document
	 * for portal is correctly set up for enrollment forms
	 * 
	 * @author Sonica P
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE-9368: SIT: Validate Upload Document for portal is correctly set up for enrollment forms", enabled = true)
	public void PE32_IC13889_IC9368_SIT_Validate_Upload_Document_for_portal_is_correctly_setup_for_enrollment()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC2";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-Requisite 2: User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 11: Log out");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-3915 Document Management - Health Condition Linked with
	 * Medication Request
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Document Management - Health Condition Linked with Medication Request", enabled = true)
	public void PE35_IC3915_Document_Management_Health_Condition_Linked_with_Medication_Request() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC4";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Prescriber Name", "Specialty", "Prescriber NPI", "Prescriber Zip",
				"Site/facility name", "Office Fax", "Office Phone", "Tax ID", "Diagnosis Code", "DUPIXENT MyWay",
				"Preferred Specialty Pharmacy" };
		String columnValue[] = { "Automation HCP", "Neurologist", "4105589820", "10038", "Automation HCO",
				"(987) 678-9098", "(982) 789-9378", "989098789", "J42 - Unspecified chronic bronchitis", "TRUE",
				"FALSE" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(5).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("COPD");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 5: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(5),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.searchAndSelectHCP(ExcelTestData.get(prescriberName));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
	//	prescriberInformationPage.searchAndSelectHCO(ExcelTestData.get(sitefacilityname));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
	//	diagnosisinformation.enterEosCountAndPatientDepenedent(eosCount.get(2), patientDepedent.get(0));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0),cpeName);
	

		Logger("STEP 17:Navigate to related tab of record ");
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 18: Validate that 2 Medical request is Created and 1 Health Condition is created.");

		// Medication Requests
		accountObject.navigateMedicationRequests();
		accountObject.validateTwoMedicationRequests(ExcelTestData.get(prescription5ADose),
				ExcelTestData.get(prescription5BDose), ExcelTestData.get(prescriberName));

		// Health Conditions
		accountObject.navigateHealthConditions();
		accountObject.validateHealthConditionsFromCPE(ExcelTestData.get(diagnosisCode));

		Logger("STEP 19: Now open any one Medication request and validate that ‘Reason Reference’  available in the page.");
		accountObject.navigateMedicationRequests();
		accountObject.clickonFirstMedicationRequest();

		Logger("STEP 20: Validate that the ‘Reason Reference’ Field is filled with the ‘Health Condition’ Hyperlink.");
		accountObject.validateFirstReasonReferenceField();
		accountObject.navigateToAccountAutomation();


		Logger("STEP 21: Now open second Medication request and validate that ‘Reason Reference’  available in the page.");
		accountObject.navigateMedicationRequests();
		accountObject.clickonSecondMedicationRequest();

		Logger("STEP 22: Validate that the ‘Reason Reference’ Field is filled with the ‘Health Condition’ Hyperlink.");
		accountObject.validateSecondReasonReferenceField();

		Logger("STEP 23: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-2189 To validate OCR mapping refinements for Patient Name
	 * and Prescriber Name from PDF to Enrollment Form
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT - TC01: To validate OCR mapping refinements for Patient Name and Prescriber Name from PDF to Enrollment Form", enabled = true)
	public void PE36_IC2189_To_validate_OCR_mapping_for_PatientName_and_PrescriberName_from_PDF_to_Enrollment_Form()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC6";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Patient Name", "Prescriber Name" };
		String columnValue[] = { "Automationtest Sanofi", "Dr.Prescriber Automation" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_Consent);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 5: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10: Patient First and Last names are populated on Enrollment Form");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.verifyPatientName(patientFirstName, patientMidName, patientLastName);
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11: On Patient Insurance Inforamtion Page click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		// Patient Prescriber Information- Page
		Logger("STEP 12: Prescriber First and Last names are populated on Enrollment Form and \"Dr/MD/DO (may be suffix or prefix with/without special characters and not case-sensitive)\" part is not mapped (In Prescriber Information section)");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.verifyPrescriberName(preFirstName, prLastName);

		Logger("STEP 11: Log out");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE20891 -R4-PE: Automate ICARE-17296--
	 * SIT-TC01-Manually reactivate the CPE when “Inactivation reason=Consent
	 * Expired”
	 * 
	 * @author Shanavaz Nishani
	 *         ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "SIT-TC01-Manually reactivate the CPE when “Inactivation reason=Consent Expired” ", enabled = true)
	public void PE37_IC17296_Manually_reactivate_the_CPE_when_Inactivation_reason_Consent_Expired()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC7";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "J33.0 - Polyp of nasal cavity" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(0).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Nasal Polyps");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("Pre-Requisite STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("Pre-Requisite STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("Pre-Requisite STEP 5:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Pre-Requisite STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-Requisite STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("Pre-Requisite STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.clearTextFromDateField();
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-Requisite STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 15: User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Pre-Requisite STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("Pre-Requisite STEP 17: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);

		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("Pre-Requisite STEP 18: Logout as DIS User");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Navigate to Care Program Enrollee Object and select the CPE record as Mentioned in the Pre Requisites");
		homeportalPage.closeTabs();
		navigateToUrl(cpeURL);
		accountObject.clickCPEStatusDrpdwn("CPE Status Update");
		triagePage.selectCPEStatus(statusCPEP.get(1));
		triagePage.selectInactivationReason(inactivationReason.get(2));
		missingInformatioPage.clickNextButton();
		triagePage.selectUnenrollPatBox("Yes");
		missingInformatioPage.clickNextButton();
		// Wait for the CPE record to be updated to Expired status this may take some time to reflect on Consent Records
		refresh();
		Thread.sleep(20000);
		refresh();
		Thread.sleep(20000);

		Logger("STEP 3:Verify the CPE Status=Inactive and Inactivation Reason=Consent Expired");
		careProgram.checkStatusOfCPERecord(statusCPEP.get(1));
		careProgram.checkReasonField(inactivationReason.get(2));

		Logger("STEP 4: Click on the Patient Account on the CPE and navigate to Patient Related List");
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(1));
		refresh();

		Logger("STEP 4.1: Verify the Patient Program Authorization and HIPPA Consent records are displayed in Authorization Form Consent section");
		accountObject.navigateToAuthFormConsentTable();
		accountObject.validateConsentRecords(consentNames.get(0));
		accountObject.validateConsentRecords(consentNames.get(6));

		Logger("STEP 5 and 6: Verify in Patient Program Authorization and HIPPA Consent records the  status=Rejected and Consent Expiration Date Time = Future Date.Update the Status of Patient Program Authorization and HIPPA Consent records to Signed");
		accountObject.clickOnConsentRecord(ExcelTestData.get(patientName), consentNames.get(0));
		accountObject.validateStatus(statusCPEP.get(3));
		accountObject.verifyFutureDate();
		docMgmt.clcikOnEditbtn("Status");
		patientSearch.updateStatusField(statusCPEP.get(0));
		utilityPage.clickOnButton("Save");
		accountObject.validateStatus(statusCPEP.get(0));

		accountObject.clickOnConsentAccountRecord();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.clickOnConsentRecord(ExcelTestData.get(patientName), consentNames.get(6));
		accountObject.verifyFutureDate();
		accountObject.validateStatus(statusCPEP.get(3));
		docMgmt.clcikOnEditbtn("Status");
		patientSearch.updateStatusField(statusCPEP.get(0));
		utilityPage.clickOnButton("Save");
		accountObject.validateStatus(statusCPEP.get(0));

		Logger("STEP 7: Navigate to the CPE and Click on CPE Status Update Button> Select the Status as Active");
		missingInformatioPage.navigateToCPERecord(cpeName);
		accountObject.clickCPEStatusDrpdwn("CPE Status Update");
		triagePage.selectCPEStatus(statusCPEP.get(0));
		missingInformatioPage.clickNextButton();
		refresh();
		careProgram.checkStatusOfCPERecord(statusCPEP.get(0));

		Logger("STEP 8: Logout from the application");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE20892 -R4-PE: Automate ICARE-17298-- 
	 * ICARE-9930-SIT-TC02-To Verify Error if consent record does not exist and user tries to reactivate the CPE
	 * 
	 * @author Shanavaz Nishani
	 *         ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "SIT-TC02-To Verify Error if consent record does not exist and user tries to reactivate the CPE ", enabled = true)
	public void PE38_IC17298_To_Verify_Error_if_consent_record_does_not_exist_and_user_tries_to_reactivate_the_CPE()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC8";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "J33.0 - Polyp of nasal cavity" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(0).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Nasal Polyps");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("Pre-Requisite STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("Pre-Requisite STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("Pre-Requisite STEP 5:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Pre-Requisite STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-Requisite STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("Pre-Requisite STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.clearTextFromDateField();
		patientInfo.enterAutherization(authorizationSigned.get(1), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(1), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-Requisite STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 15: User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Pre-Requisite STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("Pre-Requisite STEP 17: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);

		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("Pre-Requisite STEP 18: Logout as DIS User");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Navigate to Care Program Enrollee Object and select the CPE record as Mentioned in the Pre Requisites");
		homeportalPage.closeTabs();
		navigateToUrl(cpeURL);
		accountObject.clickCPEStatusDrpdwn("CPE Status Update");
		triagePage.selectCPEStatus(statusCPEP.get(1));
		triagePage.selectInactivationReason(inactivationReason.get(2));
		missingInformatioPage.clickNextButton();
		triagePage.selectUnenrollPatBox("Yes");
		missingInformatioPage.clickNextButton();
		refresh();
	
		Logger("STEP 3:Verify the CPE Status=Inactive and Inactivation Reason=Consent Expired");
		careProgram.checkStatusOfCPERecord(statusCPEP.get(1));
		careProgram.checkReasonField(inactivationReason.get(2));

		Logger("STEP 4: Click on the Patient Account on the CPE and navigate to Patient Related List");
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(1));
		
		Logger("STEP 4.1: Verify the Patient Program Authorization and HIPPA Consent records does not exist in Authorization Form Consent section");
		accountObject.navigateToAuthFormConsentTable();
		accountObject.validateConsentRecordIsNotPresent(consentNames.get(0));
		accountObject.validateConsentRecordIsNotPresent(consentNames.get(6));

		Logger("STEP 5: Navigate to the CPE and Click on CPE Status Update Button> Select the Status as Active");
		missingInformatioPage.navigateToCPERecord(cpeName);
		accountObject.clickCPEStatusDrpdwn("CPE Status Update");
		triagePage.selectCPEStatus(statusCPEP.get(0));
		missingInformatioPage.clickNextButton();
	
		Logger("STEP 5.1: Verify the following error message is displayed: \"Patient can be activated only if renewed consent is received from the patient\"");
		String renewdConstMsg = "Patient can be activated only if renewed consent is received from the patient.";
		docMgmt.verifyErrorMessage(renewdConstMsg);
		copayFlow.clickOnFinishButton();

		Logger("STEP 6: Select an Inactive CPE with status  Inactivation reason != \"Consent Expired\" or \"Unable to Contact\"");
		accountObject.clickCPEStatusDrpdwn("CPE Status Update");
		triagePage.selectCPEStatus(statusCPEP.get(1));
		triagePage.selectInactivationReason(inactivationReason.get(3));
		missingInformatioPage.clickNextButton();
		triagePage.selectUnenrollPatBox("Yes");
		missingInformatioPage.clickNextButton();
		refresh();
		careProgram.checkReasonField(inactivationReason.get(3));
	
		Logger("STEP 6.1: verify the following message is displayed:   \"CPE record can be reactivated only when Inactivation reason is ‘Unable to Contact’ or ‘Consent Expired’\"");
		String reactivationMsg = "CPE record can be reactivated only when Inactivation reason is ‘Unable to Contact’ or ‘Consent Expired’.";
		accountObject.clickCPEStatusDrpdwn("CPE Status Update");
		triagePage.selectCPEStatus(statusCPEP.get(0));
		missingInformatioPage.clickNextButton();
		docMgmt.verifyErrorMessage(reactivationMsg);
		copayFlow.clickOnFinishButton();
		
		Logger("STEP 8: Logout from the application");
		documentsPage.logout();


	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE20974 R4-PE Automate ICARE-16723 
	 * ICARE-13610-SIT-TC01- Verify Removal of Blank Picklist Value from Omni script Enrollment Form Consent Fields
	 * 
	 * @author Shanavaz Nishani
	 *         ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "ICARE-13610-SIT-TC01- Verify Removal of Blank Picklist Value from Omni script Enrollment Form Consent Fields", enabled = true)
	public void RGNPE03_IC16723_Verify_Removal_of_Blank_Picklist_Value_from_Omni_script_Enrollment_Form_Consent_Fields() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC3";
		
		String optionToVerify = "Blank";
		ArrayList<String> dropdownNames = new ArrayList<>(
			Arrays.asList("Patient Authorization Signed", "Patient Certifications Signed", "Text Messaging Consent"));

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent"};
		String columnValue[] = { "TRUE"};

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite 2 : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		//filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);

		Logger("STEP 1:Login to the Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Navigate to the Received document object →Select a document by checking the checkbox next to the relevant record--> Click on Assign to me button → Open the document and classify as enrollment form and Click on Submit");
		//String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);
		Logger("STEP 2.1: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 2.2:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3: In the Patient Search section , enter the Indication Code and Click on Next");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		Logger("STEP 3.1: Verify the Patient Information and Authorization Page is displayed");;
		patientInfo.verifyPatientAuthorizationPageTitle();

		Logger("STEP 4: Expand the Authorizations section> Navigate to Authorization to Use and Disclose Health Information >Click on Signed box> Verify the Blank Picklist value is removed");
		patientInfo.validatePicklistValueRemoved(optionToVerify,dropdownNames.get(0));

		Logger("STEP 5: Navigate to Patient Certifications in the Authorizations Section>Click on Signed>Verify the Blank Picklist value is removed");
		patientInfo.validatePicklistValueRemoved(optionToVerify,dropdownNames.get(1));

		Logger("STEP 6: Navigate to Text Messaging Consent Under Patient Certifications>Click on the Picklist field>Verify the Blank Picklist value is removed");
		patientInfo.validatePicklistValueRemoved(optionToVerify,dropdownNames.get(2));
		
		Logger("STEP 7: Logout from the application");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:RGN-Phone: Automate ICARE-9368: SIT: Validate Upload Document
	 * for portal is correctly set up for enrollment forms
	 * 
	 * @author Sonica P
	 * 
	 * @throws Exception ====================================================================================================================
	 * 
	 * @Test(description = "ICARE-9368: SIT: Validate Upload Document for portal is
	 *                   correctly set up for enrollment forms", enabled = true)
	 *                   public void
	 *                   PE25_IC13889_IC9368_SIT_Validate_Upload_Document_for_portal_is_correctly_setup_for_enrollment()
	 *                   throws Exception {
	 * 
	 *                   Map<String, String> ExcelTestData = new HashMap<String,
	 *                   String>(); String TestCaseNumber = "TC12";
	 * 
	 *                   Logger("Pre-Requisite 1: Update test data in excel test
	 *                   data sheet as per test case requirement"); String
	 *                   columnName[] = { "Diagnosis Code", "DUPIXENT MyWay",
	 *                   "Preferred Specialty Pharmacy" }; String columnValue[] = {
	 *                   "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE"
	 *                   }; excelDataUpdate.selectExcelSheet(functionality);
	 *                   excelDataUpdate.updateExcelData(TestCaseNumber, columnName,
	 *                   columnValue); ExcelTestData =
	 *                   excel.getExcelInputData(TestCaseNumber); String cpeName =
	 *                   ExcelTestData.get(patientName) + " - " +
	 *                   careProgramProduct.get(1).split(" -")[0];
	 * 
	 *                   Logger("Pre-Requisite 2: User updates the Patient Form");
	 *                   updatepdf.selectEnrollmentForm("Atopic Dermatitis");
	 *                   filePath.set( updatepdf.PDFCreation(TestCaseNumber,
	 *                   functionality); updatepdf.updatePDFForm(TestCaseNumber,
	 *                   functionality); System.out.println(filePath.get());
	 * 
	 *                   Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake
	 *                   Specialist'."); homeportalPage =
	 *                   loginPage.userLogin(DISUserName, UserPassword);
	 * 
	 *                   String[] cpeDetails = { ExcelTestData.get(patientName),
	 *                   ExcelTestData.get(patientDOB),
	 *                   ExcelTestData.get(patientEmail) };
	 * 
	 *                   Logger("STEP 2:Upload document to Dupixent portal"); String
	 *                   documentID = uploadDocs.uploadDoc(filePath.get(),
	 *                   cpeDetails);
	 * 
	 *                   Logger("STEP 3: Navigate To Recently View Document list");
	 *                   documentsPage.verifyRecentlyViewDocumentList();
	 * 
	 *                   Logger("STEP 4: User will be redirected to the 'My Received
	 *                   Document' list view, Open the Document.");
	 *                   documentsPage.navigateToMyReceivedDocListView();
	 *                   documentsPage.navigateToMyReceivedDocument(documentID,
	 *                   status.get(1));
	 * 
	 *                   Logger("STEP 6:Verify docuement details and Now on
	 *                   ‘Classify Document’ section and fill Document Type required
	 *                   field data and click on 'Submit' button.");
	 *                   documentsPage.classifyDocument(documentType.get(0));
	 *                   documentsPage.submitDocument();
	 * 
	 *                   Logger("STEP 11: Log out"); documentsPage.logout();
	 * 
	 *                   }
	 */

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE-16823-SIT-TC01- Verify OCR can read the fields from EF 
	 * and map to updated picklist fields in Patient Enrollment 
	 * 
	 * @author Sonica
	 *         ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "ICARE19138-16823-SIT-TC01- Verify OCR can read the fields from EF and map to updated picklist fields in Patient Enrollment ", enabled = true)
	public void PE41_IC19138_Verify_OCR_can_read_the_fields_from_EF_and_map_to_updated_picklist_fields_in_PatientEnrollment()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC1";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(0).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Nasal Polyps");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("Pre-Requisite STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("Pre-Requisite STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("Pre-Requisite STEP 5:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Pre-Requisite STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-Requisite STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("Pre-Requisite STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.clearTextFromDateField();
		patientInfo.enterAutherization(authorizationSigned.get(1), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(1), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-Requisite STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 15: User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Pre-Requisite STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		
		Logger("STEP 7: Logout from the application");
		documentsPage.logout();
		
		PatientEnrollmentWorkflowForm2_IC19138Form2();
		
	}

    @Test(description = "PatientEnrollment ICARE19138-16823-SIT-TC01- Verify OCR can read the fields from EF and map to updated picklist fields in Patient Enrollment ", enabled = true)
	public void PatientEnrollmentWorkflowForm2_IC19138Form2()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC2";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "FALSE", "FALSE", "FALSE" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(0).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("Pre-Requisite STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("Pre-Requisite STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("Pre-Requisite STEP 5:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Pre-Requisite STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-Requisite STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("Pre-Requisite STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.clearTextFromDateField();
		patientInfo.enterAutherization(authorizationSigned.get(1), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(1), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-Requisite STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();
	

		Logger("Pre-Requisite STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 15: User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Pre-Requisite STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
	}

      /**
       * ====================================================================================================================
       * Test Case Id:ICARE-18992 Creation of new 'Received Documents' record with 'DMW BP Enrollment-Form-English'.
       * 
       * @author Anand Pawar
       * 
       * @throws Exception ====================================================================================================================
       */
        @Test(description = "Creation of new 'Received Documents' record with 'DMW BP Enrollment-Form-English'", enabled = true)
        public void PE39_IC18992_Creation_of_new_Received_Documents_record_with_DMW_BP_Enrollment_Form_English() throws Exception {
           
			Map<String, String> ExcelTestData = new HashMap<String, String>();
			String TestCaseNumber = "TC6";

			Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
			String columnName[] = { "Patient DOB", "Patient Certifications Date", "Text Messaging Consent", "State",
					"Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
			String columnValue[] = { "05-06-2009", "05-16-2024", "TRUE", "Alaska", "L12.8 Other Pemphigoid", "TRUE",
					"FALSE" };

			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			ExcelTestData = excel.getExcelInputData(TestCaseNumber);

			String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(6).split(" -")[0];

			Logger("Pre-Requisite : User updates the Patient Form");
			updatepdf.selectEnrollmentForm("BP");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFFormWithoutEdit(TestCaseNumber, functionality);
			System.out.println(filePath.get());

			Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
			homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

			String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
					ExcelTestData.get(patientEmail) };
			
			Logger("STEP 2:Upload document to Dupixent portal");
		/*	String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

			Logger("STEP 3: Navigate To Recently View Document list");
			documentsPage.verifyRecentlyViewDocumentList();

			Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
			documentsPage.navigateToMyReceivedDocListView();
			documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

			Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
			documentsPage.classifyDocument(documentType.get(0));
			documentsPage.splitAndRotatDocument();
			documentsPage.submitDocument();
			
		//	documentsPage.verifyOCRStatus(documentOCRstatus.get(1));*/
			
			documentsPage.navigate("https://icarecrm--qatoler2.sandbox.lightning.force.com/lightning/r/ReceivedDocument/0ioOt000000D44DIAS/view?ws=%2Flightning%2Fr%2FReceivedDocument%2F0ioOt000000D3uXIAS%2Fview");
			Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
			patientSearch.verifyPatientSearchPageTitle();
			accountObject.clickOnTab(tabsName.get(0));
			documentsPage.verifyChild1Record();

			Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
			String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
			String patientFirstName = name[0];
			String patientMidName = name[1];
			String patientLastName = name[2];

			Logger("STEP 8: verify CPP error");
			patientSearch.verifyCareProgProductError();

			Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
			patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
					ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
					ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(6),
					ExcelTestData.get(patientDOB));
			patientSearch.clickOnNextButton();

			// patientinfoAndauthorization-Page
			Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
			String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
			String legalRepFirstName = legalRepName[0];
			String legalRepLastName = legalRepName[2];

			patientInfo.verifyPatientAuthorizationPageTitle();
			patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
					ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
					ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
					ExcelTestData.get(zip));
			patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
					patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
					ExcelTestData.get(textMessagingConsent));
			patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
					ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
					ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
					ExcelTestData.get(patientSecondaryphone));
			patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
			patientInfo.clickOnNextButton();

			// Patient Insurance - Page
			Logger("STEP 11:Verify Patient Insurance Inforamtion Page details, click on Save for later, open omnilink and click on Next Button");
			insuranceinfo.verifyInsuranceInfoPageTitle();
			insuranceinfo.clickOnSaveForLater();
			insuranceinfo.clickOnOK();
			insuranceinfo.switchToOmniLink();

			insuranceinfo.verifyInsuranceInfoPageTitle();
			insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
					ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
					ExcelTestData.get(rxPCN));

			insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
					ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
					ExcelTestData.get(insrelationshipToPatient));
			insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
			insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
					ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
			insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
			insuranceinfo.selectPayerPharmacy();
			insuranceinfo.selectMedicalPayer();
			insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
			insuranceinfo.clickOnNextButton();

			Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
			String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
			String preFirstName = preName[0];
			String prLastName = preName[2];

			String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
			String ofcFirstName = ofcName[0];
			String ofcLastName = ofcName[2];

			prescriberInformationPage.verifyPrescriberInfoPageTitle();
			prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
					ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
					ExcelTestData.get(prescriberstateLicense));
			prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
					ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
					ExcelTestData.get(prescriberZip));
			prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
					ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
					ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
			prescriberInformationPage.clickOnNextButton();

			// Diagnosis information-Page
			Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
			diagnosisinformation.verifyDiagnosisInfoPageTitle();
			diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
			Thread.sleep(2000);
			diagnosisinformation.clickOnNextButton();

			Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
			String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
			String mdFirstName = mdName[0];
			String mdLastName = mdName[2];

			prescriptioninformation.verifyPrescriptionInfoPageTitle();
			prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
					ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
					ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
					prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
					ExcelTestData.get(NursePractitionerNPI));
			prescriptioninformation.clickOnNextButton();

			Logger("STEP 15:User Clicks on Form Confirmation Button");
			formConfirmation.clicOnFormConfirmation();

			documentsPage.openChildDoc();
			accountObject.verifyChildDocStatusField("Completed");

			Logger("STEP 16:Verify account is created ");
			accountObject.navigateToAccount();
			accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
			refresh();

			Logger("STEP 17: Go to related tab and validate all the records has been created and is linked to the patient record");
			// Contact Contact Relationships
			accountObject.clickOnTab(tabsName.get(1));
			accountObject.navigateToCCR();
			accountObject.validateCCR(ExcelTestData.get(collaboratingMDName), ExcelTestData.get(prescriberName),
					ExcelTestData.get(legalRepresentativeName), ExcelTestData.get(legalrelationship));
			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

			// Member Plans
    		accountObject.clickOnTab(tabsName.get(1));
			accountObject.clickOnMemberPlan();
			accountObject.validateMemberPlans(ExcelTestData.get(rxPayerName), ExcelTestData.get(medicalPayerName));
			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

			// Authorization form consent
			Logger("STEP 18:Verify that user is able to navigate to Authorization Form Consent object and is able to view consents records");
    		accountObject.clickOnTab(tabsName.get(1));
    		accountObject.authorizationFormConsents(ExcelTestData.get(patientName),
    				careProgramProduct.get(6).split(" - ")[0], ExcelTestData.get(patientCertificationsDate),
    				patientcertSigned.get(0), ExcelTestData.get(patientAuthorizationDate), authorizationSigned.get(0),
    				ExcelTestData.get(prescriberSignatureDate), prescriberSignature.get(0),
    				ExcelTestData.get(textMessagingConsent));

			accountObject.clickOnTab(tabsName.get(1));
			// HIPAA
			Logger("STEP 19:Now, Open the HIPAA Authorization record and verify whether record is created by the name 'Patient Name: HIPAA Authorization'");
			accountObject.navigateToAuthFormConsentTable();
			accountObject.verifyHIPAAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
					ExcelTestData.get(patientAuthorizationDate));
			accountObject.navigateToAccountRecord(ExcelTestData.get(patientName));
			accountObject.clickOnTab(tabsName.get(1));

			// PPA
			Logger("STEP 20:Verify Consent Expiration Date logic for OTHER STATES for PPA");
			accountObject.navigateToAuthFormConsentTable();
			accountObject.verifyPPAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
					ExcelTestData.get(patientCertificationsDate));
			accountObject.navigateToAccountRecord(ExcelTestData.get(patientName));
			accountObject.clickOnTab(tabsName.get(1));

			Logger("STEP 21: Verify Care program enrollee record is linked to account ");
			accountObject.navigateCareProgramEnrollee();
			accountObject.cickOnCPERecord(cpeName);

			// HCO
			Logger("STEP 22: Verify Site/HCO record created ");
			accountObject.verifyHCORecord(ExcelTestData.get(sitefacilityname));
			accountObject.clickOnTab(tabsName.get(1));

			// Health Conditions
			Logger("STEP 23: Verify Health Conditions");
			accountObject.navigateHealthConditions();
			accountObject.validateHealthConditionsFromCPE(ExcelTestData.get(diagnosisCode));

			// Medication Requests
			Logger("STEP 24: Verify Medication Requests");
			accountObject.validateMRFromCPE(ExcelTestData.get(prescription5BDose),
					ExcelTestData.get(prescription5ADose));

			Logger("STEP 25: Logout from the application");
			documentsPage.logout();

			Logger("STEP 26: Login as PC User");
			homeportalPage = loginPage.userLogin(PCUserName, UserPassword);

			Logger("STEP 27: Navigate to Received Document object → Validate that the Program Coordinator can assign themselves a Received Document record from the PSQA Review Queue List View by clicking an \"Assign to me\" button.");
			homeportalPage.closeTabs();
			documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
			documentsPage.verifyRecentlyViewDocumentList();
			documentsPage.navigatetoPSQAReviewWorklistView();
			String createdDate = documentsPage.searchDocumentAndAssign(cpeName);

			Logger("STEP 28: Open the document from In Review List View");
			documentsPage.verifyRecordAndOpen(createdDate);

			Logger("STEP 29:Validate that Program Coordinator can View and Edit the record → Validate that the Status filed has value as Needs Review → Validate that the record has Owner name as logged in Program coordinator User.");
			patientSearch.fieldEditStatus();
			patientSearch.validateStatusDropdownValue();

			Logger("STEP 30: Logout from the application");
			documentsPage.logout();

		}
        


/**
 * ====================================================================================================================
 * Test Case Id:Validate OCR Mapping of CSU Enrollment Form from the DUPIXENT enrollment form into Omniscript
 * @author Tejal Pednekar
 * 27019 2177
 * PDF not editable
 * @throws Exception ====================================================================================================================
 */

@Test(description = "Validate OCR Mapping of CSU Enrollment Form from the DUPIXENT enrollment form into Omniscript", enabled = true)
public void RPE40_IC19139_Validate_OCR_Mapping_of_CSU_Enrollment_Form_from_dupixent_ef_into_omniscript() throws Exception {


	Map<String, String> ExcelTestData = new HashMap<String, String>();
	String TestCaseNumber = "TC9";

	Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
	String columnName[] = { "Text Messaging Consent", "Voicemail", "Text",
			"Specialty Pharmacy Name", "Diagnosis Code", "DUPIXENT MyWay",
			"Preferred Specialty Pharmacy" };
	String columnValue[] = { "TRUE", "TRUE", "TRUE", "Automation Correspondence SP",
			 "L50.9 - Urticaria, unspecified", "TRUE", "TRUE" };
	
	synchronized (excelDataUpdate) {
	excelDataUpdate.selectExcelSheet(functionality);
	excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
	}
	ExcelTestData = excel.getExcelInputData(TestCaseNumber);
	
	String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(6).split(" -")[0];

	Logger("Pre-Requisite 2 : User updates the Patient Form");
	synchronized (updatepdf) {
	updatepdf.selectEnrollmentForm("CSU");
	filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
	updatepdf.updatePDFForm(TestCaseNumber, functionality);
	}
	
	System.out.println(filePath.get());
	
	
	Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
	homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
	String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
			ExcelTestData.get(patientEmail) };

	Logger("STEP 2:Navigate to the Received document object →Select a document by checking the checkbox next to the relevant record--> Click on Assign to me button → Open the document and classify as enrollment form and Click on Submit");
	String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);
	
	Logger("STEP 2.1: Navigate To Recently View Document list");
	documentsPage.verifyRecentlyViewDocumentList();

	Logger("STEP 2.2:User will be redirected to the 'My Received Document' list view, Open the Document.");
	documentsPage.navigateToMyReceivedDocListView();
	documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));
	
	Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
	documentsPage.classifyDocument(documentType.get(0));
	documentsPage.submitDocument();

	Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
	documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

	Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
	patientSearch.verifyPatientSearchPageTitle();
	String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
	String patientFirstName = name[0];
	String patientMidName = name[1];
	String patientLastName = name[2];

	Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
	patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
			ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
			ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(6),
			ExcelTestData.get(patientDOB));
	
	patientSearch.clickOnNextButton();

	// patientinfoAndauthorization-Page
	Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
	String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
	String legalRepFirstName = legalRepName[0];
	String legalRepLastName = legalRepName[2];

	patientInfo.verifyPatientAuthorizationPageTitle();
	patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
			ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
			ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
			ExcelTestData.get(zip));
	patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
			patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
			ExcelTestData.get(textMessagingConsent));
	patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
			ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
			ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
			ExcelTestData.get(patientSecondaryphone));
	patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
	patientInfo.clickOnNextButton();

	// Patient Insurance - Page
	Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
	insuranceinfo.verifyInsuranceInfoPageTitle();
	insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
			ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
			ExcelTestData.get(rxPCN));

	insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
			ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
			ExcelTestData.get(insrelationshipToPatient));
	insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
	insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
			ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
	insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
	insuranceinfo.selectPayerPharmacy();
	insuranceinfo.selectMedicalPayer();
	insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
	insuranceinfo.clickOnNextButton();

	Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
	String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
	String preFirstName = preName[0];
	String prLastName = preName[2];

	String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
	String ofcFirstName = ofcName[0];
	String ofcLastName = ofcName[2];

	prescriberInformationPage.verifyPrescriberInfoPageTitle();
	prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
			ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
			ExcelTestData.get(prescriberstateLicense));
	prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
			ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
			ExcelTestData.get(prescriberZip));
	prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
			ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
			ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
	prescriberInformationPage.clickOnNextButton();

	// Diagnosis information-Page
	Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
	diagnosisinformation.verifyDiagnosisInfoPageTitle();
	diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
	Thread.sleep(2000);	
	diagnosisinformation.clickOnNextButton();

	Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
	String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
	String mdFirstName = mdName[0];
	String mdLastName = mdName[2];

	prescriptioninformation.verifyPrescriptionInfoPageTitle();
	prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
			ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
			ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
			prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
			ExcelTestData.get(NursePractitionerNPI));
	prescriptioninformation.clickOnNextButton();

	Logger("STEP 10:User Clicks on Form Confirmation Button");
	formConfirmation.clicOnFormConfirmation();
	documentsPage.verifyRecentlyViewDocumentList();

	Logger("STEP 11:Verify account is created ");
	accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));
	refresh();
	accountObject.clickOnTab(tabsName.get(1));
	
	Logger("12: Verify Care program enrollee record is linked to account ");
	accountObject.navigateCareProgramEnrollee();
	accountObject.cickOnCPERecord(cpeName);;
	
	Logger("13: Verify HealthCondition record populated as per EF ");
	accountObject.clickOnTab(tabsName.get(1));
     accountObject.validateHealthConditionsFromCPE(ExcelTestData.get(diagnosisCode));

	
	Logger("STEP 14: User Logout the Application.");
	documentsPage.logout();


}


	 /**
	 * ====================================================================================================================
	 * Test Case Id: Pre requisite for IC22136 where DOB <18 has to be entered, and CPE to be made Inactive, also get the Patient details for patient search in 22136
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test
	public List<String> Enrollment_PreRequisite_For_IC22136(String TestCaseNumber) throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Specialty Pharmacy Name",
				"Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy", "Prescription-5A Dose",
				"Prescription-5B Dose", "Relationship","Prescription-5A RefillCaptured", "Prescription-B RefillCaptured","Specialty"};
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "Automation Correspondence SP",
				"L12.8 Other Pemphigoid", "TRUE", "FALSE", "Dupixent 200 MG/1.14ML pre-filled syringe",
				"Dupixent 300 MG/2ML pre-filled syringe", "Caregiver","2","2" ,"ALLERGY"};

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(6).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("BP");
			filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-requisite STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-requisite STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		String dobUnder18 = utilityPage.generateDOBUnder18();
		Logger("Pre-requisite STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(6),
				dobUnder18);
		patientSearch.clickOnNextButton();

		List<String> personData = Arrays.asList(patientFirstName,patientLastName, ExcelTestData.get(patientEmail),ExcelTestData.get(patientPrimaryphone),ExcelTestData.get(zip),dobUnder18);

		Logger("Pre-requisite STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				dobUnder18, ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));

		
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.checkDOBerrorMsg();
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-requisite STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-requisite STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-requisite STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-requisite STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-requisite STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);

		Logger("Pre-requisite STEP 11: CPE record is made Inactive");
		accountObject.clickCPEStatusDrpdwn("CPE Status Update");
		docMgmt.selectCPEStatus(cpeStatus.get(1));
		 docMgmt.clickOnInactivationReason("Invalid EF (AE)");
		documentsPage.clickOnNextButtonInCM();
		docMgmt.selectUnenrollPatBox(listOptions.get(0));
		documentsPage.clickOnNextButtonInCM();

		Logger("STEP : logout the Application.");
		documentsPage.logout();

		return personData;

	}


	/**
	 * ====================================================================================================================
	 * Test Case Id: 27039 - R4.6-PE Automate iCare-16306-SIT-TC04: 
	 * Verify Reactivation via Enrollment Wizard upon Receiving a Corrected and Age-Approved Enrollment Form
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "iCare-16306-SIT-TC04: Verify Reactivation via Enrollment Wizard upon Receiving a Corrected and Age-Approved Enrolment Form", enabled = true)
	public void PE41_IC22136_Verify_Reactivation_via_Enrollment_Wizard_upon_Receiving_a_Corrected_and_Age_Approved_Enrollment_Form()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber1 = "TC10";

		List<String> exsitingpatient = Enrollment_PreRequisite_For_IC22136(TestCaseNumber1);

		String TestCaseNumber = "TC11";
		
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = {"Diagnosis Code" ,"Specialty"};
		String columnValue[] = { "L12.8 Other Pemphigoid","ALLERGY" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(6).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("BP");
			filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 1.2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 1.3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 2: Open the BP document and Classify it as enrollment form and click on submit");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-requisite STEP 3: In the Product Indication field select the product as DMW -BP Dupixient");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(6),
				ExcelTestData.get(patientDOB));

		String ExistingPatientFname =exsitingpatient.get(0);
		String ExistingPatientLname =exsitingpatient.get(1);
		String ExistingPatientPhone =exsitingpatient.get(3);
		String ExistingPatientEmail =exsitingpatient.get(2);
		String ExistingPatientDOB =exsitingpatient.get(5);
		String ExistingPatientZip =exsitingpatient.get(4);

		Logger("Pre-requisite STEP 3.1: > Enter the Patient information from CPE record created from Pre Requisites> Enter Patient First Name, Last Name, DOB, Zip>Click on Search>Select the Patient Record that is displayed>Click on Next");
		patientSearch.enterExistingPatientDetails(ExistingPatientFname, ExistingPatientLname, ExistingPatientDOB,
				ExistingPatientEmail,ExistingPatientZip , ExistingPatientPhone);
		patientSearch.searchAndSelectExistingPat();

		// patientinfoAndauthorization-Page
		Logger("Pre-requisite STEP 4: In Patient Information and Authorization Section> Enter the DOB where Patient Age is above 18 years> Enter the all the fields in Patient Information Section");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));

		Logger("STEP 5: Verify the Message for DOB field is not displayed when valid DOB is entered>Click on Next");
		patientInfo.checkDOBerrorMsg();
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-requisite STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-requisite STEP 6.1:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-requisite STEP 6.2:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-requisite STEP 6.3:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-requisite STEP 6.4:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 7: Click on the recently submitted Document>Navigate to Details Tab>Verify the CPE Record is created. >Click on the CPE record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);

		Logger("STEP 8 : Verify Status of the CPE is \"Active\"  >> Verify the status of Patient Account is Active");
		careProgram.checkStatusOfCPERecord(statusCPEP.get(0));
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(0));
		accountObject.verifyStatusField(statusCPEP.get(0));

		Logger("STEP 9: Logout from the application");
		documentsPage.logout();

			}



 /**
 * ====================================================================================================================
 * Test Case Id:ICARE-27038 Validate Linking of a Patient document to new CPE having same Patient
 * 
 * @author Trupti D
 * 
 * @throws Exception ====================================================================================================================
 */
       @Test(description = "SAT - TC02:Validate_Linking_of_a_Patient_document_to_new_CPE_having_same_Patient", enabled = true)
       public void PE_IC27038_Validate_Linking_of_a_Patient_document_to_new_CPE_having_same_Patient() throws Exception {
	
    	   
    	Map<String, String> ExcelTestData = new HashMap<String, String>();
   		String TestCaseNumber = "TC2";
   		
   		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "FALSE" };
		
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];
		
		updatepdf.selectEnrollmentForm("Asthma");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

   		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
   		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

   		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'Care program enrollee' Object.");
   		homeportalPage.closeTabs();
   		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
   		accountObject.searchRecord("Automation");
//   		accountObject.searchAndOpenRecord();
   		accountObject.searchCPERecordAndOpen();

   		Logger("STEP 3: Open any record and update the status as Active and OnHold field = TRUE");
//   		careProgram.updateStatus(cpeStatus.get(0));
//   		missingInformatioPage.clickOnSaveButton();
//   		Thread.sleep(3000);
//  		careProgram.updateOnHoldField();

   		Logger("STEP 4: Get Care Program Product");
   		// Get care program product
   		String cpProduct = careProgram.getCareProgramProduct() + " - Dupixent";

   		docMgmt.navigateToAccount();
   		String accountDetails[] = accountObject.getCPEDetails();

   		// Patient name
   		String[] existingPname = updatepdf.splitFullName(accountDetails[0]);
   		String patientFName = existingPname[0] + " " + existingPname[1];
   		String patientLName = existingPname[2];

   		// Patient DOB
   		String dob = Utility_Function.changeFormatDateMMddYYYY(accountDetails[1]);

   		// Patient email
   		String email = accountDetails[2];

   		// patient phone
   		String patientPhone = Utility_Function.formatNumber(accountDetails[3]);

   		// Patient Zip Code
   		String zipCode = accountDetails[4];

   		Logger("STEP 5: Upload document to Dupixent portal");
   		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
   				ExcelTestData.get(patientEmail) };
   		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

   		Logger("STEP 6: Navigate to the Recently view ");
   		documentsPage.verifyRecentlyViewDocumentList();

//   			Logger("STEP 2.2:Navigate to Received Document Worklist and Check the checkbox on the record and click on 'Assign to me' button.");
//   			documentsPage.navigateToReceiveddocument();
//   			documentsPage.verifyAndAssignDocID(documentID);

   		Logger("STEP 7:User will be redirected to the 'My Received Document' list view, Open the Document.");
   		documentsPage.navigateToMyReceivedDocListView();
   		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//   			Logger("STEP 2.4:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//   			documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

   		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
   		documentsPage.classifyDocument(documentType.get(0));
   		documentsPage.submitDocument();

   		Logger("STEP 9: After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
   		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
   		
   		//ExcelTestData = excel.getExcelInputData(TestCaseNumber);

   		Logger("STEP 10: User selects valid ‘Care Program Product' field data and click on Next Button.");
   		patientSearch.verifyPatientSearchPageTitle();
   		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
   		String patientFirstName = name[0];
   		String patientMidName = name[1];
   		String patientLastName = name[2];
 		
   		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));

   		Logger("Step 11: Click on 'search Patient' button and Select an existing patient from the search table and click on next button");
   		patientSearch.searchExistingPatient2(patientFName, patientLName, dob, patientPhone, email, zipCode);
 

   		Logger("Pre-Requisite STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
   		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];
   		   		
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-Requisite STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		System.out.println(ExcelTestData.get(pharmacyfax));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.updateZipandSpeciality("ALLERGY", "32839");
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 15: User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
				
		Logger("STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		
		Logger("STEP 17: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 18: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		
		homeportalPage.closeTabs();
		
		Logger("STEP 19: Open Care Program Enrollee account and verify details.");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.navigateCareProgramEnrollee();
		careProgram.checkColumnSorting();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 20: Navigate to Related tab and go to Received documents table.");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToReceivedDocTable();
		careProgram.clickOnViewAll("Received Documents");
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
		
       Logger("Step 21 :Validate the Care Program Product is a read only field");
       careProgram.ValidateCareProgramProductReadOnlyField();
       refresh();
       
       Logger("Step 22 :Validate the Care Program Enrollee field gives error when we try to save other CPE ");
       careProgram.enterCareProgramEnrollee("Automation");
       careProgram.enterCaseManager();
       careProgram.selectReviewoption();
       docMgmt.clickSave();
       docMgmt.validateSaveErrorMsg();
       refresh();
       
       Logger("Step 23 :Validate the Care Program Enrollee field saves correctly when we select the same CPE ");
       careProgram.enterCareProgramEnrollee(ExcelTestData.get(patientName));
       careProgram.enterCaseManager();
       careProgram.selectReviewoption();
       docMgmt.clickSave();
            
       Logger("STEP 24: User Logout the Application.");
		documentsPage.logout();
       
       }      


/**
 * ====================================================================================================================
 * Test Case Id:ICARE-27048 Validate Linking of a Patient document to new CPE having same Patient
 * 
 * @author Trupti D
 * 
 * @throws Exception ====================================================================================================================
 */
       @Test(description = "SIT - TC02:Verify ‘Med D PAP Reenrollment’ Document Linking to Patient and Active CPE via Manual Process", enabled = true)
       public void PE_IC27048_Verify_Med_D_PAP_Reenrollment_Document_Linking_to_Patient_and_Active_CPE_via_Manual_Process() throws Exception{

    	   String docName = "Medicare Part D PAP Re-enrollment Form – English.pdf";
    	   
      		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
      		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
      		
      		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'Care program enrollee' Object.");
       		homeportalPage.closeTabs();
       		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
       		accountObject.searchRecord("Automation");
       		accountObject.searchCPERecordAndOpen();
       		
       		String cpProduct = careProgram.getCareProgramProduct() + " - Dupixent";
    	   
    	    docMgmt.navigateToAccount();
      		String accountDetails[] = accountObject.getCPEDetails();

      		// Patient name
      		String[] existingPname = updatepdf.splitFullName(accountDetails[0]);
      		String patientFName = existingPname[0] + " " + existingPname[1];
      		String patientLName = existingPname[2];

      		// Patient DOB
      		String dob = Utility_Function.changeFormatDateMMddYYYY(accountDetails[1]);

      		// Patient email
      		String email = accountDetails[2];

      		// patient phone
      		String patientPhone = Utility_Function.formatNumber(accountDetails[3]);

      		// Patient Zip Code
      		String zipCode = accountDetails[4]; 
      		
      		documentsPage.logout();
    	      	   

        Logger("STEP 3: Login to the UAT Org as 'PSR.");
			homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
   		
		Logger("STEP 4: Navigate to Received Documents from the App Launcher");
   		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0),DocumentPage.class);
   		documentsPage.navigateToAllReceivedDocPMUser();		   		
   		accountObject.searchRecord("Automation");
   		
   		Logger("STEP 5: Assign the document to PSR User");
   		documentsPage.clickOnShowActions();
   		documentsPage.changeOwnerFromlist();
   		 
   		Logger("STEP 6: Navigate to My Received Documents list");
   		documentsPage.navigateToMyReceivedDocument();
   		accountObject.searchRecord("Automation");
   		careProgram.checkColumnSorting();
   		documentsPage.clickOnRecord();
   		
   		Logger("STEP 7: Classify the document as 'Med A PAP Enrollment' and Submit");
   		documentsPage.classifyDocument(documentType.get(2));
   		documentsPage.submitDocument();
   		
   		Logger("STEP 8: Verify and Enter the Patient search details");
   		patientSearch.verifyPatientSearchPageTitle();
   		patientSearch.searchExistingPatient2(patientFName, patientLName, dob, patientPhone, email, zipCode);
   		
   		Logger("STEP 9: Enter Review Outcome and select Updated Case Manager and click Submit");
   		psqaPage.verifyPSQAPageTitle();
   		psqaPage.selectReviewOutcome();
   		psqaPage.selectUpdatedCaseManager();
   		psqaPage.clickSubmit();
   		
   		Logger("STEP 10: Logout as PR User");
   		documentsPage.logout();
   	   
        Logger("STEP 11: Login to the UAT Org as 'CM.");
			homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		
		Logger("STEP 12: Select Care Program Enrollee from App Launcher");	
		homeportalPage.closeTabs();
       		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
   				
   		Logger("STEP 14: Select the account and navigate to Received Documents table ");	
   		accountObject.globalSearch(searchFilter.get(0), accountDetails[0]);
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToReceivedDocTable();
		careProgram.clickOnViewAll("Received Documents");
		docMgmt.verifyReceivedDocIDLinkedToCPE(docName);
		refresh();
		
		Logger("STEP 15: Validate the AR in Progress checkbox is checked and AR Speciality is read only field");	
		accountObject.globalSearch(searchFilter.get(0), accountDetails[0]);
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		careProgram.checkColumnSorting();
		accountObject.cickOnCPERecord(accountDetails[0]);
		psqaPage.validateAR();
		psqaPage.validateARSpecialistReadOnlyField();
		refresh();
		
   		Logger("STEP 16: Select the account and navigate to Cases table ");	
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCasesTable();
		careProgram.clickOnViewAll("Cases");
		psqaPage.verifyMedCases();
		
		Logger("STEP 17: Logout as CM ");	
		documentsPage.logout();
   		
       }
       

       /**
        * ====================================================================================================================
        * Test Case Id:ICARE-27048 Med D PAP Reenrollment’ Document is linked to a Patient & Active CPE from the Portal
        * 
        * @author Trupti D
        * 
        * @throws Exception ====================================================================================================================
        */
       
       
       
    @Test(description = "SIT - TC02:Verify ‘Med D PAP Reenrollment’ Document Linking to Patient and Active CPE via Manual Process", enabled = true)
    public void ICARE_27047_Med_D_PAP_Reenrollment_Document_is_linked_to_a_Patient_Active_CPE_from_the_Portal()throws Exception {
    	  	
	Map<String, String> ExcelTestData = new HashMap<String, String>();
	String testCaseNumber = "TC2";
	ExcelTestData = excel.getExcelInputData(testCaseNumber);
	String docName = "Medicare Part D PAP Re-enrollment Form – English.pdf";
	
	Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
	homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
		
	Logger("STEP 2: Navigate to the App Launcher' Search and Open 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		accountObject.searchRecord("Automation");
		accountObject.searchCPERecordAndOpen();
		
		String cpProduct = careProgram.getCareProgramProduct() + " - Dupixent";
   
      docMgmt.navigateToAccount();
       String accountDetails[] = accountObject.getCPEDetails();

		// Patient name
		String[] existingPname = updatepdf.splitFullName(accountDetails[0]);
		String patientFName = existingPname[0] + " " + existingPname[1];
		String patientLName = existingPname[2];

		// Patient DOB
		String dob = Utility_Function.changeFormatDateMMddYY(accountDetails[1]);

		// Patient email
		String email = accountDetails[2];

		// patient phone
		String patientPhone = Utility_Function.formatNumber(accountDetails[3]);

		// Patient Zip Code
		String zipCode = accountDetails[4]; 

	Logger("STEP 1: Launch the Following Portal URL for QA org.");
	uploadDocs.navigateToDupxientUrl();
	
	Logger("STEP 2: Once URL is launched, from the welcome a Pop up is displayed Click on \"I am a Patient or Caregiver\" button");
	dupixentPortal.clickOnAcceptAllCookies();
	dupixentPortal.handleLoginScreen();
	dupixentPortal.clickOnAcceptAllCookies();
	dupixentPortal.clickOnPatientorCaregiverButton();
	
	Logger("STEP 3: Click the \"Electronically Sign Patient Consent Form\" button in the home page.");
	dupixentPortal.clickOnElectronicConsentForm();

	Logger("STEP 4: Validate the User is navigating to \"Patient eSignature Authorization Form\" Page.");
	dupixentPortal.verifyPatienteSignatureAuthorizationPage();

	Logger("STEP 5: verify the Following Fields on English version are required fields on Enrollment Form:");
	dupixentPortal.selectMedDCategory();
	for (String formField : requiredFormFieldsMedD) {
		dupixentPortal.verifyRequiredFieldsMedD(formField);
	}

	Logger("STEP 6:  Click the \"Review & Sign Electronically\" button and Validate the user can enter values for all fields on the Patient Enrollment form on English version PDF’s..");
	dupixentPortal.enterPatientInfoMedD(accountDetails[0], accountDetails[1],
			ExcelTestData.get(gender), accountDetails[2], accountDetails[3],
			"2", "$40000");
	dupixentPortal.esignPDFMedD();

	Logger("STEP 7: Verify the once all required fields are entered, the user is able to proceed and confirm submission of their signature via the Adobe e-Sign window");
	dupixentPortal.clickToSign(ExcelTestData.get(patientEmail));

	Logger("STEP 8: After Submitting the Documents from the Unauthenticated Portal, Now Log in QA org As DIS User");
	uploadDocs.navigateToSFUrl();
	
	documentsPage.logout();

	Logger("STEP 9: Login as AR User");
	homeportalPage = loginPage.userLogin(ARUserName, UserPassword);
	homeportalPage.closeTabs();
	accountObject.globalSearch(searchFilter.get(0), accountDetails[0]);
	accountObject.clickOnTab(tabsName.get(1));
	accountObject.navigateCareProgramEnrollee();
	careProgram.checkColumnSorting();
	accountObject.cickOnCPERecord(accountDetails[0]);
	
	Logger("STEP 10: Validate AR in Progress is checked and AP Speacilist field is Read Only field");
	psqaPage.validateAR();
	psqaPage.validateARSpecialistReadOnlyField();
	refresh();
	
	Logger("STEP 11: Navigate to Cases table in Related tab");
	accountObject.clickOnTab(tabsName.get(1));
	docMgmt.navigateToCasesTable();
	psqaPage.verifyMedCases();
	
	Logger("STEP 12: User Logout the Application.");
	documentsPage.logout();

			}

  /**
 * ====================================================================================================================
 * Test Case Id:ICARE-27046 Validate Child Document Naming Format During Classification
 * 
 * @author Shraddha Shetty
 * 
 * @throws Exception ====================================================================================================================
 */

@Test(description = "ICARE-27046 - iCare20176 - Validate Child Document Naming Format During Classification", enabled = true, priority = 5)
public void PE41_IC24491_Validate_Child_Document_Naming_Format_During_Classification()
		throws Exception {

	Logger("Pre-Requisite : Update test data in excel test data sheet as per test case requirement");
	Map<String, String> ExcelTestData = new HashMap<String, String>();
	String TestCaseNumber = "TC8";

	String columnName[] = { "Diagnosis Code" };
	String columnValue[] = { "L28.1 - Prurigo nodularis" };
	excelDataUpdate.selectExcelSheet(functionality);
	excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
	ExcelTestData = excel.getExcelInputData(TestCaseNumber);

	Logger("Pre-Requisite : User updates the Patient Form");
	updatepdf.selectEnrollmentForm("Prurigo Nodularis");
	filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
	updatepdf.updatePDFForm(TestCaseNumber, functionality);
	System.out.println(filePath.get());
	String pdfFilePath = filePath.get();
	
	Logger("STEP 1: Login to the QA_SIT Org as 'DIS user'.");
	homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
	String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
			ExcelTestData.get(patientEmail) };
	Thread.sleep(2000);

	Logger("STEP 2: Launch the dupixent My way Portal URL for QA/Val org'.");
	navigateToUrl(DupixentMyWayPortalURL);

	Logger("STEP 3: Once URL is launched, from the welcome a Pop up is displayed Click on \"I am a Patient or Caregiver\" button.");
	dupixentPortal.clickOnAcceptAllCookies();
	dupixentPortal.clcikLoginHere();
	dupixentPortal.clickOnPatientorCaregiverButton();
	

	Logger("STEP 4: Click the \"Upload Document\" button in the home page.");
	dupixentPortal.clickOnUploadDocButton();

	Logger("STEP 5: In the next page Enter Enrollment code and submit it.");
	dupixentPortal.enterAccessCode("8443879370");
	dupixentPortal.clickOnSubmitCodeButton();

	Logger("STEP 6: Enter the details Patient Information section and submit enrollment Form");
	dupixentPortal.enterPatientInfo(cpeDetails);
	dupixentPortal.clickOnSubmitDocCheckBox();
	dupixentPortal.clickOnConsentCheckBoxes();
	dupixentPortal.clickOnUploadFileButton();
	documentsPage.uploadDocument(pdfFilePath);
	dupixentPortal.clickOnSubmitButton();
	String documentID = dupixentPortal.getDocumentID();

	Logger("STEP 7: After Submitting the Documents from the Unauthenticated Portal, Now Log in org As DIS1 User");
	navigateToUrl(URL);
	boolean homepage = dupixentPortal.verifyLoginScreen();
	if (homepage) {
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
	} else {
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
	}
	homeportalPage.closeTabs();
	documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

	Logger("STEP 8: Navigate To Received Documents Object >> Open the Uploaded Documents from Portal and Change owner to PSR user");
	documentsPage.verifyRecentlyViewDocumentList();
	docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
	docMgmt.navigateToListofCPE("All Received Documents");
	documentsPage.openDocumentFromAllRecivedDocList(documentID);
	fileName = documentsPage.getFileName(pdfFilePath);
	documentsPage.verifyRecordAndClick(fileName);
	documentsPage.changeOwner(DISUserName);
	documentsPage.logout();
	
	Logger("STEP 9:Login to the QA_SIT Org as 'Data Intake Specialist'.");
	homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

	Logger("STEP 10: Navigate To Recently View Document list");
	documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
	homeportalPage.closeTabs();
	documentsPage.verifyRecentlyViewDocumentList();

	Logger("STEP 11:User will be redirected to the 'My Received Document' list view, Open the Document.");
	documentsPage.navigateToMyReceivedDocListView();
	documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

	Logger("STEP 12:Once the Document is opened, navigate to its details Tab and get Received Date of Document");
	accountObject.clickOnTab(tabsName.get(0));
	String receivedDate = documentsPage.getReceivedDateFromDetailsTab();
	
	Logger("STEP 13: Classify document and verify Name");
	int invalidDocId = 1;
	for(int i=0; i<documentType.size(); i++) {
		
		if(documentType.get(i).equals("Invalid Document")) {
			invalidDocId = i;
		} else {
			Logger("STEP 13.1:Verify document details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
			documentsPage.classifyDocument(documentType.get(i));
			documentsPage.submitDocument();
			
			Logger("STEP 13.2: Validate naming format of the document");
			documentsPage.validateNamingFormatOfReceivedDoc(documentType.get(i), receivedDate);
			
			Logger("STEP 13.3: Click Back to Classify button");
			if(documentType.get(i).equals("Enrollment Form")) {
				documentsPage.clickBackToClassifyWithProductIndication(careProgramProduct.get(6));
			} else {
				documentsPage.clickBackToClassify();
			}
			Logger("STEP 13.4: Navigate to Document tab");
			documentsPage.navigateToDocument(fileName);
		}	
	}

	Logger("STEP 14:Verify document details and Now on ‘Classify Document’ section and fill Document Type as Invalid and click on 'Submit' button.");
	documentsPage.classifyDocument(documentType.get(invalidDocId));
	documentsPage.submitDocument();
	
	Logger("STEP 15: Validate naming format of the document");
	documentsPage.validateNamingFormatOfReceivedDoc(documentType.get(invalidDocId), receivedDate);

	Logger("STEP 16: Navigate to its details Tab and verify help text of Status field");
	accountObject.clickOnTab(tabsName.get(0));
	documentsPage.validateHelpTextOnStatusField("This field is automatically updated by system. Do not update it manually.");
	
	Logger("STEP 17: Validate Status filed is editable");
	papPage.validateFieldsAreEnableOrDisable("Status", true);
	
	Logger("STEP 18: User Logout the Application.");
	documentsPage.logout();

}


/**
	 * ====================================================================================================================
	 * Test Case Id: 27055 - R4.7 - PE Automate ICARE-15255:SIT:TC01: Validate Tax
	 * ID Field format on Enrollment of Patient
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE-15255:SIT:TC01: Validate Tax ID Field format on Enrollment of Patient ", enabled = true)
	public void PE42_IC25171_Validate_Tax_ID_Field_format_on_Enrollment_of_Patient()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC11";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code","Specialty" };
		String columnValue[] = { "J33.0 - Polyp of nasal cavity","ALLERGY" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(0).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Nasal Polyps");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.clearTextFromDateField();
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15: User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 17: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);

		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		Logger("STEP 18: Logout as DIS User");
		documentsPage.logout();

		int numberOfUsers = 4;
		String user = "";
		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
					case 0:
						Logger("STEP 19: Login to the ToleUat Org as 'CM'");
						homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
						user = "CM";
						break;

					case 1:
						Logger("STEP 19: Login to the ToleUat Org as 'PC'");
						homeportalPage = loginPage.userLogin(PCUserName, UserPassword);
						user = "PC";
						break;
					case 2:
						Logger("STEP 19: Login to the ToleUat Org as 'PM'");
						homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
						user = "PM";
						break;

					case 3:
						Logger("STEP 19: Login to the ToleUat Org as 'SA'");
						homeportalPage = loginPage.userLogin(SAUserName, UserPassword);
						user = "SA";
						break;

				}

				Logger("STEP 20:Navigate to Patient Record created from above execution.");
				navigateToURL(cpeURL);

				Logger("STEP 20.1: Open Facility record and Verify Tax ID is populated without Comma’s for "
						+ user + "user");
				docMgmt.clickOnSiteRecord();
				docMgmt.validateTaxIDFieldFormat();

				Logger("STEP 20.2: Logout from application");
				documentsPage.logout();

			} catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				documentsPage.logout();

			}

		}
	}
	
	/**
     * ====================================================================================================================
     * Test Case Id:ICARE-27045 - ICARE-22932 Validate Health Condition Record is created when Date of Diagnosis field is left blank in the Enrolment form
     * 
     * @author Shraddha Shetty
     * 
     * @throws Exception ====================================================================================================================
     */
      @Test(description = "Validate Health Condition Record is created when Date of Diagnosis field is left blank in the Enrolment form", enabled = true)
      public void PE43_IC22932_Validate_Health_Condition_Record_is_created_when_Date_of_Diagnosis_field_is_left_blank_in_the_Enrolment_form() throws Exception {
         
			Map<String, String> ExcelTestData = new HashMap<String, String>();
			String TestCaseNumber = "TC6";

			Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
			String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay" };
			String columnValue[] = { "L12.0 Bullous Pemphigoid", "TRUE"};
			String removeColumnName[] = { "Date Of Diagnosis" };

			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnName);
			ExcelTestData = excel.getExcelInputData(TestCaseNumber);

			String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(6).split(" -")[0];

			Logger("Pre-Requisite : User updates the Patient Form");
			updatepdf.selectEnrollmentForm("BP");
			filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFFormWithoutEdit(TestCaseNumber, functionality);
			System.out.println(filePath.get());
			String pdfFilePath = filePath.get();
			
			Logger("STEP 1: Login to the QA_SIT Org as 'DIS user'.");
			homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
			String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
					ExcelTestData.get(patientEmail) };
			Thread.sleep(2000);

			Logger("STEP 2: Launch the dupixent My way Portal URL for QA/Val org'.");
			navigateToUrl(DupixentMyWayPortalURL);

			Logger("STEP 3: Once URL is launched, from the welcome a Pop up is displayed Click on \"I am a Patient or Caregiver\" button.");
			dupixentPortal.clickOnAcceptAllCookies();
			dupixentPortal.clcikLoginHere();
			dupixentPortal.clickOnPatientorCaregiverButton();

			Logger("STEP 4: Click the \"Upload Document\" button in the home page.");
			dupixentPortal.clickOnUploadDocButton();

			Logger("STEP 5: In the next page Enter Enrollment code and submit it.");
			dupixentPortal.enterAccessCode("8443879370");
			dupixentPortal.clickOnSubmitCodeButton();

			Logger("STEP 6: Enter the details Patient Information section and submit enrollment Form");
			dupixentPortal.enterPatientInfo(cpeDetails);
			dupixentPortal.clickOnSubmitDocCheckBox();
			dupixentPortal.clickOnConsentCheckBoxes();
			dupixentPortal.clickOnUploadFileButton();
			documentsPage.uploadDocument(pdfFilePath);
			dupixentPortal.clickOnSubmitButton();
			String documentID = dupixentPortal.getDocumentID();

			Logger("STEP 7: After Submitting the Documents from the Unauthenticated Portal, Now Log in org As DIS User");
			navigateToUrl(URL);
			boolean homepage = dupixentPortal.verifyLoginScreen();
			if (homepage) {
				homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
			} else {
				documentsPage.logout();
				homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
			}
			homeportalPage.closeTabs();
			documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

			Logger("STEP 8: Navigate To Received Documents Object >> Open the Uploaded Documents from Portal and Change owner to PSR user");
			documentsPage.verifyRecentlyViewDocumentList();
			docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
			docMgmt.navigateToListofCPE("All Received Documents");
			documentsPage.openDocumentFromAllRecivedDocList(documentID);
			fileName = documentsPage.getFileName(pdfFilePath);
			documentsPage.verifyRecordAndClick(fileName);
			documentsPage.changeOwner(DISUserName);
			documentsPage.logout();
			
			Logger("STEP 9:Login to the QA_SIT Org as 'PSR User'.");
			homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

			Logger("STEP 10: Navigate To Recently View Document list");
			documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
			homeportalPage.closeTabs();
			documentsPage.verifyRecentlyViewDocumentList();

			Logger("STEP 11:User will be redirected to the 'My Received Document' list view, Open the Document.");
			documentsPage.navigateToMyReceivedDocListView();
			documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

			Logger("STEP 12:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
			documentsPage.classifyDocument(documentType.get(0));
			documentsPage.submitDocument();

			Logger("STEP 13:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
			patientSearch.verifyPatientSearchPageTitle();
			accountObject.clickOnTab(tabsName.get(0));
			documentsPage.verifyChild1Record();

			Logger("STEP 14: User selects valid ‘Care Program Product' field data and click on Next Button.");
			String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
			String patientFirstName = name[0];
			String patientMidName = name[1];
			String patientLastName = name[2];

			Logger("STEP 15: verify CPP error");
			patientSearch.verifyCareProgProductError();

			Logger("STEP 16: Verify Patient Search Page details and click on Next Button");
			patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
					ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
					ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(6),
					ExcelTestData.get(patientDOB));
			patientSearch.clickOnNextButton();

			// patientinfoAndauthorization-Page
			Logger("STEP 17:Verify Patient Information & Authorizations Page details and click on Next Button");
			String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
			String legalRepFirstName = legalRepName[0];
			String legalRepLastName = legalRepName[2];

			patientInfo.verifyPatientAuthorizationPageTitle();
			patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
					ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
					ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
					ExcelTestData.get(zip));
			patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
					patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
					ExcelTestData.get(textMessagingConsent));
			patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
					ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
					ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
					ExcelTestData.get(patientSecondaryphone));
			patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
			patientInfo.clickOnNextButton();

			// Patient Insurance - Page
			Logger("STEP 18:Verify Patient Insurance Inforamtion Page details, click on Save for later, open omnilink and click on Next Button");
			insuranceinfo.verifyInsuranceInfoPageTitle();
			insuranceinfo.clickOnSaveForLater();
			insuranceinfo.clickOnOK();
			insuranceinfo.switchToOmniLink();

			insuranceinfo.verifyInsuranceInfoPageTitle();
			insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
					ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
					ExcelTestData.get(rxPCN));

			insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
					ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
					ExcelTestData.get(insrelationshipToPatient));
			insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
			insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
					ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
			insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
			insuranceinfo.selectPayerPharmacy();
			insuranceinfo.selectMedicalPayer();
			insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
			insuranceinfo.clickOnNextButton();

			Logger("STEP 19:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
			String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
			String preFirstName = preName[0];
			String prLastName = preName[2];

			String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
			String ofcFirstName = ofcName[0];
			String ofcLastName = ofcName[2];

			prescriberInformationPage.verifyPrescriberInfoPageTitle();
			prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
					ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
					ExcelTestData.get(prescriberstateLicense));
			prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
					ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
					ExcelTestData.get(prescriberZip));
			prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
					ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
					ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
			prescriberInformationPage.clickOnNextButton();

			// Diagnosis information-Page
			Logger("STEP 20:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
			diagnosisinformation.verifyDiagnosisInfoPageTitle();
			diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
			Thread.sleep(2000);
			diagnosisinformation.clickOnNextButton();

			Logger("STEP 21:Verify Patient Prescription Inforamtion Page details and click on Next Button");
			String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
			String mdFirstName = mdName[0];
			String mdLastName = mdName[2];

			prescriptioninformation.verifyPrescriptionInfoPageTitle();
			prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
					ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
					ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
					prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
					ExcelTestData.get(NursePractitionerNPI));
			prescriptioninformation.clickOnNextButton();

			Logger("STEP 22:User Clicks on Form Confirmation Button");
			formConfirmation.clicOnFormConfirmation();

			//PSQA review
			Logger("STEP 23: Enter Review Outcome and select Updated Case Manager and click Submit");
	   		psqaPage.verifyPSQAPageTitle();
	   		psqaPage.selectReviewOutcome();
	   		psqaPage.selectUpdatedCaseManager();
	   		psqaPage.clickSubmit();
	   		
			Logger("STEP 24:Verify account is created ");
			accountObject.navigateToAccount();
			accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
			refresh();

			Logger("STEP 25: Go to related tab and validate all the records has been created and is linked to the patient record");
			accountObject.clickOnTab(tabsName.get(1));
			accountObject.navigateCareProgramEnrollee();
			careProgram.checkColumnSorting();
			accountObject.cickOnCPERecord(cpeName);
			accountObject.clickOnTab(tabsName.get(1));

			Logger("STEP 26: Verify Health Conditions record");
			accountObject.navigateHealthConditions();
			accountObject.validateHealthConditionsFromCPE(ExcelTestData.get(diagnosisCode));
			
			Logger("STEP 27: Verify Health Conditions code in record");
			accountObject.openHealthConditionsFromCPE();
			accountObject.validateLinkFields("Condition Code", ExcelTestData.get(diagnosisCode));

			Logger("STEP 28: Logout from the application");
			documentsPage.logout();

		}

	/**
 * ====================================================================================================================
 * Test Case Id:Pre requisite testcase for ICARE-24711, to create MED D AR Case
 * 
 * @author Shanavaz Nishani
 * 
 * @throws Exception ====================================================================================================================
 */
       @Test(description = "SIT - TC02:Verify ‘Med D PAP Reenrollment’ Document Linking to Patient and Active CPE via Manual Process", enabled = true)
       public String[] PreRequisite_To_create_MED_D_AR_Case() throws Exception{

    	   String docName = "Medicare Part D PAP Re-enrollment Form – English.pdf";
    	   
      		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
      		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
      		
      		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'Care program enrollee' Object.");
       		homeportalPage.closeTabs();
       		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
       		accountObject.searchRecord("Automation");
       		accountObject.searchCPERecordAndOpen();
       		
       		String cpProduct = careProgram.getCareProgramProduct() + " - Dupixent";
    	   
    	    docMgmt.navigateToAccount();
      		String accountDetails[] = accountObject.getCPEDetails();

      		// Patient name
      		String[] existingPname = updatepdf.splitFullName(accountDetails[0]);
      		String patientFName = existingPname[0].trim();
      		String patientLName = existingPname[2];
			System.out.println(patientFName + " " + patientLName
			);

      		// Patient DOB
      		String dob = Utility_Function.changeFormatDateMMddYYYY(accountDetails[1]);
			System.out.println(dob);

      		// Patient email
      		String email = accountDetails[2];
			System.out.println(email);

      		// patient phone
      		String patientPhone = Utility_Function.formatNumber(accountDetails[3]);
			System.out.println(patientPhone);

      		// Patient Zip Code
      		String zipCode = accountDetails[4]; 
			System.out.println(zipCode);
      		
      		documentsPage.logout();
    	      	   

        Logger("STEP 3: Login to the UAT Org as 'PSR.");
			homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
   		
		Logger("STEP 4: Navigate to Received Documents from the App Launcher");
   		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0),DocumentPage.class);
   		documentsPage.navigateToAllReceivedDocPMUser();		   		
   		accountObject.searchRecord("Automation");
   		
   		Logger("STEP 5: Assign the document to PSR User");
   		documentsPage.clickOnShowActions();
   		documentsPage.changeOwnerFromlist();
   		 
   		Logger("STEP 6: Navigate to My Received Documents list");
   		documentsPage.navigateToMyReceivedDocument();
   		accountObject.searchRecord("Automation");
   		careProgram.checkColumnSorting();
   		documentsPage.clickOnRecord();
   		
   		Logger("STEP 7: Classify the document as 'Med A PAP Enrollment' and Submit");
   		documentsPage.classifyDocument(documentType.get(2));
   		documentsPage.submitDocument();
   		
   		Logger("STEP 8: Verify and Enter the Patient search details");
   		patientSearch.verifyPatientSearchPageTitle();
   		patientSearch.searchExistingPatient2(patientFName, patientLName, dob, patientPhone, email, zipCode);

   		Logger("STEP 9: Enter Review Outcome and select Updated Case Manager and click Submit");
   		psqaPage.verifyPSQAPageTitle();
   		psqaPage.selectReviewOutcome();
   		psqaPage.selectUpdatedCaseManager();
   		psqaPage.clickSubmit();
   		
   		Logger("STEP 10: Logout as PR User");
   		documentsPage.logout();

		return accountDetails;

	   }


 /**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-27051 R4.7- Automate ICARE-21192-SIT-TC01-To verify Med D
	 * AR Case Page Layout
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE-21192-SIT-TC01-To verify Med D AR Case Page Layout", enabled = true)
	public void PE43_IC24711_verify_Med_D_AR_Case_Page_Layout()
			throws Exception {

		String[] details = PreRequisite_To_create_MED_D_AR_Case();
		String cpename  = details[0];

		Logger("STEP 1: Login in the Org as a AR Specialist User");
		homeportalPage = loginPage.userLogin(ARSUserName, UserPassword);

		Logger("STEP 2 and 3 :Verify the ‘Change Owner’ and ‘Assign Label’ standard buttons from all List views under Cases is removed. and Navigate to the Cases object and go to the 'AR Specialist Queue' list view");
		documentsPage =
		homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5),
		DocumentPage.class);
		documentsPage.verifyRecentlyViewDocumentList();
		documentsPage.verifyStdButtonRemoved(standardBtns.get(0));
		documentsPage.verifyStdButtonRemoved(standardBtns.get(1));
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(5));
		assessmentTasksPage.clickOnListView(Cases_ListView.get(4));

		Logger("STEP 4: Verify the following columns are displayed in the \"AR Specialist Queue\" list view: 1.Case Number 2.Care program Enrollee 3.Date Time Opened");
		docMgmt.verifyColumnsHeaderCases(columnsARSpecialistQ);

		Logger("STEP 5: Click on the Case-->Verify the Case Owner is displayed as ‘AR Specialist Queue’ when Status=Open");
		documentsPage.openRecentCase(cpename);
		accountObject.verifyStatusField(caseStatus.get(0));
		accountObject.verifyCaseOwnerForCase(caseOwners.get(0));
		String caseNo = accountObject.getCaseNumber();
		String cpeURL = getCurrentPageURL();

		Logger("STEP 6: Click on the Care Program Enrollee Link-->Navigate to Related List of CPE-->Verify the Med D AR Case is present in the Cases Section");
		accountObject.clickOnLinkFromField(fieldHyperLink.get(0));
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCasesTable();
		careProgram.clickOnCasesTable();
		documentsPage.checkIfCaseIsPresent(caseTypes.get(8));
		// add method to check case present

		Logger("STEP 7: Navigate back to the Account Object--> Click on the Med D AR Case in Open Status-->Update the Status of the Case from \"Open\" to \"Closed\" -->Select any value from Outcome-->Click on Save-->Verify the following error message is displayed: \"This status transition is not allowed manually\".Click on Cancel");
		documentsPage.clickOnCaseBasedOnStatus(caseTypes.get(8), caseStatus.get(0));
		documentsPage.EditAndUpdateTheCaseFields(fieldNames.get(1) , caseStatus.get(1));
		documentsPage.UpdateTheCaseFields("Outcome" , outcome_LoVs.get(4));
		documentsPage.clickOnSave();
		documentsPage.validateErrorMsgforCases();
		refresh();

		Logger("STEP 8 and 9: Navigate Back to AR Specialist List View-->Select a Case-->Click on Assign to me button → Verify the User is navigated to the My Cases list view and the oldest MED D AR case present in the list view is assigned to the user");
		documentsPage =
		homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5),
		DocumentPage.class);
		documentsPage.verifyRecentlyViewDocumentList();
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(5));
		assessmentTasksPage.clickOnListView(Cases_ListView.get(4));	
		documentsPage.selectCaseToAssign(cpename);
		documentsPage.clickOnAssignToMe();
		refresh();
		documentsPage.searchDocument(caseNo);
		documentsPage.clickOnTheDocumentName("Record Type", caseTypes.get(8), StatusCheck.get(0));

		Logger("STEP 10: Open the Case → Verify the Status of the Case is updated to \"In progress\"");
		accountObject.verifyStatusField(StatusCheck.get(0));

		Logger("STEP 11: Verify that when the Status is in Progress--> the Case Owner field is displayed as a hyperlink in Case Owner field and the logged in ARS User is assigned as the Case Owner");
		accountObject.verifyIfFieldisHyperlink("Case Owner",caseOwners.get(1));//change case owner as current Automation user once Automation user created

		Logger("STEP 12: Click on the Care Program Enrollee Link-->Navigate back to CPE record-->Verify the field ’AR in Progress' is checked and is a Read Only field");
		accountObject.clickOnLinkFromField(fieldHyperLink.get(0));
		accountObject.clickOnTab(tabsName.get(0));
		accountObject.validateCheckboxStatus("AR in Progress",true);
		accountObject.validateReadOnlyField("AR in Progress");

		Logger("STEP 13: Verify ‘AR Specialist’ field on the CPE Details page is auto populated with the AR Specialist hyperlink associated with the Case Ownerfield in Med D AR Case Record");
		accountObject.clickOnTab(tabsName.get(0));
		accountObject.verifyIfFieldisHyperlink(caseOwnerTitle.get(0),caseOwners.get(1));//change case owner as current Automation user once Automation user created

		Logger("STEP 14: Navigate back to Case record-->Open the Med D AR Case which is in In Progress State-->Update the Case Owner name to any other AR Specialist User other than the logged in User-->Click on Save-->Verify an Error message is displayed :\"You do not have access, please work with your manager to update Case Owner.\"");
		navigation_PreviousePage();
		refresh();
		Thread.sleep(2000);
		documentsPage.changeOwner(caseOwners.get(3),caseOwnerTitle.get(1));
		documentsPage.validateErrorMsgChangeOwner("Please select an AR Specialist user only, You do not have access, please work with your manager to update Case Owner.");
		refresh();

		Logger("STEP 15: Update the Status of the Case from \"In progress\" to \"Open\" for the the Med D AR Case which is in In Progress State-->Verify the following error message is displayed: \"This status transition is not allowed manually.\"");
		documentsPage.EditAndUpdateTheCaseFields(fieldNames.get(1) , caseStatus.get(0));
		documentsPage.clickOnSave();
		documentsPage.validateErrorMsgforCases();
		refresh();

		Logger("STEP 16 and 17: Update the Status of the Case from \"In Progress\" to \"Closed\" -->Verify the status of the case is changed to Closed");
		documentsPage.EditAndUpdateTheCaseFields(fieldNames.get(1) , caseStatus.get(1));
		documentsPage.UpdateTheCaseFields("Outcome" , outcome_LoVs.get(4));
		documentsPage.clickOnSave();
		accountObject.verifyStatusField(caseStatus.get(1));

		Logger("STEP 18: Verify when Status is selected as ‘Closed’-->the Following are the LoVs which should appear in Outcome drop-down:");
		documentsPage.EditAndUpdateTheCaseFields(fieldNames.get(1) , caseStatus.get(1));
		for (String val : outcome_LoVs) {
		papPage.validatePickListValues("Outcome", val);
		}
		refresh();
		
		Logger("STEP 19: Click on the Related Tab-->Verify Case History section is displayed");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyCaseHistory(); //check and change if needed

		Logger("STEP 20: Click on Care Program Enrollee Link-->Navigate Back to the CPE Record-->Verify that when the Med D AR case is closed-->");
		accountObject.clickOnTab(tabsName.get(0));
		accountObject.clickOnLinkFromField(fieldHyperLink.get(0));
		accountObject.VerifyFieldisNull(caseOwnerTitle.get(0));
		accountObject.validateCheckboxStatus("AR in Progress",false);

		Logger("STEP 21: Navigate back to the Med D AR Case record in closed Status-->Verify the Links : Account Name , Care Program Enrollee, Care Program are, are auto populated with their respective record links");
		navigation_PreviousePage();
		String cpeName = accountObject.getCpeDetails(fieldHyperLink.get(0));
		
		String[] parts = cpeName.split(" - ");
		String accName = parts[0].trim();
		String careProgram = parts[1].trim();

		String newRole = null;
		for (String role : carePrograms) {
			if (!role.equalsIgnoreCase(careProgram)) {
				newRole = role;
				break;
			}
		}
		accountObject.verifyIfFieldisHyperlink(fieldHyperLink.get(1),accName);
		accountObject.verifyIfFieldisHyperlink(fieldHyperLink.get(0),cpeName);
		accountObject.verifyIfFieldisHyperlink(fieldHyperLink.get(2),careProgram);

		Logger("STEP 22: Click on the Account Field-->Search and select any other patient Account which is not associated to the linked CPE-->Click on Save-->Verify  the error message \"Account Name cannot be updated\" is displayed");
		docMgmt.clcikOnEditbtn(fieldNames.get(1));
		documentsPage.updateCaseDetails(fieldHyperLink.get(1), "Automation");
		documentsPage.clickOnSave();
		documentsPage.validateErrorMsgAccntDetails("Account name can not be updated");

		Logger("STEP 23: Click on the Care Program Field-->Search and select any other Care Program which is not associated to the linked CPE-->Click on Save-->Verify  the error message \"Care Program cannot be updated.\" is displayed");
		documentsPage.updateCaseDetails(fieldHyperLink.get(2), newRole);
		documentsPage.clickOnSave();
		documentsPage.validateErrorMsgAccntDetails("Care Program can not be updated");
		refresh();
		accountObject.switchTabOnCPEheader(appLauncherMenuItem.get(5));

		List<String> caseNumber = new ArrayList<>();
		//This is a work around, if this doesnt work we need to create new MED D AR Cases from enrollment
		Logger("pre-requiste to create MED D AR Cases in In Progress State");
		for(int i=1; i<4;i++){
			missingInformatioPage.clickNewButton();
		docMgmt.selectNewCase(caseTypes.get(8));
		documentsPage.clickNextButton();
		documentsPage.createNewMedARCase(accName, careProgram, StatusCheck.get(0));
		String caseDetail = accountObject.getCaseNumber();
		accountObject.switchTabOnCPEheader(appLauncherMenuItem.get(5));
		caseNumber.add(caseDetail);
		}
		
		Logger("STEP 24: Logout from the Application as ARS User");
		documentsPage.logout();

		 String MedCase="" ;
		int numberOfUsers = 2;
		SoftAssert softassert = new SoftAssert();
		String currentUser = "";
		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
				case 0:
					Logger("STEP 1: Login to the UAT Org as 'Case Manager'.");
					homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
					currentUser = "PM";
					MedCase = caseNumber.get(0);
					break;
				case 1:
					Logger("STEP 1: Login to the UAT Org as 'PC User'.");
					homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
					currentUser = "BO";
					MedCase = caseNumber.get(1);
					break;
				}
				}catch (Exception e) {
					// TODO: handle exception
					Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				}

		
		Logger("STEP 25: Login to the Org as "+ currentUser +" User-->Navigate to Care Program Enrollee Object");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5), DocumentPage.class);
		documentsPage.verifyRecentlyViewDocumentList();
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(5));
		assessmentTasksPage.clickOnListView(Cases_ListView.get(1));

		Logger("STEP 26 and 27: Search and Select the CPE record which consists of the Med D AR cases in In progress State and Click on the Med D AR Case which is in Progress");
		refresh();
		documentsPage.searchDocument(MedCase);
		documentsPage.clickOnTheDocumentName("Record Type", caseTypes.get(8), StatusCheck.get(0));

		Logger("STEP 28: Edit The Case Owner Field and Assign any other AR Specialist User as the Owner of the Med D AR Case\r\n"
				+ //
				"\r\n" + //
				"Note: the newly assigned AR Specialist User should be different from the user already present in the Case Owner field\r\n"
				+ //
				"\r\n" + //
				"Click on Save");
		documentsPage.changeOwner(caseOwners.get(2), caseOwnerTitle.get(0));

		Logger("STEP 29: Click on the Care Program Enrollee Link-->Verify that the newly added Case Owner is displayed in the AR Specialist Field in the CPE record");
		accountObject.clickOnLinkFromField(fieldHyperLink.get(0));
		accountObject.verifyIfFieldisHyperlink(caseOwnerTitle.get(0),caseOwners.get(2));

		Logger("STEP 30: Navigate back to the Med D AR Case record which is in ‘In Progress’ State -->Update the Status to Closed-->Enter the Outcome -->Click on Save");
		navigation_PreviousePage();
		documentsPage.EditAndUpdateTheCaseFields(fieldNames.get(1), caseStatus.get(1));
		documentsPage.UpdateTheCaseFields("Outcome", outcome_LoVs.get(4));
		documentsPage.clickOnSave();

		Logger("STEP 30.1: Logout from the application");
		documentsPage.logout();
	}
		Logger("STEP 31: Repeat Step 27 to 31 for BO User");


		Logger("STEP 32: Login to the Org as CM User");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 33 and 34: Search and Select the CPE record which consists of the Med D AR cases in In progress State and >Navigate to Cases section and Click on the Med D AR Case which is in Progress");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5), DocumentPage.class);
		documentsPage.verifyRecentlyViewDocumentList();
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(5));
		assessmentTasksPage.clickOnListView(Cases_ListView.get(1));
		refresh();
		documentsPage.searchDocument(caseNumber.get(2));
		documentsPage.clickOnTheDocumentName("Record Type", caseTypes.get(8), StatusCheck.get(0));

		Logger("STEP 35: Edit The Case Owner Field and Assign any other AR Specialist User as the Owner of the Med D AR Case\r\n" + //
						"\r\n" + //
						"Verify the Error Message: \"You do not have access, please work with your manager to update Case Owner..\" is displayed");
		documentsPage.changeOwner(caseOwners.get(2), caseOwnerTitle.get(0));
		documentsPage.validateErrorMsgChangeOwner("You do not have access, please work with your manager to update Case Owner.");

		Logger("STEP 36: Logout from the application");
		documentsPage.logout();

	}
/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE_9346 - Regression-CarePrgm: Automate TC01: EF NEGATIVE
	 * SCENARIO 1
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test
	public void PE44_IC9346_Automate_TC01_EF_Negative_Scenario() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC1";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy",
				"Prescription 5B Quick Start" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "FALSE", "TRUE" };
		String removeColumnData[] = { "Prescriber Zip" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the VAL Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 3.1: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.2: Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 4: On Classify document page select Doc type = Enrollment Form > Click on submit.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 4.1: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 5: Enter the CARE PROGRAM PRODUCT > Click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 6: In Patient Information & Authorizations pg enter all the mandatory details of the patient.");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 7: Enter all the mandatory details in the Insurance Information section > Click on next.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 8: In the Prescriber Information section fill the zip code and the other details and the leave the specialty fieldblank > click on next.");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 9: In the Diagnosis Information fill all the mandatory details > click on next.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 10:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 11:User Click on Submit and Enrollment Form should be submitted");
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clickOnConfirm();

		Logger("STEP 18:  Open the CPE record > Validate CM & FRM is not assigned.");
		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));

		Logger("STEP 19: Validate that in CPE record CM is not assigned.");// FRM user is decommissioned
		careTeamAsgn.validateCMFields();

		Logger("STEP 20:Validate log record is created.");
		careTeamAsgn.validateLogRecordDetails();

		Logger("STEP 20: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-10556 Regression-CarePrgm: Automate Care Team Assignment:
	 * TC02_NEGATIVE SCENARIO 2
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "ICARE_10556 :Regression-CarePrgm: Automate Care Team Assignment: TC02_NEGATIVE SCENARIO 2", enabled = true)
	public void PE45_IC9347_Validate_Care_Team_Assignment_Negative_Scenario_02() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC1";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy",
				"Prescription 5B Quick Start" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "FALSE", "TRUE" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the VAL Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 3.1: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.2: Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 4: On Classify document page select Doc type = Enrollment Form > Click on submit.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 4.1: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 5: Enter the CARE PROGRAM PRODUCT > Click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 6: In Patient Information & Authorizations pg enter all the mandatory details of the patient.");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 7: Enter all the mandatory details in the Insurance Information section > Click on next.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 8: In the Prescriber Information section fill the zip code and the other details and the leave the specialty fieldblank > click on next.");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 9: In the Diagnosis Information fill all the mandatory details > click on next.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 10:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 11:User Click on Submit and Enrollment Form should be submitted");
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clickOnConfirm();

		Logger("STEP 12:  Open the CPE record > Validate CM is not assigned.");
		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));
		careTeamAsgn.validateCMFields();

		Logger("STEP 12.1:  Logout from application.");
		documentsPage.logout();
	}

	

/**
 * ====================================================================================================================
 * Test Case Id:ICARE-21663 
 * Verify Error message is displayed when DOB field is not entered in Patient Search Functionality in Enrollment Omniscript
 * @author Tejal
 * 27035
 * @throws Exception ====================================================================================================================
 */

@Test(description = "Verify Error message is displayed when DOB field is not entered in Patient Search Functionality in Enrollment Omniscript", enabled = true, priority = 5)
public void PE01_IC21663_Verify_Error_msg_is_displayed_when_dob_is_not_entered()
		throws Exception {

	Map<String, String> ExcelTestData = new HashMap<String, String>();
	String TestCaseNumber = "TC20";

	Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
	String columnName[] = { "Text Messaging Consent", "Voicemail", "Text",
			"Specialty Pharmacy Name", "Diagnosis Code", "DUPIXENT MyWay",
			"Preferred Specialty Pharmacy" };
	String columnValue[] = { "TRUE", "TRUE", "TRUE", "Automation Correspondence SP",
			 "L50.9 - Urticaria, unspecified", "TRUE", "TRUE" };
	

	excelDataUpdate.selectExcelSheet(functionality);
	excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
	ExcelTestData = excel.getExcelInputData(TestCaseNumber);
	String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(5).split(" -")[0];

	Logger("Pre-Requisite 2 : User updates the Patient Form");
	updatepdf.selectEnrollmentForm("Asthma");
	
	filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
	updatepdf.updatePDFForm(TestCaseNumber, functionality);
	System.out.println(filePath);

	Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
	homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

	Logger("STEP 2:Upload document to Dupixent portal");
	String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
			ExcelTestData.get(patientEmail) };
	String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

	Logger("STEP 3: Navigate To Recently View Document list");
	documentsPage.verifyRecentlyViewDocumentList();

	Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
	documentsPage.navigateToMyReceivedDocListView();
	documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

	

	Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
	documentsPage.classifyDocument(documentType.get(0));
	documentsPage.submitDocument();
     refresh();
    
     Logger("STEP 10: User selects valid ‘Care Program Product' field data and click on Next Button.");
	patientSearch.verifyPatientSearchPageTitle();

	Logger("STEP 11: Enter first name, last name , zip and email and Search patient");
	patientSearch.clearExistingFields();
	patientSearch.enterCareProgram(careProgramProduct.get(0));
	
	patientSearch.verifyFuzzyLogicExistingPatient(fuzzyPatientData3.get(0), fuzzyPatientData3.get(1), fuzzyPatientData3.get(3),
			fuzzyPatientData3.get(6), fuzzyPatientData3.get(2), null);

	Logger("STEP 12: Verify that the search functionality works with Fuzzy Logic at High Precision (matches nicknames, punctuation, international characters, and cultural spellings).");

	patientSearch.verifyMinCriteriaNotMet();


	Logger("STEP 18: User Logout the Application.");
	documentsPage.logout();

}

	
}