package com.sanofi.selenium.testutils;

import org.testng.ITestListener;
import org.testng.ITestResult;

public class CustomTestListener implements ITestListener {
    
    @Override
    public void onTestSkipped(ITestResult result) {
        Throwable skipReason = result.getThrowable();
        if (skipReason != null) {
            System.err.println("[Test Skipped] " + result.getMethod().getMethodName() +
                               " → " + skipReason.getMessage());
        } else {
            System.err.println("[Test Skipped] " + result.getMethod().getMethodName() +
                               " skipped with no exception.");
        }
    }
}
