package com.sanofi.selenium.Regression;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;

import org.testng.Assert;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.Configuration;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.AuthorizationFormConsentPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAPPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.utils.ReadExcel;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

import com.sanofi.selenium.pages.DocumentManagementPage;

public class DocumentManagement extends BaseTest {
	public static String PatientName, PatientDoB, PatientEmail, CMName, CPEURL, existingCPEURL;

	public String filePath;
	public ReadExcel excel;
	public String fileName;
	String functionality = "DocumentManagement";

	public static double getRandomNumber(double min, double max) {
		double x = (int) (Math.random() * ((max - min) + 1)) + min;
		return x;
	}

	double randomNum = getRandomNumber(1111, 9999);

	@BeforeMethod
	public void setUp() {
		accountObject = GetInstance(AccountObject.class);
		authorizationConsentPage = GetInstance(AuthorizationFormConsentPage.class);
		utilityPage = GetInstance(Utility_Function.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		documentsPage = GetInstance(DocumentPage.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		iapPage = GetInstance(IAPPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		generateTestData = GetInstance(GenerateTestData.class);
		sheetName = "Doc_MGMNT";
		excel = new ReadExcel(sheetName);
		PatientName = Configuration.readApplicationFile("PatientName");
		PatientDoB = Configuration.readApplicationFile("Birthdate");
		PatientEmail = Configuration.readApplicationFile("Email");
		CMName = Configuration.readApplicationFile("CMName");
		existingCPEURL = Configuration.readApplicationFile("CPEurl");
		uploadDocs = GetInstance(UploadDocument.class);
		papPage = GetInstance(PAPPage.class);
		quickStartPage = GetInstance(QuickStartPage.class);

	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	// Note: If this function is executed before document management test
	// cases, it will write the `cpeurl` to the text file. This URL can then be
	// reused for subsequent similar test cases, eliminating the need to create test
	// data again.

	@Test(description = "SIT_Document Management Workflow Patient Enrollment Prerequisites", enabled = true)
	public void DocumentManagement_CareProgramEnrolleeCreation() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC1";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Specialty Pharmacy Name",
				"Pharmacy Phone", "Pharmacy Fax", "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "Automation Correspondence SP", "(954) 312-1432",
				"(982) 053-8606", "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.verifyAndClickOnRecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		// Write url in text file
		Utility_Function.writeURL(cpeURL);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

	}

	@Test(description = "SIT_Document Management Workflow Patient Enrollment Prerequisites", enabled = true)
	public String DocumentManagement_PatientEnrollment_Prerequisites(String testcaseNumber) throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Prescriber NPI",
				"Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax", "Diagnosis Code", "DUPIXENT MyWay",
				"Preferred Specialty Pharmacy" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "370874" + randomNum, "Automation Correspondence SP",
				"(954) 312-1432", "(982) 053-8606", "L20.9 - Atopic dermatitis, unspecified", "TRUE", "TRUE" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);

		CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		return CPEURL;

	}

	@Test(description = "TC01 - Validate that request for Sharps can be sent to Merkle", enabled = true)
	public void DM01_IC4615_validate_That_Request_For_Sharps_CanBeSentToMerkle() throws Exception {

		String TestCaseNumber = "TC1";
		if (Utility_Function.checkURLinFile()) {
			CPEURL = Utility_Function.readURL();
			TestCaseNumber = "TC1";
		} else {
			CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);
		}
		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 5: Click on Start New Service Button");
		iapPage.clickOnStartNewService();
		iapPage.verifyServiceTitle();

		Logger("STEP 6: Select Service = ‘Fullfillment', Reason = ‘Patient requested’ and click on ‘Next’");
		docMgmt.selectService();
		missingInformatioPage.clickNextButton();
		docMgmt.selectReason();
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 7:  Select 'Sharps Kit’ from dropdown and click 'Next’");
		docMgmt.itemsToSend();
		missingInformatioPage.clickNextButton();

		Logger("STEP 8: Validate the request is sent and confirmation message is displayed ");
		docMgmt.validateConfirmationMessage();

		Logger("STEP 9:Log out from application");
		documentsPage.logout();
	}

	@Test(description = "TC02 - Validate Sharps container request when patient's consent is not on-file.", enabled = true)
	public void DM02_IC6316_Validate_Sharps_container_request_when_Patients_Consent_is_Not_on_File() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC2";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Prescriber NPI" };
		String columnValue[] = { "FALSE", "FALSE", "FALSE", "370874" + randomNum };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_Consent);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 1.2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 2.1: Navigate to the Recently view ");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 2.2:Navigate to Received Document Worklist and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.3:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//		Logger("STEP 2.4:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.2:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(1), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 12: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 16: Search CPE");
		homeportalPage.closeTabs();
		accountObject.globalSearchAcc(searchFilter.get(1), cpeName);

		Logger("STEP 17: Verify Consents are not provided by patient and is reflected on Authorization Form consents related list.");
		docMgmt.clickOnAccountName("Account");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.verifyConsentIsNotOnFile();

		Logger("STEP 20: Create a new auth form consent record and link it with patient indicating verbal consent was provided during call.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(6), DocumentPage.class);
		authorizationConsentPage.verifyAuthorizationConsentPage();
		authorizationConsentPage.verifyClickNewButton();
		authorizationConsentPage.selectAuthorizationConsent();
		authorizationConsentPage.verifyNextButton();

		docMgmt.createAuthorizationFormConsentRecord(accountName, ExcelTestData.get(legalRepresentativeName),
				consentCapturedSourceType.get(2), "General Marketing Consent", "DMW Asthma", consentStatus.get(1));

		Logger("STEP 19:Verify if CM user is able to update patients demographic Info.");
		Thread.sleep(4000);
		docMgmt.switchTab("CareProgramEnrollee", cpeName);
		docMgmt.clickOnAccountName("Account");
		accountObject.clickOnTab(tabsName.get(0));
		docMgmt.updateDemographicInfo(patientFirstName, patientLastName, ExcelTestData.get(city));

		Logger("STEP 9:Log out from application");
		documentsPage.logout();
	}

	@Test(description = "TC03 -To validate the error handling message  on Fax Correspondences", enabled = true)
	public void DM03_IC7454_validate_The_Error_Handling_Message_On_FaxCorrespondences() throws Exception {

		int numberOfUsers = 3;
		String TestCaseNumber = "TC3";
		if (Utility_Function.checkURLinFile()) {
			CPEURL = Utility_Function.readURL();
			TestCaseNumber = "TC1";
		} else {
			CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);
		}
		Map<String, String> ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		SoftAssert softassert = new SoftAssert();

		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
				case 0:
					Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
					homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
					break;
				case 1:
					Logger("STEP 1: Login to the QA_SIT Org as 'BV User'.");
					homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
					break;
				case 2:
					Logger("STEP 1: Login to the QA_SIT Org as 'System Admin User'.");
					homeportalPage = loginPage.userLogin(SAUserName, UserPassword);
					break;
				}

				Logger("STEP 2: Navigate to the Care program Enrollees object");
				navigateToUrl(CPEURL);
				Thread.sleep(4000);

				Logger("STEP 5: Clear the fax field of the patient and click on Save");
				docMgmt.verifyToclearFax();
				missingInformatioPage.clickOnSaveButton();
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

				Logger("STEP 6: Click on the Correspondence button");
				docMgmt.clickOnCorrespondenceBotton();

				Logger("STEP 7: Select the Process Name as 'Welcome Correspondence' and Select items to Send as 'DMW Checkbox Welcome' and Click on Next");
				docMgmt.selectProcessName(selectProcessName.get(0));
				docMgmt.selectItemsToSend(itemToSend.get(0));
				missingInformatioPage.clickNextButton();

				Logger("STEP 8: Validate error message for missing fax information");
				docMgmt.verifyErrorMessage();

				Logger("STEP 9: Click on Finish button and navigate back to the CPE record ");
				docMgmt.clickonFinishButton();
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

				Logger("STEP 10: Go to the Patient Account, fill the fax field, and click Save");
				docMgmt.editFax(ExcelTestData.get(pharmacyfax));
				missingInformatioPage.clickOnSaveButton();
				refresh();
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

				Logger("STEP 11: Click on the Correspondence button");
				docMgmt.clickOnCorrespondenceBotton();

				Logger("STEP 12: Verify Process Name and Item To Send");
				docMgmt.selectProcessNameAndItemToSend(selectProcessName.get(0), itemToSend.get(0));
				missingInformatioPage.clickNextButton();

				Logger("STEP 13: Verify Generate Document Correspondence Screen opens and user can send the Correspondence");
				docMgmt.verifyGenerateDocumentScreen();
				docMgmt.clickSendButtonUntilFinish();

				Logger("STEP 14: Validate success message is populated in the Correspondence record");
				String msg = docMgmt.validateSuccessMessage();
				if (msg.contains(summaryofBenefitMDFAXSuccessMSG)) {
					Logger("Success message verified.");
				} else {
					Logger("Success message not found.");
					softassert.fail(); // Soft assertion failure
					throw new Exception("Success message not found.");
				}

				docMgmt.clickonFinishButton();

				Logger("STEP 15: Verify message in Correspondence Record");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();
				accountObject.clickOnTab(tabsName.get(1));
				docMgmt.navigateToCorrespondenceTable();
				careProgram.clickOnViewAll("Correspondences");
				docMgmt.verifyCorrespondenceRecord(selectProcessName.get(0));
				docMgmt.clickOnCorrespondenceRecord(selectProcessName.get(0));
				docMgmt.verifyMessageIsPopulated();

				Logger("STEP 16: Log out from application");
				documentsPage.logout();

			} catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				documentsPage.logout();
			}
		}

		softassert.assertAll();
	}

	@Test(description = "TC04 - SAT - To validate the error handling message on Email Correspondences.", enabled = true)
	public void DM04_IC7656_To_validate_the_error_handling_message_on_Email_Correspondences() throws Exception {

		int numberOfUsers = 3;
		String TestCaseNumber = "TC4";
		if (Utility_Function.checkURLinFile()) {
			CPEURL = Utility_Function.readURL();
			TestCaseNumber = "TC1";
		} else {
			CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);
		}
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		SoftAssert softassert = new SoftAssert();

		for (int i = 0; i < numberOfUsers; i++) {
			try {

				switch (i) {
				case 0:
					Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
					homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
					break;
				case 1:
					Logger("STEP 1: Login to the QA_SIT Org as 'BV User'.");
					homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
					break;
				case 2:
					Logger("STEP 1: Login to the QA_SIT Org as 'System Admin User'.");
					homeportalPage = loginPage.userLogin(SAUserName, UserPassword);
					break;
				}

				Logger("STEP 2: Navigate to the Care program Enrollees object");
				homeportalPage.closeTabs();
				navigateToUrl(CPEURL);
				Thread.sleep(4000);

				Logger("STEP 19.2: Go to the Patient Account and fill the email field of the patient and click on Save");
				docMgmt.navigateToAccount();
				docMgmt.clearEmail();
				docMgmt.editPhone();
				missingInformatioPage.clickOnSaveButton();
				String name = ExcelTestData.get(patientName);
				String firstName = name.split(" ")[0];
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

				Logger("STEP 17: Click on the Correspondence button");
				docMgmt.clickOnCorrespondenceBotton();

				Logger("STEP 18.1: Select the Process Name as 'Welcome Correspondence' and Select items to Send as 'DMW Checkbox Welcome' and Click on Next");
				docMgmt.selectProcessName(processName.get(0));
				docMgmt.selectItemsToSend(itemsToSend.get(11));
				missingInformatioPage.clickNextButton();

				Logger("STEP 18.2: Validate that the system shows an error message \"The correspondence cannot be generated because the email information is either missing or incomplete.\" and user should not be able to send the correspondence");
				docMgmt.validateErrorMessage(welcomeCorrespondenceErrorMSG);

				Logger("STEP 19.1: Click on Finish button and navigate back to the CPE record ");
				docMgmt.clickonFinishButton();
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

				Logger("STEP 19.2: Go to the Patient Account and fill the email field of the patient and click on Save");
				docMgmt.navigateToAccount();
				docMgmt.editEmail(firstName);
				missingInformatioPage.clickOnSaveButton();
				refresh();
				Thread.sleep(5000);

				Logger("STEP 20.1: Navigate back to the CPE record and Click on Correspondence button →Select the Process Name as \"Welcome Correspondence\" and Select items to Send as \"DMW Checkbox welcome\" and Click on Next");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();
				docMgmt.clickOnCorrespondenceBotton();
				docMgmt.selectProcessName(processName.get(0));
				docMgmt.selectItemsToSend(itemsToSend.get(11));
				missingInformatioPage.clickNextButton();

				Logger("STEP 20.2: Validate user sees the confirmation message and the correspondence record is generated successfully");
				String successMessage = docMgmt.validateSuccessMessage();

				if (successMessage.contains(welcomeCorrespondenceSuccessMSG)) {
					Logger("Success message verified.");
				} else {
					Logger("Success message not found.");
					softassert.fail(); // Soft assertion failure
					throw new Exception("Success message not found.");
				}
				Logger("Success message verified.");
				docMgmt.clickonFinishButton();

				Logger("STEP 21.1: Navigate back to the CPE record and Go to the related list → Go to Correspondence and Open the Recently created correspondence record");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();
				accountObject.clickOnTab(tabsName.get(1));
				docMgmt.navigateToCorrespondenceTable();
				careProgram.clickOnViewAll("Correspondences");
				docMgmt.verifyCorrespondenceRecord(processName.get(0));
				docMgmt.clickOnCorrespondenceRecord(processName.get(0));

				Logger("STEP 21.2: Validate that the response message is getting populated on the message field of Correspondence record");
				docMgmt.verifyMessageIsPopulated();

				Logger("STEP 22: Log out from application");
				documentsPage.logout();

			} catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				documentsPage.logout();
			}
		}

		softassert.assertAll();
	}

	// NOTE:Test case has been cancelled.
	/***
	 * @Test(description = "TC05 - Validate that Multiple existing documents can be
	 *                   attached to a new Correspondence", enabled = true) public
	 *                   void
	 *                   DM05_IC4891_validate_The_Multiple_Existing_Docs_Attachement()
	 *                   throws Exception {
	 * 
	 *                   int numberOfUsers = 3; for (int i = 2; i < numberOfUsers;
	 *                   i++) {
	 * 
	 *                   switch (i) { case 0: Logger("STEP 1: Login to the QA_SIT
	 *                   Org as 'Case Manger'."); homeportalPage =
	 *                   loginPage.userLogin(CMUserName, UserPassword); break; case
	 *                   1: Logger("STEP 1: Login to the QA_SIT Org as 'BV User'.");
	 *                   homeportalPage = loginPage.userLogin(BVUsername,
	 *                   UserPassword); break; case 2: Logger("STEP 1: Login to the
	 *                   QA_SIT Org as 'System Admin User'."); homeportalPage =
	 *                   loginPage.userLogin(SAUserName, UserPassword); break; }
	 * 
	 *                   Logger("STEP 2:Navigate to the App Launcher' Search and
	 *                   Open 'iCare Connec' App.From App Launcher, search and click
	 *                   on the 'Care Program Enrollee'Object.");
	 *                   homeportalPage.closeTabs(); documentsPage =
	 *                   homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7),
	 *                   DocumentPage.class);
	 * 
	 *                   Logger("STEP 3: Change List view to 'Recently View' queue
	 *                   list view."); docMgmt.verifyRecentlyViewList();
	 * 
	 *                   Logger("STEP 4: Open the any newly created CPE");
	 *                   documentsPage.searchDocument("Automation"); String
	 *                   recordName = missingInformatioPage.searchAndOpenRecord();
	 * 
	 *                   Logger("STEP 4.1: Edit fax details to avoid empty fax
	 *                   error"); docMgmt.verifyToEditFax();
	 *                   missingInformatioPage.clickOnSaveButton();
	 *                   missingInformatioPage.navigateToCPERecord(recordName);
	 * 
	 *                   Logger("STEP 5: Click on the Correspondence button");
	 *                   docMgmt.clickOnCorrespondenceBotton();
	 * 
	 *                   Logger("STEP 6: Select the Process Name as 'Med D PAP
	 *                   Re-enrollment' and Select items to Send as 'DMW Med D PAP
	 *                   Annual Re-Enrollment - HCP Fax' and Click on Next");
	 *                   docMgmt.selectProcessName(processName.get(3));
	 *                   docMgmt.selectItemsToSend(itemsToSend.get(2));
	 *                   missingInformatioPage.clickNextButton();
	 * 
	 *                   Logger("STEP 7: User select Template");
	 *                   docMgmt.PickTemplates();
	 * 
	 *                   Logger("STEP 8: Check for previous and next page");
	 *                   docMgmt.NavigateBackAndForth();
	 * 
	 *                   Logger("STEP9: Again select template after moving back and
	 *                   fourth"); docMgmt.PickTemplates();
	 * 
	 *                   Logger("STEP 10: click on send attachment");
	 *                   docMgmt.SendAttachement();
	 * 
	 *                   Logger("STEP 11:Log out from application");
	 *                   documentsPage.logout(); } }
	 ***/


	// NOTE: Test case has been cancelled.
	// cancelling this test case since the Document linking message  will not be visible when an Existing Patient With an Active CPE as it will now redirect to the Enrollment screen
// 	@Test(description = "TC06: Validate removal of 'Next' and 'Save for later' buttons once doc is linked to existing patient", enabled = true)
// 	public void DM06_IC7183_Validate_Removal_of_Next_and_SaveForLater_buttons_once_doc_is_linked_to_ExistingPatient()
// 			throws Exception {

// 		Logger("Pre-Requisite : Update test data in excel test data sheet as per test case requirement");
// 		Map<String, String> ExcelTestData = new HashMap<String, String>();
// 		String TestCaseNumber = "TC6";

// 		String columnName[] = { "Diagnosis Code" };
// 		String columnValue[] = { "L28.1 - Prurigo nodularis" };
// 		excelDataUpdate.selectExcelSheet(functionality);
// 		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
// 		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

// 		Logger("Pre-Requisite : User updates the Patient Form");
// 		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
// 		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
// 		updatepdf.updatePDFForm(TestCaseNumber, functionality);
// 		System.out.println(filePath);

// 		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
// 		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

// 		Logger("STEP 1: Get patient record");
// 		accountObject.navigateToAccount();
// 		accountObject.searchRecord("Automation");
// 		// accountObject.searchAndOpenRecord();
// 		accountObject.searchRecordAndOpen();
// 		String accountDetails[] = accountObject.getCPEDetails();

// 		// Patient name
// 		String[] existingPname = updatepdf.splitFullName(accountDetails[0]);
// 		String patientFName = existingPname[0] + " " + existingPname[1];
// 		String patientLName = existingPname[2];

// 		// Patient DOB
// 		String dob = Utility_Function.changeFormatDateMMddYYYY(accountDetails[1]);

// 		// Patient email
// 		String email = accountDetails[2];

// 		// patient phone
// 		String patientPhone = Utility_Function.formatNumber(accountDetails[3]);

// 		// patient zip
// 		String pin = accountDetails[4];

// 		Logger("STEP 1.2:Upload document to Dupixent portal");
// 		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
// 				ExcelTestData.get(patientEmail) };
// 		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

// 		Logger("STEP 2.1: Navigate to the Recently view ");
// 		documentsPage.verifyRecentlyViewDocumentList();

// //		Logger("STEP 2.2:Navigate to Received Document Worklist and Check the checkbox on the record and click on 'Assign to me' button.");
// //		documentsPage.navigateToReceiveddocument();
// //		documentsPage.verifyAndAssignDocID(documentID);

// 		Logger("STEP 2.3:User will be redirected to the 'My Received Document' list view, Open the Document.");
// 		documentsPage.navigateToMyReceivedDocListView();
// 		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

// //		Logger("STEP 2.4:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
// //		documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

// 		Logger("STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
// 		documentsPage.classifyDocument(documentType.get(0));
// 		documentsPage.submitDocument();

// 		Logger("STEP 3.2:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
// 		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

// 		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
// 		patientSearch.verifyPatientSearchPageTitle();
// 		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
// 		String patientFirstName = name[0];
// 		String patientLastName = name[2];

// 		patientSearch.verifyPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
// 				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
// 				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
// 				ExcelTestData.get(patientDOB));

// 		Logger("Step 4: Click on 'search Patient' button and Select an existing patient from the search table and click on next button");
// 		patientSearch.searchExistingPatient(patientFName, patientLName, dob, patientPhone, email, pin);
// //		patientSearch.selectExistingPatientWithFaxNumber();

// 		Logger("Step 5: Selecting the existing record, the system links the CPE to the document so now Next and Save for Later button is not hidden on UI.");
// //		docMgmt.verifyNextAndSaveLaterButtonIsHidden();
// 		docMgmt.verifyNextAndSaveForLaterButtonIsNotHidden();

// 		Logger("STEP 6: User Logout the Application.");
// 		documentsPage.logout();

// 	}

	@Test(description = "TC07 -To validate the error handling message on PT letter Correspondences", enabled = true)
	public void DM07_IC7655_validate_The_Error_Handling_Message_on_PT_LetterCorrespondences() throws Exception {

		int numberOfUsers = 3;

		// Prerequisites

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC7";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified" };
		String removeColumnData[] = { "Address", "City", "State", "Zip" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 10: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 11: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 12:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 13:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 15:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 16:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 17:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.verifyAndClickOnRecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		// accountObject.verifyAndClickOnCPERecord(cpeName);
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		SoftAssert softassert = new SoftAssert();

		for (int i = 0; i < numberOfUsers; i++) {
			try {

				switch (i) {
				case 0:
					Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
					homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
					break;
				case 1:
					Logger("STEP 1: Login to the QA_SIT Org as 'BV User'.");
					homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
					break;
				case 2:
					Logger("STEP 1: Login to the QA_SIT Org as 'System Admin User'.");
					homeportalPage = loginPage.userLogin(SAUserName, UserPassword);
					break;
				}

				Logger("STEP 2: Navigate to the Care program Enrollees object");
				homeportalPage.closeTabs();
				navigateToUrl(CPEURL);
				Thread.sleep(4000);

				Logger("STEP 19.2: Go to the Patient Account and fill the email field of the patient and click on Save");
				docMgmt.navigateToAccount();
				docMgmt.clearMailingAddress();
				missingInformatioPage.clickOnSaveButton();
				Thread.sleep(2000);
				refresh();
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

				Logger("STEP 17: Click on the Correspondence button");
				refresh();
				docMgmt.clickOnCorrespondenceBotton();

				Logger("STEP 18.1: Select the Process Name as 'Welcome Correspondence' and Select items to Send as 'DMW Checkbox Welcome' and Click on Next");
				docMgmt.selectProcessName(processName.get(2));
				docMgmt.selectItemsToSend(itemToSend.get(2));
				missingInformatioPage.clickNextButton();

				Logger("STEP 18.2: Validate that the system shows an error message \"The correspondence cannot be generated because the email information is either missing or incomplete.\" and user should not be able to send the correspondence");
				docMgmt.validateErrorMessage(summaryofBenefitPTLetterErrorMSG);

				Logger("STEP 19.1: Click on Finish button and navigate back to the CPE record ");
				docMgmt.clickonFinishButton();
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

				Logger("STEP 19.2: Go to the Patient Account and fill the email field of the patient and click on Save");
				docMgmt.navigateToAccount();
				docMgmt.editMailingAddress(ExcelTestData.get(patientEmail),ExcelTestData.get(patientAddress), ExcelTestData.get(city),
						ExcelTestData.get(state), ExcelTestData.get(zip));
				missingInformatioPage.clickOnSaveButton();
				refresh();
				Thread.sleep(5000);

				Logger("STEP 20.1: Navigate back to the CPE record and Click on Correspondence button →Select the Process Name as \"Welcome Correspondence\" and Select items to Send as \"DMW Checkbox welcome\" and Click on Next");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();
				docMgmt.clickOnCorrespondenceBotton();
				docMgmt.selectProcessName(processName.get(2));
				docMgmt.selectItemsToSend(itemToSend.get(1));
				missingInformatioPage.clickNextButton();

				Logger("STEP 20.2: Validate user sees the confirmation message and the correspondence record is generated successfully");
				docMgmt.validateSuccessMessage();
				docMgmt.clickonFinishButton();

				Logger("STEP 13: Log out from application");
				documentsPage.logout();

			} catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				documentsPage.logout();
			}
		}

		softassert.assertAll();
	}

	@Test(description = "TC07: Data Intake Specialist (DIS) receives an invalid document", enabled = true)
	public void DM08_IC7114_Data_Intake_Specialist_DIS_receives_InvalidDocument() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC8";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "Prescriber NPI" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "374841" + randomNum };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		fileName = documentsPage.getFileName(filePath);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 1.2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 2.1: Navigate to the Recently view ");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 2.2:Navigate to Received Document Worklist and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.3:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//		Logger("STEP 2.7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Step 6: On the Document Type field, validate if you can see \"Invalid Document\" on the picklist values and it is the last value on the list");
		docMgmt.verifyInvalidDoc();

		Logger("STEP 7: Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.selectDocumentType(documentType.get(1));
		documentsPage.submitDocument();

		Logger("Step 9: On the same page, navigate to 'Details' tab and validate if the Status is in 'Needs Review'");
		documentsPage.verifyChildDocStatus(tabsName.get(0), status.get(1));

		Logger("STEP 10: Logout as DIS User from the Application.");
		documentsPage.logout();

		//Below steps not required
		// Logger("STEP 1:Login to the QA_SIT Org as 'PC'.");
		// homeportalPage = loginPage.userLogin(PCUserName, UserPassword);

		// Logger("Step 11: Go back to Navigation Menu and select 'Received Documents'");
		// documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		// documentsPage.verifyRecentlyViewDocumentList();

		// Logger("Step 12: Click 'PSQA Review Worklist' on the list view and validate if you are able to see the newly added invalid document");
		// documentsPage.navigateToPQSAWorklist();
		// documentsPage.verifyDOCInPSQAReviewList(fileName);

		// Logger("STEP 13: Logout as DIS User from the Application.");
		// documentsPage.logout();

	}

	@Test(description = "TC09 - Validate the Record Trigger flow to share Content Document with Owner of Received Document", enabled = true)
	public void DM09_IC6390_validate_The_Record_Trigger_Flow_To_Share_Content_Document_With_Owner_of_ReceivedDocument()
			throws Exception {

		Map<String, Map<String, String>> testCaseData = new HashMap<>();
		String testCaseNumber = "TC9";
		testCaseData.put(testCaseNumber,
				excelDataUpdate.createTestData(Map.of("Preferred Specialty Pharmacy", "FALSE", "DUPIXENT MyWay", "TRUE",
						"Text Messaging Consent", "TRUE", "Voicemail", "TRUE", "Text", "TRUE", "Best Timing AM", "TRUE",
						"Best Timing Afternoon", "TRUE", "Best Timing PM", "TRUE", "Prescriber NPI", "374841" + randomNum, "Diagnosis Code",
						"J45.40 - Moderate persistent asthma, uncomplicated")));

		Map<String, String> ExcelTestData = testCaseData.get(testCaseNumber);

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement for TestCaseNumber: "
				+ testCaseNumber);
		excelDataUpdate.updateExcelTestData(testCaseNumber, ExcelTestData, functionality);
		ExcelTestData = excel.getExcelInputData(testCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		filePath = updatepdf.PDFCreation(testCaseNumber, functionality);
		updatepdf.updatePDFForm(testCaseNumber, functionality);
		System.out.println(filePath);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 1.2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadsDoc(filePath, cpeDetails);

		Logger("STEP 2: Navigate to the Recently view list ");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

//		Logger("STEP 3:Once the PDF Enrollment Form is uploaded, navigate to the 'Received Document Worklist' list view of the Received Document.");
//		//fileName = documentsPage.getFileName(filePath);
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyRecord(documentID);
//		String parentDocId = documentsPage.getParentDocumentID(documentID);
//		System.out.print("docID" + parentDocId);
//
//		Logger("STEP 4:Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
//		docMgmt.clickOnCPERecord(parentDocId);
//		documentsPage.classifyDocument(documentType.get(0));
//		documentsPage.submitDocument();
//
//		Logger("STEP 5:Validate that the DIS User Cannot be able to procced without assign the Document to themselves, Error message Should be displayed.");
//		docMgmt.validateError();
//
//		Logger("STEP 6: Navigate to Recieved document worklist and Check the checkbox on the record and click on 'Assign to me' button.");
//		docMgmt.switchtoRecievedDocuments();
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocumentID(parentDocId);
//
//		Logger("STEP 7:User will be redirected to the 'My Received Document' list view, Open the Document.");
//		documentsPage.navigateToMyReceivedDoc(parentDocId, status.get(1));
//
//		Logger("STEP 8:Once the Document is opened, Click on refresh until the OCR status is updated to Success. and also verify owner name");
//		docMgmt.verifyDocDetailsPage(fileName);
//		documentsPage.verifyOCRStatus(documentOCRstatus.get(0));
//		String parentDocumentID = documentsPage.receivedDocumentId();
//
//		Logger("STEP 9:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
//		documentsPage.verfiyParentDocDetailsPage(tabsName.get(0), status.get(1));
//		documentsPage.classifyDocument(documentType.get(0));
//		documentsPage.submitDocument();
//
//		Logger("STEP 10:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
//		String childDocFileName = fileName + " (1)";
//		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
//		documentsPage.verifyDocDetailsPage(childDocFileName, ownerName.get(1));
//		documentsPage.verfiyChildDocDetailsPage(tabsName.get(0), documentType.get(0), status.get(0), fileName);
//		String childDocumentID = documentsPage.receivedDocumentId();
//
//		Logger("STEP 11:Validate a new child document with new record ID gets created in 'Received Document' related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
//		documentsPage.navigateToparentRecord();
//		documentsPage.verifyChildRecord(tabsName.get(1), childDocFileName);
//		documentsPage.compareDocumentIDs(parentDocumentID, childDocumentID);
//		documentsPage.verfiyParentDocDetailsPage(tabsName.get(0), status.get(2));
//		documentsPage.navigateToChildRecord();

		Logger("STEP 12: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		patientSearch.verifyCareProgProductError();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		// Patient Search Page
		Logger("STEP 13: Verify Patient Search Page details and click on Next Button");
		patientSearch.verifyPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.verifyBackToClassify();
		patientSearch.verifyPatientSearchButton();
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 14:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 15:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 16:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();


		// Diagnosis information-Page
		Logger("STEP 17:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		// Prescription Informaiton-Page
		Logger("STEP 18:Verify Patient Prescription Inforamtion Page details and click on Next Button");

		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 19:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		// Accounts Validation
		Logger("STEP 22:Verify if the 'Account--> Patient' record is visible");
		accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);

		Logger("STEP 23:Log out from application");
		documentsPage.logout();
	}

	@Test(description = "TC10 -To validate error message when a Recipient’s email is not found during Correspondence", enabled = true)
	public void DM10_IC7377_Validate_ErrorMessage_When_Recipients_Email_NotFound_DuringCorrespondence()
			throws Exception {

		int numberOfUsers = 3;
		String TestCaseNumber = "TC10";
		if (Utility_Function.checkURLinFile()) {
			CPEURL = Utility_Function.readURL();
			TestCaseNumber = "TC1";
		} else {
			CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);
		}

		Map<String, String> ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		SoftAssert softassert = new SoftAssert();

		for (int i = 0; i < numberOfUsers; i++) {
			try {

				switch (i) {
				case 0:
					Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
					homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
					break;
				case 1:
					Logger("STEP 1: Login to the QA_SIT Org as 'BV User'.");
					homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
					break;
				case 2:
					Logger("STEP 1: Login to the QA_SIT Org as 'System Admin User'.");
					homeportalPage = loginPage.userLogin(SAUserName, UserPassword);
					break;
				}

				Logger("STEP 2: Navigate to the Care program Enrollees object");
				navigateToUrl(CPEURL);
				Thread.sleep(4000);

				Logger("STEP 5: Clear the fax field of the patient and click on Save");
				Logger("STEP 5: Go to the Patient Account and fill the email field of the patient and click on Save");
				docMgmt.navigateToAccount();
				docMgmt.clearEmail();
				docMgmt.editPhone();
				missingInformatioPage.clickOnSaveButton();
				String name = ExcelTestData.get(patientName);
				String firstName = name.split(" ")[0];
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

				Logger("STEP 6: Click on the Correspondence button");
				docMgmt.clickOnCorrespondenceBotton();

				Logger("STEP 7: Select the Process Name as 'Welcome Correspondence' and Select items to Send as 'DMW Checkbox Welcome' and Click on Next");
				docMgmt.selectProcessName(processName.get(0));
				docMgmt.selectItemsToSend(itemsToSend.get(7));
				missingInformatioPage.clickNextButton();

				Logger("STEP 8: Validate that the system shows an error message \"The correspondence cannot be generated because the email information is either missing or incomplete.\" and user should not be able to send the correspondence");
				docMgmt.validateErrorMessage(welcomeCorrespondenceErrorMSG);

				Logger("STEP 9: Click on Finish button and navigate back to the CPE record ");
				docMgmt.clickonFinishButton();
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

				Logger("STEP 10: Go to the Patient Account and fill the email field of the patient and click on Save");
				docMgmt.navigateToAccount();
				docMgmt.editEmail(firstName);
				missingInformatioPage.clickOnSaveButton();
				refresh();
				Thread.sleep(5000);

				Logger("STEP 11: Navigate back to the CPE record and Click on Correspondence button →Select the Process Name as \"Welcome Correspondence\" and Select items to Send as \"DMW Checkbox welcome\" and Click on Next");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();
				docMgmt.clickOnCorrespondenceBotton();
				docMgmt.selectProcessName(processName.get(0));
				docMgmt.selectItemsToSend(itemsToSend.get(0));
				missingInformatioPage.clickNextButton();

				Logger("STEP 12: Validate user sees the confirmation message and the correspondence record is generated successfully");
				String successMessage = docMgmt.validateSuccessMessage();

				if (successMessage.contains(welcomeCorrespondenceSuccessMSG)) {
					Logger("Success message verified.");
				} else {
					softassert.fail(); // Soft assertion failure
					throw new Exception("Success message not found.");
				}
				Logger("STEP : Click on Finish button");
				docMgmt.clickonFinishButton();

				Logger("STEP 13: Navigate back to the CPE record and Go to the related list → Go to Correspondence and Open the Recently created correspondence record");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();
				accountObject.clickOnTab(tabsName.get(1));
				docMgmt.navigateToCorrespondenceTable();
				careProgram.clickOnViewAll("Correspondences");
				docMgmt.verifyCorrespondenceRecord(processName.get(0));
				docMgmt.clickOnCorrespondenceRecord(processName.get(0));

				Logger("STEP 14: Validate that the response message is getting populated on the message field of Correspondence record");
				docMgmt.verifyMessageIsPopulated();

				Logger("STEP 15: Log out from application");
				documentsPage.logout();

			} catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				// Log out and continue with the next user
				documentsPage.logout();
			}
		}

		softassert.assertAll();
	}

	@Test(description = "SAT - TC01: Validate the Auto match is Found patient based on info entered via portal and link document to patient/CPE", enabled = true)
	public void DM011_IC6153_Validate_the_Auto_match_is_Found_patient_based_on_info_entered_via_portal_and_link_document_to_patientCPE()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC11";

		Logger("Pre-requisite: Generate enrollment form");
		excelDataUpdate.selectExcelSheet(functionality);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);

		Logger("STEP 1: Login to the QA_SIT Org as 'DIS user'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
		String[] cpeDetails = { PatientName, PatientDoB, PatientEmail };
		Thread.sleep(2000);

		Logger("STEP 2: Launch the dupixent My way Portal URL for QA/Val org'.");
		navigateToUrl(DupixentMyWayPortalURL);

		Logger("STEP 3: Once URL is launched, from the welcome a Pop up is displayed Click on \"I am a Patient or Caregiver\" button.");
		dupixentPortal.clickOnAcceptAllCookies();
		dupixentPortal.clickOnPatientorCaregiverButton();

		Logger("STEP 4: Click the \"Upload Document\" button in the home page.");
		dupixentPortal.clickOnUploadDocButton();

		Logger("STEP 5: In the next page Enter Enrollment code and submit it.");
		dupixentPortal.enterAccessCode("8443879370");
		dupixentPortal.clickOnSubmitCodeButton();

		Logger("STEP 6: Enter the details Patient Information section and submit enrollment Form");
		dupixentPortal.enterPatientInfo(cpeDetails);
		dupixentPortal.clickOnSubmitDocCheckBox();
		dupixentPortal.clickOnConsentCheckBoxes();
		dupixentPortal.clickOnUploadFileButton();
		documentsPage.uploadDocument(filePath);
		dupixentPortal.clickOnSubmitButton();
		String documentID = dupixentPortal.getDocumentID();

		Logger("STEP 7: After Submitting the Documents from the Unauthenticated Portal, Now Log in org As DIS1 User");
		navigateToUrl(URL);
		boolean homepage = dupixentPortal.verifyLoginScreen();
		if (homepage) {
			homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
		}
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

		Logger("STEP 8: Navigate To Received Documents Object >> Open the Uploaded Documents from Portal");
		documentsPage.verifyRecentlyViewDocumentList();
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		docMgmt.navigateToListofCPE("All Received Documents");
		documentsPage.openDocumentFromAllRecivedDocList(documentID);
		fileName = documentsPage.getFileName(filePath);
		documentsPage.verifyRecordAndClick(fileName);

		Logger("STEP 9: Validate from Unauthenticated Portal Fields values are set on the Received Document record for any documents uploaded or submitted via the Unauthenticated Portal");
		accountObject.clickOnTab(tabsName.get(0));
		docMgmt.validateDocumentDetails(documentID);

		Logger("STEP 10: Logout from application");
		documentsPage.logout();

		Logger("STEP 11: Login into PC1 user >> Open the same record in PC1 user ");
		homeportalPage = loginPage.userLogin(PCUserName, UserPassword);
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 12: Validate document is assigned to PSQA review queue");
		documentsPage.navigatetoPSQAReviewWorklistView();
		documentsPage.searchDocument(fileName);
		documentsPage.verifyRecordAndClick(fileName);

		Logger("STEP 13: Go to Details Tab >> Validate the Case manager is assigned to that record.");
		docMgmt.verifyCaseManagerDetails(CMName);

		Logger("STEP 14: Logout from application");
		documentsPage.logout();

		Logger("STEP 15: Log in org As CM1 User");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		navigateToUrl(existingCPEURL);

		Logger("STEP 17: Go to Related Tab >>In Related tab Navigate to Received Documents Section >>Open Newly Linked Received Documents from Portal ");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToReceivedDocTable();
		careProgram.clickOnViewAll("Received Documents");

		Logger("STEP 18: Validate the New Received Document is Linked to the Existing CPE");
		docMgmt.verifyReceivedDocIDLinkedToCPE(fileName);
		documentsPage.logout();

	}

	@Test(description = "To validate error message when a Recipient’s mailing address is not found during Correspondence", enabled = true)
	public void DM12_IC7358_To_validate_the_error_handling_message_on_Email_Correspondences() throws Exception {

		int numberOfUsers = 3;
		String TestCaseNumber = "TC12";
		if (Utility_Function.checkURLinFile()) {
			CPEURL = Utility_Function.readURL();
			TestCaseNumber = "TC1";
		} else {
			CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);
		}

		Map<String, String> ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		SoftAssert softassert = new SoftAssert();

		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
				case 0:
					Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
					homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
					break;
				case 1:
					Logger("STEP 1: Login to the QA_SIT Org as 'BV User'.");
					homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
					break;
				case 2:
					Logger("STEP 1: Login to the QA_SIT Org as 'System Admin User'.");
					homeportalPage = loginPage.userLogin(SAUserName, UserPassword);
					break;
				}

				Logger("STEP 2: Navigate to the Care program Enrollees object");
				navigateToUrl(CPEURL);
				Thread.sleep(4000);

				Logger("STEP 19.2: Go to the Patient Account and fill the email field of the patient and click on Save");
				docMgmt.navigateToAccount();
				docMgmt.clearMailingAddress();
				missingInformatioPage.clickOnSaveButton();
				String name = ExcelTestData.get(patientName);
				// missingInformatioPage.navigateToCPERecord(name);
				// missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
//				String url = "https://icarecrm--uat.sandbox.lightning.force.com/lightning/r/Account/001O400000nNhmPIAS/view?ws=%2Flightning%2Fr%2FCareProgramEnrollee%2F0WwO400000035WDKAY%2Fview";
//				navigateToUrl(url);

//				String name = ExcelTestData.get(patientName);
				// missingInformatioPage.closeAccChildObj();
				missingInformatioPage.navigateToCPERecord(name);

				Logger("STEP 17: Click on the Correspondence button");
				docMgmt.clickOnCorrespondenceBotton();

				Logger("STEP 18.1: Select the Process Name as 'BV' and Select items to Send as 'DMW Summary of Benefits-PT Letter' and Click on Next");
				docMgmt.selectProcessName(processName.get(8));
				docMgmt.selectItemsToSend(itemsToSend.get(10));
				missingInformatioPage.clickNextButton();

				Logger("STEP 18.2: Validate that the system shows an error message \"The correspondence cannot be generated because the email information is either missing or incomplete.\" and user should not be able to send the correspondence");
				docMgmt.validateErrorMessage(summaryofBenefitPTLetterErrorMSG);

				Logger("STEP 19.1: Click on Finish button and navigate back to the CPE record ");
				docMgmt.clickonFinishButton();
				missingInformatioPage.navigateToCPERecord(name);

				Logger("STEP 19.2: Go to the Patient Account and fill the email field of the patient and click on Save");
				docMgmt.navigateToAccount();
				docMgmt.editMailingAddress(ExcelTestData.get(patientEmail),ExcelTestData.get(patientAddress), ExcelTestData.get(city),
						ExcelTestData.get(state), ExcelTestData.get(zip));
				missingInformatioPage.clickOnSaveButton();
				refresh();
				Thread.sleep(5000);

				Logger("STEP 20.1: Navigate back to the CPE record and Click on Correspondence button →Select the Process Name as \"Welcome Correspondence\" and Select items to Send as \"DMW Checkbox welcome\" and Click on Next");
				missingInformatioPage.navigateToCPERecord(name);
				refresh();
				docMgmt.clickOnCorrespondenceBotton();
				docMgmt.selectProcessName(processName.get(8));
				docMgmt.selectItemsToSend(itemsToSend.get(10));
				missingInformatioPage.clickNextButton();

				Logger("STEP 20.2: Validate user sees the confirmation message and the correspondence record is generated successfully");
				String successMessage = docMgmt.validateSuccessMessage();

				if (successMessage.contains(summaryofBenefitPTLetterSuccessMSG)) {
					Logger("Success message verified.");
				} else {
					Logger("Success message not found.");
					softassert.fail(); // Soft assertion failure
					throw new Exception("Success message not found.");
				}
				Logger("Success message verified.");
				docMgmt.clickonFinishButton();

				Logger("STEP 22: Log out from application");
				documentsPage.logout();

			} catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				documentsPage.logout();
			}
		}

		softassert.assertAll();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7380 TC03-To validate error message when a Recipient’s Fax
	 * is not found during Correspondence
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "TC03-To validate the error handling message  on Fax Correspondences", enabled = true)
	public void DM13_IC7380_Validate_Error_Message_when_Recipients_Fax_is_not_found_during_Correspondence()
			throws Exception {

		int numberOfUsers = 3;
		String TestCaseNumber = "TC13";
		if (Utility_Function.checkURLinFile()) {
			CPEURL = Utility_Function.readURL();
			TestCaseNumber = "TC1";
		} else {
			CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);
			// CPEURL =
			// "https://icarecrm--uat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0WwO400000035WDKAY/view";
		}

		Map<String, String> ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		SoftAssert softassert = new SoftAssert();

		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
				case 0:
					Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
					homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
					break;
				case 1:
					Logger("STEP 1: Login to the QA_SIT Org as 'BV User'.");
					homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
					break;
				case 2:
					Logger("STEP 1: Login to the QA_SIT Org as 'System Admin User'.");
					homeportalPage = loginPage.userLogin(SAUserName, UserPassword);
					break;
				}

				Logger("STEP 2: Navigate to the Care program Enrollees object");
				navigateToUrl(CPEURL);
				Thread.sleep(2000);

				Logger("STEP 5: Clear the fax field of the patient and click on Save");
				docMgmt.verifyToclearFax();
				missingInformatioPage.clickOnSaveButton();
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

				Logger("STEP 6: Change member plan to active");
				docMgmt.navigateToAccount();
				accountObject.clickOnTab(tabsName.get(1));
				docMgmt.verifyPrimaryRecordMemberPlansSection();
				docMgmt.changeMemberPlanStatusActive(pharamcyMember.get(4));

				Logger("STEP 6: Click on the Correspondence button");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				docMgmt.clickOnCorrespondenceBotton();

				Logger("STEP 7: Select the Process Name as 'Welcome Correspondence' and Select items to Send as 'DMW Checkbox Welcome' and Click on Next");
				docMgmt.selectProcessName(selectProcessName.get(0));
				docMgmt.selectItemsToSend(itemToSend.get(0));
				missingInformatioPage.clickNextButton();

				Logger("STEP 8: Validate error message for missing fax information");
				docMgmt.verifyErrorMessage();

				Logger("STEP 9: Click on Finish button and navigate back to the CPE record ");
				docMgmt.clickonFinishButton();
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

				Logger("STEP 10: Go to the Patient Account, fill the fax field, and click Save");
				docMgmt.editFax(ExcelTestData.get(pharmacyfax));
				missingInformatioPage.clickOnSaveButton();
				refresh();
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

				Logger("STEP 11: Click on the Correspondence button");
				docMgmt.clickOnCorrespondenceBotton();

				Logger("STEP 12: Verify Process Name and Item To Send");
				docMgmt.selectProcessNameAndItemToSend(selectProcessName.get(0), itemToSend.get(0));
				missingInformatioPage.clickNextButton();

				Logger("STEP 13: Verify Generate Document Correspondence Screen opens and user can send the Correspondence");
				docMgmt.verifyGenerateDocumentScreen();
				docMgmt.clickSendButtonUntilFinish();

				Logger("STEP 14: Validate success message is populated in the Correspondence record");
				String msg = docMgmt.validateSuccessMessage();
				if (msg.contains(summaryofBenefitMDFAXSuccessMSG)) {
					Logger("Success message verified.");
				} else {
					Logger("Success message not found.");
					softassert.fail(); // Soft assertion failure
					throw new Exception("Success message not found.");
				}

				docMgmt.clickonFinishButton();

				Logger("STEP 15: Log out from application");
				documentsPage.logout();

			} catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				documentsPage.logout();
			}
		}

		softassert.assertAll();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-10415 - Regression-DocMgmt: Automate the COVERAGE
	 * PROFILE REPORT for Summary of Benefits - MD Fax correspondence with primary
	 * insurance details
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "TC01: Validate the COVERAGE PROFILE REPORT for Summary of Benefits - MD Fax correspondence with primary insurance details", enabled = true)
	public void DM14_IC8053_Validate_the_COVERAGE_PROFILE_REPORT_for_Summary_of_Benefits_MD_Fax_correspondence_with_primary_insurance_details()
			throws Exception {

		String TestCaseNumber = "TC14";
		if (Utility_Function.checkURLinFile()) {
			CPEURL = Utility_Function.readURL();
			TestCaseNumber = "TC1";
		} else {
			CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);
		}

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 2: Open a CPE record which is tagged to a patient that has only primary record of Member plan");
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.verifyPrimaryRecordMemberPlansSection();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		Thread.sleep(4000);

		Logger("STEP 3: Click on the correspondence Button present on the Top right corner of CPE Record.");
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 4: Fill Process name and select items to send information");
		docMgmt.selectProcessName(processName.get(2));
		docMgmt.selectItemsToSend(itemToSend.get(2));
		missingInformatioPage.clickNextButton();
		missingInformatioPage.clickNextButton();

		Logger("STEP 5: Wait for few seconds on the Generate Document(s) Screen to load the DMW Summary of Benefits - MD Fax  → Match the field mapping → Click on Send");
		docMgmt.clickSendButtonUntilFinish();

		Logger("STEP 6: Click on Finish button on confirmation page");
		docMgmt.clickonFinishButton();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 7: Validate PDF Files present in Related List of Correspondence ");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecord(itemToSend.get(2));
		String pdfName = itemToSend.get(2).trim();
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.deleteExistingFile(downloadPath);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);

		// Data validation
		String payerNumber = Utility_Function.formatNumber(ExcelTestData.get(rxPhone));

		Map<String, Integer> fieldsToValidate = new HashMap<>();
		// Medical
		fieldsToValidate.put("Primary Payer: " + ExcelTestData.get(medicalPayerName), 3);
		fieldsToValidate.put("Plan Name: " + ExcelTestData.get(medicalPayerName), 3);
		fieldsToValidate.put("Policy Number: " + ExcelTestData.get(medicalPolicyID), 3);
		fieldsToValidate.put("Group Number: " + ExcelTestData.get(medicalGroup), 3);

		// Pharmacy
		// fieldsToValidate.put("PBM Name: " + ExcelTestData.get(rxPayerName), 3);
		fieldsToValidate.put("PBM Phone: " + payerNumber, 3);
		fieldsToValidate.put("PBM Policy Number: " + ExcelTestData.get(rxPolicyID), 3);
		fieldsToValidate.put("PBM Group Number: " + ExcelTestData.get(rxGroup), 3);

		Logger("STEP 8: Validate the COVERAGE PROFILE REPORT will only show the primary Insurance details");
		docMgmt.validateMultiplePDFFields(downloadPath, fieldsToValidate);

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE_8042 - Regression-DocMgmt: Automate Case Manager (CM) user
	 * views the Case Manager Home Page for the My Failed Correspondence Report
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "TC01: Case Manager (CM) user views the Case Manager Home Page for the My Failed Correspondence Report")
	public void DM15_IC8042_CaseManager_user_views_Case_Manager_Home_Page_for_the_My_Failed_Correspondence_Report()
			throws Exception {

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Navigate to the 'Home' object");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(4), DocumentPage.class);

		Logger("STEP 3: Validate the My Failed Correspondence Report.");
		docMgmt.verifyDashboardTitle();
		docMgmt.verifyFailedCorrespondenceReport();

		Logger("STEP 4: Validate the columns of the Report.");
		docMgmt.validateColumns();

		Logger("STEP 5: Select a Correspondence Record from the Report..");
		docMgmt.clickOnCorrespondenceRecord();

		Logger("STEP 6: Validate the values of the Correspondence record.");
		docMgmt.validateValuesOfCorrespondence();

		Logger("STEP 7: Log out from application");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-8055-(PA) Validate the COVERAGE PROFILE REPORT for Summary
	 * of Benefits - MD Fax correspondence with primary and secondary insurance
	 * details
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Validate the COVERAGE PROFILE REPORT for Summary of Benefits - MD Fax correspondence with primary and secondary insurance details ", enabled = true)
	public void DM016_IC8055_Validate_the_COVERAGE_PROFILE_REPORT_for_Summary_of_Benefits_MD_Fax_correspondence_with_primary_and_secondary_insurance_details()
			throws Exception {

		String TestCaseNumber = "TC16";

		if (Utility_Function.checkURLinFile()) {
			CPEURL = Utility_Function.readURL();
			TestCaseNumber = "TC1";
		} else {
			CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);
		}

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("STEP 1: Login as a Case Manager.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Open a CPE record which is tagged to a patient that has  primary and secondary record of Member plan, Prescriber & Site information (Patient Account>Member Plan)");
		// Navigate to CPE URL
		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 6: Change member plan to active");
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.verifyPrimaryRecordMemberPlansSection();
		docMgmt.changeMemberPlanStatusActive(pharamcyMember.get(4));

		Logger("STEP 2: Click on the correspondence Button present on the Top right corner of CPE Record.");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 3: Select Items to send Section is displayed with two fields: select the values1. Process Name as PA2. Select Items to send as DMW Summary of Benefits - MD Fax");
		docMgmt.selectProcessName(processName.get(2));
		docMgmt.selectItemsToSend(itemToSend.get(2));
		missingInformatioPage.clickNextButton();

		Logger("STEP 4: Generate Document(s) section should be displayed with the document processing");
		docMgmt.clickSendButtonUntilFinish();

		Logger("STEP 5: Click on Finish button on confirmation page");
		docMgmt.clickonFinishButton();

		Logger("STEP 6: Navigate to Related List of CPE record → Validate correspondence record → Validate Files record");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

//		String urlC = "https://icarecrm--uat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0WwO40000003aerKAA/view";
//		navigateToUrl(urlC);

		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();
		careProgram.clickOnViewAll("Correspondences");
		docMgmt.verifyCorrespondenceRecord(processName.get(2));
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 7: Validate PDF Files present in Related List of Correspondence ");
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecord(itemToSend.get(2));
		String pdfName = itemToSend.get(2).trim();
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.deleteExistingFile(downloadPath);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);

		// Data validation
		String payerNumber = Utility_Function.formatNumber(ExcelTestData.get(rxPhone));

		Map<String, Integer> fieldsToValidate = new HashMap<>();
		// Medical
		fieldsToValidate.put("Primary Payer: " + ExcelTestData.get(medicalPayerName), 3);
		fieldsToValidate.put("Plan Name: " + ExcelTestData.get(medicalPayerName), 3);
		fieldsToValidate.put("Policy Number: " + ExcelTestData.get(medicalPolicyID), 3);
		fieldsToValidate.put("Group Number: " + ExcelTestData.get(medicalGroup), 3);

		// Pharmacy
		// fieldsToValidate.put("PBM Name: " + ExcelTestData.get(rxPayerName), 3);
		fieldsToValidate.put("PBM Phone: " + payerNumber, 3);
		fieldsToValidate.put("PBM Policy Number: " + ExcelTestData.get(rxPolicyID), 3);
		fieldsToValidate.put("PBM Group Number: " + ExcelTestData.get(rxGroup), 3);

		Logger("STEP 8: Validate the \"COVERAGE PROFILE REPORT\" will  show the primary and secondary Insurance {Pharmacy & Medical} details");
		docMgmt.validateMultiplePDFField(downloadPath, fieldsToValidate);

	}

	/**
	 * ============================================================================================================================
	 * Test Case Id:ICARE_5508 - TC01- Case Manager sends fullfillment request to
	 * Patient.
	 * 
	 * @author Anand Pawar
	 * 
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "TC01: Case Manager sends fullfillment request to Patient")
	public void DM17_IC5508_Case_Manager_sends_fullfillment_request_to_Patient() throws Exception {

		String TestCaseNumber = "TC17";
		if (Utility_Function.checkURLinFile()) {
			CPEURL = Utility_Function.readURL();
			TestCaseNumber = "TC1";
		} else {
			CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);
		}

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 5: Click on Start New Service Button");
		iapPage.clickOnStartNewService();
		iapPage.verifyServiceTitle();

		Logger("STEP 6: Select Service = ‘Fullfillment', Reason = ‘Patient requested’ and click on ‘Next’");
		docMgmt.selectService();
		missingInformatioPage.clickNextButton();
		docMgmt.selectReason();
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 7:  Select 'Sharps Kit’ from dropdown and click 'Next’");
		docMgmt.itemsToSend();
		missingInformatioPage.clickNextButton();

		Logger("STEP 8: Validate the request is sent and confirmation message is displayed ");
		docMgmt.validateConfirmationMessage();

		Logger("STEP 27: Click on finish button");
		docMgmt.clickonFinishButton();

		Logger("STEP 28: Navigate back to the CPE record and Go to the related list → Go to Correspondence and Open the Recently created correspondence record");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();
		careProgram.clickOnViewAll("Correspondences");
		docMgmt.verifyCorrespondenceRecord(processName.get(4));
		docMgmt.clickOnCorrespondenceRecord(processName.get(4));

		Logger("STEP 29: User Logout the Application.");
		documentsPage.logout();

	}

	@Test(description = "Sharps request sent to Merkle by Case Manager on receiving the Patient's request", enabled = true)
	public void DM018_IC5507_VSharps_request_sent_to_Merkle_by_Case_Manager_on_receiving_the_Patients_request()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC18";
		if (Utility_Function.checkURLinFile()) {
			CPEURL = Utility_Function.readURL();
			TestCaseNumber = "TC1";
		} else {
			CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);
		}

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 5: Click on Start New Service Button");
		iapPage.clickOnStartNewService();
		iapPage.verifyServiceTitle();

		Logger("STEP 6: Select Service = ‘Fullfillment', Reason = ‘Patient requested’ and click on ‘Next’");
		docMgmt.selectService();
		missingInformatioPage.clickNextButton();
		docMgmt.selectReason();
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 7:  Select 'Sharps Kit’ from dropdown and click 'Next’");
		docMgmt.itemsToSend();
		missingInformatioPage.clickNextButton();

		Logger("STEP 8: Validate the request is sent and confirmation message is displayed ");
		docMgmt.validateConfirmationMessage();

		Logger("STEP 9:Log out from application");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-10419 Regression-DocMgmt: Automate a new document is
	 * received for a Patient with multiple CPEs
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE-10419- Regression-DocMgmt: Automate a new document is received for a Patient with multiple CPEs'", enabled = true)
	public void DM19_IC7213_Verify_A_New_Document_is_received_for_a_Patient_with_multiple_CPEs() throws Exception {

		Logger("Pre-Requisite : Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC19";
		// String ExistingCPEFaxNumber = "3985147562";
		// String ExistingCPERecordName = "AutomationClaire Lucy";

		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L28.1 - Prurigo nodularis" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_TestCase04);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 1: Get patient record");
		accountObject.navigateToAccount();
		accountObject.searchRecord("Automation");
		accountObject.searchRecordAndOpen();
		String accountDetails[] = accountObject.getCPEDetails();

		// Patient name
		String[] existingPname = updatepdf.splitFullName(accountDetails[0]);
		String patientFName = existingPname[0];
		String patientLName = existingPname[2];

		String dob = Utility_Function.changeFormatDateMMddYYYY(accountDetails[1]);
		String email = accountDetails[2];
		String patientPhone = Utility_Function.formatNumber(accountDetails[3]);
		String pin = accountDetails[4];

		Logger("STEP 2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 2.1: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 4:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 3 and 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 5.1:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		String receivedDocumentName =documentsPage.getFormName();

		Logger("STEP 5.2: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Step 6: Validate if fields are fetched from OCR correctly");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(1),
				ExcelTestData.get(patientDOB));

		Logger("Step 7 and 8: Click 'Search Patient' and Select Patient");
		patientSearch.searchExistingPatient(patientFName, patientLName, dob, patientPhone, email, pin);
//		
//		///
//		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.searchAndSelectHCP(ExcelTestData.get(prescriberName));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.searchAndSelectHCO(ExcelTestData.get(sitefacilityname));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.enterEosCountAndPatientDepenedent(eosCount.get(0), patientDepedent.get(0));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();

		Logger("Step 9: Open CPE record that matches the Fax Number");
		accountObject.clickOnTab(tabsName.get(1));
//		accountObject.navigateToAccountRecord(ExistingCPERecordName);
//		accountObject.clickOnTab(tabsName.get(1));
//		String facilityName = docMgmt.getPatientDetailsFromCPEPage("Facility Fax");
//
//		if (facilityName.contains(ExistingCPEFaxNumber)) {
//			Log.info("CPE record that matches Fax Number is opened.");
//		}

		Logger("Step 10: Navigate to the Related tab and validate the Received Document list.");
		patientSearch.verifyReceivedDocumentInRelatedTab(receivedDocumentName);
		documentsPage.logout();
	}


	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate IC13491 Regression-FAX: Automate the COVERAGE PROFILE
	 * REPORT for Summary of Benefits - MD Fax correspondence with primary insurance
	 * details
	 * 
	 * @author Sonica P
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "IC13491 Regression-FAX: Automate the COVERAGE PROFILE REPORT for Summary of Benefits - MD Fax correspondence with primary insurance details", enabled = true)
	public void DM21_IC7813_Validate_the_COVERAGE_PROFILE_REPORT_for_Summary_of_Benefits_MD_Fax_correspondence_with_primary_insurance_details()
			throws Exception {

		String TestCaseNumber = "TC21";
		if (Utility_Function.checkURLinFile()) {
			CPEURL = Utility_Function.readURL();
			TestCaseNumber = "TC1";
		} else {
			CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);
		}

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 2: Open a CPE record which is tagged to a patient that has only primary record of Member plan");
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.verifyPrimaryRecordMemberPlansSection();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		Thread.sleep(4000);

		Logger("STEP 3: Click on the correspondence Button present on the Top right corner of CPE Record.");
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 4: Fill Process name and select items to send information");
		docMgmt.selectProcessName(selectProcessName.get(0));
		docMgmt.selectItemsToSend(bvitemsToSend.get(2));
		missingInformatioPage.clickNextButton();

		Logger("STEP 5: Wait for few seconds on the Generate Document(s) Screen to load the DMW Summary of Benefits - MD Fax  → Match the field mapping → Click on Send");
		docMgmt.clickSendButtonUntilFinish();

		Logger("STEP 6: Click on Finish button on confirmation page");
		docMgmt.clickonFinishButton();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 7: Validate PDF Files present in Related List of Correspondence ");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecord(bvitemsToSend.get(2));
		String pdfName = bvitemsToSend.get(2).trim();
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.deleteExistingFile(downloadPath);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);

		// Data validation
		String payerNumber = Utility_Function.formatNumber(ExcelTestData.get(rxPhone));

		Map<String, Integer> fieldsToValidate = new HashMap<>();
		// Medical
		fieldsToValidate.put("Primary Payer: " + ExcelTestData.get(medicalPayerName), 3);
		fieldsToValidate.put("Plan Name: " + ExcelTestData.get(medicalPayerName), 3);
		fieldsToValidate.put("Policy Number: " + ExcelTestData.get(medicalPolicyID), 3);
		fieldsToValidate.put("Group Number: " + ExcelTestData.get(medicalGroup), 3);

		// Pharmacy
		fieldsToValidate.put("PBM Name: " + ExcelTestData.get(rxPayerName), 3);
		fieldsToValidate.put("PBM Phone: " + payerNumber, 3);
		fieldsToValidate.put("PBM Policy Number: " + ExcelTestData.get(rxPolicyID), 3);
		fieldsToValidate.put("PBM Group Number: " + ExcelTestData.get(rxGroup), 3);

		Logger("STEP 8: Validate the COVERAGE PROFILE REPORT will only show the primary Insurance details");
		docMgmt.validateMultiplePDFFields(downloadPath, fieldsToValidate);

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-12077 - To validate Initial Free Goods Shipment
	 * Confirmation - HCP Fax correspondence generation with the new template
	 * updates
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "TC04: To validate Initial Free Goods Shipment Confirmation - HCP Fax correspondence generation with the new template updates", enabled = true)
	public void DM22_IC12077_To_validate_Initial_Free_Goods_Shipment_Confirmation_HCP_Fax_correspondence_generation_with_the_new_template_updates()
			throws Exception {

		String TestCaseNumber = "TC22";

		CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		// BV Initiation

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
//
		Logger("Pre-requisites 1.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 1.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 1.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String acctname = ExcelTestData.get(patientName);
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(acctname);
		assessmentTasksPage.openCPETask(createdDate);
		Utility_Function.switchToWindow(acctname);

//		String cpeurl = "https://icarecrm--uat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0WwO40000003aRxKAI/view";
//		navigateToUrl(cpeurl);
//		Thread.sleep(2000);

		Logger("Pre-requisites 1.4: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("Pre-requisites 1.5: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre-requisites 1.6: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 1.7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		// BV Summary
		Logger("Pre-requisites 1.8: Complete BV summary task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(1));
		careProgram.clickOnSubTask(bvSubTaskNames.get(1));

		Logger("Pre-requisites 1.9: Select Outcome and Outcome Reason");
		bvPage.enterDetailsOnBVOutcome(outComeOptions.get(4), outComeReasonOptions.get(2));
		careProgram.clickOnSave();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 1.10: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 2: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 3: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask("Pre-Check");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(2), "0", "Private Commercial", "", "Yes", ""));
		papPage.verifyPatientInformationDetails(expectedValues);

		Logger("STEP 4: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 5: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(1));
		papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();

		Logger("STEP 6: On \"Research\" Sub Task >> Validate Below Mentioned Fields are Filled -Alternate Coverage Identified? and  ");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Alternate Coverage");
		papPage.clickOnTask("Research");
		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 7: Open \"Communicate Results\" Sub Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Alternate Coverage");
		papPage.clickOnTask("Communicate Results");

		Logger("STEP 8: Enter information in \"Communicate Results\" Sub Task");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(7));
		ArrayList<String> communicateResultsValues = new ArrayList<>(
				Arrays.asList(StatusCheck.get(1), contactMade.get(0), attempts.get(0), attemptOutcome.get(1)));
		papPage.enterCommunicateResultsDetails(communicateResultsValues, attemptOutcome.get(1), attemptOutcome.get(0));
		papPage.verifyAttemptDateIsNotNull();
		quickStartPage.clickOnSubmitButton();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Alternate Coverage");
		papPage.clickOnTask("Capture Coverage Outcome");

		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(8));
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 11: Click on the correspondence Button present on the Top right corner of CPE Record.");
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 12: Fill Process name and select items to send information");
		docMgmt.selectProcessName(selectProcessName.get(2));
		docMgmt.selectItemsToSend(itemToSend.get(4));
		missingInformatioPage.clickNextButton();

		Logger("STEP 13: Wait for few seconds on the Generate Document(s) Screen to load the DMW Summary of Benefits - MD Fax  → Match the field mapping → Click on Send");
		docMgmt.clickSendButtonUntilFinish();

		Logger("STEP 14: Click on Finish button on confirmation page");
		docMgmt.clickonFinishButton();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 15: Validate PDF Files present in Related List of Correspondence ");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecord(itemToSend.get(2));
		String pdfName = itemToSend.get(2).trim();
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.deleteExistingFile(downloadPath);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);

		Logger("STEP 16: Validate that the document generated is according to the updated template attached and fields are mapped correctly in the document ");

		Map<String, Integer> fieldsToValidate = new HashMap<>();
		// Medical
		String updatedPara = textToValidate.get(0);
		String dupCode = textToValidate.get(1);
		fieldsToValidate.put(updatedPara, 2);
		fieldsToValidate.put(dupCode, 2);

		docMgmt.validateMultiplePDFFields(downloadPath, fieldsToValidate);

		Logger("STEP 17: Navigate back to the CPE record → Click on the related tab and Go to the Correspondence list Validate that a new Correspondence record has been created ");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();

		Logger("STEP 18: Open the Record → Validate the new DUP Code US.DUP.24.12.0076is visible on the record → Click on the Related tab → Validate that the document is present on the files list ");
		docMgmt.clickOncorrespondence();
		docMgmt.verifyDUP(dupCode);
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecord(itemToSend.get(2));

		Logger("STEP 19: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-15664 Regression: Automate ICARE-11421: SIT: TC01: To
	 * Validate "Assign to Me" feature is reverted for all users except DIS.
	 * 
	 * @author Shanavaz Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE-11421: SIT: TC01: To Validate \"Assign to Me\" feature is reverted for all users except DIS.", enabled = true)
	public void DM23_IC12042_Validate_Assign_to_Me_feature_is_reverted_for_all_users_except_DIS() throws Exception {

		String searchDocName = "Enrollment Form";
		String ownerName = "Program Coordinator";

		Logger("STEP 1:Login to the UAT Org as 'Program Coordinator'.");
		homeportalPage = loginPage.userLogin(PCUserName, UserPassword);

		Logger("STEP 2:Navigate to Received Document object through app launcher and change the list view to \"PSQA Review Worklist\".");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		documentsPage.navigateToPQSAWorklist();

		Logger("STEP 3:Select one Received Document records from the worklist.");
		documentsPage.searchDocument(searchDocName);
		String docName = documentsPage.selectFirstRecordFromList();

		Logger("STEP 4:Click the \"Assign to Me\" button");
		documentsPage.clickOnAssignToMe();

		Logger("STEP 5:Validate that the Status field of the selected Received Document record is updated to \"In Review\"");
		documentsPage.verifyMyReceivedDocumentsList();
		documentsPage.searchDocument(docName);
		documentsPage.verifyDocStatusFromListView(docName, status.get(1));
		docMgmt.openFirstRecentRecord();

		Logger("STEP 6: Validate that the owner of the receive document record is changed to PC user.");
		documentsPage.validateOwnerName(ownerName);

		Logger("STEP 7: Logout the application as PC user.");
		documentsPage.logout();

	}

	/**
	 * *
	 * ==================================================================================
	 * 
	 * * @author Tejal * ICARE_15652_To validate DMW PAP Renewal - MD Fax
	 * correspondence generation with the new template updates
	 * =====================================================================================
	 * ==============================
	 * 
	 */

	@Test(description = "To validate DMW PAP Renewal - MD Fax correspondence generation with the new template updates", enabled = true)
	public void DM24_ICARE_15652_IC12190_To_validate_DMWPAPRenewal_MD_Fax_correspondence_generation_with_new_template_updates()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC24";
		if (Utility_Function.checkURLinFile()) {
			CPEURL = Utility_Function.readURL();
			TestCaseNumber = "TC1";
		} else {
			CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);
		}

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(CPEURL);
		Thread.sleep(2000);
		Logger("STEP 3 :PAP work order initialization.");
		papPage.clickOnStartNewService(); //
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason("PAP Appeal");
		Logger("STEP 4: Click on save and refresh the page");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		Logger("STEP 5: Open Capture Coverage Outcome sub task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(5));
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 6: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		careProgram.clickOnWorkOrderTask(workOrderName.get(5));
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1)); //
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();

		careProgram.clickOnWorkOrderTask(workOrderName.get(5));
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterOutcome(iapoutcome.get(0)); //
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 7: Click on the Correspondence button");
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 8: Select the Process Name as 'Welcome Correspondence' and Select items to Send as 'DMW Checkbox Welcome' and Click on Next");
		docMgmt.selectProcessName(processName.get(5));
		docMgmt.selectItemsToSend(itemsToSend.get(3));
		missingInformatioPage.clickNextButton();
		missingInformatioPage.clickNextButton();

		Logger("STEP 9: Verify Generate Document Correspondence Screen opens and user can send the Correspondence");
		docMgmt.verifyGenerateDocScreen(itemsToSend.get(3)); //
		docMgmt.clickSendButtonUntilFinish();

		Logger("STEP 10: Validate success message is populated in the Correspondence record");
		String msg = docMgmt.validateSuccessMessage();
		if (msg.contains(papRenewal)) { //
			Logger("Success message verified.");
		} else {
			Logger("Success message not found.");
			Assert.fail();
			throw new Exception("Success message not found.");
		}

		docMgmt.clickonFinishButton();

		Logger("STEP 11: Verify message in Correspondence Record");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();
		careProgram.clickViewAll("Correspondences");
		docMgmt.verifyCorrespondenceRecord(processName.get(5));
		docMgmt.clickOnCorrespondenceRecord(processName.get(5));
		docMgmt.DUPCodeIsPopulated(); //
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.verifyFilesRecord(itemsToSend.get(3));

		Logger("STEP 12: Log out from application");
		documentsPage.logout();

	}

	/**
	 * *
	 * ==================================================================================
	 * 
	 * * @author Tejal * ICARE_15660_To validate DMW PAP Approval Medicare Enrollee
	 * - MD Fax correspondence generation with the new template updates
	 * =====================================================================================
	 * ==============================
	 * 
	 */

	@Test(description = "To validate DMW PAP Approval Medicare Enrollee - MD Fax correspondence generation with the new template updates", enabled = true)
	public void DM25_IC15660_IC12070_To_validate_DMWPAPApproval_MedicareEnrolee_MD_Fax_correspondence_generation_with_new_template_updates()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC25";
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];
		if (Utility_Function.checkURLinFile()) {
			CPEURL = Utility_Function.readURL();
			TestCaseNumber = "TC1";
		} else {
			CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);
		}

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Thread.sleep(4000);

		Logger("STEP 2: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(CPEURL);
		Thread.sleep(2000);

		Logger("STEP 3 :PAP work order initialization.");
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason("PAP Appeal");

		Logger("STEP 4 : Click on save and refresh the page");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 5: Open Capture Coverage Outcome sub task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(5));
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 6: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		careProgram.clickOnWorkOrderTask(workOrderName.get(5));
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();

		careProgram.clickOnWorkOrderTask(workOrderName.get(5));
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();

		Logger("STEP 7: Click on the Correspondence button");
		missingInformatioPage.navigateToCPERecord(cpeName);
		refresh();
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 8: Select the Process Name as 'Welcome Correspondence' and Select items to Send as 'DMW Checkbox Welcome' and Click on Next");
		docMgmt.selectProcessName(processName.get(6));
		docMgmt.selectItemsToSend(itemsToSend.get(5));
		missingInformatioPage.clickNextButton();
		missingInformatioPage.clickNextButton();

		Logger("STEP 9: Verify Generate Document Correspondence Screen opens and user can send the Correspondence");
		docMgmt.verifyGenerateDocScreen(itemsToSend.get(5));
		docMgmt.clickSendButtonUntilFinish();

		Logger("STEP 10: Validate success message is populated in the Correspondence record");
		String msg = docMgmt.validateSuccessMessage();
		if (msg.contains(papApproval)) {
			Logger("Success message verified.");
		} else {
			Logger("Success message not found.");
			Assert.fail();
			throw new Exception("Success message not found.");
		}

		docMgmt.clickonFinishButton();
		Logger("STEP 11: Verify message in Correspondence Record");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();
		careProgram.clickViewAll("Correspondences");
		docMgmt.verifyCorrespondenceRecord(processName.get(6));
		docMgmt.clickOnCorrespondenceRecord(processName.get(6));
		docMgmt.DUPCodeIsPopulated();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.verifyFilesRecord(itemsToSend.get(5));

		Logger("STEP 12: Log out from application");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-12071 - To validate DMW PAP Discontinuation - MD
	 * Fax correspondence generation with the new template updates
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "TC03: To validate DMW PAP Discontinuation - MD Fax correspondence generation with the new template updates", enabled = true)
	public void DM26_IC12071_To_validate_DMW_PAP_Discontinuation_MD_Fax_correspondence_generation_with_the_new_template_updates()
			throws Exception {

		String TestCaseNumber = "TC26";

		CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 2: Validate PAP WO is initiated and Click on PAP WO");
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason("PAP Appeal");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		Logger("STEP 3: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(5));
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		
		Logger("STEP 4: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();

		careProgram.clickOnWorkOrderTask(workOrderName.get(5));
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(cpeName);

		Logger("STEP 5: Navigate to Quick start CPE Record");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String papCpep = "PAP - " + careProgramProduct.get(2).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(papCpep);

		Logger("STEP 6: Navigate to Quick start CPE Record");
		quickStartPage.editCPEPDetails(quickStartStatus.get(1), reason.get(3));
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 7: Click on the correspondence Button present on the Top right corner of CPE Record.");
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 8: Fill Process name and select items to send information");
		docMgmt.selectProcessName(selectProcessName.get(2));
		docMgmt.selectItemsToSend(itemToSend.get(3));
		missingInformatioPage.clickNextButton();

		Logger("STEP 9: Wait for few seconds on the Generate Document(s) Screen to load the DMW Summary of Benefits - MD Fax  → Match the field mapping → Click on Send");
		docMgmt.clickSendButtonUntilFinish();

		Logger("STEP 10: Click on Finish button on confirmation page");
		docMgmt.clickonFinishButton();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 11: Validate PDF Files present in Related List of Correspondence ");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecord(itemToSend.get(2));
		String pdfName = itemToSend.get(2).trim();
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.deleteExistingFile(downloadPath);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);

		Logger("STEP 12: Validate that the document generated is according to the updated template attached and fields are mapped correctly in the document ");

		Map<String, Integer> fieldsToValidate = new HashMap<>();
		// Medical
		String updatedPara = textToValidate.get(3);
		String dupCode = textToValidate.get(2);
		fieldsToValidate.put(updatedPara, 2);
		fieldsToValidate.put(dupCode, 2);

		docMgmt.validateMultiplePDFFields(downloadPath, fieldsToValidate);

		Logger("STEP 13: Navigate back to the CPE record → Click on the related tab and Go to the Correspondence list Validate that a new Correspondence record has been created ");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();

		Logger("STEP 14: Open the Record → Validate the new DUP Code US.DUP.24.11.0111 is visible on the record → Click on the Related tab → Validate that the document is present on the files list ");
		docMgmt.clickOncorrespondence();
		docMgmt.verifyDUP(dupCode);
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecord(itemToSend.get(2));

		Logger("STEP 15: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * *
	 * ==================================================================================
	 * 
	 * * @author Tejal * ICARE_15665_To Validate Correspondence Resend button is
	 * hidden if Request status = Success or blank.
	 * =====================================================================================
	 * ==============================
	 * 
	 */

	@Test(description = "SIT_Document Management Workflow Patient Enrollment Prerequisites", enabled = true)
	public String PatientEnrollment_Prerequisites(String testcaseNumber) throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "FALSE" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.1: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.2: Once the Document is opened, Click on refresh until the OCR status is updated to Success.");

		Logger("STEP 4: On Classify document page select Doc type = Enrollment Form > Click on submit.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(2));

		Logger("STEP 4.1: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4.2: Enter the CARE PROGRAM PRODUCT > Click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 4.3: In Patient Information & Authorizations pg enter all the mandatory details of the patient.");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 4.4: Enter all the mandatory details in the Insurance Information section > Click on next.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		System.out.println(ExcelTestData.get(pharmacyfax));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 4.5: In the Prescriber Information section fill the HCP Speciality and HCo Zip code and other details > click on next.");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		System.out.println(ExcelTestData.get(prescriberZip));
		System.out.println(ExcelTestData.get(specialty));
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.updateZipandSpeciality("ALLERGY", "32839");
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 4.6: In the Diagnosis Information fill all the mandatory details > click on next.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 4.7:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), "", "",
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 5: Click on Submit and Enrollment Form should be submitted");
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		refresh();

		accountObject.verifyAndClickOnRecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		String url = getCurrentPageURL();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'BV'");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		navigateToUrl(url);
		Thread.sleep(4000);

		// Bv start
		Logger("STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		Logger("STEP 26: Open BV summary section");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(1));
		careProgram.clickOnSubTask(bvSubTaskNames.get(1));

		Logger("STEP 27: Enter details in Review and Send Summary of Benefits");
		bvPage.enterDetailsOnBVOutcome(outComeOptions.get(1), outComeReasonOptions.get(1));
		careProgram.clickOnSave();

		// pa start
		Logger("STEP 28: Click on PA/Appeal work order ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 29: Open \"Follow up on Results\" task and enter mandatory details and outcome as approved and click on save ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(0), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(0), PAOutcomeReason.get(0));
		String effectiveDate = Utility_Function.getNthDayFromToday(10);
		String expirationDate = Utility_Function.getNthDayFromToday(15);
		// paAppealsPage.enterMandatoryPAApprovedDetails(effectiveDate, paDosage.get(0),
		// expirationDate);
		careProgram.clickOnSave();

		String urll = getCurrentPageURL();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		navigateToUrl(urll);
		Thread.sleep(4000);
		// pa start 2
		Logger("STEP 32: open HCP follow up task ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));

		Logger("STEP 33: Mark status as completed and enter mandatory details click on save");
		paAppealsPage.selectDropdownValue("Status", paStatus.get(1));

		paAppealsPage.enterHCPFollowUp(hcpContact.get(0), attempts.get(0), ExcelTestData.get(officeContactName),
				intendedDate, submissionChannel.get(0), intentOfSubmission.get(0), nextFollowupTime.get(0));

		careProgram.clickOnSave();

		Logger("STEP 34: Follow up on result task and change status to completed ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));
		paAppealsPage.changeStatusToCompleted(StatusCheck.get(1));
		paAppealsPage.enterOutcome(pAOutcomeOptions.get(7));
		careProgram.clickOnSave();

		Logger("STEP 35: Navigate to PA summary task \"Communicate Results & Send SOB\" enter hcp contact details and save");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(1));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName), attempts.get(0), intentOfSubmission.get(0));
		paAppealsPage.enterOutcome(pAOutcomeOptions.get(1));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// PAP start Initialization and completion////////////
		Logger("STEP 41 :PAP work order initialization.");
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		papPage.selectReason("PAP Appeal");
		Logger("STEP 42 : Click on save and refresh the page");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnSubmitButton();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterOutcome(iapoutcome.get(0));
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();

		// quick start start/////////////
		Logger("STEP 12: Navigate to Quick Start and verify flow has initiated");
		refresh();
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();

		Logger("STEP 13: Click on Enrollment task");
		quickStartPage.clickOnTask();

		Logger("STEP 14: Enter Eligibility Criteria and click on Next button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 15: Enter Eligibility outcome and click on next button ");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 17: Enter order details and click on submit button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 18: Click on quick start button and verify task compltion status");
		quickStartPage.clickOnQuickStart();
		quickStartPage.checkQuickStartTaskComplition();

		// Copay start work order/////////////////////////
		Logger("STEP 16: Open Copay work order");
		careProgram.clickOnWorkOrderTask(workOrderName.get(3));
		careProgram.clickOnMainTask(copayMainTaskNames.get(0));
		careProgram.clickOnSubTask(copaySubTaskNames.get(0));

		Logger("STEP 17: Enter Eligibility Criteria and click on submit button");
		String outcomeDate = Utility_Function.getNthDayFromToday(0);
		boolean outcomeScreen = copayFlow.verifyReviewOutcomeScreen();
		if (outcomeScreen) {
			copayFlow.enterOutcomeDetails(copayOutcome.get(0), outcomeDate);
			copayFlow.clickOnReAssessButton();
		}
		copayFlow.enterEligibilityCriteria();
		quickStartPage.clickOnSubmitButton();
		copayFlow.enterRequestOutcome(copayOutcome.get(0), outcomeDate);
		copayFlow.clickOnFinishButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// triage start////////
		Logger("STEP 35: Navigate to Traige and verify flow has initiated");
		triagePage.checkTraigeIntiation();
		triagePage.checkTriageTaskInitiation();

		Logger("STEP 36: Click on Traige task");
		triagePage.clickOnTask();

		Logger("STEP 37: Verify task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(5));
		String selectedSP = triagePage.verifySelectedPharmacy(alliancePharmacy.get(0));
		Logger("STEP 38: Verify review information and click on next button");
		triagePage.verifyReviewTask(selectedSP, SPtype.get(1), expedited.get(1));
		missingInformatioPage.clickNextButton();

		Logger("STEP 39: Verify order details task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));

		Logger("STEP 40: Enter order details and click on submit");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 41: Click on Triage button and verify task compltion status");
		triagePage.clickOnTraige();
		triagePage.checkTraigeTaskComplition();

		//////////// iap start
		Logger("STEP 38: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 39: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 40: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.selectReason();

		Logger("STEP 41: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 42: Validate that in the right side of the UI there are two tasks:IAP Summary,Extend/Discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();
		iapPage.checkIAPSecondTask();

		Logger("STEP 43: Expand the IAP Summary section and Click on IAP Enrollment Task");
		iapPage.clickOnTask();

		Logger("STEP 44: Verify Users selects Enrollment Reason as Below Enrollment End Date populates accordingly");
		iapPage.verifyTaskIsLoaded(taskTitle.get(0));
		iapPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 45: Validate if User is navigated to the eligibility screen");
		iapPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 46: Verify Correspondence task is loaded and click on next button");
		// iapPage.verifyCorrespondenceScreen(); // does not exist anymore

		Logger("STEP 47: On Order Section Select the Prescription which were updated at the time of patient enrollment.");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		return CPEURL;
	}

	
	/**
	 * ====================================================================================================================
	 * Test Case Id:Regression-DocMgmnt: Automate ICARE-7434-SAT-TC02: Validate the
	 * Nursing Outcome and Nursing Outcome Reason field on Injection Training Case
	 * Layout:
	 * 
	 * @author Sonica P
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "IC15679 Regression-DocMgmnt: Automate ICARE-7434-SAT-TC02: Validate the Nursing Outcome and Nursing Outcome Reason field on Injection Training Case Layout:", enabled = true)
	public void DM28_IC15679_ICARE_7434_SAT_TC02_Validate_the_Nursing_Outcome_and_Nursing_Outcome_Reason_field_on_Injection_Training_Case_Layout()
			throws Exception {

		String TestCaseNumber = "TC28";

		CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		String NusringOut ="CAS-VR43: Nursing Outcome Reason is required when the Status is Closed.";
		String NusringReason ="CAS-VR42: Nursing Outcome is required when the Status is Closed.";

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 2: Navigate to Cases tab");
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 3: Click on the New Button at the top right corner.");
		docMgmt.navigateToCasesSection();
		missingInformatioPage.clickOnNewButtonInCase();

		// Injection Training Case
		Logger("STEP 4: Verify Case Manager is able to create 'Injection Training' Case Record Type(RT) ");
		missingInformatioPage.verifyNewCaseTitle();
		missingInformatioPage.clickCaseType(caseTypes.get(1));
		documentsPage.clickOnNextButtonInCM();
		documentsPage.verifyNewCaseTitle();

		documentsPage.enterAccountAndHCPName();
		documentsPage.selectTrainingType(trainingType.get(0));
		documentsPage.selectHCPTrainingStatus(trainingStatus.get(0));
		documentsPage.selectCaseStatus(caseStatus.get(1));
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 5: Now update the status to close and verify error occurs while saving");
		docMgmt.validateNursingErrorMsg(NusringOut);
		docMgmt.validateNursingErrorMsg(NusringReason);
		documentsPage.closeErrorDialog();

		Logger("STEP 6: Now, fill the Nursing Outcome and Nursing Outcome Reason  and Click Save");
		documentsPage.fillNursingDetails(nursingOutValues.get(0), nursingOutcomeReasonValues.get(0));
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 7: User Logout the Application.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-15681 Regression-DocMgmnt: Automate ICare-1630- SAT-TC01:
	 * Case Manager (CM) resends a previously sent Correspondence
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICare-1630- SAT-TC01: Case Manager (CM) resends a failed Correspondence.", enabled = true)
	public void DM29_IC7184_Validate_Case_Manager_CM_resends_a_failed_Correspondence() throws Exception {
		String user = "Trupti Zure_CM";
		Logger("STEP 1: Login to iCare Connect App as Case Manager (CM)");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Select \"Care Program Enrollee\" from the Navigation Menu");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 3 4 5: Open an existing Care Program Enrollee record  that has a Failed Correspondence record -> Navigate toRealted Tab -> Open the Correspondence record with Failed Status.");
		accountObject.searchRecord("Automation");
		docMgmt.openCPEwithFailedCorrespondence();

		Logger("STEP 6: Validate the status is Failed and you can see the Resend button");
		Thread.sleep(5000);
		docMgmt.statusCheckFail();
		docMgmt.validateResendBtn();

		Logger("STEP 7: Click on Resend Button");
		docMgmt.clickOnResendBtn();
		docMgmt.clickOnResendFinishBtn();

		Logger("STEP 8: Validate if the status is Ready to Send and Last Modified By field is updated");
		// docMgmt.validateFieldValue("Status", "Ready to Send");//Status is directly updated to Sent
		docMgmt.validateLastModifiedField(user);

		String currentDate = utilityPage.getCurrentDateInFormat("MM/dd/yyyy");
		docMgmt.validateFieldValue("Last Modified By", currentDate);

		Logger("STEP 9: Once the Correspondence is sent successfully, verify if the status is updated to \"Sent\" (You can refresh the page after sending)");
		refresh();
		refresh();
		docMgmt.validateFieldValue("Status", "Sent");

		Logger("STEP 10: Logout from the application");
		documentsPage.logout();

	}

	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-18039 TC03-Validate Updated Columns are displayed on Cases
	 * related List on CPE 12098
	 * 
	 * @author Tejal
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "TC01 - Validate Updated Columns are displayed on Cases related List on CPE", enabled = true)
	public void DM31_IC18039_validate_That_Updated_Columns_are_displayed_on_Cases_related_List_on_CPE()
			throws Exception {
		String TestCaseNumber = "TC30";

		if (Utility_Function.checkURLinFile()) {
			CPEURL = Utility_Function.readURL();
			TestCaseNumber = "TC1";
		} else {
			CPEURL = DocumentManagement_PatientEnrollment_Prerequisites(TestCaseNumber);
		}

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		int numberOfUsers = 6;
		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
				case 0:
					Logger("STEP 1: Login to the QA_SIT Org as 'CM'");
					homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
					break;

				case 1:
					Logger("STEP 2: Login to the QA_SIT Org as 'NE'");
					homeportalPage = loginPage.userLogin(NurseEduUserName, UserPassword);
					break;
				case 2:
					Logger("STEP 3: Login to the QA_SIT Org as 'PM'");
					homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
					break;

				case 3:
					Logger("STEP 4: Login to the QA_SIT Org as 'BO'");
					homeportalPage = loginPage.userLogin(BOUsername, UserPassword);
					break;
				case 4:
					Logger("STEP 5: Login to the QA_SIT Org as 'PC'");
					homeportalPage = loginPage.userLogin(PCUserName, UserPassword);
					break;
				case 5:
					Logger("STEP 6: Login to the QA_SIT Org as 'QM'");
					homeportalPage = loginPage.userLogin(QualityMGRUserName, UserPassword);
					break;

				}

				Logger("STEP 2: Open a CPE record");
				homeportalPage.closeTabs();
				navigateToUrl(CPEURL);
				Thread.sleep(2000);
				accountObject.clickOnTab(tabsName.get(1));
				docMgmt.navigateToCasesTable();
				accountObject.clickOnCaseNewButton();
				docMgmt.switchToAccessibilityFrame();
				docMgmt.selectNewCase(caseTypes.get(2));
				docMgmt.validateMissingInformationCaseIsAbsent();
				docMgmt.clickNextButton();
				docMgmt.switchToParentFrame();
				docMgmt.clickSaveButton();
				docMgmt.validateCaseIsFormed(caseTypes.get(2));
				accountObject.clickOnCPERecord(ExcelTestData.get(patientName));
				accountObject.clickOnTab(tabsName.get(1));
				docMgmt.navigateToCasesTable();
				careProgram.clickOnViewAll("Cases");
				docMgmt.validateCaseColumns();
				docMgmt.validateColsAreRemoved();

				Logger("STEP 9:Log out from application");
				documentsPage.logout();
			} catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				documentsPage.logout();

			}
		}

	}
}
