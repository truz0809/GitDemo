package com.sanofi.selenium.testutils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.TestNG;
import org.testng.annotations.Test;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlInclude;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import com.sanofi.selenium.core.Configuration;
import com.sanofi.selenium.utils.ReadExcel;

public class TestNgAutoCreation {
	ReadExcel excel = new ReadExcel("Execution sheet");
	String Thread = Configuration.readApplicationFile("executionThreadCount");
	int ThreadCount = Integer.parseInt(Thread);
	public String Filepath = System.getProperty("user.dir") + "/TestData/" + "TestNG.xlsx";// TestNgAutoCreationData
	int Counter = 1;
	int Counter1 = 1;
	HashMap<String, String> ExcelHashMapata = new HashMap<>();
	List<String> ClassList = new ArrayList<>();

	public void runTestNGTest() throws IOException { // Create an instance on TestNG
		TestNG myTestNG = new TestNG();
		List<XmlClass> myClasses = new ArrayList<XmlClass>();// create list to save Test classes name path

		XmlSuite mySuite = new XmlSuite();// Create an instance of XML Suite and assign a name for it.
		mySuite.setName("Suite");
		mySuite.setParallel(XmlSuite.ParallelMode.METHODS);

		XmlTest myTest = new XmlTest(mySuite);// Create an instance of XmlTest and assign a name for it.
		myTest.setName("test");

		XSSFSheet sheet = excel.getSheetData(Filepath);
		XSSFRow row;

		while (Counter <= sheet.getLastRowNum()) { // iterate loop until last row of excel Data.
			for (int i = Counter; i <= sheet.getLastRowNum(); i++) { // This for loop will iterate each mentioned in
																		// test data

				row = sheet.getRow(i);
				if (row != null) {
					Cell cell = row.getCell(0);
					String data = excel.getCellValueAsString(cell);

					if ((data != "") && ClassList.isEmpty()) {
						String value = excel.getCellValueAsString(cell);
						ClassList.add(value);
						Counter = i + 1;
					} else if (data == "") {
						Counter = i + 1;
					} else if (data != null) {
						Counter = i;
						break;
					}
				}
			}

			for (int i1 = Counter1; i1 < Counter; i1++) { // This for loop will iterate each testcase name mentionned in
															// testdata file.

				row = sheet.getRow(i1);
				if (row != null) {
					Cell cell = row.getCell(1);// read testcase name row column cells
					Cell cell1 = row.getCell(2);// read Executed column cells
					if (cell != null && cell1 != null) {
						String testValue = excel.getCellValueAsString(cell);
						String ExecutedValue = excel.getCellValueAsString(cell1);

						ExcelHashMapata.put(testValue, ExecutedValue);
						Counter1 = i1 + 1;
					}

				}
			}
			for (int i11 = 0; i11 < ClassList.size(); i11++) { // This loop will add tClass name and testcase name in
																// xml file
				if (ExcelHashMapata.containsValue("TRUE") || ExcelHashMapata.containsValue("True")) {

					List<XmlInclude> includedMethodsList = new ArrayList<XmlInclude>();

					XmlClass myClass = new XmlClass(ClassList.get(i11));
					myClasses.add(myClass);
					for (java.util.Map.Entry<String, String> entry : ExcelHashMapata.entrySet()) {
						String strValue = entry.getValue();
						if (strValue.equalsIgnoreCase("TRUE")) {

							XmlInclude includedtestMethod1 = new XmlInclude(entry.getKey());

							includedMethodsList.add(includedtestMethod1);
							myClass.setIncludedMethods(includedMethodsList);
						}
					}
					myTest.setXmlClasses(myClasses);
				}
			}
			ClassList = new ArrayList<>();
			ExcelHashMapata = new HashMap<String, String>();
		}

		List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
		mySuites.add(mySuite);

		// Set the list of Suites to the testNG object you created earlier.
		myTestNG.setXmlSuites(mySuites);
		mySuite.setFileName("testng.xml");
		mySuite.setThreadCount(ThreadCount);

		// Create physical XML file based on the virtual XML content
		for (XmlSuite suite : mySuites) {
			createXmlFile(suite);
		}
		System.out.println("TestNG Execution File generated successfully.");

	}

	public void createXmlFile(XmlSuite mSuite) {
		FileWriter writer;
		try {
			writer = new FileWriter(new File("testng.xml"));
			writer.write(mSuite.toXml());
			writer.flush();
			writer.close();
			System.out.println(new File("testng.xml").getAbsolutePath());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Main Method
	public static void main(String args[]) throws IOException {
		TestNgAutoCreation dt = new TestNgAutoCreation();
		dt.runTestNGTest();
	}
}