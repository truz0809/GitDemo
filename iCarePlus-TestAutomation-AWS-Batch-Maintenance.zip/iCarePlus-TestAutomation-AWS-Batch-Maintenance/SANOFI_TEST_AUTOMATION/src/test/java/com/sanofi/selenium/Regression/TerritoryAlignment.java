package com.sanofi.selenium.Regression;

import java.util.HashMap;
import java.util.Map;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.CareTeamAssignment;
import com.sanofi.selenium.pages.CopayFlow;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;

public class TerritoryAlignment extends BaseTest {

	private static ThreadLocal<String> filePath = new ThreadLocal<>();
	public String CPEURL;
	public ReadExcel excel;
	public String fileName;
	String functionality = "CareProgram";

	public static double getRandomNumber(double min, double max) {
		double x = (int) (Math.random() * ((max - min) + 1)) + min;
		return x;
	}

	double randomNum = getRandomNumber(1111, 9999);

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		copayFlow = GetInstance(CopayFlow.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		triagePage = GetInstance(TriagePage.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		careTeamAsgn = GetInstance(CareTeamAssignment.class);
		docMgmt = GetInstance(DocumentManagementPage.class);

		sheetName = "CareProgram";
		excel = new ReadExcel(sheetName);
	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-9354: Care team Assignment:SAT:Exception Handling when
	 * multiple potential CM & FRM matches.
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Care team Assignment:SAT:Exception Handling when multiple potential CM & FRM matches.", enabled = true)
	public void TA01_IC9354_Exception_Handling_when_multiple_potential_CM_FRM_matches() throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC2";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy",
				"Prescription 5B Quick Start", "Specialty", "Prescriber Zip", "Patient DOB",
				"Patient Authorization Date", "Collaborating MD Name", "Zip" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "FALSE", "TRUE", "ALLERGY", "32839", "01-16-2007", "05-01-2024", "32839",
				" " };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the VAL Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 3.1: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 3.2: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 4: On Classify document page select Doc type = Enrollment Form > Click on submit.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 4.1: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4.2: Enter the CARE PROGRAM PRODUCT > Click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 4.3: In Patient Information & Authorizations pg enter all the mandatory details of the patient.");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 4.4: Enter all the mandatory details in the Insurance Information section > Click on next.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		System.out.println(ExcelTestData.get(pharmacyfax));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 4.5: In the Prescriber Information section fill the HCP Speciality and HCo Zip code and other details > click on next.");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		System.out.println(ExcelTestData.get(prescriberZip));
		System.out.println(ExcelTestData.get(specialty));
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.updateZipandSpeciality("ALLERGY", "32839");
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 4.6: In the Diagnosis Information fill all the mandatory details > click on next.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 4.7:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 5: Click on Submit and Enrollment Form should be submitted");
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 6:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 7: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		String cpeurl = getCurrentPageURL();
		cpeurl = Utility_Function.removeQueryString(cpeurl);

		Logger("STEP 8: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 9: Login as a program co-ordinator.");
		homeportalPage = loginPage.userLogin(PCUserName, UserPassword);
		homeportalPage.closeTabs();

		navigateToURL(cpeurl);
		Thread.sleep(4000);

//		Logger("STEP 10: Verify New field Assignment Detail(*Lookup to Log Object)* Fields is added on CPE page layout.");
//		careTeamAsgn.verifyASGNDetailsField();

		Logger("STEP 11: Verify When CM is assigned, and no FRM is Assigned Log Record will auto populate in Assignment details fields.");
		careTeamAsgn.verifyCMIsAssigned();

		Logger("STEP 12: Validate When HCP/ HCO is updated then also Log Record is getting created if CM or FRM are not getting assigned");

		// Add HCP to Facility Record

		docMgmt.clickOnSiteRecord();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToHealthcarePractitioner();
		accountObject.clickNewButton();
		accountObject.addHCPtoFacilityRecord(ExcelTestData.get(sitefacilityname), ExcelTestData.get(prescriberName));
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		docMgmt.clickOnSiteRecord();
		String siteName = "Automation " + ExcelTestData.get(sitefacilityname);
		careTeamAsgn.editSiteName(siteName);
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// HCP update
		accountObject.clickonAccount(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToCCR();
		accountObject.clickOnCCRRecord(ExcelTestData.get(prescriberName));
		documentsPage.clickOnEditActive();
		accountObject.clickActiveCheckBox();
		missingInformatioPage.clickOnSaveButton();
		documentsPage.navigateToCCRTab();
		missingInformatioPage.clickOnNewRelationshipButton();
		documentsPage.selectHCPFromDropDown();
		accountObject.clickActiveCheckBox();
		String hcpName = "Automation " + ExcelTestData.get(prescriberName);
		documentsPage.enterHCPName(hcpName);
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// deactivate CM manager
		accountObject.clickOnTab(tabsName.get(1));
		careTeamAsgn.clickOnCareTeamMemberEnrolle();
		careTeamAsgn.clickOnCareTeamMember();
		documentsPage.clickOnEditActive();
		accountObject.clickActiveCheckBoxCTM();
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// HCO/Site update
		careTeamAsgn.updateSiteDetails(siteName);
		refresh();

//		String newLog2 = careTeamAsgn.getLogNumber();
//		System.out.println(newLog2);

		Logger("STEP 13: Logout from application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE-10559 Regression-CarePrgm: Automate Care Team Assignment
	 * via Enrollment flow(Patient Search).
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE-10559 Regression-CarePrgm: Automate Care Team Assignment via Enrollment flow(Patient Search).", enabled = true)
	public void TA02_IC9335_Validate_Care_Team_Assignment_via_Enrollment_Flow_Patient_Search() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC2";
		String caseManager = "Case  Manager4";

		// String cpeName = "AutomationJoe Roy Gilbert";
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy",
				"Prescription 5B Quick Start", "Specialty", "Prescriber Zip", "Patient DOB",
				"Patient Authorization Date", "Prescriber Name", "Prescriber Address", "Prescriber City",
				"Prescriber State", "Prescriber NPI", "Site/facility name", "Office Phone", "Office Contact Name",
				"Office Contact Email" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "FALSE", "TRUE",
				"ALLERGY", "32839", "01-16-2007", "05-01-2024", "Joe Lewis", "139 Front Street", "Los Angeles",
				"South Carolina", "3708713132", "Mount Sinai Medical Center", "(193) 853-7839", "Alice Emily",
				"aliceemily@gmail.com" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the VAL Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 3.1: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.2: Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 4: On Classify document page select Doc type = Enrollment Form > Click on submit.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 4.1: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4.2: Enter the CARE PROGRAM PRODUCT > Click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 4.3: In Patient Information & Authorizations pg enter all the mandatory details of the patient.");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 4.4: Enter all the mandatory details in the Insurance Information section > Click on next.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 4.5: In the Prescriber Information section fill the  details and Select HCP and HCO via Search Functionality> click on next.");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		System.out.println(ExcelTestData.get(prescriberZip));
		System.out.println(ExcelTestData.get(specialty));
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		careTeamAsgn.selectHCPrecord(ExcelTestData.get(prescriberName), ofcLastName);
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 4.6: In the Diagnosis Information fill all the mandatory details > click on next.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 4.7:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 5: Click on Submit and Enrollment Form should be submitted");
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 6:  Navigate to CPE record and Verify Case Manager and Field Reimbursement Manager are assigned.");
//		accountObject.navigateToCareProgramEnrollee();
//		assessmentTasksPage.verifyRecentlyViewList();
//		documentsPage.searchDocument(cpeName);
//		missingInformatioPage.clickOnRecord(cpeName);
		
		Logger("STEP 7:  Open the CPE record > Validate CM & FRM is not assigned.");
		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));

		String CaseManagerName = careTeamAsgn.validateManagerField(managerFields.get(0));

		Logger("STEP 6.1: Verify No Log Created is created in Assignment details field.");
//		careTeamAsgn.validateNoLogIsCreated();
		String cpeURL = getCurrentPageURL();

		Logger("STEP 8:  Logout AS DIS and Login as CM User.");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 9: Navigate to Same CPE record from above and Update HCP & HCO.");
		navigateToUrl(cpeURL);

//		String url = "https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf0000005W5hCAE/view";
//		navigateToUrl(url);
		CaseManagerName = careTeamAsgn.validateManagerField(managerFields.get(0));

//		careTeamAsgn.updatePrescriberAndSiteDetails(prescriberDetails.get(1));
		refresh();

		Logger("Step 9.1: Verify Territory recalculation is getting retriggered.");
		String updatedCaseManagerName = careTeamAsgn.validateManagerField(managerFields.get(0));
//		careTeamAsgn.compareManagerNames(CaseManagerName, updatedCaseManagerName);
//		accountObject.clickOnTab(tabsName.get(1));
//		careTeamAsgn.clickOnCareTeamMemberEnrolle();
//		careTeamAsgn.validateExistingCMandFRMDeactivated(caseManager);
//
//		Logger("Step 10: Verify CPE, MI cases updated to newly assigned Case Manager.");
//		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
//		accountObject.clickOnTab(tabsName.get(2));
//		careTeamAsgn.checkMICaseOwner(updatedCaseManagerName);
//
//		// validate CPE record Owner name
//		accountObject.navigateToCareProgramEnrollee();
//		documentsPage.searchDocument(cpeName);
//		careTeamAsgn.validateCPEownerName(cpeName, updatedCaseManagerName);

		Logger("STEP 10.1:  Logout as CM User");
		documentsPage.logout();

	}

	
	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE_10560 :Regression-CarePrgm: Automate Care Team Assignment
	 * via Enrollment flow
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE_10560 :Regression-CarePrgm: Automate Care Team Assignment via Enrollment flow", enabled = true)
	public void TA03_IC9320_Validate_Care_Team_Assignment_via_Enrollment_Flow() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC3";
		String caseManager = "Case  Manager4";
		String fieldManager = "Field Reimbursement  Manager2";
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy",
				"Prescription 5B Quick Start", "Specialty", "Prescriber Zip", "Patient DOB",
				"Patient Authorization Date", "Collaborating MD Name", "Zip" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "FALSE", "TRUE",
				"ALLERGY", "32839", "01-16-2007", "05-01-2024", "", "32839" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the VAL Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 3.1: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.2: Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 4: On Classify document page select Doc type = Enrollment Form > Click on submit.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 4.1: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4.2: Enter the CARE PROGRAM PRODUCT > Click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 4.3: In Patient Information & Authorizations pg enter all the mandatory details of the patient.");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 4.4: Enter all the mandatory details in the Insurance Information section > Click on next.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		System.out.println(ExcelTestData.get(pharmacyfax));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 4.5: In the Prescriber Information section fill the HCP Speciality and HCo Zip code and other details > click on next.");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		System.out.println(ExcelTestData.get(prescriberZip));
		System.out.println(ExcelTestData.get(specialty));
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.updateZipandSpeciality("ALLERGY", "32839");
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 4.6: In the Diagnosis Information fill all the mandatory details > click on next.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 4.7:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 5: Click on Submit and Enrollment Form should be submitted");
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 6:  Navigate to CPE record and Verify Case Manager and Field Reimbursement Manager are assigned.");
//		accountObject.navigateToCareProgramEnrollee();
//		assessmentTasksPage.verifyRecentlyViewList();
//		documentsPage.searchDocument(cpeName);
//		missingInformatioPage.clickOnRecord(cpeName);

		Logger("STEP 7:  Open the CPE record > Validate CM & FRM is not assigned.");
		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));

		String CaseManagerName = careTeamAsgn.validateManagerField(managerFields.get(0));
		// String FieldReimbursementManagerName =
		// careTeamAsgn.validateManagerField(managerFields.get(1));

//		Logger("STEP 6.1: Verify No Log Created is created in Assignment details field.");
//		careTeamAsgn.validateNoLogIsCreated();

		// Logger("STEP 7: Check the Owner of CPE record, MI cases");
		// accountObject.clickOnTab(tabsName.get(2));
		// careTeamAsgn.checkMICaseOwner(CaseManagerName);
		String cpeURL = getCurrentPageURL();

		Logger("STEP 8:  Logout AS DIS and Login as CM User.");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 9: Navigate to Same CPE record from above and Update HCP & HCO.");
		navigateToUrl(cpeURL);
//		careTeamAsgn.updatePrescriberAndSiteDetails(prescriberDetails.get(0), prescriberDetails.get(1));
//		careTeamAsgn.updatePrescriberAndSiteDetails(prescriberDetails.get(1));
		refresh();

//		Logger("Step 9.1: Verify Territory recalculation is getting retriggered.");
//		String updatedCaseManagerName = careTeamAsgn.validateManagerField(managerFields.get(0));
//		// String updatedFieldReimbursementManagerName =
//		// careTeamAsgn.validateManagerField(managerFields.get(1));
//		careTeamAsgn.compareManagerNames(CaseManagerName, updatedCaseManagerName);
//		// careTeamAsgn.compareManagerNames(FieldReimbursementManagerName,
//		// updatedFieldReimbursementManagerName);
//		accountObject.clickOnTab(tabsName.get(1));
//		careTeamAsgn.clickOnCareTeamMemberEnrolle();
//		careTeamAsgn.validateExistingCMandFRMDeactivated(caseManager);
//		// careTeamAsgn.validateExistingCMandFRMDeactivated(fieldManager);
//
//		Logger("Step 10: Verify CPE, MI cases updated to newly assigned Case Manager.");
//		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
//		accountObject.clickOnTab(tabsName.get(2));
//		careTeamAsgn.checkMICaseOwner(updatedCaseManagerName);
//
//		// validate CPE record Owner name
//		accountObject.navigateToCareProgramEnrollee();
//		documentsPage.searchDocument(cpeName);
//		careTeamAsgn.validateCPEownerName(cpeName, updatedCaseManagerName);

		Logger("STEP 10.1:  Logout as DIS User.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE_4579 :Validate there is only one Active assignment per
	 * role (FRM/CM) assigned either via auto-alignment or either via manual
	 * alignment.
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE_4579 :Validate there is only one Active assignment per role (FRM/CM) assigned either via auto-alignment or either via manual alignment", enabled = true)
	public void TA04_IC4579_Validate_there_is_only_one_Active_assignment_per_role_FRM_CM_assigned_either_via_auto_alignment_or_either_via_manual_alignment()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC4";
		String caseManager = "Case  Manager4";
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy",
				"Prescription 5B Quick Start", "Specialty", "Prescriber Zip", "Patient DOB",
				"Patient Authorization Date", "Collaborating MD Name", "Zip" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "FALSE", "TRUE",
				"ALLERGY", "32839", "01-16-2007", "05-01-2024", " ", "32839" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the VAL Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 3.1: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.2: Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 4: On Classify document page select Doc type = Enrollment Form > Click on submit.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 4.1: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4.2: Enter the CARE PROGRAM PRODUCT > Click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 4.3: In Patient Information & Authorizations pg enter all the mandatory details of the patient.");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 4.4: Enter all the mandatory details in the Insurance Information section > Click on next.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		System.out.println(ExcelTestData.get(pharmacyfax));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 4.5: In the Prescriber Information section fill the HCP Speciality and HCo Zip code and other details > click on next.");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		System.out.println(ExcelTestData.get(prescriberZip));
		System.out.println(ExcelTestData.get(specialty));
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.updateZipandSpeciality("ALLERGY", "32839");
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 4.6: In the Diagnosis Information fill all the mandatory details > click on next.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 4.7:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 5: Click on Submit and Enrollment Form should be submitted");
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 6:  Navigate to CPE record and Verify Case Manager and Field Reimbursement Manager are assigned.");
		accountObject.navigateToCareProgramEnrollee();
		assessmentTasksPage.verifyRecentlyViewList();
		documentsPage.searchDocument(cpeName);
		missingInformatioPage.clickOnRecord(cpeName);

		String CaseManagerName = careTeamAsgn.validateManagerField(managerFields.get(0));

		String cpeURL = getCurrentPageURL();

		Logger("STEP 7:  Logout AS DIS User");
		documentsPage.logout();

		Logger("STEP 8:Login to the SIT Org as 'Case Manager User");
		homeportalPage = loginPage.userLogin(PCUserName, UserPassword);

		Logger("STEP 9:Open the recently created record.");
		navigateToUrl(cpeURL);
		Thread.sleep(4000);

		Logger("STEP 10:Navigate to related tab.");
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 11:Validate that there is already an active CPE TM is available for both the roles (CM/FRM)");
		docMgmt.navigateToCPETeamMemberTable();
		careProgram.clickOnViewAll("Care Program Enrollee Team Members");

		Logger("STEP 12:Click on new button and try to create a new CPE TM record for any role (FRM/CM) with the ACTIVE checkbox checked");
		careProgram.clickOnNewButton();
		careProgram.enterCPETeamMemData();
		careProgram.selectProgramRoleAndStartDate(managerFields.get(0));
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 13:Validate error message 'Only one Care Team user for a given role can be assigned. To add a new Team Member, inactivate the other Care Team User' should be displayed on the screen.");
		careProgram.validateErrorMessgae();
		accountObject.clickCancelButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
	

		// HCP update
		accountObject.clickonAccount(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToCCR();
		accountObject.clickOnCCRRecord(ExcelTestData.get(prescriberName));
		documentsPage.clickOnEditActive();
		accountObject.clickActiveCheckBox();
		missingInformatioPage.clickOnSaveButton();
		documentsPage.navigateToCCRTab();
		missingInformatioPage.clickOnNewRelationshipButton();
		documentsPage.selectHCPFromDropDown();
		accountObject.clickActiveCheckBox();
		String hcpName = "Automation User" ;
		documentsPage.enterHCPName(hcpName);
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		documentsPage.clickOnEditSiteButton();
		careTeamAsgn.updateSiteDetails("Test Data");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		// String CMName = careTeamAsgn.validateCMField(managerFields.get(0))

		// add new CPE Team member manually
		Logger("STEP 10:Navigate to related tab.");
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 11:Validate that there is already an active CPE TM is available for both the roles (CM/FRM)");
		docMgmt.navigateToCPETeamMemberTable();
		careProgram.clickOnViewAll("Care Program Enrollee Team Members");

//		Logger("STEP 12:Click on new button and try to create a new CPE TM record for any role (FRM/CM) with the ACTIVE checkbox checked");
//		careProgram.clickOnNewButton();
//		careProgram.enterCPETeamMemData();
//		careProgram.selectProgramRoleAndStartDate(managerFields.get(0));
//		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 14:Validate that the ‘Start Date' of the new CPE TM and 'End Date’ of Previous CPE TM are populated according to the Start and End date of service.");
		careProgram.validateStartEndDate();
		careProgram.validateNewActiveCM();

		Logger("STEP 15: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-13485 Regression-Territory Alignment: Automate
	 * Case Manager assignment on update of related record.
	 * 
	 * @author Sonica P
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE-13485 Regression-Territory Alignment: Automate Case Manager assignment on update of related record.", enabled = true)
	public void TA05_IC4509_ICARE_1624_SAT_TC01_To_Validate_Case_Manager_assignment_on_updation_of_related_record()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC7";
		String caseManager = "Case  Manager4";
		String fieldManager = "Field Reimbursement  Manager2";
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy",
				"Prescription 5B Quick Start", "Specialty", "Prescriber Zip", "Patient DOB",

				"Patient Authorization Date", "Prescriber Name", "Prescriber Address", "Prescriber City",
				"Prescriber State", "Prescriber NPI", "Site/facility name", "Office Phone", "Office Contact Name",
				"Office Contact Email" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "TRUE", "TRUE",
				"ALLERGY", "32839", "01-16-2007", "05-01-2024", "Joe Lewis", "139 Front Street", "Los Angeles",
				"South Carolina", "370871" + randomNum, "Mount Sinai Medical Center", "(193) 853-7839", "Alice Emily",
				"aliceemily@gmail.com" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the VAL Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 3.1: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 3.2: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 4: On Classify document page select Doc type = Enrollment Form > Click on submit.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 4.1: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4.2: Enter the CARE PROGRAM PRODUCT > Click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 4.3: In Patient Information & Authorizations pg enter all the mandatory details of the patient.");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 4.4: Enter all the mandatory details in the Insurance Information section > Click on next.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		// insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 4.5: In the Prescriber Information section fill the  details and Select HCP and HCO via Search Functionality> click on next.");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		System.out.println(ExcelTestData.get(prescriberZip));
		System.out.println(ExcelTestData.get(specialty));
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));

		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 4.6: In the Diagnosis Information fill all the mandatory details > click on next.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 4.7:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 5: Click on Submit and Enrollment Form should be submitted");
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 6:  Navigate to CPE record and Verify Case Manager and Field Reimbursement Manager are assigned.");
//		accountObject.navigateToCareProgramEnrollee();
//		assessmentTasksPage.verifyRecentlyViewList();
//		documentsPage.searchDocument(cpeName);
//		missingInformatioPage.clickOnRecord(cpeName);
		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));

//		String url = "https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf00000086ppCAA/view";
//				//"https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf00000088urCAA/view";
//		navigateToUrl(url);
		String CaseManagerName = careTeamAsgn.validateManagerField(managerFields.get(0));

		// String FieldReimbursementManagerName =
		// careTeamAsgn.validateManagerField(managerFields.get(1));

		Logger("Step 7: Validate CPE Team Member related list displays name of CM and FRM");
		accountObject.clickOnTab(tabsName.get(1));
		careTeamAsgn.clickOnCareTeamMemberEnrolle();

		Logger("Step 8: Validate HCP Specialty details are mentioned and service Resource and Account is hidden from Care program enrollee team Member Page Layout.");
		utilityPage.back();
		accountObject.validateHCPSpecialty();
		careTeamAsgn.clickOnCareTeamMemberEnrolle();
		String cpeURL = getCurrentPageURL();

		Logger("STEP 9: Logout AS DIS and Login as CM User.");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 10: Navigate to Same CPE record from above and Update HCP & HCO.");
		navigateToUrl(cpeURL);
		utilityPage.back();
		accountObject.clickOnTab(tabsName.get(0));
		// careTeamAsgn.updatePrescriberAndSiteDetails(prescriberDetails.get(0),
		// prescriberDetails.get(1));
		refresh();

		Logger("Step 10.1: Verify Territory recalculation is getting retriggered.");
		String updatedCaseManagerName = careTeamAsgn.validateManagerField(managerFields.get(0));
		// String updatedFieldReimbursementManagerName =
		// careTeamAsgn.validateManagerField(managerFields.get(1));
//		careTeamAsgn.compareManagerNames(CaseManagerName, updatedCaseManagerName);
//		// careTeamAsgn.compareManagerNames(FieldReimbursementManagerName,
//		// updatedFieldReimbursementManagerName);
//		accountObject.clickOnTab(tabsName.get(1));
//		careTeamAsgn.clickOnCareTeamMemberEnrolle();
//		careTeamAsgn.validateExistingCMandFRMDeactivated(caseManager);
//		// careTeamAsgn.validateExistingCMandFRMDeactivated(fieldManager);

		Logger("STEP 11:  Logout AS DIS and Login as PM User.");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);

		Logger("Step 12: Navigate to the CPE Team Member Object and validate the Manual Override checkbox");
		navigateToUrl(cpeURL);
		accountObject.clickOnTab(tabsName.get(1));
		careTeamAsgn.clickOnCareTeamMemberEnrolle();
//		accountObject.validateManualOverRide();

		Logger("STEP 13: Navigate to Same CPE record from above and Update HCP & HCO.");
		utilityPage.back();
		accountObject.clickOnTab(tabsName.get(0));
		// careTeamAsgn.updatePrescriberAndSiteDetails(prescriberDetails.get(0),
		// prescriberDetails.get(1));
		refresh();

		Logger("Step 14: Validate that the CM remains same as Manual Override checkbox is checked");
		accountObject.clickOnTab(tabsName.get(1));
		careTeamAsgn.clickOnCareTeamMemberEnrolle();

		Logger("STEP 15:  Logout AS PM");
		documentsPage.logout();
	}

}
