package com.sanofi.selenium.Regression;

import java.util.HashMap;
import java.util.Map;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;

public class Fax extends BaseTest {
	private static ThreadLocal<String> filePath = new ThreadLocal<>();
	public ReadExcel excel;
	public String fileName;
	String functionality = "Fax";

	public static double getRandomNumber(double min, double max) {
		double x = (int) (Math.random() * ((max - min) + 1)) + min;
		return x;
	}

	double randomNum = getRandomNumber(1111, 9999);

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		sheetName = "Fax";
		excel = new ReadExcel(sheetName);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		uploadDocs = GetInstance(UploadDocument.class);
		triagePage = GetInstance(TriagePage.class);

	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	@Test(description = "SIT_Fax Workflow Patient Enrollment Prerequisites", enabled = true)
	public String Fax_PatientEnrollment_Prerequisites(String testcaseNumber) throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Specialty Pharmacy Name",
				"Pharmacy Phone", "Pharmacy Fax", "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "Automation Correspondence SP", "(954) 312-1432",
				"(982) 053-8606", "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		return CPEURL;

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE- 7277 To validate Updated Fax field for all HCP
	 * Correspondences
	 * 
	 * @author Trupti
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "TC01: Validate the COVERAGE PROFILE REPORT for Summary of Benefits - MD Fax correspondence with primary insurance details", enabled = true)
	public void Fax01_IC7277_To_validate_Updated_Fax_field_for_all_HCP_Correspondences() throws Exception {

		String TestCaseNumber = "TC1";
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Care Program Enrollee'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 3: Change List view to 'Recently View' queue list view.");
		docMgmt.verifyRecentlyViewList();

		Logger("STEP 4: Open the any newly created CPE");
		documentsPage.searchDocument("Automation");
		String recordName = missingInformatioPage.searchAndOpenRecord();

		Logger("STEP 5: Click and open the record on the Site field and check for the Patient  have the Fax details present in the corresponding \"Active\" Facility record linked to the HCP Record, so that the HCP fax Correspondences can be send.");
		boolean siteRecord = docMgmt.verifySiteRecordIsPresent();
		int retryCount = 0;
		int maxRetries = 3;
		while (!siteRecord) {
			Logger("Site record not found, retrying...");
			documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
			documentsPage.searchDocument("Automation");
			recordName = missingInformatioPage.searchAndOpenRecord();
			siteRecord = docMgmt.verifySiteRecordIsPresent();
			if (retryCount > maxRetries) {
				Logger("Maximum retry count reached, exiting loop.");
				break;
			}
		}
		if (siteRecord) {
			Logger("Site record found, continuing with further steps.");

			boolean faxFound = docMgmt.verifyFaxIsPresent();
			if (!faxFound) {
				docMgmt.editFax(ExcelTestData.get(pharmacyfax));
				missingInformatioPage.clickOnSaveButton();
				Thread.sleep(5000);
				refresh();
			}
			String patientName = recordName.split("-")[0].trim();
			missingInformatioPage.navigateToCPERecord(patientName);
			refresh();

			Logger("STEP 6: Click on the Correspondence button");
			docMgmt.clickOnCorrespondenceBotton();

			Logger("STEP 7: Verify Process Name and Item To Send");
			docMgmt.selectProcessNameAndItemToSend(selectProcessName.get(1), itemToSend.get(2));
			missingInformatioPage.clickNextButton();
			missingInformatioPage.clickNextButton();

			Logger("STEP 8: Verify Generate Document Correspondence Screen opens and user can send the Correspondence");
			docMgmt.verifyGenerateDocScreen(itemToSend.get(2));
			docMgmt.clickSendButtonUntilFinish();

			Logger("STEP 10: Validate success message is populated in the Correspondence record");
			String msg = docMgmt.validateSuccessMessage();
			if (msg.contains(summaryofBenefitsPASuccessMSG)) {
				Logger("Success message verified.");
			} else {
				Logger("Success message not found.");
				Assert.fail();
				throw new Exception("Success message not found.");
			}

			docMgmt.clickonFinishButton();

			Logger("STEP 11: Verify message in Correspondence Record");
			missingInformatioPage.navigateToCPERecord(patientName);
			refresh();
			accountObject.clickOnTab(tabsName.get(1));
			docMgmt.navigateToCorrespondenceTable();
			careProgram.clickOnViewAll("Correspondences");
			docMgmt.verifyCorrespondenceRecord(selectProcessName.get(1));
			docMgmt.clickOnCorrespondenceRecord(selectProcessName.get(1));
			docMgmt.verifyMessageIsPopulated();

			Logger("STEP 12: Log out from application");
			documentsPage.logout();

		}

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate IC13491 Regression-FAX: Automate the COVERAGE PROFILE
	 * REPORT for Summary of Benefits - MD Fax correspondence with primary insurance
	 * details
	 * 
	 * @author Sonica P
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "IC13491 Regression-FAX: Automate the COVERAGE PROFILE REPORT for Summary of Benefits - MD Fax correspondence with primary insurance details", enabled = true)
	public void Fax02_IC7813_Validate_the_COVERAGE_PROFILE_REPORT_for_Summary_of_Benefits_MD_Fax_correspondence_with_primary_insurance_details()
			throws Exception {

		String TestCaseNumber = "TC2";

		String CPEURL = Fax_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 2: Open a CPE record which is tagged to a patient that has only primary record of Member plan and make it Active");
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.verifyPrimaryRecordMemberPlansSection();
		careProgram.clickOnViewAll("Member Plans");
		docMgmt.changeMemberPlanStatusActive(ExcelTestData.get(rxPayerName));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToMemPlans();
		docMgmt.changeMemberPlanStatusActive(ExcelTestData.get(medicalPayerName));
		missingInformatioPage.clickOnSaveButton();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		Thread.sleep(4000);

		Logger("STEP 3: Click on the correspondence Button present on the Top right corner of CPE Record.");
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 4: Fill Process name and select items to send information");
		docMgmt.selectProcessName(selectProcessName.get(0));
		docMgmt.selectItemsToSend(bvitemsToSend.get(2));
		missingInformatioPage.clickNextButton();
		missingInformatioPage.clickNextButton();

		Logger("STEP 5: Wait for few seconds on the Generate Document(s) Screen to load the DMW Summary of Benefits - MD Fax  → Match the field mapping → Click on Send");
		docMgmt.clickSendButtonUntilFinish();

		Logger("STEP 6: Click on Finish button on confirmation page");
		docMgmt.clickonFinishButton();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 7: Validate PDF Files present in Related List of Correspondence ");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecord(bvitemsToSend.get(2));
		String pdfName = bvitemsToSend.get(2).trim();
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.deleteExistingFile(downloadPath);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);

		// Data validation
		String payerNumber = Utility_Function.formatNumber(ExcelTestData.get(rxPhone));

		Map<String, Integer> fieldsToValidate = new HashMap<>();
		// Medical
		fieldsToValidate.put("Primary Payer: " + ExcelTestData.get(medicalPayerName), 3);
		fieldsToValidate.put("Plan Name: " + ExcelTestData.get(medicalPayerName), 3);
		fieldsToValidate.put("Policy Number: " + ExcelTestData.get(medicalPolicyID), 3);
		fieldsToValidate.put("Group Number: " + ExcelTestData.get(medicalGroup), 3);

		// Pharmacy
		fieldsToValidate.put("PBM Name: " + ExcelTestData.get(rxPayerName), 3);
		fieldsToValidate.put("PBM Phone: " + payerNumber, 3);
		fieldsToValidate.put("PBM Policy Number: " + ExcelTestData.get(rxPolicyID), 3);
		fieldsToValidate.put("PBM Group Number: " + ExcelTestData.get(rxGroup), 3);

		Logger("STEP 8: Validate the COVERAGE PROFILE REPORT will only show the primary Insurance details");
//		docMgmt.validateMultiplePDFFields(downloadPath, fieldsToValidate);

	}

	/***
	 * Test Case Id:Automate ICARE-7817 Regression-FAX: Validate the COVERAGE
	 * PROFILE REPORT for Summary of Benefits - MD Fax correspondence with primary
	 * and secondary insurance details
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "IC7817 Regression-FAX: Automate the COVERAGE PROFILE REPORT for Summary of Benefits - MD Fax correspondence with primary and secondary insurance details", enabled = true)
	public void Fax03_IC7817_Validate_the_COVERAGE_PROFILE_REPORT_for_Summary_of_Benefits_MD_Fax_correspondence_with_primary_and_secondary_insurance_details()
			throws Exception {

		String TestCaseNumber = "TC6";
		String CPEURL = Fax_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(CPEURL);
		Thread.sleep(4000);
		
//		String cpeu = "https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf0000004rH3CAI/view";
//		navigateToUrl(cpeu);

		Logger("STEP 2: Open a CPE record which is tagged to a patient that has primary record of Member plan and add Secondary plan");
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.verifyPrimaryRecordMemberPlansSection();
		careProgram.clickOnViewAll("Member Plans");
		refresh();

		// Pharmacy secondary record
		careProgram.clickOnNewBtn();
		missingInformatioPage.clickCaseType(caseTypes.get(4));
		documentsPage.clickNextButton();
		documentsPage.enterSecondaryPharmacy(pharamcyMember.get(0), pharamcyMember.get(1), pharamcyMember.get(2),
				pharamcyMember.get(3));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToMemPlans();

		// Medical secondary record
		refresh();
		careProgram.clickOnNewBtn();
		missingInformatioPage.clickCaseType(caseTypes.get(5));
		documentsPage.clickNextButton();
		documentsPage.enterSecondaryMedical(medicalMember.get(0), medicalMember.get(1), medicalMember.get(2));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToMemPlans();

		docMgmt.changeMemberPlanStatusActive(pharamcyMember.get(0));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToMemPlans();
		docMgmt.changeMemberPlanStatusActive(medicalMember.get(0));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToMemPlans();
		docMgmt.changeMemberPlanStatusActive(ExcelTestData.get(rxPayerName));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToMemPlans();
		docMgmt.changeMemberPlanStatusActive(ExcelTestData.get(medicalPayerName));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 3: Click on the correspondence Button present on the Top right corner of CPE Record.");
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 4: Fill Process name and select items to send information");
		docMgmt.selectProcessName(selectProcessName.get(0));
		docMgmt.selectItemsToSend(bvitemsToSend.get(2));
		missingInformatioPage.clickNextButton();
		missingInformatioPage.clickNextButton();

		Logger("STEP 5: Wait for few seconds on the Generate Document(s) Screen to load the DMW Summary of Benefits - MD Fax  → Match the field mapping → Click on Send");
		docMgmt.clickSendButtonUntilFinish();

		Logger("STEP 6: Click on Finish button on confirmation page");
		docMgmt.clickonFinishButton();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 7: Validate PDF Files present in Related List of Correspondence ");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecord(bvitemsToSend.get(2));
		String pdfName = bvitemsToSend.get(2).trim();
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.deleteExistingFile(downloadPath);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);

		// Data validation
		String payerNumber = Utility_Function.formatNumber(ExcelTestData.get(rxPhone));

		Map<String, Integer> fieldsToValidate = new HashMap<>();
		// Medical - primary
		fieldsToValidate.put("Primary Payer: " + ExcelTestData.get(medicalPayerName), 3);
		fieldsToValidate.put("Plan Name: " + ExcelTestData.get(medicalPayerName), 3);
		fieldsToValidate.put("Policy Number: " + ExcelTestData.get(medicalPolicyID), 3);
		fieldsToValidate.put("Group Number: " + ExcelTestData.get(medicalGroup), 3);

		// Pharmacy - primary
		fieldsToValidate.put("PBM Name: " + ExcelTestData.get(rxPayerName), 3);
		fieldsToValidate.put("PBM Phone: " + payerNumber, 3);
		fieldsToValidate.put("PBM Policy Number: " + ExcelTestData.get(rxPolicyID), 3);
		fieldsToValidate.put("PBM Group Number: " + ExcelTestData.get(rxGroup), 3);

		// Medical - secondary
		fieldsToValidate.put("Primary Payer: " + medicalMember.get(0), 4);
		fieldsToValidate.put("Plan Name: " + medicalMember.get(0), 4);
		fieldsToValidate.put("Policy Number: " + medicalMember.get(1), 4);
		fieldsToValidate.put("Group Number: " + medicalMember.get(2), 4);

		// Pharmacy - secondary
		fieldsToValidate.put("PBM Name: " + pharamcyMember.get(0), 4);
		fieldsToValidate.put("PBM Phone: " + pharamcyMember.get(1), 4);
		fieldsToValidate.put("PBM Policy Number: " + pharamcyMember.get(2), 4);
		fieldsToValidate.put("PBM Group Number: " + pharamcyMember.get(3), 4);

		Logger("STEP 8: Validate the COVERAGE PROFILE REPORT will show the primary Insurance details and secondary insurance details on page third and fourth.");
//		docMgmt.validateMultiplePDFFields(downloadPath, fieldsToValidate);

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE- 7818 Summary of Benefits - MD Fax correspondence when no
	 * insurance detail is linked to the CPE
	 * 
	 * @author Trupti
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Summary of Benefits - MD Fax correspondence when no insurance detail is linked to the CPE", enabled = true)
	public void Fax04_IC7818_Validate_the_Summary_of_BenefitsMD_Fax_correspondence_when_no_insurance_detail_is_linked_to_the_CPE()
			throws Exception {

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC9";

		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_MDFax);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite 02: User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 5:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 6:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 7:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 8:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 9: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 10: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 11:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.clearTextFromDateField();
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 12: Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 13: Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 14:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 15:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 16:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 17: Verify if patient record is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 18: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);

		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		Logger("STEP 19: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 20: Login to the  Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		navigateToUrl(cpeURL);

		Logger("STEP 21: Click on the Correspondence button");
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 22: Select Items to send Section is displayed with two fields: select the values1. Process Name as BV2. Select Items to send as DMW Summary of Benefits - MD Fax Click on Next");
		docMgmt.selectProcessName(selectProcessName.get(0));
		docMgmt.selectItemsToSend(itemToSend.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 23: No document should be genrated with the following validation message as: \"Recipient Not Found\" ");
		docMgmt.validateErrorMessage(summaryofBenefitMDFAXErrorMSG);

		Logger("STEP 24: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Regression: Automate ICARE-10338: SIT: TC01: To Validate
	 * Correspondence Resend button is available if Request status = Failed
	 * 
	 * @author Sonica P
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Regression: ICARE15663 Automate ICARE-10338: SIT: TC01: To Validate Correspondence Resend button is available if Request status = Failed", enabled = true)
	public void Fax05_IC12043_To_Validate_Correspondence_Resend_button_is_available_if_Request_status_Failed()
			throws Exception {

		int numberOfUsers = 3;
		String TestCaseNumber = "TC1";

		String CPEURL = Fax_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		SoftAssert softassert = new SoftAssert();

		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
				case 0:
					Logger("STEP 1: Login to the QA_SIT Org as 'PC'");
					homeportalPage = loginPage.userLogin(PCUserName, UserPassword);
					break;

				case 1:
					Logger("STEP 1: Login to the QA_SIT Org as 'NE'");
					homeportalPage = loginPage.userLogin(NurseEduUserName, UserPassword);
					break;

				case 2:
					Logger("STEP 1: Login to the QA_SIT Org as 'PM'");
					homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
					break;

				case 3:
					Logger("STEP 1: Login to the QA_SIT Org as 'BO'");
					homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
					break;

				}

				Logger("STEP 2: Navigate to the Care program Enrollees object");
				navigateToUrl(CPEURL);
				Thread.sleep(4000);
				
				/*bvPage.verifytheBVTaskInitiated();
				careProgram.clickOnWorkOrderTask(workOrderName.get(0));
				careProgram.clickOnMainTask(bvMainTaskNames.get(0));
				careProgram.clickOnSubTask(bvSubTaskNames.get(0));
				
				bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
						ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
						ExcelTestData.get(rxGroup));
				bvPage.clickOnSavePharmacy();
				
				bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
						medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
				
				bvPage.clickOnCoverageBenefitSave();
				bvPage.clickOnCompleteButton();
				
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();*/

				

				////////////////////// generating doc for each process name///////////////
				// BV
				Logger("STEP 6: Click on the Correspondence button");
				docMgmt.clickOnCorrespondenceBotton();

				Logger("STEP 7: Select the Process Name as 'Welcome Correspondence' and Select items to Send as 'DMW Checkbox Welcome' and Click on Next");
				docMgmt.selectProcessName(processName.get(1));
				docMgmt.selectItemsToSend(itemToSend.get(0));
				missingInformatioPage.clickNextButton();
				//missingInformatioPage.clickNextButton();

				Logger("STEP 13: Verify Generate Document Correspondence Screen opens and user can send the Correspondence");
				//docMgmt.verifyGenerateDocScreen(itemToSend.get(0));
				//docMgmt.clickSendButtonUntilFinish();

//				Logger("STEP 14: Validate success message is populated in the Correspondence record");
//				String msg = docMgmt.validateSuccessMessage();
//				if (msg.contains(welcomeCorrespondenceSuccessMSG)) { // check again
//					Logger("Success message verified.");
//				} else {
//					Logger("Success message not found.");
//					Assert.fail();
//					throw new Exception("Success message not found.");
//				}

				docMgmt.clickonFinishButton();

				Logger("STEP 15: Verify message in Correspondence Record");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();
				accountObject.clickOnTab(tabsName.get(1));
				docMgmt.navigateToCorrespondenceTable();
				// docMgmt.clickViewAll("Correspondences");
				careProgram.clickOnViewAll("Correspondences");
				docMgmt.verifyCorrespondenceRecord(processName.get(1));
				docMgmt.clickOnCorrespondenceRecord(processName.get(1));

				docMgmt.statusCheckFail();
				docMgmt.validateResendBtn();

				// PA
				Logger("STEP 6: Click on the Correspondence button");
				docMgmt.clickOnCorrespondenceBotton();

				Logger("STEP 7: Select the Process Name as 'Welcome Correspondence' and Select items to Send as 'DMW Checkbox Welcome' and Click on Next");
				docMgmt.selectProcessName(processName.get(2));
				docMgmt.selectItemsToSend(itemToSend.get(0));
				missingInformatioPage.clickNextButton();

				Logger("STEP 13: Verify Generate Document Correspondence Screen opens and user can send the Correspondence");
				docMgmt.verifyGenerateDocScreen(itemToSend.get(0));
				docMgmt.clickSendButtonUntilFinish();
//
//				Logger("STEP 14: Validate success message is populated in the Correspondence record");
//				String msgPA = docMgmt.validateSuccessMessage();
//				if (msgPA.contains(welcomeCorrespondenceSuccessMSG)) { // check again
//					Logger("Success message verified.");
//				} else {
//					Logger("Success message not found.");
//					Assert.fail();
//					throw new Exception("Success message not found.");
//				}

				docMgmt.clickonFinishButton();

				Logger("STEP 15: Verify message in Correspondence Record");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();
				accountObject.clickOnTab(tabsName.get(1));
				docMgmt.navigateToCorrespondenceTable();
				// docMgmt.clickViewAll("Correspondences");
				careProgram.clickOnViewAll("Correspondences");
				docMgmt.verifyCorrespondenceRecord(processName.get(2));
				docMgmt.clickOnCorrespondenceRecord(processName.get(2));
				docMgmt.statusCheckFail();
				docMgmt.validateResendBtn();

			} catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				documentsPage.logout();
			}
		}
	}

	@Test(description = "To validate Correspondence, resend option is hidden if Request status = success or blank", enabled = true)
	public void Fax06_IC12027_To_Validate_Correspondence_Resend_button_is_hidden_if_Request_status_Success_or_blank()
			throws Exception {

		String TestCaseNumber = "TC11";

//		String CPEURL = Fax_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		SoftAssert softassert = new SoftAssert();

		int numberOfUsers = 4;
		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
				case 0:
					Logger("STEP 1: Login to the QA_SIT Org as 'PC'");
					homeportalPage = loginPage.userLogin(PCUserName, UserPassword);
					break;

				case 1:
					Logger("STEP 2: Login to the QA_SIT Org as 'NE'");
					homeportalPage = loginPage.userLogin(NurseEduUserName, UserPassword);
					break;

				case 2:
					Logger("STEP 3: Login to the QA_SIT Org as 'PM'");
					homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
					break;

				case 3:
					Logger("STEP 4: Login to the QA_SIT Org as 'BO'");
					homeportalPage = loginPage.userLogin(BOUsername, UserPassword);
					break;

				}
//
//				Logger("STEP 2: Navigate to the Care program Enrollees object");
//				navigateToUrl(CPEURL);
//				Thread.sleep(4000);
				
				String cp = "https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf0000005b3lCAA/view";
				navigateToUrl(cp);

				// BV
				Logger("STEP 6: Click on the Correspondence button");
				docMgmt.clickOnCorrespondenceBotton();

				Logger("STEP 7: Select the Process Name as 'Welcome Correspondence' and Select items to Send as 'DMW Checkbox Welcome' and Click on Next");
				docMgmt.selectProcessName(processName.get(1));
				docMgmt.selectItemsToSend(itemToSend.get(0));
				missingInformatioPage.clickNextButton();
				missingInformatioPage.clickNextButton();

				Logger("STEP 13: Verify Generate Document Correspondence Screen opens and user can send the Correspondence");
				docMgmt.verifyGenerateDocScreen(itemToSend.get(0));
				docMgmt.clickSendButtonUntilFinish();

//				Logger("STEP 14: Validate success message is populated in the Correspondence record");
//				String msg = docMgmt.validateSuccessMessage();
//				if (msg.contains(welcomeCorrespondenceSuccessMSG)) {
//					Logger("Success message verified.");
//				} else {
//					Logger("Success message not found.");
//					Assert.fail();
//					throw new Exception("Success message not found.");
//				}

				docMgmt.clickonFinishButton();

				Logger("STEP 15: Verify message in Correspondence Record");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();
				accountObject.clickOnTab(tabsName.get(1));
				docMgmt.navigateToCorrespondenceTable();
				careProgram.clickOnViewAll("Correspondences");
				docMgmt.verifyCorrespondenceRecord(processName.get(1));
				docMgmt.clickOnCorrespondenceRecord(processName.get(1));

				docMgmt.statusCheck();
				docMgmt.validateResendBtnIsHidden();

				// PA
				Logger("STEP 6: Click on the Correspondence button");
				docMgmt.clickOnCorrespondenceBotton();

				Logger("STEP 7: Select the Process Name as 'Welcome Correspondence' and Select items to Send as 'DMW Checkbox Welcome' and Click on Next");
				docMgmt.selectProcessName(processName.get(2));
				docMgmt.selectItemsToSend(itemToSend.get(0));
				missingInformatioPage.clickNextButton();
//				missingInformatioPage.clickNextButton();

				Logger("STEP 13: Verify Generate Document Correspondence Screen opens and user can send the Correspondence");
				docMgmt.verifyGenerateDocScreen(itemToSend.get(0));
				docMgmt.clickSendButtonUntilFinish();

//				Logger("STEP 14: Validate success message is populated in the Correspondence record");
//				String msgPA = docMgmt.validateSuccessMessage();
//				if (msgPA.contains(welcomeCorrespondenceSuccessMSG)) {
//					Logger("Success message verified.");
//				} else {
//					Logger("Success message not found.");
//					Assert.fail();
//					throw new Exception("Success message not found.");
//				}

				docMgmt.clickonFinishButton();

				Logger("STEP 15: Verify message in Correspondence Record");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();
				accountObject.clickOnTab(tabsName.get(1));
				docMgmt.navigateToCorrespondenceTable();
				careProgram.clickOnViewAll("Correspondences");
				docMgmt.verifyCorrespondenceRecord(processName.get(2));
				docMgmt.clickOnCorrespondenceRecord(processName.get(2));
				docMgmt.statusCheck();
				docMgmt.validateResendBtnIsHidden();

			} catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				documentsPage.logout();

			}
		}
	}

}
