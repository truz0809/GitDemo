package com.sanofi.selenium.Regression;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.AuthorizationFormConsentPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.CopayFlow;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;

public class CopayWorkflow extends BaseTest {
	private static ThreadLocal<String> filePath = new ThreadLocal<>();
	public ReadExcel excel;
	public String fileName;
	String functionality = "CopayWorkflow";

	
	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		copayFlow = GetInstance(CopayFlow.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		triagePage = GetInstance(TriagePage.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		sheetName = "CopayWorkflow";
		excel = new ReadExcel(sheetName);
		docMgmt=GetInstance(DocumentManagementPage.class);
		authorizationConsentPage=GetInstance(AuthorizationFormConsentPage.class);

		
	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}
	
	@Test(description = "SIT_Prior Authorization Workflow Patient Enrollment Prerequisites", enabled = true)
	public String CopayWorkflow_PatientEnrollment_Prerequisites(String testcaseNumber) throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "State", "Zip", "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "Alaska", "99501", "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		synchronized (excelDataUpdate) {
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite 02: User updates the Patient Form");
	
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());
		fileName = documentsPage.getFileName(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 10: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 11: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 12:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		Thread.sleep(20000);
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 13:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 15:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 16:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 17:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 18:Verify account is created ");
		accountObject.globalSearchAcc(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 19: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID=assessmentTasksPage.navigateAndGetID();


		Logger("STEP 20: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 21: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 22: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 23:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);

		Logger("STEP 24: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();
		
		return ID;

	}
	

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7291 Validating the reinitiation flow of
	 * Triage/Copay/Quickstart WO
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "ICARE-7291_Validating the reinitiation flow of Triage/Copay/Quickstart WO", enabled = true)
	public void CP01_IC7291_Validating_the_reinitiation_flow_of_TriageCopayQuickstart_WO() throws Exception {

		String TestCaseNumber = "TC24";

		// Prerequisites
		String ID=CopayWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		// BV task
		Logger("STEP 1:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		
		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		Logger("STEP 5: Verify BV Task is initiated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 6: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 7: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 10: User Logout the Application.");
		documentsPage.logout();

		// case manager
		Logger("STEP 11: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();
		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		// Quick Start work order
		Logger("STEP 12: Open Quick start work order");
		careProgram.clickOnWorkOrderTask(workOrderName.get(2));
		careProgram.clickOnMainTask(quickStartMainTaskNames.get(0));
		careProgram.clickOnSubTask(quickStartSubTaskNames.get(0));

		Logger("STEP 13: Enter Eligibility Criteria and click on Next button");
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 14: Enter Eligibility outcome and click on next button ");
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 15: Enter order details");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// Copay work order
		Logger("STEP 16: Open Copay work order");
		refresh();
		careProgram.clickOnWorkOrderTask(workOrderName.get(3));		
     	careProgram.clickOnMainTask(copayMainTaskNames.get(0));
		careProgram.clickOnSubTask(copaySubTaskNames.get(0));


		Logger("STEP 17: Enter Eligibility Criteria and click on submit button");
    	String outcomeDate = Utility_Function.getNthDayFromToday(0);
		boolean outcomeScreen = copayFlow.verifyReviewOutcomeScreen();
		if (outcomeScreen) {
			copayFlow.enterOutcomeDetails(copayOutcome.get(0), outcomeDate);
			copayFlow.clickOnReAssessButton();
      	} 
		if(!(copayFlow.checkCopayMainTaskCompletion())) {
			copayFlow.enterEligibilityCriteria();
			quickStartPage.clickOnSubmitButton();
			copayFlow.enterRequestOutcome(copayOutcome.get(0), outcomeDate);
			copayFlow.clickOnFinishButton();
			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
			refresh();
		}
		

		// Triage work order
		Logger("STEP 18: Open Triage work order");
		if(!(careProgram.workOrderTaskIsClickable(workOrderName.get(4)))) {
			iapPage.clickOnStartNewService();
			iapPage.verifyServiceTitle();
			copayFlow.selectService(workOrderName.get(4));
			missingInformatioPage.clickNextButton();
			iapPage.checkAttestationcheckboxIfPresent();
			copayFlow.selectReason(serviceReason.get(3));
			missingInformatioPage.clickOnSaveButton();
			refresh();
			Thread.sleep(2000);
		}
		careProgram.clickOnWorkOrderTask(workOrderName.get(4));
		careProgram.clickOnMainTask(triageMainTaskNames.get(0));
		careProgram.clickOnSubTask(triageSubTaskNames.get(0));

		Logger("STEP 19: Enter order details and click on submit");
		missingInformatioPage.clickNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 20: Check word order status is completed QuickStart,Copay,Triage");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEWorkOrder();
		String[] workOrders = { "Triage", "Copay", "Quick Start" };
		String expectedStatus = "Completed";
		copayFlow.checkCPEWorkOrderData(careProgramProduct.get(2), ExcelTestData.get(patientName),
				Arrays.asList(workOrders), expectedStatus);

		Logger("STEP 21: Manually initiate the WO: Quick start,Triage,Copay");

		for (String workorder : workOrders) {
			iapPage.clickOnStartNewService();
			iapPage.verifyServiceTitle();
			copayFlow.selectService(workorder);
			missingInformatioPage.clickNextButton();
			iapPage.checkAttestationcheckboxIfPresent();
			if(workorder.equals("Copay"))
			{
				copayFlow.selectReason(serviceReason.get(2));
			}else if(workorder.equals("Quick Start")){
				copayFlow.selectReason(serviceReason.get(4));
			}else if(workorder.equals("Triage")){
				copayFlow.selectReason(serviceReason.get(3));
			}
			missingInformatioPage.clickOnSaveButton();
			refresh();
			Thread.sleep(2000);
		}
		
		refresh();
		Logger("STEP 22: Check word order status is inprogress QuickStart,Copay,Triage");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEWorkOrder();
		expectedStatus = "InProgress";
		copayFlow.checkCPEWorkOrderData(careProgramProduct.get(2), ExcelTestData.get(patientName),
				Arrays.asList(workOrders), expectedStatus);

		// Quick Start work order
		Logger("STEP 23: Open Quick start work order");
		careProgram.clickOnWorkOrderTask(workOrderName.get(2));
		careProgram.clickOnMainTask(quickStartMainTaskNames.get(0));
		careProgram.clickOnSubTask(quickStartSubTaskNames.get(0));

		Logger("STEP 24: Enter Eligibility Criteria and click on Next button");
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 25: Enter Eligibility outcome and click on next button ");
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 26: Enter order details");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// Triage work order
		Logger("STEP 27: Open Triage work order");
		careProgram.clickOnWorkOrderTask(workOrderName.get(4));
		careProgram.clickOnMainTask(triageMainTaskNames.get(0));
		careProgram.clickOnSubTask(triageSubTaskNames.get(0));

		Logger("STEP 28: Enter order details and click on submit");
		missingInformatioPage.clickNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

	}
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7984 Validate the updated flows on the Flex card of CPE
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test
	public void CP02_IC7984_Validate_the_updated_flows_on_Flex_Card_of_CPE() throws Exception {

		String TestCaseNumber = "TC14";

		// Prerequisites
		String ID=CopayWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		// BV task
		Logger("STEP 1:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		Logger("STEP 5: Verify BV Task is initiated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 6: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 7: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 10: User Logout the Application.");
		documentsPage.logout();

		// case manager
		Logger("STEP 11: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 11: Validate the My Tasks card is displayed on the Right side of the layout and ");
		bvPage.verifyMyTasksTitle();

		Logger("STEP 12: Validate All other cards (patient/hcp/hco/ Medical&Coverage information) should be on left side of the layout");
		bvPage.verifyOtherCards();

		Logger("STEP 13: Validate the sections 'Caregiver Information' and 'Office Contact Information' no longer visible ");
		bvPage.verifySectionNotVisible();

		Logger("STEP 14: Validate new fields(Email,Caregiver,Relationship) present in Patient Information Section ");
		bvPage.validateNewFieldsInPatienInfo(ExcelTestData.get(patientEmail),
				ExcelTestData.get(legalRepresentativeName), ExcelTestData.get(legalrelationship));

		Logger("STEP 15: Validate new fields(HCO Type, Office contact name, office contact email) present in HCO Information Section ");
		bvPage.validateNewFieldsInHCOInfo(ExcelTestData.get(officeContactName), ExcelTestData.get(officeContactEmail));

		Logger("STEP 16: Validate new Medical/Coverage Section added with new fields ");
		bvPage.validateMedicalCoverageSectionFields(ExcelTestData.get(specialtyPharmacyName),
				ExcelTestData.get(diagnosisCode), ExcelTestData.get(prescription5ADose), ExcelTestData.get(rxPayerName),
				planType.get(0), outComeOptions.get(1));

		Logger("STEP 17: Validate the field ‘*Patient Consent on file?*’ field is moved from the Patient Information section to the Medical/Coverage Information section");
		bvPage.validatePatienConsentOnfile();

		Logger("STEP 18:Validate on the HCP Information 'Prescribing HCP Name' is changed and labelled as 'HCP Name' 2. \"HCP Type\" field is added");
		bvPage.validateNewHCPFields();

		Logger("STEP 19: User Logout the Application.");
		documentsPage.logout();

	}
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:Verify Error Message for Comma(,) and slash(/)on Patient Address Field
	 * @author Tejal Pednekar
	 * 27029 21196
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Verify Error Message for Comma(,) and slash(/)on Patient Address Field", enabled = true)
	public void CP04_IC21196_Validate_error_msg_for_comma_slash_in_patient_address() throws Exception {


		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC15";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text",
				"Specialty Pharmacy Name", "DUPIXENT MyWay",
				"Preferred Specialty Pharmacy","State","Zip","Specialty","Pharmacy Fax" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "Automation Correspondence SP","TRUE","TRUE","New York","11201","CARDIOVASCULAR SURGERY","9082037482"};
		

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(5).split(" -")[0];

		Logger("Pre-Requisite 2 : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Navigate to the Received document object →Select a document by checking the checkbox next to the relevant record--> Click on Assign to me button → Open the document and classify as enrollment form and Click on Submit");
		
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);
		Logger("STEP 2.1: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 2.2:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));
		
		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
	    String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(5),
				ExcelTestData.get(patientDOB));
		
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		
		patientInfo.updatePatientAddressOnly("Main, Street/");
		docMgmt.validateErrorMsgForAddress();

		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		Thread.sleep(2000);	
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));
		accountObject.updateStreetAndCity();
		missingInformatioPage.clickOnSaveButton();
		docMgmt.validateErrorMsgForAddressInAccount();

		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		
		String url = getCurrentPageURL();

		Logger("STEP 1.10: Logout of the application as CM user.");
		documentsPage.logout();

		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();
		
		navigateToUrl(url);
		
		// Benefits Verification
		Logger("STEP 17: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));
 
		Logger("STEP 18: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();
 
		Logger("STEP 19: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		
		
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		//copayFlow.verifyWorkOrderStatus("Benefits Verification","Completed");
		//copayFlow.verifyWorkOrderStatus("Copay","Completed");
		
		
		Logger("STEP 6: Click on the Correspondence button");
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 7: Select the Process Name as 'Welcome Correspondence' and Select items to Send as 'DMW Checkbox Welcome' and Click on Next");
		docMgmt.selectProcessName(selectProcessName.get(3));
		docMgmt.selectItemsToSend(itemToSend.get(5));
		missingInformatioPage.clickNextButton();
		missingInformatioPage.clickNextButton();


		Logger("STEP 9: Click on Finish button and navigate back to the CPE record ");
		docMgmt.clickonFinishButton();
		docMgmt.verifyGenerateDocumentScreen();
		docMgmt.clickSendButtonUntilFinish();
		docMgmt.clickonFinishButton();

		Logger("STEP 15: Verify message in Correspondence Record");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();
		careProgram.clickOnViewAll("Correspondences");
		docMgmt.clickOnCorrespondenceRecord(selectProcessName.get(3));
		docMgmt.validateStatus();
// below steps we can skip as per the manual tester hence commented
//		accountObject.clickOnTab(tabsName.get(1));
//		accountObject.navigateToCCRTable();
//		accountObject.clickRelatedContactByName(ExcelTestData.get(prescriberName));
//		accountObject.updateStreetAndCityHCP();
//		docMgmt.enterCredentials();
//		missingInformatioPage.clickOnSaveButton();
//		docMgmt.validateErrorMsgForAddress();
//		String acctname = ExcelTestData.get(patientName);
//		Utility_Function.switchToWindow(acctname);
		
		
		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();


	}
	
}
