package com.sanofi.selenium.Regression;

import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.CopayFlow;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;

public class TriageToPharmacy extends BaseTest {

	private static ThreadLocal<String> filePath = new ThreadLocal<>();
	public ReadExcel excel;
	public String fileName;
	String functionality = "TriageToPharmacy";

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		copayFlow = GetInstance(CopayFlow.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		triagePage = GetInstance(TriagePage.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		uploadDocs = GetInstance(UploadDocument.class);

		sheetName = "TriageToPharmacy";
		excel = new ReadExcel(sheetName);
	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	// description = "SIT_Traige Workflow Patient Enrollment Prerequisites"
	public String TriageToPharmacyWorkflow_PatientEnrollment_Prerequisites_QuickStartYes(String testcaseNumber)
			throws Exception {

		String cpeUrl = null;
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3.1: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.2:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.3: Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.4: After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.5: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();

		Logger("STEP 16: Search CPE");
		accountObject.globalSearch(searchFilter.get(1), cpeName);
		cpeUrl = getCurrentPageURL();
		
		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();
		return cpeUrl;

	}

	public String TriageToPharmacyWorkflow_PatientEnrollment_Prerequisites_QuickStartNo(String testcaseNumber)
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		String removeColumnData[] = { "Prescription-B RefillCaptured", "Prescription-5B Dose" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());
		fileName = documentsPage.getFileName(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 3.1:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 2.3:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.2:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.3:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 10: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 11: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 12:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 13:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 15:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 16:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 17:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 18:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 19: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);

		Logger("STEP 20: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 21: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 22: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();

		Logger("STEP 23: Search CPE");
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 24: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();

		return fileName;
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7413 To validate 'Prescription' lookup field for
	 * QuickStart Triage to Pharmacy throws Exception
	 * 
	 * @author Anand Pawar
	 *         ====================================================================================================================
	 **/
	@Test(description = "TC01 To validate 'Prescription' lookup field for QuickStart Triage to Pharmacy", enabled = true)
	public void Triage01_IC7413_Validate_Prescription_lookup_field_for_QuickStart() throws Exception {

		String TestCaseNumber = "TC1";

		// Pre-requisites
		String url = TriageToPharmacyWorkflow_PatientEnrollment_Prerequisites_QuickStartYes(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-requisites 2.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 2.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		navigateToUrl(url);
		
//		String url = "String cpeUrl = null;"
//		navigateToUrl(url);
//		Logger("Pre-requisites 2.3: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("Pre-requisites 2.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);

		// BV Initialization code starts here
		Logger("Pre-requisites 2.5: Verify BV Task is initiated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre-requisites 2.6: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 2.7: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(0), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		// Get CPE URL
		String cpeURL = getCurrentPageURL();

		Logger("Pre-requisites 2.10: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(cpeURL);

		Logger("STEP 2: Navigate to Quick Start and verify flow has initiated");
		refresh();
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();

		Logger("STEP 3: Click on Enrollment task");
		quickStartPage.clickOnTask();

		Logger("STEP 4: Enter Eligibility Criteria and click on Next button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 5: Enter Eligibility outcome and click on next button ");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 6: Verify Correspondence task is removed and user navigated to Order Details page ");
		quickStartPage.verifyTaskIsNotLoaded(taskTitle.get(2));// verify this is removed
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));

		Logger("STEP 7: Enter order details and click on submit button");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 8: Click on quick start button and verify task compltion status");
		refresh();
		quickStartPage.clickOnQuickStart();
		quickStartPage.checkQuickStartTaskComplition();

		refresh();

		Logger("STEP 9: After QuickStart is completed, navigate to the Order object and validate that Order details are generated on Patient's name.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		quickStartPage.verifyOrderDetails(ExcelTestData.get(patientName));

		Logger("STEP 10: User clicks on quickstart Prescription and edit the Status");
		quickStartPage.clickOnQSOrderPrescription();
		quickStartPage.editPrescriptionStatus(mrStatus.get(1));
		missingInformatioPage.clickOnSaveButton();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 11: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 12: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 13: User will see two fields: 1. Start Service : Pick the value as 'Quick Start' 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		iapPage.selectQSService();
		missingInformatioPage.clickNextButton();
		iapPage.selectQSReason();

		Logger("STEP 14: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 15: Navigate to Quick Start and verify flow has initiated");
		refresh();
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();

		Logger("STEP 16: Click on Enrollment task");
		quickStartPage.clickOnTask();

		Logger("STEP 17: Enter Eligibility Criteria and click on Next button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 18: Enter Eligibility outcome and click on next button ");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 19: Verify Correspondence task is removed and user navigated to Order Details page ");
		quickStartPage.verifyTaskIsNotLoaded(taskTitle.get(2));// verify this is removed
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));

		Logger("STEP 20: Enter order details and click on submit button");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 21: Click on quick start button and verify task compltion status");
		refresh();
		quickStartPage.clickOnQuickStart();
		quickStartPage.checkQuickStartTaskComplition();

		refresh();

		Logger("STEP 22: After QuickStart is completed, navigate to the Order object and validate that Order details are generated on Patient's name.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		quickStartPage.verifyOrderDetails(ExcelTestData.get(patientName));

		Logger("STEP 23: User clicks on quickstart Prescription and edit the Status");
		quickStartPage.clickOnQSOrderPrescription();
		quickStartPage.editPrescriptionStatus(mrStatus.get(1));
		missingInformatioPage.clickOnSaveButton();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		refresh();
		Logger("STEP 24: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 25: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 26: User will see two fields: 1. Start Service : Pick the value as 'Quick Start' 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		iapPage.selectQSService();
		missingInformatioPage.clickNextButton();
		iapPage.selectQSReason();

		Logger("STEP 27: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 28: Navigate to Quick Start and verify flow has initiated");
		refresh();
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();

		Logger("STEP 29: Click on Enrollment task");
		quickStartPage.clickOnTask();

		Logger("STEP 30: Enter Eligibility Criteria and click on Next button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 31: Enter Eligibility outcome and click on next button ");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 32: Verify Correspondence task is removed and user navigated to Order Details page ");
		quickStartPage.verifyTaskIsNotLoaded(taskTitle.get(2));// verify this is removed
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));

		Logger("STEP 33: Enter order details and click on submit button");
		quickStartPage.verifyNoRecordMsg();

		Logger("STEP 34: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-4478 Submit order flow when 'Expedited Triage' is yes
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "TC03 - Submit order flow when 'Expedited Triage' is yes", enabled = true)
	public void Triage02_IC4478_Submit_order_flow_when_Expedited_Triage_is_yes() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC2";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		String removeColumnData[] = { "Prescription-B RefillCaptured", "Prescription-5B Dose" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);
		fileName = documentsPage.getFileName(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.1:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 2.3:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.2:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.3:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 10: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 11: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 12:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 13:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 15:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 16:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 17:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 18:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		String cpeUrl = getCurrentPageURL();

		Logger("STEP 19: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 20: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 21: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 22: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();

		Logger("STEP 23: Search CPE");
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 24: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		homeportalPage.closeTabs();

		Logger("STEP 2: From App Launcher search for Medication Dispense");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(23), DocumentPage.class);
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllMedication();

		Logger("STEP 3: Check there is no Medication Dispense record created for the current CPE");
		String accountName = ExcelTestData.get(patientName);
		careProgram.checkMedicationRequestNotCreated(accountName);

		Logger("STEP 4: From App Launcher search for Medication Dispense");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 5: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 6: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		// String name = ExcelTestData.get(patientName);
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		Logger("STEP 7: Verify BV Task is initiated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 8: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 9: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(0), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(3));
		String selectedSP = alliancePharmacy.get(0);
		bvPage.enterPharmacy1Details(selectedSP);

		Logger("STEP 10: click on save button in CB section>>Click on Complete button on the bottom on saving both Member plan and Coverage benefit details");
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		String url = getCurrentPageURL();

		Logger("STEP 13: Logout as BV user and login as Case Manager");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 14: Navigate to same CPE Record created in above steps and Validate Triage is initiated");
		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);
		triagePage.checkTraigeIntiation();

		Logger("STEP 15: Open this WO record , in accordion named as Triage Validate there is Assessment task created with name \"Submit Order\" Click on this order");
		triagePage.checkTriageTaskInitiation();
		careProgram.clickOnSubTask(triageSubTaskNames.get(0));
		triagePage.clickOnTask();

		Logger("STEP 16: Validate user is presented with Screen 1 Titled \"Review\"");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(5));
		triagePage.verifyReviewTaskFieldsReadOnly();
		triagePage.verifyReviewTask(selectedSP, SPtype.get(1), expedited.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 17: For Expedited Triage, Check following is shown to the Case Manager:Prescription,Demonstrate that all Enrollment form File records associated to the Care Program Enrollee are shown ");
		triagePage.verifyOrderTable(quickStartRx.get(1));
		String file = fileName.split("\\.")[0];
		triagePage.verifyFileName(file);

		Logger("STEP 18: Click on Submit button present at the bottom of this page");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 19: Verify order is created for triage work order");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		triagePage.verifyOrderDetails(ExcelTestData.get(patientName));
		String orderId = triagePage.getOrderDetails();

		Logger("STEP 19: From App Launcher >> search and open orders >> validate a order is create for same CPE/patient");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(9), DocumentPage.class);
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllOrders();
		triagePage.verifyOrderRecordIsPresent(orderId);

		Logger("STEP 20: Logout as Case Manager");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7541 To validate 'Prescription' lookup field for Triage
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Triage to pharmacy: Automate iCare5635: SAT: TC04: To validate 'Prescription' lookup field for Triage")
	public void Triage03_IC7541_SIT_To_validate_Prescription_lookup_field_for_Triage() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC3";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "TRUE" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy(alliancePharmacy.get(0));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16: Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		String cpeUrl = getCurrentPageURL();

		Logger("STEP 17: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 20: Seacrh 'Care program enrollee' .");
		homeportalPage.closeTabs();
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 22: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 123: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 24: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 25: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		navigateToUrl(cpeUrl);
		
//		Logger("STEP 26: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 27: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);

		// BV Initialization code starts here
		Logger("STEP 28: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("STEP 29: verify to select Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 30: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));

		Logger("STEP 32: Complete the Summary of Benefits task by filling the \"Payer Collected Pharmacy 1\",\"Payer Collected Pharmacy 2\",\"Payer Collected Pharmacy 3\" and Review and Send Summary of Benefits task to initiate the Triage Task and validate that user is automatically redirected to Correspondence creation page");
		bvPage.enterPharmacy1Details(alliancePharmacy.get(1));
		bvPage.enterPharmacy2Details(alliancePharmacy.get(2));
		bvPage.enterPharmacy3Details(alliancePharmacy.get(3));

		Logger("STEP 33: Save the details");
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		Logger("STEP 37: Verify \"Selected Specialty Pharmacy\" is auto populated");
		String selectedSP = triagePage.verifySelectedSP();

		String cpeURL = getCurrentPageURL();

		Logger("STEP 38: User Logout the Application.");
		documentsPage.logout();

		//// Traige completion
		Logger("STEP 39: Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		navigateToUrl(cpeURL);

		Logger("STEP 40: Navigate to Traige and verify flow has initiated");
		triagePage.checkTraigeIntiation();
		triagePage.checkTriageTaskInitiation();

		Logger("STEP 41: Click on Traige task");
		triagePage.clickOnTask();

		Logger("STEP 42: Verify task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(5));

		Logger("STEP 43: Verify review information and click on next button");
		triagePage.verifyReviewTask(selectedSP, SPtype.get(1), expedited.get(1));
		missingInformatioPage.clickNextButton();

		Logger("STEP 44: Verify order details task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));

		Logger("STEP 45: Enter order details and click on submit");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 46: Click on Triage button and verify task compltion status");
		triagePage.clickOnTraige();
		triagePage.checkTraigeTaskComplition();

		Logger("STEP 47: After Triage is completed, navigate to the Order object and validate that Order details are generated on Patient's name.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		triagePage.verifyOrderDetails(ExcelTestData.get(patientName));

		Logger("STEP 48: Click on Prescription and verify the status as active ");
		quickStartPage.clickOnQSOrderPrescription();
		triagePage.verifyMRStatus();
		quickStartPage.editPrescriptionStatus(mrStatus.get(1));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 50: Verify to start new Triage task");
		triagePage.clickOnStartNewService();
		triagePage.verifyServiceTitle();
		triagePage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		missingInformatioPage.clickNextButton();
		triagePage.selectReason();
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 51: Navigate to Traige and verify flow has initiated");
		triagePage.checkTraigeIntiation();
		triagePage.checkTriageTaskInitiation();

		Logger("STEP 52: Click on Traige task");
		triagePage.clickOnTask();

		Logger("STEP 53: Verify task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(5));

		Logger("STEP 54: Verify review information and click on next button");
		triagePage.verifyReviewTask(selectedSP, SPtype.get(1), expedited.get(1));
		missingInformatioPage.clickNextButton();

		Logger("STEP 55: Verify order details task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));

		Logger("STEP 56: Validate that records are not shown on Triage order details omniscripts");
		quickStartPage.verifyNoRecordMsg();

		Logger("STEP 57: User Logout the Application.");
		documentsPage.logout();

	}

	// description = "Patient Enrollement Pre-requisite for testcase IC9579-IC3422"
	public String PreReuisites_For_Triage_IC3422(String testCaseNo) throws Exception {

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String testCaseNumber = testCaseNo;

		String columnName[] = { "Diagnosis Code", "Preferred Specialty Pharmacy", "DUPIXENT MyWay",
				"Prescription 5B Quick Start" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "FALSE", "TRUE", "FALSE" };
		String removeColumnData[] = { "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax",
				"Prescription-B RefillCaptured", "Prescription-5B Dose" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(testCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(testCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(testCaseNumber);

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(testCaseNumber, functionality));
			updatepdf.updatePDFForm(testCaseNumber, functionality);
		}
		System.out.println(filePath.get());
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		refresh();
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInfoQN_No(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		return ID;
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE3422-SAT-TC02- Part-1 Validate Expedited Triage is marked
	 * as NO when Conditions are not met
	 * 
	 * @author Shanavaz Nishani , date- 11/14/2024
	 *         ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "ICARE3422-SAT-TC02- Part-1 Validate Expedited Triage is marked as NO when Conditions are not met", enabled = true)
	public void Triage04_IC3422_Validate_Expedited_Triage_is_marked_as_NO_when_Conditions_are_not_met()
			throws Exception {

		String TestCaseNumber = "TC4";

		String ID = PreReuisites_For_Triage_IC3422(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("STEP 3: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 3.1: Search CPE");
		homeportalPage.closeTabs();
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 4: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 4.1: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 4.3:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		homeportalPage.closeTabs();

		Logger("STEP 5: From App Launcher search for Medication Dispense");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(23), DocumentPage.class);
		assessmentTasksPage.verifyRecentlyViewList();
		refresh();
		careProgram.navigateToAllMedication();

		Logger("STEP 5.1: Check there is no Medication Dispense record created for the current CPE");
		String accountName = ExcelTestData.get(patientName);
		careProgram.checkMedicationRequestNotCreated(accountName);

		Logger("STEP 5.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 5.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 5.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		Logger("STEP 6: Open \"Review and Finalize Benefit\" assessment task from BV work order");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 7: Update \"Plan Type\" as any value other than \"Private Commercial\" and mandatory other fields from Member Plan section and click on save.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 8:Scroll to Coverage Benefit Section and Update these fields accordingly:Coverage Status='Covered' or 'PA Required' and Select Payer Collected SP 1 or 2 or 3 from these SPs as Alliance or Non- Allia\n"

				+ "Step 9 :Scroll down to Coverage Benefit Section and Update these fields accordingly: PA Outcome = Pending ");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(0), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(3));
		// select value for sppharmacy
		bvPage.enterPharmacy1Details(alliancePharmacy.get(0));
		bvPage.clickOnCoverageBenefitSave();
		Logger("Step 10: Click on Complete button on the bottom on saving both Member plan and Coverage benefit details");
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		String url = getCurrentPageURL();

		Logger("STEP 11: logout as BV user and login with Case Manager.");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("Step 12: Navigate to same CPE page created in above steps and Validate Triage is initiated");
		navigateToUrl(url);
		Thread.sleep(4000);
		triagePage.checkTraigeIntiation();

		Logger("Step 13: Open this WO record , in accordion named as Triage Validate there is Assessment task created with name \"Submit Order\"");
		triagePage.checkTriageTaskInitiation();
		careProgram.clickOnSubTask(triageSubTaskNames.get(0));

		Logger("STEP 14: while on \"Submit order\" Screen 1 check Expedited Triage (Yes/No) picklist is marked as No by system");
		String selectedSP = alliancePharmacy.get(0);
		triagePage.verifyReviewTask(selectedSP, SPtype.get(1), expedited.get(1));

		Logger("STEP 14.1: User Logout the Application.");
		documentsPage.logout();

		// Second CPE record Creation
		String TestCaseNumber2 = "TC16";

		String id2 = PreReuisites_For_Triage_IC3422(TestCaseNumber2);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber2);

		Logger("STEP 15: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 3.1: Search CPE");
		homeportalPage.closeTabs();
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 16: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 16.1: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 16.2:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 17: From App Launcher search for Medication Dispense");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(23), DocumentPage.class);
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllMedication();

		Logger("STEP 17.1: Check there is no Medication Dispense record created for the current CPE");
		careProgram.checkMedicationRequestNotCreated(accountName);

		Logger("STEP 17.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 17.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 17.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate1 = assessmentTasksPage.verifyAndAssignCPERecord(id2);
		assessmentTasksPage.openCPETask(createdDate1);

		Logger("STEP 18: Open \"Review and Finalize Benefit\" assessment task from BV work order");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 19: Update \"Plan Type as Private Commercial\" and mandatory other fields from Member Plan section and click on save.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 20:Scroll to Coverage Benefit Section and Update these fields accordingly:Coverage Status='Covered' or 'PA Required' and Select Payer Collected SP 1 or 2 or 3 from these SPs as Alliance or Non- Allia\n"
				+ "Step 21 :Scroll down to Coverage Benefit Section and Update these fields accordingly: PA Outcome = any value other than Pending ");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(0), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		// select value for sppharmacy
		bvPage.enterPharmacy1Details(alliancePharmacy.get(0));
		bvPage.clickOnCoverageBenefitSave();

		Logger("Step 22: Click on Complete button on the bottom on saving both Member plan and Coverage benefit details");
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		String url1 = getCurrentPageURL();

		Logger("STEP 23: logout as BV user and login with Case Manager.");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("Step 24: Navigate to same CPE page created in above steps and Validate Triage is initiated");
		navigateToUrl(url1);
		Thread.sleep(4000);
		triagePage.checkTraigeIntiation();

		Logger("Step 25: Open this WO record , in accordion named as Triage Validate there is Assessment task created with name \"Submit Order\"");
		triagePage.checkTriageTaskInitiation();
		careProgram.clickOnSubTask(triageSubTaskNames.get(0));

		Logger("STEP 26: while on \"Submit order\" Screen 1 check Expedited Triage (Yes/No) picklist is marked as No by system");
		String selectedSP1 = alliancePharmacy.get(0);
		triagePage.verifyReviewTask(selectedSP1, SPtype.get(1), expedited.get(1));

		Logger("STEP 26.1: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: Regression Triage to Pharmacy Automate ICARE-15651: SIT-TC01:
	 * To Validate Status Update on SP Order when Order Fax is Sent - Non Alliance
	 * (Correspondence Status is Success)
	 * 
	 * @author Shanavaz Nishani , date- 03/26/2025
	 *         ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "ICARE-11420: SIT-TC01: To Validate Status Update on SP Order when Order Fax is Sent - Non Alliance (Correspondence Status is Success)", enabled = true)
	public void Triage05_IC12240_To_Validate_Status_Update_on_SP_Order_when_Order_Fax_is_Sent_Non_Alliance_Correspondence_Status_is_Success()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC5";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "Pharmacy Fax", "DUPIXENT MyWay", "Preferred Specialty Pharmacy",
				"Office Fax" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "4253563101", "TRUE", "FALSE",
				"4253563101" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-requisite STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-requisite STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-requisite STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("Pre-requisite STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-requisite STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-requisite STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-requisite STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-requisite STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-requisite STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));
		String cpeUrl = getCurrentPageURL();
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
//		accountObject.navigateCareProgramEnrollee();
//		accountObject.cickOnCPERecord(cpeName);
//		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("Pre-requisite STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("Pre-requisite STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("Pre-requisite STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("Pre-requisite STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("Pre-requisite STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("Pre-requisites 19::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 20:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
//		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);
//
//		Logger("Pre-requisites 21: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("Pre-requisites 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);

		navigateToUrl(cpeUrl);
		// BV Initialization code starts here
		Logger("Pre-requisites 23: Verify BV Task is initiated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre-requisites 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		// Get CPE URL
		String cpeURL = getCurrentPageURL();

		Logger("Pre-requisites 28: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 1: Login to the UAT as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		Logger("STEP 2: Navigate to the CPE record created in above steps");
		navigateToUrl(cpeURL);

		Logger("Step 3: Complete Triage WO");
		triagePage.checkTraigeIntiation();
		triagePage.checkTriageTaskInitiation();
		careProgram.clickOnSubTask(triageSubTaskNames.get(0));
		missingInformatioPage.clickNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 3.1: Validate the  fields are populated on the Order created after Completing Triage WO. Status = Submitted, Order Type = Commercial, SP = Any Non-Alliance SP");
		triagePage.clickOnTraige();
		triagePage.checkTraigeTaskComplition();
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		triagePage.openOrderRec();
		triagePage.validateOrderDetailsValues("Order Type", "Commercial");
		triagePage.validateOrderDetailsValues("Status", "Submitted");
		triagePage.validateOrderDetailsValues("Alliance SP?", "Non-Alliance");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 4: Send Correspondence for \"DMW Non-Network Referral - SP Fax\" and Validate if Request Status = Success on generated Correspondence record.");

		docMgmt.clickOnCorrespondenceBotton();
		docMgmt.selectProcessName(processName.get(10));
		docMgmt.selectItemsToSend(TriageitemToSend.get(1));
		missingInformatioPage.clickNextButton();
		docMgmt.clickSendButtonUntilFinish();
		docMgmt.clickonFinishButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 5: Navigate to Order Record and open the most recent Commercial Order. Validate if Status field is updated to ‘Sent to SP’. ");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		triagePage.openOrderRec();
		refresh();
		// Status takes upto 10-20 mins to refect as Sent to SP
		Thread.sleep(900000);
		triagePage.validateOrderDetailsValues("Status", "Sent to SP");

		Logger("Step 6: User Logout the Application.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE15655 -Regression-TriageToPharm: Automate:SIT:TC01:To
	 * validate the Search Results for Alliance SP and Non Alliance SP
	 * 
	 * @author Shanavaz Nishani , date- 4/3/2025
	 *         ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "iCare-11090:SIT:TC01:To validate  the Search Results for Alliance SP  and Non Alliance SP", enabled = true)
	public void Traige06_IC12152_To_validate_the_Search_Results_for_Alliance_SP_and_Non_Alliance_SP() throws Exception {

		String TestCaseNumber = "TC6";
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "TRUE" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the UAT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 2.2:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 2.3:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 2.4:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 3.1: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 3.2:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 3.3:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectMedicalPayer();

		Logger("STEP 4 and 5: Validate that when searching for any Alliance SP, the search results display only the matching record available in the Care Program Specialty Pharmacy Network object");
		// insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		for (String AllianceSP : AllianceSP_List) {
			bvPage.veridyPharmacyValues(SPtype.get(1), PayerPharmacyFieldName.get(0), AllianceSP);
		}

		Logger("STEP 6: Now remove the Alliance SP Name from the field and Fill any Non- Alliance SP Name and Click on Search. Validate that the search results are coming for SPs from Account Specialty Pharmacies");
		bvPage.veridyPharmacyValues(SPtype.get(0), PayerPharmacyFieldName.get(0), "Automation Specialty Pharmacy");

		Logger("STEP 7 : Now Select a Specialty Pharmacy from the Search Result → Populate all the required Details in rest of the sections of the enrollment form and submit the form");
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7.1:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 7.2:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 7.3:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 7.4:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));
		String cpeUrl = getCurrentPageURL();
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

//		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
//		accountObject.navigateCareProgramEnrollee();
//		accountObject.cickOnCPERecord(cpeName);
//		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 7.5: User Logout the Application.");
		documentsPage.logout();

		Logger("Pre-requisite STEP 7.6 : Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("Pre-requisite STEP 7.7 : Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("Pre-requisite STEP 7.9 : Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 8 :Log out from the DIS user and Login as a BV user in the Org");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 9 :Navigate to the Care Program Enrollee object and open the latest CPE record");
		homeportalPage.closeTabs();
//		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);
//		
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);

		navigateToUrl(cpeUrl);
		// BV Initialization code starts here
		Logger("STEP 10: Click on Review and Finalize Benefit task present under My task section");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 11 : Fill all the mandatory fields in the member plan section and Coverage Benefit Section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));

		Logger("STEP 11.1 and 12 : Now Click on the \"Payer Collected Pharmacy #1\" field and Search for Any of the below Alliance SP -> Validate that on searching for any Alliance SP, the search results display only the matching record available in the Care Program Specialty Pharmacy Network object");
		for (String AllianceSP : AllianceSP_List) {
			bvPage.veridyPharmacyValues(SPtype.get(1), PayerPharmacyFieldName.get(1), AllianceSP);
		}

		Logger("STEP 13: Now remove the Alliance SP Name from the field and Fill any Non- Alliance SP Name and Click on Search, Validate that the matching search results are coming for SPs from Account Specialty Pharmacies");
		bvPage.veridyPharmacyValues(SPtype.get(0), PayerPharmacyFieldName.get(1), "Automation Specialty Pharmacy");

		Logger("STEP 14: Repeat the Step 12 and 13 in the Payer Collected Pharmacy #2 and Payer Collected Pharmacy #3 field as well");
		// Payer pharmacy2
		for (String AllianceSP : AllianceSP_List) {
			bvPage.veridyPharmacyValues(SPtype.get(1), PayerPharmacyFieldName.get(2), AllianceSP);
		}
		bvPage.veridyPharmacyValues(SPtype.get(0), PayerPharmacyFieldName.get(2), "Automation Specialty Pharmacy");
		// Payer pharmacy3
		for (String AllianceSP : AllianceSP_List) {
			bvPage.veridyPharmacyValues(SPtype.get(1), PayerPharmacyFieldName.get(3), AllianceSP);
		}
		bvPage.veridyPharmacyValues(SPtype.get(0), PayerPharmacyFieldName.get(3), "Automation Specialty Pharmacy");

		Logger("STEP 15: Populate the Payer Collected Pharmacy #1, Payer Collected Pharmacy #2 and Payer Collected Pharmacy #3 fields with Alliance SP selected");
		bvPage.enterPharmacy1Details(AllianceSP_List.get(0));
		bvPage.enterPharmacy2Details(AllianceSP_List.get(1));
		bvPage.enterPharmacy3Details(AllianceSP_List.get(2));

		Logger("STEP 15.1: Click on Complete Button");
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		String url = getCurrentPageURL();

		Logger("STEP 16: logout as BV user Now login as a CM user.");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("Step 17: Open the CPE record");
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("Step 17.1:  Click on the Triage Task → In the Review Screen all fields will be Pre populated--> click on Next");
		triagePage.clickOnTraige();
		triagePage.checkTriageTaskInitiation();
		careProgram.clickOnSubTask(triageSubTaskNames.get(0));
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(5));
		missingInformatioPage.clickNextButton();

		Logger("STEP 17.2:  select a MR record and attachment and click on Submit");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("Step 18: Navigate to the Order related list on CPE and Open the latest order record ");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		triagePage.openOrderRec();
		refresh();

		Logger("Step 19: Validate that in the Order record, Alliance SP name is populated, and Order is successfully sent through integration");
		triagePage.validateOrderDetailsValues("Alliance SP?", "Alliance");
		triagePage.validateOrderDetailsValues("Status", "Submitted");

		Logger("Step 20: Logout From the Application");
		documentsPage.logout();

	}

	public String TriageRXManagementWorkflow_PatientEnrollment_Prerequisites(String testCaseNo) throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String testCaseNumber = testCaseNo;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "FALSE" };
		String removeColumnData[] = { "Specialty Pharmacy Name",
				"Prescription-B RefillCaptured", "Prescription-5B Dose" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(testCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(testCaseNumber, columnName, columnValue);
		}

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement for TestCaseNumber: "
				+ testCaseNumber);
		ExcelTestData = excel.getExcelInputData(testCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(testCaseNumber, functionality));
			updatepdf.updatePDFForm(testCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 1.2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.1:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.2:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.3:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		refresh();
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(specialtyPharmacyName),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		String url = getCurrentPageURL();

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();

		Logger("STEP 16: Search CPE record");
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		return url;

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE 5116SIT_Triage/RX Management_SF - Scenario 3 - TC01-
	 * Alliance SP is selected as HCP Mandated SP.
	 * 
	 * @author Trupti
	 *         ====================================================================================================================
	 * @throws Exception
	 */

	@Test(description = "SIT_Triage/RX Management_SF - Scenario 3 - TC01- Alliance SP is selected as HCP Mandated SP.", enabled = true)
	public void Traige07_IC5116_Alliance_SP_is_selected_as_HCP_Mandated_SP() throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC7";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "K20.0 - Eosinophilic esophagitis", "TRUE", "TRUE" };
		String removeColumnData[] = { "Prescription-B RefillCaptured", "Prescription-5B Dose" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(4).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("EOE");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 1.2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate to the Recently view ");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 2.2:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.2:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy(alliancePharmacy.get(0));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11: Verify account is created ");
		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		String cpeUrl = getCurrentPageURL();

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
//		accountObject.navigateCareProgramEnrollee();
//		accountObject.verifyAndClickOnCPERecord(cpeName);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();

		Logger("STEP 16: search the CPE Record.");
		accountObject.globalSearch(searchFilter.get(1), cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 20: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		navigateToUrl(cpeUrl);
//		String urll="https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf00000080fZCAQ/view";
//		navigateToUrl(urll);
//		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);

		// BV Initialization code starts here
		Logger("STEP 23: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("STEP 24: verify to select Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));

		Logger("STEP 26: Validate that the HCP Preferred Specialty Pharmacy field on coverage benefit section should be fetched from Enrollment form.");
		bvPage.verifyHCPPreferredSPInBenifitTask(alliancePharmacy.get(0));

		Logger("STEP 28: Save the details");
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		Logger("STEP 29: Verify that the Specialty Pharmacy Type field is auto populating with the value as Alliance.");
		accountObject.clickOnTab(tabsName.get(0));
		triagePage.verifySPType(SPtype.get(1));

		Logger("STEP 30: Validate that the HCP Preferred Specialty Pharmacy field on coverage benefit section should be fetched from Enrollment form.");
		String selectedSP = triagePage.verifySelectedPharmacy(alliancePharmacy.get(0));

		// Get CPE URL
		String cpeURL = getCurrentPageURL();

		Logger("STEP 31: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 32: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(cpeURL);

		Logger("STEP 33: Navigate to Traige and verify flow has initiated");
		triagePage.checkTraigeIntiation();
		triagePage.checkTriageTaskInitiation();

		Logger("STEP 34: Click on Traige task");
		triagePage.clickOnTask();

		Logger("STEP 35: Verify task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(5));

		Logger("STEP 36: Verify review information and validate that the Expedited field is marked as no. click on next button");
		triagePage.verifyReviewTask(selectedSP, SPtype.get(1), expedited.get(1));
		missingInformatioPage.clickNextButton();

		Logger("STEP 37: Verify order details task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));

		Logger("STEP 38: Enter order details and click on submit");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 39: Click on Triage button and verify task compltion status");
		triagePage.clickOnTraige();
		triagePage.checkTraigeTaskComplition();

		Logger("STEP 40: After Triage is completed, navigate to the Order object and validate that Order details are generated on Patient's name.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		triagePage.verifyOrderDetails(ExcelTestData.get(patientName));

		Logger("STEP 41: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE-5104-SAT-TC02- Alliance or Non-Alliance SP is selected as
	 * HCP Mandated SP and Expedited Triage is marked as Yes.
	 * 
	 * @author Samarth Sahu
	 *         ====================================================================================================================
	 * @throws Exception
	 */

	@Test(description = "TC03- Alliance or Non-Alliance SP is selected as HCP Mandated SP and Expedited Triage is marked as Yes.", enabled = true)
	public void Traige08_IC5104_AllianceNonAlliance_SP_SelectedAs_HCP() throws Exception {

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String testCaseNumber = "TC8";

		String columnName[] = { "Diagnosis Code", "Preferred Specialty Pharmacy", "DUPIXENT MyWay" };
		String columnValue[] = { "L28.1 - Prurigo nodularis", "TRUE", "TRUE" };
		String removeColumnData[] = { "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax",
				"Prescription-B RefillCaptured", "Prescription-5B Dose" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(testCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(testCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(testCaseNumber);

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Prurigo Nodularis");
			filePath.set(updatepdf.PDFCreation(testCaseNumber, functionality));
			updatepdf.updatePDFForm(testCaseNumber, functionality);
		}
		System.out.println(filePath.get());
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("STEP 1:Login to  QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 5:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		refresh();
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(1),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy(alliancePharmacy.get(0));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInfoQN_No(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));
		String cpeUrl = getCurrentPageURL();
		accountObject.clickOnTab(tabsName.get(1));
		
		Logger("STEP 17: Verify Care program enrollee record is linked to account ");
//		accountObject.navigateCareProgramEnrollee();
//		accountObject.cickOnCPERecord(cpeName);
//		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 20: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();

		Logger("STEP 21:  Verify recently view list is displayed and search the CPE Record.");
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 22: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 23: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 24:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		
		Logger("STEP 25:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		navigateToUrl(cpeUrl);
//		Logger("STEP 26: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 27: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);

		Logger("STEP 28: Verify BV Task is initiated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 29: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 30: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(3));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 32: Verify that the any of the three Payer Collected Pharmacy is assigned as a Patient’s SP randomly.");
		accountObject.clickOnTab(tabsName.get(0));
		triagePage.verifySelectedPharmacy(alliancePharmacy.get(0));

		String selectedSP = triagePage.verifySelectedPharmacy(alliancePharmacy.get(0));

		String url = getCurrentPageURL();

		Logger("STEP 33: User Logout the Application.");
		documentsPage.logout();

		//// Traige
		Logger("STEP 34: Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		navigateToUrl(url);
		Thread.sleep(4000);

		// Triage work order
		Logger("STEP 35: Open Triage work order");
		careProgram.clickOnWorkOrderTask(workOrderName.get(4));
		careProgram.clickOnMainTask(triageMainTaskNames.get(0));
		careProgram.clickOnSubTask(triageSubTaskNames.get(0));

		Logger("STEP 36: Enter order details and click on submit");
		triagePage.verifyReviewTask(selectedSP, SPtype.get(1), expedited.get(0));
		missingInformatioPage.clickNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 37: Click on Triage button and verify task compltion status");
		triagePage.clickOnTraige();
		triagePage.checkTraigeTaskComplition();

		Logger("STEP 38: After Triage is completed, navigate to the Order object and validate that Order details are generated on Patient's name.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		triagePage.verifyOrderDetails(ExcelTestData.get(patientName));

		Logger("STEP 39: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE4939-Non-Alliance SP is selected as per Random selectio
	 * 
	 * @author Trupti
	 *         ====================================================================================================================
	 * @throws Exception
	 */

	@Test(description = "SIT_Triage/RX Management_SF-Scenario 2- TC04- Non-Alliance SP is selected as per Random selection.", enabled = true, priority = 11)
	public void Traige09_IC4939_Non_Alliance_SP_is_selected_as_per_Random_selection() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String testCaseNumber = "TC9";
//		String ID = TriageRXManagementWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);
//		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		
		//
		String columnName[] = { "Diagnosis Code", "Preferred Specialty Pharmacy", "DUPIXENT MyWay" };
		String columnValue[] = { "L28.1 - Prurigo nodularis", "TRUE", "TRUE" };
		String removeColumnData[] = { "Specialty Pharmacy Name",
				"Prescription-B RefillCaptured", "Prescription-5B Dose" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(testCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(testCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(testCaseNumber);

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Prurigo Nodularis");
			filePath.set(updatepdf.PDFCreation(testCaseNumber, functionality));
			updatepdf.updatePDFForm(testCaseNumber, functionality);
		}
		System.out.println(filePath.get());
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("STEP 1:Login to  QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 5:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		refresh();
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(1),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy(alliancePharmacy.get(0));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInfoQN_No(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));
		String cpeUrl = getCurrentPageURL();
		accountObject.clickOnTab(tabsName.get(1));
		
//		Logger("STEP 17: Verify Care program enrollee record is linked to account ");
//		accountObject.navigateCareProgramEnrollee();
//		accountObject.cickOnCPERecord(cpeName);
//		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();
		
		Logger("STEP 19: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 20: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();

		Logger("STEP 21:  Verify recently view list is displayed and search the CPE Record.");
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 22: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 23: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);
		
//		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);
		
		navigateToUrl(cpeUrl);

		// BV Initialization code starts here
		Logger("STEP 5: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("STEP 6: verify to select Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));

		Logger("STEP 8: Validate that the HCP Preferred Specialty Pharmacy field on coverage benefit section is blank.");
//		bvPage.verifyHCPPreferredSPIsBlank();
		
		Logger("STEP 10: Select Payer Collected .");
		bvPage.enterPharmacy1Details(nonAlliancePharmacy.get(0));
		bvPage.enterPharmacy2Details(nonAlliancePharmacy.get(1));
		bvPage.enterPharmacy3Details(nonAlliancePharmacy.get(2));

		Logger("STEP 11: Save the details");
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		Logger("STEP 13: Verify that the Specialty Pharmacy Type field is auto populating with the value as Non-Alliance.");
		accountObject.clickOnTab(tabsName.get(0));
//		triagePage.verifySPType(SPtype.get(0));

		Logger("STEP 14: Verify that the any of the three Payer Collected Pharmacy is assigned as a Patient’s SP randomly.");
		String selectedSP = triagePage.verifySelectedPharmacy(nonAlliancePharmacy.get(0), nonAlliancePharmacy.get(1),
				nonAlliancePharmacy.get(2));

		// Get CPE URL
		String cpeURL = getCurrentPageURL();

		Logger("STEP 15: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 16: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(cpeURL);

		Logger("STEP 17: Navigate to Traige and verify flow has initiated");
		triagePage.checkTraigeIntiation();
		triagePage.checkTriageTaskInitiation();

		Logger("STEP 18: Click on Traige task");
		careProgram.clickOnSubTask(triageSubTaskNames.get(0));
		triagePage.clickOnTask();

		Logger("STEP 19: Verify task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(5));

		Logger("STEP 20: Verify review information and validate that the Expedited field is marked as no. click on next button");
//		triagePage.verifyReviewTask(selectedSP, SPtype.get(0), expedited.get(1));
		missingInformatioPage.clickNextButton();

		Logger("STEP 21: Verify order details task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));

		Logger("STEP 22: Enter order details and click on submit");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 23: Click on Triage button and verify task compltion status");
		careProgram.clickOnWorkOrderTask(workOrderName.get(4));
		triagePage.checkTraigeTaskComplition();

		Logger("STEP 24: After Triage is completed, navigate to the Order object and validate that Order details are generated on Patient's name.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		triagePage.verifyOrderDetails(ExcelTestData.get(patientName));

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE 5119-Non-Alliance SP is selected as HCP Mandated SP
	 * 
	 * @author Kavyashree
	 *         ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "SIT_Triage/RX Management_SF - Scenario 3- TC02- Non-Alliance SP is selected as HCP Mandated SP.", enabled = true)
	public void Traige10_IC5119_Non_Alliance_SP_is_selected_as_HCP_Mandated_SP() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String testCaseNumber = "TC16";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "TRUE" };
		String removeColumnData[] = { "Prescription-B RefillCaptured", "Prescription-5B Dose" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(testCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(testCaseNumber, columnName, columnValue);

		}
		ExcelTestData = excel.getExcelInputData(testCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(testCaseNumber, functionality));
			updatepdf.updatePDFForm(testCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 1.2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate to the Recently view ");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 2.2:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.2:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(specialtyPharmacyName),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Search CPE record");
		homeportalPage.closeTabs();
		accountObject.globalSearch(searchFilter.get(1), cpeName);
		String cpeUrl = getCurrentPageURL();

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 20: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

//		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);

		navigateToUrl(cpeUrl);
		// BV Initialization code starts here
		Logger("STEP 23: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("STEP 24: verify to select Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));

		Logger("STEP 26: Save the details");
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		Logger("STEP 29: Verify that the Specialty Pharmacy Type field is auto populating with the value as Non-Alliance.");
		accountObject.clickOnTab(tabsName.get(0));
//		triagePage.verifySPType(SPtype.get(0));

		Logger("STEP 30: Verify that SP1 Specialty Pharmacy which we have given at the time of Enrollment form submission, is selected and assigned to the Patient.");
		String selectedSP = triagePage.verifySelectedPharmacy(ExcelTestData.get(specialtyPharmacyName));

		// Get CPE URL
		String cpeURL = getCurrentPageURL();

		Logger("STEP 31: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 32: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(cpeURL);

		Logger("STEP 33: Navigate to Traige and verify flow has initiated");
		triagePage.checkTraigeIntiation();
		triagePage.checkTriageTaskInitiation();

		Logger("STEP 34: Click on Traige task");
		triagePage.clickOnTask();

		Logger("STEP 35: Verify task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(5));

		Logger("STEP 36: Verify review information and validate that the Expedited field is marked as no. click on next button");
//		triagePage.verifyReviewTask(selectedSP, SPtype.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 37: Verify order details task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));

		Logger("STEP 38: Enter order details and click on submit");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 39: Click on Triage button and verify task compltion status");
		triagePage.clickOnTraige();
		triagePage.checkTraigeTaskComplition();

		Logger("STEP 40: After Triage is completed, navigate to the Order object and validate that Order details are generated on Patient's name.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		triagePage.verifyOrderDetails(ExcelTestData.get(patientName));

		Logger("STEP 41: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE 5101-Alliance or Non-Alliance SP is selected as Payer
	 * Mandated SP and Expedited Triage is marked as Yes.
	 * 
	 * @author Shanavaz Nishani
	 *         ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "Triage/RX Management_SF - Scenario 1- TC03- Alliance or Non-Alliance SP is selected as Payer Mandated SP and Expedited Triage is marked as Yes.", enabled = true)
	public void Traige11_IC5101_SIT_TriageManagement_Alliance_or_NonAlliance_SP_is_selected_as_Payer_Mandated_SP()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC11";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L28.1 - Prurigo nodularis", "TRUE", "FALSE" };
		String removeColumnData[] = { "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax",
				"Prescription-B RefillCaptured", "Prescription-5B Dose" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Prurigo Nodularis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.1:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.2:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.3:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(1),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11: Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);

		Logger("STEP 12: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: search CPE Record");
		homeportalPage.closeTabs();
		accountObject.globalSearch(searchFilter.get(1), cpeName);
		String cpeUrl =getCurrentPageURL();
		
		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 20: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		navigateToUrl(cpeUrl);
//		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);

		// BV Initialization code starts here
		Logger("STEP 23: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("STEP 24: verify to select Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));

		Logger("STEP 26: Validate that the HCP Preferred Specialty Pharmacy field on coverage benefit section is blank.");
		bvPage.verifyHCPPreferredSPIsBlank();

		Logger("STEP 28: Select Payer Collected .");
		bvPage.enterPharmacy1Details(nonAlliancePharmacy.get(0));

		Logger("STEP 28: Save the details");
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		Logger("STEP 30: Verify that the Specialty Pharmacy Type field is auto populating with the value as Alliance.");
		accountObject.clickOnTab(tabsName.get(0));
//		triagePage.verifySPType(SPtype.get(1));

		Logger("STEP 31: Verify \"Selected Specialty Pharmacy\" is auto populated");
		String selectedSP = triagePage.verifySelectedSP();

		String BVUrl = getCurrentPageURL();

		Logger("STEP 32: User Logout the Application.");
		documentsPage.logout();

		//// Triage completion
		Logger("STEP 33: Login to the QA_SIT Org as 'CM user'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		navigateToUrl(BVUrl);

		Logger("STEP 34: Navigate to Traige and verify flow has initiated");
		triagePage.checkTraigeIntiation();
		triagePage.checkTriageTaskInitiation();

		Logger("STEP 35: Click on Traige task");
		triagePage.clickOnTask();

		Logger("STEP 36: Verify task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(5));

		Logger("STEP 37: Verify review information and click on next button");
//		triagePage.verifyReviewTask(selectedSP, SPtype.get(1), expedited.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 38: Verify order details task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));

		Logger("STEP 39: Enter order details and click on submit");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 40: Click on Triage button and verify task compltion status");
		triagePage.clickOnTraige();
		triagePage.checkTraigeTaskComplition();

		Logger("STEP 41: After Triage is completed, navigate to the Order object and validate that Order details are generated on Patient's name.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		triagePage.verifyOrderDetails(ExcelTestData.get(patientName));

		Logger("STEP 43: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE 5096-Non-Alliance SP is selected as Payer Mandated SP.
	 * 
	 * @author Kavyashree
	 *         ====================================================================================================================
	 * @throws Exception
	 */

	@Test(description = "SIT_Triage/RX Management_SF - Scenario 1- TC02- Non-Alliance SP is selected as Payer Mandated SP.", enabled = true)
	public void Traige12_IC5096_Non_Alliance_SP_is_selected_as_Payer_Mandated_SP() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC12";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L28.1 - Prurigo nodularis", "TRUE", "FALSE" };
		String removeColumnData[] = { "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax",
				"Prescription-B RefillCaptured", "Prescription-5B Dose" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Prurigo Nodularis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.1:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.2:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.3:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(1),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Search CPE record");
		homeportalPage.closeTabs();
		accountObject.globalSearch(searchFilter.get(1), cpeName);
		String url = getCurrentPageURL();

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 20: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

//		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);
		navigateToUrl(url);

		// BV Initialization code starts here
		Logger("STEP 23: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("STEP 24: verify to select Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));

		Logger("STEP 26: Validate that the HCP Preferred Specialty Pharmacy field on coverage benefit section is blank.");
		bvPage.verifyHCPPreferredSPIsBlank();

		Logger("STEP 28: Select Payer Collected .");
		bvPage.enterPharmacy1Details(nonAlliancePharmacy.get(3));

		Logger("STEP 29: Save the details");
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		Logger("STEP 30: Verify that the Specialty Pharmacy Type field is auto populating with the value as Non-Alliance.");
		accountObject.clickOnTab(tabsName.get(0));
		triagePage.verifySPType(SPtype.get(0));

		Logger("STEP 31: Verify that SP1 (non-Alliance SP provided in Coverage benefit section of BV 1st task) will be assigned to the patient.");
		String selectedSP = triagePage.verifySelectedPharmacy(nonAlliancePharmacy.get(3));

		String cpeURL = getCurrentPageURL();

		Logger("STEP 31: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 32: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(cpeURL);

		Logger("STEP 32: Navigate to Traige and verify flow has initiated");
		triagePage.checkTraigeIntiation();
		triagePage.checkTriageTaskInitiation();

		Logger("STEP 33: Click on Traige task");
		triagePage.verifyAndclickOnTask();

		Logger("STEP 34: Verify task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(5));

		Logger("STEP 35: Verify review information and validate that the Expedited field is marked as no. click on next button");
//		triagePage.verifyReviewTask(selectedSP, SPtype.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 36: Verify order details task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));

		Logger("STEP 37: Enter order details and click on submit");
		quickStartPage.selectOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		Thread.sleep(4000);
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 38: Click on Triage button and verify task compltion status");
		triagePage.clickOnTraige();
		triagePage.verifyTraigeTaskComplition();

		Logger("STEP 39: After Triage is completed, navigate to the Order object and validate that Order details are generated on Patient's name.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		triagePage.verifyOrderDetails(ExcelTestData.get(patientName));

		Logger("STEP 40: User Logout the Application.");
		documentsPage.logout();

	}

	@Test(description = "SIT_Triage/RX Management_SF - Scenario 2- TC05- Non-Alliance SP is selected as per Random selection.", enabled = true)
	public void Traige13_IC5478_SIT_TriageManagement_Non_Alliance_SP_is_selecte_as_per_Random_selection()
			throws Exception {

		String TestCaseNumber = "TC13";

		// Prerequisites
		String cpeUrl = TriageRXManagementWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("STEP 1: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		navigateToUrl(cpeUrl);
//		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);

		// BV Initialization code starts here
		Logger("STEP 5: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("STEP 6: verify to select Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(0), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));

		Logger("STEP 8: Validate that the HCP Preferred Specialty Pharmacy field on coverage benefit section is blank.");
		bvPage.verifyHCPPreferredSPIsBlank();

		Logger("STEP 10: Select Payer Collected .");
		bvPage.clickOnSearchButton();
		bvPage.enterPharmacy2Details(nonAlliancePharmacy.get(0));
		bvPage.enterPharmacy3Details(nonAlliancePharmacy.get(1));

		Logger("STEP 11: Save the details");
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		Logger("STEP 14: Verify that the Specialty Pharmacy Type field is auto populating with the value as Non-Alliance.");
		accountObject.clickOnTab(tabsName.get(0));
		refresh();
		triagePage.verifySPType(SPtype.get(0));

		Logger("STEP 15: Verify that the any of the three Payer Collected Pharmacy is assigned as a Patient’s SP randomly.");
		String selectedSP = triagePage.verifySelectedPharmacy(nonAlliancePharmacy.get(0), nonAlliancePharmacy.get(1),
				null);

		// Get CPE URL
		String cpeURL = getCurrentPageURL();

		Logger("STEP 16: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 17: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(cpeURL);

		Logger("STEP 16: Navigate to Traige and verify flow has initiated");
		triagePage.checkTraigeIntiation();
		triagePage.checkTriageTaskInitiation();

		Logger("STEP 17: Click on Traige task");
		careProgram.clickOnSubTask(triageSubTaskNames.get(0));
		triagePage.clickOnTask();

		Logger("STEP 18: Verify task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(5));

		Logger("STEP 19: Verify review information and validate that the Expedited field is marked as no. click on next button");
		triagePage.verifyReviewTask(selectedSP, SPtype.get(0), expedited.get(1));
		missingInformatioPage.clickNextButton();

		Logger("STEP 20: Verify order details task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));

		Logger("STEP 21: Enter order details and click on submit");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 22: Click on Triage button and verify task compltion status");
		triagePage.clickOnTraige();
		triagePage.checkTraigeTaskComplition();

		Logger("STEP 23: After Triage is completed, navigate to the Order object and validate that Order details are generated on Patient's name.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		triagePage.verifyOrderDetails(ExcelTestData.get(patientName));

		Logger("STEP 24: User Logout the Application.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE 5080-Alliance SP is selected as Payer Mandated SP.
	 * 
	 * @author Shanavaz Nishani
	 *         ====================================================================================================================
	 * @throws Exception
	 */

	@Test(description = "Triage/RX Management_SF - Scenario 1- TC01- Alliance SP is selected as Payer Mandated SP.", enabled = true)
	public void Traige14_IC5080_SIT_TriageManagement_Alliance_Selected_as_Payer_Mandated_SP() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC14";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "TRUE" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.1:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.2:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.3:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy(alliancePharmacy.get(1));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11: Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		String cpeUrl = getCurrentPageURL();

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 12: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();

		Logger("STEP 16:  Search CPE");
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 20: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		navigateToUrl(cpeUrl);
//		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		assessmentTasksPage.navigateToAllBVWorklist();
//
//		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
//		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
//		assessmentTasksPage.openCPETask(createdDate);

		// BV Initialization code starts here
		Logger("STEP 23: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("STEP 24: verify to select Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));

		Logger("STEP 26: Validate that the HCP Preferred Specialty Pharmacy field on coverage benefit section Contains Walsgreen record.");
		bvPage.verifyHCPPreferredSPInBenifitTask(alliancePharmacy.get(1));

		Logger("STEP 28: Select Payer Collected .");
		bvPage.enterPharmacy1Details(alliancePharmacy.get(0));

		Logger("STEP 28: Save the details");
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		refresh();

		Logger("STEP 31: Verify that the Specialty Pharmacy Type field is auto populating with the value as Alliance.");
		accountObject.clickOnTab(tabsName.get(0));
		triagePage.verifySPType(SPtype.get(1));

		Logger("STEP 32: Verify \"Selected Specialty Pharmacy\" is auto populated");
		String selectedSP = triagePage.verifySelectedPharmacy(alliancePharmacy.get(0));

		WebDriver driver = BaseTest.getWebDriver();
		String BVUrl = driver.getCurrentUrl();

		Logger("STEP 33: User Logout the Application.");
		documentsPage.logout();

		//// Traige completion
		Logger("STEP 34: Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		navigateToUrl(BVUrl);

		Logger("STEP 35: Navigate to Traige and verify flow has initiated");
		triagePage.checkTraigeIntiation();
		triagePage.checkTriageTaskInitiation();

		Logger("STEP 36: Click on Traige task");
		triagePage.clickOnTask();

		Logger("STEP 37: Verify task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(5));

		Logger("STEP 38: Verify review information and click on next button");
		triagePage.verifyReviewTask(selectedSP, SPtype.get(1), expedited.get(1));
		missingInformatioPage.clickNextButton();

		Logger("STEP 39: Verify order details task is loaded");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));

		Logger("STEP 40: Enter order details and click on submit");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 41: Click on Triage button and verify task compltion status");
		triagePage.clickOnTraige();
		triagePage.checkTraigeTaskComplition();

		Logger("STEP 42: After Triage is completed, navigate to the Order object and validate that Order details are generated on Patient's name.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		triagePage.verifyOrderDetails(ExcelTestData.get(patientName));

		Logger("STEP 43: User Logout the Application.");
		documentsPage.logout();

	}
}
