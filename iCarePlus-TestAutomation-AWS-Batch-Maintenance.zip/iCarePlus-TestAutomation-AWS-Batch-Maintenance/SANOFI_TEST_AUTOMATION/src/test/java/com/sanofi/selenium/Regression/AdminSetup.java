package com.sanofi.selenium.Regression;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import org.junit.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.CopayFlow;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PAPPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.pages.HealthcareAccountSearch;
import com.sanofi.selenium.utils.ReadExcel;
import com.sanofi.selenium.pages.CareTeamAssignment;

public class AdminSetup extends BaseTest {
	public static String PatientName, PatientDoB, PatientEmail, CMName, CPEURL, existingCPEURL;

	private static ThreadLocal<String> filePath = new ThreadLocal<>();
	public String filePath2;
	public ReadExcel excel;
	public String fileName;
	String functionality = "AdminSetup";

	public static double getRandomNumber(double min, double max) {
		double x = (int) (Math.random() * ((max - min) + 1)) + min;
		return x;
	}

	double randomNum = getRandomNumber(1111, 9999);

	@BeforeMethod
	public void setUp() {
		try {
			utilityPage = GetInstance(Utility_Function.class);
			insuranceinfo = GetInstance(InsuranceInformation.class);
			diagnosisinformation = GetInstance(DiagnosisInfo.class);
			prescriptioninformation = GetInstance(PrescriptionInformation.class);
			updatepdf = GetInstance(UpdatePDF.class);
			patientSearch = GetInstance(PatientSearchPage.class);
			patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
			prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
			formConfirmation = GetInstance(FormConfirmation.class);
			accountObject = GetInstance(AccountObject.class);
			documentsPage = GetInstance(DocumentPage.class);
			generateTestData = GetInstance(GenerateTestData.class);
			excelDataUpdate = GetInstance(ExcelDataUpdate.class);
			bvPage = GetInstance(BenefitVerificationPage.class);
			paAppealsPage = GetInstance(PAAndAppealsPage.class);
			iapPage = GetInstance(IAPPage.class);
			uploadDocs = GetInstance(UploadDocument.class);
			assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
			missingInformatioPage = GetInstance(MissingInformatioPage.class);
			careProgram = GetInstance(CareProgramEnrolleePage.class);
			docMgmt = GetInstance(DocumentManagementPage.class);
			sheetName = "AdminSetup";
			excel = new ReadExcel(sheetName);
			dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
			uploadDocs = GetInstance(UploadDocument.class);
			triagePage = GetInstance(TriagePage.class);
			quickStartPage = GetInstance(QuickStartPage.class);
			hcAccountSearch = GetInstance(HealthcareAccountSearch.class);
			papPage = GetInstance(PAPPage.class);
			copayFlow = GetInstance(CopayFlow.class);
			careTeamAsgn = GetInstance(CareTeamAssignment.class);
			docMgmt = GetInstance(DocumentManagementPage.class);
			System.out.println("All GetInstance calls succeeded in setUp().");
		} catch (Exception | Error e) {
			System.err.println("Exception in AdminSetup setUp(): " + e.getMessage());
			e.printStackTrace();
			throw new RuntimeException("setUp failed in AdminSetup", e);
		}
	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	@Test(description = "SIT_Prior Authorization Workflow Patient Enrollment Prerequisites", enabled = true)
	public String AdminSetup_PatientEnrollment_Prerequisites_AtopicDermatitis(String testcaseNumber) throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "State", "Zip", "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy",
				"Prescription 5B Quick Start" };
		String columnValue[] = { "Alaska", "99501", "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE", "TRUE" };


		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();
		refresh();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		return ID;
	}

	@Test(description = "SIT_FreeGoods Workflow Patient Enrollment Prerequisites", enabled = true)
	public String AdminSetup_PatientEnrollment_Prerequisites_DMWAsthma(String testcaseNumber) throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Diagnosis Code", "DUPIXENT MyWay",
				"Preferred Specialty Pharmacy" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE",
				"FALSE" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		return CPEURL;

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5258 Search RCM Accounts within iCC+ [Non-Enrollment]
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Search RCM Accounts within iCC+ [Non-Enrollment]", enabled = true)
	public void AS01_IC5258_Search_RCM_Accounts_within_iCC() throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC1";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Prescriber Name", "Specialty", "Prescriber NPI", "Site/facility name", "Office Fax",
				"Prescriber Zip", "Specialty Pharmacy Name", "Rx Payer Name" };
		String columnValue[] = { "Automation HCP", "ALLERGY", "4755212702", "Automation HCO", "1819190187",
				"18911", "Automation Correspondence SP", "TestAutomation Payer Pharmacy" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 2: Open ICARE Connect App from the App launcher.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(12), DocumentPage.class);

		Logger("STEP 3: Validate \"Healthcare Account Search\" screen from the Header Tab within iCC+ to initiate a search on RCM managed accounts (HCP, HCO, SP, Payer).");
		refresh();
		hcAccountSearch.verifyAccountSearchPage();

		Logger("STEP 4: Validate Radio button for HCP, HCO, SP and Payer search present on Healthcare Account Search Screen.");
		String[] buttonsName = { "Payer", "HCP", "SP", "HCO" };
		for (String buttonName : buttonsName) {
			hcAccountSearch.validateSearchButtons(buttonName);
		}

		Logger("STEP 5: Click on HCP button → Validate below Search Criteria for HCP: (Account Name) AND one of the following → Click on Search");
		hcAccountSearch.clickOnButton(buttonsName[1]);
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];
		String[] hcpSearchCriteria = { preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI) };
		hcAccountSearch.validateHCPSearchCriteria(hcpSearchCriteria);
		hcAccountSearch.clickOnHCPSearchButton();
		hcAccountSearch.validateHCPSearchResult(hcpSearchCriteria);

		Logger("STEP 6: Click on HCO button → Validate below Search Criteria for HCO: (Account Name) AND (Email OR Fax) AND (Billing Zip/Postal Code) OR (Facility Tax ID) → Click on Search");
		hcAccountSearch.clickOnButton(buttonsName[3]);
		String[] hcoSearchCriteria = { ExcelTestData.get(sitefacilityname), ExcelTestData.get(officeFax) };
		hcAccountSearch.validateHCOSearchCriteria(hcoSearchCriteria, ExcelTestData.get(prescriberZip));
		hcAccountSearch.clickOnHCOSearchButton();
		hcAccountSearch.validateHCOSearchResult(hcoSearchCriteria);

		Logger("STEP 7: Click on SP button → Validate below Search Criteria for SP → Click on Search");
		hcAccountSearch.clickOnButton(buttonsName[2]);
		hcAccountSearch.validateSPSearchCriteria(ExcelTestData.get(specialtyPharmacyName));
		hcAccountSearch.clickOnSPSearchButton();
		hcAccountSearch.validateSPSearchResult(ExcelTestData.get(specialtyPharmacyName));

		Logger("STEP 8: Click on Payer button → Validate below Search Criteria for Payer → Click on Search");
		hcAccountSearch.clickOnButton(buttonsName[0]);
		hcAccountSearch.validatePayerSearchCriteria(ExcelTestData.get(rxPayerName));
		hcAccountSearch.clickOnPayerSearchButton();
		hcAccountSearch.validatePayerSearchResult(ExcelTestData.get(rxPayerName));

		Logger("STEP 9: Validate that the user is able to initiate the Account search within iCC+ and RCM and can view the returned results.");
		String payerName = "Regence Bcbs Of Oregon";
		hcAccountSearch.validatePayerSearchCriteria(payerName);
		hcAccountSearch.clickOnPayerSearchButton();
		hcAccountSearch.validateSourceSystemResult();

		Logger("STEP 10: Logout");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7220 Automate "Patient has insurance" field should be
	 * removed from Patient Detail Page Layout
	 * 
	 * @author Kavyashree MB
	 * @Maintenance_author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT - TC01:\"Patient has insurance\" field should be removed from Patient Detail Page Layout", enabled = true)
	public void AS02_IC7220_Patient_has_insurance_field_should_be_removed_from_Patient_Detail_Page_Layout()
			throws Exception {

		Logger("STEP 1: Navigate to the Care program Enrollee Record and validate USer is able to perform BV and other patient journey steps");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		documentsPage.searchDocument("Automation");
		missingInformatioPage.searchAndOpenRecord();

		Logger("STEP 3: Click on the Account Link and verify the Person Account Page is displayed'");
		docMgmt.navigateToAccount();

		Logger("STEP 4: Verify ‘Patient has Insurance’ field is not displayed in the Details section of the Person Account Page Layout");
		accountObject.verifyAbsenceofPatientHasInsurance();

		Logger("STEP 5: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7288 Verify Button Standardization rules are applied to
	 * all Work Orders and Assessment Tasks
	 * 
	 * @author Anand Pawar Note- Manual test case needs update
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "SAT - TC01:Verify Button Standardization rules are applied to all Work Orders and Assessment Tasks", enabled = true)
	public void AS03_IC7288_Verify_Button_Standardization_rules_are_applied_to_all_Work_Orders_and_Assessment_Tasks()
			throws Exception {

		String TestCaseNumber = "TC4";

		// Prerequisites
		String ID = AdminSetup_PatientEnrollment_Prerequisites_AtopicDermatitis(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 1.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 1.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 1.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		// BV Initialization code starts here
		Logger("Pre-requisites 1.5: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("Pre-requisites 1.6: Enter  Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 1.7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(2));
		bvPage.enterPAOutcomeDeniedDetails(denialReason.get(0), paRequired.get(0), appealLevel.get(2));
		bvPage.enterPharmacy1Details(AllianceSP_List.get(1));
		bvPage.enterPharmacy2Details(AllianceSP_List.get(3));
		bvPage.enterPharmacy3Details("Elixir Pharmacy");
		bvPage.clickOutreachAttemptChebox();
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// Re-initate BV for PAP initiation
		Logger("STEP 1: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 2: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 3: User will see two fields: 1. Start Service : Pick the value as \"BV\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		papPage.selectService(service.get(0));
		missingInformatioPage.clickNextButton();
		papPage.selectReason(serviceReason.get(0));

		Logger("STEP 4: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 5: Verify BV Task is initiated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 6: Enter  Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(2));
		bvPage.enterPAOutcomeDeniedDetails(denialReason.get(0), paRequired.get(0), appealLevel.get(2));
		bvPage.enterPharmacy1Details(AllianceSP_List.get(1));
		bvPage.enterPharmacy2Details(AllianceSP_List.get(3));
		bvPage.enterPharmacy3Details("Elixir Pharmacy");
		bvPage.clickOutreachAttemptChebox();
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();


		Logger("Step 10: Verify the Work Orders are initiated automatically after completion of BV WO without manual refresh");
		//papPage.checkPAPWOIntiation();
		paAppealsPage.verifyPATaskInitiated();
		quickStartPage.checkQuickStartIntiation();
		triagePage.checkTraigeIntiation();

		Logger("STEP 11: Navigate to 1st level of appeals Tasks \"Follow up on results\"");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(2));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		String effectiveDate = Utility_Function.getNthDayFromToday(10);
		String expirationDate = Utility_Function.getNthDayFromToday(15);

		Logger("STEP 12: Enter and save details in follow up on results task");
		//paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(1), payerContact.get(0), attempts.get(0),
		//		hcpFollowUpRequired.get(1), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		//paAppealsPage.enterMandatoryPAAppealDetails1(paStatus.get(1), payerContact.get(0), attempts.get(0), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(1), PAOutcomeReason.get(0));
		paAppealsPage.enterMandatoryPAApprovedDetails(effectiveDate, paDosage.get(0), expirationDate);
		careProgram.clickOnSave();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 13: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'CM User'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 15: Navigate to 1st level of appeals Tasks \"Communicate Results & Send SOB\" ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(3));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 16: Select Outcome as \"Approved\" and \"Proceed with Appeals\" is marked as \"Yes\" click on save button ");
		//paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName), attempts.get(0), intentOfSubmission.get(0));
		//paAppealsPage.enterHCPContactDetails1(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(1), PAOutcomeReason.get(0));
		String intendedDate = Utility_Function.getNthDayFromToday(10);
		paAppealsPage.enterPAAppealDeniedDetails(proceedWithAppeal.get(0), intendedDate, appealPacked.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// Triage
		triagePage.checkTraigeIntiation();

		Logger("STEP 17: Open this WO record , in accordion named as Triage Validate there is Assessment task created with name \"Submit Order\" Click on this order");
		triagePage.checkTriageTaskInitiation();
		careProgram.clickOnSubTask(triageSubTaskNames.get(0));
		triagePage.clickOnTask();

		Logger("STEP 18: Validate user is presented with Screen 1 Titled \"Review\"");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(5));
		triagePage.verifyReviewTaskFieldsReadOnly();
		missingInformatioPage.clickNextButton();

		Logger("STEP 19: Click on Submit button present at the bottom of this page>>check previous, next, save,and submit button working as expected");
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnPreviousButton();
		missingInformatioPage.clickNextButton();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// QS
		Logger("STEP 20: Open the QS WO >> Open the \"Enrollment\" Task");
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();
		quickStartPage.clickOnTask();

		Logger("STEP 21: In the Eligibility Assessment Task >>In Eligibility Cretia section select all the Fields as YES >> Click on Next button.");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 22: In the next screen Eligibility Outcome page >> Eligibility Outcome as Eligible >> select Outcome as Approved >> Click on next button.");
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 23: On Order detail Page, select Prescription → Select any attachment and click on Submit button, check previous, next, save,and submit button working as expected");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnPreviousButton();
		missingInformatioPage.clickNextButton();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 24: Click on quick start button and verify task compltion status");
		quickStartPage.clickOnQuickStart();
		quickStartPage.checkQuickStartTaskComplition();
		refresh();

		// PAP
		Logger("STEP 25: Validate PAP WO is initiated and Click on PAP WO");
		iapPage.verifyStartNewServiceButton();
		iapPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(serviceReason.get(0));
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 26: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask("Pre-Check");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 27: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 28: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(1));
		//papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		/*Logger("STEP 29: On \"Research\" Sub Task >> Validate Below Mentioned Fields are Filled -Alternate Coverage Identified? and  ");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Alternate Coverage");
		papPage.clickOnTask("Research");
		papPage.enterResearchDetails(alternateCoverage.get(1), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnSubmitButton();*/

		Logger("STEP 30: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Confirm PAP Eligibility");
		papPage.clickOnTask("Eligibility");
		papPage.enterEligibilityCheck("Yes");
		quickStartPage.clickOnNextButton();

		Logger("STEP 31: Enter outome details");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 32: Enter Order Details,check previous, next, save,and submit button working as expected");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnPreviousButton();
		quickStartPage.clickOnNextButton();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// copay
		Logger("STEP 33: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 34: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 35: User will see two fields: 1. Start Service : Pick the value as \"Copay\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		papPage.selectService(service.get(3));
		missingInformatioPage.clickNextButton();
		papPage.selectReason(serviceReason.get(0));

		Logger("STEP 36: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 37: Open Copay work order");
		careProgram.clickOnWorkOrderTask(workOrderName.get(3));
		careProgram.clickOnMainTask(copayMainTaskNames.get(0));
		careProgram.clickOnSubTask(copaySubTaskNames.get(0));

//		Logger("STEP 38: Enter Eligibility Criteria and click on submit button, check previous, next, save,and submit button working as expected");
//		String outcomeDate = Utility_Function.getNthDayFromToday(0);
//		boolean outcomeScreen = copayFlow.verifyReviewOutcomeScreen();
//		if (outcomeScreen) {
//			copayFlow.enterOutcomeDetails(copayOutcome.get(0), outcomeDate);
//			copayFlow.clickOnReAssessButton();
//		}

		copayFlow.enterEligibilityCriteria();
		quickStartPage.clickOnSubmitButton();
		//copayFlow.enterRequestOutcome(copayOutcome.get(0), outcomeDate);
		quickStartPage.clickOnPreviousButton();
		quickStartPage.clickOnSubmitButton();
		copayFlow.clickOnFinishButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// IAP
		Logger("STEP 39: Select Click on Start new Service");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 40: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 41:Select the Service as IAP ,Select Reason as Lapse in Coverage");
		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(serviceReason.get(1));

		Logger("STEP 42: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 43: Verify the IAP WO is initiated automatically without manual refresh of the page");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();
		iapPage.checkIAPSecondTask();

		Logger("STEP 44: Expand the IAP Summary section and Click on IAP Enrollment Task");
		iapPage.clickOnTask();

		Logger("STEP 45: Enter eligibilty criteria");
		iapPage.verifyTaskIsLoaded(taskTitle.get(0));
		iapPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 46: Validate if User is navigated to the eligibility screen");
		iapPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 47: Enter order details and click submit, check previous, next and submit button working as expected");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnPreviousButton();
		missingInformatioPage.clickNextButton();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 48: Click on IAP subtask extend/discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPSecondTask();
		iapPage.clickOnTask2();

		Logger("STEP 49: Enter Extend Discontinue Details");
		iapPage.enterExtendDiscontinue();
		missingInformatioPage.clickNextButton();
		iapPage.enterDiscontinuationReason();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 50: Validate the task status is completed");
		iapPage.verifyIAPCompletion();

		Logger("STEP 51: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-6216 Regression-Admin/Setup: Automate the Care Program
	 * Enrollee List View & Fields on Accounts object
	 * 
	 * @author Shanavaz Nishani
	 * @Maintenane_author Trupti
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "TC01_Validate the Care Program Enrollee List View & Fields on Accounts object.", enabled = true)
	public void AS04_IC6216_Validate_the_Care_Program_Enrollee_List_View_and_Fields_on_Accounts_object()
			throws Exception {

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Navigate to CPE object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		Thread.sleep(4000);

		Logger("STEP 3: Click on list view drop down of CPE object and validate that below filters are added in the list view.All Migrated Care Program Enrollees ,My Migrated Care Program Enrollees");
		docMgmt.ClicklistViewdropdownofCPEobject();
		docMgmt.validateListViewFilters(listViewFilters.get(0));
		docMgmt.validateListViewFilters(listViewFilters.get(1));

		Logger("STEP 4: Navigate to All Migrated Patients CPE from the list view drop down of CPE Object.");
		docMgmt.navigateToListofCPEAllMigrated(listViewFilters.get(0));
		Thread.sleep(10000);

		Logger("STEP 5: Validate the columns for All Migrated Care Program Enrollees List View:");
		docMgmt.verifyColumnsHeader(columnsAllMigratedCPE);

		Logger("STEP 6: Open an existing record.");
		docMgmt.openExistingdoc();

		Logger("STEP 7: Click on Account field → Patient account page will be opened → Validate the below fields, Status, LegacyId, sourceSystem");
		docMgmt.navigateToAccount();
		docMgmt.validateAccountObjFields();

		Logger("STEP 8: Navigate to My Migrated Patients CPE from the list view drop down of CPE Object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		docMgmt.ClicklistViewdropdownofCPEobject();
		docMgmt.navigateToListofCPEAllMigrated(listViewFilters.get(1));

		Logger("STEP 9: Validate the columns for My Migrated Care Program Enrollees List View:");
		docMgmt.verifyColumnsHeader(columnsMyMigratedCPE);

		Logger("STEP 10: Open an existing record.");
		docMgmt.openExistingdoc();

		Logger("STEP 11: Click on Account field → Patient account page will be opened → Validate the below fields, Status, LegacyId, sourceSystem");
		docMgmt.navigateToAccount();
		docMgmt.validateAccountObjFields();

		Logger("STEP 12: Log out from application");
		documentsPage.logout();

		Logger("STEP 13: Login with BV user → Navigate to CPE object → Validate that the below filters are not present in the drop-down menu of CPE object. All Migrated Care Program Enrollees ,My Migrated Care Program Enrollees");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		docMgmt.ClicklistViewdropdownofCPEobject();
		docMgmt.validateListViewFilters(listViewFilters.get(0));
		docMgmt.validateListViewFilters(listViewFilters.get(1));
		documentsPage.logout();

		Logger("STEP 14: Login with DIS user → Navigate to CPE object → Validate that the below filters are not present in the drop-down menu of CPE object.All Migrated Care Program Enrollees ,My Migrated Care Program Enrollees");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		docMgmt.ClicklistViewdropdownofCPEobject();
		docMgmt.validateListViewFilters(listViewFilters.get(0));
		docMgmt.validateListViewFilters(listViewFilters.get(1));
		documentsPage.logout();

		Logger("STEP 15: Login with PM user → Navigate to CPE object → Validate that the below filters are present in the drop-down menu of CPE object.All Migrated Care Program Enrollees ,My Migrated Care Program Enrollees");
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		docMgmt.ClicklistViewdropdownofCPEobject();
		docMgmt.validateListViewFilters(listViewFilters.get(0));
		docMgmt.validateListViewFilters(listViewFilters.get(1));
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-10626 Regression-Admin/Setup: Automate Set up Companion
	 * App Objects and master data
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT: TC01: Set up Companion App Objects and master data.", enabled = true)
	public void AS05_IC4688_Set_up_Companion_App_Objects_and_master_data() throws Exception {

		String recordToSearch = "MobileApp";
		Logger("STEP 1: Login to iCare Connect App with 'System Admin User'.");
		homeportalPage = loginPage.userLogin(SAUserName, UserPassword);

		Logger("STEP 2: Navigate to Product Object → Validate Master record \"Product: MobileApp\"*on Product Object");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(14), DocumentPage.class);
		Thread.sleep(4000);
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(14));
		docMgmt.navigateToListofCPE(listViewFilters.get(2));
		Thread.sleep(3000);
		docMgmt.validateRecordPresent(recordToSearch);

		Logger("STEP 3: Navigate to CPP object → Validate all Master record -> DMW Nasal Polyposis: MobileApp, DMW Asthma: MobileApp, DMW EoE: MobileApp, DMW Atopic Dermatitis: MobileApp, DMW Prurigo Nodularis: MobileApp, DMW COPD: MobileApp");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(15), DocumentPage.class);
		docMgmt.navigateToListofCPEListView(listViewFilters.get(3));
		Thread.sleep(3000);
		refresh();
		documentsPage.searchDocument(recordToSearch);
		for (String product : productsMobileApp) {
			docMgmt.validateRecordPresent(product);
		}
		Logger("STEP 4: Log out from application");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-3731 Validate that search results are visible from SFDC
	 * and RCM when DIS searches for Specialty Pharmacy on Omniscript
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "SAT - TC01:Validate that search results are visible from SFDC and RCM when DIS searches for Specialty Pharmacy on Omniscript", enabled = true)
	public void AS06_IC3731_Validate_that_search_results_are_visible_from_SFDC_and_RCM_when_DIS_searches_for_Specialty_Pharmacy_on_Omniscript()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC6";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_adminSetup);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		synchronized (updatepdf) {
			Logger("Pre-Requisite : User updates the Patient Form");
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));

		Logger("STEP 6.1:Search for a Specialty Pharmacy which does not exist iCare Connect → Validate that 'No Records Found' message is displayed ");
		insuranceinfo.validateErrorMessage();

		Logger("STEP 6.2:Validate that search results are displayed with source RCM as well as Salesforce");
		insuranceinfo.selectSpecialtyPharmacy(alliancePharmacy.get(2));// Specialty Pharmacy
		insuranceinfo.verifySourceColumn();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 10.1:Navigate to the Accounts Object >> Select and Open the Patient Record >> Navigate to the Related List  and Open the Care Program Enrollee associated to it >> Navigate to the related list of Care Program Enrollee And Open the  Care Program Enrollee Product >> Navigate to Related List of the opened record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
//		accountObject.clickOnTab(tabsName.get(1));
//		careProgram.clickOnViewAll("Care Program Enrollee Products");
//		iapPage.navigateToCPEPRecord("CPE");
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 10.2:  Validate Care Program Enrollee Product SPs Object in Related List >> Open Care Program Enrollee Product SPs >> Validate that the SP record previously selected from search result in the Enrollment Form is visible on Care Program Enrollee Product SP");
		careProgram.clickOnViewAll("Care Program Enrollee Product SPs");
		iapPage.navigateToCPEPSpsRecord(alliancePharmacy.get(2));
		docMgmt.verifyCPEspField(alliancePharmacy.get(2));

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5178 validate that DIS can see results of HCP from SFDC
	 * and RCM
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "validate that DIS can see results of HCP from SFDC and RCM", enabled = true)
	public void AS07_IC5178_validate_that_DIS_can_see_results_of_HCP_from_SFDC_and_RCM() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC7";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Prescriber Name", "Specialty", "Prescriber NPI", "Prescriber Zip" };
		String columnValue[] = { "Destiny Rower", "UNSPEC", "1841909355", "95993" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_adminSetup2);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Nasal Polyps");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5: Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.searchRecord();

		Logger("STEP:Validate that the: Results from RCM display ‘RCM’ as the source system, Results from ICARE display ‘ICARE+’ as the source");
		insuranceinfo.verifySourceColumnHCP();

		Logger("STEP:Select any RCM record and click on next and proceed with submitting the enrollment form");
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));

		Logger("STEP 17:validate that the HCP account record is  created and is visible ");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToCCR();
		accountObject.clickOnRelatedRecord(ExcelTestData.get(prescriberName));

		Logger("STEP 18: Go to related tab");
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 19: validate that the Contact Point Address’, ‘Contact Point Email’, ‘Contact Point Phone’ records are created for the HCP account");
		accountObject.validateContactPointDetails();

		Logger("STEP 20: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-2786 Validating the Contact-Contact Relationship field in
	 * accordance with the new updates
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT -  Validating the Contact-Contact Relationship field in accordance with the new updates", enabled = true)
	public void AS08_IC2786_Validating_the_Contact_Contact_Relationship_field_in_accordance_with_the_new_updates()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC8";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code","Relationship" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified","Other" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 5: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.validateRelationshipDropDownValues();
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.globalSearchNormal(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 17: Navigate to Contact-Contact Relationship Object");
		// Contact Contact Relationships
		accountObject.navigateToCCR();
		accountObject.clickOnCCRRecord(ExcelTestData.get(legalRepresentativeName));

		Logger("STEP 17: On the detail section of the record, validate the \"Relationship\" field is visible to user with picklist values");
		accountObject.clickOnRelationshipEditButton();
		accountObject.validateRelationshipDropDownValues();
		accountObject.clickCancelButton();

		Logger("STEP 17: Verify if the HCP type field is no longer visible on the detail/compact section of the UI.");
		accountObject.verifyHCPFieldIsNotVisible();

		Logger("STEP 17: \"Party Role Relationship\" should be auto-populated with the value \"Patient-Related Entity\" after a CCR record is created");
		accountObject.verifyPartyRoleRelationship();

		Logger("STEP 17: Relationship field should get populated with the same value given while submitting EF");
		accountObject.verifyRelationship(ExcelTestData.get(legalrelationship));

		Logger("STEP 17: Log Out from the Org.");
		documentsPage.logout();

		Logger("STEP 17: Login As System Admin");
		homeportalPage = loginPage.userLogin(SAUserName, UserPassword);

		Logger("STEP 17: Now, open the Party Role relationship from the app launcher");
		documentsPage = homeportalPage.selectObjectFromAppLauncher(appLauncherMenuItem.get(13), DocumentPage.class);

		Logger("STEP 17: Verify if Patient-Related Entity is created and visible on the Party Role relationship list view page");
		documentsPage.navigateToPartyRelationListView();
		accountObject.verifyPartyRoleRelationshipList();

		Logger("STEP 17: Log Out from the Org.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-10629 Regression-Admin/Setup: Automate Relate Specialty
	 * Pharmacy that was found during a search to the CPEP
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT-TC01 - [Technical] Relate Specialty Pharmacy that was found during a search to the CPEP", enabled = true)
	public void AS09_IC1107_Relate_Specialty_Pharmacy_that_was_found_during_a_search_to_the_CPEP() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC10";
		
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_adminSetup);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();


		Logger("STEP 2.2:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));


		Logger("STEP 3:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.1:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.2: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 5.1:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));

		Logger("STEP 6: Navigate to insurance information section and validate SP search below Payer name.");
		insuranceinfo.validateSPsearch();

		Logger("Step 7 and 8: Search for existing SP record through SP search -> Select any record from search result.");
		insuranceinfo.selectSpecialtyPharmacy("Automation Specialty Pharmacy");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 9.1:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9.2:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 9.3:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 10.1:Navigate to the Accounts Object >> Select and Open the Patient Record >> Navigate to the Related List  and Open the Care Program Enrollee associated to it >> Navigate to the related list of Care Program Enrollee And Open the  Care Program Enrollee Product >> Navigate to Related List of the opened record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		accountObject.clickOnTab(tabsName.get(1));
		
		Logger("STEP 10.2:  Validate Care Program Enrollee Product SPs Object in Related List >> Open Care Program Enrollee Product SPs >> Validate that the SP record previously selected from search result in the Enrollment Form is visible on Care Program Enrollee Product SP");
		careProgram.clickOnViewAll("Care Program Enrollee Product SPs");
		iapPage.navigateToCPEPSpsRecord("Automation Specialty Pharmacy");
		docMgmt.verifyCPEspField("Automation Specialty Pharmacy");

		Logger("STEP 11: Navigate to Account Object and validate that no new SP record is created after having submitted the enrollment form.");
		docMgmt.switchtoRequiredTab("Care Program Enrollee Product SPs");
		docMgmt.validateNoNewSPRecord();

		Logger("STEP 11.1: User Logout the Application.");
		documentsPage.logout();
	}
	

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-15666 Regression Admin/Setup: Automate ICARE-9851:
	 * SIT-TC01: To Validate field label change to 'Care Program Enrollee' for the
	 * required field on different objects.
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE-9851: SIT-TC01: To Validate field label change to 'Care Program Enrollee' for the required field on different objects.", enabled = true)
	public void AS10_IC12025_To_Validate_field_label_change_to_Care_Program_Enrollee_for_the_required_field_on_different_objects()
			throws Exception {
		String FiledsAndRelationshiptURL = "https://icarecrm--toleuat.sandbox.my.salesforce-setup.com/lightning/setup/ObjectManager/01IPs000001eu9Y/FieldsAndRelationships/view";
		String FieldToValidate = "Care Program Enrollee";
		Logger("STEP 1: Log in to UAT Org using CM User");

		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();

		Logger("STEP 2 :Navigate to App Launcher and Search for Cases Object. Open any record from the searched list.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5), DocumentPage.class);
		docMgmt.openRecentCase();

		Logger("STEP 3: Validate whether ‘Patient Journey’ has been re-labeled to ‘Care Program Enrollee’.");
		missingInformatioPage.verifyFieldPresenceOnLayout(FieldToValidate);

		Logger("STEP 4 : Repeat step 2 & 3 for below objects and validate if the respective fields have been updated to ‘Care Program Enrollee’ ,  Orders Object → ‘Patient Program ID’");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(8), DocumentPage.class);
		docMgmt.openFirstRecentRecord();
		missingInformatioPage.verifyFieldPresenceOnLayout(FieldToValidate);

		Logger("STEP 4.1: Voice Calls Object → ‘Related Care Program Enrollee’");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(22), DocumentPage.class);
		docMgmt.openFirstRecentRecord();
		missingInformatioPage.verifyFieldPresenceOnLayout2(FieldToValidate);

		Logger("STEP 4.2: CPE Detail Object → ‘Patient Program ID");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		accountObject.searchRecord("Automation");
		docMgmt.openRecentdoc();
		missingInformatioPage.verifyFieldPresenceOnLayout3(FieldToValidate);

		Logger("STEP 5: Log out from the org and log in as System Admin User.");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(SAUserName, UserPassword);

		Logger("STEP 6: Navigate to Setup and Click on Object Manager. Open Claims Object and go to Fields and Relationships and Validate if Patient Program has been relabeled to Care Program Enrollee.");
		navigateToURL(FiledsAndRelationshiptURL);
		missingInformatioPage.validateFieldLabelValueforObjectManager(FieldToValidate);

		Logger("STEP 7: Log Out from the Org.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-11982
	 * To_validate_Updates_on_the_Expiring_Correspondences_of_Fax
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test
	public void AS11_IC11982_To_validate_Updates_on_the_Expiring_Correspondences_of_Fax() throws Exception {

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(SAUserName, UserPassword);

		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Master Correspondence Sets' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(16), DocumentPage.class);
		careProgram.navigateToAllCorrespondences();
		refresh();

		Logger("STEP 3: Open DMW PAP Renewal MD Fax and Validate start and End Date, Dupix Code");
		careProgram.searchRecord(correspondences.get(1));
		careProgram.clickOnFirstCorresRecord();
		docMgmt.verifyCorresDUPCode(DUPCode.get(1));
		docMgmt.verifyStartEndDateCorrespondence(corresDates.get(2), corresDates.get(3));
		careProgram.navigateToAllCorresTab();
		refresh();

		Logger("STEP 4: Open DMW PAP Approval Medicare Enrollee - MD Fax  and Validate start and End Date, Dupix Code");
		careProgram.searchRecord(correspondences.get(2));
		careProgram.clickOnFirstCorresRecord();
		docMgmt.verifyCorresDUPCode(DUPCode.get(2));
		docMgmt.verifyStartEndDateCorrespondence(corresDates.get(2), corresDates.get(4));
		careProgram.navigateToAllCorresTab();
		refresh();

		Logger("STEP 5: Open DMW PAP Discontinuation - MD Fax and Validate start and End Date, Dupix Code");
		careProgram.searchRecord(correspondences.get(3));
		careProgram.clickOnFirstCorresRecord();
		docMgmt.verifyCorresDUPCode(DUPCode.get(3));
		docMgmt.verifyStartEndDateCorrespondence(corresDates.get(2), corresDates.get(5));
		careProgram.navigateToAllCorresTab();
		refresh();

		Logger("STEP 6: Open Initial Free Goods Shipment Confirmation - HCP Fax and Validate start and End Date, Dupix Code");
		careProgram.searchRecord(correspondences.get(4));
		careProgram.clickOnFirstCorresRecord();
		docMgmt.verifyCorresDUPCode(DUPCode.get(4));
		docMgmt.verifyStartEndDateCorrespondence(corresDates.get(6), corresDates.get(7));

		Logger("STEP 7: Log out from application");
		documentsPage.logout();

	}
 
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-12022 TC01:To validate the Audit Trial Related List
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "TC01:To validate the Audit Trial Related List", enabled = true)
	public void AS12_IC12022_validate_the_Audit_Trial_Related_List() throws Exception {

		int numberOfUsers = 9;

		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
					case 0:
						Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
						homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
						break;
					case 1:
						Logger("STEP 1: Login to the QA_SIT Org as 'BV User'.");
						homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
						break;
					case 2:
						Logger("STEP 1: Login to the QA_SIT Org as 'DIS User'.");
						homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
						break;
					case 3:
						Logger("STEP 1: Login to the QA_SIT Org as 'PC User'.");
						homeportalPage = loginPage.userLogin(PCUserName, UserPassword);
						break;

					case 4:
						Logger("STEP 1: Login to the QA_SIT Org as 'PM User'.");
						homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
						break;
					case 5:
						Logger("STEP 1: Login to the QA_SIT Org as 'BusimessOps User'.");
						homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
						break;
					case 6:
						Logger("STEP 1: Login to the QA_SIT Org as 'TPL User'.");
						homeportalPage = loginPage.userLogin(TPLUserName, UserPassword);
						break;
					case 7:
						Logger("STEP 1: Login to the QA_SIT Org as 'NE User'.");
						homeportalPage = loginPage.userLogin(NurseEduUserName, UserPassword);
						break;
					case 8:
						Logger("STEP 1: Login to the QA_SIT Org as 'Quality Manager User'.");
						homeportalPage = loginPage.userLogin(QualityMGRUserName, QualityMGRPassword);
						break;

				}

				Logger("STEP 2: Navigate to the Account Object open the Patient Account Record → Validate that the History tracking data is visible on the Related List is visible ");
				homeportalPage.closeTabs();
				accountObject.navigateToAccount();
				accountObject.navigateToListView(accountListView.get(0));
				accountObject.clickonFirstAccount();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyPatientHistoryTrackingdata();

				Logger("STEP 3: Validate same for the other Account Record type as well");
				accountObject.navigateToAccount();
				accountObject.navigateToListView(accountListView.get(1));
				accountObject.clickonFirstAccount();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyPatientHistoryTrackingdata();

				accountObject.navigateToAccount();
				accountObject.navigateToListView(accountListView.get(2));
				accountObject.clickonFirstAccount();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyPatientHistoryTrackingdata();

				accountObject.navigateToAccount();
				accountObject.navigateToListView(accountListView.get(3));
				accountObject.clickonFirstAccount();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyPatientHistoryTrackingdata();

				accountObject.navigateToAccount();
				accountObject.navigateToListView(accountListView.get(4));
				accountObject.clickonFirstAccount();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyAccountHistoryTrackingdata();

				accountObject.navigateToAccount();
				accountObject.navigateToListView(accountListView.get(5));
				accountObject.clickonFirstAccount();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyAccountHistoryTrackingdata();

				accountObject.navigateToAccount();
				accountObject.navigateToListView(accountListView.get(6));
				accountObject.clickonFirstAccount();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyAccountHistoryTrackingdata();

				Logger("STEP 4: Navigate to the Case Object open the MI Case Record → Validate that the  History tracking data is visible on the Related Lis");
				refresh();
				documentsPage = homeportalPage.selectObjectFromAppLauncher(appLauncherMenuItem.get(5),
						DocumentPage.class);
				accountObject.clickonFirstCase();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyCaseHistory();

				String miCase;
				Logger("STEP 5: Validate same for the other Case Record type ");
				if (!(i == 0)) {
					// Navigate to Injection Training Case
					miCase = "https://icarecrm--uat.sandbox.lightning.force.com/lightning/r/Case/500O400000KhJ8kIAF/view";
					navigateToUrl(miCase);
					accountObject.clickOnTab(tabsName.get(1));
					accountObject.verifyCaseHistory();
				}

				// Navigate to Welcome Message case
				miCase = "https://icarecrm--uat.sandbox.lightning.force.com/lightning/r/Case/500O400000Ibq3mIAB/view";
				navigateToUrl(miCase);
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyCaseHistory();

				if (!(i == 0)) {
					// Navigate to Order Follow up case
					miCase = "https://icarecrm--uat.sandbox.lightning.force.com/lightning/r/Case/500O400000McN5SIAV/view";
					navigateToUrl(miCase);
					accountObject.clickOnTab(tabsName.get(1));
					accountObject.verifyCaseHistory();
				}

				Logger("STEP 6: Navigate to the Authorization Form Consent Object open a Record → Validate that the  History tracking data is visible on the Related List ");
				refresh();
				documentsPage = homeportalPage.selectObjectFromAppLauncher(appLauncherMenuItem.get(6),
						DocumentPage.class);
				accountObject.clickonfirstRecord();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyHistoryTrackingData(accountHistory.get(0));

				Logger("STEP 7: Repeat the above step and validate the Audit Trial Related List for the same ");
				// Care Program Enrollee
				refresh();
				documentsPage = homeportalPage.selectObjectFromAppLauncher(appLauncherMenuItem.get(7),
						DocumentPage.class);
				accountObject.clickonfirstRecord();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyHistoryTrackingData(accountHistory.get(1));

				// Care Program Enrollee Product
				refresh();
				documentsPage = homeportalPage.selectObjectFromAppLauncher(appLauncherMenuItem.get(7),
						DocumentPage.class);
				accountObject.clickonfirstRecord();
				accountObject.clickOnTab(tabsName.get(1));
				careProgram.clickOnViewAll("Care Program Enrollee Products");
				accountObject.clickOnRelatedRecord("CPE");
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyHistoryTrackingData(accountHistory.get(2));

				// Contact Contact Relationships
				refresh();
				documentsPage = homeportalPage.selectObjectFromAppLauncher(appLauncherMenuItem.get(17),
						DocumentPage.class);
				accountObject.clickonfirstRecord();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyHistoryTrackingData(accountHistory.get(3));

				// Coverage Benefits
				refresh();
				documentsPage = homeportalPage.selectObjectFromAppLauncher(appLauncherMenuItem.get(18),
						DocumentPage.class);
				accountObject.clickonfirstRecord();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyHistoryTrackingData(accountHistory.get(4));

				// Health Condition
				documentsPage = homeportalPage.selectObjectFromAppLauncher(appLauncherMenuItem.get(19),
						DocumentPage.class);
				accountObject.clickonfirstRecord();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyHistoryTrackingData(accountHistory.get(5));

				// Medication Request
				documentsPage = homeportalPage.selectObjectFromAppLauncher(appLauncherMenuItem.get(20),
						DocumentPage.class);
				accountObject.clickonfirstRecord();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyHistoryTrackingData(accountHistory.get(6));

				// Member Plan
				documentsPage = homeportalPage.selectObjectFromAppLauncher(appLauncherMenuItem.get(9),
						DocumentPage.class);
				accountObject.clickonfirstRecord();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyHistoryTrackingData(accountHistory.get(7));

				// Correspondence
				documentsPage = homeportalPage.selectObjectFromAppLauncher(appLauncherMenuItem.get(11),
						DocumentPage.class);
				accountObject.clickonfirstRecord();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyHistoryTrackingData(accountHistory.get(8));

				// Order
				documentsPage = homeportalPage.selectObjectFromAppLauncher(appLauncherMenuItem.get(8),
						DocumentPage.class);
				accountObject.clickonfirstRecord();
				accountObject.clickOnTab(tabsName.get(1));
				accountObject.verifyHistoryTrackingData(accountHistory.get(9));

				// Received DocumentS
				if (!(i == 0)) {
					documentsPage = homeportalPage.selectObjectFromAppLauncher(appLauncherMenuItem.get(0),
							DocumentPage.class);
					accountObject.clickonfirstRecord();
					accountObject.clickOnTab(tabsName.get(1));
					accountObject.verifyHistoryTrackingData(accountHistory.get(10));
				}

				Logger("STEP 8: Log out from application");
				documentsPage.logout();

			} catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				e.printStackTrace();
				try {
					if (documentsPage != null) {
						documentsPage.logout();
					}
				} catch (Exception logoutEx) {
					Logger("Logout failed after test failure for user " + i + ": " + logoutEx.getMessage());
				}
			}

		}
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-15672_To validate that RCM ID field is updated to remove
	 * commas so that IDs remain consistent.
	 * 
	 * @author Tejal
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "To validate that RCM ID field is updated to remove commas so that IDs remain consistent", enabled = true)
	public void AS13_IC11811_To_validate_that_RCMID_field_is_updated_to_remove_commas_so_that_IDs_remain_consistent()
			throws Exception {

		String TestCaseNumber = "TC13";

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "Rx Payer Name", "Medical Payer Name", "Specialty Pharmacy Name",
				"Prescriber Name", "Specialty", "Prescriber NPI", "Prescriber Zip", "Site/facility name", "Office Fax",
				"Collaborating MD Name" };

		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "CBA Blue", "Bcd Travel", "Rc3 Pharmacy",
				"Destiny Rower", "UNSPEC", "1841909355", "95993", "Cumberland Skin Surgery And Dermatology", "(908) 203-7482",
				"Kent Sanders" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.1: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));


		Logger("STEP 4: On Classify document page select Doc type = Enrollment Form > Click on submit.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(2));

		Logger("STEP 4.1: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4.2: Enter the CARE PROGRAM PRODUCT > Click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 4.3: In Patient Information & Authorizations pg enter all the mandatory details of the patient.");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 4.4: Enter all the mandatory details in the Insurance Information section > Click on next.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		//Pharmacy
		insuranceinfo.searchPayerPharmacy("CBA Blue");
		insuranceinfo.verifySourceColumnHCP();

		//Medical
		insuranceinfo.searchPayerMedical("Bcd Travel");
		insuranceinfo.verifySourceColumnHCP();
		//SPPharmacy
		
		insuranceinfo.verifySourceColumnHCP();
		insuranceinfo.sarchSpecialtyPharmacy("Rc3 Pharmacy");
		insuranceinfo.verifySourceColumnHCP();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 4.5: In the Prescriber Information section fill the HCP Speciality and HCo Zip code and other details > click on next.");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.searchAndSelectHCP();
		insuranceinfo.verifySourceColumnHCP();
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 4.6: In the Diagnosis Information fill all the mandatory details > click on next.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 4.7:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName("Peyton Sanders");
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 5: Click on Submit and Enrollment Form should be submitted");
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));
		refresh();


		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		int numberOfUsers = 7;
        String user="";
		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
					case 0:
						Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
						homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
					     user="CMUSer";
						break;
					case 1:
						Logger("STEP 1: Login to the QA_SIT Org as 'BV User'.");
						homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
					    user="BVUser";
						break;
					case 2:
						Logger("STEP 1: Login to the QA_SIT Org as 'PC User'.");
						homeportalPage = loginPage.userLogin(PCUserName, UserPassword);
					    user="PC";
						break;

					case 3:
						Logger("STEP 1: Login to the QA_SIT Org as 'PM User'.");
						homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
					    user="PM";
						break;
					case 4:
						Logger("STEP 1: Login to the QA_SIT Org as 'BusimessOps User'.");
						homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
					    user="BOPs";
						break;
					case 5:
						Logger("STEP 1: Login to the QA_SIT Org as 'TPL User'.");
						homeportalPage = loginPage.userLogin(TPLUserName, UserPassword);
					    user="TPL";
						break;
					case 6:
						Logger("STEP 1: Login to the QA_SIT Org as 'NE User'.");
						homeportalPage = loginPage.userLogin(NurseEduUserName, UserPassword);
					    user="NurseEdu";
						break;
					case 7:
						Logger("STEP 1: Login to the QA_SIT Org as 'Quality Manager User'.");
						homeportalPage = loginPage.userLogin(FRMUserName, UserPassword);
					    user="FRMUser";
						break;

				}

				accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));
				Thread.sleep(4000);
				accountObject.clickOnTab(tabsName.get(1));

				Logger("STEP 12: Verify Care program enrollee record is linked to account ");
				careProgram.clickOnViewAll("Member Plans");
				careProgram.clickOnPayersMemberplan("CBA Blue");
				docMgmt.validateRCMID();

				accountObject.navigateToAccount();
				refresh();
				accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));
				refresh();
				CPEURL = getCurrentPageURL();
				CPEURL = Utility_Function.removeQueryString(CPEURL);     		
				
				// HCO validation
				Logger("STEP 10.2:  Validate Site RCM ID");
				accountObject.clickOnSite();
				if(user.equalsIgnoreCase("CMUser")){
					docMgmt.validateEditSiteRCMID();
				}else {
				docMgmt.validateRCMID();
				}
				navigateToUrl(CPEURL);

				//HCP
				Logger("STEP 10.2:  Validate HCP RCM ID");
				accountObject.clickOnHCP();
				docMgmt.validateRCMID();
				navigateToUrl(CPEURL);
				

				// SP validation
				accountObject.clickOnTab(tabsName.get(1));
				Logger("STEP 10.2:  Validate Care Program Enrollee Product SPs Object in Related List >> Open Care Program Enrollee Product SPs >> Validate that the SP record previously selected from search result in the Enrollment Form is visible on Care Program Enrollee Product SP");
				careProgram.clickOnViewAll("Care Program Enrollee Product SPs");
				careProgram.clickOnPayersMemberplan("Rc3 Pharmacy");
				docMgmt.validateRCMID();

				Logger("STEP 13: User Logout the Application.");
				documentsPage.logout();

			}

			catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " +user+ e.getMessage());
				documentsPage.logout();
			}
		}
	}
	
	
	

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-12125 To Validate DUP Code Change in Quick Start
	 * Correspondence
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT -  To Validate DUP Code Change in Quick Start Correspondence", enabled = true)
	public void AS14_IC12125_To_Validate_DUP_Code_Change_in_Quick_Start_Correspondence() throws Exception {

		String TestCaseNumber = "TC17";

		// Prerequisites
		 String url =AdminSetup_PatientEnrollment_Prerequisites_DMWAsthma(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Navigate to  CPE url");
		navigateToUrl(url);
		Thread.sleep(3000);

		Logger("STEP 3: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();
		refresh();

		Logger("STEP 4: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 5: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 6: User will see two fields: 1. Start Service : Pick the value as \"QS\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		papPage.selectService(service.get(5));
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(4));

		Logger("STEP 7: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 8: Navigate to Quick Start and verify flow has initiated");
		refresh();
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();

		Logger("STEP 9: Click on Enrollment task");
		quickStartPage.clickOnTask();

		Logger("STEP 10: Enter Eligibility Criteria and click on Next button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 11: Enter Eligibility outcome and click on next button ");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 12: Enter order details and click on submit button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 13: Click on quick start button and verify task compltion status");
		quickStartPage.clickOnQuickStart();
		quickStartPage.checkQuickStartTaskComplition();

		Logger("STEP 14: Click on the Correspondence button");
		refresh();
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 15: Select the Process Name as 'Quick Start' and Select items to Send as 'DMW Quick Start Program Notification of Program End Date - MD Fax' and Click on Next");
		docMgmt.selectProcessName(processName.get(8));
		docMgmt.selectItemsToSend(itemsToSend.get(6));
		missingInformatioPage.clickNextButton();
		docMgmt.enterFaxNumber(ExcelTestData.get(officeFax));
		missingInformatioPage.clickNextButton();

		Logger("STEP 16: Verify Generate Document Correspondence Screen opens and user can send the Correspondence");
		docMgmt.clickSendButtonUntilFinish();

		Logger("STEP 17: Validate success message is populated in the Correspondence record");
		String msg = docMgmt.validateSuccessMessage();
		if (msg.contains(QSSuccessMSG)) {
			Logger("Success message verified.");
		} else {
			Logger("Success message not found.");
			Assert.fail();
			throw new Exception("Success message not found.");
		}

		docMgmt.clickonFinishButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 18: Validate PDF Files present in Related List of Correspondence ");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToFilesSection();
		docMgmt.clickFirstCorrespondence(itemToSend.get(4));
		String pdfName = itemToSend.get(4).trim();
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.deleteExistingFile(downloadPath);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);

		Logger("STEP 19: Validate that the document generated is according to the updated template attached and fields are mapped correctly in the document ");
		Map<String, Integer> fieldsToValidate = new HashMap<>();
		String updatedPara = textToValidate.get(4);
		String updatedPara2 = textToValidate.get(5);
		String title = textToValidate.get(6);
		String dupCode = DUPCode.get(0);
		fieldsToValidate.put(title, 2);
		fieldsToValidate.put(updatedPara, 2);
		fieldsToValidate.put(updatedPara2, 2);
		fieldsToValidate.put(dupCode, 2);
		docMgmt.validateMultiplePDFFields(downloadPath, fieldsToValidate);
		docMgmt.clickCloseBtn();

		Logger("STEP 20: Navigate back to the CPE record → Click on the related tab and Go to the Correspondence list Validate that a new Correspondence record has been created ");
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();
		careProgram.clickOnViewAll("Correspondences");
		docMgmt.verifyCorrespondenceRecord(selectProcessName.get(2));
		docMgmt.clickOnCorrespondenceRecord(selectProcessName.get(2));
		docMgmt.verifyDUPCode(DUPCode.get(0));
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// Negative testing
		Logger("STEP 21: Click on the Correspondence button");
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 22: Select the Process Name as 'Quick Start' and Select items to Send as 'DMW Quick Start Program Notification of Program End Date - MD Fax' and Click on Next");
		docMgmt.selectProcessName(processName.get(8));
		docMgmt.validateQSOptionNotPresent();

		homeportalPage.closeTabs();

		int numberOfCareprograms = 5;
		for (int i = 1; i < numberOfCareprograms; i++) {
			try {
				switch (i) {
					case 0:
						accountObject.navigateToCareProgramEnrollee();
						Logger("STEP 23:  Verify recently view list is displayed and search the CP Record.");
					//	careProgram.navigateToAllCPE();
						careProgram.searchRecord(carePrograms.get(0));
						careProgram.clickOnFirstCPERecord();
						break;
					case 1:
						accountObject.navigateToCareProgramEnrollee();
						Logger("STEP 23:  Verify recently view list is displayed and search the CP Record.");
						//careProgram.navigateToAllCPE();
						careProgram.searchRecord(carePrograms.get(1));
						careProgram.clickOnFirstCPERecord();
						break;
					case 2:
						accountObject.navigateToCareProgramEnrollee();
						Logger("STEP 23:  Verify recently view list is displayed and search the CP Record.");
					//	careProgram.navigateToAllCPE();
						careProgram.searchRecord(carePrograms.get(2));
						careProgram.clickOnFirstCPERecord();
						break;
					case 3:
						accountObject.navigateToCareProgramEnrollee();
						Logger("STEP 23:  Verify recently view list is displayed and search the CP Record.");
					//	careProgram.navigateToAllCPE();
						careProgram.searchRecord(carePrograms.get(3));
						careProgram.clickOnFirstCPERecord();
						break;
					case 4:
						accountObject.navigateToCareProgramEnrollee();
						Logger("STEP 23:  Verify recently view list is displayed and search the CP Record.");
					//	careProgram.navigateToAllCPE();
						careProgram.searchRecord(carePrograms.get(4));
						careProgram.clickOnFirstCPERecord();
						break;

				}

				refresh();
				Logger("STEP 24: Navigate to MI-Tab and change status of MI cases to collected");
				accountObject.clickOnTab(tabsName.get(2));
				missingInformatioPage.changeStatusOfMICases();
				refresh();

				Logger("STEP 25: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
				iapPage.verifyStartNewServiceButton();

				Logger("STEP 26: Click on the button \"Start New Services\"");
				iapPage.clickOnStartNewService();

				Logger("STEP 27: User will see two fields: 1. Start Service : Pick the value as \"QS\" 2. Reason: Any one");
				iapPage.verifyServiceTitle();
				papPage.selectService(service.get(5));
				missingInformatioPage.clickNextButton();
				iapPage.checkAttestationcheckboxIfPresent();
				papPage.selectReason(papOptions.get(3));

				Logger("STEP 28: Click on Save button");
				missingInformatioPage.clickOnSaveButton();
				refresh();

				Logger("STEP 29: Navigate to Quick Start and verify flow has initiated");
				refresh();
				quickStartPage.checkQuickStartIntiation();
				quickStartPage.checkQuickStartTaskInitiation();

				Logger("STEP 30: Click on Enrollment task");
				quickStartPage.clickOnTask();

				Logger("STEP 31: Enter Eligibility Criteria and click on Next button");
				quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
				quickStartPage.enterEligibilityCriteria();
				missingInformatioPage.clickNextButton();

				Logger("STEP 32: Enter Eligibility outcome and click on next button ");
				quickStartPage.verifyTaskIsLoaded(taskTitle.get(1));
				quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
				missingInformatioPage.clickNextButton();

				Logger("STEP 33: Enter order details and click on submit button");
				quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));
				quickStartPage.enterOrderDetails();
				quickStartPage.checkAttachCheckbox();
				quickStartPage.clickOnSubmitButton();
				missingInformatioPage.navigateToCPETab();

				Logger("STEP 34: Click on quick start button and verify task compltion status");
				quickStartPage.clickOnQuickStart();
				quickStartPage.checkQuickStartTaskComplition();

				Logger("STEP 35: Click on the Correspondence button");
				docMgmt.clickOnCorrespondenceBotton();

				Logger("STEP 36: Select the Process Name as 'Quick Start' and Select items to Send as 'DMW Quick Start Program Notification of Program End Date - MD Fax' and Click on Next");
				docMgmt.selectProcessName(processName.get(8));
				docMgmt.selectItemsToSend(itemsToSend.get(6));
				missingInformatioPage.clickNextButton();
				docMgmt.enterFaxNumber(ExcelTestData.get(officeFax));
				missingInformatioPage.clickNextButton();

				Logger("STEP 37: Verify Generate Document Correspondence Screen opens and user can send the Correspondence");
				docMgmt.clickSendButtonUntilFinish();

				Logger("STEP 38: Validate success message is populated in the Correspondence record");
				String msg2 = docMgmt.validateSuccessMessage();
				if (msg2.contains(QSSuccessMSG)) {
					Logger("Success message verified.");
				} else {
					Logger("Success message not found.");
					Assert.fail();
					throw new Exception("Success message not found.");
				}

				docMgmt.clickonFinishButton();
				missingInformatioPage.navigateToCPETab();
				refresh();

				Logger("STEP 39: Validate PDF Files present in Related List of Correspondence ");
				accountObject.clickOnTab(tabsName.get(1));
				docMgmt.navigateToFilesSection();
				docMgmt.clickFirstCorrespondence(itemToSend.get(4));
				String pdFName = itemToSend.get(4).trim();
				String downloaDPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
						+ "PDFDownloads" + File.separator + pdFName + ".pdf";
				docMgmt.deleteExistingFile(downloaDPath);
				documentsPage.downloadPDFfileFromRelatedCPESection(pdFName);

				Logger("STEP 40: Validate that the document generated is according to the updated template attached and fields are mapped correctly in the document ");
				Map<String, Integer> fieldsToValidate2 = new HashMap<>();
				String updatedParagraph = textToValidate.get(4);
				String updatedParagraph2 = textToValidate.get(5);
				String titlePage = textToValidate.get(6);
				String dupixCode = textToValidate.get(7);
				fieldsToValidate2.put(titlePage, 2);
				fieldsToValidate2.put(updatedParagraph, 2);
				fieldsToValidate2.put(updatedParagraph2, 2);
				fieldsToValidate2.put(dupixCode, 2);
				docMgmt.validateMultiplePDFFields(downloaDPath, fieldsToValidate2);
				docMgmt.clickCloseBtn();

				Logger("STEP 41: Navigate back to the CPE record → Click on the related tab and Go to the Correspondence list Validate that a new Correspondence record has been created ");
				refresh();
				accountObject.clickOnTab(tabsName.get(1));
				docMgmt.navigateToCorrespondenceTable();
				careProgram.clickOnViewAll("Correspondences");
				docMgmt.verifyCorrespondenceRecord(selectProcessName.get(2));
				docMgmt.clickOnCorrespondenceRecord(selectProcessName.get(2));
				docMgmt.verifyDUPCode(DUPCode.get(0));

			} catch (Exception e) {
				Logger("Test failed " + i + " due to error: " + e.getMessage());

			}

		}

		Logger("STEP 42: Log out from application");
		documentsPage.logout();

		Logger("STEP 43: Login to the QA_SIT Org as 'System Admin'.");
		homeportalPage = loginPage.userLogin(SAUserName, UserPassword);

		Logger("STEP 44: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Master Correspondence Sets' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(16), DocumentPage.class);
		careProgram.navigateToAllCorrespondences();

		Logger("STEP 45: Open Quick Start Program Notification of Program End Date - MD Fax and Validate start and End Date");
		careProgram.searchRecord(correspondences.get(0));
		careProgram.clickOnFirstCorresRecord();
		docMgmt.verifyStartEndDateCorrespondence(corresDates.get(0), corresDates.get(1));

		Logger("STEP 46: Log out from application");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-11200 - To Verify removal of New Button and
	 * Activity Widget
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "To Verify removal of New Button and Activity Widget", enabled = true)
	public void AS15_IC11200_To_Verify_removal_of_New_Button_and_Activity_Widget() throws Exception {

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 2:  Navigate to care program enrollee object");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 3: Verify the ‘New’ button is removed from the Care Program Enrollee List View");
		accountObject.verifyAbsenceOfNewButton();
		String cpeListView = getCurrentPageURL();

		Logger("STEP 4: Navigate to Related tab of the CPE record>Navigate to Care Program Enrollee Products Section and select a CPEP record");
		docMgmt.verifyRecentlyViewList();
		documentsPage.searchDocument("Automation");
		missingInformatioPage.searchAndOpenRecord();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.clickOnCPEPRecord();
		String cpepUrl = getCurrentPageURL();

		Logger("STEP 5: Verify the activity widget is removed from the CPEP records and the remaining section should occupy the space");
		accountObject.verifyAbsenceOfActivityWidget();

		Logger("STEP 6: User Logout the Application.");
		documentsPage.logout();

		int numberOfUsers = 10;
		for (int i = 0; i < numberOfUsers; i++) {

			// Login based on the user role
			switch (i) {
				case 0:
					Logger("STEP 7: Login to the QA_SIT Org as 'BV'");
					homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
					break;

				case 1:
					Logger("STEP 8: Login to the QA_SIT Org as 'CM'");
					homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
					break;

				case 2:
					Logger("STEP 9: Login to the QA_SIT Org as 'PM'");
					homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
					break;

				case 3:
					Logger("STEP 10: Login to the QA_SIT Org as 'PC'");
					homeportalPage = loginPage.userLogin(PCUserName, UserPassword);
					break;

				case 4:
					Logger("STEP 11: Login to the QA_SIT Org as 'TPL'");
					homeportalPage = loginPage.userLogin(TPLUserName, UserPassword);
					break;

				case 5:
					Logger("STEP 12: Login to the QA_SIT Org as 'FRM'");
					homeportalPage = loginPage.userLogin(FRMUserName, UserPassword);
					break;

				case 6:
					Logger("STEP 13: Login to the QA_SIT Org as 'NurseEducator'");
					homeportalPage = loginPage.userLogin(NurseEduUserName, UserPassword);
					break;

				case 7:
					Logger("STEP 14: Login to the QA_SIT Org as 'BO'");
					homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
					break;

				case 8:
					Logger("STEP 15: Login to the QA_SIT Org as 'QM'");
					homeportalPage = loginPage.userLogin(QualityMGRUserName, UserPassword);
					break;

				case 9:
					Logger("STEP 16: Login to the QA_SIT Org as 'SA'");
					homeportalPage = loginPage.userLogin(SAUserName, UserPassword);
					break;

			}
			navigateToURL(cpeListView);
			accountObject.verifyAbsenceOfNewButton();
			navigateToURL(cpepUrl);
			accountObject.verifyAbsenceOfActivityWidget();
			documentsPage.logout();

		}

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE20973 R4-ADM Automate ICARE-16570
	 * SIT-Verify Specific fields are auto-populated when cases are created from
	 * cases related list on the CPE
	 * 
	 * @author Shanavaz Nishani
	 *         ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "SIT-Verify Specific fields are auto-populated when cases are created from cases related list on the CPE", enabled = true)
	public void RGNADM16_IC16570_Verify_Specific_fields_are_auto_populated_when_cases_are_created_from_cases_related_list_on_the_CPE()
			throws Exception {

		Logger("STEP 1: Login to the UAT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Navigate to App Launcher> Search and Select the Care Program Enrollee Object>Click on Recently Viewed List Views and select any the Care Program Enrollee Record");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7),
				DocumentPage.class);
		careProgram.searchRecord("Automation");
		docMgmt.openFirstRecentRecord();

		Logger("STEP 3: Navigate to Cases section on the related list >Click on New");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCasesTable();
		docMgmt.openCaseTable();
		String caseWindowURL = documentsPage.getCurrentURL();
		docMgmt.clickOnNewButton();

		Logger("STEP 4: Select the Welcome Message Case and Click on Next");
		documentsPage.createNewCase(caseTypes.get(2));

		Logger("STEP 5: Verify the below fields are auto populated. 1.Account name , 2.Care Program.Then Click on Save button");
		documentsPage.verifyFieldsAutopopulated("Account Name");
		documentsPage.verifyFieldsAutopopulated("Care Program");
		documentsPage.clickOnSave();

		Logger("STEP 6: Navigate Back to New Case Page>Select Injection Training Case from the New Case Page and Click on Next");
		navigateToURL(caseWindowURL);
		docMgmt.clickOnNewButton();
		documentsPage.createNewCase(caseTypes.get(1));

		Logger("STEP 7: Verify the below fields are auto populated, 1.Account name , 2.HCP Account Name.Then Click on Save button");
		documentsPage.verifyFieldsAutopopulated("Account Name");
		documentsPage.verifyFieldsAutopopulated("HCP Account Name");
		documentsPage.selectTrainingType(trainingType.get(0));
		documentsPage.selectHCPTrainingStatus(trainingStatus.get(0));
		documentsPage.clickOnSave();
		Logger("STEP 8: Navigate Back to New Case Page>Select Consent Opt Out Case from the New Case Page and Click on Next");
		navigateToURL(caseWindowURL);
		docMgmt.clickOnNewButton();
		documentsPage.createNewCase(caseTypes.get(6));

		Logger("STEP 9: Verify the below fields are auto populated, 1.Account name , 2.HCP Account Name.Then Click on Save button");
		documentsPage.verifyFieldsAutopopulated("Account Name");
		documentsPage.verifyFieldsAutopopulated("HCP Account Name");
		documentsPage.selectGlobalOptOutType("Yes");
		documentsPage.clickOnSave();

		Logger("STEP 10: Navigate Back to New Case Page>Select Consent Renewal Case from the New Case Page and Click on Next");
		navigateToURL(caseWindowURL);
		docMgmt.clickOnNewButton();
		documentsPage.createNewCase(caseTypes.get(7));

		Logger("STEP 11: Verify the below fields are auto populated. 1.Account name , 2.Care Program Enrollee.Then Click on Save button");
		documentsPage.verifyFieldsAutopopulated("Account Name");
		documentsPage.verifyFieldsAutopopulated("Care Program Enrollee");
		documentsPage.clickOnSave();

		Logger("STEP 12: Logout from the application");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: RGN-ADM: Automate ICARE-16643- ICARE-12725-SIT-TC01
	 * To Validate Updated Correspondence with System Admin (Read Only)
	 * 
	 * @author Shanavaz Nishani
	 *         ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "ICARE-12725-SIT-TC01-To Validate Updated Correspondence with System Admin (Read Only)", enabled = true)
	public void RGNADM17_IC16643_Validate_Updated_Correspondence_with_SystemAdmin_ReadOnly() throws Exception {

		Logger("STEP 1: Login to Application as System Admin Read only.");
		homeportalPage = loginPage.userLogin(SAUserName, UserPassword);

		Logger("STEP 2: Navigate to Master Correspondence Set object from App Launcher");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(16), DocumentPage.class);
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(16));
		assessmentTasksPage.clickOnListView("All");

		Logger("STEP 3.1: Verify Correspondence Master Data Records verify JRC/PRB date, Template Dup Code is updated as per table mentioned in Data table");
		for (Map.Entry<String, String[]> entry : ActiveDUPCodes.entrySet()) {
			String DUPid = entry.getKey();
			System.out.println(DUPid); // This is the ID
			String[] values = entry.getValue();
			accountObject.searchRecord(DUPid);
			accountObject.recordValidation(values[0], CorrespondenceActiveStatus.get(0), DUPid, values[1]); // These are the associated value
			getWebDriver().navigate().back();
		}

		Logger("STEP 3.2: Verify previous version of correspondence inactivated and JRC/PRB date populated for same");
		for (Map.Entry<String, String[]> entry : inactiveDUPcodes.entrySet()) {
			String DUPid = entry.getKey();
			System.out.println(DUPid); 
			String[] values = entry.getValue();
			accountObject.searchRecord(DUPid);
			accountObject.recordValidation(values[0], CorrespondenceActiveStatus.get(1), DUPid, values[1]);
			getWebDriver().navigate().back();
		}

		Logger("STEP 4: Verify Master Correspondence code MCS-744 is deactivated");
		accountObject.searchRecord(correspondences.get(5));
		accountObject.openMasterCorsp(correspondences.get(5));
		accountObject.validateActiveStatus(CorrespondenceActiveStatus.get(1));

		Logger("STEP 5: logout from the application");
		documentsPage.logout();
	}
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-15255:SIT:TC02: Validate Tax ID Field format on 
	 * Exiting facility record
	 * 
	 * @author Sonica P
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE-15255:SIT:TC02: Validate Tax ID Field format on Exiting facility record", enabled = true)
	public void AS18_IC25177_Validate_Tax_ID_Field_format_on_Exiting_facility_record()
			throws Exception {

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();
		
		Logger("STEP 2: Navigate to CPE object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(3), DocumentPage.class);
		Thread.sleep(4000);

		Logger("STEP 3: Click on list view drop down of Account object and go to All Facilities tab");
		docMgmt.ClicklistViewdropdownofAccounts();
		docMgmt.navigateToListofCPE(listViewFiltersAcc.get(0));
		Thread.sleep(5000);
		
		Logger("STEP 4: Click on existing Facilities record");
		docMgmt.selectExistingRec();
		Thread.sleep(5000);

		Logger("STEP 5: Edit Tax Id field to validate that is contains 9 char long and doesnt have any commas");
		docMgmt.validateTaxIdField(taxId.get(0));

		Logger("STEP 6: Log out from application");
		documentsPage.logout();
		
		//PC user
		Logger("STEP 1: Login to the QA_SIT Org as 'PC Manager'.");
		homeportalPage = loginPage.userLogin(PCUserName, UserPassword);
		homeportalPage.closeTabs();

		Logger("STEP 2: Navigate to CPE object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(3), DocumentPage.class);
		Thread.sleep(4000);

		Logger("STEP 3: Click on list view drop down of Account object and go to All Facilities tab");
		docMgmt.ClicklistViewdropdownofAccounts();
		docMgmt.navigateToListofCPE(listViewFiltersAcc.get(0));
		Thread.sleep(6000);
		
		Logger("STEP 4: Click on existing Facilities record");
		docMgmt.selectExistingRec();
		Thread.sleep(5000);

		Logger("STEP 5: Edit Tax Id field to validate that is contains 9 char long and doesnt have any commas");
		docMgmt.validateTaxIdField(taxId.get(0));

		Logger("STEP 6: Log out from application");
		documentsPage.logout();
		
		//PM User
		Logger("STEP 1: Login to the QA_SIT Org as 'PM Manager'.");
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		homeportalPage.closeTabs();

		Logger("STEP 2: Navigate to CPE object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(3), DocumentPage.class);
		Thread.sleep(4000);

		Logger("STEP 3: Click on list view drop down of Account object and go to All Facilities tab");
		docMgmt.ClicklistViewdropdownofAccounts();
		docMgmt.navigateToListofCPE(listViewFiltersAcc.get(0));
		
		Logger("STEP 4: Click on existing Facilities record");
		docMgmt.selectExistingRec();
		Thread.sleep(5000);

		Logger("STEP 5: Edit Tax Id field to validate that is contains 9 char long and doesnt have any commas");
		docMgmt.validateTaxIdField(taxId.get(0));

		Logger("STEP 6: Log out from application");
		documentsPage.logout();
	}

	
	
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-25146_To verify updates to Correspondence Template for Summary of Benefits
	 *
	 * @author Navita
	 *
	 * @throws Exception ====================================================================================================================
	 */
 
	@Test(description = "ICARE-25146-To verify updates to Correspondence Template for Summary of Benefits", enabled = true, priority = 5)
	public void AS011_ICARE_25146_To_verify_updates_to_Correspondence_Template_for_Summary_of_Benefits()
			throws Exception {
 
		Logger("Pre-Requisite : Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC11";
		SoftAssert softassert = new SoftAssert();
		
		String columnName[] = { "Diagnosis Code"};
		String columnValue[] = { "L28.1 - Prurigo nodularis" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];
 
		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());
 
		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
		
			Logger("STEP 2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);
 
		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();
 
		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));
 
		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
 
		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
		Logger("STEP 10: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];
 
		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(1),
				ExcelTestData.get(patientDOB));
		
		patientSearch.clickOnNextButton();
 
		// patientinfoAndauthorization-Page
		Logger("STEP 14:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];
 
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();
 
		// Patient Insurance - Page
		Logger("STEP 15:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();
 
		Logger("STEP 16:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];
 
		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];
 
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();
 
		// Diagnosis information-Page
		Logger("Pre-requisite STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();
 
		Logger("Pre-requisite STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];
 
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();
 
		Logger("Pre-requisite STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
	
				
		Logger("STEP 14:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
	
    	Logger("STEP 6: Change member plan to active");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.verifyPrimaryRecordMemberPlansSection();
		docMgmt.changeMemberPlanStatusActive(pharamcyMember.get(0));
		docMgmt.clickSaveButton();
		
		Logger("Pre-requisite STEP 16: Logout as a DIS User.");
		documentsPage.logout();
						

		int numberOfUsers = 4;
 
		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
					case 0:
						Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
						homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
						break;
					case 1:
						Logger("STEP 1: Login to the QA_SIT Org as 'BV User'.");
						homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
						break;
 
					case 2:
						Logger("STEP 1: Login to the QA_SIT Org as 'PM User'.");
						homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
						break;
					case 3:
						Logger("STEP 1: Login to the QA_SIT Org as 'BusimessOps User'.");
						homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
						break;
				}		
		
		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		
		
		Logger("STEP 14:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		String hubId = accountObject.getHubIDField();
				
		Logger("STEP 15:Navigate to the below mentioned objects and validate the new records linked and created upon the submission of EF\r\n");
 
		// CPE
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
 
		String url = getCurrentPageURL();
		
		refresh();
		Logger("STEP 16: Click on the Correspondence button");
		docMgmt.clickOnCorrespondenceBotton();
 
		Logger("STEP 17: Select the Process Name as 'BV' and Select items to Send as ' DMW Summary of Benefits-MD Fax' and Click on Next");
		docMgmt.selectProcessName(selectProcessName.get(0));
		docMgmt.selectItemsToSend(bvitemsToSend.get(2));
		missingInformatioPage.clickNextButton();
		docMgmt.enterFaxNumber(ExcelTestData.get(officeFax));
		missingInformatioPage.clickNextButton();
 
		Logger("STEP 18: Verify Generate Document Correspondence Screen opens and user can send the Correspondence");				
		docMgmt.clickSendButtonUntilFinish();	
		
		Logger("STEP 19: Validate success message is populated in the Correspondence record");
		String msg = docMgmt.validateSuccessMessage();
		if (msg.contains(summaryofBenefitMDFAXSuccessMSG)) {
			Logger("Success message verified.");
		} else {
			Logger("Success message not found.");
			softassert.fail();
			throw new Exception("Success message not found.");
		}
		docMgmt.clickonFinishButton();
		missingInformatioPage.navigateToCPERecord(cpeName);
		refresh();
			
		Logger("STEP 7: Validate PDF Files present in Related List of Correspondence ");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecord(bvitemsToSend.get(2));
		String pdfName = bvitemsToSend.get(2).trim();
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.deleteExistingFile(downloadPath);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);
 
		// Data validation
		String payerNumber = Utility_Function.formatNumber(ExcelTestData.get(rxPhone));
		String dupCode = "US.DUP.25.05.0073";	
		String currentDate = Utility_Function.getNthDayFromTodayFormatyyyyMMdd(0);
		String patientDob = Utility_Function.changeDateFormatyyyyMMdd(ExcelTestData.get(patientDOB));
 
		Map<String, Integer> fieldsToValidate = new HashMap<>();
		fieldsToValidate.put("Patient: "+ExcelTestData.get(patientName), 2);
		fieldsToValidate.put(ExcelTestData.get(prescriberAddress), 2);
		fieldsToValidate.put(ExcelTestData.get(prescriberCity),2);
		fieldsToValidate.put(ExcelTestData.get(prescriberState),2);
		fieldsToValidate.put(ExcelTestData.get(prescriberZip),2);
		fieldsToValidate.put("Date of Birth: " +patientDob,2);
		fieldsToValidate.put(hubId,2);
		fieldsToValidate.put(dupCode,2);
		
		fieldsToValidate.put(ExcelTestData.get(rxBIN),3);
		fieldsToValidate.put(ExcelTestData.get(rxPCN),3);
 
		// Pharmacy
		fieldsToValidate.put("Rx Plan Name " + ExcelTestData.get(rxPayerName), 3);
		fieldsToValidate.put("Rx Member Number " + ExcelTestData.get(rxPolicyID), 3);
		fieldsToValidate.put("Rx Group Number " + ExcelTestData.get(rxGroup), 3);
 
		Logger("STEP 8: Validate the COVERAGE PROFILE REPORT will only show the primary Insurance details");
		docMgmt.validateMultiplePDFFields(downloadPath, fieldsToValidate);
		
		navigateToUrl(url);
		
		Logger("STEP 20: Navigate back to the CPE record → Click on the related tab and Go to the Correspondence list Validate that a new Correspondence record has been created ");
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();
		careProgram.clickOnViewAll("Correspondences");
		docMgmt.verifyCorrespondenceRecord(selectProcessName.get(0));
		docMgmt.clickOnCorrespondenceRecord(selectProcessName.get(0));
		docMgmt.verifyDUPCode(dupCode);
		
		homeportalPage.closeTabs();
		docMgmt.navigate(url);
		refresh();
		Logger("STEP 21: Click on the Correspondence button");
		docMgmt.clickOnCorrespondenceBotton();
 
		Logger("STEP 17: Select the Process Name as 'PA' and Select items to Send as ' DMW Summary of Benefits-MD Fax' and Click on Next");
		docMgmt.selectProcessName(selectProcessName.get(1));
		docMgmt.selectItemsToSend(itemToSend.get(2));
		missingInformatioPage.clickNextButton();
		docMgmt.enterFaxNumber(ExcelTestData.get(officeFax));
		missingInformatioPage.clickNextButton();
 
		Logger("STEP 18: Verify Generate Document Correspondence Screen opens and user can send the Correspondence");				
		docMgmt.clickSendButtonUntilFinish();	
 
		Logger("STEP 19: Validate success message is populated in the Correspondence record");
		String msg1 = docMgmt.validateSuccessMessage();
		if (msg1.contains(summaryofBenefitsPASuccessMSG)) {
			Logger("Success message verified.");
		} else {
			Logger("Success message not found.");
			softassert.fail();
			throw new Exception("Success message not found.");
		}
		docMgmt.clickonFinishButton();
		missingInformatioPage.navigateToCPERecord(cpeName);
		refresh();	
		
		Logger("STEP 7: Validate PDF Files present in Related List of Correspondence ");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecord(itemToSend.get(2));
		String pdfName1 = itemToSend.get(2).trim();
		String downloadPath1 = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName1 + ".pdf";
		docMgmt.deleteExistingFile(downloadPath1);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName1);
 
 
		Map<String, Integer> fieldsToValidate1 = new HashMap<>();
		fieldsToValidate1.put("Patient: "+ExcelTestData.get(patientName), 2);
		fieldsToValidate1.put(ExcelTestData.get(prescriberAddress), 2);
		fieldsToValidate1.put(ExcelTestData.get(prescriberCity),2);
		fieldsToValidate1.put(ExcelTestData.get(prescriberState),2);
		fieldsToValidate1.put(ExcelTestData.get(prescriberZip),2);
		fieldsToValidate1.put("Date of Birth: " +patientDob,2);
		fieldsToValidate1.put(hubId,2);
		fieldsToValidate1.put(dupCode,2);
		
		fieldsToValidate1.put(ExcelTestData.get(rxBIN),3);
		fieldsToValidate1.put(ExcelTestData.get(rxPCN),3);
 
		// Pharmacy
		fieldsToValidate1.put("Rx Plan Name " + ExcelTestData.get(rxPayerName), 3);
		fieldsToValidate1.put("Rx Member Number " + ExcelTestData.get(rxPolicyID), 3);
		fieldsToValidate1.put("Rx Group Number " + ExcelTestData.get(rxGroup), 3);
 
		Logger("STEP 8: Validate the COVERAGE PROFILE REPORT will only show the primary Insurance details");
		docMgmt.validateMultiplePDFFields(downloadPath1, fieldsToValidate1);
		docMgmt.clickCloseBtn();
		documentsPage.logout();
		}
			catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				documentsPage.logout();
			}
		}
		
		Logger("STEP 1:Login to the QA_SIT Org as 'System admin'.");
		homeportalPage = loginPage.userLogin(SAUserName, UserPassword);
		
		Logger("STEP 2: Navigate to Master Correspondence Set object from App Launcher");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(16), DocumentPage.class);
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(16));
		assessmentTasksPage.clickOnListView("All");
		
		Logger("STEP 4: Open DMW Copay Card Information - MD Fax for BV and Validate start and End Date, Dupix Code");
		careProgram.searchRecord(DUPCode.get(5));
		careProgram.clickOnFirstCorresRecord();
		docMgmt.verifyCorresDUPCode(DUPCode.get(5));
		docMgmt.verifyStartEndDateCorrespondence(corresDates.get(8), corresDates.get(9));
		accountObject.validateActiveStatus(CorrespondenceActiveStatus.get(0));
		
		careProgram.navigateToAllCorresTab();
		refresh();
		careProgram.searchRecord(DUPCode.get(5));
		careProgram.clickOnCorrespondanceRecord(BusinessProcess.get(2));
		docMgmt.verifyCorresDUPCode(DUPCode.get(5));
		docMgmt.verifyStartEndDateCorrespondence(corresDates.get(8), corresDates.get(9));
		accountObject.validateActiveStatus(CorrespondenceActiveStatus.get(0));
		
		documentsPage.logout();
	}
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-16257
	 * Validate if an existing SP/ Payer is selected with Source system "iCare+", the existing Alliance SP/ Payer will be tagged to CPE
	 * 
	 * @author Tejal pednekar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Validate if an existing SP/ Payer is selected with Source system \"iCare+\", the existing Alliance SP/ Payer will be tagged to CPE", enabled = true)
	public void AS06_IC_16257_IC_20978_Validate_if_an_existing_SPPayer_is_selected_with_Source_systemiCare_the_existing_Alliance_SPPayer_will_be_tagged_to_CPE()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC13";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax", "Diagnosis Code",
				"DUPIXENT MyWay", "Preferred Specialty Pharmacy", "Office Fax" };
		String columnValue[] = { "Automation Correspondence SP", "(954) 312-1432", "(166) 254-1171",
				"L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE", "(166) 254-1171" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		refresh();
	
		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(2));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 10.1:Navigate to the Accounts Object >> Select and Open the Patient Record >> Navigate to the Related List  and Open the Care Program Enrollee associated to it >> Navigate to the related list of Care Program Enrollee And Open the  Care Program Enrollee Product >> Navigate to Related List of the opened record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		careProgram.clickOnViewAll("Member Plans");
	
		
		careProgram.verifyMemberPlanSections("TestAutomation Payer Pharmacy","TestAutomation Payer Medical");
		

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

	}
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-16683
	 *  Validating CPEP SP fields are restricted post creation from BV task
	 * 
	 * @author Tejal pednekar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Validating CPEP SP fields are restricted post creation from BV task", enabled = true)
	public void AS06_IC_16683_IC_20979_Validating_CPEP_SP_fields_restricted_postcreation_from_BV_task()
			throws Exception {
        
		String cpeUrl = null;
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC15";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax", "Diagnosis Code",
				"DUPIXENT MyWay", "Preferred Specialty Pharmacy", "Office Fax" };
		String columnValue[] = { "Automation Correspondence SP", "(954) 312-1432", "(166) 254-1171",
				"L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE", "(166) 254-1171" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		refresh();
	
		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(2));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 10.1:Navigate to the Accounts Object >> Select and Open the Patient Record >> Navigate to the Related List  and Open the Care Program Enrollee associated to it >> Navigate to the related list of Care Program Enrollee And Open the  Care Program Enrollee Product >> Navigate to Related List of the opened record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);

		cpeUrl = getCurrentPageURL();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();
		
		Logger("STEP 1: Navigate to the Care program Enrollee Record and validate USer is able to perform BV and other patient journey steps");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		
		navigateToUrl(cpeUrl);
		
		Logger("STEP 17: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		
		Logger("STEP 32: Select Payer Collected .");
		bvPage.enterPharmacy1Details(AllianceSP_List.get(0));
		bvPage.enterPharmacy2Details(AllianceSP_List.get(2));
		bvPage.enterPharmacy3Details(AllianceSP_List.get(3));
		
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
		accountObject.clickOnTab(tabsName.get(1));
		careProgram.clickOnViewAll("Care Program Enrollee Product SPs");
		iapPage.navigateToCPEPSpRecord(AllianceSP_List.get(0));
		docMgmt.verifyPSPisMandatory();
		docMgmt.validateSPTypeisNotEditable();
		
		docMgmt.validateSPType("Alliance");
		Logger("STEP 17: logout from applilcaton");
		documentsPage.logout();
		
		Logger("STEP 1: Navigate to the Care program Enrollee Record and validate USer is able to perform BV and other patient journey steps");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		
		navigateToUrl(cpeUrl);
		
		
		

	}
	
	

	
}