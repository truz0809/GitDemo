package com.sanofi.selenium.Regression;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.HealthcareAccountSearch;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.LoginPage;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;

public class Phone extends BaseTest {
	public String filePath;
	public ReadExcel excel;
	public String fileName;
	String functionality = "RGNPhone";

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		sheetName = "RGNPhone";
		excel = new ReadExcel(sheetName);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		uploadDocs = GetInstance(UploadDocument.class);
		triagePage = GetInstance(TriagePage.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		hcAccountSearch = GetInstance(HealthcareAccountSearch.class);
	}


	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}
	

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-13420 - Validate E-Sign for portal is correctly set up for enrollment forms
	 * 
	 * @author Kavyashree MB
	 * @Maintenance_author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Validate E-Sign for portal is correctly set up for enrollment forms", enabled = true)
	public void Ph01_IC13420_Validate_E_Sign_for_portal_is_correctly_set_up_for_enrollment_forms()
			throws Exception {
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String testCaseNumber = "TC1";
		ExcelTestData = excel.getExcelInputData(testCaseNumber);
		String docName = "Patient Consent and Enrollment Form – English.pdf";

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
		
		Logger("STEP 1: Launch the Following Portal URL");
		uploadDocs.navigateToDupxientUrl();

		dupixentPortal.handleLoginScreen();
		
		Logger("STEP 2: Once URL is launched, from the welcome a Pop up is displayed Click on \"I am a Patient or Caregiver\" button");
		dupixentPortal.clickOnAcceptAllCookies();
		dupixentPortal.handleLoginScreen();
		dupixentPortal.clickOnAcceptAllCookies();
		dupixentPortal.clickOnPatientorCaregiverButton();

		Logger("STEP 3: Click the \"Electronically Sign Patient Consent Form\" button in the home page.");
		dupixentPortal.clickOnElectronicConsentForm();

		Logger("STEP 4: Validate the User is navigating to \"Patient eSignature Authorization Form\" Page.");
		dupixentPortal.verifyPatienteSignatureAuthorizationPageForms();
		dupixentPortal.selectCategoryForForm(formCategory.get(0));

		Logger("STEP 6:  Click on continue button, start button and Validate the user can enter values for all mandatory fields on the Patient Enrollment form  PDF’s ");
		dupixentPortal.enterPatientInfo(ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone));
		dupixentPortal.esignPDF();

		Logger("STEP 7: Verify the once all required fields are entered, the user is able to proceed and confirm submission of their signature via the Adobe e-Sign window");
		dupixentPortal.clickToSign(ExcelTestData.get(patientEmail));

		Logger("STEP 8: After Submitting the Documents from the Dupixent Portal, Now Log in  as PM User");
		uploadDocs.navigateToSFUrl();
		boolean homepage = dupixentPortal.verifyLoginScreen();
		
		loginPage = GetInstance(LoginPage.class);
		if (homepage) {
			homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		} else {
			documentsPage.logout();
			homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		}

		Logger("STEP 9: Click on the App Launcher and navigate to iCare Connect App >> Received Documents Object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

		Logger("STEP 10: Change List view to All Received documents and change the owner");
		documentsPage.verifyRecentlyViewDocumentList();
		documentsPage.navigateToAllReceivedDocPMUser();
		Thread.sleep(5000);
		documentsPage.searchDocument(docName);
		documentsPage.verifyRecordAndClick(docName);
		documentsPage.changeOwner();

		Logger("STEP 11: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 12: verify to login as DIS User ");
		uploadDocs.loginAsDISUser();
	
		Logger("STEP 13: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 14:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.verifyToOpenDoc(docName);

		Logger("STEP 15:Select document type as Enrollment Form and click on submit");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		patientSearch.verifyPatientSearchPageTitle();

		Logger("STEP 16: User Logout the Application.");
		documentsPage.logout();

	}


}
