package com.sanofi.selenium.Regression;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.AuthorizationFormConsentPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.ConsentCaptureDate;
import com.sanofi.selenium.pages.CopayFlow;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.HealthcareAccountSearch;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PAPPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;

public class ConsentPrefManagement extends BaseTest {
	private static ThreadLocal<String> filePath = new ThreadLocal<>();
	public ReadExcel excel;
	public String fileName;
	String functionality = "Consent Management";

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		authorizationConsentPage = GetInstance(AuthorizationFormConsentPage.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		sheetName = "Consent_Management";
		excel = new ReadExcel(sheetName);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		uploadDocs = GetInstance(UploadDocument.class);
		triagePage = GetInstance(TriagePage.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		hcAccountSearch = GetInstance(HealthcareAccountSearch.class);
		consentCaptureDate = GetInstance(ConsentCaptureDate.class);
		copayFlow = GetInstance(CopayFlow.class);
		papPage = GetInstance(PAPPage.class);


	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	@Test(description = "SIT_Prior Authorization Workflow Patient Enrollment Prerequisites", enabled = true)
	public String PatientEnrollment_Prerequisites(String testcaseNumber) throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "State", "Zip", "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "Alaska", "99501", "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());
		//fileName = documentsPage.getFileName(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 10: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 11: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 12:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		Thread.sleep(20000);
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 13:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 15:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 16:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 17:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 18:Verify account is created ");
		accountObject.globalSearchAcc(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 19: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 20: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 21: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 22: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 23:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);

		Logger("STEP 24: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();

		return ID;

	}

	@Test(description = "TC01-Creation of Authorization Form Consent records", enabled = true, priority = 10)
	public void CM01_IC886_creation_Of_Authorization_Form_ConsentRecords() throws Exception {

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 2: Navigate to Authorization Form Consent object from App Launcher and verify Recently Viewed authorization form consent page is displayed.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(6), DocumentPage.class);
		authorizationConsentPage.verifyAuthorizationConsentPage();

		Logger("STEP 3: Verify that user is able to click on New button present on the Authorization Form Consent page.");
		authorizationConsentPage.verifyClickNewButton();

		Logger("STEP 4: Verify that a new Authorization Form Consent page opens with below record types-1.Authorization Consent2.Contact Consent");
		authorizationConsentPage.verifyConsentRecords();

		Logger("STEP 5: Verify user is able to click on next button.");
		authorizationConsentPage.selectAuthorizationConsent();
		authorizationConsentPage.verifyNextButton();

		Logger("STEP 6:On new Authorization Form Consent page, verify fields are visibl");
		authorizationConsentPage.verifyPageFields();

		Logger("STEP 7:Verify user is able to view Save, Save & New and Cancel button below the fields mentioned.");
		authorizationConsentPage.verifySaveNewCancelButton();

		Logger("STEP 8:Verify that user is able to save the record by filling all the mandatory fields.");
		authorizationConsentPage.saveAuthorizationFormConsentRecord();

		Logger("STEP 9:Log out from application");
		documentsPage.logout();
	}

	@Test(description = "TC02-Validation of the Authorization Form Consent Object - Creation of HIPPA Authorization and validation of consent expiration logic for Other States where Patient's 18 Birthday + 180 < Consent Signed Date+ 540", enabled = true)
	public void CM02_IC887_validation_Of_The_Authorizatio_Form_ConsentObject_creation_Of_HIPPAAuthorization()
			throws Exception {

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC3";

		String columnName[] = { "Patient DOB", "Patient Authorization Date", "State", "Diagnosis Code",
				"Text Messaging Consent", };
		String columnValue[] = { "01-16-2007", "05-01-2024", "California", "L20.9 - Atopic dermatitis, unspecified",
				"TRUE" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite 02: User updates the Patient Form");

		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 4:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 5:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 16:Verify if the 'Account--> Patient' record is visible");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		accountObject.authorizationFormConsents(ExcelTestData.get(patientName),
				careProgramProduct.get(2).split(" - ")[0], ExcelTestData.get(patientCertificationsDate),
				patientcertSigned.get(0), ExcelTestData.get(patientAuthorizationDate), authorizationSigned.get(0),
				ExcelTestData.get(prescriberSignatureDate), prescriberSignature.get(0),
				ExcelTestData.get(textMessagingConsent));

		// HIPPA Consent Verification
		Logger("STEP 17:Verify Consent Expiration Date logic for OTHER STATES");
		accountObject.verifyHIPAAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientAuthorizationDate));

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();
	}

	@Test(description = "TC03-Creation of HIPPA Authorization and validation of consent expiration logic for Other States where Patient's 18 Birthday + 180 > Consent Signed Date+ 540", enabled = true, priority = 12)
	public void CM03_IC1082_validationOfTheAuthorizationFormConsentObject_creationOfHIPPAAuthorization()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC3";
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Patient DOB", "Patient Authorization Date", "Text Messaging Consent", "State",
				"Diagnosis Code", "Pharmacy Fax" };
		String columnValue[] = { "05-06-2008", "05-16-2024", "TRUE", "Alaska", "J33.0 - Polyp of nasal cavity", "" };
		// Monday, 2 November 2026
		// Friday, 7 November 2025

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite 2 : User updates the Patient Form");

		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Nasal Polyps");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		// Accounts Validation
		Logger("STEP 15:From App Launcher, search and click on the '*Accounts*' Object and Verify that patient account is created..");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		accountObject.authorizationFormConsents(ExcelTestData.get(patientName),
				careProgramProduct.get(0).split(" - ")[0], ExcelTestData.get(patientCertificationsDate),
				patientcertSigned.get(0), ExcelTestData.get(patientAuthorizationDate), authorizationSigned.get(0),
				ExcelTestData.get(prescriberSignatureDate), prescriberSignature.get(0),
				ExcelTestData.get(textMessagingConsent));

		Logger("STEP 16:Verify that user is able to navigate to Authorization Form Consent object and is able to view consents records");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.authorizationFormConsents(ExcelTestData.get(patientName),
				careProgramProduct.get(0).split(" - ")[0], ExcelTestData.get(patientCertificationsDate),
				patientcertSigned.get(0), ExcelTestData.get(patientAuthorizationDate), authorizationSigned.get(0),
				ExcelTestData.get(prescriberSignatureDate), prescriberSignature.get(0),
				ExcelTestData.get(textMessagingConsent));

		Logger("STEP 17:Now, Open the HIPAA Authorization record and verify whether record is created by the name 'Patient Name: HIPAA Authorization'");
		accountObject.verifyHIPAAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientAuthorizationDate));

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

	}

	@Test(description = "TC04-Creation of HIPPA Authorization and validation of consent expiration logic for Puerto Rico where Patient's 21 Birthday + 180 < Consent Signed Date+ 540", enabled = true, priority = 13)
	public void CM04_IC1252_validationOfTheAuthorizationFormConsentObject_creationOfHIPPAAuthorization()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC20";
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Patient DOB", "Patient Authorization Date", "Text Messaging Consent", "State",
				"Diagnosis Code" };
		String columnValue[] = { "05-06-2004", "05-17-2024", "TRUE", "Puerto Rico",
				"K20.0 - Eosinophilic esophagitis" };
		// Sunday, 2 November 2025
		// Saturday, 8 November 2025

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite 2 : User updates the Patient Form");

		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("EOE");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}

		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		documentsPage.verifyRecentlyViewDocumentList();

		// Accounts Validation
		Logger("STEP 15:From App Launcher, search and click on the '*Accounts*' Object and Verify that patient account is created..");
		accountObject.navigateToAccount();
		refresh();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 16:Verify that user is able to navigate to Authorization Form Consent object and is able to view consents records");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.authorizationFormConsents(ExcelTestData.get(patientName),
				careProgramProduct.get(4).split(" - ")[0], ExcelTestData.get(patientCertificationsDate),
				patientcertSigned.get(0), ExcelTestData.get(patientAuthorizationDate), authorizationSigned.get(0),
				ExcelTestData.get(prescriberSignatureDate), prescriberSignature.get(0),
				ExcelTestData.get(textMessagingConsent));

		Logger("STEP 17:Now, Open the HIPAA Authorization record and verify whether record is created by the name 'Patient Name: HIPAA Authorization'");
		accountObject.verifyHIPAAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientAuthorizationDate));

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

	}

	@Test(description = "TC05- Authorization Form - Creation of HIPPA Authorization and validation of consent expiration logic for Puerto Rico where Patient's 21 Birthday + 180 > Consent Signed Date+ 540", enabled = true, priority = 14)
	public void CM05_IC1757_validationOfTheAuthorizationFormConsentObject_creationOfHIPPAAuthorization()
			throws Exception {

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC9";

		String columnName[] = { "Patient DOB", "Patient Authorization Date", "State", "Diagnosis Code",
				"Text Messaging Consent" };
		String columnValue[] = { "05-06-2005", "05-16-2024", "Puerto Rico",
				"J45.40 - Moderate persistent asthma, uncomplicated", "TRUE" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];
		
		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		System.out.println(ExcelTestData.get(pharmacyfax));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		// Accounts Validation
		Logger("STEP 15:Verify if the 'Account--> Patient' record is visible");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.authorizationFormConsents(ExcelTestData.get(patientName),
				careProgramProduct.get(2).split(" - ")[0], ExcelTestData.get(patientCertificationsDate),
				patientcertSigned.get(0), ExcelTestData.get(patientAuthorizationDate), authorizationSigned.get(0),
				ExcelTestData.get(prescriberSignatureDate), prescriberSignature.get(0),
				ExcelTestData.get(textMessagingConsent));

		// Hippa Consent Verification
		Logger("STEP 16:Verify Consent Expiration Date logic for OTHER STATES");
		accountObject.verifyHIPAAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientAuthorizationDate));

		Logger("STEP 17: User Logout the Application.");
		documentsPage.logout();
	}

	@Test(description = "ICARE-35 - Consent Management - SIT -TC06-Validation of the Authorization Form Consent Object - Creation of HIPPA Authorization and validation of consent expiration logic for Minnesota/ Maryland where Patient's 18 Birthday + 180 < Consent Signed Date+ 365", enabled = true, priority = 15)
	public void CM06_IC1758_validationOfTheAuthorizationFormConsentObject_creationOfHIPPAAuthorization()
			throws Exception {

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC9";

		String columnName[] = { "Patient DOB", "Patient Authorization Date", "State", "Diagnosis Code",
				"Text Messaging Consent" };
		String columnValue[] = { "07-06-2008", "05-16-2024", "Minnesota", "L28.1 - Prurigo nodularis", "TRUE" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Prurigo Nodularis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(1),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		// Accounts Validation
		Logger("STEP 15:Verify if the 'Account--> Patient' record is visible");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();

		accountObject.clickOnTab(tabsName.get(1));
		accountObject.authorizationFormConsents(ExcelTestData.get(patientName),
				careProgramProduct.get(1).split(" - ")[0], ExcelTestData.get(patientCertificationsDate),
				patientcertSigned.get(0), ExcelTestData.get(patientAuthorizationDate), authorizationSigned.get(0),
				ExcelTestData.get(prescriberSignatureDate), prescriberSignature.get(0),
				ExcelTestData.get(textMessagingConsent));

		// Hippa Consent Verification
		Logger("STEP 16:Verify Consent Expiration Date logic for OTHER STATES");
		accountObject.verifyHIPAAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientAuthorizationDate));

		Logger("STEP 17: User Logout the Application.");
		documentsPage.logout();
	}

	@Test(description = "TC07-Validation of the Authorization Form Consent Object - Creation of HIPPA Authorization and validation of consent expiration logic for Minnesota/ Maryland where Patient's 18 Birthday + 180 > Consent Signed Date+ 365", enabled = true, priority = 16)
	public void CM07_IC1764_validationOfTheAuthorizationFormConsentObject_creationOfHIPPAAuthorization()
			throws Exception {

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC3";

		String columnName[] = { "Patient DOB", "Patient Authorization Date", "State", "Diagnosis Code",
				"Text Messaging Consent" };
		String columnValue[] = { "05-06-2009", "03-08-2024", "Maryland", "L20.9 - Atopic dermatitis, unspecified",
				"TRUE" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		 documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		// Accounts Validation
		Logger("STEP 11:Verify if the 'Account--> Patient' record is visible");
		accountObject.navigateToAccount();
		refresh();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();

		accountObject.clickOnTab(tabsName.get(1));
		accountObject.authorizationFormConsents(ExcelTestData.get(patientName),
				careProgramProduct.get(2).split(" - ")[0], ExcelTestData.get(patientCertificationsDate),
				patientcertSigned.get(0), ExcelTestData.get(patientAuthorizationDate), authorizationSigned.get(0),
				ExcelTestData.get(prescriberSignatureDate), prescriberSignature.get(0),
				ExcelTestData.get(textMessagingConsent));

		// Hippa Consent Verification
		Logger("STEP 12:Verify Consent Expiration Date logic for OTHER STATES");
		accountObject.verifyHIPAAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientAuthorizationDate));

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();
	}

	@Test(description = "ICARE-35 - Consent Management - SIT -TC08-Validation of the Authorization Form Consent Object - Creation of Patient Program Authorization and validating consent expiration logic for Other States where Patient's 18 Birthday + 180 < Consent Signed Date+ 540", enabled = true, priority = 17)
	public void CM08_IC982_validationOfTheAuthorizationFormConsentObject_creationOfPatientProgramAuthorization()
			throws Exception {

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC3";

		String columnName[] = { "Patient DOB", "Patient Certifications Date", "State", "Diagnosis Code",
				"Text Messaging Consent" };
		String columnValue[] = { "09-06-2006", "04-09-2024", "Arkansas", "K20.0 - Eosinophilic esophagitis", "TRUE" };
		// Wednesday, 5 March 2025
		// Wednesday, 1 October 2025

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("EOE");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		 documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));

		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		documentsPage.verifyRecentlyViewDocumentList();

		// Accounts Validation
		Logger("STEP 15:Verify if the 'Account--> Patient' record is visible");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();

		accountObject.clickOnTab(tabsName.get(1));
		accountObject.authorizationFormConsents(ExcelTestData.get(patientName),
				careProgramProduct.get(4).split(" - ")[0], ExcelTestData.get(patientCertificationsDate),
				patientcertSigned.get(0), ExcelTestData.get(patientAuthorizationDate), authorizationSigned.get(0),
				ExcelTestData.get(prescriberSignatureDate), prescriberSignature.get(0),
				ExcelTestData.get(textMessagingConsent));

		// PPA Consent Verification
		Logger("STEP 16:Verify Consent Expiration Date logic for OTHER STATES");
		accountObject.verifyPPAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientCertificationsDate));

		Logger("STEP 17: User Logout the Application.");
		documentsPage.logout();

	}

	@Test(description = "ICARE-35 - Consent Management - SIT -TC09-Validation of the Authorization Form Consent Object - Creation of Patient Program Authorization and validating consent expiration logic for Other States where Patient's 18 Birthday + 180 > Consent Signed Date+ 540", enabled = true, priority = 18)
	public void CM09_IC1246_validationOfTheAuthorizationFormConsentObject_creationOfPPAAuthorization()
			throws Exception {

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC10";

		String columnName[] = { "Patient DOB", "Patient Certifications Date", "State", "Diagnosis Code",
				"Text Messaging Consent", "Pharmacy Fax" };
		String columnValue[] = { "05-06-2009", "05-16-2024", "Alabama", "J33.0 - Polyp of nasal cavity", "TRUE", "" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Nasal Polyps");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		 documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));

		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		// Accounts Validation
		Logger("STEP 11:Verify if the 'Account--> Patient' record is visible");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));

		refresh();

		accountObject.clickOnTab(tabsName.get(1));
		accountObject.authorizationFormConsents(ExcelTestData.get(patientName),
				careProgramProduct.get(0).split(" - ")[0], ExcelTestData.get(patientCertificationsDate),
				patientcertSigned.get(0), ExcelTestData.get(patientAuthorizationDate), authorizationSigned.get(0),
				ExcelTestData.get(prescriberSignatureDate), prescriberSignature.get(0),
				ExcelTestData.get(textMessagingConsent));

		// PPA Consent Verification
		Logger("STEP 12:Verify Consent Expiration Date logic for OTHER STATES");
		accountObject.verifyPPAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientCertificationsDate));

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();
	}

	@Test(description = "ICARE-35-Consent Management-SIT-TC10-Validation of the Authorization Form Consent Object - Creation of Patient Program Authorization and validating consent expiration logic for Puerto Rico where Patient's 21 Birthday + 180 < Consent Signed Date+ 540", enabled = true)
	public void CM10_IC1786_validationOfTheAuthorizationFormConsentObject_creationOfPPAAuthorization()
			throws Exception {

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC4";

		String columnName[] = { "Patient DOB", "Patient Certifications Date", "State", "Diagnosis Code",
				"Text Messaging Consent" };
		String columnValue[] = { "01-01-2004", "07-16-2024", "Puerto Rico",
				"J45.40 - Moderate persistent asthma, uncomplicated", "TRUE" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		 documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));

		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		documentsPage.verifyRecentlyViewDocumentList();

		// Accounts Validation
		Logger("STEP 11:Verify if the 'Account--> Patient' record is visible");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();

		accountObject.clickOnTab(tabsName.get(1));
		accountObject.authorizationFormConsents(ExcelTestData.get(patientName),
				careProgramProduct.get(0).split(" - ")[0], ExcelTestData.get(patientCertificationsDate),
				patientcertSigned.get(0), ExcelTestData.get(patientAuthorizationDate), authorizationSigned.get(0),
				ExcelTestData.get(prescriberSignatureDate), prescriberSignature.get(0),
				ExcelTestData.get(textMessagingConsent));

		// PPA Consent Verification
		Logger("STEP 12:Verify Consent Expiration Date logic for OTHER STATES");
		accountObject.verifyPPAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientCertificationsDate));

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();
	}

	@Test(description = "ICARE-35 - Consent Management - SIT -TC1789-Validation of the Authorization Form Consent Object - Creation of Patient Program Authorization and validating consent expiration logic for Puerto Rico where Patient's 21 Birthday + 180 > Consent Signed Date+ 540", enabled = true, priority = 20)
	public void CM11_IC1789_validationOfTheAuthorizationFormConsentObject_creationOfPPAAuthorization()
			throws Exception {

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC12";

		String columnName[] = { "Patient DOB", "Patient Certifications Date", "State", "Diagnosis Code",
				"Text Messaging Consent", "Pharmacy Fax" };
		String columnValue[] = { "05-06-2005", "04-09-2024", "Puerto Rico", "J33.0 - Polyp of nasal cavity", "TRUE",
				"" };
		// Monday, 2 November 2026
		// Wednesday, 1 October 2025

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("EOE");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		 documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));

		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		documentsPage.verifyRecentlyViewDocumentList();

		// Accounts Validation
		Logger("STEP 11:Verify if the 'Account--> Patient' record is visible");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.authorizationFormConsents(ExcelTestData.get(patientName),
				careProgramProduct.get(0).split(" - ")[0], ExcelTestData.get(patientCertificationsDate),
				patientcertSigned.get(0), ExcelTestData.get(patientAuthorizationDate), authorizationSigned.get(0),
				ExcelTestData.get(prescriberSignatureDate), prescriberSignature.get(0),
				ExcelTestData.get(textMessagingConsent));

		// PPA Consent Verification
		Logger("STEP 12:Verify Consent Expiration Date logic for Puerto Rico");
		accountObject.verifyPPAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientCertificationsDate));

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

	}

	@Test(description = "TC012-Validation of the Authorization Form Consent Object for HCP, Email and Text", enabled = true, priority = 21)
	public void CM12_IC4198_Validation_of_AuthorizationFormConsent_Object_for_HCP_Email_and_Text() throws Exception {

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String testCaseNumber = "TC7";

		String columnName[] = { "Patient DOB", "Patient Certifications Date", "State", "Voicemail", "Diagnosis Code",
				"Text Messaging Consent", "Best Timing Afternoon", "Text" };
		String columnValue[] = { "05-06-2004", "05-17-2024", "Puerto Rico", "True", "J33.0 - Polyp of nasal cavity",
				"TRUE", "TRUE", "TRUE" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(testCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(testCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Nasal Polyps");
			filePath.set(updatepdf.PDFCreation(testCaseNumber, functionality));
			updatepdf.updatePDFForm(testCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));

		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 11:Verify if the 'Account--> Patient' record is visible");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();

		accountObject.clickOnTab(tabsName.get(1));
		accountObject.authorizationFormConsents(ExcelTestData.get(patientName),
				careProgramProduct.get(0).split(" - ")[0], ExcelTestData.get(patientCertificationsDate),
				patientcertSigned.get(0), ExcelTestData.get(patientAuthorizationDate), authorizationSigned.get(0),
				ExcelTestData.get(prescriberSignatureDate), prescriberSignature.get(0),
				ExcelTestData.get(textMessagingConsent));

		Logger("STEP 12:Verify HCP Authorization");
		accountObject.verifyHCPAuthorization(ExcelTestData.get(patientName));

		Logger("STEP 13:Verify Written/Mail Consent Authorization");
		accountObject.navigateToAccountRecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyWrittenMailAuthorization(ExcelTestData.get(patientName), ExcelTestData.get(state),
				ExcelTestData.get(patientDOB), ExcelTestData.get(patientCertificationsDate));

		Logger("STEP 14:Verify Email Communication Consent Authorization");
		accountObject.navigateToAccountRecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyEmailAuthorization(ExcelTestData.get(patientName), ExcelTestData.get(state),
				ExcelTestData.get(patientDOB), ExcelTestData.get(patientCertificationsDate));

		Logger("STEP 15:Verify General Marketing Consent Authorization");
		accountObject.navigateToAccountRecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyGeneralAuthorization(ExcelTestData.get(patientName), ExcelTestData.get(state),
				ExcelTestData.get(patientDOB), ExcelTestData.get(patientCertificationsDate));

		Logger("STEP 16:Verify Text Messaging Consent Authorization");
		accountObject.navigateToAccountRecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyTextMessagingAuthorization(ExcelTestData.get(patientName), ExcelTestData.get(state),
				ExcelTestData.get(patientDOB), ExcelTestData.get(patientCertificationsDate));

		Logger("STEP 17:Verify Telephone Communication Consent Authorization");
		accountObject.navigateToAccountRecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyTelephoneAuthorization(ExcelTestData.get(patientName), ExcelTestData.get(state),
				ExcelTestData.get(patientDOB), ExcelTestData.get(patientCertificationsDate));

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-350 Validate the Authorization Consent Page Layout - Text
	 * Messaging Consents
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Validate the Authorization Consent Page Layout - Text Messaging Consents", enabled = true)
	public void CM13_IC350_Validate_the_Authorization_Consent_Page_Layout_Text_Messaging_Consents() throws Exception {

		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC8";

		String columnName[] = { "Text Messaging Consent" };
		String columnValue[] = { "TRUE" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_ConsentPref);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 5:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];
		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.clearTextFromDateField();
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify if the 'Account--> Patient' record is visible");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 17:Navigate to Authorization Form Consent object and check for records as:Text Messaging consent");
		accountObject.clickOnTextMessagingConsentRecord(ExcelTestData.get(patientName));

		Logger("STEP 18:Validate that the layout of Authorization Form Consent detail page,For Consent Expiration Date calculation, validate that the logic are satisfied:");
		String consentExpiryDate = accountObject.getCalculatedConsentExpiryDate(ExcelTestData.get(state),
				ExcelTestData.get(patientDOB), ExcelTestData.get(patientCertificationsDate));
		accountObject.validateCompactLayoutConsentFieldsData(ExcelTestData.get(patientName), consentNames.get(5),
				ExcelTestData.get(legalRepresentativeName), consentExpiryDate);
		accountObject.validateInfoSecConsentFieldsData(ExcelTestData.get(patientName), consentNames.get(5),
				consentExpiryDate, ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(legalRepresentativeName), careProgramProduct.get(2));
		accountObject.validateSystemInformationFields();

		Logger("STEP 19: Validate that for Contact Consents, if the patient DOB and/or Address is missing in enrollment form then the Consent Expiration Date is populated with the minimum expiration duration (180 days + Consent Captured Date)");
		// Email Communication Consent
		accountObject.clickOnConsentAccountRecord();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.clickOnConsentRecord(ExcelTestData.get(patientName), consentNames.get(2));
		accountObject.validateConsentExpiryDate(consentExpiryDate);

		// Telephone Communication Consent
		accountObject.clickOnConsentAccountRecord();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.clickOnConsentRecord(ExcelTestData.get(patientName), consentNames.get(3));
		accountObject.validateConsentExpiryDate(consentExpiryDate);

		// Written/Mail Communication Consent
		accountObject.clickOnConsentAccountRecord();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.clickOnConsentRecord(ExcelTestData.get(patientName), consentNames.get(4));
		accountObject.validateConsentExpiryDate(consentExpiryDate);

		Logger("STEP 20: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-6635 Validate the Display Expiring Consent Cases on Case
	 * Manager Home Page
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "SAT - TC01: Validate the Display Expiring Consent Cases on Case Manager Home Page", enabled = true)
	public void CM14_IC6635_Validate_the_Display_Expiring_Consent_Cases_on_Case_Manager_Home_Page() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC14";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "K20.0 - Eosinophilic esophagitis", "TRUE", "FALSE" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(4).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("EOE");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 12:Verify if the 'Account--> Patient' record is visible");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(PCUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		// homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();

		Logger("STEP 17: Navigate to Care Program Enrollee Object >> open the newly Created CPE Record >> Navigate to Related Tab >> In the Related Tab Assign the CPE Team Member");
		careProgram.clickOnCPERecord(cpeName);
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateClickToCPETeamMemberTable();
		iapPage.verifyClickNewButton();
		authorizationConsentPage.addCPETeamMember();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		String[] cpeDetails2 = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 20:Upload document to Dupixent portal");
		String documentID2 = uploadDocs.uploadDoc(filePath.get(), cpeDetails2);

		Logger("STEP 21: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 22:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID2, status.get(1));

		Logger("STEP 23:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 24:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 25: User selects valid ‘Care Program Product' field data ");
		patientSearch.verifyPatientSearchPageTitle();
		Logger("STEP 26:On the Patient search page, Validate the required fields in '*Patient Information & Authorizations*' section are populated as per the details given in the uploaded PDF form in Step5, enter required field data and click on 'Next' button.");
		String[] name2 = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFName = name2[0];
		String patientLName = name2[2];

		patientSearch.enterPatientSearchFields(documentType.get(0), patientFName, patientLName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		patientSearch.verifyPatientSearchButton();
		patientSearch.verifyAndClickExisitngPatient();
		patientSearch.clickOnNextButton();
		refresh();
		patientSearch.verifyDocumentLinkedText();

		Logger("STEP 27: User Logout the Application.");
		documentsPage.logout();

	}

	@Test(description = "TC05-Creation of new 'Received Documents' record with 'DMW-EoE-Enrollment-Form-English'", enabled = true, priority = 6)
	public void CM15_IC1155_creationOfNewReceivedDocumentsRecord_EnrollmentForm_EoE() throws Exception {

		Logger("Pre-Requisite : Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC6";

		String columnName[] = { "Text Messaging Consent", "Diagnosis Code" };
		String columnValue[] = { "Yes", "K20.0 - Eosinophilic esophagitis" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_TestCase05);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("EOE");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);
		fileName = documentsPage.getFileName(filePath.get());
		// String accountName=ExcelTestData.get(patientName);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.2: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 2.3:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 2.5:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.1:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 4: User selects valid ‘Care Program Product' field data and click on Next Button,Navigate to Patient Search' tab and validate when '*Care Program Product*' field data is not selected and user click on next button,error message will pops up.");
		patientSearch.verifyPatientSearchPageTitle();
		patientSearch.verifyCareProgProductError();

		Logger("STEP 5:On the Patient search page, Validate the required fields in '*Patient Information & Authorizations*' section are populated as per the details given in the uploaded PDF form in Step5, enter required field data and click on 'Next' button.");
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		Logger("STEP 6: On the Patient Enrollment' page, Validate the required fields in '*Patient Information & Authorizations*' section are populated as per the details given in the uploaded PDF form in Step5, enter required field data and click on 'Next' button.");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		Logger("STEP 7: In '*Insurance Information*' section, click on '*Save for Later.*,Verify that user is able to view below mentioned message as Your OmniScript is saved for later and user can use the link to resume the form filling afterwards also.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.VerifySaveLater();
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName), quickStartRx.get(2));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 8:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String preFirstName = null;
		String prLastName = null;
		if (!(ExcelTestData.get(prescriberName) == null)) {
			String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
			preFirstName = preName[0];
			prLastName = preName[2];
		}

		String ofcFirstName = null;
		String ofcLastName = null;
		if (!(ExcelTestData.get(officeContactName) == null)) {
			String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
			ofcFirstName = ofcName[0];
			ofcLastName = ofcName[2];
		}

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 9:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnPreviousButton();
		prescriberInformationPage.clickOnNextButton();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 10:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String mdFirstName = null;
		String mdLastName = null;
		if (!(ExcelTestData.get(collaboratingMDName) == null)) {

			String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
			mdFirstName = mdName[0];
			mdLastName = mdName[2];
		}
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(1), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 11:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 12:Verify if the 'Account--> Patient' record is visible");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.NavigateToAccObject(ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(gender), ExcelTestData.get(patientSecondaryphone), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientAddress), patientHasInsurance.get(0), ExcelTestData.get(language),
				ExcelTestData.get(city), ExcelTestData.get(state), ExcelTestData.get(zip));

		Logger("STEP 13: Search for the '*Health Conditions*' record(s) is created for the completed and submitted 'Enrollment Form'");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
		accountObject.verifyHealthCondition(ExcelTestData.get(diagnosisCode));
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 14: Verify HIPPAAuthorization Consent record.");
		accountObject.navigateToAuthFormConsentTable();
		accountObject.verifyHIPAAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientAuthorizationDate));

		Logger("STEP 15:Verify PPA Consent Authorization");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToAuthFormConsentTable();
		accountObject.verifyPPAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientCertificationsDate));

		Logger("STEP 16: User Logout the Application.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-3981 Create Consent Record for Text Message Consent
	 * Captured during Copay
	 * 
	 * @author Shanavaz Nishani, Date - 11/7/2024
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "ICARE-3981 Create Consent Record for Text Message Consent Captured during Copay", enabled = true)
	public void CM16_IC3981_Create_Consent_Record_for_Text_Message_Consent_Captured_during_Copay() throws Exception {

		String TestCaseNumber = "TC3";

		// Prerequisites
		String ID = PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		// BV task
		Logger("Pre requsite STEP 1:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger(" Pre requsite STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre requsite STEP 3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre requsite STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		Logger("Pre requsite STEP 5: Verify BV Task is initiated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre requsite STEP 6: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre requsite STEP 7: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(0), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("Pre requsite STEP 10: User Logout the Application.");
		documentsPage.logout();

		// case manager
		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2:  Navigate to Copay Work Order");
		navigateToUrl(url);
		Thread.sleep(4000);

		// Copay work order
		Logger("STEP 3: Validate Copay Work Order is initiated");
		copayFlow.checkCopayIntiation();
		careProgram.clickOnWorkOrderTask(workOrderName.get(3));
		careProgram.clickOnMainTask(copayMainTaskNames.get(0));

		Logger("Step 4 :Validate Elgibility Task present under My Tasks on right-hand side of the screen");
		careProgram.verifySubTaskInitiaited(copaySubTaskNames.get(0));
		careProgram.clickOnSubTask(copaySubTaskNames.get(0));

		Logger("STEP 5: Click on Copay Task → Omniscript form opens → Validate that the following Additional Consent Questions are able to be viewed/edited → Fill Text opt in ? Field as Yes → Click on Submit ButtonConsent Section Text opt in? Yes");
		String outcomeDate = Utility_Function.getNthDayFromToday(10);
		boolean outcomeScreen = copayFlow.verifyReviewOutcomeScreen();
		if (outcomeScreen) {
			copayFlow.enterOutcomeDetails(copayOutcome.get(1), outcomeDate);
			copayFlow.clickOnReAssessButton();
		}
		copayFlow.enterEligibilityCriteria();
		quickStartPage.clickOnSubmitButton();
		copayFlow.enterOutcomeDetails(copayOutcome.get(0), outcomeDate);
		copayFlow.clickOnFinishButton();

		Logger("STEP 6: Open the recently created Text Messaging Consent Record from Authorization Form Consent object.");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("Step 7 : Validate Consent fields to be pre-filled on the Text Messaging Consent Record:");
		accountObject.clickOnTextMessagingConsentRecord(ExcelTestData.get(patientName));
		accountObject.verifyConsentExpirationForTextMessaging(ExcelTestData.get(patientName), ExcelTestData.get(state),
				ExcelTestData.get(patientDOB), ExcelTestData.get(patientCertificationsDate));
		authorizationConsentPage.verifyTextMessagingConsentPageData(ExcelTestData.get(patientName),careProgramProduct.get(2).split(" -")[0]);

		Logger("STEP 8: User Logout the Application.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-13494 Regression-Consent/Pref Mgmnt: Automate creation of
	 * a new Authorization Form Consent record when Copay Card Program Consent is
	 * obtained
	 * 
	 * @author Sonica P
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "ICARE-13494 Regression-Consent/Pref Mgmnt: Automate creation of a new Authorization Form Consent record when Copay Card Program Consent is obtained", enabled = true)
	public void CM17_IC4099_iCare2386_SAT_TC01_To_validate_creation_of_a_new_Authorization_Form_Consent_record_when_Copay_Card_Program_Consent_is_obtained()
			throws Exception {

		String TestCaseNumber = "TC10";

		// Prerequisites
		String ID = PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		// BV task
		Logger("Pre requsite STEP 1:Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger(" Pre requsite STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre requsite STEP 3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre requsite STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		Logger("Pre requsite STEP 5: Verify BV Task is initiated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre requsite STEP 6: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre requsite STEP 7: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(0), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		// CPE URL
		String url = getCurrentPageURL();

		Logger("Pre requsite STEP 10: User Logout the Application.");
		documentsPage.logout();

		// case manager
		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2:  Navigate to Copay Work Order");
		navigateToUrl(url);
		Thread.sleep(4000);
//
//		// Copay work order
//		Logger("STEP 3: Validate Copay Work Order is initiated");
//		copayFlow.checkCopayIntiation();
//		careProgram.clickOnWorkOrderTask(workOrderName.get(3));
//		careProgram.clickOnMainTask(copayMainTaskNames.get(0));

		Logger("Step 3: Initiate Copay with start new service");
		iapPage.clickOnStartNewService();
		copayFlow.selectService("Copay");
		missingInformatioPage.clickNextButton();
		copayFlow.selectReason("Migrated Patient");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("Step 4 :Validate Elgibility Task present under My Tasks on right-hand side of the screen");
		// careProgram.verifySubTaskInitiaited(copaySubTaskNames.get(0));
		copayFlow.checkCopayIntiation();
		careProgram.clickOnWorkOrderTask(workOrderName.get(3));
		careProgram.clickOnMainTask(copayMainTaskNames.get(0));
		careProgram.clickOnSubTask(copaySubTaskNames.get(0));

		Logger("STEP 5: Click on Copay Task → Omniscript form opens → Validate that the following Additional Consent Questions are able to be viewed/edited → Fill Text opt in ? Field as Yes → Click on Submit ButtonConsent Section Text opt in? Yes");
		quickStartPage.clickOnSubmitButton();
//		String outcomeDate = Utility_Function.getNthDayFromToday(10);
//		boolean outcomeScreen = copayFlow.verifyReviewOutcomeScreen();
//		if (outcomeScreen) {
//			copayFlow.enterOutcomeDetails(copayOutcome.get(0), outcomeDate);
//			copayFlow.clickOnReAssessButton();
//		}
//		copayFlow.validateConsentCopayField();
//		copayFlow.enterEligibilityCriteria();
//		quickStartPage.clickOnSubmitButton();
//		copayFlow.validateRequestOutcomeFields();
//		copayFlow.enterOutcomeDetails(copayOutcome.get(0), outcomeDate);
		copayFlow.clickOnFinishButton();
		refresh();

		Logger("STEP 6: Open the recently created Copay Consent Record from Authorization Form Consent object.");
		// missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("Step 7 : Validate Consent fields to be pre-filled on the Text Messaging Consent Record:");
		accountObject.clickOnCopayConsentRecord(ExcelTestData.get(patientName));
		authorizationConsentPage.verifyCopayConsentPageData(ExcelTestData.get(patientName),
				careProgramProduct.get(2).split(" -")[0]);

		Logger("STEP 8: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-19687 Validate Consent Status updates when New Consents
	 * records are created 27025
	 * 
	 * @author Tejal
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Validate Consent Status updates when New Consents records are created", enabled = true)
	public void CPM26_IC19687_Validate_Consent_Status_updates_when_New_Consents_records_are_created() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC2";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Specialty Pharmacy Name",
				"Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "Automation Correspondence SP", "L20.9 - Atopic dermatitis",
				"TRUE", "TRUE" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-Requisite 2: User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));


		Logger("STEP 5:Navigate to details Tab and validate that the Parent Received Document field and Document Type are NULL");
//		accountObject.clickOnTab(tabsName.get(0));
//		documentsPage.verifyParentDocumentType();

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document,verify OCR status as 'Success'");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		Logger("STEP 8:Validate User can search for Existing patient >> Select patient from search list >> Click on Next, Refresh and validate document Link message");
		patientSearch.selectExistingPatient(careProgramProduct.get(4));
		Thread.sleep(2000);

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();


		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();


		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		Thread.sleep(2000);
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();


		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		Logger("STEP 12: Verify HIPPAAuthorization Consent record.");
		accountObject.navigateToAuthFormConsentTable();

		accountObject.verifyProgramStatus(carePrograms.get(3), "Active");
		accountObject.verifyProgramStatus(carePrograms.get(0), "Expired");// CHANGE
		accountObject.clickPageOfAFC("2");
		accountObject.verifyProgramStatus(carePrograms.get(0), "Expired");
		accountObject.clickPageOfAFC("1");

		authorizationConsentPage.createAuthorizationConsent();

		authorizationConsentPage.saveAuthorizationFormConsentRecord();
		Thread.sleep(5000);

		Logger("STEP 20: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-27030 R4.6-CAP Automate iCare11932:SIT:TC01: Validate That
	 * Consent Renewal Job Does Not Run for Inactive, Deceased, or Duplicate
	 * Patients
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SIT:TC01: Validate That Consent Renewal Job Does Not Run for Inactive, Deceased, or Duplicate Patients", enabled = true)
	public void CM18_IC2119_Validate_that_ConsentRenewal_Job_Does_Not_Run_for_Inactive_Deceased_or_Duplicate_Patients()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC8";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		// Pre-requisite
		Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		/*Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("Pre-Requisite STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("Pre-Requisite STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("Pre-Requisite STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Pre-Requisite STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-Requisite STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		Logger("Pre-Requisite STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		System.out.println(ExcelTestData.get(pharmacyfax));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();*/

		Logger("Pre-Requisite STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		String accountURL = getCurrentPageURL();

		Logger("Pre-Requisite STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		//accountObject.verifyAndClickOnCPERecord(cpeName);
		accountObject.cickOnCPERecord(cpeName);
		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		Logger("Pre-Requisite STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 1:Log in to Org using BO User");
		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);

		Logger("STEP 2 : Navigate to the Account object and open a Patient Account where Patient Status = Inactive");
		navigateToUrl(accountURL);
		accountObject.clickOnAccountStatusUpdate();
		accountObject.selectStatus(patientAccountStatus.get(0));
		accountObject.clickOnNext();
		accountObject.confirmAccountStatusUpdate(listOptions.get(0));
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 3: Click on the Related tab → Go to the AFC list → Open the  HIPAA Consent record.");
		navigateToUrl(accountURL);
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.openHIPAAConsent();

		Logger("STEP 4: Update the Consent Expiration Date field with a date that is less than 90 days from today, then click Save.");
		docMgmt.clcikOnEditbtn("Consent Expiration Date Time");
		accountObject.enterConsentExpDate(80);
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 5: Go to the CPE record for the patient → Click on the Related tab → Navigate to the Cases list → Validate that no Consent Renewal Case is created for the HIPAA Consent.");
		navigateToURL(cpeURL);
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCasesTable();
		careProgram.clickOnCasesTable();
		docMgmt.verifyConsentRenewalCaseNotCreated();
		documentsPage.logout();

		Logger("STEP 6: Navigate to the Patient Account and open a Deceased patient account → Repeat Steps 3 to 5 for the Deceased patient → Validate that Consent Renewal Cases are not created.");
		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
		navigateToURL(accountURL);
		accountObject.clickOnAccountStatusUpdate();
		accountObject.selectStatus(patientAccountStatus.get(1));
		accountObject.clickOnNext();
		accountObject.confirmAccountStatusUpdate(listOptions.get(0));
		refresh();
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		navigateToUrl(accountURL);
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.openHIPAAConsent();
		docMgmt.clcikOnEditbtn("Consent Expiration Date Time");
		accountObject.enterConsentExpDate(85);
		missingInformatioPage.clickOnSaveButton();
		navigateToURL(cpeURL);
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCasesTable();
		careProgram.clickOnCasesTable();
		docMgmt.verifyConsentRenewalCaseNotCreated();
		documentsPage.logout();

		Logger("STEP 7: Navigate to the Patient Account and open a Duplicate patient account → Repeat Steps 3 to 5 for the Duplicate patient → Validate that Consent Renewal Cases are not created.");
		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
		navigateToURL(accountURL);
		accountObject.clickOnAccountStatusUpdate();
		accountObject.selectStatus(patientAccountStatus.get(2));
		accountObject.selectWinnerPatient();
		accountObject.confirmAccountStatusUpdate(listOptions.get(0));
		refresh();
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		navigateToUrl(accountURL);
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.openHIPAAConsent();
		docMgmt.clcikOnEditbtn("Consent Expiration Date Time");
		accountObject.enterConsentExpDate(70);
		missingInformatioPage.clickOnSaveButton();
		navigateToURL(cpeURL);
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCasesTable();
		careProgram.clickOnCasesTable();
		docMgmt.verifyConsentRenewalCaseNotCreated();

		Logger("STEP 8: Logout of the application");
		documentsPage.logout();

	}
	
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-26795 - Validate that “Plan Type” field visible on the PAP WO should be stamped on the PAP CPEP 
	 * page layout with the same value as in BV WO, when a PAP WO is completed, and a PAP CPEP is created
	 *
	 * @author Anand Pawar
	 *
	 * @throws Exception ===================================================================================================
	 */
 
	@Test(description = "Validate that “Plan Type” field visible on the PAP WO should be stamped on the PAP CPEP page layout with the same value as in BV WO, when a PAP WO is completed, and a PAP CPEP is created", enabled = true)
	public void CM21_ICARE_26795_Validate_that_Plan_Type_field_visible_on_the_PAP_WO_should_be_stamped_on_the_PAP_CPEP_page_layout_with_the_same_value_as_in_BV_WO_when_PAP_WO_completed_and_PAP_CPEP_is_created()
			throws Exception {
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC10";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code","Text Messaging Consent" , "DUPIXENT MyWay",
				"Preferred Specialty Pharmacy"};
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified","TRUE","TRUE", "FAL" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 15:Navigate to Account object");
		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 16: User Logout the Application.");
		documentsPage.logout();
		
		
		Logger("STEP 17:Login to the QA_SIT Org as CM User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		navigateToUrl(url);
		Thread.sleep(4000);
		
		Logger("STEP 18: Complete BV Task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(0), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		//bvPage.clickOutreachAttemptChebox();
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		refresh();	
	    missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
		Logger("STEP 19: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 20: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 21: User will see two fields: 1. Start Service : Pick the value as \"PAP\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		papPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(0));

		Logger("STEP 22: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		Logger("STEP 23: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 24: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask("Pre-Check");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));

		Logger("STEP 25: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 26: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		
		Logger("STEP 27: Enter eligibilty Check");
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(0), planType.get(0), "", ""));
		papPage.verifyPatientInfoDetails(expectedValues);
		papPage.enterEligibilityCheckEligibileforLIS("Yes");

		Logger("STEP 28: Click on next Button");
		quickStartPage.clickOnNextButton();

		Logger("STEP 29: Verify that PAP Eligibility Outcome value will be auto populated, greyed out, and non-editable. is populated as Eligible only for the combinations given in the table ->Enter the Outcome Value as Approved and Click on Next");
		papPage.validateEligibiltyIsDisable(false);
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 30: In the Order Details page, Select the Order details and Selected Documents and Click on Submit.");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));	
		refresh();
		
		Logger("STEP 31: Verify PAP CPEP Record created");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		iapPage.navigateToCPEPRecord("PAP");		
		
		Logger("STEP 32: Validate Plan Type field value on PAP CPEP record page is as same as the value in PAP WO");
		quickStartPage.clickOnEditButton();
		papPage.validatePlantype(planType.get(0));
		quickStartPage.clickOnCancelButton();
			
		Logger("STEP 33: Logout of the application");
		documentsPage.logout();
		
		
	}
	
	
	
  
  	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-22315 Verify the User is able to Withdraw Consent from Quick Action on CPE record Page
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "SAT - TC01: Verify the User is able to Withdraw Consent from Quick Action on CPE record Page", enabled = true)
	public void CM16_IC22315_Verify_the_User_is_able_to_Withdraw_Consent_from_Quick_Action_on_CPE_record_Page() throws Exception {
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC1";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code","Text Messaging Consent" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified","TRUE" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 15:Navigate to Account object");
		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 16: User Logout the Application.");
		documentsPage.logout();

		// case manager
		Logger("STEP 17: Login to Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 18:  Navigate to CPE URL");
		navigateToUrl(url);
		Thread.sleep(4000);
		
		Logger("STEP 19:Click on the Dropdown on the CPE page header(Quick Actions) > Click on the Quick Actions>>Verify Action Screen is displayed with the Radio Buttons Create and Withdraw");
		careProgram.clickQuickActionsButton();
		careProgram.verifyButtonByTitle("Consent Updates");

		Logger("STEP 20: Click on Consent Updates >>Verify the Action Screen is displayed>> Verify the Radio buttons: Create and Withdraw are displayed");
		careProgram.clickActionByName("Consent Updates");
		careProgram.verifyActionScreenDisplayed();
		careProgram.verifyRadioButtonsDisplayed("Create", "Withdraw");
	
		
		Logger("STEP 21: Select the Withdraw Radio button>>Click on Next>>Verify Withdraw Consent Screen is displayed>>Verify the Sub header displays the message \"Select at least one consent record to proceed further\"");
		careProgram.clickRadioButtonByLabel("Withdraw");
		missingInformatioPage.clickNextButton();	
		authorizationConsentPage.verifyConsentWithdrawHeaderAndSubheader();
		
		
		Logger("STEP 22: Verify the Table is displayed with Columns: Select, Consent Type, Consent Capture Date, Expiration Date");
		authorizationConsentPage.compareTableColumnNames();
		
		
		Logger("STEP 23: Verify All Active Consents for the CPE linked to Patient record based on the Care Program Are displayed");
		authorizationConsentPage.verifyAllConsentsPresent();
		
		Logger("STEP 24: Verify a Mandatory Field : Consent Withdrawn Date is displayed >> Select a Date from the Calendar >> Do not select any Consent>>Click on Submit>>Verify the Message \\\"Select at least one consent record to proceed further.\\\" is displayed in the Confirmation Screen");
		String date = Utility_Function.getNthDayFromToday(1);
		authorizationConsentPage.enterConsentWithdrawlDate(date);
		quickStartPage.clickOnSubmitButton();
		authorizationConsentPage.verifyConsentConfirmationErrorMessage();
		
		Logger("STEP 25: Navigate Back to Withdraw Consent Screen>>Select a Consent Record>>Select the Consent Withdrawn Date>>Click on Submit");
		careProgram.clickRadioButtonByLabel("Withdraw");
		missingInformatioPage.clickNextButton();	
		String textConsent=authorizationConsentPage.selectConsenCheckbox();
		authorizationConsentPage.enterConsentWithdrawlDate(date);
		quickStartPage.clickOnSubmitButton();
		authorizationConsentPage.verifyConsentConfirmationMessage();
		
		Logger("STEP 26:Navigate Back to CPE record>>Select the Patient Account >>Navigate to Related List>>Verify the corresponding Consent is displayed in Withdrawn Status");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.navigateToAccountRecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToAuthFormConsentTable();
		accountObject.validateConsentStatusWithdrawn(textConsent);
		
		Logger("STEP 27:Select the Consent in Withdrawn Status>>Verify the Consent Expiration Date Time Field is Auto populated");
		accountObject.validateConsentExpirationDateTime();

		Logger("STEP 28: User Logout the Application.");
		documentsPage.logout();

		
	}
	
  
  
  
  
  
  
  
  
  

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-27041  Verify User is able to create Consent from Quick Action on CPE record page
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = " Verify User is able to create Consent from Quick Action on CPE record page", enabled = true)
	public void CM17_IC27041_Verify_User_is_able_to_create_Consent_from_Quick_Action_on_CPE_record_page() throws Exception {

		Logger("STEP 1:Login to the Org as CM User");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Navigate to the App Launcher, search and open the 'iCare Connec' App. "
				+ "From App Launcher, search and click on the 'Care Program Enrollee' Object.");
		 homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 3: Change List view to 'Recently View' queue list view.");
		docMgmt.verifyRecentlyViewList();

		Logger("STEP 4: Open any newly created Care Program Enrollee (CPE) record.");
		documentsPage.searchDocument("Automation");
		String recordName = missingInformatioPage.searchAndOpenRecord();

		Logger("STEP 5: Verify that only the buttons Start New Service and Correspondence are displayed on the CPE page");
		careProgram.verifyButtonsDisplayedOnCPEPage("Start New Service", "Correspondence");

		Logger("STEP 6: Click on the Dropdown on the CPE page header(Quick Actions) > Verify other buttons are displayed in the Quick Actions");
		careProgram.clickQuickActionsButton();
		careProgram.verifyButtonByTitle("Consent Updates");

		Logger("STEP 7: Click on Consent Updates >>Verify the Action Screen is displayed>> Verify the Radio buttons: Create and Withdraw are displayed");
		careProgram.clickActionByName("Consent Updates");
		careProgram.verifyActionScreenDisplayed();
		careProgram.verifyRadioButtonsDisplayed("Create", "Withdraw");

		Logger("STEP 8: Click on Create and Click on Next>>Verify the Create Consent Screen is displayed");
		careProgram.clickRadioButtonByLabel("Create");
		missingInformatioPage.clickNextButton();
		careProgram.verifyScreenDisplayedByHeading("Create Consent");

		Logger("STEP 9: Verify the below Picklist Fields are displayed:");
		List<String> picklistFields = Arrays.asList("Type of Consent", "Consent Captured Source Type", "Consent Giver");
		careProgram.verifyPicklistFieldsDisplayed(picklistFields);
		List<String> textFields = Arrays.asList("Consent Capture Date");
		careProgram.verifyTextFieldsDisplayed(textFields);

		Logger("STEP 10: Verify the Consent Capture Date Field is a Mandatory Field>> Verify it is auto populated with Todays date");
		String label = "Consent Capture Date";
		paAppealsPage.verifyFieldIsMandatory(label);
		String expectedDate = careProgram.verifyConsentCaptureDateAutoPopulated();

		Logger("STEP 11: Verify Consent Captured Source Type is a Mandatory field with Picklist Values: Written, eSign, verbal");
		label = "Consent Captured Source Type";
		List<String> sourceOptions = Arrays.asList("Written", "eSign", "Verbal");
		paAppealsPage.verifyFieldIsMandatory(label);
		paAppealsPage.verifyDropdownOptionsArePresent(label, sourceOptions);

		Logger("STEP 12: Verify Type of Consent is a mandatory field with following Picklist values: HIPAA Authorization, Patient Program Authorization, HCP Authorization, Text Messaging Consent;");
		label = "Type of Consent";
		List<String> consentOptions = Arrays.asList("HIPAA Authorization", "Patient Program Authorization",
				"HCP Authorization", "Text Messaging Consent");
		paAppealsPage.verifyFieldIsMandatory(label);
		paAppealsPage.verifyDropdownOptionsArePresent(label, consentOptions);

		Logger("STEP 13: In the \"Type of Consent field\": Select one of the following:  HIPAA Authorization/ Patient Program / Text Messaging Consent >> Verify in the Consent Giver field that Patient and Caregiver picklist values are displayed");
		label = "Type of Consent";
		paAppealsPage.selectDropdownValue(label, consentOptions.get(0));
		label = "Consent Giver";
		List<String> consentGiver = Arrays.asList("Patient", "Caregiver");
		careProgram.verifyDropdownOptionsArePresent(label, consentGiver);

		Logger("STEP 14: In the \"Type of Consent field\": Select one of the following:  HCP Authorization>> Verify in the Consent Giver field that only the HCP picklist value is displayed");
		label = "Type of Consent";
		paAppealsPage.selectDropdownValue(label, consentOptions.get(2));
		label = "Consent Giver";
		consentGiver = Arrays.asList("HCP");
		paAppealsPage.verifyDropdownOptionsArePresent(label, consentGiver);

		Logger("STEP 15: Verify that when Type of Consent=HCP Authorization and Consent Giver=HCP is entered, then the Mandatory field: \"Consent Giver Name\" is auto populated with HCP name stamped on the CPE");
		// careProgram.verifyConsentGiverNameAutoPopulated("name");

		Logger("STEP 16:Enter the Values in Consent Captured Source Type, Type of Consent=Patient Program Authorization, Consent Giver=Patient>> Click on Submit>>Verify the message Selected Consent has been Successfully Created is displayed");
		// Patient program authorization
		label = "Type of Consent";
		paAppealsPage.selectDropdownValue(label, consentOptions.get(1));
		label = "Consent Captured Source Type";
		paAppealsPage.selectDropdownValue(label, sourceOptions.get(0));
		label = "Consent Giver";
		consentGiver = Arrays.asList("Patient", "Caregiver");
		careProgram.selectDropdownValue(label, consentGiver.get(0));
		quickStartPage.clickOnSubmitButton();

		// Success message verification
		String msg = docMgmt.validateSuccessMessage();
		if (msg.contains(consentSuccessMSG)) {
			Logger("Success message verified.");
		} else {
			Logger("Success message not found.");
			SoftAssert softassert = new SoftAssert();
			softassert.fail();
			throw new Exception("Success message not found.");
		}
		docMgmt.clickonFinishButton();
		careProgram.verifyActionScreenDisplayed();

		Logger("STEP 17: Navigate to CPE record>>Click the Patient Account on CPE>>Navigate to Patient Related List>>Verify the Patient Program Authorization Consent is created in Active Status");
		missingInformatioPage.navigateToCPERecord(recordName);
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(1));

		String[] parts = recordName.split(" - ");
		String acctName = parts[0].trim();
		String careProgramProduct = parts[1].trim();
		String formattedDate = accountObject.formatDate(expectedDate);
		accountObject.verifyConsentIsCreated(acctName, consentOptions.get(1), formattedDate, "Active",
				careProgramProduct, "Case Manager");

		Logger("STEP 18: Verify the Consent Expiration Date Time is Auto populated with a Future Date");
		accountObject.verifyConsentExpirationDateIsFuture(consentOptions.get(1), formattedDate);

		Logger("STEP 19: Navigate back to CPE record>>Click on Quick Actions>>Consent Updates>> Create a Consent for each of the Consent Type:");
		// HIPPA authorization
		missingInformatioPage.navigateToCPERecord(recordName);
		careProgram.clickQuickActionsButton();
		careProgram.clickActionByName("Consent Updates");
		careProgram.clickRadioButtonByLabel("Create");
		missingInformatioPage.clickNextButton();
		label = "Type of Consent";
		paAppealsPage.selectDropdownValue(label, consentOptions.get(0));
		label = "Consent Captured Source Type";
		paAppealsPage.selectDropdownValue(label, sourceOptions.get(0));
		label = "Consent Giver";
		consentGiver = Arrays.asList("Patient", "Caregiver");
		careProgram.selectDropdownValue(label, consentGiver.get(0));
		quickStartPage.clickOnSubmitButton();

		// Verify consent is created
		missingInformatioPage.navigateToCPERecord(recordName);
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyConsentIsCreated(acctName, consentOptions.get(0), formattedDate, "Active",
				careProgramProduct, "Case Manager");
		
		Logger("STEP 20: Logout of the application");
		documentsPage.logout();
		
	}

}
