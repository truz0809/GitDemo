package com.sanofi.selenium.Regression;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.io.File;

import org.junit.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
//import com.sanofi.selenium.pages.CampaignsPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
//import com.sanofi.selenium.pages.CareTeamAssignment;
import com.sanofi.selenium.pages.CopayFlow;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PAPPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;
import com.sanofi.selenium.pages.FreeGoodsPage;

public class FreeGoods extends BaseTest {

	private static ThreadLocal<String> filePath = new ThreadLocal<>();
	public ReadExcel excel;
	public String fileName;
	String functionality = "Free Goods";

	public static double getRandomNumber(double min, double max) {
		double x = (int) (Math.random() * ((max - min) + 1)) + min;
		return x;
	}

	double randomNum = getRandomNumber(1111, 9999);

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		copayFlow = GetInstance(CopayFlow.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		triagePage = GetInstance(TriagePage.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		// campaigns=GetInstance(CampaignsPage.class);
		papPage = GetInstance(PAPPage.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		documentsPage = GetInstance(DocumentPage.class);
		freeGoods = GetInstance(FreeGoodsPage.class);
		sheetName = "Free_Goods";
		excel = new ReadExcel(sheetName);
	}

	@Test(description = "Pre-Requisite : Generate test data for enrpllment test cases", enabled = true, priority = 1)
	public void FG_ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	@Test(description = "SIT_FreeGoods Workflow Patient Enrollment Prerequisites", enabled = true)
	public String FreeGoods_PatientEnrollment_Prerequisites(String testcaseNumber) throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Diagnosis Code", "DUPIXENT MyWay",
				"Preferred Specialty Pharmacy" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };

		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 17: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		return CPEURL;

	}
	

	@Test(description = "SIT_Prior Authorization Workflow Patient Enrollment Prerequisites", enabled = true, priority = 2)
	public String FreeGoodsWorkflow_PatientEnrollment_Prerequisites_PrurigoNodularis(String testcaseNumber)
			throws Exception {

		String cpeUrl = null;

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L28.1 - Prurigo nodularis", "TRUE", "FALSE" };
		
		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 1.2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate to the Recently view ");
		documentsPage.verifyRecentlyViewDocumentList();

//			Logger("STEP 2.2:Navigate to Received Document Worklist and Check the checkbox on the record and click on 'Assign to me' button.");
//			documentsPage.navigateToReceiveddocument();
//			documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.3:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//	     	Logger("STEP 2.4:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//			documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.2:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(1),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate), textMessaging.get(0));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		cpeUrl = getCurrentPageURL();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		 homeportalPage.closeTabs();
		 documentsPage.navigate(cpeUrl);
	/*	documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);*/

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		return cpeUrl;

	}

	@Test(description = "SIT_Prior Authorization Workflow Patient Enrollment Prerequisites", enabled = true, priority = 2)
	public String FreeGoodsWorkflow_PatientEnrollment_Prerequisites_PrurigoNodularis2(String testcaseNumber)
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L28.1 - Prurigo nodularis", "TRUE", "FALSE" };
		
		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}		
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

			Logger("STEP 1.2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate to the Recently view ");
		documentsPage.verifyRecentlyViewDocumentList();

//			Logger("STEP 2.2:Navigate to Received Document Worklist and Check the checkbox on the record and click on 'Assign to me' button.");
//			documentsPage.navigateToReceiveddocument();
//			documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.3:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//	     	Logger("STEP 2.4:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//			documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.2:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
		
		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(1),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate), textMessaging.get(0));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String cpeUrl = getCurrentPageURL();
		String ID = assessmentTasksPage.navigateAndGetID();
		//String cpeUrl = getCurrentPageURL();
		cpeUrl = Utility_Function.removeQueryString(cpeUrl);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		// homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
		//assessmentTasksPage.verifyRecentlyViewList();
		//careProgram.navigateToAllCPE();
		//careProgram.checkColumnSorting();
		//careProgram.clickOnCPERecord(cpeName);
		navigateToUrl(cpeUrl);	

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		return ID;

	}

	@Test(description = "SIT_Prior Authorization Workflow Patient Enrollment Prerequisites", enabled = true)
	public String FreeGoodsWorkflow_PatientEnrollment_Prerequisites_AtopicDermatitis(String testcaseNumber)
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy", };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };

		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);
		
		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();
//
//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
	
		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		// insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
		// ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax),
		// ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 15:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 16: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String url = getCurrentPageURL();
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 17: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 18: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 19: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		// homeportalPage.closeTabs();
		/*documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 20:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);*/
		
		documentsPage.navigate(url);
		Logger("STEP 21: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 22: User Logout the Application.");
		documentsPage.logout();

		return ID;

	}

	@Test(description = "SIT_Prior Authorization Workflow Patient Enrollment Prerequisites", enabled = true)
	public String FreeGoodsWorkflow_PatientEnrollment_Prerequisites_EOE(String testcaseNumber) throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "K20.0 - Eosinophilic esophagitis", "TRUE", "FALSE" };
		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(4).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("EOE");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);
		
		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 17: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String url = getCurrentPageURL();
		String ID = assessmentTasksPage.navigateAndGetID();
		
		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		// homeportalPage.closeTabs();
		/*documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 20:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);*/
		
		documentsPage.navigate(url);
		Logger("STEP 21: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 22: User Logout the Application.");
		documentsPage.logout();

		return ID;

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-7294- Validate the updated flow of IAP & PAP
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Test Case Id:ICARE-7294-  Validate the updated flow of IAP & PAP", enabled = true)
	public void FG01_ICARE_7294_Validate_the_updated_flow_of_IAP_PAP() throws Exception {

		String TestCaseNumber = "TC1";

		// Prerequisites
		String url = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_PrurigoNodularis(TestCaseNumber);
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = accountName + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		
		Logger("STEP 2: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(url);
		Thread.sleep(4000);
//
//		String urlCPE = "https://icarecrm--test.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0WwO1000000EurxKAC/view";
//		navigateToUrl(urlCPE);
		// IAP
		Logger("STEP 4: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 5: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 6: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		iapPage.selectReason();

		Logger("STEP 7: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 8: Validate that in the right side of the UI there are two tasks:IAP Summary,Extend/Discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();
		iapPage.checkIAPSecondTask();

		Logger("STEP 9: Expand the IAP Summary section and Click on IAP Enrollment Task");
		iapPage.clickOnTask();

		Logger("STEP 10: Enter eligibilty criteria");
		iapPage.verifyTaskIsLoaded(taskTitle.get(0));
		iapPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 11: Validate if User is navigated to the eligibility screen");
		iapPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 12: Enter order details and click submit");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 13: Click on IAP subtask extend/discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPSecondTask();
		iapPage.clickOnTask2();

		Logger("STEP 14: Enter Extend Discontinue Details");
		iapPage.enterExtendDiscontinue();
		missingInformatioPage.clickNextButton();
		iapPage.enterDiscontinuationReason();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// PAP
		Logger("STEP 15: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 16: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 17: User will see two fields: 1. Start Service : Pick the value as \"PAP\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		papPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(0));

		Logger("STEP 19: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 19: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 20: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask("Pre-Check");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 22: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 22: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(1));
		quickStartPage.clickOnSubmitButton();

		Logger("STEP 23: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheck();

		Logger("STEP 23: Click on next Button");
		quickStartPage.clickOnNextButton();

		Logger("STEP 25: Enter outome details");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 26: Enter order details and click on submit");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 27:IAP / PAP WO is in completed status");
		papPage.checkPAPCompletion();
		iapPage.checkIAPCompletion();

		/*Logger("STEP 29: Re-initiate IAP and PAP manually ");
		String[] workOrders = { "IAP", "PAP" };

		Logger("STEP 30: Manually re-initiate the WO: IAP & PAP");
		for (String workorder : workOrders) {
			iapPage.clickOnStartNewService();
			iapPage.verifyServiceTitle();
			copayFlow.selectService(workorder);
			missingInformatioPage.clickNextButton();
			iapPage.checkAttestationcheckboxIfPresent();
			copayFlow.selectReason(serviceReason.get(1));
			missingInformatioPage.clickOnSaveButton();
			refresh();
			Thread.sleep(2000);
		}
		*/
		iapPage.clickOnStartNewService();
		iapPage.verifyServiceTitle();
		copayFlow.selectService("IAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		copayFlow.selectReason(serviceReason.get(1));
		missingInformatioPage.clickOnSaveButton();
		refresh();
		Thread.sleep(2000);
		
		iapPage.clickOnStartNewService();
		iapPage.verifyServiceTitle();
		copayFlow.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		copayFlow.selectReason(serviceReason.get(2));
		missingInformatioPage.clickOnSaveButton();
		refresh();
		Thread.sleep(2000);

		Logger("STEP 31:IAP-Validate the tasks are displayed before the prior assessment tasks making Completed ones at the bottom and InProgress ones On the top");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();
		iapPage.checkIAPSecondTask();

		Logger("STEP 32:PAP-Validate the tasks are displayed before the prior assessment tasks making Completed ones at the bottom and InProgress ones On the top");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 33: User Logout the Application.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-6736 -Validate the Med D PAP AR - PAP / BV Work initiation
	 * after re-enrollment
	 * 
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "SIT_FreeGoods_Validate the QS Discontinuation Process after PA/Appeal Approval", enabled = true)
	public void FG02_IC6736_Validate_the_MedD_PAP_AR_PAP_BV_Work_initiation_after_re_enrollment() throws Exception

	{
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC3";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Diagnosis Code", "DUPIXENT MyWay",
				"Preferred Specialty Pharmacy" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };

		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite 2 : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
/*
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		
		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);
		
		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.selectDocumentType(documentType.get(2));
		documentsPage.submitDocument();
*/documentsPage.navigate("https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/ReceivedDocument/0iobf000000HWbNAAW/view");
		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];
		accountObject.clickOnTab(tabsName.get(0));
		accountObject.verifyDocTypeMedD();

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(2), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 17: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		// homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 20:  Verify recently view list is displayed and search the CPE Record.");
		assessmentTasksPage.verifyRecentlyViewList();
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);

		Logger("STEP 21: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 22: User Logout the Application.");
		documentsPage.logout();
		
		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 1.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 1.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 1.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		
		Logger("Pre-requisites 1.4: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("Pre-requisites 1.5: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre-requisites 1.6: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 1.7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 1.10: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 10: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 11: Navigate to existing CPE Url");
		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 12: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 13: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 14: User will see two fields: 1. Start Service : Pick the value as \"PAP\" 2. Reason: 'Med D Annual Reverification'");
		iapPage.verifyServiceTitle();
		papPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(2));

		Logger("STEP 15: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 16: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 17: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask("Pre-Check");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 18: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 19: Select value 'Med D Financial Hardship' and validate Alternate Research is auto populated as 'No' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();

		Logger("STEP 20: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheck();
		quickStartPage.clickOnNextButton();

		Logger("STEP 21: Enter outome details");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 22: Enter order details and click on submit");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 23: Navigate to PAP CPEP Record and validate outcome as 'Renewed'");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		iapPage.navigateToCPEPRecord("PAP");
		papPage.validatePAPOutcomeStatus();

		Logger("Step 24: Logout from Application");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-10576 - Regression-FreeGoods: Automate SAT-TC03: Flow 2:
	 * Add Campaign Members: To Verify when Program Manager clicks Add Campaign
	 * Members button, a flow is triggered that adds the campaign Members to the
	 * campaign based on the logic
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT-TC03: Flow 2: Add Campaign Members: To Verify when Program Manager clicks Add Campaign Members button, a flow is triggered that adds the campaign Members to the campaign based on the logic", enabled = true)
	public void FG03_IC6616_Verify_when_ProgramManager_clicks_AddCampaignMembers_button_flow_is_triggered_that_adds_the_campaignMembers_to_the_Campaign_based_on_Logic()
			throws Exception {

		Logger("STEP 1: Login to the application as the Business Ops user.");
		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);

		Logger("STEP 2: Connect to Icare Connect App from App launcher and click select the Campaign Object");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(10), DocumentPage.class);

		Logger("Step 2.1: Create a Parent Campaign");
		freeGoods.clickOnNewButton();
		freeGoods.selectNewCampaignChildORParent(newCampaign.get(1));
		String currentYear = String.valueOf(Year.now().getValue());
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		String formattedDate = currentDate.format(formatter);
		String nameOfParentCampaign = "AutomationTesting_" + formattedDate;
		freeGoods.createParentCampaign(nameOfParentCampaign, "testingPurpose", parentCampaignStatus.get(4),
				currentYear);
		missingInformatioPage.clickOnSaveButton();

		Logger("Step 2.2: From Parent Campaign Page Layout click on Child Campaign and create a child Campaign for (Fax,Email,Direct mail,Phone)");
		freeGoods.clickOnChildCampaign();
		freeGoods.createChildCampain(channelType.get(0), masterCorrespondencefields.get(3));

		//not visible details not present in Org
//		Logger("STEP : Create Child Campaign by selecting Master Correspondence set Object as DirectMail");
//		freeGoods.clickOnChildCampaign();
//		freeGoods.createChildCampain(channelType.get(5), masterCorrespondencefields.get(4));

		Logger("STEP : Create Child Campaign by selecting Master Correspondence set Object as Phone");
		freeGoods.clickOnChildCampaign();
		freeGoods.createChildCampain(channelType.get(6), masterCorrespondencefields.get(2));

		//not visible details not present in Org
//		Logger("STEP : Create Child Campaign by selecting Master Correspondence set Object as Email");
//		freeGoods.clickOnChildCampaign();
//		freeGoods.createChildCampain(channelType.get(3), masterCorrespondencefields.get(3));

		Logger("Step 2.3: Navigate to  Child Campaign record.");
		accountObject.clickOnTab(tabsName.get(1));
		freeGoods.validateChildCampaignsCreated();

		Logger("Step 2.4 :click on Add Campaign button and verify the Campaign Members are added to the child Campaign (Fax,Email,Direct mail,Phone).");
		freeGoods.openChildCampaignMember(channelType.get(0));
		freeGoods.verifyaddCampaignMembers();
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		freeGoods.verifyCampaignMembersAdded();
		freeGoods.navigateToCPERecord(nameOfParentCampaign);
     	accountObject.clickOnTab(tabsName.get(1));

//		freeGoods.openChildCampaignMember(channelType.get(5));
//		freeGoods.verifyaddCampaignMembers();
//		refresh();
//		accountObject.clickOnTab(tabsName.get(1));
//		freeGoods.verifyCampaignMembersAdded();
//		freeGoods.navigateToCPERecord(nameOfParentCampaign);
//		accountObject.clickOnTab(tabsName.get(1));

		freeGoods.openChildCampaignMember(channelType.get(6));
		freeGoods.verifyaddCampaignMembers();
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		freeGoods.verifyCampaignMembersAdded();
//		freeGoods.navigateToCPERecord(nameOfParentCampaign);
//		accountObject.clickOnTab(tabsName.get(1));
//
//		freeGoods.openChildCampaignMember(channelType.get(3));
//		freeGoods.verifyaddCampaignMembers();
//		refresh();
//		accountObject.clickOnTab(tabsName.get(1));
//		freeGoods.verifyCampaignMembersAdded();

		Logger("Step 3 : Navigate to Related List on Child Campaign");
		accountObject.clickOnTab(tabsName.get(1));

		Logger("Step 3.1: Verify the Campaign members and Campaign member statuses are displayed");
		freeGoods.validateCampaignMemberandStatusDisplayed();

		Logger("Step 4 : Logout from the application");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-10577 - Regression-FreeGoods: Automate SAT-TC02: Flow 1:
	 * To verify Program Manager is able to create Child Campaign from the Parent
	 * Campaign
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "To verify Program Manager is able to create Child Campaign from  the Parent Campaign", enabled = true)
	public void FG04_ICARE_6614_To_verify_Program_Manager_is_able_to_create_Child_Campaign_from_the_Parent_Campaign()
			throws Exception {

		Logger("Pre-requisites 1::Login to the application as the Business Ops user user'.");
		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);

		Logger("STEP 1: Click on the App Launcher and select the Campaign Object");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(10), DocumentPage.class);

		Logger("STEP 2: Select the Parent Campaign record and verify the button to create Child Campaign is displayed");
		String parentRecord = freeGoods.verifyParentCampaignRecord();
		freeGoods.verifyCreateChildCampaignButton();

		Logger("STEP 3: Click on Child Campaign, Verify the Master Correspondence Look up field is displayed and Enter the value from the look up field and create a child campaign by entering the values in the Mandatory fields");
		freeGoods.clickOnChildCampaign();

		Logger("STEP 4: Create Child Campaign by selecting Master Correspondence set Object as FAX");
		freeGoods.createChildCampain(channelType.get(0), masterCorrespondencefields.get(3));

		// Letter master details not present in Org
//		Logger("STEP 5: Create Child Campaign by selecting Master Correspondence set Object as Letter");
//		freeGoods.clickOnChildCampaign();
//    	freeGoods.createChildCampain(channelType.get(1), masterCorrespondencefields.get(1));

		Logger("STEP 5: Create Child Campaign by selecting Master Correspondence set Object as Phone");
		freeGoods.clickOnChildCampaign();
		freeGoods.createChildCampain(channelType.get(4), masterCorrespondencefields.get(2));

		// master details not present in Org
//		Logger("STEP 6: Create Child Campaign by selecting Master Correspondence set Object as Email");
//		freeGoods.clickOnChildCampaign();
//		freeGoods.createChildCampain(channelType.get(3), masterCorrespondencefields.get(3));

		Logger("STEP 7: Verify Campaign name is auto populated");
		accountObject.clickOnTab(tabsName.get(1));
		freeGoods.verifychildCampaignName(parentRecord);

		Logger("STEP 8: Verify the Campaign Name, Type and therapeutic Area fields are populated in the Child Campaign Page Layout");
		freeGoods.verifyChildCampaignFields();

		Logger("STEP 9: Click on the Start Campaign Button and verify the message");
		freeGoods.verifyInitiateCampaign();
		freeGoods.clickOnFinishBtn();

		Logger("STEP 10: Verify add campaign members and end campaign button");
		freeGoods.verifyaddCampaignMembersAndEndCampaign();

		Logger("STEP 11: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-10559 - Regression-FreeGoods: Automate Fields on Master
	 * Campaign Page Layout and Child Campaign Page Layout Campaign
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "iCare-5239- SAT-TC01: Verify Fields on Master Campaign Page Layout and Child Campaign Page Layout", enabled = true)
	public void FG05_IC6612_To_Verify_Fields_on_Master_Campaign_Page_Layout_and_Child_Campaign_Page_Layout()
			throws Exception {

		Logger("STEP 1: Login to the application as the Business Ops user.");
		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);

		Logger("STEP 2: Click on the App Launcher and select the Campaign Object");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(10), DocumentPage.class);

		Logger("STEP 3: Click on a Master Campaign record > Verify the fields are displayed according to the page layout mentioned.");
		freeGoods.openMasterCampaignRecord();
		freeGoods.validateMasterCampaignPageLayout();

		Logger("STEP 4: Navigate to Campaign Object > Click on New and Select the Parent and click on next > create the Master Campaign Record by entering the fields in the below page layout");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(10), DocumentPage.class);
		freeGoods.clickOnNewButton();
		freeGoods.selectNewCampaignChildORParent(newCampaign.get(1));
		String currentYear = String.valueOf(Year.now().getValue());
		freeGoods.createParentCampaign("Testing", "testingPurpose", parentCampaignStatus.get(4), currentYear);
		missingInformatioPage.clickOnSaveButton();
		freeGoods.validateParentCampaignCreated();

		Logger("STEP 5: Logout from the Application");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-6509 -Validate the QS Discontinuation Process after
	 * PA/Appeal Approval
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "SIT_FreeGoods_Validate the QS Discontinuation Process after PA/Appeal Approval", enabled = true)
	public void FG06_IC6509_Validate_the_QS_Discontinuation_Process_after_PA_Appeal_Approval() throws Exception {

		String TestCaseNumber = "TC31";

		// Prerequisites
		String ID = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_AtopicDermatitis(TestCaseNumber);
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 1.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 1.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 1.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		

		Logger("Pre-requisites 1.4: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("Pre-requisites 1.5: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre-requisites 1.6: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 1.7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

	// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 1.10: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
	
		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 2: Open the QS WO >> Open the \"Enrollment\" Task");
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();
		quickStartPage.clickOnTask();

		Logger("STEP 3: In the Eligibility Assessment Task >>In Eligibility Cretia section select all the Fields as YES >> Click on Next button.");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 4: In the next screen Eligibility Outcome page >> Eligibility Outcome as Eligible >> select Outcome as Approved >> Click on next button.");
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 5: On Order detail Page, select Prescription → Select any attachment and click on Submit button.");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		//missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 6: Click on quick start button and verify task compltion status");
		quickStartPage.clickOnQuickStart();
		quickStartPage.checkQuickStartTaskComplition();
		refresh();

		Logger("STEP 7: After completing the QS WO >> Navigate to PA / Appeal WO");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTaskWO(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 8: In the \"Follow Up on Results\" Task Fill all the Mandatory fields and Status Field as \"Completed\" >> Outcome as \"Approved\" >> Submit the task");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(1), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(0), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(1), PAOutcomeReason.get(0));
		String effectiveDate = Utility_Function.getNthDayFromToday(10);
		String expirationDate = Utility_Function.getNthDayFromToday(15);
		paAppealsPage.enterMandatoryPAApprovedDetails(effectiveDate, paDosage.get(0), expirationDate);
		careProgram.clickOnSave();
        refresh();

		Logger("STEP 11: Open Communication Results and send SOB task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTaskWO(paMainTaskNames.get(1));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));

		Logger("STEP 12: On the \"Communication Results\" task fill all the Mandatory fields >> Validate the value are mapped from Follow up on results Task.");
		paAppealsPage.enterHCPContactDetails1(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName));
		paAppealsPage.validateOutcomeAndOutcomeReason(pAOutcomeOptions.get(1), PAOutcomeReason.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 13: Navigate to Quick start CPE Record");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String quickStartCPE = "QuickStart - " + careProgramProduct.get(2).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(quickStartCPE);

		Logger("STEP 14: Navigate to Quick start CPE Record");
		quickStartPage.editCPEPDetails(quickStartStatus.get(1), reason.get(3));
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 15: Validate the Stamp \"PA/Appeal Approval Date\" added new field on QS CPEP Page Layout.");
		quickStartPage.verifyFieldIsPresent(quickStartLabels.get(0));

		Logger("STEP 16: Logout of the application as BV user.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-18048 RGN-FG: Automate SIT_FreeGoods_PAP- Scenario 7-TC05
	 * -Verify PAP CPEP Fields are added on the PAP CPEP Layout
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SIT_FreeGoods_PAP- Scenario 7-TC05 -Verify PAP CPEP Fields are added on the PAP CPEP Layout", enabled = true)
	public void FG07_IC6415_Verify_PAP_CPEP_Fields_are_added_on_the_PAP_CPEP_Layout() throws Exception {

		String TestCaseNumber = "TC7";

		// Prerequisites
		String ID = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_EOE(TestCaseNumber);
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("STEP 1: Login as BV user and open CPE record and select BV’s \"Review and Finalize Benefit\" task and complete it");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		bvPage.verifytheBVTaskInitiated();
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 3: Logout from BV user and Login to CM user");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 4: Navigate to CPE – PAP record and complete the task Pre-check and Research");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterResearchDetails(alternateCoverage.get(1), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 5: Expand the ‘Confirm PAP Eligibility Task’ and click on the Eligibility Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Confirm PAP Eligibility");
		papPage.clickOnTask("Eligibility");
		careProgram.verifySubTaskInitiaited("Eligibility");

		Logger("STEP 6: Enter all the Mandatory fields in Eligibility Check section as Yes");
		papPage.enterEligibilityCheck("Yes");
		quickStartPage.clickOnNextButton();

		Logger("STEP 7: In the Outcome Page  >> Verify the Picklist Value ‘Approved’ is displayed in the Outcome Field. ");
		papPage.validateOutcomePicklistValue("Approved");

		Logger("STEP 7.1: Select the  ‘Approved’ Picklist Value and Click on Next and give necessary information and save the record.");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 8: Verify the PAP Work Order is Completed");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		papPage.checkPAPCompletion();

		Logger("STEP 9: Click on the Related tab of the CPE record>>Navigate to Care Program Enrollee Product Section and select the Care Program Enrollee Product record.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String papCPE = "PAP - " + careProgramProduct.get(4).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(papCPE);

		Logger("STEP 10: Navigate to Details section >>Verify the Following : 'Outcome' field is displayed with the value from PAP WO as ‘Approved’");
		papPage.validatePAPoutcomeVal("Approved");

		Logger("STEP 10.1: ‘Action Required’ picklist is displayed with the values: 1.Patient to submit re-enrollment form (or be discontinued), 2.Missing Information (patient or provider) , 3.No action required");
		String fieldName = "Action Required";
		docMgmt.clcikOnEditbtn(fieldName);
		for (String val : papActionRequired_picklist) {
			papPage.validatePickListValues(fieldName, val);
		}

		Logger("STEP 10.2: 'Patient has Medicare Part D? ' field is a Look Up field populated with the value from \"Coverage Benefit Selected\" field on BV Work Order and has the Picklist Value Yes/No");
		String fieldName1 = "Patient has Medicare Part D?";
		for (String val : patientMedicarePartD_picklist) {
			papPage.validatePickListValues(fieldName1, val);
		}

		Logger("STEP 11: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-6351 -Validate the Correspondence for Non-Medicare Part D
	 * Patients PAP Renewal
	 * 
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "SIT_FreeGoods_Validate the QS Discontinuation Process after PA/Appeal Approval", enabled = true)
	public void FG08_IC6351_Validate_the_Correspondence_for_Non_Medicare_PartD_Patients_PAP_Renewal() throws Exception

	{

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 1.2: Navigate to the Care program Enrollees object");
		homeportalPage.closeTabs();
		missingInformatioPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7),
				MissingInformatioPage.class);
		refresh();

		Logger("STEP 1.3: User should be able to view the Recently View List of care program enrollees.");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 2: Navigate to CPE Object → Open any record from CPE Object");
		documentsPage.searchDocument("Automation");
		String recordName = missingInformatioPage.searchAndOpenRecord();
		String patientName = recordName.split(" -")[0];
		String facilityName = docMgmt.getPatientDetailsFromCPEPage("Facility Name");
		String facilityAddress = docMgmt.getPatientDetailsFromCPEPage("Facility Address");

		Logger("STEP 6: Click on the Correspondence button");
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 7: Select the Process Name as 'Welcome Correspondence' and Select items to Send as 'DMW Checkbox Welcome' and Click on Next");
		docMgmt.selectProcessName(processName.get(5));
		docMgmt.selectItemsToSend(itemsToSend.get(3));
		missingInformatioPage.clickNextButton();

		missingInformatioPage.clickNextButton();

		Logger("STEP 8: Generate Document(s) section should be displayed with the document processing");
		docMgmt.clickSendButtonUntilFinish();

		Logger("STEP 9: Click on Finish button on confirmation page");
		docMgmt.clickonFinishButton();

		Logger("STEP 10: Navigate to Related List of CPE record → Validate correspondence record → Validate Files record");
		missingInformatioPage.navigateToCPERecord(patientName);
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();
		careProgram.clickOnViewAll("Correspondences");
		docMgmt.verifyCorrespondenceRecord(processName.get(5));
		missingInformatioPage.navigateToCPERecord(patientName);
		String winName = getWebDriver().getTitle();

		Logger("STEP 11: Validate PDF Files present in Related List of Correspondence ");
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecord(itemsToSend.get(3));
		String pdfName = itemsToSend.get(3).trim();
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.deleteExistingFile(downloadPath);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);

		docMgmt.validatePDFData(downloadPath, facilityName, 2);
		docMgmt.validatePDFData(downloadPath, facilityAddress, 2);
		docMgmt.deletePDF(downloadPath);
		utilityPage.switchToWindow(winName);

		Logger("Step 12: Logout from Application");
		docMgmt.closeButton();
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5684 -
	 * Validate_Managing_PAP_Denial_Appeals_via_Start_New_Service_Button
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "TestCase Id- ICARE-5684 Validate Managing PAP Denial Appeals via Start New Service Button", enabled = true)
	public void FG09_ICARE_5684_Validate_Managing_PAP_Denial_Appeals_Via_Start_New_Service_Button() throws Exception

	{

		String TestCaseNumber = "TC9";

		// Prerequisites
		String url = FreeGoods_PatientEnrollment_Prerequisites(TestCaseNumber);
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = accountName + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 3: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();
		refresh();

		Logger("STEP 4: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 5: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 6: User will see two fields: 1. Start Service : Pick the value as \"PAP\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		papPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(1));

		Logger("STEP 7: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 8: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 9: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask("Pre-Check");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 10: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 11: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(3));
		papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		navigateToUrl(url);
		Logger("STEP 16: On \"Research\" Sub Task >> Validate Below Mentioned Fields are Filled -Alternate Coverage Identified? and  ");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Alternate Coverage");
		papPage.clickOnTask("Research and Capture Outcome");
		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
		Logger("STEP 12: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheck(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 13: Enter outome details");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(2));
		papPage.enterCoverageOutcomeReason(pAPOutcomeOptions.get(0));
		quickStartPage.clickOnNextButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// re-initiate PAP
		Logger("STEP 14: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 15: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 16: User will see two fields: 1. Start Service : Pick the value as \"PAP\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		papPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(0));

		Logger("STEP 17: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 18: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 19: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask("Pre-Check");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 20: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 21: Select value as Med Part D - Potentially LIS and validate Alternate Research is auto populated as 'No' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(3));
		papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 16: On \"Research\" Sub Task >> Validate Below Mentioned Fields are Filled -Alternate Coverage Identified? and  ");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Alternate Coverage");
		papPage.clickOnTask("Research and Capture Outcome");
		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 22: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheck(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 23: Enter outome details");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(2));
		papPage.enterCoverageOutcomeReason(pAPOutcomeOptions.get(0));
		quickStartPage.clickOnNextButton();

		Logger("STEP 24: User Logout the Application.");
		documentsPage.logout();

	}
	

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5364- Validating the new flow of re-enrollment for IAP
	 * services
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Test Case Id:ICARE-5364- Validating the new flow of re-enrollment for IAP services", enabled = true)
	public void FG10_ICARE_5364_Validating_the_new_flow_of_reenrollment_for_IAP_services() throws Exception {

		String TestCaseNumber = "TC10";

		// Prerequisites
		String url = FreeGoods_PatientEnrollment_Prerequisites(TestCaseNumber);
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = accountName + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 3: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		// IAP
		Logger("STEP 5: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 6: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 7: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		iapPage.selectReason();

		Logger("STEP 8: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 9: Validate that in the right side of the UI there are two tasks:IAP Summary,Extend/Discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();
		iapPage.checkIAPSecondTask();

		Logger("STEP 10: Expand the IAP Summary section and Click on IAP Enrollment Task");
		iapPage.clickOnTask();

		Logger("STEP 11: Enter eligibilty criteria");
		iapPage.verifyTaskIsLoaded(taskTitle.get(0));
		iapPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 12: Validate if User is navigated to the eligibility screen");
		iapPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 13: Enter order details and click submit");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 14: Click on IAP subtask extend/discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPSecondTask();
		iapPage.clickOnTask2();

		Logger("STEP 15: Enter Extend Discontinue Details");
		iapPage.enterExtendDiscontinue();
		missingInformatioPage.clickNextButton();
		iapPage.enterDiscontinuationReason();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 16: Validate the task status is completed");
		iapPage.verifyIAPCompletion();

		Logger("STEP 17: Again, Click on the button \"Start New Services\"");
		iapPage.verifyStartNewServiceButton();
		iapPage.clickOnStartNewService();

		Logger("STEP 18: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");

		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		iapPage.selectReason();

		Logger("STEP 19: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 20: Validate the IAP Services is reinitiated and also Validate that in the right side of the UI there are two tasks:IAP Summary,Extend/Discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();
		iapPage.checkIAPSecondTask();

		Logger("STEP 21: Expand the IAP Summary section and Click on IAP Enrollment Task");
		iapPage.clickOnTask();

		Logger("STEP 22: Enter eligibilty criteria");
		iapPage.verifyTaskIsLoaded(taskTitle.get(0));
		iapPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 23: Validate if User is navigated to the eligibility screen");
		iapPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 24: Enter order details and click submit");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 25: Click on IAP subtask extend/discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPSecondTask();
		iapPage.clickOnTask2();

		Logger("STEP 26: Enter Extend Discontinue Details");
		iapPage.enterExtendDiscontinue();
		missingInformatioPage.clickNextButton();
		iapPage.enterDiscontinuationReason();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 27: Validate the task status is completed");
		iapPage.verifyIAPCompletion();

		Logger("STEP 28: Again, Click on the button \"Start New Services\"");
		iapPage.verifyStartNewServiceButton();
		iapPage.clickOnStartNewService();

		Logger("STEP 29: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		iapPage.selectReason();

		Logger("STEP 30: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 31: Validate the IAP Services is reinitiated and also Validate that in the right side of the UI there are two tasks:IAP Summary,Extend/Discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();
		iapPage.checkIAPSecondTask();

		Logger("STEP 32: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5185 Validating the extension flow of a patient's IAP
	 * eligibility period for PA Delayed
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT - TC01: Validating the extension flow of a patient's IAP eligibility period for PA Delayed", enabled = true)
	public void FG11_IC_5185_Validating_the_extension_flow_of_patient_IAP_eligibility_period_for_PA_Delayed()
			throws Exception {

		String TestCaseNumber = "TC11";

		// Prerequisites
		String url = FreeGoods_PatientEnrollment_Prerequisites(TestCaseNumber);
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = accountName + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Open a CPE record");
		// homeportalPage.closeTabs();
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 3: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		// IAP
		Logger("STEP 4: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 5: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 6: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		iapPage.selectReason();

		Logger("STEP 7: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 8: Validate the IAP Services is reinitiated and also Validate that in the right side of the UI there are two tasks:IAP Summary,Extend/Discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();
		iapPage.checkIAPSecondTask();

		Logger("STEP 9: Expand the IAP Summary section and Click on IAP Enrollment Task");
		iapPage.clickOnTask();

		Logger("STEP 10: Enter eligibilty criteria");
		iapPage.verifyTaskIsLoaded(taskTitle.get(0));
		iapPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 11: Validate if User is navigated to the eligibility screen");
		iapPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 12: Enter order details and click submit");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 14: Click on IAP subtask extend/discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPSecondTask();
		iapPage.clickOnTask2();

		Logger("STEP 15: Enter Extend Discontinue Details");
		iapPage.enterExtendDiscontinueReason(appealNeeded.get(0), appealNeeded.get(1));
		missingInformatioPage.clickNextButton();
		iapPage.enterExtensionReason();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
	
		Logger("STEP 21: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5142 Validate that PAP Enrollment Correspondence can be
	 * sent from CPE
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Validate that PAP Enrollment Correspondence can be sent from CPE", enabled = true)
	public void FG12_IC5142_Validate_that_PAP_Enrollment_Correspondence_can_be_sent_from_CPE() throws Exception {

		String TestCaseNumber = "TC12";

		// Prerequisites
		String CPEURL = FreeGoods_PatientEnrollment_Prerequisites(TestCaseNumber);
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		// BV task
		Logger("STEP 1: Login as a Case Manager.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Open a CPE record which is tagged to a patient that has  primary and secondary record of Member plan, Prescriber & Site information (Patient Account>Member Plan)");
		// Navigate to CPE URL
		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 2.1: Navigate to patient account and make member plans active");
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.verifyPrimaryRecordMemberPlansSection();
		careProgram.clickOnViewAll("Member Plans");
		docMgmt.changeMemberPlanStatusActive(ExcelTestData.get(rxPayerName));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToMemPlans();
		docMgmt.changeMemberPlanStatusActive(ExcelTestData.get(medicalPayerName));
		missingInformatioPage.clickOnSaveButton();

		missingInformatioPage.navigateToCPERecord(cpeName);

		Logger("STEP 3: Click on the correspondence Button present on the Top right corner of CPE Record.");
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 4: Select Items to send Section is displayed with two fields: select the values1. Process Name as PAP. Select Items to send as DMW Summary of Benefits - MD Fax");
		docMgmt.selectProcessName(processName.get(6));
		docMgmt.selectItemsToSend(itemToSend.get(3));
		missingInformatioPage.clickNextButton();

		missingInformatioPage.clickNextButton();

		Logger("STEP 5: Generate Document(s) section should be displayed with the document processing");
		docMgmt.clickSendButtonUntilFinish();

		Logger("STEP 6: Click on Finish button on confirmation page");
		docMgmt.clickonFinishButton();

		Logger("STEP 7: Navigate to Related List of CPE record → Validate correspondence record → Validate Files record");
		missingInformatioPage.navigateToCPERecord(cpeName);
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();
		careProgram.clickOnViewAll("Correspondences");
		docMgmt.verifyCorrespondenceRecord(processName.get(6));
		missingInformatioPage.navigateToCPERecord(cpeName);

		Logger("STEP 8: Validate PDF Files present in Related List of Correspondence ");
		docMgmt.navigateToFiles();
		docMgmt.verifyFilesRecord(itemToSend.get(3));
		String pdfName = itemToSend.get(3).trim();
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.deleteExistingFile(downloadPath);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);

		// Data validation
		String faxNumber = MDfax.get(0);
		String subject = itemToSend.get(3);

		Map<String, Integer> fieldsToValidate = new HashMap<>();
		// Medical
		fieldsToValidate.put("Fax: " + faxNumber, 1);

		fieldsToValidate.put("Subject: " + subject, 1);

		Logger("STEP 9: Validate the \"COVERAGE PROFILE REPORT\" will  show the primary and secondary Insurance {Pharmacy & Medical} details");
		docMgmt.validateMultiplePDFFields(downloadPath, fieldsToValidate);

		Logger("STEP 10: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5141 -Validate the IAP CPEP record is not getting created
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "SIT_FreeGoods_Validate the IAP CPEP record is not getting created", enabled = true)
	public void FG13_IC5141_Negativescenarios_for_IAP_WO_in_terms_of_Patient_Eligibility_for_IAP() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC13";

		// Pre-Requisite
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "DUPIXENT MyWay", "Preferred Specialty Pharmacy","Diagnosis Code" };
		String columnValue[] = { "TRUE", "FALSE" ,"J45.40 - Moderate persistent asthma, uncomplicated"};
		
		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnDataIAP);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Asthma");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 1.2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate to the Recently view ");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 2.2:Navigate to Received Document Worklist and Check the
		// checkbox on the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.3:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 2.4:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.2:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		Thread.sleep(20000);
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(cpeURL);
		Thread.sleep(4000);

		Logger("STEP 16: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		// IAP
		Logger("STEP 17: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 18: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 19: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		iapPage.selectReason();

		Logger("STEP 20: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 21: Validate that in the right side of the UI there are two tasks: IAP summary,Extend/Discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();
		iapPage.checkIAPSecondTask();

		Logger("STEP 22: Expand the IAP Summary section and Click on IAP Enrollment Task");
		iapPage.clickOnTask();

		Logger("STEP 23: Select any Enrollment Reason from Enrollment Reason picklist.");
		iapPage.verifyTaskIsLoaded(taskTitle.get(0));
		iapPage.enterEligibilityCriteria(enrollmentReason.get(0), paApproval.get(1), residential.get(1), hcpUSPR.get(1),
				indication.get(0), inpatient.get(0), therapy.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 24: Eligibility Outcome field [Read-only] to be populated as \"Not Eligible\", update the outcome field as \"Denied\" and Fill the outcome reason");
		iapPage.verifyTaskIsLoaded(taskTitle.get(1));
		iapPage.verifyAndEntereligibilityOutcome(eligibilityOutcome.get(1), iapoutcome.get(1), reason.get(0));
		missingInformatioPage.clickNextButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 25: Validate the IAP CPEP record is not getting created");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		iapPage.verifyCPEPRecordNotCreated("IAP");

		Logger("STEP 26: User Logout the Application.");
		documentsPage.logout();

	}

	@Test(description = "IC15689 Regression-FreeGoods: Automate SIT_Free Goods_IAP_SF_Scenario1-TC01- Initiating IAP WO with Patient Eligiblity for IAP", enabled = true)
	public void FG14_IC5136_SIT_IAP_Initiating_IAP_WO_With_Patient_Eligibilty() throws Exception {

		String TestCaseNumber = "TC14";

		// Prerequisites
		String ID=FreeGoodsWorkflow_PatientEnrollment_Prerequisites_PrurigoNodularis2(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("STEP 1: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		

		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		Utility_Function.switchToWindow(accountName);

		Logger("STEP 5: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("STEP 6: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 7: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 8: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));

		Logger("STEP 9: Save the details");
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 11: Validate On the CPE Record, WO should be on PA/Appeal, Follow Up on benefit Task status should be In-Progress");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEWorkOrder();
		iapPage.checkCPEWorkOrderData(careProgramProduct.get(1), ExcelTestData.get(patientName));

		Logger("STEP 12: Validate user is able to Open the Site Record and give the value as “Hospitals“ on the RCM Account Type Field");
		accountObject.clickOnTab(tabsName.get(0));
		iapPage.navigateToSiteRecord();
		iapPage.updateRCMAccountField();
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 13: Validate user is able to verify From the Health Condition Record, update the Condition code and from the Care program product code sets");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToHealthConditions();
		iapPage.verifyHCCodeRecord(ExcelTestData.get(diagnosisCode));
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		String cpeURL = getCurrentPageURL();

		Logger("STEP 14: Logout from application ");
		documentsPage.logout();

		Logger("STEP 15: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 16: Open CPE record");
		navigateToUrl(cpeURL);
		Thread.sleep(4000);

		Logger("STEP 17: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 18: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 19: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		iapPage.selectReason();

		Logger("STEP 20: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 21: Validate that in the right side of the UI there are two tasks:IAP Summary,Extend/Discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();
		iapPage.checkIAPSecondTask();

		Logger("STEP 22: Expand the IAP Summary section and Click on IAP Enrollment Task");
		iapPage.clickOnTask();

		Logger("STEP 23: Verify Users selects Enrollment Reason as Below Enrollment End Date populates accordingly");
		iapPage.verifyTaskIsLoaded(taskTitle.get(0));
		iapPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 24: Validate if User is navigated to the eligibility screen");
		iapPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 25: On Order Section Select the Prescription which were updated at the time of patient enrollment.");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 26: validate if the Specialty Pharmacy field is auto-populated with the value coming from \"Care Program Specialty Network\" which is \"Theracom\"");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		iapPage.verifySpecialityPharmRecord();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 27: Validate Enrollment end date populating according to logic ");
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		iapPage.navigateToCPEPRecord("IAP");
		iapPage.validateEnrollmenetEndDate();

		Logger("STEP 28: Logout from application ");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5110 - PAP is initiated with BV Outcome = Not Covered
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "SIT_Free Goods_PAP_SF - Scenario 4 - TC02 - PAP is initiated with BV Outcome = Not Covered.", enabled = true)
	public void FG015_ICARE_5110_SIT_Free_Goods_PAP_SF_PAP_is_initiated_with_BV_Outcome_Not_Covered() throws Exception {

		String TestCaseNumber = "TC15";

		// Prerequisites
		String ID = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_PrurigoNodularis2(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = accountName + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 1.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 1.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 1.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(accountName);

		// BV Initialization code starts here
		Logger("Pre-requisites 1.5: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("Pre-requisites 1.6: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 1.7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(1));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 1.8: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 2: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 3: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask("Pre-Check");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 4: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 5: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(1));
		papPage.verifyAlternateResearch(alternateResearch.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();

//		Logger("STEP 6: On \"Research\" Sub Task >> Validate Below Mentioned Fields are Filled -Alternate Coverage Identified? and  ");
//		papPage.clickOnPAPTask();
//		papPage.clickOnMainTask("Alternate Coverage");
//		papPage.clickOnTask("Research");
//		papPage.enterResearchDetails(alternateCoverage.get(1), ExcelTestData.get(rxPayerName),
//				ExcelTestData.get(officePhone));
//		quickStartPage.clickOnSubmitButton();

		Logger("STEP 7: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Confirm PAP Eligibility");
		papPage.clickOnTask("Eligibility");
		papPage.enterEligibilityCheck("Yes");
		quickStartPage.clickOnNextButton();

		Logger("STEP 8: Enter outome details");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 9: Enter Order Details");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecordFrmCorrespondence(cpeName);

		Logger("STEP 10: Navigate to Related list of CPE record and open Care Program Enrollee Products, validate Enrollment end date, should be 365 days from current date ");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		iapPage.navigateToCPEPRecord("PAP");
		papPage.validateEnrollmenetStartEndDate();

		Logger("STEP 11: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5102 PAP is initiated with BV Outcome = Not Covered and
	 * alternate coverage is approved
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "PAP is initiated with BV Outcome = Not Covered and alternate coverage is approved", enabled = true)
	public void FG16_IC5102_PAP_is_Initiated_BV_Outcome_Not_Covered_and_alternate_coverage_is_approved()
			throws Exception {

		String TestCaseNumber = "TC14";

		// Prerequisites
		String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("STEP 1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
	
		navigateToUrl(CPEURL);

		Logger("STEP 5: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("STEP 6: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 7: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 8: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(1), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecordFrmCorrespondence(ExcelTestData.get(patientName));
		refresh();
		// CPE URL

		Logger("STEP 11: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 12: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 14: Validate PAP WO is initiated Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();
		papPage.clickOnTask(papSubTaskNames.get(0));


		Logger("STEP 17: Click on Alternate Coverage Task → Click on Pre-Check → Select picklist value Patient Uninsured or Patient Underinsured on Coverage Situation Field → Click on Submit Button");
		papPage.enterCoverageSituation(coverageSituation.get(0));
		papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 18:Again, navigate to PAP WO → Click on Alternate Coverage Task → Click on Research → Select picklist value Yes on Alternate Coverage Identified? Field");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(0));	
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 19: Open \"Communicate Results\" Sub Task and enter contact made and attempt made details");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(2));
		papPage.enterDetails(paStatus.get(1), payerContact.get(0), attempts.get(0), attempt.get(0),
				attemptOutcomes.get(1), attempt.get(1), attemptOutcomes.get(1), attempt.get(2), attemptOutcomes.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		refresh();

		Logger("STEP 20: Open Capture Coverage Outcome sub task and Validate the Below Mentioned Fields: Outcome is picklist (Approved, Denied) Select outcome value as Denied");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(3));
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(2));
		quickStartPage.clickOnSubmitButton();

		// missing steps added
		Logger("STEP 21: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Confirm PAP Eligibility");
		papPage.clickOnTask("Eligibility");
		papPage.enterEligibilityCheck("Yes");
		quickStartPage.clickOnNextButton();

		Logger("STEP 22: Enter outome details");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 23: Enter Order Details");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 24: Now click on the related tab and validate that the PAP Enrollment record is visible on the related list of CPE → Click on the record.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		papPage.clickOnPAPCpe();

		Logger("STEP 23: Verify the \"Enrollment Start Date\" field should be auto-populated with the current date, and the \"Enrollment End Date\" should be auto-populated based on the logic below:");
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate);

		Logger("STEP 24: User Logouts the Application.");
		documentsPage.logout();

	}

	@Test(description = "SIT_Free Goods_PAP_SF - Scenario 4 - TC02 - PAP is initiated with BV Outcome = Not Covered.", enabled = true)
	public void FG17_ICARE_5064_PAP_is_initiated_manually_with_alternate_research_required_no_eligibility_outcome_is_non_eligible()
			throws Exception {

		String TestCaseNumber = "TC4";

		// Prerequisites

		String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 1.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		
		navigateToUrl(CPEURL);
		// Utility_Function.switchToWindow(accountName);

		// BV Initialization code starts here
		Logger("Pre-requisites 1.5: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("Pre-requisites 1.6: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 1.7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(1), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		// CPE URL

		Logger("STEP 1.10: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 38: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 39: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 40: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		papPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(0));
		missingInformatioPage.clickOnSaveButton();
		
		refresh();

		Logger("STEP 2: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 3: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask("Pre-Check");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(1), "", "Private Commercial", "", "No", ""));
		papPage.verifyPatientInformationDetails(expectedValues);

		Logger("STEP 4: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 5: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(3));
		papPage.verifyAlternateResearch(alternateResearch.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 7: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Confirm PAP Eligibility");
		papPage.clickOnTask("Eligibility");
		papPage.enterEligibilityCheck("No");
		ArrayList<String> expectedValues2 = new ArrayList<>(
				Arrays.asList(outComeOptions.get(1), "", "Private Commercial", "", "No", ""));
		papPage.verifyPatientInformationDetails(expectedValues2);
		quickStartPage.clickOnNextButton();

		Logger("STEP 8: Enter outome details");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(2));
		papPage.enterCoverageOutcomeReason(pAPOutcomeOptions.get(0));
		quickStartPage.clickOnNextButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 10: Navigate to Related list of CPE record and open Care Program Enrollee Work Order related list and validate for PAP WO is marked as Completed with outcome as Withdrawn and outcome reason as Alternate coverage approved");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		iapPage.navigateToCPEPRecord("PAP");
		papPage.validateEnrollmenetStartEndDate();

		Logger("STEP 11: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5047 PAP is Initiated manually and alternate coverage is
	 * approved
	 * 
	 * @author Trupti Zure Functional TC update needed
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "PAP is Initiated manually and alternate coverage is approved", enabled = true)
	public void FG18_IC5047_PAP_is_Initiated_manually_and_alternate_coverage_is_approved() throws Exception {

		String TestCaseNumber = "TC18";

		// Prerequisites
		String ID = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_EOE(TestCaseNumber);
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 1.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 1.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 1.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(accountName);

		Logger("Pre-requisites 1.4: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("Pre-requisites 1.5: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre-requisites 1.6: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 1.7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecordFrmCorrespondence(ExcelTestData.get(patientName));
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 1.10: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 2: On CPE record created , form top click on Start New Service button In Service select PAP click on next in reason select PA Appeal denied and click on Save");
		iapPage.clickOnStartNewService();
		papPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(0));
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 3: Validate PAP WO is initiated Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();
		papPage.clickOnTask(papSubTaskNames.get(0));

		Logger("STEP 4: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(1), planType.get(0), "", ""));
		papPage.verifyPatientInformationDetails(expectedValues);

		Logger("STEP 5: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 6: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(0));
		papPage.verifyAlternateResearch(alternateResearch.get(1));// as per new changes this will populate as No
		quickStartPage.clickOnSubmitButton();

//		Logger("STEP 7: On \"Research\" Sub Task >> Validate Below Mentioned Fields are Filled -Alternate Coverage Identified?  ");
//		papPage.clickOnPAPTask();
//		papPage.clickOnMainTask(papMainTaskNames.get(0));
//		papPage.clickOnTask(papSubTaskNames.get(1));
//		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
//				ExcelTestData.get(officePhone));
//		quickStartPage.clickOnSubmitButton();
//		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 8: Open \"Communicate Results\" Sub Task and enter contact made and attempt made details");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(2));
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(7));
		ArrayList<String> communicateResultsValues = new ArrayList<>(
				Arrays.asList(StatusCheck.get(1), contactMade.get(0), attempts.get(0), attemptOutcome.get(1)));
		papPage.enterCommunicateResultsDetails(communicateResultsValues, attempts.get(1), attemptOutcome.get(0));
		papPage.verifyAttemptDateIsNotNull();
		quickStartPage.clickOnSubmitButton();

		Logger("STEP 9: Open Capture Coverage Outcome sub task and Validate the Below Mentioned Fields: Outcome is picklist (Approved, Denied) Select outcome value as Approved");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(3));
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnSubmitButton();

		Logger("STEP 10: Navigate to Related list of CPE record and open Care Program Enrollee Work Order related list and validate for PAP WO is marked as Completed with outcome as Withdrawn and outcome reason as Alternate coverage approved");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEWorkOrder();
		papPage.checkCPEWorkOrderWithOutcome(careProgramProduct.get(4), ExcelTestData.get(patientName),
				iapoutcome.get(2), reason.get(8), workOrderName.get(5), StatusCheck.get(1));

		Logger("STEP 10: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5035 -PAP is initiated when BV Outcome = Uninsured and
	 * alternate coverage is approved TC update needed as per new changes
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "SIT_FreeGoods_PAP_SF - Scenario 1 - TC03 - PAP is initiated when BV Outcome = Uninsured and alternate coverage is approved", enabled = true)
	public void FG19_IC_5035_PAP_is_initiated_when_BV_Outcome_Uninsured_and_alternate_coverage_is_approved()
			throws Exception {

		String TestCaseNumber = "TC3";

		// Prerequisites
		String ID = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_AtopicDermatitis(TestCaseNumber);
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 1.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 1.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 1.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		Logger("Pre-requisites 1.4: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("Pre-requisites 1.5: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre-requisites 1.6: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 1.7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 1.10: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();

		// Navigate to CPE URL
		navigateToUrl("https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf0000008ZGjCAM/view");
		Thread.sleep(4000);

		Logger("STEP 2: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 3: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask(papSubTaskNames.get(0));
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(4), planType.get(0),"0",  "", lISEligible.get(0), ""));
		papPage.verifyPatientInformationDetails(expectedValues);

		Logger("STEP 4: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 5: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(1));
		papPage.verifyAlternateResearch(alternateResearch.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 7: Open accordion \"Confirm PAP Eligibility\" >> open task \"Eligibilty\"");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheck(alternateResearch.get(0));
		quickStartPage.clickOnNextButton();
		
		Logger("STEP 8: In \"Outcome\" Task Populate the \"Outcome\" as Approved.");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 9: Enter Order Details");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 10: Navigate to Related list of CPE record and open Care Program Enrollee Work Order related list and validate for PAP WO is marked as Completed with outcome as Withdrawn and outcome reason as Alternate coverage approved");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEWorkOrder();
		papPage.checkCPEWorkOrderData(careProgramProduct.get(2), ExcelTestData.get(patientName));

		Logger("STEP 11: User Logouts the Application.");
		documentsPage.logout();
	}

	public String PAPWorkflow_PatientEnrollment_Prerequisites(String testcaseNumber) throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L28.1 - Prurigo nodularis", "FALSE", "FALSE" };
		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 1.2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = "";
		documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate to the Recently view ");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 2.2:Navigate to Received Document Worklist and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.3:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//     	Logger("STEP 2.4:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//		documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.2:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(1),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);
		String url = getCurrentPageURL();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Search CPE");
		homeportalPage.closeTabs();
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();
		
		return url;

	}

	@Test(description = "SIT_FreeGoods_PAP_SF - Scenario 1 - TC02 - PAP is initiated with BV Outcome = Not Covered and alternate coverage is approved", enabled = true)
	public void FG20_IC5030_PAP_is_initiated_with_BV_Outcome_Not_Covered_and_alternate_coverage_is_approved()
			throws Exception {

		String TestCaseNumber = "TC20";

		// Prerequisites
		String url = PAPWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 1.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage.navigate(url);
		
		// BV Initialization code starts here
		Logger("Pre-requisites 1.5: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("Pre-requisites 1.6: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 1.7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(1), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(1));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 1.10: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 4: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 5: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask(papSubTaskNames.get(0));
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(2), "0", "Private Commercial", "", "Yes", ""));
		papPage.verifyPatientInformationDetails(expectedValues);

		Logger("STEP 6.1: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 6.2: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(1));
		papPage.verifyAlternateResearch(alternateResearch.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 7: On \"Research\" Sub Task >> Validate Below Mentioned Fields are Filled -Alternate Coverage Identified? and  ");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 8.1: Open \"Communicate Results\" Sub Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(2));

		Logger("STEP 8.2: Enter information in \"Communicate Results\" Sub Task");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(7));
		ArrayList<String> communicateResultsValues = new ArrayList<>(
				Arrays.asList(StatusCheck.get(1), contactMade.get(0), attempts.get(0), attemptOutcome.get(1)));
		papPage.enterCommunicateResultsDetails(communicateResultsValues, attemptOutcome.get(1), attemptOutcome.get(0));
		papPage.verifyAttemptDateIsNotNull();
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(3));

		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(8));
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 11: Navigate to Related list of CPE record and open Care Program Enrollee Work Order related list and validate for PAP WO is marked as Completed with outcome as Withdrawn and outcome reason as Alternate coverage approved");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEWorkOrder();
		papPage.checkCPEWorkOrderData(careProgramProduct.get(1), ExcelTestData.get(patientName));

		Logger("STEP 12: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-4626 -iCare2393 - SAT - TC02: Validate the Process for
	 * completing Alternate Coverage Research when the outcome is Denied for PAP
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "iCare2393 - SAT - TC02: Validate the Process for completing Alternate Coverage Research when the outcome is Denied for PAP", enabled = true)
	public void FG21_IC4626_Validate_the_Process_for_completing_Alternate_Coverage_Research_when_the_outcome_is_Denied_for_PAP()
			throws Exception {

		String TestCaseNumber = "TC21";

		// Prerequisites
	//	String ID = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_PrurigoNodularis2(TestCaseNumber);
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeURL = "https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf0000008NU5CAM/view";
		String ID = "0Wwbf0000008NU5";
		Logger("STEP 1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(accountName);

		// BV Initialization code starts here
		Logger("STEP 5: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("STEP 6: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(1));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 10: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 11: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 12: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 13: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask("Pre-Check");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);
//		ArrayList<String> expectedValues = new ArrayList<>(
//				Arrays.asList(outComeOptions.get(2), "0", "Private Commercial", "", "Yes", ""));
//		papPage.verifyPatientInformationDetails(expectedValues);

		Logger("STEP 14: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 15: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(0));
		papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 16: On \"Research\" Sub Task >> Validate Below Mentioned Fields are Filled -Alternate Coverage Identified? and  ");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Alternate Coverage");
		papPage.clickOnTask("Research and Capture Outcome");
		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 17: Open \"Communicate Results\" Sub Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Alternate Coverage");
		papPage.clickOnTask("Communicate Results");

		Logger("STEP 18: Enter information in \"Communicate Results\" Sub Task");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(7));
		ArrayList<String> communicateResultsValues = new ArrayList<>(
				Arrays.asList(StatusCheck.get(1), contactMade.get(0), attempts.get(0), attemptOutcome.get(1)));
		papPage.enterCommunicateResultsDetails(communicateResultsValues, attemptOutcome.get(1), attemptOutcome.get(0));
		papPage.verifyAttemptDateIsNotNull();
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 21: Validate the Accrodian 2 Confirm PAP Eligibility Task should be initiated");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Confirm PAP Eligibility");
		papPage.clickOnTask("Eligibility");

		Logger("STEP 22: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE4624 - iCare2393 - SAT - TC01: Validate the Process for
	 * completing Alternate Coverage Research when the outcome is Approved for PAP
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "TC01: Validate the Process for completing Alternate Coverage Research when the outcome is Approved for PAP.", enabled = true)
	public void FG22_IC4624_Validate_the_Process_for_completing_Alternate_Coverage_Research_when_the_outcome_is_Approved_for_PAP()
			throws Exception {

		String TestCaseNumber = "TC22";

		// Prerequisites
		String ID = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_PrurigoNodularis2(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = accountName + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 1.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 1.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 1.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(accountName);

		// BV Initialization code starts here
		Logger("Pre-requisites 1.5: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("STEP 7: Click on Review and Finalize Benefit Task from BV Task>>Update Mandatory fields from Member Plan section and click on save.>>Then Update all the mandatory fields of CB section. >> Click on save of CB section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(1), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(1));
		bvPage.clickOnCoverageBenefitSave();

		Logger("STEP 8 : Click on Complete button on the bottom , saving both Member plan and Coverage benefit details.");
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecordFrmCorrespondence(ExcelTestData.get(patientName));
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 10: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 10.1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl("https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf0000008QJtCAM/view");
		Thread.sleep(4000);

		Logger("STEP 12: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 13: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask("Pre-Check");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 14: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 14.1: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(0));
		papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 15: Validate the Research Task should be Initiated.");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.verifyResearchTask();

		Logger("STEP 16: Open \"Research\" Sub Task >> Validate Below Mentioned Fields are Filled -Alternate Coverage Identified?  ");
		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// /last modified method
		Logger("STEP 19: Initiate PAP manually and follow the above mentioned step to terminate PAP when Outcome is Approved on Capture Coverage Outcome task.");
		iapPage.clickOnStartNewService();
		papPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(0));
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 19.1: Validate PAP WO is initiated Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();
		papPage.clickOnTask(papSubTaskNames.get(0));

		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 19.2: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 19.3: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(0));
		papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 19.4: On \"Research\" Sub Task >> Validate Below Mentioned Fields are Filled -Alternate Coverage Identified?  ");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 19.5: Open \"Communicate Results\" Sub Task and enter contact made and attempt made details");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(2));
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(7));
		ArrayList<String> communicateResultsValues1 = new ArrayList<>(
				Arrays.asList(StatusCheck.get(1), contactMade.get(0), attempts.get(0), attemptOutcome.get(1)));
		papPage.enterCommunicateResultsDetails(communicateResultsValues1, attemptOutcome.get(1), attemptOutcome.get(0));
		papPage.verifyAttemptDateIsNotNull();
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 20: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-4600 iCare 2391 - SAT - TC01: Validate the Configuration
	 * of Alternate Coverage Research Criteria when the BV Outcome is Uninsured for
	 * PAP
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT - TC01: Validate the Configuration of Alternate Coverage Research Criteria when the BV Outcome is Uninsured for PAP", enabled = true)
	public void FG23_IC4600_Validate_the_Configuration_of_Alternate_Coverage_Research_Criteria_when_the_BV_Outcome_is_Uninsured_for_PAP()
			throws Exception {

		String TestCaseNumber = "TC24";

		// Prerequisites
		String ID = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_PrurigoNodularis2(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = accountName + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("STEP 4 :Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 4.1 :Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 4.2: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 5: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(accountName);

		// BV Initialization code starts here
		Logger("STEP 5.1: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifyBVTasks();
		bvPage.verifyBVCaptureState();

		Logger("STEP 6 and 7: Click on Review and Finalize Benefit Task from BV Task>>Update Mandatory fields from Member Plan section and click on save.>>Then Update all the mandatory fields of CB section. >> Click on save of CB section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(1));
		bvPage.clickOnCoverageBenefitSave();

		Logger("STEP 8 : Click on Complete button on the bottom , saving both Member plan and Coverage benefit details");
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 10: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 11: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 12: PAP WO should get initiated for the CPE >> Click on it to open PAP task.");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 13: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask("Pre-Check");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 13.1: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 14: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(0));
		papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 15: Research Task is initiated and validate the fields");
		careProgram.clickOnWorkOrderTask(workOrderName.get(5));
		careProgram.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask("Research and Capture Outcome");
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 15.1: User Logouts the Application.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-4437 Validate the Accordion 2 - Step 2 - Creation of PAP
	 * Enrollment Record (CPEP) For Patient has Medicare Part D
	 * 
	 * @author Trupti Zure
	 */

	@Test(description = "Validate the Accordion 2 - Step 2 - Creation of PAP Enrollment Record (CPEP) For Patient has Medicare Part D", enabled = true)
	public void FG24_IC4437_Creation_of_PAP_Enrollment_Record_CPEP_For_Patient_has_Medicare_Part_D() throws Exception {

		String TestCaseNumber = "TC24";

		// Prerequisites
		String ID = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_EOE(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 1.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 1.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 1.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(accountName);

		Logger("Pre-requisites 1.4: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("Pre-requisites 1.5: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre-requisites 1.6: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(2),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 1.7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();

		Logger("STEP  : Click on Complete button on the bottom , saving both Member plan and Coverage benefit details");
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		String url = getCurrentPageURL();

		Logger("STEP 1.10: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 2: PAP WO should get initiated for the CPE >> Click on it to open PAP task.");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();
		papPage.clickOnTask(papSubTaskNames.get(0));

		Logger("STEP 3: Open Alternate Coverage >> Open Pre-check OS >> Validate below mentioned fields are filled");
		papPage.clickOnTask(papSubTaskNames.get(0));
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(4), planType.get(2), "0","","Yes", ""));
		papPage.verifyPatientInformationDetails(expectedValues);

		Logger("STEP 4: While on the same ScreenF validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 5: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(2));
		papPage.verifyAlternateResearch(alternateResearch.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 7: Open accordion \"Confirm PAP Eligibility\" >> open task \"Eligibilty\"");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.verifyPatientInformationDetails(expectedValues);
		papPage.enterEligibilityCheck(alternateResearch.get(0));
		quickStartPage.clickOnNextButton();
		
		Logger("STEP 8: In \"Outcome\" Task Populate the \"Outcome\" as Approved.");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 9: Enter Order Details");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 10: Now click on the related tab and validate that the PAP Enrollment record is visible on the related list of CPE → Click on the record.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String papCPE = "PAP - " + careProgramProduct.get(4).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(papCPE);

		Logger("STEP 11: Verify the \"Enrollment Start Date\" field should be auto-populated with the current date, and the \"Enrollment End Date\" should be auto-populated based on the logic below:");
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate);

		Logger("STEP 12: Validate that the PAP CPEP details Page layout is according to the attached snippet");
		papPage.verifyInformationFieldsArePresent();
		papPage.verifySysInformationFieldsArePresent();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-4352- To Validate Patient IAP duration can be extended,
	 * and IAP CPEP record creation
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Test Case Id:ICARE-4352- To Validate Patient IAP duration can be extended, and IAP CPEP record creation", enabled = true)
	public void FG25_ICARE_4352_To_Validate_Patient_IAP_duration_can_be_extended_and_IAP_CPEP_record_creation()
			throws Exception {

		String TestCaseNumber = "TC25";

		// Prerequisites
		String url = FreeGoods_PatientEnrollment_Prerequisites(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = accountName + " - " + careProgramProduct.get(1).split(" -")[0];
		
		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 3: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		// IAP
		Logger("STEP 3: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 4: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 5: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		iapPage.selectReason();

		Logger("STEP 6: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 7: Validate that in the right side of the UI there are two tasks:IAP Summary,Extend/Discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();
		iapPage.checkIAPSecondTask();

		Logger("STEP 8: Expand the IAP Summary section and Click on IAP Enrollment Task");
		iapPage.clickOnTask();

		Logger("STEP 9: Enter eligibilty criteria");
		iapPage.verifyTaskIsLoaded(taskTitle.get(0));
		iapPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 10: Validate if User is navigated to the eligibility screen");
		iapPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 11: Enter order details and click submit");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		navigateToUrl("https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf0000008PpFCAU/view");
		Logger("STEP 12: Click on IAP subtask extend/discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPSecondTask();
		iapPage.clickOnTask2();

		Logger("STEP 13: Enter Extend Discontinue Details");
		iapPage.enterExtend();
		missingInformatioPage.clickNextButton();
		iapPage.verifyandenterExtentionReason(extensionReason.get(0));
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 14: Validate Enrollment end date and extension Reason ");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		iapPage.navigateToCPEPRecord("IAP");
		iapPage.validateEnrollmenetEndDate();
		iapPage.validateExtensionReason(extensionReason.get(0));

		Logger("STEP 15: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-4351 -Validate the Initiation of PAP record When the
	 * Patient has BV Outcome has Uninsured.
	 * 
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE-4351 -Validate the Initiation of PAP record When the Patient has BV Outcome has Uninsured.", enabled = true)
	public void FG26_IC_4351_Validate_the_initiation_of_PAP_record_when_patient_has_BV_Outcome_has_uninsured()
			throws Exception {

		String TestCaseNumber = "TC26";

		// Prerequisites
		String ID = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_AtopicDermatitis(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 1.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 1.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 1.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(accountName);

		Logger("Pre-requisites 1.4: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("Pre-requisites 1.5: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre-requisites 1.6: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 1.7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecordFrmCorrespondence(ExcelTestData.get(patientName));
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("Pre-requisites 1.10: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 2: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();
		papPage.clickOnTask(papSubTaskNames.get(0));

		Logger("STEP 3: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all PAP critical fields are populated");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 4: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 5: Select value as Patient Uninsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(0));
		papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 5.1: Enter Research details");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterResearchDetails(alternateResearch.get(1), ExcelTestData.get(PayerName),
				ExcelTestData.get(rxPhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 6: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheck(alternateResearch.get(0));
		quickStartPage.clickOnNextButton();

		Logger("STEP 7: In \"Outcome\" Task Populate the \"Outcome\" as Approved.");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 8: Enter Order Details");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 9: Navigate to MI tab and check if any MI is open");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 10: User Logout the Application.");
		documentsPage.logout();

	}

	@Test(description = "SIT_Free Goods_QuickStart_SF - Scenario 1 - TC01 - Patient is Eligible for QuickStart Program.", enabled = true)
	public void FG27_IC4266_Validate_Patient_Is_Eligible_For_QuickStart_Program() throws Exception {

		String TestCaseNumber = "TC27";

		// Prerequisites
		String ID=FreeGoodsWorkflow_PatientEnrollment_Prerequisites_PrurigoNodularis2(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-requisites 2.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 2.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 2.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 2.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		// BV Initialization
		Logger("Pre-requisites 2.5: Verify BV Task is initiated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(1), paRequired.get(0), pAOutcomeOptions.get(3));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 26: Login to the QA_SIT Org as 'Case manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		
		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 12: Navigate to Quick Start and verify flow has initiated");
		refresh();
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();

		Logger("STEP 13: Click on Enrollment task");
		quickStartPage.clickOnTask();

		Logger("STEP 14: Enter Eligibility Criteria and click on Next button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 15: Enter Eligibility outcome and click on next button ");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 17: Enter order details and click on submit button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		Logger("STEP 18: Click on quick start button and verify task compltion status");
		quickStartPage.clickOnQuickStart();
		quickStartPage.checkQuickStartTaskComplition();

		Logger("STEP 19: Click on relatad tab and verify to retrive order number of CPE Record");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		String orderNumber = quickStartPage.getOrderNumber();

		Logger("STEP 20: Navigate to order Page");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(8), DocumentPage.class);

		Logger("STEP 21: Verify to Search abd click on Order Number");
		quickStartPage.searchOrder(orderNumber);
		quickStartPage.clickOnRecord(orderNumber);

		Logger("STEP 22: verify to click on account and navigate to CPE Record");
		String account = ExcelTestData.get(patientName);
		quickStartPage.navigateToAccount(account);
		accountObject.clickOnTab(tabsName.get(1));
		String cpe = account + " - " + careProgramProduct.get(1).split(" -")[0];
		quickStartPage.navigateToCPERecord(cpe);

		Logger("STEP 23: Navigate to Quick start CPE Record");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String quickStartCPE = "QuickStart - " + careProgramProduct.get(1).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(quickStartCPE);

		Logger("STEP 24: Verify Enrollment start and end date");
		quickStartPage.validateEnrollmentStartEndDate();// check this, run again

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-3682 -Validate Enrollment Start date and End date are
	 * automatically populated in QA CPEP
	 * 
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test
	public void FG28_IC_3682_Validate_Enrollment_Start_date_and_End_date_are_automatically_populated_in_QA_CPEP()
			throws Exception {

		String TestCaseNumber = "TC20";

		// Prerequisites
		String ID = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_AtopicDermatitis(TestCaseNumber);
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-requisites 2.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 2.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 2.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 2.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		// BV Initialization
		Logger("Pre-requisites 2.5: Verify BV Task is initiated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 2.6: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 2.7: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(1), paRequired.get(0), pAOutcomeOptions.get(3));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 3: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 4: Login to the QA_SIT Org as 'Case manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 5: Navigate to Quick Start and verify flow has initiated");
		refresh();
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();

		Logger("STEP 6: Click on Enrollment task");
		quickStartPage.clickOnTask();

		Logger("STEP 7: Enter Eligibility Criteria and click on Next button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 8: Enter Eligibility outcome and click on next button ");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 9: Enter order details and click on submit button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));		

		Logger("STEP 10: Click on quick start button and verify task compltion status");
		quickStartPage.clickOnQuickStart();
		quickStartPage.checkQuickStartTaskComplition();
		refresh();

		Logger("STEP 11: Navigate to Quick start CPE Record");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String quickStartCPE = "QuickStart - " + careProgramProduct.get(2).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(quickStartCPE);

		Logger("STEP 12: Verify Enrollment start and end date");
		quickStartPage.validateEnrollmentStartEndDate();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-3490 -Validate QA-Critical information and QS eligibility
	 * criteria
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Validate QA-Critical information and QS eligibility criteria", enabled = true)
	public void FG29_IC3490_Validate_QA_Critical_information_and_QS_eligibility_criteria() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC29";

		// Pre-Requisite
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "DUPIXENT MyWay", "Preferred Specialty Pharmacy", "Diagnosis Code" };
		String columnValue[] = { "TRUE", "FALSE", "L20.9 - Atopic dermatitis, unspecified" };
		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		 Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

				Logger("STEP 1.2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate to the Recently view ");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 2.2:Navigate to Received Document Worklist and Check the
		// checkbox on the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.3:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 2.4:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.2:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
		documentsPage.navigate("https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/ReceivedDocument/0iobf000000H5mTAAS/view?ws=%2Flightning%2Fr%2FReceivedDocument%2F0iobf000000H5krAAC%2Fview");
		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate), textMessaging.get(0));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(cpeURL);
		Thread.sleep(4000);

		Logger("STEP 16: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 16.1: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 16.2: Login to the QA_SIT Org as 'BV User'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 1.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 1.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 1.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(accountName);

		Logger("Pre-requisites 1.4: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("Pre-requisites 16.3: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre-requisites 16.4: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 16.5: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 16.8: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 16.9: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		navigateToUrl(cpeURL);
		refresh();
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();

		Logger("STEP 18: Click on Enrollment task");
		quickStartPage.clickOnTask();
		refresh();

		Logger("STEP 19: Navigate to MI-Tab and Validate in compact layout \"blocked by MI\" field is blank, no open cases, collect MI if present");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.validateNoOpenCases();

		Logger("STEP 20: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-5064 PAP is initiated manually with alternate research
	 * required is no , eligibility outcome is non-eligible
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "SIT_FreeGoods_PAP_SF - Scenario 1 - TC03 - PAP is initiated when BV Outcome = Uninsured and alternate coverage is approved", enabled = true)
	public void FG30_IC_5064_PAP_is_manually_initiated_with_alternateresearch_required_if_the_eligibility_outcome_is_noneligible()
			throws Exception {

		String TestCaseNumber = "TC30";

		// Prerequisites
		String ID = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_EOE(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 1.2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("Pre-requisites 1.3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("Pre-requisites 1.4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(accountName);

		Logger("Pre-requisites 1.4: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("Pre-requisites 1.5: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre-requisites 1.6: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 1.7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 1.10: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 2: On CPE record created , form top click on Start New Service button In Service select PAP click on next in reason select PA Appeal denied and click on Save");
		iapPage.clickOnStartNewService();
		papPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(0));
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 3: Validate PAP WO is initiated Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();
		papPage.clickOnTask(papSubTaskNames.get(0));

		Logger("STEP 4: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(1), "0", planType.get(0), "", lISEligible.get(0), ""));
		papPage.verifyPatientInformationDetails(expectedValues);

		Logger("STEP 5: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 6: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(3));
		papPage.verifyAlternateResearch(alternateResearch.get(1));
		quickStartPage.clickOnSubmitButton();

		Logger("STEP 7: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.verifyPatientInformationDetails(expectedValues);
		papPage.enterEligibilityCheck(listOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 8: Enter outome details");
		iapPage.verifyAndEntereligibilityOutcome(eligibilityOutcome.get(1), iapoutcome.get(1), reason.get(0));
		quickStartPage.clickOnNextButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 9: Navigate to Related list of CPE record and open Care Program Enrollee Work Order related list and validate for PAP WO is marked as Completed with outcome as Denied");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEWorkOrder();
		papPage.checkCPEWorkOrderWithOutcome(careProgramProduct.get(4), ExcelTestData.get(patientName),
				iapoutcome.get(1), reason.get(0), workOrderName.get(5), StatusCheck.get(1));

		Logger("STEP 10: User Logouts the Application.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-12128 - To validate PAP CPEP Record Type Based For Non Med
	 * part D 12128
	 * 
	 * @author Tejal
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "To validate DMW PAP Approval Medicare Enrollee - MD Fax correspondence generation with the new template updates", enabled = true)
	public void FG31_IC12128_To_validate_DMWPAPApproval_MedicareEnrolee_MD_Fax_correspondence_generation_with_new_template_updates()
			throws Exception {

		String TestCaseNumber = "TC31";

		// Prerequisites
		String ID = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_PrurigoNodularis2(TestCaseNumber);
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("STEP 1::Login to the QA_SIT Org as 'BV Specialist'.");
		Logger("STEP 1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(ID);
		
		Logger("STEP 5: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();
		bvPage.verifytheBVTaskInitiated();

		Logger("STEP 6: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 7: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 8: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(1), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 11: Logout of the application as BV user.");
		documentsPage.logout();
		documentsPage.logout();

		Logger("STEP 12: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 14: Validate PAP WO is initiated Click on PAP WO");
		Logger("STEP 14: Validate PAP WO is initiated Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituationAndValidateNoneoptionisAbsent(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 6: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
	//	papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		papPage.enterResearchDetails(alternateCoverage.get(1), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecordFrmCorrespondence(ExcelTestData.get(patientName));
		
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheckEligibileforLIS("Yes"); // Adjusted FPL % should be less than 150
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 7: Navigate to Related list of CPE record and open Care Program Enrollee Work Order related list and validate for PAP WO is marked as Completed with outcome as Withdrawn and outcome reason as Alternate coverage approved");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEWorkOrder();
		papPage.clickOnPAPCpe();
		papPage.verifyStartEndDateNotEditable();
		papPage.validateEnrollmenetStartEndDate();
		papPage.validateMedicarePartDisNo(alternateCoverage.get(1));

		Logger("STEP 8: Log out from application");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-Free Goods_IAP_SF_Scenario1-TC03- Discontinuation of IAP
	 * Service ICARE-18053
	 * 
	 * @author Tejal
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Free Goods_IAP_SF_Scenario1-TC03- Discontinuation of IAP Service", enabled = true)
	public void FG32_IC_5138_Free_Goods_IAP_TC03_Discontinuation_of_IAP_Service() throws Exception {
		String TestCaseNumber = "TC24";

		// Prerequisitess
		String cpeUrl = FreeGoodsWorkflow_PatientEnrollment_Prerequisites_PrurigoNodularis(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		// cpeUrl
		navigateToUrl(cpeUrl);
		Logger("STEP 39: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();// IAP start

		Logger("STEP 40: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		iapPage.selectReason();

		Logger("STEP 41: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		Logger("STEP 42: Validate that in the right side of the UI there are two tasks:IAP Summary,Extend/Discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();
		iapPage.checkIAPSecondTask();

		Logger("STEP 43: Expand the IAP Summary section and Click on IAP Enrollment Task");
		iapPage.clickOnTask();

		Logger("STEP 44: Verify Users selects Enrollment Reason as Below Enrollment End Date populates accordingly");
		iapPage.verifyTaskIsLoaded(taskTitle.get(0));
		iapPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 45: Validate if User is navigated to the eligibility screen");
		iapPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		iapPage.checkIAPIntiation();
		iapPage.checkIAPSecondTaskInitiation();
		iapPage.clickOnIAPTask();
		iapPage.enterDiscontinue();
		missingInformatioPage.clickNextButton();
		iapPage.enterDiscontinuationReason();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
		Logger("STEP 46: Navigate to CPEP table and validate IAP Discontinuation date and reason");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		iapPage.clickOnIAPCpe();
		iapPage.validateDiscontinuationDate();// new
		iapPage.validateDiscontinuationReason();
		
		Logger("STEP 47: Log out from application");
		documentsPage.logout();
	}

	@Test(description = "SIT_Prior Authorization Workflow Patient Enrollment Prerequisites", enabled = true)
	public String BenefitVerificationWorkflow_PatientEnrollment_Prerequisites(String testcaseNumber) throws Exception {

		String cpeUrl = null;
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax", "Diagnosis Code",
				"DUPIXENT MyWay", "Preferred Specialty Pharmacy", "Office Fax" };
		String columnValue[] = { "Automation Correspondence SP", "(954) 312-1432", "(166) 254-1171",
				"L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE", "(166) 254-1171" };
		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		Logger("STEP 2:Upload document to Dupixent portal");
		/*String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));*/
		documentsPage.navigate("https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/ReceivedDocument/0iobf000000H1PVAA0/view");
		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();

		cpeUrl = getCurrentPageURL();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		return cpeUrl;

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-Free Goods_PAP_SF - Scenario 5 - TC02 - PAP is initiated
	 * with BV Outcome = Not Covered ICARE-18058
	 * 
	 * @author Tejal
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Free Goods_PAP_SF - Scenario 5 - TC02 - PAP is initiated with BV Outcome = Not Covered", enabled = true)
	public void FG33_IC_5113_Free_Goods_PAP_SF_TC02_PAP_is_initiated_with_BV_Outcome_Not_Covered() throws Exception {
		String TestCaseNumber = "TC47";

		// Pre-requisites
	    String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite STEP 14: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		navigateToURL(CPEURL);

      Logger("Pre-Requisite STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(1), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		Logger("Pre-Requisite STEP 24: logout from applilcaton");
		documentsPage.logout();

		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();
		navigateToURL(CPEURL);
		papPage.checkPAPWOIntiation();
		
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();
		papPage.validateEnrollmenetStartEndDate();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEWorkOrder();
		String[] workOrders = { "PAP" };
		String expectedStatus = "Completed";
		String expectedOutcome = "Approved";

		papPage.checkCPEWorkOrderData(Arrays.asList(workOrders), expectedStatus, expectedOutcome);
		Logger("STEP 16: Log out from application");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-Free Goods_PAP_SF - Scenario 5 - TC02 - PAP is Initiated
	 * manually and alternate coverage is Denied
	 * 
	 * @author Tejal
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "SIT_Free Goods_PAP_SF - Scenario 3 - TC04 - PAP is Initiated manually and alternate coverage is Denied", enabled = true)
	public void FG34_IC5108_Free_Goods_PAP_SF_TC02_PAP_is_initiated_manually_and_alternate_coverage_is_Denied()
			throws Exception {
		String cpeUrl = null;
		String TestCaseNumber = "TC34";

		// Prerequisites
		cpeUrl = BenefitVerificationWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		Logger("STEP 2: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(cpeUrl);
		Thread.sleep(2000);
		Logger("STEP 41 :PAP work order initialization.");
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason("PAP Appeal");
		Logger("STEP 42 : Click on save and refresh the page");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(0));
		// papPage.enterPayerDetails();
		quickStartPage.clickOnSubmitButton();
		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(2));
		papPage.enterDetails(paStatus.get(1), payerContact.get(0), attempts.get(0), attempt.get(0),
				attemptOutcomes.get(1), attempt.get(1), attemptOutcomes.get(1), attempt.get(2), attemptOutcomes.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(3));
		papPage.enterCoverageOutcome(iapoutcome.get(1));

		quickStartPage.clickOnSubmitButton();
		refresh();

		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheck();

		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();
		papPage.validateEnrollmenetStartEndDate();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		// papPage.verifyPAPOutcomeIsApproved();
		Logger("STEP 16: Log out from application");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-18059 RRGN-FG: Automate SIT_Free Goods_PAP_SF - Scenario 4
	 * - TC04 - PAP is Initiated manually, Alternate Research Required is Yes,
	 * Research Alternate Coverage Identified is No, Coverage outcome is Denied,
	 * Eligibility outcome is Eligible with Medicare Part D.
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SIT_Free Goods_PAP_SF - Scenario 4 - TC04 - PAP is Initiated manually, Alternate Research Required is Yes, Research Alternate Coverage Identified is No, Coverage outcome is Denied, Eligibility outcome is Eligible with Medicare Part D.", enabled = true)
	public void FG34_IC5112_Verify_PAP_is_Initiated_manually_Alternate_Research_Required_is_Yes_Research_Alternate_Coverage_Identified_is_No_Coverage_outcome_is_Denied_Eligibility_outcome_is_Eligible_with_Medicare_PartD()
			throws Exception {

		String TestCaseNumber = "TC30";
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "K20.0 - Eosinophilic esophagitis", "TRUE", "FALSE" };

		synchronized(excelDataUpdate) {
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(4).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("EOE");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("Pre-Requisite STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("Pre-Requisite STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Pre-Requisite STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 5:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-Requisite STEP 6: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 7: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("Pre-Requisite STEP 8:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-Requisite STEP 9:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 10:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 11:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 11.1:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 12:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Pre-Requisite STEP 13: OPen CPE record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		documentsPage.logout();

		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2 :Navigate to CPE object → Click on Start new service button at the top right corner.Select, Service → PAP and click on Next button.Reason → PAP Appeal and click on Save button");
		navigateToURL(CPEURL);
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason("PAP Appeal");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 3: Click on PAP from Word order → Validate ‘Alternate Coverage' and 'Confirm PAP Eligibility’ tasks under My Tasks");
		papPage.checkPAPWOIntiation();
		papPage.clickOnPAPTask();
		careProgram.checkMainTaskInitiation("Alternate Coverage");
		careProgram.checkMainTaskInitiation("Confirm PAP Eligibility");

		Logger("STEP 4: Click on Alternate Coverage Task → Click on Pre-Check → Select picklist value Patient Uninsured or Patient Underinsured on Coverage Situation Field → Click on Submit Button");
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
    	refresh();

		Logger("STEP 5: Again, navigate to PAP WO → Click on Alternate Coverage Task → Click on Research → Select picklist value No on Alternate Coverage Identified? Field → Click on Submit Button");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterResearchDetails(alternateCoverage.get(1), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 6: Again, navigate to PAP WO → Click on Confirm PAP Eligibility Task → Click on Eligibility → Select picklist value Yes on all Field under Eligibility Check Section → Click on Next Button");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Confirm PAP Eligibility");
		papPage.clickOnTask("Eligibility");
		papPage.enterEligibilityCheck("Yes");
		quickStartPage.clickOnNextButton();

		Logger("STEP 7: On the Outcome Section validate Eligibility field is populated with Eligible → Select Approved in the Outcome Field → Click on Next Button");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 8: On the Order Details Section select any picklist values for Prescription Field →Select at least one attachment →  Click on Submit Button ");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 9: Go to Related List of the same CPE Record → Open recently created CPEP PAP record from CPEP related List → Validate Enrollment Start Date as Today’s Date and Enrollment End Date as 365 days from Todays Date (For Non-Medicare Part D)");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String papCPE = "PAP - " + careProgramProduct.get(4).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(papCPE);
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate);

		Logger("STEP 10: Go to Related List of the same CPE Record → Go to CPE Work Order Related List → Validate Outcome as Approved");
		papPage.validatePAPoutcomeVal(pAOutcomeOptions.get(1));

		Logger("STEP 11: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-12143 -To validate PAP CPEP Record Type Based For
	 * Med part D
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT - TC01: To validate PAP CPEP Record Type Based For Med part D", enabled = true)
	public void FG35_IC12143_To_validate_PAP_CPEP_Record_Type_Based_For_Med_part_D() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC30";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L28.1 - Prurigo nodularis", "TRUE", "FALSE" };
		
		synchronized(excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

			Logger("STEP 1.2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate to the Recently view ");
		documentsPage.verifyRecentlyViewDocumentList();

//			Logger("STEP 2.2:Navigate to Received Document Worklist and Check the checkbox on the record and click on 'Assign to me' button.");
//			documentsPage.navigateToReceiveddocument();
//			documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.3:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//	     	Logger("STEP 2.4:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//			documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.2:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(1),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate), textMessaging.get(0));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(ID);

		Logger("STEP 5: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("STEP 6: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 7: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 8: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(1), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecordFrmCorrespondence(ExcelTestData.get(patientName));
		refresh();
		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 11: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 18: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 19: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 26: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();
		papPage.clickOnTask(papSubTaskNames.get(0));

		Logger("STEP 27: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all PAP critical fields are populated");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 28: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 29: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(2));
		papPage.verifyAlternateResearch(alternateResearch.get(1));
		quickStartPage.clickOnSubmitButton();
		papPage.clickRefresh();

		Logger("STEP 30: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.verifyAndenterEligibilityCheck(alternateResearch.get(0));
		quickStartPage.clickOnNextButton();

		Logger("STEP 31: In \"Outcome\" Task Populate the \"Outcome\" as Approved.");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 32: Enter Order Details");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		navigateToUrl(url);
		refresh();

		Logger("STEP 33: Now click on the related tab and validate that the PAP Enrollment record is visible on the related list of CPE → Click on the record.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String papCPE = "PAP - " + careProgramProduct.get(1).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(papCPE);

		Logger("STEP 34: Validate that the Patient has Medicare Part D field is populated as Yes");
		papPage.validatedPatientHasMedPartD();

		Logger("STEP 35: Validate that the Enrollment Start Date and Enrollment End Date fields are Read only fields");
		papPage.ValidateEnrollmentDateReadOnlyFields();

		Logger("STEP 36: Validate that the End Date Field is populated with the Last Day of the Year");
		String expectedEndDate = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate);

		Logger("STEP 37: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-5114 -TC03 - PAP is initiated when with BV
	 * Outcome = Uninsured (non Med D)
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "TC03 - PAP is initiated when with BV Outcome = Uninsured (non Med D)", enabled = true)
	public void FG38_IC5114_TC03_PAP_is_initiated_when_with_BV_Outcome_Uninsured_non_Med_D() throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC38";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L28.1 - Prurigo nodularis", "TRUE", "FALSE", "371841" };
		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 1.2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate to the Recently view ");
		documentsPage.verifyRecentlyViewDocumentList();

//			Logger("STEP 2.2:Navigate to Received Document Worklist and Check the checkbox on the record and click on 'Assign to me' button.");
//			documentsPage.navigateToReceiveddocument();
//			documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.3:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//	     	Logger("STEP 2.4:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//			documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.2:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(1),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate), textMessaging.get(0));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(ID);

		Logger("STEP 5: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("STEP 6: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 7: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 8: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(1), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecordFrmCorrespondence(ExcelTestData.get(patientName));
		refresh();
		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 11: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 18: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 19: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 26: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();
		papPage.clickOnTask(papSubTaskNames.get(0));

		Logger("STEP 27: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all PAP critical fields are populated");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 28: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 29: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(0));
		papPage.clickRefresh();
		papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();
		papPage.clickRefresh();

		Logger("STEP 30: Enter Research details");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterResearchDetails(alternateResearch.get(1), ExcelTestData.get(PayerName),
				ExcelTestData.get(rxPhone));
		quickStartPage.clickOnSubmitButton();
		papPage.clickRefresh();

		Logger("STEP 31: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.verifyAndenterEligibilityCheck(alternateResearch.get(0));
		quickStartPage.clickOnNextButton();

		Logger("STEP 32: In \"Outcome\" Task Populate the \"Outcome\" as Approved.");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 33: Enter Order Details");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		navigateToUrl(url);
		refresh();

		Logger("STEP 34: Now click on the related tab and validate that the PAP Enrollment record is visible on the related list of CPE → Click on the record.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String papCPE = "PAP - " + careProgramProduct.get(1).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(papCPE);

		Logger("STEP 35: Validate Enrollment Start Date as Today’s Date and Enrollment End Date as 365 days from Todays Date ");
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate);
		navigateToUrl(url);
		refresh();

		Logger("STEP 36: Go to Related List of the same CPE Record → Go to CPE Work Order Related List → Validate Outcome as Approved ");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEWorkOrder();
		papPage.validateCPEWOOutcomeStatus(pAOutcomeOptions.get(1));

		Logger("STEP 37: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-5111 -TC03 - PAP is initiated when with BV
	 * Outcome = Uninsured (Med D)
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "TC03 - PAP is initiated when with BV Outcome = Uninsured (Med D)", enabled = true)
	public void FG39_IC5111_TC03_PAP_is_initiated_when_with_BV_Outcome_Uninsured_Med_D() throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC39";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L28.1 - Prurigo nodularis", "TRUE", "FALSE"};
		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 1.2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate to the Recently view ");
		documentsPage.verifyRecentlyViewDocumentList();

//			Logger("STEP 2.2:Navigate to Received Document Worklist and Check the checkbox on the record and click on 'Assign to me' button.");
//			documentsPage.navigateToReceiveddocument();
//			documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.3:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

//	     	Logger("STEP 2.4:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
//			documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.2:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(1),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate), textMessaging.get(0));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 1::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);

		Logger("STEP 3: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 4: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);
		// Utility_Function.switchToWindow(ID);

		Logger("STEP 5: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("STEP 6: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 7: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 8: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecordFrmCorrespondence(ExcelTestData.get(patientName));
		refresh();
		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 11: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 18: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 19: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 26: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();
		papPage.clickOnTask(papSubTaskNames.get(0));

		Logger("STEP 27: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all PAP critical fields are populated");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 28: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 29: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(2));
		papPage.clickRefresh();
		papPage.verifyAlternateResearch(alternateResearch.get(1));
		quickStartPage.clickOnSubmitButton();
		papPage.clickRefresh();

		Logger("STEP 30: Enter Research details");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterResearchDetails(alternateResearch.get(1), ExcelTestData.get(PayerName),
				ExcelTestData.get(rxPhone));
		quickStartPage.clickOnSubmitButton();
		papPage.clickRefresh();

		Logger("STEP 31: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.verifyAndenterEligibilityCheck(alternateResearch.get(0));
		quickStartPage.clickOnNextButton();

		Logger("STEP 32: In \"Outcome\" Task Populate the \"Outcome\" as Approved.");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 33: Enter Order Details");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		navigateToUrl(url);
		refresh();

		Logger("STEP 34: Now click on the related tab and validate that the PAP Enrollment record is visible on the related list of CPE → Click on the record.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String papCPE = "PAP - " + careProgramProduct.get(1).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(papCPE);

		Logger("STEP 35: Validate Enrollment Start Date as Today’s Date and Enrollment End Date as 365 days from Todays Date");
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate);
		navigateToUrl(url);
		refresh();

		Logger("STEP 36: Go to Related List of the same CPE Record → Go to CPE Work Order Related List → Validate Outcome as Approved ");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEWorkOrder();
		papPage.validateCPEWOOutcomeStatus(pAOutcomeOptions.get(1));

		Logger("STEP 37: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-18056 RRGN-FG: RGN-FG: Automate SIT_Free Goods_PAP_SF -
	 * Scenario 5 - TC04 - PAP is Initiated manually, Alternate Research Required is
	 * Yes, Research Alternate Coverage Identified is No Coverage outcome is Denied,
	 * Eligibility outcome is Eligible with Non-Medicare Part D.
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SIT_Free Goods_PAP_SF - Scenario 5 - TC04 - PAP is Initiated manually, Alternate Research Required is Yes, Research Alternate Coverage Identified is No, Coverage outcome is Denied, Eligibility outcome is Eligible with Non-Medicare Part D.", enabled = true)
	public void FG40_IC5115_Verify_PAP_is_Initiated_manually_Alternate_Research_Required_is_Yes_Research_Alternate_Coverage_Identified_is_No_Coverage_outcome_is_Denied_Eligibility_outcome_is_Eligible_with_NonMedicarePartD()
			throws Exception {

		String TestCaseNumber = "TC40";
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "K20.0 - Eosinophilic esophagitis", "TRUE", "FALSE" };

		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(4).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("EOE");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("Pre-Requisite STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("Pre-Requisite STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Pre-Requisite STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 5:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-Requisite STEP 6: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 7: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("Pre-Requisite STEP 8:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-Requisite STEP 9:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 10:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 11:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 11.1:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 12:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Pre-Requisite STEP 13: OPen CPE record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		documentsPage.logout();
		Logger("Pre-Requisite STEP 14: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		navigateToURL(CPEURL);

		Logger("Pre-Requisite STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		Logger("Pre-Requisite STEP 24: logout from applilcaton");
		documentsPage.logout();

		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2 :Navigate to CPE object → Click on Start new service button at the top right corner.Select, Service → PAP and click on Next button.Reason → PAP Appeal and click on Save button");
		navigateToURL(CPEURL);
		papPage.checkPAPWOIntiation();
		careProgram.clickOnWorkOrderTask(workOrderName.get(5));

		Logger("STEP 3: Click on PAP from Word order → Validate ‘Alternate Coverage' and 'Confirm PAP Eligibility’ tasks under My Tasks");
		careProgram.checkMainTaskInitiation("Alternate Coverage");
		careProgram.checkMainTaskInitiation("Confirm PAP Eligibility");

		Logger("STEP 4: Click on Alternate Coverage Task → Click on Pre-Check → Select picklist value Patient Uninsured or Patient Underinsured on Coverage Situation Field → Click on Submit Button");
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 5: Again, navigate to PAP WO → Click on Alternate Coverage Task → Click on Research → Select picklist value No on Alternate Coverage Identified? Field → Click on Submit Button");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterResearchDetails(alternateCoverage.get(1), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnSubmitButton();

		Logger("STEP 6: Again, navigate to PAP WO → Click on Confirm PAP Eligibility Task → Click on Eligibility → Select picklist value Yes on all Field under Eligibility Check Section → Click on Next Button");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Confirm PAP Eligibility");
		papPage.clickOnTask("Eligibility");
		papPage.enterEligibilityCheck("Yes");
		quickStartPage.clickOnNextButton();

		Logger("STEP 7: On the Outcome Section validate Eligibility field is populated with Eligible → Select Approved in the Outcome Field → Click on Next Button");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 8: On the Order Details Section select any picklist values for Prescription Field →Select at least one attachment →  Click on Submit Button ");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 9: Go to Related List of the same CPE Record → Open recently created CPEP PAP record from CPEP related List → Validate Enrollment Start Date as Today’s Date and Enrollment End Date as 365 days from Todays Date (For Non-Medicare Part D)");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String papCPE = "PAP - " + careProgramProduct.get(4).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(papCPE);
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate);

		Logger("STEP 10: Go to Related List of the same CPE Record → Go to CPE Work Order Related List → Validate Outcome as Approved");
		papPage.validatePAPoutcomeVal(pAOutcomeOptions.get(1));

		Logger("STEP 11: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-18062 RGN-FG: Automate SIT_Free Goods_PAP_SF - Scenario 3
	 * - TC03 - PAP is initiated when with BV Outcome = Uninsured and alternate
	 * coverage is Denied
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SIT_Free Goods_PAP_SF - Scenario 3 - TC03 - PAP is initiated when with BV Outcome = Uninsured and alternate coverage is Denied", enabled = true)
	public void FG41_IC5107_Verify_PAP_is_initiated_when_with_BV_Outcome_Uninsured_and_alternate_coverage_is_Denied()
			throws Exception {

		String TestCaseNumber = "TC5";
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "TRUE", "FALSE" };

		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("Pre-Requisite STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("Pre-Requisite STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Pre-Requisite STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 5:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-Requisite STEP 6: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 7: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("Pre-Requisite STEP 8:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-Requisite STEP 9:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 10:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 11:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 11.1:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 12:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Pre-Requisite STEP 13: OPen CPE record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		documentsPage.logout();

		Logger("Pre-Requisite STEP 14: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		navigateToURL(CPEURL);

		Logger("Pre-Requisite STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		Logger("Pre-Requisite STEP 24: logout from applilcaton");
		documentsPage.logout();

		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2 :Navigate to CPE object → Click on Start new service button at the top right corner.Select, Service → PAP and click on Next button.Reason → PAP Appeal and click on Save button");
		navigateToURL(CPEURL);
		papPage.checkPAPWOIntiation();
		careProgram.clickOnWorkOrderTask(workOrderName.get(5));

		Logger("STEP 3: Click on PAP from Word order → Validate ‘Alternate Coverage' and 'Confirm PAP Eligibility’ tasks under My Tasks");
		careProgram.checkMainTaskInitiation("Alternate Coverage");
		careProgram.checkMainTaskInitiation("Confirm PAP Eligibility");

		Logger("STEP 4: Click on Alternate Coverage Task → Click on Pre-Check → Select picklist value Patient Uninsured or Patient Underinsured on Coverage Situation Field → Click on Submit Button");
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 5: Again, navigate to PAP WO → Click on Alternate Coverage Task → Click on Research → Select picklist value Yes on Alternate Coverage Identified? Field");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));

		Logger("STEP 6: Fill Payer Name and Payer Phone fields → Click on Submit Button");
		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
				quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(0));
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(cpeName);
		refresh();

		Logger("STEP 7:Again, navigate to PAP WO → Click on Alternate Coverage Task → Click on Communicate Results → Fill values in required fields → Click on Submit Button");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(2));

		quickStartPage.verifyTaskIsLoaded(taskTitle.get(7));
		ArrayList<String> communicateResultsValues = new ArrayList<>(
				Arrays.asList(StatusCheck.get(1), contactMade.get(0), attempts.get(0), attemptOutcome.get(1)));
		papPage.enterCommunicateResultsDetails(communicateResultsValues, attemptOutcome.get(1), attemptOutcome.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 8: Again, navigate to PAP WO → Click on Alternate Coverage Task → Click on Capture Coverage Outcome → Select picklist value Denied on Outcome Field → Click on Submit Button");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(3));
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(8));
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(2));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 9: Again, navigate to PAP WO → Click on Confirm PAP Eligibility Task → Click on Eligibility → Select picklist value Yes on all Field under Eligibility Check Section → Click on Next Button");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Confirm PAP Eligibility");
		papPage.clickOnTask("Eligibility");
		papPage.enterEligibilityCheck("Yes");
		// papPage.enterLISinfo("Eligible");
		quickStartPage.clickOnNextButton();

		Logger("STEP 10: On the Outcome Section validate Eligibility field is populated with Eligible → Select Approved in the Outcome Field → Click on Next Button");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 11: On the Order Details Section select any picklist values for Prescription Field →Select at least one attachment →  Click on Submit Button ");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 12: Go to Related List of the same CPE Record → Open recently created CPEP PAP record from CPEP related List → Validate Enrollment Start Date as Today’s Date and Enrollment End Date as 365 days from Todays Date (For Non-Medicare Part D)");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String papCPE = "PAP - " + careProgramProduct.get(2).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(papCPE);
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate);

		Logger("STEP 13: Go to Related List of the same CPE Record → Go to CPE Work Order Related List → Validate Outcome as Approved");
		papPage.validatePAPoutcomeVal(pAOutcomeOptions.get(1));

		Logger("STEP 14: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-5636 -SIT_Free Goods_QuickStart_SF - Scenario 3 -
	 * TC01 - Initiate QuickStart work order with start new service button.
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "TC01 - Initiate QuickStart work order with start new service button.", enabled = true)
	public void FG42_IC5636_SIT_Free_Goods_QuickStart_Initiate_QuickStart_work_order_with_start_new_service_button()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC24";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax", "Diagnosis Code",
				"DUPIXENT MyWay", "Preferred Specialty Pharmacy", "Office Fax" };
		String columnValue[] = { "Automation Correspondence SP", "(954) 312-1432", "(166) 254-1171",
				"L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE", "(166) 254-1171" };

		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 15:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 16: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String qsUrl = getCurrentPageURL();

		Logger("STEP 17: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 18: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 19: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		 homeportalPage.closeTabs();
		documentsPage.navigate(qsUrl);
		Thread.sleep(2000);

		Logger("STEP 22: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 23: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 24: User will see two fields: 1. Start Service : Pick the value as Quick Start 2. Reason: 'Received QS Rx'");
		iapPage.verifyServiceTitle();
		papPage.selectService(service.get(5));
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(quickStartReason.get(0));

		Logger("STEP 25: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 26: Navigate to Quick Start and verify flow has initiated");
		refresh();
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();

		Logger("STEP 27: Click on Enrollment task");
		quickStartPage.clickOnTask();

		Logger("STEP 28: Enter Eligibility Criteria and click on Next button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 29: Enter Eligibility outcome and click on next button ");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 30: Enter order details and click on submit button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		navigateToUrl(qsUrl);
		refresh();

		Logger("STEP 31: Click on quick start button and verify task compltion status");
		quickStartPage.clickOnQuickStart();
		quickStartPage.checkQuickStartTaskComplition();

		refresh();

		Logger("STEP 32: Now navigate to the CPEP record list in Related tab of CPE and validate that a new CPEP record is created for QuickStart with Outcome as Approved.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String quickStartCPE = "QuickStart - " + careProgramProduct.get(2).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(quickStartCPE);
		quickStartPage.validateOutcome(quickStartOutcome.get(0));

		navigateToUrl(qsUrl);
		refresh();

		Logger("STEP 33: Click on relatad tab and verify to retrive order number of CPE Record");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		String orderNumber = quickStartPage.getOrderNumber();

		Logger("STEP 34: Navigate to order Page");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(8), DocumentPage.class);

		Logger("STEP 35: Verify to Search abd click on Order Number");
		quickStartPage.searchOrder(orderNumber);
		quickStartPage.clickOnRecord(orderNumber);

		Logger("STEP 36:validate that the Order record is created on the patient’s name.");
		quickStartPage.verifyPatientName(ExcelTestData.get(patientName));

		Logger("STEP 37: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-18064 RGN-FG: Automate SIT_Free Goods_PAP_SF - Scenario 2
	 * - TC04 PAP is Initiated manually and alternate coverage is Denied
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SIT_Free Goods_PAP_SF - Scenario 2 - TC04 - PAP is Initiated manually and alternate coverage is Denied", enabled = true)
	public void FG43_IC5105_Validate_PAP_is_Initiated_manually_and_alternate_coverage_is_Denied() throws Exception {

		String TestCaseNumber = "TC50";
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "DUPIXENT MyWay", "Preferred Specialty Pharmacy","Diagnosis Code" };
		String columnValue[] = { "TRUE", "FALSE","L20.9 - Atopic dermatitis, unspecified" };

		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

			Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("Pre-Requisite STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("Pre-Requisite STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Pre-Requisite STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 5:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
		Logger("Pre-Requisite STEP 6: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 7: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("Pre-Requisite STEP 8:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-Requisite STEP 9:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 10:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 11:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 11.1:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 12:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Pre-Requisite STEP 13: OPen CPE record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		documentsPage.logout();

		Logger("Pre-Requisite STEP 14: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		navigateToURL(CPEURL);

		Logger("Pre-Requisite STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		Logger("Pre-Requisite STEP 24: logout from applilcaton");
		documentsPage.logout();

		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2 :Navigate to CPE object → Click on Start new service button at the top right corner.Select, Service → PAP and click on Next button.Reason → PAP Appeal and click on Save button");
		navigateToURL(CPEURL);
		papPage.checkPAPWOIntiation();
		careProgram.clickOnWorkOrderTask(workOrderName.get(5));

		Logger("STEP 3: Click on PAP from Word order → Validate ‘Alternate Coverage' and 'Confirm PAP Eligibility’ tasks under My Tasks");
		careProgram.checkMainTaskInitiation("Alternate Coverage");
		careProgram.checkMainTaskInitiation("Confirm PAP Eligibility");

		Logger("STEP 4: Click on Alternate Coverage Task → Click on Pre-Check → Select picklist value Patient Uninsured or Patient Underinsured on Coverage Situation Field → Click on Submit Button");
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 5: Again, navigate to PAP WO → Click on Alternate Coverage Task → Click on Research → Select picklist value Yes on Alternate Coverage Identified? Field");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));

		Logger("STEP 6: Fill Payer Name and Payer Phone fields → Click on Submit Button");
		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(9));
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 9: Again, navigate to PAP WO → Click on Confirm PAP Eligibility Task → Click on Eligibility → Select picklist value Yes on all Field under Eligibility Check Section → Click on Next Button");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Confirm PAP Eligibility");
		papPage.clickOnTask("Eligibility");

		Logger("STEP 10: On the Outcome Section validate Eligibility field is populated with Eligible → Select Approved in the Outcome Field → Click on Next Button");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 11: On the Order Details Section select any picklist values for Prescription Field →Select at least one attachment →  Click on Submit Button ");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 12: Go to Related List of the same CPE Record → Open recently created CPEP PAP record from CPEP related List → Validate Enrollment Start Date as Today’s Date and Enrollment End Date as 365 days from Todays Date (For Non-Medicare Part D)");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String papCPE = "PAP - " + careProgramProduct.get(2).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(papCPE);
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate);

		Logger("STEP 13: Go to Related List of the same CPE Record → Go to CPE Work Order Related List → Validate Outcome as Approved");
		papPage.validatePAPoutcomeVal(pAOutcomeOptions.get(1));

		Logger("STEP 14: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * 
	 * @author Tejal PatientEnrollment_Prerequisites_RGN_FG_PAP
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Patient Enrollment Prerequisites", enabled = true)
	public String PatientEnrollment_Prerequisites_RGN_FG_PAP(String testcaseNumber) throws Exception {
		String TestCaseNumber = testcaseNumber;
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "DUPIXENT MyWay", "Preferred Specialty Pharmacy", "Diagnosis Code" };
		String columnValue[] = { "TRUE", "FALSE", "L20.9 - Atopic dermatitis, unspecified" };

		synchronized(excelDataUpdate){
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("Pre-Requisite STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("Pre-Requisite STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("Pre-Requisite STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 5:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(2));

		Logger("Pre-Requisite STEP 6: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 7: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		Logger("Pre-Requisite STEP 8:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 9:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 10:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 11:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 11.1:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 12:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Pre-Requisite STEP 13: OPen CPE record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		documentsPage.logout();
		return CPEURL;

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-Free Goods_PAP_SF - Scenario 5 - TC02 - PAP is initiated
	 * with BV Outcome = Not Covered ICARE-18058
	 * 
	 * @author Tejal
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Free Goods_PAP_SF - Scenario 5 - TC02 - PAP is initiated with BV Outcome = Not Covered", enabled = true)
	public void FG44_IC5113_Free_Goods_PAP_SF_TC02_PAP_is_initiated_with_BV_Outcome_Not_Covered() throws Exception {
		String TestCaseNumber = "TC44";

		// Pre-requisites
		String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite STEP 14: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		homeportalPage.closeTabs();
		navigateToURL(CPEURL);

		Logger("Pre-Requisite STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(1), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		Logger("Pre-Requisite STEP 24: logout from applilcaton");
		documentsPage.logout();

		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2 :Navigate to CPE object → check PAP WO already initiated");
		homeportalPage.closeTabs();
		navigateToURL(CPEURL);
		papPage.checkPAPWOIntiation();
		
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));


		Logger("STEP 12: Go to Related List of the same CPE Record → Open recently created CPEP PAP record from CPEP related List → Validate Enrollment Start Date as Today’s Date and Enrollment End Date as 365 days from Todays Date (For Non-Medicare Part D)");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		papPage.clickOnPAPCpe();
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate);

		Logger("STEP 13: Go to Related List of the same CPE Record → Go to CPE Work Order Related List → Validate Outcome as Approved");
		papPage.validatePAPoutcomeVal(pAOutcomeOptions.get(1));
		Logger("STEP 14: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-Free Goods_PAP_SF - Scenario 5 - TC02 - PAP is Initiated
	 * manually and alternate coverage is Denied
	 * 
	 * @author Tejal
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "SIT_Free Goods_PAP_SF - Scenario 3 - TC04 - PAP is Initiated manually and alternate coverage is Denied", enabled = true)
	public void FG45_IC_5108_Free_Goods_PAP_SF_TC02_PAP_is_initiated_manually_and_alternate_coverage_is_Denied()
			throws Exception {
		String TestCaseNumber = "TC45";

		// Pre-requisites
		String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(CPEURL);
		Thread.sleep(2000);
		Logger("STEP 41 :PAP work order initialization.");
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason("PAP Appeal");
		
		Logger("STEP 42 : Click on save and refresh the page");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(0));
		Logger("STEP 6: Fill Payer Name and Payer Phone fields → Click on Submit Button");
		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(2));
		papPage.enterDetails(paStatus.get(1), payerContact.get(0), attempts.get(0), attempt.get(0),
				attemptOutcomes.get(1), attempt.get(1), attemptOutcomes.get(1), attempt.get(2), attemptOutcomes.get(0));
		quickStartPage.clickOnSubmitButton();
		
		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(3));
		papPage.enterCoverageOutcome(iapoutcome.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();

		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 12: Go to Related List of the same CPE Record → Open recently created CPEP PAP record from CPEP related List → Validate Enrollment Start Date as Today’s Date and Enrollment End Date as 365 days from Todays Date (For Non-Medicare Part D)");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		papPage.clickOnPAPCpe();
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate);

		Logger("STEP 13: Go to Related List of the same CPE Record → Go to CPE Work Order Related List → Validate Outcome as Approved");
		papPage.validatePAPoutcomeVal(pAOutcomeOptions.get(1));

		Logger("STEP 14: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-18065 SIT_Free Goods_PAP_SF - Scenario 2 - TC03 - PAP is
	 * initiated when with BV Outcome = Uninsured and alternate coverage is denied
	 * 
	 * @author Tejal
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SIT_Free Goods_PAP_SF - Scenario 2 - TC03 - PAP is initiated when with BV Outcome = Uninsured and alternate coverage is denied", enabled = true)
	public void FG46_IC5103_Validate_PAP_is_Initiated_when_Bv_outcome_Uninsured_Alternate_Coverage_Denied()
			throws Exception {

		String TestCaseNumber = "TC4";

		// Pre-requisites
		String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite STEP 14: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		navigateToURL(CPEURL);

		Logger("Pre-Requisite STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		Logger("Pre-Requisite STEP 24: logout from applilcaton");
		documentsPage.logout();

		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2 :Navigate to CPE object → Click on Start new service button at the top right corner.Select, Service → PAP and click on Next button.Reason → PAP Appeal and click on Save button");
		homeportalPage.closeTabs();
		
		navigateToURL(CPEURL);
		papPage.checkPAPWOIntiation();
		
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(0));
		Logger("STEP 6: Fill Payer Name and Payer Phone fields → Click on Submit Button");
		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(2));
		papPage.enterDetails(paStatus.get(1), payerContact.get(0), attempts.get(0), attempt.get(0),
				attemptOutcomes.get(1), attempt.get(1), attemptOutcomes.get(1), attempt.get(2), attemptOutcomes.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(3));
		papPage.enterCoverageOutcome(iapoutcome.get(1));

     	quickStartPage.clickOnSubmitButton();
		refresh();

		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();

		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 12: Go to Related List of the same CPE Record → Open recently created CPEP PAP record from CPEP related List → Validate Enrollment Start Date as Today’s Date and Enrollment End Date as 365 days from Todays Date (For Non-Medicare Part D)");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		papPage.clickOnPAPCpe();
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate);

		Logger("STEP 13: Go to Related List of the same CPE Record → Go to CPE Work Order Related List → Validate Outcome as Approved");
		papPage.validatePAPoutcomeVal(pAOutcomeOptions.get(1));
		Logger("STEP 14: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * *
	 * ====================================================================================
	 * ================================== * Test Case Id: ICARE-18069
	 * SIT_FreeGoods_PAP_SF - Scenario 8 - TC03 -PAP is initiated with BV Outcome =
	 * Not Covered with alternate research required * @author Tejal *
	 * =======================================================================================
	 * ==============================
	 */
	@Test
	public void FG47_IC18069_5073_PAP_is_initiated_with_BVOutcome_NotCovered_with_alternate_research_required()
			throws Exception {
		String TestCaseNumber = "TC47";

		// Pre-requisites
	    String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite STEP 14: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		navigateToURL(CPEURL);

      Logger("Pre-Requisite STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(1), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		Logger("Pre-Requisite STEP 24: logout from applilcaton");
		documentsPage.logout();

		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();
		navigateToURL(CPEURL);
		papPage.checkPAPWOIntiation();
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));

		papPage.validatePatientInfoFieldsAreDisable(false);
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(2), planType.get(0), "", ""));
		papPage.verifyPatientInformationDetails(expectedValues);

		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheckNo();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(1));
		papPage.enterCoverageOutcomeReason("Missing Information");
		quickStartPage.clickOnNextButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEWorkOrder();
		String[] workOrders = { "PAP" };
		String expectedStatus = "Completed";
		String expectedOutcome = "Denied";

		papPage.checkCPEWorkOrderData(Arrays.asList(workOrders), expectedStatus, expectedOutcome);
		Logger("STEP 14: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * *
	 * ====================================================================================
	 * ================================== * Test Case Id: ICARE-18070
	 * SIT_FreeGoods_PAP_SF - Scenario 8 - TC03 -PAP is initiated with BV Outcome =
	 * Uninsured with alternate research required * @author Tejal *
	 * =======================================================================================
	 * ==============================
	 */
	@Test
	public void FG48_IC18070_5072_PAP_is_initiated_with_BVOutcome_NotCovered_with_alternate_research_required()
			throws Exception {

		String TestCaseNumber = "TC24";

		// Pre-requisites
		String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite STEP 14: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		navigateToURL(CPEURL);

		Logger("Pre-Requisite STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		Logger("Pre-Requisite STEP 24: logout from applilcaton");
		documentsPage.logout();

		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();
		navigateToURL(CPEURL);
		papPage.checkPAPWOIntiation();
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));

		papPage.validatePatientInfoFieldsAreDisable(false);
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(4), planType.get(0), "", ""));
		papPage.verifyPatientInformationDetails(expectedValues);

		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheckNo();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(1));
		papPage.enterCoverageOutcomeReason("Missing Information");
		quickStartPage.clickOnNextButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEWorkOrder();
		String[] workOrders = { "PAP" };
		String expectedStatus = "Completed";
		String expectedOutcome = "Denied";

		papPage.checkCPEWorkOrderData(Arrays.asList(workOrders), expectedStatus, expectedOutcome);
		Logger("STEP 14: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * *
	 * ====================================================================================
	 * ================================== * Test Case Id: ICARE-18072
	 * SIT_FreeGoods_PAP_SF - Scenario 8 - TC03 -PAP is initiated with BV Outcome =
	 * Uninsured and Eligibility is confirmed with Non-Medicare Part D * @author
	 * Tejal *
	 * =======================================================================================
	 * ==============================
	 */
	@Test
	public void FG49_IC18072_5058_PAP_is_initiated_with_BVOutcome_Uninsured_with_alternate_research_required()
			throws Exception {

		String TestCaseNumber = "TC49";

		// Pre-requisites
	String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite STEP 14: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		navigateToURL(CPEURL);

		Logger("Pre-Requisite STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(4),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		Logger("Pre-Requisite STEP 24: logout from applilcaton");
		documentsPage.logout();

		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();
		navigateToURL(CPEURL);
		
		papPage.checkPAPWOIntiation();
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));

		papPage.validatePatientInfoFieldsAreDisable(false);
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(4), "","", ""));
		papPage.verifyPatientInformationDetails(expectedValues);

		papPage.enterCoverageSituation(coverageSituation.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		Logger("STEP 26: Open the newly created PAP CPEP record and Validate the Following \"Enrollment Start Date\" auto-populated with the current date and \"Enrollment End Date\" auto-populated for plan type= Medicare Part D, as start date + 365 days");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		papPage.clickOnPAPCpe();
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate);
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		careProgram.clickOnOrderNumber(service.get(1));
		papPage.validatePAPCPEPfield();
		documentsPage.logout();

	}

	/**
	 * *
	 * ====================================================================================
	 * ================================== * Test Case Id: ICARE-18073
	 * SIT_FreeGoods_PAP_SF PAP is Initiated manually, alternate research required
	 * is No, eligibility outcome is eligible with Medicare part D * @author Tejal *
	 * =======================================================================================
	 * ==============================
	 */
	@Test
	public void FG50_IC18073_5054_PAP_is_initiated_manually_with_alternate_research_No_MedicarepartD()
			throws Exception {

		String TestCaseNumber = "TC5";

		// Pre-requisites
		String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite STEP 14: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		navigateToURL(CPEURL);

		Logger("Pre-Requisite STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(2),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(0), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		Logger("Pre-Requisite STEP 24: logout from applilcaton");
		documentsPage.logout();

		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();
		navigateToURL(CPEURL);
		Logger("STEP 23: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 24: User will see two fields: 1. Start Service : Pick the value as \"PAP\" 2. Reason: 'Med D Annual Reverification'");
		iapPage.verifyServiceTitle();
		papPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(1));
		missingInformatioPage.clickOnSaveButton();

		refresh();
		papPage.checkPAPWOIntiation();
		Logger("STEP 25: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));

		papPage.validatePatientInfoFieldsAreDisable(false);
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(0), planType.get(2), "", ""));
		papPage.verifyPatientInformationDetails(expectedValues);

		papPage.enterCoverageSituation(coverageSituation.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();

		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		Logger("STEP 26: Open the newly created PAP CPEP record and Validate the Following \"Enrollment Start Date\" auto-populated with the current date and \"Enrollment End Date\" auto-populated for plan type= Medicare Part D, as start date + 365 days");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		papPage.clickOnPAPCpe();		
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate);
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		careProgram.clickOnOrderNumber(service.get(1));
		papPage.validatePAPCPEPfield();
		documentsPage.logout();

	}

	/**
	 * *
	 * ====================================================================================
	 * ================================== * Test Case Id: ICARE-18069
	 * SIT_FreeGoods_PAP_SF - Scenario 8 - TC03 -PAP is initiated with BV Outcome =
	 * Not Covered with alternate research required * @author Tejal *
	 * =======================================================================================
	 * ==============================
	 */
	@Test
	public void FG51_IC18074_5053_PAP_is_initiated_Uninsured_with_alternate_research_No_MedicarepartD()
			throws Exception {

		String TestCaseNumber = "TC51";

		// Pre-requisites
		String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite STEP 14: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		navigateToURL(CPEURL);

		Logger("Pre-Requisite STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(2),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(4), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		Logger("Pre-Requisite STEP 24: logout from applilcaton");
		documentsPage.logout();

		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();
		navigateToURL(CPEURL);

		papPage.checkPAPWOIntiation();
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));

		papPage.validatePatientInfoFieldsAreDisable(false);
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(4), planType.get(2), "", ""));
		papPage.verifyPatientInformationDetails(expectedValues);

		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();
		refresh();

		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		papPage.enterLISinfo(eligibilityOutcome.get(2));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));

		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate);
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		careProgram.clickOnViewAll("Orders");
		careProgram.clickOnOrderNumber(service.get(1));
		papPage.validatePAPCPEPfield();
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-5106 SIT_Free Goods_PAP_SF - Scenario 3 - TC02 -
	 * PAP is initiated with BV Outcome = Not Covered and alternate coverage is
	 * Denied
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "TC02 - PAP is initiated with BV Outcome = Not Covered and alternate coverage is Denied", enabled = true)
	public void FG52_IC5106_TC02_PAP_is_initiated_with_BV_Outcome_Not_Covered_and_alternate_coverage_is_Denied()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC52";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax", "Diagnosis Code",
				"DUPIXENT MyWay", "Preferred Specialty Pharmacy", "Office Fax" };
		String columnValue[] = { "Automation Correspondence SP", "(954) 312-1432", "(166) 254-1171",
				"L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE", "(166) 254-1171" };
		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		Logger("STEP 15: OPen CPE record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));

		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
		String CPEURL = getCurrentPageURL();

		documentsPage.logout();

		Logger(" STEP 16: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		navigateToURL(CPEURL);

		Logger("Pre-Requisite STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(1), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		refresh();

		Logger(" STEP 18: logout from applilcaton");
		documentsPage.logout();
		
		
		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();
		navigateToURL(CPEURL);
		papPage.checkPAPWOIntiation();
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));

		papPage.validatePatientInfoFieldsAreDisable(false);
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(2),planType.get(0),"0" ,"","Yes" , ""));
		papPage.verifyPatientInformationDetails(expectedValues);

		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheckNo();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(1));
		papPage.enterCoverageOutcomeReason("Missing Information");
		quickStartPage.clickOnNextButton();
		docMgmt.selectItemsToSend(papItemsToSend.get(1));
		quickStartPage.clickOnNextButton();
		Thread.sleep(3000);
		quickStartPage.clickOnNextButton();
		Logger("STEP 4: Generate Document(s) section should be displayed with the document processing");
		docMgmt.clickSendButtonUntilFinish();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEWorkOrder();
		String[] workOrders = { "PAP" };
		String expectedStatus = "Completed";
		String expectedOutcome = "Denied";

		papPage.checkCPEWorkOrderData(Arrays.asList(workOrders), expectedStatus, expectedOutcome);
		
		Logger("STEP 23: Navigate to PAP CPE Record");		
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String PAPCPE = "PAP - " + careProgramProduct.get(2).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(PAPCPE);

		Logger("STEP 24: Verify Enrollment start and end date");
		quickStartPage.validateEnrollmentStartEndDate();
		
		Logger("STEP 14: User Logouts the Application.");
		documentsPage.logout();

	}

	/**
	 * *
	 * ====================================================================================
	 * ================================== * Test Case Id: ICARE-18069
	 * SIT_FreeGoods_PAP_SF - Scenario 8 - TC03 -PAP is initiated with BV Outcome =
	 * Not Covered with alternate research required * @author Tejal *
	 * =======================================================================================
	 * ==============================
	 */
	@Test(description = "TC03 - PAP is initiated with BV Outcome = Not Covered and Eligibility is confirmed with Non-Medicare Part D", enabled = true)
	public void FG53_IC5060_TC03_PAP_is_initiated_with_BV_Outcome_Not_Covered_and_Eligibility_is_confirmed_with_Non_Medicare_Part_D()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC53";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax", "Diagnosis Code",
				"DUPIXENT MyWay", "Preferred Specialty Pharmacy", "Office Fax" };
		String columnValue[] = { "Automation Correspondence SP", "(954) 312-1432", "(166) 254-1171",
				"L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE", "(166) 254-1171" };
		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		Logger("STEP 15: OPen CPE record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));

		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
		String CPEURL = getCurrentPageURL();

		documentsPage.logout();

		Logger(" STEP 16: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		navigateToURL(CPEURL);

		Logger("STEP 17: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(1), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		refresh();

		Logger(" STEP 17: logout from applilcaton");
		documentsPage.logout();

		Logger("STEP 18: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 19 :Navigate to CPE object");
		navigateToURL(CPEURL);
		refresh();

		Logger("STEP 20: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();
		papPage.clickOnTask(papSubTaskNames.get(0));

		Logger("STEP 21: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all PAP critical fields are populated");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 22: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 23: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(0));
		papPage.verifyAlternateResearch(alternateResearch.get(0));
		quickStartPage.clickOnSubmitButton();
		papPage.clickRefresh();

		Logger("STEP 24: Enter Research details");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterResearchDetails(alternateResearch.get(0),
				ExcelTestData.get(PayerName),
				ExcelTestData.get(rxPhone));
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		papPage.clickRefresh();
		

		Logger("STEP 25: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheckEligibileforLIS(alternateResearch.get(0));
		quickStartPage.clickOnNextButton();

		Logger("STEP 26: In \"Outcome\" Task Populate the \"Outcome\" as approved.");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 27: Enter Order Details");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		navigateToUrl(CPEURL);
		refresh();

		Logger("STEP 28: Now click on the related tab and validate that the PAP Enrollment record is visible on the related list of CPE → Click on the record.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String papCPE = "PAP - " + careProgramProduct.get(2).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(papCPE);

		Logger("STEP 29: Go to Related List of the same CPE Record → Open recently created CPEP PAP record from CPEP related List → Validate Enrollment Start Date as Today’s Date and Enrollment End Date as auto-populated for plan type= non-Medicare Part D, as current date + 365 days.");

		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate);
		navigateToUrl(CPEURL);
		refresh();

		Logger("STEP 30: From App Launcher search and open Orders >> Validate that Order is created for PAP");

		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(8), DocumentPage.class);
		papPage.VerifyPAPOrder();

		Logger("STEP 31: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-18075 -R4-FG: Automate SIT_FreeGoods_PAP_SF -
	 * Scenario 6 TC01 - PAP is initiated with BV Outcome = Not Covered, alternate
	 * research required is No, eligibility outcome is eligible with Medicare part D
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SIT_FreeGoods_PAP_SF - Scenario 6 - TC01 - PAP is initiated with BV Outcome = Not Covered, alternate research required is No, eligibility outcome is eligible with Medicare part D", enabled = true)
	public void FG54IC5052_Validate_PAP_is_Initiated_with_BV_outcome_As_NotCovered_alternate_research_required_is_No_eligibility_outcome_is_eligible_with_MedicarepartD()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC50";
		String EXURL;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "J33.0 - Polyp of nasal cavity", "TRUE", "FALSE" };

		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(0).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Nasal Polyps");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 12:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Pre-Requisite STEP 13: OPen CPE record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		documentsPage.logout();
		Logger("Pre-Requisite STEP 14: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		navigateToURL(CPEURL);

		Logger("Pre-Requisite STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		// bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(2),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(1), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();

		Logger("Pre-Requisite STEP 24: logout from applilcaton");
		documentsPage.logout();

		Logger("STEP 1: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2 :Validate PAP WO is initiated. Click on PAP WO");
		navigateToURL(CPEURL);
		papPage.checkPAPWOIntiation();
		careProgram.clickOnWorkOrderTask(workOrderName.get(5));

		Logger("STEP 3: From PAP Open Alternate Coverage Task >> Open Pre-check subtask >> Validate below mentioned fields are populated");
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));

		papPage.validatePatientInfoFieldsAreDisable(false);
		ArrayList<String> expectedValues = new ArrayList<>(
				Arrays.asList(outComeOptions.get(2), "0", "Medicare Part D", "", "Yes", ""));
		papPage.verifyPatientInformationDetails(expectedValues);

		Logger("STEP 4: While on the same Screen validate a new section with title Outcome (editable section) have below mentioned fields.Select value as Med Part D - Financial Hardship, 2. Alternate Research Required? (Picklist) (Yes/No) Alternate Research is auto populated as \"No\" ");
		papPage.enterCoverageSituation(coverageSituation.get(2));
		papPage.verifyAlternateResearch(alternateResearch.get(1));
		quickStartPage.clickOnSubmitButton();

		Logger("STEP 5: From Confirm PAP Eligibility task >>open \"Eligibility \" Sub task >>Validate below mentioned fields are populated");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask("Confirm PAP Eligibility");
		papPage.clickOnTask("Eligibility");
		ArrayList<String> expectedValues1 = new ArrayList<>(
				Arrays.asList(outComeOptions.get(2), "0", "Medicare Part D", "", "Yes", ""));
		papPage.verifyPatientInformationDetails(expectedValues1);
		papPage.verifyAndenterEligibilityCheck(alternateResearch.get(0));
		quickStartPage.clickOnNextButton();

		Logger("STEP 6: In \"Outcome\" Screen Populate the \"Outcome\" as Approved.Click on next.");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 7: On the Order Details Section select any picklist values for Prescription Field →Select at least one attachment →  Click on Submit Button ");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 8: Now Navigate back to CPE related list >> open CPEP related list>>");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String papCPE = "PAP - " + careProgramProduct.get(0).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(papCPE);

		Logger("STEP 9: Open the newly created PAP CPEP record and Validate the Following \"Enrollment Start Date\" auto-populated with the current date");
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);

		Logger("STEP 9.1: \"Enrollment End Date\" auto-populated for plan type= Medicare Part D, as end of the current calendar year (Ex: December 31, 2024)");
		String expectedEndDate = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate);

		Logger("STEP 10: open Orders >> Validate that Order is created for PAP");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll("Orders");
		iapPage.verifyOrderCreated("PAP");

		Logger("STEP 10: Logout from the application");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE 5001 - R4-FG: Automate SIT_FreeGoods_PAP_SF - Scenario 7 -
	 * TC01 - PAP is initiated manually and alternate coverage Eligibility is
	 * confirmed with Non-Medicare Part D
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "TC01 -PAP is initiated manually and alternate coverage Eligibility is confirmed with Non-Medicare Part D", enabled = true)
	public void FG55_IC5001_TC01_PAP_is_initiated_manually_and_alternate_coverage_Eligibility_is_confirmed_with_Non_Medicare_Part_D()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC5";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Specialty Pharmacy Name", "Pharmacy Phone", "Pharmacy Fax", "Diagnosis Code",
				"DUPIXENT MyWay", "Preferred Specialty Pharmacy", "Office Fax" };
		String columnValue[] = { "Automation Correspondence SP", "(954) 312-1432", "(166) 254-1171",
				"L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE", "(166) 254-1171" };

		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		Logger("STEP 15: OPen CPE record");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));

		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
		String CPEURL = getCurrentPageURL();

		documentsPage.logout();

		Logger(" STEP 16: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		navigateToURL(CPEURL);

		Logger("STEP 17: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		// bvPage.enterCallInformationSection();
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(4),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(1), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		refresh();

		Logger("STEP 17: logout from applilcaton");
		documentsPage.logout();

		Logger("STEP 18: Login to iCare Connect App with Case Manager User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 19 :Navigate to CPE object");
		navigateToURL(CPEURL);
		refresh();

		Logger("STEP 20: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 21: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 22: User will see two fields: 1. Start Service : Pick the value as \"PAP\" 2. Reason: 'PA Appeal Denied'");
		iapPage.verifyServiceTitle();
		papPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(1));

		Logger("STEP 23: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 24: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();
		papPage.clickOnTask(papSubTaskNames.get(0));

		Logger("STEP 25: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all PAP critical fields are populated");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));
		papPage.validatePatientInfoFieldsAreDisable(false);

		Logger("STEP 26: While on the same Screen validate a new section with title Outcome (editable section) have all the fields");
		papPage.validateCoverageSituationIsEnable(true);
		papPage.validateAlternateResearchIsDisable(false);

		Logger("STEP 27: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(2));
		papPage.verifyAlternateResearch(alternateResearch.get(1));
		quickStartPage.clickOnSubmitButton();
		papPage.clickRefresh();

		Logger("STEP 28: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.verifyAndenterEligibilityCheck(alternateResearch.get(0));
		quickStartPage.clickOnNextButton();

		Logger("STEP 29: In \"Outcome\" Task Populate the \"Outcome\" as approved.");
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 30: Enter Order Details");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.verifyOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		navigateToUrl(CPEURL);
		refresh();

		Logger("STEP 31: Now click on the related tab and validate that the PAP Enrollment record is visible on the related list of CPE → Click on the record.");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		String papCPE = "PAP - " + careProgramProduct.get(2).split(" -")[0];
		quickStartPage.navigateToQuickStartCPE(papCPE);

		Logger("STEP 29: Go to Related List of the same CPE Record → Open recently created CPEP PAP record from CPEP related List → Validate Enrollment Start Date as Today’s Date and Enrollment End Date as auto-populated for plan type= non-Medicare Part D, as current date + 365 days.");
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getLastDayOfYear();
				//getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate);

		Logger("STEP 33: From App Launcher search and open Orders >> Validate that Order is created for PAP");

		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(8), DocumentPage.class);
		papPage.VerifyPAPOrder();

		Logger("STEP 34: User Logout the Application.");
		documentsPage.logout();

	}
/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-20890-Validate CPEP Date revision when Older CPEP record does not exist
	 * 
	 * @author Tejal
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Validate CPEP Date revision when Older CPEP record does not exist", enabled = true)
	public void FG57_IC16828_Free_Goods_PAP_SF_TC02_Validate_CPEP_Date_revision_when_Older_CPEPrecord_does_not_exist()
			throws Exception {
		
		String cpeUrl = null;
		String TestCaseNumber = "TC21";

		// Prerequisites
		cpeUrl = BenefitVerificationWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		//PM User coverage as-Med Part D - Financial Hardship
		Logger("STEP 1::Login to the QA_SIT Org as 'PM Manager'.");
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		homeportalPage.closeTabs();
		
		
//		 documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7),
//					DocumentPage.class);
//		assessmentTasksPage.verifyRecentlyViewList();
//		careProgram.navigateToAllCPE();
//		documentsPage.searchDocument("Automation");
//		missingInformatioPage.searchAndOpenRecord();
		
//		Thread.sleep(2000);
//		Logger("STEP 41 :PAP work order initialization.");
//		papPage.clickOnStartNewService();
//		papPage.selectService("PAP");
//		
//		
//		
//		//----------
		Logger("STEP 2: Open a CPE record");
		navigateToUrl(cpeUrl);
		Thread.sleep(2000);
		
		Logger("STEP 3 :PAP work order initialization.");
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
        missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(2));
        Logger("STEP 4: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		Logger("STEP 5: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
	//	papPage.enterLISinfo(eligibilityOutcome.get(2));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
	    missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
        accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();
		String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate);
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
	    documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7),
				DocumentPage.class);

	    //Pm user coverage as -Med Part D - Potentially LIS
//		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		careProgram.navigateToAllCPE();
//		documentsPage.searchDocument("Automation");
//		missingInformatioPage.searchAndOpenRecord();
		
		Logger("STEP 41 :PAP work order initialization.");
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		missingInformatioPage.clickNextButton();
		papPage.selectReason(papOptions.get(2));
		Logger("STEP 19: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(3));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(5));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		missingInformatioPage.clickNextButton();
        papPage.enterCaptureCoverageOutcome(captureCoverageOutcomes.get(0)); 
	    quickStartPage.clickOnSubmitButton();
		refresh();
		
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
	//	papPage.enterLISinfo(eligibilityOutcome.get(2));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
	    missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
        accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();
		String expectedStartDate1 = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate1);
		String expectedEndDate1 = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate1);
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
		Logger("STEP 16: Log out from application");
		documentsPage.logout();
	
		
		//BO User coverage as - Med Part D - Financial Hardship
		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'BOps Manager'.");
		homeportalPage = loginPage.userLogin(BOUsername, UserPassword);
		homeportalPage.closeTabs();
		
		navigateToUrl(cpeUrl);

		
//		Logger("STEP 2: Open a CPE record");
//		
//		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7),
//				DocumentPage.class);
//
//		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		careProgram.navigateToAllCPE();
//		documentsPage.searchDocument("Automation");
//		missingInformatioPage.searchAndOpenRecord();
		
		Logger("STEP 41 :PAP work order initialization.");
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
        missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		missingInformatioPage.clickNextButton();
		papPage.selectReason(papOptions.get(2));
        Logger("STEP 19: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
	//	iapPage.finishButtonIfPresent();
		refresh();
		
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
	//	papPage.enterLISinfo(eligibilityOutcome.get(2));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
	    missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
        accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();
		String expectedStartDate2 = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate2);
		String expectedEndDate2 = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate2);
		
		documentsPage.logout();

		Logger("Login as Admin User.");
		homeportalPage = loginPage.userLogin(BOUsername, UserPassword);
		homeportalPage.closeTabs();
		
		navigateToUrl(cpeUrl);
		
		
//		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
//	    documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7),
//				DocumentPage.class);
//
//		Logger("STEP 16:  Verify recently view list is displayed and search the CPE Record.");
//		assessmentTasksPage.verifyRecentlyViewList();
//		careProgram.navigateToAllCPE();
//		documentsPage.searchDocument("Automation");
//		missingInformatioPage.searchAndOpenRecord();
		
		 //BO USER coverage situation as - Med Part D - Potentially LIS
		Logger("STEP 41 :PAP work order initialization.");
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		missingInformatioPage.clickNextButton();
		papPage.selectReason(papOptions.get(2));
		Logger("STEP 19: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		iapPage.finishButtonIfPresent();
		refresh();
		
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(3));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(5));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		missingInformatioPage.clickNextButton();
        papPage.enterCaptureCoverageOutcome(captureCoverageOutcomes.get(0));
	    quickStartPage.clickOnSubmitButton();
		refresh();
		
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
	//	papPage.enterLISinfo(eligibilityOutcome.get(2));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
	    missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
        accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();
		String expectedStartDate3 = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate3);
		String expectedEndDate3 = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate3);
		
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
		
		Logger("STEP 16: Log out from application");
		documentsPage.logout();
	}

	/**
	 * Test Case Id:iCare-12507-SIT-TC01-Verify the PAP Research and Capture 
	 * Outcome Task
	 * 
	 * @author Sonica
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "ICARE-27020 iCare-12507-SIT-TC01-Verify the PAP Research and Capture Outcome Task", enabled = true)
	public void FG59_IC19145_Verify_the_PAP_Research_and_Capture_Outcome_Task()
			throws Exception {

		String cpeUrl = null;
		String TestCaseNumber = "TC23";

		// Prerequisites
		cpeUrl = BenefitVerificationWorkflow_PatientEnrollment_Prerequisites(TestCaseNumber);
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-requisites 1.1::Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		homeportalPage.closeTabs();

		//documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		//assessmentTasksPage.verifyRecentlyViewList();
		//careProgram.navigateToAllCPE();
//			navigateToUrl(cpeUrl);
//			documentsPage.searchDocument("Automation");
//			missingInformatioPage.searchAndOpenRecord();

//			Thread.sleep(2000);
//			Logger("STEP 41 :PAP work order initialization.");
//			papPage.clickOnStartNewService();
//			papPage.selectService("PAP");

		Logger("STEP 2: Open a CPE record");
//			homeportalPage.closeTabs();
		navigateToUrl(cpeUrl);
		Thread.sleep(2000);

		Logger("STEP 41 :PAP work order initialization.");
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		missingInformatioPage.clickNextButton();
		papPage.selectReason(papOptions.get(2));

		Logger("STEP 19: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(3));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 9: Verify Research and Capture Outcome task is displayed");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		
		Logger("STEP 6: Fill Payer Name and Payer Phone fields → Click on Submit Button");
		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(2));
		papPage.enterDetails(paStatus.get(1), payerContact.get(0), attempts.get(0), attempt.get(0),
				attemptOutcomes.get(1), attempt.get(1), attemptOutcomes.get(1), attempt.get(2), attemptOutcomes.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		//Start new PAP service
		Logger("STEP 41 :PAP work order initialization.");
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(2));

		Logger("STEP 19: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(3));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 9: Verify Research and Capture Outcome task is displayed");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		
		Logger("STEP 6: Fill Payer Name and Payer Phone fields → Click on Submit Button");
		papPage.enterResearchDetails(alternateCoverage.get(0), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		//PAP Eligibility
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();

		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		documentsPage.logout();


		
			}
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:Validate auto-population of Eligibility Criteria fields in QS WO
	 * @author Tejal Pednekar
	 * 27021 
	 * @throws Exception ====================================================================================================================
	 */
	
	@Test(description = "Validate auto-population of Eligibility Criteria fields in QS WO", enabled = true)
	public void RPE40_IC19453_Validate_autopopulation_of_Eligibility_Criteria_fields_in_QS_WO() throws Exception {


		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC12";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text",
				"Specialty Pharmacy Name", "Diagnosis Code", "DUPIXENT MyWay",
				"Preferred Specialty Pharmacy" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "Automation Correspondence SP",
				 "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "TRUE" };
		

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite 2 : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");	
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Navigate to the Received document object →Select a document by checking the checkbox next to the relevant record--> Click on Assign to me button → Open the document and classify as enrollment form and Click on Submit");
		
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);
		Logger("STEP 2.1: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 2.2:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));
		
		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0) , ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		Logger("Pre-Requisite STEP 17: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		
		String CPEURL = getCurrentPageURL();

		documentsPage.logout();
		
		Logger(" STEP 16: Login as Bv User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		homeportalPage.closeTabs();
		
		navigateToURL(CPEURL);
		
		Logger("Pre-requisites 1.4: Verify BV Task is initiated");
		bvPage.verifytheBVTaskInitiated();

		Logger("Pre-requisites 1.5: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre-requisites 1.6: Enter Call Information section and Pharmacy Record and validate Pharmacy name is populated as per the Name provided in enrollment form under Payer Name.");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 1.7: Verify Coverage benefit section and select member plan and fill mandatory fields.");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		//bvPage.clickOnAttemptOutreachForConsents();
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		documentsPage.logout();
		
		Logger(" STEP 16: Login as CM User");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();
		
		navigateToURL(CPEURL);
		
		Logger("STEP 20: Open the QS WO >> Open the \"Enrollment\" Task");
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();
		quickStartPage.clickOnTask();

		Logger("STEP 21: In the Eligibility Assessment Task >>In Eligibility Cretia section select all the Fields as YES >> Click on Next button.");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.verifyAndenterEligibilityCriteria();
		missingInformatioPage.clickNextButton();
		

		Logger("STEP 22: In the next screen Eligibility Outcome page >> Eligibility Outcome as Eligible >> select Outcome as Approved >> Click on next button.");
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 23: On Order detail Page, select Prescription → Select any attachment and click on Submit button, check previous, next, save,and submit button working as expected");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		Logger("STEP 24: Click on quick start button and verify task compltion status");
		quickStartPage.clickOnQuickStart();
		quickStartPage.checkQuickStartTaskComplition();
		
		documentsPage.logout();

	}
	
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-27436 - Verify the automated DMW PAP Approval Medicare Enrollee - Payer Fax When 
	 * Coverage Situation = Medicare Part D - Potentially LIS
	 *
	 * @author Anand Pawar
	 *
	 * @throws Exception ===================================================================================================
	 */
 
	@Test(description = "Verify the automated DMW PAP Approval Medicare Enrollee - Payer Fax When Coverage Situation = Medicare Part D - Potentially LIS", enabled = true)
	public void FG59_IC27436_Verify_the_automated_DMW_PAP_Approval_Medicare_Enrollee_Payer_Fax_When_Coverage_Situation_Medicare_Part_D_Potentially_LIS()
			throws Exception {
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC9";


		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code","Text Messaging Consent", "DUPIXENT MyWay",
				"Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified","TRUE" ,"TRUE","FALSE"};

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());
//
//		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
//		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
//
//		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
//				ExcelTestData.get(patientEmail) };
//
//		Logger("STEP 2:Upload document to Dupixent portal");
//		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);
//
//		Logger("STEP 3: Navigate To Recently View Document list");
//		documentsPage.verifyRecentlyViewDocumentList();
//
//		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
//		documentsPage.navigateToMyReceivedDocListView();
//		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));
//
//		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
//		documentsPage.classifyDocument(documentType.get(0));
//		documentsPage.submitDocument();
//
//		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
//		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
//
//		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
//		patientSearch.verifyPatientSearchPageTitle();
//		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
//		String patientFirstName = name[0];
//		String patientMidName = name[1];
//		String patientLastName = name[2];
//
//		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
//		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
//				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
//				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
//				ExcelTestData.get(patientDOB));
//		patientSearch.clickOnNextButton();
//
//		// patientinfoAndauthorization-Page
//		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
//		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
//		String legalRepFirstName = legalRepName[0];
//		String legalRepLastName = legalRepName[2];
//
//		patientInfo.verifyPatientAuthorizationPageTitle();
//		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
//				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
//				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
//				ExcelTestData.get(zip));
//		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
//				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
//				ExcelTestData.get(textMessagingConsent));
//		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
//				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
//				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
//				ExcelTestData.get(patientSecondaryphone));
//		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
//		patientInfo.clickOnNextButton();
//
//		// Patient Insurance - Page
//		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
//		insuranceinfo.verifyInsuranceInfoPageTitle();
//		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
//				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
//				ExcelTestData.get(rxPCN));
//		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
//				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
//				ExcelTestData.get(insrelationshipToPatient));
//		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
//				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
//		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
//		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
//		insuranceinfo.selectPayerPharmacy();
//		insuranceinfo.selectMedicalPayer();
//		insuranceinfo.clickOnNextButton();
//
//		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
//		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
//		String preFirstName = preName[0];
//		String prLastName = preName[2];
//
//		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
//		String ofcFirstName = ofcName[0];
//		String ofcLastName = ofcName[2];
//
//		prescriberInformationPage.verifyPrescriberInfoPageTitle();
//		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
//				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
//				ExcelTestData.get(prescriberstateLicense));
//		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
//				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
//				ExcelTestData.get(prescriberZip));
//		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
//				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
//				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
//		prescriberInformationPage.clickOnNextButton();
//
//		// Diagnosis information-Page
//		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
//		diagnosisinformation.verifyDiagnosisInfoPageTitle();
//		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
//		diagnosisinformation.clickOnNextButton();
//
//		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
//		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
//		String mdFirstName = mdName[0];
//		String mdLastName = mdName[2];
//
//		prescriptioninformation.verifyPrescriptionInfoPageTitle();
//		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
//				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
//				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
//				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
//				ExcelTestData.get(NursePractitionerNPI));
//		prescriptioninformation.clickOnNextButton();
//
//		Logger("STEP 14:User Clicks on Form Confirmation Button");
//		formConfirmation.clicOnFormConfirmation();
//
//		Logger("STEP 15:Navigate to Account object");
//		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));
//
//		// CPE URL
//		String url = getCurrentPageURL();
//
//		Logger("STEP 16: User Logout the Application.");
//		documentsPage.logout();
		
		
		Logger("STEP 17:Login to the QA_SIT Org as CM User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		
//		navigateToUrl(url);
//		Thread.sleep(4000);
		String url1 = "https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf0000007KGXCA2/view";
		navigateToUrl(url1);
		
		Logger("STEP 18: Complete BV Task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(0), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOutreachAttemptChebox();
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		refresh();	
	    missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
		Logger("STEP 19: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 20: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 21: User will see two fields: 1. Start Service : Pick the value as \"PAP\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		papPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(3));

		Logger("STEP 22: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		Logger("STEP 23: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 24: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask("Pre-Check");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));

		Logger("STEP 25: Select value as Med Part D Potentially LIS then research required is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(3));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 26: Open 'Research and Capture Outcome', select as alternate coverage as No and Alternate Coverage Not Found   Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterResearchDetails(alternateCoverage.get(1), ExcelTestData.get(rxPayerName),
				ExcelTestData.get(officePhone));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();


		Logger("STEP 27: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		
		Logger("STEP 28: Enter eligibilty Check as Yes");
		papPage.enterEligibilityCheckEligibileforLIS("Yes");

		Logger("STEP 29: Click on next Button");
		quickStartPage.clickOnNextButton();

		Logger("STEP 30: Verify that PAP Eligibility Outcome value will be auto populated, greyed out, and non-editable. ->Enter the Outcome Value as Approved and Click on Next");
		papPage.validateEligibiltyIsDisable(false);
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 31: In the Order Details page, Select the Order details and Selected Documents and Click on Submit.");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));	
		refresh();
		
		Logger("STEP 32:Now Click on the related tab → Go to the Correspondence Related list → Verify \"DMW PAP Approval Medicare Enrollee - Payer Fax\" correspondence record is auto-created and is visible on the list");
		String dupCode="US.DUP.24.11.0282";
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();
		docMgmt.verifyCorresName();
		docMgmt.clickOncorrespondence();
		docMgmt.verifyDUP(dupCode);
		docMgmt.verifyRecepient(pharamcyMember.get(5));

		Logger("STEP 33: Validate PDF Files present in Related List of Correspondence ");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecordDocx(selectProcessName.get(5));
		String pdfName = selectProcessName.get(5).trim();
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.deleteExistingFile(downloadPath);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);

		Map<String, Integer> fieldsToValidate = new HashMap<>();
		fieldsToValidate.put(pharamcyMember.get(0), 2);
		
		Logger("Step 34: Verify correct document is generated with the Payer details in the document");
		docMgmt.validateMultiplePDFFields(downloadPath, fieldsToValidate);
		docMgmt.closeButton();

		Logger("Step 35: Logout from Application");
		documentsPage.logout();
			
	}
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-26859 - Verify the automated DMW PAP Approval Medicare Enrollee - Payer Fax When Coverage Situation =
	 *  Medicare Part D - Financial Hardship
	 *
	 * @author Anand Pawar
	 *
	 * @throws Exception ===================================================================================================
	 */
 
	@Test(description = "Verify the automated DMW PAP Approval Medicare Enrollee - Payer Fax When Coverage Situation = Medicare Part D - Fiancial Hardship", enabled = true)
	public void FG60_IC26859_Verify_the_automated_DMW_PAP_Approval_Medicare_Enrollee_Payer_Fax_When_Coverage_Situation_Medicare_Part_D_Financial_Hardship()
			throws Exception {
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC8";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code","Text Messaging Consent", "DUPIXENT MyWay",
				"Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified","TRUE" ,"TRUE","FALSE"};

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 15:Navigate to Account object");
		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 16: User Logout the Application.");
		documentsPage.logout();
			
		Logger("STEP 17:Login to the QA_SIT Org as CM User.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		
		navigateToUrl(url);
		Thread.sleep(4000);
		
		Logger("STEP 18: Complete BV Task");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(0), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		//bvPage.clickOutreachAttemptChebox();
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		refresh();	
	    missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
		Logger("STEP 19: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 20: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 21: User will see two fields: 1. Start Service : Pick the value as \"PAP\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		papPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(papOptions.get(0));

		Logger("STEP 22: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		Logger("STEP 23: Validate PAP WO is initiated and Click on PAP WO");
		papPage.checkPAPWOIntiation();
		papPage.checkPAPTaskInitiation();

		Logger("STEP 24: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
		papPage.clickOnTask("Pre-Check");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));

		Logger("STEP 25: Select value as Med Part D Potentially LIS then research required is auto populated as 'Yes' and Click on Submit button..");
		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 26: Open 'Confirm PAP eligibility'  Task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		
		Logger("STEP 27: Enter eligibilty Check as Yes");
		papPage.enterEligibilityCheckEligibileforLIS("Yes");

		Logger("STEP 28: Click on next Button");
		quickStartPage.clickOnNextButton();

		Logger("STEP 29: Verify that PAP Eligibility Outcome value will be auto populated, greyed out, and non-editable. ->Enter the Outcome Value as Approved and Click on Next");
		papPage.validateEligibiltyIsDisable(false);
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();

		Logger("STEP 30: In the Order Details page, Select the Order details and Selected Documents and Click on Submit.");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));	
		refresh();
		
		Logger("STEP 31:Now Click on the related tab → Go to the Correspondence Related list → Verify \"DMW PAP Approval Medicare Enrollee - Payer Fax\" correspondence record is auto-created and is visible on the list >> verify Dup Code and receipent details populated as payer fax");
		String dupCode="US.DUP.24.11.0282";
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();
		docMgmt.verifyCorresName();
		docMgmt.clickOncorrespondence();
		docMgmt.verifyDUP(dupCode);
		docMgmt.verifyRecepient(pharamcyMember.get(5));

		Logger("STEP 32: Validate PDF Files present in Related List of Correspondence");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToFilesSection();
		docMgmt.verifyFilesRecordDocx(selectProcessName.get(5));
		String pdfName = selectProcessName.get(5).trim();
		String downloadPath = System.getProperty("user.dir") + File.separator + "TestData" + File.separator
				+ "PDFDownloads" + File.separator + pdfName + ".pdf";
		docMgmt.deleteExistingFile(downloadPath);
		documentsPage.downloadPDFfileFromRelatedCPESection(pdfName);

		Map<String, Integer> fieldsToValidate = new HashMap<>();
		fieldsToValidate.put(pharamcyMember.get(0), 2);
		
		Logger("Step 33: Verify correct document is generated with the Payer details in the document");
		docMgmt.validateMultiplePDFFields(downloadPath, fieldsToValidate);
		docMgmt.closeButton();

		Logger("Step 34: Logout from Application");
		documentsPage.logout();
			
	}
	
	/**
	 * * ICARE-16824_14910-SIT-TC04-Validate CPEP Date revision when Coverage Situation =
	 *   Med Part D - Financial Hardship OR Med Part D - Potentially LIS for 
	 *   Older Active Records with This Years End date
	 * 
	 * * @author Sonica *
	 */
	@Test
	public void RGNFG13_20889_ICARE_14910_Validate_CPEP_Date_revision_when_Coverage_Situation_Med_Part_D_Financial_Hardship_OR_Potentially_LIS_for_Older_Active_Records_For_This_Years_End_Date()
			throws Exception {

		String TestCaseNumber = "TC32";
		String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
	//	String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite STEP 14: Login as PM User");
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		navigateToUrl(CPEURL);

		// Med D Financial Hardship
	/*	papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		papPage.checkPAPWOIntiation();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();
		refresh();*/


		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();

		String expectedStartDate = Utility_Function.getFirstDayofNextYear();
		papPage.validateEnrollmenetStartDate(expectedStartDate);

		String expectedEndDate = Utility_Function.getLastDayofNextYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate);

		// papPage.verifyStartEndDateEditable();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// For Potentially LIS
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		papPage.checkPAPWOIntiation();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));

		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();

		String expectedStartDate1 = Utility_Function.getFirstDayofNextYear();
		papPage.validateEnrollmenetStartDate(expectedStartDate1);

		String expectedEndDate1 = Utility_Function.getLastDayofNextYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate1);

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		String CPEURL1 = getCurrentPageURL();
		CPEURL1 = Utility_Function.removeQueryString(CPEURL1);
		documentsPage.logout();

		Logger("Pre-Requisite STEP 14: Login as BO User");
		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
		navigateToUrl(CPEURL1);
		papPage.checkPAPWOIntiation();
		
		// Med D Financial Hardship
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();
		
		String expectedStartDate2 = Utility_Function.getFirstDayofNextYear();
		papPage.validateEnrollmenetStartDate(expectedStartDate2);
		
		String expectedEndDate2 = Utility_Function.getLastDayofNextYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate2);
		
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// For Potentially LIS
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		papPage.checkPAPWOIntiation();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();

		String expectedStartDate3 = Utility_Function.getFirstDayofNextYear();
		papPage.validateEnrollmenetStartDate(expectedStartDate3);
		
		String expectedEndDate3 = Utility_Function.getLastDayofNextYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate3);

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		String CPEURL2 = getCurrentPageURL();
		CPEURL2 = Utility_Function.removeQueryString(CPEURL2);
		documentsPage.logout();

		//CM User
		Logger("Pre-Requisite STEP 14: Login as System admin User");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		navigateToUrl(CPEURL2);
		papPage.checkPAPWOIntiation();
		
		// Med D Financial Hardship
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();
		
		String expectedStartDate4 = Utility_Function.getFirstDayofNextYear();
		papPage.validateEnrollmenetStartDate(expectedStartDate4);
		
		String expectedEndDate4 = Utility_Function.getLastDayofNextYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate4);
		
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// For Potentially LIS
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		papPage.checkPAPWOIntiation();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();

		String expectedStartDate5 = Utility_Function.getFirstDayofNextYear();
		papPage.validateEnrollmenetStartDate(expectedStartDate5);
		
		String expectedEndDate5 = Utility_Function.getLastDayofNextYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate5);
		
		documentsPage.logout();

	}

	/**
	 * * ICARE-16818-14910-SIT-TC03-Validate CPEP Date revision when Coverage Situation = 
	 * Med Part D - Financial Hardship OR Med Part D - Potentially LIS for 
	 * Older Discontinued Records
	 * 
	 * * @author Sonica *
	 */
	@Test
	public void RGNFG14_20887_ICARE_14910_Validate_CPEP_Date_revision_when_Coverage_Situation_Med_Part_D_Financial_Hardship_OR_Potentially_LIS_for_Older_Discontinued_Records()
			throws Exception {

		String TestCaseNumber = "TC14";
		String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);

		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite STEP 14: Login as PM User");
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		navigateToUrl(CPEURL);

		// Med D Financial Hardship
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		papPage.checkPAPWOIntiation();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();
		refresh();

		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(3));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();

		String expectedStartDate = Utility_Function.getTodaysDate();
		papPage.validateEnrollmenetStartDate(expectedStartDate);

		String expectedEndDate = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate);

		// papPage.verifyStartEndDateEditable();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// For Potentially LIS
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		papPage.checkPAPWOIntiation();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));

		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();

		String expectedStartDate1 = Utility_Function.getTodaysDate();
		papPage.validateEnrollmenetStartDate(expectedStartDate1);

		String expectedEndDate1 = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate1);

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

//		papPage.clickOnStartNewService();
//		papPage.selectService("PAP");
//		missingInformatioPage.clickNextButton();
//		papPage.selectReason("Med D Annual Reverification");
//		missingInformatioPage.clickOnSaveButton();
		refresh();

		String CPEURL1 = getCurrentPageURL();
		CPEURL1 = Utility_Function.removeQueryString(CPEURL1);
		documentsPage.logout();

		Logger("Pre-Requisite STEP 14: Login as BO User");
		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
		navigateToUrl(CPEURL1);
		papPage.checkPAPWOIntiation();
		
		// Med D Financial Hardship
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(3));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();
		
		String expectedStartDate2 = Utility_Function.getTodaysDate();
		papPage.validateEnrollmenetStartDate(expectedStartDate2);
		
		String expectedEndDate2 = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate2);
		
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// For Potentially LIS
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		papPage.checkPAPWOIntiation();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();

		String expectedStartDate3 = Utility_Function.getTodaysDate();
		papPage.validateEnrollmenetStartDate(expectedStartDate3);
		
		String expectedEndDate3 = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate3);

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

//		papPage.clickOnStartNewService();
//		papPage.selectService("PAP");
//		missingInformatioPage.clickNextButton();
//		papPage.selectReason("Med D Annual Reverification");
//		missingInformatioPage.clickOnSaveButton();
		refresh();

		String CPEURL2 = getCurrentPageURL();
		CPEURL2 = Utility_Function.removeQueryString(CPEURL2);
		documentsPage.logout();

		//CM User
		Logger("Pre-Requisite STEP 14: Login as System admin User");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		navigateToUrl(CPEURL2);
		papPage.checkPAPWOIntiation();
		
		// Med D Financial Hardship
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(1));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(3));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();
		
		String expectedStartDate4 = Utility_Function.getTodaysDate();
		papPage.validateEnrollmenetStartDate(expectedStartDate4);
		
		String expectedEndDate4 = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate4);
		
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// For Potentially LIS
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		papPage.checkPAPWOIntiation();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();

		String expectedStartDate5 = Utility_Function.getTodaysDate();
		papPage.validateEnrollmenetStartDate(expectedStartDate5);
		
		String expectedEndDate5 = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate5);
		
		documentsPage.logout();
		
	}
	
	/**
	 * *
	 * ====================================================================================
	 * ================================== * Test Case Id: ICARE-16798
	 * Validate CPEP Date revision when Coverage Situation = Patient Uninsured OR Patient Underinsured
	 *  * @author  Tejal *
	 * =======================================================================================
	 * ==============================
	 */
	@Test
	public void BV09_IC20883_16798_PAP_is_initiated_with_BVOutcome_Uninsured_with_alternate_research_required()
			throws Exception {

		String TestCaseNumber = "TC12";
		String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);


		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);

		Logger("Pre-Requisite STEP 14: Login as PM User");
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		navigateToUrl(CPEURL);

		// Patient Uninsured
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		papPage.checkPAPWOIntiation();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(3));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();
        String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate);
		papPage.verifyStartEndDateEditable();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// For Patient Underinsured
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		papPage.checkPAPWOIntiation();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(1));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();

		String expectedStartDate1 = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate1);
		String expectedEndDate1 = Utility_Function.getDateNDaysFromToday(365);
		papPage.validateEnrollmenetEndDate(expectedEndDate1);
		papPage.verifyStartEndDateEditable();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		String CPEURL1 = getCurrentPageURL();
		CPEURL1 = Utility_Function.removeQueryString(CPEURL1);
	    documentsPage.logout();
	    
	    Logger("Pre-Requisite STEP 14: Login as BO User");
	  		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
	  		navigateToUrl(CPEURL1);
	  		papPage.checkPAPWOIntiation();
	  	// Patient Uninsured
	  		Logger("STEP 9: Open Capture Coverage Outcome sub task");
	  		papPage.clickOnPAPTask();
	  		papPage.clickOnMainTask(papMainTaskNames.get(0));
	  		papPage.clickOnTask(papSubTaskNames.get(0));
	  		papPage.enterCoverageSituation(coverageSituation.get(0));
	  		quickStartPage.clickOnSubmitButton();
	  		refresh();
	  		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
	  		papPage.clickOnPAPTask();
	  		papPage.clickOnMainTask(papMainTaskNames.get(0));
	  		papPage.clickOnTask(papSubTaskNames.get(1));
	  		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
	  		quickStartPage.clickOnNextButton();
	  		papPage.enterCoverageOutcome(iapoutcome.get(3));
	  		quickStartPage.clickOnSubmitButton();

	  		refresh();
	  		papPage.clickOnPAPTask();
	  		papPage.clickOnMainTask(papMainTaskNames.get(1));
	  		papPage.clickOnTask(papSubTaskNames.get(4));
	  		papPage.enterPAPEligibilityCheck();
	  		quickStartPage.clickOnNextButton();
	  		papPage.enterCoverageOutcome(iapoutcome.get(0));
	  		quickStartPage.clickOnNextButton();
	  		quickStartPage.enterOrderDetails();
	  		quickStartPage.checkAttachCheckbox();
	  		quickStartPage.clickOnSubmitButton();
	  		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
	  		refresh();
	  		accountObject.clickOnTab(tabsName.get(1));
	  		papPage.clickOnPAPCpe();
	          String expectedStartDate2= Utility_Function.getDateNDaysFromToday(0);
	  		papPage.validateEnrollmenetStartDate(expectedStartDate2);
	  		String expectedEndDate2 = Utility_Function.getDateNDaysFromToday(365);
	  		papPage.validateEnrollmenetEndDate(expectedEndDate2);
	  		papPage.verifyStartEndDateEditable();
	  		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

	  		// For Patient Underinsured
	  		papPage.clickOnStartNewService();
	  		papPage.selectService("PAP");
	  		missingInformatioPage.clickNextButton();
	  		papPage.selectReason("Med D Annual Reverification");
	  		missingInformatioPage.clickOnSaveButton();
	  		refresh();

	  		papPage.checkPAPWOIntiation();

	  		Logger("STEP 9: Open Capture Coverage Outcome sub task");
	  		papPage.clickOnPAPTask();
	  		papPage.clickOnMainTask(papMainTaskNames.get(0));
	  		papPage.clickOnTask(papSubTaskNames.get(0));
	  		papPage.enterCoverageSituation(coverageSituation.get(1));
	  		quickStartPage.clickOnSubmitButton();

	  		refresh();
	  		papPage.clickOnPAPTask();
	  		papPage.clickOnMainTask(papMainTaskNames.get(1));
	  		papPage.clickOnTask(papSubTaskNames.get(4));
	  		papPage.enterPAPEligibilityCheck();
	  		quickStartPage.clickOnNextButton();
	  		papPage.enterCoverageOutcome(iapoutcome.get(0));
	  		quickStartPage.clickOnNextButton();
	  		quickStartPage.enterOrderDetails();
	  		quickStartPage.checkAttachCheckbox();
	  		quickStartPage.clickOnSubmitButton();
	  		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
	  		refresh();
	  		accountObject.clickOnTab(tabsName.get(1));
	  		papPage.clickOnPAPCpe();

	  		String expectedStartDate3 = Utility_Function.getDateNDaysFromToday(0);
	  		papPage.validateEnrollmenetStartDate(expectedStartDate3);
	  		String expectedEndDate3 = Utility_Function.getDateNDaysFromToday(365);
	  		papPage.validateEnrollmenetEndDate(expectedEndDate3);
	  		papPage.verifyStartEndDateEditable();
	   
	  		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
			
			papPage.clickOnStartNewService();
			papPage.selectService("PAP");
			missingInformatioPage.clickNextButton();
			papPage.selectReason("Med D Annual Reverification");
			missingInformatioPage.clickOnSaveButton();
			refresh();
			
			String CPEURL2 = getCurrentPageURL();
			CPEURL2 = Utility_Function.removeQueryString(CPEURL2);
		    documentsPage.logout();
		    
		    
		    Logger("Pre-Requisite STEP 14: Login as System admin User");
	  		homeportalPage = loginPage.userLogin(SAUserName, UserPassword);
	  		navigateToUrl(CPEURL2);
	  		papPage.checkPAPWOIntiation();
	  	// Patient Uninsured
	  		Logger("STEP 9: Open Capture Coverage Outcome sub task");
	  		papPage.clickOnPAPTask();
	  		papPage.clickOnMainTask(papMainTaskNames.get(0));
	  		papPage.clickOnTask(papSubTaskNames.get(0));
	  		papPage.enterCoverageSituation(coverageSituation.get(0));
	  		quickStartPage.clickOnSubmitButton();
	  		refresh();
	  		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
	  		papPage.clickOnPAPTask();
	  		papPage.clickOnMainTask(papMainTaskNames.get(0));
	  		papPage.clickOnTask(papSubTaskNames.get(1));
	  		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
	  		quickStartPage.clickOnNextButton();
	  		papPage.enterCoverageOutcome(iapoutcome.get(3));
	  		quickStartPage.clickOnSubmitButton();

	  		refresh();
	  		papPage.clickOnPAPTask();
	  		papPage.clickOnMainTask(papMainTaskNames.get(1));
	  		papPage.clickOnTask(papSubTaskNames.get(4));
	  		papPage.enterPAPEligibilityCheck();
	  		quickStartPage.clickOnNextButton();
	  		papPage.enterCoverageOutcome(iapoutcome.get(0));
	  		quickStartPage.clickOnNextButton();
	  		quickStartPage.enterOrderDetails();
	  		quickStartPage.checkAttachCheckbox();
	  		quickStartPage.clickOnSubmitButton();
	  		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
	  		refresh();
	  		accountObject.clickOnTab(tabsName.get(1));
	  		papPage.clickOnPAPCpe();
	          String expectedStartDate4= Utility_Function.getDateNDaysFromToday(0);
	  		papPage.validateEnrollmenetStartDate(expectedStartDate4);
	  		String expectedEndDate4 = Utility_Function.getDateNDaysFromToday(365);
	  		papPage.validateEnrollmenetEndDate(expectedEndDate4);
	  		papPage.verifyStartEndDateEditable();
	  		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

	  		// For Patient Underinsured
	  		papPage.clickOnStartNewService();
	  		papPage.selectService("PAP");
	  		missingInformatioPage.clickNextButton();
	  		papPage.selectReason("Med D Annual Reverification");
	  		missingInformatioPage.clickOnSaveButton();
	  		refresh();

	  		papPage.checkPAPWOIntiation();

	  		Logger("STEP 9: Open Capture Coverage Outcome sub task");
	  		papPage.clickOnPAPTask();
	  		papPage.clickOnMainTask(papMainTaskNames.get(0));
	  		papPage.clickOnTask(papSubTaskNames.get(0));
	  		papPage.enterCoverageSituation(coverageSituation.get(1));
	  		quickStartPage.clickOnSubmitButton();

	  		refresh();
	  		papPage.clickOnPAPTask();
	  		papPage.clickOnMainTask(papMainTaskNames.get(1));
	  		papPage.clickOnTask(papSubTaskNames.get(4));
	  		papPage.enterPAPEligibilityCheck();
	  		quickStartPage.clickOnNextButton();
	  		papPage.enterCoverageOutcome(iapoutcome.get(0));
	  		quickStartPage.clickOnNextButton();
	  		quickStartPage.enterOrderDetails();
	  		quickStartPage.checkAttachCheckbox();
	  		quickStartPage.clickOnSubmitButton();
	  		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
	  		refresh();
	  		accountObject.clickOnTab(tabsName.get(1));
	  		papPage.clickOnPAPCpe();

	  		String expectedStartDate5 = Utility_Function.getDateNDaysFromToday(0);
	  		papPage.validateEnrollmenetStartDate(expectedStartDate5);
	  		String expectedEndDate5 = Utility_Function.getDateNDaysFromToday(365);
	  		papPage.validateEnrollmenetEndDate(expectedEndDate5);
	  		papPage.verifyStartEndDateEditable();
	  		documentsPage.logout();
	  
		
	}
	
	/**
	 * *
	 * ====================================================================================
	 * ================================== * Test Case Id: ICARE-16807
	 * Validate CPEP Date revision when Coverage Situation = Med Part D - Financial Hardship OR Med Part D - Potentially LIS for Older Active Records with last Years End date
	 *  * @author  Tejal *
	 * =======================================================================================
	 * ==============================
	 */
	@Test
	public void BV09_IC20885_16807_Validate_CPEP_Date_revision_Coverage_Situation_MedPartD_Financial_Hardship_OR_MedPartD_Potentially_LIS()
			throws Exception {
		
		String TestCaseNumber = "TC14";
		String CPEURL = PatientEnrollment_Prerequisites_RGN_FG_PAP(TestCaseNumber);


		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		
		Logger("Pre-Requisite STEP 14: Login as PM User");
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		navigateToUrl(CPEURL);

		// Med Part D - Financial Hardship
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		papPage.checkPAPWOIntiation();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(2));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		papPage.enterLISinfo(eligibilityOutcome.get(2));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();
        String expectedStartDate = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate);
		String expectedEndDate = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate);
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// Med Part D - Potentially LIS
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();

		papPage.checkPAPWOIntiation();

		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(3));
		quickStartPage.clickOnSubmitButton();

		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(3));
		quickStartPage.clickOnSubmitButton();
		refresh();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterPAPEligibilityCheck();
		papPage.enterLISinfo(eligibilityOutcome.get(2));
		quickStartPage.clickOnNextButton();
		papPage.enterCoverageOutcome(iapoutcome.get(0));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		papPage.clickOnPAPCpe();

		String expectedStartDate1 = Utility_Function.getDateNDaysFromToday(0);
		papPage.validateEnrollmenetStartDate(expectedStartDate1);
		String expectedEndDate1 = Utility_Function.getLastDayOfYear();
		papPage.validateEnrollmenetEndDate(expectedEndDate1);
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		papPage.selectReason("Med D Annual Reverification");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		String CPEURL1 = getCurrentPageURL();
		CPEURL1 = Utility_Function.removeQueryString(CPEURL1);
	    documentsPage.logout();

	    
	    Logger("Pre-Requisite STEP 14: Login as BO User");
  		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
  	    navigateToUrl(CPEURL1);
  		
  	// Med Part D - Financial Hardship

  			papPage.checkPAPWOIntiation();

  			Logger("STEP 9: Open Capture Coverage Outcome sub task");
  			papPage.clickOnPAPTask();
  			papPage.clickOnMainTask(papMainTaskNames.get(0));
  			papPage.clickOnTask(papSubTaskNames.get(0));
  			papPage.enterCoverageSituation(coverageSituation.get(2));
  			quickStartPage.clickOnSubmitButton();
  			refresh();
  			
  			papPage.clickOnPAPTask();
  			papPage.clickOnMainTask(papMainTaskNames.get(1));
  			papPage.clickOnTask(papSubTaskNames.get(4));
  			papPage.enterPAPEligibilityCheck();
  			papPage.enterLISinfo(eligibilityOutcome.get(2));
  			quickStartPage.clickOnNextButton();
  			papPage.enterCoverageOutcome(iapoutcome.get(0));
  			quickStartPage.clickOnNextButton();
  			quickStartPage.enterOrderDetails();
  			quickStartPage.checkAttachCheckbox();
  			quickStartPage.clickOnSubmitButton();
  			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
  			refresh();
  			accountObject.clickOnTab(tabsName.get(1));
  			papPage.clickOnPAPCpe();
  	        String expectedStartDate2 = Utility_Function.getDateNDaysFromToday(0);
  			papPage.validateEnrollmenetStartDate(expectedStartDate2);
  			String expectedEndDate2 = Utility_Function.getLastDayOfYear();
  			papPage.validateEnrollmenetEndDate(expectedEndDate2);
  			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

  			// Med Part D - Potentially LIS
  			papPage.clickOnStartNewService();
  			papPage.selectService("PAP");
  			missingInformatioPage.clickNextButton();
  			iapPage.checkAttestationcheckboxIfPresent();
  			quickStartPage.clickOnNextButton();
  			papPage.selectReason("Med D Annual Reverification");
  			missingInformatioPage.clickOnSaveButton();
  			refresh();

  			papPage.checkPAPWOIntiation();

  			Logger("STEP 9: Open Capture Coverage Outcome sub task");
  			papPage.clickOnPAPTask();
  			papPage.clickOnMainTask(papMainTaskNames.get(0));
  			papPage.clickOnTask(papSubTaskNames.get(0));
  			papPage.enterCoverageSituation(coverageSituation.get(3));
  			quickStartPage.clickOnSubmitButton();

  			refresh();
  			papPage.clickOnPAPTask();
  			papPage.clickOnMainTask(papMainTaskNames.get(0));
  			papPage.clickOnTask(papSubTaskNames.get(1));
  			papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
  			quickStartPage.clickOnNextButton();
  			papPage.enterCoverageOutcome(iapoutcome.get(3));
  			quickStartPage.clickOnSubmitButton();
  			refresh();
  			papPage.clickOnPAPTask();
  			papPage.clickOnMainTask(papMainTaskNames.get(1));
  			papPage.clickOnTask(papSubTaskNames.get(4));
  			papPage.enterPAPEligibilityCheck();
  			papPage.enterLISinfo(eligibilityOutcome.get(2));
  			quickStartPage.clickOnNextButton();
  			papPage.enterCoverageOutcome(iapoutcome.get(0));
  			quickStartPage.clickOnNextButton();
  			quickStartPage.enterOrderDetails();
  			quickStartPage.checkAttachCheckbox();
  			quickStartPage.clickOnSubmitButton();
  			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
  			refresh();
  			accountObject.clickOnTab(tabsName.get(1));
  			papPage.clickOnPAPCpe();

  			String expectedStartDate3 = Utility_Function.getDateNDaysFromToday(0);
  			papPage.validateEnrollmenetStartDate(expectedStartDate3);
  			String expectedEndDate3 = Utility_Function.getLastDayOfYear();
  			papPage.validateEnrollmenetEndDate(expectedEndDate3);
  			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
  			
  			papPage.clickOnStartNewService();
  			papPage.selectService("PAP");
  			missingInformatioPage.clickNextButton();
  			iapPage.checkAttestationcheckboxIfPresent();
  			quickStartPage.clickOnNextButton();
  			papPage.selectReason("Med D Annual Reverification");
  			missingInformatioPage.clickOnSaveButton();
  			refresh();
  			
  			String CPEURL2 = getCurrentPageURL();
  			CPEURL2 = Utility_Function.removeQueryString(CPEURL2);
  		    documentsPage.logout();
		
    
  		   
  		  Logger("Pre-Requisite STEP 14: Login as System admin User");
    		homeportalPage = loginPage.userLogin(SAUserName, UserPassword);
    	    navigateToUrl(CPEURL2);
    	
    	// Med Part D - Financial Hardship
  		
                papPage.checkPAPWOIntiation();

    			Logger("STEP 9: Open Capture Coverage Outcome sub task");
    			papPage.clickOnPAPTask();
    			papPage.clickOnMainTask(papMainTaskNames.get(0));
    			papPage.clickOnTask(papSubTaskNames.get(0));
    			papPage.enterCoverageSituation(coverageSituation.get(2));
    			quickStartPage.clickOnSubmitButton();
    			refresh();
    			
    			papPage.clickOnPAPTask();
    			papPage.clickOnMainTask(papMainTaskNames.get(1));
    			papPage.clickOnTask(papSubTaskNames.get(4));
    			papPage.enterPAPEligibilityCheck();
    			papPage.enterLISinfo(eligibilityOutcome.get(2));
    			quickStartPage.clickOnNextButton();
    			papPage.enterCoverageOutcome(iapoutcome.get(0));
    			quickStartPage.clickOnNextButton();
    			quickStartPage.enterOrderDetails();
    			quickStartPage.checkAttachCheckbox();
    			quickStartPage.clickOnSubmitButton();
    			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
    			refresh();
    			accountObject.clickOnTab(tabsName.get(1));
    			papPage.clickOnPAPCpe();
    	        String expectedStartDate4 = Utility_Function.getDateNDaysFromToday(0);
    			papPage.validateEnrollmenetStartDate(expectedStartDate4);
    			String expectedEndDate4 = Utility_Function.getLastDayOfYear();
    			papPage.validateEnrollmenetEndDate(expectedEndDate4);
    			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

    			// Med Part D - Potentially LIS
    			papPage.clickOnStartNewService();
    			papPage.selectService("PAP");
    			missingInformatioPage.clickNextButton();
    			iapPage.checkAttestationcheckboxIfPresent();
    			quickStartPage.clickOnNextButton();
    			papPage.selectReason("Med D Annual Reverification");
    			missingInformatioPage.clickOnSaveButton();
    			refresh();

    			papPage.checkPAPWOIntiation();

    			Logger("STEP 9: Open Capture Coverage Outcome sub task");
    			papPage.clickOnPAPTask();
    			papPage.clickOnMainTask(papMainTaskNames.get(0));
    			papPage.clickOnTask(papSubTaskNames.get(0));
    			papPage.enterCoverageSituation(coverageSituation.get(3));
    			quickStartPage.clickOnSubmitButton();

    			refresh();
    			papPage.clickOnPAPTask();
    			papPage.clickOnMainTask(papMainTaskNames.get(0));
    			papPage.clickOnTask(papSubTaskNames.get(1));
    			papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
    			quickStartPage.clickOnNextButton();
    			papPage.enterCoverageOutcome(iapoutcome.get(3));
    			quickStartPage.clickOnSubmitButton();
    			refresh();
    			papPage.clickOnPAPTask();
    			papPage.clickOnMainTask(papMainTaskNames.get(1));
    			papPage.clickOnTask(papSubTaskNames.get(4));
    			papPage.enterPAPEligibilityCheck();
    			papPage.enterLISinfo(eligibilityOutcome.get(2));
    			quickStartPage.clickOnNextButton();
    			papPage.enterCoverageOutcome(iapoutcome.get(0));
    			quickStartPage.clickOnNextButton();
    			quickStartPage.enterOrderDetails();
    			quickStartPage.checkAttachCheckbox();
    			quickStartPage.clickOnSubmitButton();
    			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
    			refresh();
    			accountObject.clickOnTab(tabsName.get(1));
    			papPage.clickOnPAPCpe();

    			String expectedStartDate5 = Utility_Function.getDateNDaysFromToday(0);
    			papPage.validateEnrollmenetStartDate(expectedStartDate5);
    			String expectedEndDate5 = Utility_Function.getLastDayOfYear();
    			papPage.validateEnrollmenetEndDate(expectedEndDate5);
    			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
    			
    			papPage.clickOnStartNewService();
    			papPage.selectService("PAP");
    			missingInformatioPage.clickNextButton();
    			iapPage.checkAttestationcheckboxIfPresent();
    			quickStartPage.clickOnNextButton();
    			papPage.selectReason("Med D Annual Reverification");
    			missingInformatioPage.clickOnSaveButton();
    			refresh();
    			
    			String CPEURL3 = getCurrentPageURL();
    			CPEURL3 = Utility_Function.removeQueryString(CPEURL3);
    		    documentsPage.logout();
    		    
    		    Logger("Pre-Requisite STEP 14: Login as CM User");
        		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
        	    navigateToUrl(CPEURL3);
        	
        	// Med Part D - Financial Hardship
      		
                    papPage.checkPAPWOIntiation();

        			Logger("STEP 9: Open Capture Coverage Outcome sub task");
        			papPage.clickOnPAPTask();
        			papPage.clickOnMainTask(papMainTaskNames.get(0));
        			papPage.clickOnTask(papSubTaskNames.get(0));
        			papPage.enterCoverageSituation(coverageSituation.get(2));
        			quickStartPage.clickOnSubmitButton();
        			refresh();
        			
        			papPage.clickOnPAPTask();
        			papPage.clickOnMainTask(papMainTaskNames.get(1));
        			papPage.clickOnTask(papSubTaskNames.get(4));
        			papPage.enterPAPEligibilityCheck();
        			papPage.enterLISinfo(eligibilityOutcome.get(2));
        			quickStartPage.clickOnNextButton();
        			papPage.enterCoverageOutcome(iapoutcome.get(0));
        			quickStartPage.clickOnNextButton();
        			quickStartPage.enterOrderDetails();
        			quickStartPage.checkAttachCheckbox();
        			quickStartPage.clickOnSubmitButton();
        			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
        			refresh();
        			accountObject.clickOnTab(tabsName.get(1));
        			papPage.clickOnPAPCpe();
        	        String expectedStartDate6 = Utility_Function.getDateNDaysFromToday(0);
        			papPage.validateEnrollmenetStartDate(expectedStartDate6);
        			String expectedEndDate6 = Utility_Function.getLastDayOfYear();
        			papPage.validateEnrollmenetEndDate(expectedEndDate6);
        			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

        			// Med Part D - Potentially LIS
        			papPage.clickOnStartNewService();
        			papPage.selectService("PAP");
        			missingInformatioPage.clickNextButton();
        			iapPage.checkAttestationcheckboxIfPresent();
        			quickStartPage.clickOnNextButton();
        			papPage.selectReason("Med D Annual Reverification");
        			missingInformatioPage.clickOnSaveButton();
        			refresh();

        			papPage.checkPAPWOIntiation();

        			Logger("STEP 9: Open Capture Coverage Outcome sub task");
        			papPage.clickOnPAPTask();
        			papPage.clickOnMainTask(papMainTaskNames.get(0));
        			papPage.clickOnTask(papSubTaskNames.get(0));
        			papPage.enterCoverageSituation(coverageSituation.get(3));
        			quickStartPage.clickOnSubmitButton();

        			refresh();
        			papPage.clickOnPAPTask();
        			papPage.clickOnMainTask(papMainTaskNames.get(0));
        			papPage.clickOnTask(papSubTaskNames.get(1));
        			papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
        			quickStartPage.clickOnNextButton();
        			papPage.enterCoverageOutcome(iapoutcome.get(3));
        			quickStartPage.clickOnSubmitButton();
        			refresh();
        			papPage.clickOnPAPTask();
        			papPage.clickOnMainTask(papMainTaskNames.get(1));
        			papPage.clickOnTask(papSubTaskNames.get(4));
        			papPage.enterPAPEligibilityCheck();
        			papPage.enterLISinfo(eligibilityOutcome.get(2));
        			quickStartPage.clickOnNextButton();
        			papPage.enterCoverageOutcome(iapoutcome.get(0));
        			quickStartPage.clickOnNextButton();
        			quickStartPage.enterOrderDetails();
        			quickStartPage.checkAttachCheckbox();
        			quickStartPage.clickOnSubmitButton();
        			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
        			refresh();
        			accountObject.clickOnTab(tabsName.get(1));
        			papPage.clickOnPAPCpe();

        			String expectedStartDate7 = Utility_Function.getDateNDaysFromToday(0);
        			papPage.validateEnrollmenetStartDate(expectedStartDate7);
        			String expectedEndDate7 = Utility_Function.getLastDayOfYear();
        			papPage.validateEnrollmenetEndDate(expectedEndDate7);
        			missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
    
	
	    
	  
	}
  
  
  @Test(description = "Patient Enrollment Prequisite for 10265", enabled = true)
	public String FG_Pre_Requisite_10265_PE(String tcNumber) throws Exception {
		

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = tcNumber;
 
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text",
				"Specialty Pharmacy Name", "Diagnosis Code", "DUPIXENT MyWay",
				"Preferred Specialty Pharmacy" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "Automation Correspondence SP",
				 "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "FALSE" };

 
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];
 
		Logger("Pre-Requisite 2 : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);
 
		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
 
		Logger("STEP 2:Navigate to the Received document object →Select a document by checking the checkbox next to the relevant record--> Click on Assign to me button → Open the document and classify as enrollment form and Click on Submit");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);
		Logger("STEP 2.1: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();
 
		Logger("STEP 2.2:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));
		
		Logger("STEP 2.3:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
 
		Logger("STEP 3:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
 
		Logger("STEP 3.1: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];
 
		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();
 
		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];
 
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();
 
		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
 
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();
 
		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];
 
		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];
 
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();
 
		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		Thread.sleep(2000);	
		diagnosisinformation.clickOnNextButton();
 
		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];
 
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();
 
		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
 
		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
		
		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();
		
		return CPEURL;
	}
  
  /**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-10265 To Verify PAP Eligibility Logic Update
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 

	@Test(description = "Test Case Id:ICARE-10265-  To Verify PAP Eligibility Logic Update", enabled = true)
	public void FG58_ICARE_10265_To_Verify_PAP_Eligibility_Logic_Updates() throws Exception {

		String TestCaseNumber = "TC4";

		int numberOfUsers = 3;
		
		String user="";

		String CPEURL = FG_Pre_Requisite_10265_PE(TestCaseNumber);

		Map<String, String> ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		SoftAssert softassert = new SoftAssert();

		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
				case 0:
					Logger("STEP 1: Login to the  Org as 'Case Manager'.");
					homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
					user="CM User";					
					break;
				case 1:
					Logger("STEP 1: Login to the  Org as 'PM User'.");
					homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
					user="PM User";					
					break;
				case 2:
					Logger("STEP 1: Login to the Org as 'Business Ops User'.");
					homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
					user="BOps User";				
					break;
				}
				
				navigateToUrl(CPEURL);
				Thread.sleep(4000);
				

				Logger("STEP 15: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
				iapPage.verifyStartNewServiceButton();

				Logger("STEP 16: Click on the button \"Start New Services\"");
				iapPage.clickOnStartNewService();

				Logger("STEP 17: User will see two fields: 1. Start Service : Pick the value as \"PAP\" 2. Reason: Any one");
				iapPage.verifyServiceTitle();
				papPage.selectService();
				missingInformatioPage.clickNextButton();
				iapPage.checkAttestationcheckboxIfPresent();
				papPage.selectReason(papOptions.get(3));

				Logger("STEP 19: Click on Save button");
				missingInformatioPage.clickOnSaveButton();
				refresh();

				Logger("STEP 19: Validate PAP WO is initiated and Click on PAP WO");
				papPage.checkPAPWOIntiation();
				papPage.checkPAPTaskInitiation();

				Logger("STEP 20: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
				papPage.clickOnTask("Pre-Check");
				quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));

				Logger("STEP 21: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
				papPage.enterCoverageSituation(coverageSituation.get(2));
				quickStartPage.clickOnSubmitButton();
				refresh();

				Logger("STEP 22: Open 'Confirm PAP eligibility'  Task");
				papPage.clickOnPAPTask();
				papPage.clickOnMainTask(papMainTaskNames.get(1));
				papPage.clickOnTask(papSubTaskNames.get(4));

				Logger("STEP 22.1: Verify a new field \"LIS\" is added under eligibility assessment task of PAP WO under Eligibility check section Verify the Picklist value contains: Eligible/ Denied");
				papPage.verifyLISFieldOptions();

				Logger("STEP 22.2: Verify that LIS field is mandatory when the Adjusted FPL% field is equal to/less than 150%,Enter the value which is equal to/ less than 150% in Adjusted FPL and click on Next to verify that LIS field is mandatory->verify the error message \"LIS is required\" is displayed");
				papPage.verifyLISMandatory();
				papPage.verifyLISNotMandatory();

				Logger("STEP 22.2: Verify help text is updated on \"M3P and Deductible Not Met\" field to \"PT must attest opted in to M3P and not met $2,000 out of pocket");
				papPage.verifyHelpText();

				Logger("STEP 23: Enter eligibilty Check");
				papPage.enterEligibilityCheckEligibileforLIS("Yes");

				Logger("STEP 24: Click on next Button");
				quickStartPage.clickOnNextButton();

				Logger("STEP 25: Verify that PAP Eligibility Outcome field is populated as Eligible only for the combinations given in the table ->Enter the Outcome Value as Approved and Click on Next");
				papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
				quickStartPage.clickOnNextButton();

				Logger("STEP 26: In the Order Details page, Select the Order details and Selected Documents and Click on Submit.");
				iapPage.verifyTaskIsLoaded(taskTitle.get(3));
				quickStartPage.enterOrderDetails();
				quickStartPage.checkAttachCheckbox();
				quickStartPage.clickOnSubmitButton();
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();

				Logger("STEP 27:Verify the PAP Work Order is completed and the Alternate Coverage and Confirm PAP Eligibility Tasks are completed");
				papPage.checkPAPCompletion();

				Logger("STEP 28: Verify PAP CPEP Record created");
				accountObject.clickOnTab(tabsName.get(1));
				iapPage.navigateToCPEPTable();
				careProgram.clickOnViewAll("Care Program Enrollee Products");
				iapPage.navigateToCPEPRecord("PAP");

				Logger("STEP 29:Navigate back to CPE > click on the  related > Navigate to Orders section > verify the order is created");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				accountObject.clickOnTab(tabsName.get(1));
				iapPage.navigateToOrdersTable();
				careProgram.clickOnViewAll("Orders");
				iapPage.verifyOrderCreated("PAP");

				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();

				Logger("STEP 30: Re-intiate PAP again , Enter the Adjusted FPL% >300");
				iapPage.clickOnStartNewService();

				Logger("STEP 31: User will see two fields: 1. Start Service : Pick the value as \"PAP\" 2. Reason: Any one");
				iapPage.verifyServiceTitle();
				papPage.selectService();
				missingInformatioPage.clickNextButton();
				iapPage.checkAttestationcheckboxIfPresent();
				papPage.selectReason(papOptions.get(3));

				Logger("STEP 32: Click on Save button");
				missingInformatioPage.clickOnSaveButton();
				refresh();

				Logger("STEP 33: Validate PAP WO is initiated and Click on PAP WO");
				papPage.checkPAPWOIntiation();
				papPage.checkPAPTaskInitiation();

				Logger("STEP 34: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
				papPage.clickOnTask("Pre-Check");
				quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));

				Logger("STEP 35: Select value as Patient Underinsured and validate Alternate Research is auto populated as 'Yes' and Click on Submit button..");
				papPage.enterCoverageSituation(coverageSituation.get(2));
				quickStartPage.clickOnSubmitButton();
				refresh();

				Logger("STEP 36: Open 'Confirm PAP eligibility'  Task");
				papPage.clickOnPAPTask();
				papPage.clickOnMainTask(papMainTaskNames.get(1));
				papPage.clickOnTask(papSubTaskNames.get(4));

				Logger("STEP 37: Enter eligibilty Check");
				papPage.enterEligibilityCheckEligible();

				Logger("STEP 38: Click on next Button");
				quickStartPage.clickOnNextButton();

				Logger("STEP 39: Verify that PAP Eligibility Outcome field is populated as Eligible only for the combinations given in the table ->Enter the Outcome Value as Denied and Click on Next");
				papPage.enterCoverageOutcome(pAOutcomeOptions.get(2));
				papPage.enterCoverageOutcomeReason(caseTypes.get(0));
				quickStartPage.clickOnNextButton();

				Logger("STEP 40:Navigate back to CPE > click on the  related > Navigate to Orders section > verify the new order not created");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();
				accountObject.clickOnTab(tabsName.get(1));
				iapPage.navigateToOrdersTable();
				careProgram.clickOnViewAll("Orders");
				int orderCount = iapPage.verifyNumberOfOrderCreated("PAP");
				System.out.println(orderCount);
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

				Logger("STEP 41: Verify PAP CPEP Record is not created");
				accountObject.clickOnTab(tabsName.get(1));
				iapPage.navigateToCPEPTable();
				careProgram.clickOnViewAll("Care Program Enrollee Products");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();

				Logger("STEP 42: Click on Start New Service and Initiate the PAP Work Order by selecting service as PAP and select any reason from the Picklist and click on Save\r\n");
				iapPage.clickOnStartNewService();

				Logger("STEP 43: User will see two fields: 1. Start Service : Pick the value as \"PAP\" 2. Reason: Any one");
				iapPage.verifyServiceTitle();
				papPage.selectService();
				missingInformatioPage.clickNextButton();
				iapPage.checkAttestationcheckboxIfPresent();
				papPage.selectReason(papOptions.get(2));

				Logger("STEP 44: Click on Save button");
				missingInformatioPage.clickOnSaveButton();
				refresh();

				Logger("STEP 45: Validate PAP WO is initiated and Click on PAP WO");
				papPage.checkPAPWOIntiation();
				papPage.checkPAPTaskInitiation();

				Logger("STEP 46: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
				papPage.clickOnTask("Pre-Check");
				quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));

				Logger("STEP 47: Click on Pre Check Task and select the Coverage Situation Value as Med Part D - Financial hardship/ Med Part D - Potentially LIS->Click on Submit");
				papPage.enterCoverageSituation(coverageSituation.get(3));
				quickStartPage.clickOnSubmitButton();
				refresh();

				Logger("STEP 48: In Research Task, Enter the value in the Alternate Research identified field as No->Click on Submit");
				papPage.clickOnPAPTask();
				papPage.clickOnMainTask(papMainTaskNames.get(0));
				papPage.clickOnTask(papSubTaskNames.get(1));
				papPage.enterResearchDetails(alternateCoverage.get(1), ExcelTestData.get(rxPayerName),
						ExcelTestData.get(officePhone));
				quickStartPage.clickOnNextButton();
				papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
				quickStartPage.clickOnSubmitButton();
				refresh();

				Logger("STEP 49: Open 'Confirm PAP eligibility'  Task");
				papPage.clickOnPAPTask();
				papPage.clickOnMainTask(papMainTaskNames.get(1));
				papPage.clickOnTask(papSubTaskNames.get(4));

				Logger("STEP 50: Enter eligibilty Check");
				papPage.enterEligibilityCheckEligible();
				papPage.verifyLISNotMandatory();

				Logger("STEP 51: Click on next Button");
				quickStartPage.clickOnNextButton();

				Logger("STEP 52: Verify that PAP Eligibility Outcome field is populated as Eligible only for the combinations given in the table ->Enter the Outcome Value as Approved and Click on Next");
				papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
				quickStartPage.clickOnNextButton();

				Logger("STEP 53: In the Order Details page, Select the Order details and Selected Documents and Click on Submit.");
				iapPage.verifyTaskIsLoaded(taskTitle.get(3));
				quickStartPage.enterOrderDetails();
				quickStartPage.checkAttachCheckbox();
				quickStartPage.clickOnSubmitButton();
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();

				Logger("STEP 54: Verify PAP CPEP Record created");
				accountObject.clickOnTab(tabsName.get(1));
				iapPage.navigateToCPEPTable();
				careProgram.clickOnViewAll("Care Program Enrollee Products");
				iapPage.navigateToCPEPRecord("PAP");

				Logger("STEP 55:Navigate back to CPE > click on the  related > Navigate to Orders section > verify the order is created");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				accountObject.clickOnTab(tabsName.get(1));
				iapPage.navigateToOrdersTable();
				careProgram.clickOnViewAll("Orders");
				iapPage.verifyOrderCreated("PAP");

				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();

				Logger("STEP 56: Click on Start New Service and Initiate the PAP Work Order by selecting service as PAP and select any reason from the Picklist and click on Save\r\n");
				iapPage.clickOnStartNewService();

				Logger("STEP 57: User will see two fields: 1. Start Service : Pick the value as \"PAP\" 2. Reason: Any one");
				iapPage.verifyServiceTitle();
				papPage.selectService();
				missingInformatioPage.clickNextButton();
				iapPage.checkAttestationcheckboxIfPresent();
				papPage.selectReason(papOptions.get(2));

				Logger("STEP 58: Click on Save button");
				missingInformatioPage.clickOnSaveButton();
				refresh();

				Logger("STEP 59: Validate PAP WO is initiated and Click on PAP WO");
				papPage.checkPAPWOIntiation();
				papPage.checkPAPTaskInitiation();

				Logger("STEP 60: From PAP Open Alternate Coverage Task >> Open Pre-check subtask and validate all the fields are populated");
				papPage.clickOnTask("Pre-Check");
				quickStartPage.verifyTaskIsLoaded(taskTitle.get(6));

				Logger("STEP 61: Click on Pre Check Task and select the Coverage Situation Value as Med Part D - Financial hardship/ Med Part D - Potentially LIS->Click on Submit");
				papPage.enterCoverageSituation(coverageSituation.get(3));
				quickStartPage.clickOnSubmitButton();
				refresh();

				Logger("STEP 62: In Research Task, Enter the value in the Alternate Research identified field as No->Click on Submit");

				papPage.clickOnPAPTask();
				papPage.clickOnMainTask(papMainTaskNames.get(0));
				papPage.clickOnTask(papSubTaskNames.get(1));
				papPage.enterResearchDetails(alternateCoverage.get(1), ExcelTestData.get(rxPayerName),
						ExcelTestData.get(officePhone));
				quickStartPage.clickOnNextButton();
				papPage.enterCoverageOutcome(alternateCovOutcome.get(1));
				quickStartPage.clickOnSubmitButton();
				refresh();

				Logger("STEP 63: Open 'Confirm PAP eligibility'  Task");
				papPage.clickOnPAPTask();
				papPage.clickOnMainTask(papMainTaskNames.get(1));
				papPage.clickOnTask(papSubTaskNames.get(4));

				Logger("STEP 64: Enter eligibilty Check");
				papPage.enterEligibilityCheckEligible();
				papPage.verifyLISNotMandatory();

				Logger("STEP 65: Click on next Button");
				quickStartPage.clickOnNextButton();

				Logger("STEP 66: Verify that PAP Eligibility Outcome field is populated as Eligible only for the combinations given in the table ->Enter the Outcome Value as Approved and Click on Next");
				papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
				quickStartPage.clickOnNextButton();

				Logger("STEP 67: In the Order Details page, Select the Order details and Selected Documents and Click on Submit.");
				iapPage.verifyTaskIsLoaded(taskTitle.get(3));
				quickStartPage.enterOrderDetails();
				quickStartPage.checkAttachCheckbox();
				quickStartPage.clickOnSubmitButton();
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				refresh();

				Logger("STEP 68: Verify PAP CPEP Record created");
				accountObject.clickOnTab(tabsName.get(1));
				iapPage.navigateToCPEPTable();
				careProgram.clickOnViewAll("Care Program Enrollee Products");
				iapPage.navigateToCPEPRecord("PAP");

				Logger("STEP 69:Navigate back to CPE > click on the  related > Navigate to Orders section > verify the order is created");
				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
				accountObject.clickOnTab(tabsName.get(1));
				iapPage.navigateToOrdersTable();
				careProgram.clickOnViewAll("Orders");
				iapPage.verifyOrderCreated("PAP");

				missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

				Logger("STEP 70: User Logout the Application.");
				documentsPage.logout();

			} catch (Exception e) {
				Logger("Test failed for user " + user + " due to error: " + e.getMessage());
				documentsPage.logout();
			}
		}

		softassert.assertAll();

	}*/
  
  
  
  
}