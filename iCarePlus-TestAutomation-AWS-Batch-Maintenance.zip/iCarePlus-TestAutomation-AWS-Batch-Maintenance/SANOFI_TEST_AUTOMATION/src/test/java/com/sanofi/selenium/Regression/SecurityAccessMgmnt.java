package com.sanofi.selenium.Regression;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.AuthorizationFormConsentPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.HealthcareAccountSearch;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;

public class SecurityAccessMgmnt extends BaseTest {
	public String filePath;
	public ReadExcel excel;
	public String fileName;
	String functionality = "SecurityAccessMgmnt";


	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		authorizationConsentPage = GetInstance(AuthorizationFormConsentPage.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		sheetName = "SecurityAccessMgmnt";
		excel = new ReadExcel(sheetName);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		uploadDocs = GetInstance(UploadDocument.class);
		triagePage = GetInstance(TriagePage.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		hcAccountSearch = GetInstance(HealthcareAccountSearch.class);

	}


	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE- 6275 To Verify Case Record type are visible to different
	 * Personas
	 * 
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "To Verify Case Record type are visible to different Personas", enabled = true)
	public void SAM01_IC6275_To_Verify_Case_Record_type_are_visible_to_different_Personas() throws Exception {

		Logger("STEP 1:Login to the SIT Org as 'Case Manager User");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Cases' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5), DocumentPage.class);
		refresh();

		Logger("STEP 3: Verify Case Manager is able to Read and edit these Injection Training Case Record Type");
		documentsPage.navigateNurseEducatorsListView();
		accountObject.clickOnFirstCase();
		refresh();
		documentsPage.clickonEditButton();

		// Injection Training Case
		Logger("STEP 4: Verify Case Manager is able to create 'Injection Training' Case Record Type(RT) ");
		missingInformatioPage.clickOnSaveAndNewButton();
		missingInformatioPage.verifyNewCaseTitle();
		missingInformatioPage.clickCaseType(caseTypes.get(1));
		documentsPage.clickOnNextButton();
		documentsPage.verifyNewCaseTitle();
		missingInformatioPage.clickOnCancelButton();

		documentsPage.clickonEditButton();

		Logger("STEP 5: Verify Case Manager is able to create 'Missing Information' Case Record Type(RT) ");
		missingInformatioPage.clickOnSaveAndNewButton();
		missingInformatioPage.verifyNewCaseTitle();
		missingInformatioPage.clickCaseType(caseTypes.get(0));
		documentsPage.clickOnNextButton();
		missingInformatioPage.clickOnCancelButton();

		documentsPage.clickonEditButton();

		Logger("STEP 6: Verify Case Manager is able to create 'Welcome Message' Case Record Type(RT) ");
		missingInformatioPage.clickOnSaveAndNewButton();
		missingInformatioPage.verifyNewCaseTitle();
		missingInformatioPage.clickCaseType(caseTypes.get(2));
		documentsPage.clickOnNextButton();
		missingInformatioPage.clickOnCancelButton();
		documentsPage.clickonEditButton();

		Logger("STEP 7: Verify Case Manager is able to create 'Order Follow up' Case Record Type(RT) ");
		missingInformatioPage.clickOnSaveAndNewButton();
		missingInformatioPage.verifyNewCaseTitle();
		missingInformatioPage.clickCaseType(caseTypes.get(3));
		documentsPage.clickOnNextButton();
		missingInformatioPage.clickOnCancelButton();

		Logger("STEP 8: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 9:Login to the SIT Org as 'BV User");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
		homeportalPage.closeTabs();

		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5), DocumentPage.class);
		refresh();
		// Missing Information
		Logger("STEP 10: Click on any Case");
		accountObject.clickOnFirstCase();
		documentsPage.clickonEditButton();

		Logger("STEP 11: Verify Case Manager is able to create 'Missing Information' Case Record Type(RT) ");
		missingInformatioPage.clickOnSaveAndNewButton();
		missingInformatioPage.verifyNewCaseMITitle();

		Logger("STEP 12: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 13:Login to the SIT Org as 'PM User");
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);

		Logger("STEP 14: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Cases' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5), DocumentPage.class);
		documentsPage.navigateNurseEducatorsListView();
		accountObject.clickOnFirstCase();
		refresh();
		documentsPage.clickonEditButton();
		missingInformatioPage.clickOnSaveAndNewButton();

		Logger("STEP 15:Verify all cases record types  Missing Information, Injection training,Welcome Correspondence, Order follow up are visible to PM User");
		missingInformatioPage.clickCaseType(caseTypes.get(0));
		missingInformatioPage.clickCaseType(caseTypes.get(1));
		missingInformatioPage.clickCaseType(caseTypes.get(2));
		missingInformatioPage.clickCaseType(caseTypes.get(3));

		Logger("STEP 16: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 17:Login to the SIT Org as 'PC User' ");
		homeportalPage = loginPage.userLogin(PCUserName, UserPassword);

		Logger("STEP 18: Navigate to CPE >> Open any record ");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5), DocumentPage.class);
		refresh();
		
		Logger("STEP 19:  Click on any Case");
		accountObject.clickOnFirstCase();
		documentsPage.clickonEditButton();
		missingInformatioPage.clickOnSaveAndNewButton();

		Logger("STEP 20:Verify all cases record types  Missing Information, Injection training,Welcome Correspondence, Order follow up are visible to PC User");
		missingInformatioPage.clickCaseType(caseTypes.get(0));
		missingInformatioPage.clickCaseType(caseTypes.get(1));
		missingInformatioPage.clickCaseType(caseTypes.get(2));
		missingInformatioPage.clickCaseType(caseTypes.get(3));

		Logger("STEP 21: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 22:Login to the SIT Org as 'NE User' ");
		homeportalPage = loginPage.userLogin(NurseEduUserName, UserPassword);

		Logger("STEP 23: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Cases' Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5), DocumentPage.class);
		documentsPage.navigateNurseEducatorsListView();
		accountObject.clickOnFirstCase();
		refresh();
		documentsPage.clickonEditButton();
		missingInformatioPage.clickOnSaveAndNewButton();

		Logger("STEP 24:Verify user is able to Access and create this Case RT Injection training as Nurse Educator User");
		missingInformatioPage.clickCaseType(caseTypes.get(1));
		documentsPage.clickOnNextButton();
		missingInformatioPage.clickOnCancelButton();

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();

	}

}
