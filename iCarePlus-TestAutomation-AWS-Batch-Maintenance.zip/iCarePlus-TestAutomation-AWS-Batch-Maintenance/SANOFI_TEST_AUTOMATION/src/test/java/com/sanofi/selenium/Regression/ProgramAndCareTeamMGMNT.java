package com.sanofi.selenium.Regression;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.CareTeamAssignment;
import com.sanofi.selenium.pages.CopayFlow;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.HealthcareAccountSearch;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PAPPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;

public class ProgramAndCareTeamMGMNT extends BaseTest {

	public String filePath;
	public String filePath2;
	public ReadExcel excel;
	public String fileName;
	String functionality = "ProgramAndCareTeamMGMNT";

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		sheetName = "ProgramAndCareTeamMGMNT";
		excel = new ReadExcel(sheetName);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		uploadDocs = GetInstance(UploadDocument.class);
		triagePage = GetInstance(TriagePage.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		hcAccountSearch = GetInstance(HealthcareAccountSearch.class);
		papPage = GetInstance(PAPPage.class);
		copayFlow = GetInstance(CopayFlow.class);
		careTeamAsgn = GetInstance(CareTeamAssignment.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		accountObject = GetInstance(AccountObject.class);

	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	@Test(description = "To Validate auto-inactivation of CPE on Inactivation of Patient - Duplicate", enabled = true)
	public void PCTM01_IC13517_Validate_auto_inactivation_of_CPE_when_Patient_is_inactivated_due_to_Duplicate()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC1";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		// Pre-requisite
			Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);

		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 1:Log in to Org using BO User");
		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);

		navigateToUrl(cpeURL);
		
	//String urlspe = "https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf0000007aI5CAI/view";
	//navigateToUrl(urlspe);

		Logger("STEP 2: Validate if Status is in Active State.Also, validate if Inactivation Reason field is visible and is initially blank.");
		String status = "Active";
		careProgram.checkStatusOfCPERecord(status);
		careProgram.checkReasonField("");

		Logger("STEP 3: Go to Patient Account and Validate if Patient is Active.");
		docMgmt.navigateToAccount();
		accountObject.verifyStatusField(status);

		Logger("STEP 4:Click on Account Status Update Button, Select the Status as Duplicate. Validate if user is prompted to add Winner Patient. Click Next.");
		accountObject.clickOnAccountStatusUpdate();
		status = "Duplicate";
		accountObject.selectStatus(status);
		String patient = accountObject.selectWinnerPatient();

		Logger("STEP 5: Validate if user is getting prompt message for confirmation saying This will inactivate the patient and remove it from all the Care Programs. Do you wish to Continue? when user attempt to save the status of patient as Duplicate.Validate if options consist of Yes and No.");
		accountObject.validateConfirmationStatusAndValues();

		Logger("STEP 6: Select No in the Prompt message and click Next. Validate if Patient Account status remains unchanged.");
		String option = "No";
		accountObject.confirmAccountStatusUpdate(option);
		status = "Active";
		accountObject.verifyStatusField(status);

		Logger("STEP 7: Now again mark the status of patient as Duplicate and Select Yes in the Prompt message and click Next.");
		accountObject.clickOnAccountStatusUpdate();
		status = "Duplicate";
		accountObject.selectStatus(status);
		patient = accountObject.selectWinnerPatient();
		option = "Yes";
		accountObject.confirmAccountStatusUpdate(option);

		Logger("STEP 8: Validate if Patient Account status gets updated as Duplicate. Click Edit Button on Patient Account and validate if Status field and Winner Patient field is read only and user should not be able to update the Status back to Active.");
		accountObject.verifyStatusField(status);
		accountObject.validatePatientAccountFieldIsReadOnly(patient);
		accountObject.clickOnSave();

		Logger("STEP 9: Navigate to Patient Account Related Tab and open Pharmacy Record from Member Plan Object and Validate if status is updated to Inactive.");

		String expectedStatus = "Inactive";

		// Navigate to Pharmacy record and validate status
		accountObject.clickOnMemberPlan();
		accountObject.clickOnMemberPlanRecord(ExcelTestData.get(rxPayerName));
		accountObject.verifyStatusField(expectedStatus);

		Logger("STEP 10: Navigate to Patient Account Related Tab and open Medical Record from Member Plan Object and Validate if status is updated to Inactive.");

		// Navigate to Medical record and validate status
		missingInformatioPage.navigateToCPERecord("Member Plans");
		accountObject.clickOnMemberPlanRecord(ExcelTestData.get(medicalPayerName));
		accountObject.verifyStatusField(expectedStatus);
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
		Logger("STEP 11: Under Medication Request Object, validate if status of all the Medication Request Record is updated to ‘Cancelled’");
		expectedStatus = "Cancelled";
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateMedicationRequests();
		accountObject.clickonFirstMedicationRequest();
		accountObject.verifyStatusField(expectedStatus);
		// Navigate to second Medical record and validate status
		missingInformatioPage.navigateToCPERecord(cpeName);
		accountObject.clickonSecondMedicationRequest();
		accountObject.verifyStatusField(expectedStatus);

		Logger("STEP 12: Navigate back to CPE record and validate if the Status of CPE is automatically updated as Inactive. Also, validate if Inactivation Reason field is visible, and its value is auto populated to Duplicate Patient.");
		status = "Inactive";
		missingInformatioPage.navigateToCPERecord(cpeName);
		careProgram.checkStatusOfCPERecord(status);
		String reason = "Duplicate patient";
		careProgram.checkReasonField(reason);

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE18012 -RGN-P2-PCTM: Automate ICARE-12393:SIT:TC01:
	 * Validating CPE Reactivation Logic for Inactive CPE with Inactivation Reason =
	 * Unable to Contact
	 * 
	 * @author Shanavaz Nishani , date- 4/29/2025
	 * @Maintenance_author Trupti
	 *                     ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "ICARE-12393:SIT:TC01: Validating CPE Reactivation Logic for Inactive CPE with Inactivation Reason = Unable to Contact", enabled = true)
	public void PCTM02_IC13741_Validating_CPE_Reactivation_Logic_for_Inactive_CPE_with_Inactivation_Reason_Unable_to_Contact()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC11";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "J33.0 - Polyp of nasal cavity" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(0).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Nasal Polyps");
			filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

			Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.clearTextFromDateField();
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 17: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);

		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		Logger("STEP 18: Logout as DIS User");
		documentsPage.logout();
		
		Logger("STEP 19: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 20:Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care Program Enrollee'Object.");
		homeportalPage.closeTabs();
		navigateToUrl(cpeURL);

		// Pre requisite -Update MI case status to Not collected
		String miSubjectName = "Patient DOB";
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.clickOnMICase(miSubjectName);
		missingInformatioPage.selectStatusNotCollcted();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 21: Access CPE record with Status= Inactive and Inactivation Reason=Unable to Contact");
		
		triagePage.clickOnCPEStatusUpdate();
		triagePage.selectCPEStatus(statusCPEP.get(1));
		triagePage.selectInactivationReason(inactivationReason.get(0));
		missingInformatioPage.clickNextButton();
		triagePage.selectUnenrollPatBox("Yes");
		missingInformatioPage.clickNextButton();
		refresh();
		careProgram.checkStatusOfCPERecord(statusCPEP.get(1));
		careProgram.checkReasonField(inactivationReason.get(0));

		Logger("STEP 22: Navigate to CPEP Related list of CPE record.");
		navigateToUrl(cpeURL);
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");

		Logger("STEP 23: Open Dupixent CPEP record and Click on Edit button.Then Click on SAVE& NEW from bottom and Create MobileApp CPEP record.");

		String productName = "MobileApp " + careProgramProduct.get(0).split("-")[0].trim();
		documentsPage.clickOnEditButton();
		triagePage.clickOnSaveandNewBtn();
		triagePage.selectNewCPEProduct(cpepProductName.get(0));
		missingInformatioPage.clickNextButton();
		triagePage.createCPEPMobileProduct(cpepProductName.get(0), ExcelTestData.get(patientName), productName,
				statusCPEP.get(0));

		Logger("STEP 24: Navigate to Care Program Enrollee Product Related List of CPE record. Verify Dupixent and MobileApp CPEP Status is Inactive");
		refresh();
		navigateToUrl(cpeURL);
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		refresh();
		triagePage.validateCPEPstatus(cpepProductName.get(1), statusCPEP.get(2));
		triagePage.validateCPEPstatus(cpepProductName.get(0), statusCPEP.get(2));

		Logger("STEP 25: Click on Correspondence Button from Compact Layout of CPE. Select Business process as PAP");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		docMgmt.clickOnCorrespondenceBotton();
		docMgmt.selectProcessName(processName.get(6));
		triagePage.validteCorrespondenceRecordsPicklist();

		Logger("STEP 26: Navigate MI tab -> Do not Collect Critical MI Cases Click on CPE Status Update Button from Compact Layout of CPE.");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		triagePage.clickOnCPEStatusUpdate();

		Logger("STEP 27: Update Status as Active in Picklist and Click on Next button.");
		triagePage.selectCPEStatus(statusCPEP.get(0));
		missingInformatioPage.clickNextButton();
		docMgmt.verifyErrorMessage("Please collect the MI before Re-activating the CPE");
		copayFlow.clickOnFinishButton();

		Logger("STEP 28: Navigate to MI Cases tab of CPE record. Collect Open MI Case on CPE record");
		accountObject.clickonAccount(ExcelTestData.get(patientName));
		docMgmt.clcikOnEditbtn("Birthdate");
		docMgmt.editDOB();
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.MIcasesStatusUpdate("Closed Cases", statusOptionsMIOpenCases.get(4));
		refresh();

		Logger("STEP 29: Validate CPE Status is Updated to Active and Inactivation Reason field gets updated to Blank");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		careProgram.checkStatusOfCPERecord(statusCPEP.get(0));
		careProgram.checkReasonField("");

		Logger("STEP 30: Navigate to CPEP related list of CPE record. Verify Dupixent CPEP and MobileApp CPEP record Status gets updated to Active on CPE Re-activation");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll("Care Program Enrollee Products");
		refresh();
		triagePage.validateCPEPstatus(cpepProductName.get(1), statusCPEP.get(0));
		triagePage.validateCPEPstatus(cpepProductName.get(0), statusCPEP.get(0));

		Logger("STEP 31: Click on Correspondence Button from Compact Layout of CPE. Verify User is Navigated to Correspondence Screen ");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// Pre- requiste for Correspondence - Update member plans status to active
		// status
		// Rx payer
		accountObject.clickonAccount(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.clickOnMemberPlan();
		docMgmt.changeMemberPlanStatusActive(ExcelTestData.get(rxPayerName));
		missingInformatioPage.clickOnSaveButton();

		// Medical Payer
		missingInformatioPage.navigateToCPERecord("Member Plans");
		docMgmt.changeMemberPlanStatusActive(ExcelTestData.get(medicalPayerName));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		docMgmt.clickOnCorrespondenceBotton();

		Logger("STEP 32: Select Process Name as PAP and DMW PAP Approval Medicare Enrollee- Payer Fax as the Template from Select to Send item picklist. Click on Next");
		docMgmt.selectProcessName(processName.get(6));
		docMgmt.selectItemsToSend(papItemsToSend.get(2));

		Logger("STEP 34: On Generate Document Stage, Click on Send Button from the Bottom of Generated Document.");
		missingInformatioPage.clickNextButton();
		docMgmt.clickSendButtonUntilFinish();

		Logger("STEP 35: Click on Finish button on Confirmation Screen");
		docMgmt.clickonFinishButton();

		Logger("STEP 36: Navigate to Correspondence Related List from Related tab of CPE. Verify Correspondence Record is created");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCorrespondenceTable();
		careProgram.clickOnViewAll("Correspondences");
		docMgmt.verifyCorrespondenceRecord(processName.get(6));

		Logger("STEP 37: On CPE, Click on Start New Service and Select Service as IAP and any select any from Reason picklist. Click on SAVE");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		iapPage.clickOnStartNewService();
		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.selectReason();
		missingInformatioPage.clickOnSaveButton();
		refresh();
		iapPage.checkIAPIntiation();

		Logger("STEP 38: Logout from the application");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-13364 -To Validate auto-inactivation of CPE on
	 * Inactivation of Patient - Inactive
	 * 
	 * @author Kavyashree MB
	 * @Maintenance_author Trupti
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "To Validate auto-inactivation of CPE on Inactivation of Patient - Inactive", enabled = true)
	public void PCTM03_IC13364_To_Validate_auto_inactivation_of_CPE_on_Inactivation_of_Patient_Inactive()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC5";
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_CareTeam);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("STEP 1: Log in to QAEnh Org using BO User");
		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);

		Logger("STEP 2: Navigate to App Launcher and go to Accounts Object. Click on New Button ");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(3), DocumentPage.class);
		accountObject.clickOnNew();

		Logger("STEP 3: Select Account type as patient. Fill required Patient Details and Click Save.");
		accountObject.selectPatient();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientLastName = name[2];
		accountObject.VerifyToEnterPatientDetails(patientFirstName, patientLastName);
		accountObject.clickOnSave();

		Logger("STEP 4: Go to newly created Patient Account and Validate if Status of Patient is Active.");
		String accountstatus = "Active";
		accountObject.verifyStatusField(accountstatus);
//
//		Logger("STEP 5: Click on Account Status Update Button, Select the Status as Inactive. Validate if user is not prompted to add Winner Patient. Click Next.");
//		accountObject.clickOnAccountStatusUpdate();
//		accountObject.selectStatus(statusCPEP.get(1));
//		accountObject.clickOnNext();
//
//		Logger("STEP 6:  Validate if user is getting prompt message for confirmation text and Validate if options consist of Yes and No.");
//		accountObject.validateConfirmationStatusAndValues();

//		Logger("STEP 7: Select No in the Prompt message and validate if Patient Account status remains unchanged.");
//		accountObject.confirmAccountStatusUpdate(listOptions.get(1));
//		accountObject.verifyStatusField(statusCPEP.get(0));
//
//		Logger("STEP 8: Now again mark the status of patient as Inactive and Select Yes in the Prompt message and Click Next");
//		accountObject.clickOnAccountStatusUpdate();
//		accountObject.selectStatus(statusCPEP.get(1));
//		accountObject.clickOnNext();
//		accountObject.confirmAccountStatusUpdate(listOptions.get(0));
//
//		Logger("STEP 8: click Edit Button on Patient Account and validate if Status field and Winner Patient field is read only and user should not be able to update the Status back to Active.");
//		accountObject.validateStatusAndWinnerPatientIsReadOnly();
//		accountObject.clickCancelButtonOnEditAccount();

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		// Pre-requisite
		Logger("STEP 10:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 11:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 12: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 13:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 14:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 15:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 16:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		

		Logger("STEP 17: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String patientMidName = name[1];
		Logger("STEP 18: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 19:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 20:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 21:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 22:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 23:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 24:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 25:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 26: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);

		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		Logger("STEP 27: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 28:Log in to Org using BO User");
		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);

		navigateToUrl(cpeURL);

		Logger("STEP 29: Validate if Status is in Active State.Also, validate if Inactivation Reason field is visible and is initially blank.");
		String status = "Active";
		careProgram.checkStatusOfCPERecord(status);

		Logger("STEP 30: Go to Patient Account and Validate if Patient is Active.");
		docMgmt.navigateToAccount();

		Logger("STEP 31: Go to newly created Patient Account and Validate if Status of Patient is Active.");
		accountObject.verifyStatusField(accountstatus);

		Logger("STEP 32: Now again mark the status of patient as Inactive and Select Yes in the Prompt message and Click Next");
		accountObject.clickOnAccountStatusUpdate();
		accountObject.selectStatus(statusCPEP.get(1));
		accountObject.clickOnNext();
		accountObject.confirmAccountStatusUpdate(listOptions.get(0));

		Logger("STEP 33: click Edit Button on Patient Account and validate if Status field and Winner Patient field is read only and user should not be able to update the Status back to Active.");
		accountObject.validateStatusAndWinnerPatientIsReadOnly();
		accountObject.clickCancelButtonOnEditAccount();

		Logger("STEP 34: Navigate to Patient Account Related Tab and open Pharmacy Record from Member Plan Object and Validate if status is updated to Inactive.");

		String expectedStatus = "Inactive";

		// Navigate to Pharmacy record and validate status
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.clickOnMemberPlan();
		accountObject.clickOnMemberPlanRecord(ExcelTestData.get(rxPayerName));
		accountObject.verifyStatusField(expectedStatus);

		Logger("STEP 35: Navigate to Patient Account Related Tab and open Medical Record from Member Plan Object and Validate if status is updated to Inactive.");

		// Navigate to Medical record and validate status
		missingInformatioPage.navigateToCPERecord("Member Plans");
		accountObject.clickOnMemberPlanRecord(ExcelTestData.get(medicalPayerName));
	accountObject.verifyStatusField(expectedStatus);
		missingInformatioPage.navigateToCPERecord(cpeName);

		Logger("STEP 36: Under Medication Request Object, validate if status of all the Medication Request Record is updated to ‘Cancelled’");
		expectedStatus = "Cancelled";
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateMedicationRequests();
		accountObject.clickonFirstMedicationRequest();
		accountObject.verifyStatusField(expectedStatus);
		// Navigate to second Medical record and validate status
		missingInformatioPage.navigateToCPERecord(cpeName);
		accountObject.clickonSecondMedicationRequest();
		accountObject.verifyStatusField(expectedStatus);

		Logger("STEP 37: User Logout the Application.");
		documentsPage.logout();

	}

	@Test(description = "ICARE-13479 Regression-Missing Info Mgmnt: Automate MI Cases are created for Caregiver/Legal Representative if Patient is a minor", enabled = true)
	public void CP06_IC4618_iCare2797_SAT_TC01_Validate_the_Welcome_Message_Case_and_Welcome_Correspondence()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC6";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy",
				"Prescription 5B Quick Start", "Specialty", "Prescriber Zip", "Patient DOB",
				"Patient Authorization Date", "Prescriber Address", "Prescriber City", "Prescriber State",
				"Prescriber NPI", "Site/facility name", "Office Phone", "Office Contact Name", "Office Contact Email" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "FALSE", "TRUE",
				"ALLERGY", "32839", "01-16-2000", "05-01-2024", "Joe Lewis", "139 Front Street", "Los Angeles",
				"South Carolina", "Mount Sinai Medical Center", "(193) 853-7839", "Alice Emily",
				"aliceemily@gmail.com" };
		// String removeColumnData[] = { "Legal Representative Name","Relationship",
		// "Specialty Pharmacy Name"};

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		// excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the VAL Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 3.1: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 3.2: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 4: On Classify document page select Doc type = Enrollment Form > Click on submit.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 4.1: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4.2: Enter the CARE PROGRAM PRODUCT > Click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 4.3: In Patient Information & Authorizations pg enter all the mandatory details of the patient.");

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 4.4: Enter all the mandatory details in the Insurance Information section > Click on next.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		// insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 4.5: In the Prescriber Information section fill the  details and Select HCP and HCO via Search Functionality> click on next.");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		System.out.println(ExcelTestData.get(prescriberZip));
		System.out.println(ExcelTestData.get(specialty));
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		// careTeamAsgn.selectHCPrecord(ExcelTestData.get(prescriberName),ofcLastName);
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 4.6: In the Diagnosis Information fill all the mandatory details > click on next.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 4.7:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 5: Click on Submit and Enrollment Form should be submitted");
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 6:  Navigate to CPE record and Verify Case Manager and Field Reimbursement Manager are assigned.");
		accountObject.navigateToCareProgramEnrollee();
		assessmentTasksPage.verifyRecentlyViewList();
		documentsPage.searchDocument(cpeName);
		missingInformatioPage.clickOnRecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		// Logger("STEP 8: Logout AS DIS and Login as CM User.");
		// documentsPage.logout();
		// homeportalPage = loginPage.userLogin(CMUserName, CMPassword);

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 20: Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);
		Thread.sleep(4000);

		Logger("STEP 21: Change List view to 'All BV worklist' queue list view.");
		assessmentTasksPage.verifyRecentlyViewList();
		assessmentTasksPage.navigateToAllBVWorklist();

		Logger("STEP 22: Select the care program enrollee record and click on Assign to me button and verify the record is displayed under 'My Assestement Task'");
		String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
		assessmentTasksPage.openCPETask(createdDate);

		// Benefits Verification
		Logger("STEP 23: Open Review and finalize task under Benefits Verification ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("STEP 24: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("STEP 25: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(0), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 28: Click on PA/Appeal work order ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));

		Logger("STEP 29: Open \"Follow up on Results\" task and enter mandatory details and outcome as approved and click on save ");
		paAppealsPage.enterMandatoryPAAppealDetails(paStatus.get(0), payerContact.get(0), attempts.get(0),
				hcpFollowUpRequired.get(0), receiptRequired.get(1), ExcelTestData.get(policyholderName));
		paAppealsPage.enterOutcomeAndOutcomeReason(pAOutcomeOptions.get(1), PAOutcomeReason.get(0));
		String effectiveDate = Utility_Function.getNthDayFromToday(10);
		String expirationDate = Utility_Function.getNthDayFromToday(15);
		paAppealsPage.enterMandatoryPAApprovedDetails(effectiveDate, paDosage.get(0), expirationDate);
		careProgram.clickOnSave();

		// CPE URL
		String url = getCurrentPageURL();

		Logger("STEP 30: Logout of the application as BV user.");
		documentsPage.logout();

		Logger("STEP 31: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		navigateToUrl(url);
		Thread.sleep(4000);

		Logger("STEP 32: open HCP follow up task ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(2));

		Logger("STEP 33: Mark status as completed and enter mandatory details click on save");
		paAppealsPage.selectDropdownValue("Status", paStatus.get(1));
		paAppealsPage.enterHCPFollowUpDetailsIntent(hcpContact.get(1), attempts.get(0),
				ExcelTestData.get(officeContactName), intentOfSubmission.get(1));
		careProgram.clickOnSave();

		Logger("STEP 34: Follow up on result task and change status to completed ");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(0));
		careProgram.clickOnSubTask(paSubTaskNames.get(0));
		paAppealsPage.changeStatusToCompleted(StatusCheck.get(1));
		careProgram.clickOnSave();

		Logger("STEP 35: Navigate to PA summary task \"Communicate Results & Send SOB\" enter hcp contact details and save");
		careProgram.clickOnWorkOrderTask(workOrderName.get(1));
		careProgram.clickOnMainTask(paMainTaskNames.get(1));
		careProgram.clickOnSubTask(paSubTaskNames.get(1));
		paAppealsPage.enterHCPContactDetails(paStatus.get(1), hcpContact.get(0), ExcelTestData.get(prescriberName),
				attempts.get(0), intentOfSubmission.get(0));
		careProgram.clickOnSave();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		// Quick Start initialization

		Logger("STEP 36: Navigate to Quick Start and verify flow has initiated");
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();

		Logger("STEP 8.2: Click on Enrollment task");
		quickStartPage.clickOnTask();

		Logger("STEP 8.3: Enter Eligibility Criteria and click on Next button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 8.4: Enter Eligibility outcome and click on next button ");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome("Eligible");
		missingInformatioPage.clickNextButton();

		Logger("STEP 8.5: Verify Correspondence task is loaded and click on next button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(2));
		missingInformatioPage.clickNextButton();

		Logger("STEP 8.6: Enter order details and click on submit button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.clickOnSubmitButton();

		Logger("STEP 8.7: Click on quick start button and verify task compltion status");
		quickStartPage.clickOnQuickStart();
		quickStartPage.checkQuickStartTaskComplition();

		Logger("STEP 30: Logout of the application as CM user.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE_13516_18016 :To Validate Inactivation Reason field is
	 * visible when CPE is marked as Inactive
	 * 
	 * @author Tejal
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test
	public void CP01_ICARE_13516_To_Validate_Inactivation_Reason_field_is_visible_when_CPE_is_marked_Inactive()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC9";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Specialty Pharmacy Name",
				"Pharmacy Phone", "Pharmacy Fax", "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "Automation Correspondence SP", "(954) 312-1432",
				"(982) 053-8606", "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 17:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));

		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);

		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(CPEURL);
		Thread.sleep(2000);
		careProgram.checkStatusOfCPERecord(cpeStatus.get(0));
		careProgram.checkInactivationReasonIsBlank();
		docMgmt.clickOnshowMoreActionsButton();
		docMgmt.clickOnCPEStatusButton();
		docMgmt.selectCPEStatus(cpeStatus.get(1));
		docMgmt.clickOnInactivationReason(InactivationReasons.get(0));
		documentsPage.clickOnNextButtonInCM();
		docMgmt.selectUnenrollPatBox(listOptions.get(0));
		documentsPage.clickOnNextButtonInCM();
		careProgram.checkStatusOfCPERecord(cpeStatus.get(1));
		documentsPage.validateInactivationReasonIsPopulated(InactivationReasons.get(0));
		docMgmt.clickOnCPEStatusButton();
		docMgmt.selectCPEStatus(cpeStatus.get(0));
		documentsPage.clickOnNextButtonInCM();
		careProgram.checkStatusOfCPERecord(cpeStatus.get(0));
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: R4-OM Automate ICARE-17270 -- ICARE-13090: SIT-TC01:
	 * To Validate Status Update on SP Order when Order Fax is Sent Non-Alliance
	 * (Correspondence Status is Success)
	 * 
	 * @author Shanavaz Nishani , date- 06/25/2025
	 *         ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "ICARE-13090: SIT-TC01: To Validate Status Update on SP Order when Order Fax is Sent Non-Alliance (Correspondence Status is Success)", enabled = true)
	public void PCTM04_IC17270_To_Validate_Status_Update_on_SP_Order_when_Order_Fax_is_Sent_Non_Alliance_Correspondence_Status_is_Success()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC7";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

			Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-requisite STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
		Logger("Pre-requisite STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-requisite STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("Pre-requisite STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-requisite STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		// insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("Pre-requisite STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-requisite STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-requisite STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-requisite STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		String ID = assessmentTasksPage.navigateAndGetID();

		Logger("Pre-requisite STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("Pre-requisite STEP 14: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("Pre-requisite STEP 15: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("Pre-requisite STEP 17: Navigate to MI-Tab and change status of MI cases to collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.changeStatusOfMICases();
		String CPEURL = getCurrentPageURL();

		Logger("Pre-requisite STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("Pre-requisites 19::Login to the QA_SIT Org as 'BV Specialist'.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("Pre-requisites 20:Navigate to the App Launcher' Search and Open 'iCare Connec' App.From App Launcher, search and click on the 'Assestement Task'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);
		navigateToUrl(CPEURL);

		Logger("Pre-requisites 21: Verify BV Task is initiated");
		careProgram.clickOnWorkOrderTask(workOrderName.get(0));
		careProgram.clickOnMainTask(bvMainTaskNames.get(0));
		careProgram.clickOnSubTask(bvSubTaskNames.get(0));

		Logger("Pre-requisites 22: Verify and enter pharamcy details under member plan section");
		bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
				ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
				ExcelTestData.get(rxGroup));
		bvPage.clickOnSavePharmacy();

		Logger("Pre-requisites 23: Enter and save pharamcy details under coverage Benefit section");
		bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(2), pharmacyDeductiable.get(0),
				medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
		bvPage.clickOnCoverageBenefitSave();
		bvPage.clickOnCompleteButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		CPEURL = getCurrentPageURL();

		Logger("Pre-requisites 24: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 1: Login to the UAT as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		// Navigate to CPE URL
		Logger("STEP 2: Navigate to the CPE record created in above steps");
		navigateToUrl(CPEURL);

		Logger("Step 3: Complete Triage WO");
		triagePage.checkTraigeIntiation();
		triagePage.checkTriageTaskInitiation();
		careProgram.clickOnSubTask(triageSubTaskNames.get(0));
		missingInformatioPage.clickNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 3.1: Validate the  fields are populated on the Order created after Completing Triage WO. Status = Submitted, Order Type = Commercial, SP = Any Non-Alliance SP");
		triagePage.clickOnTraige();
		triagePage.checkTraigeTaskComplition();
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll(appLauncherMenuItem.get(8));
		triagePage.openOrderRec();
		triagePage.validateOrderDetailsValues(fieldNames.get(0), orderType.get(0));
		triagePage.validateOrderDetailsValues(fieldNames.get(1), order_Status.get(0));
		triagePage.validateOrderDetailsValues(fieldNames.get(2), SPtype.get(0));
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 4: Send Correspondence for \"DMW Non-Network Referral - SP Fax\" and Validate if Request Status = Success on generated Correspondence record.");

		docMgmt.clickOnCorrespondenceBotton();
		docMgmt.selectProcessName(processName.get(10));
		docMgmt.selectItemsToSend(TriageitemToSend.get(1));
		missingInformatioPage.clickNextButton();
		docMgmt.clickSendButtonUntilFinish();
		docMgmt.clickonFinishButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 5: Navigate to Order Record and open the most recent Commercial Order. Validate if Status field is updated to ‘Sent to SP’. ");
		accountObject.clickOnTab(tabsName.get(1));
		iapPage.navigateToOrdersTable();
		careProgram.clickOnViewAll(appLauncherMenuItem.get(8));
		triagePage.openOrderRec();
		refresh();

		// Status takes upto 5-15 mins to reflect as Sent to SP
		triagePage.validateSentToSP();
		String date = utilityPage.getCurrentDateInFormat("M/dd/yyyy");

		Logger("STEP 5.1: Validate Sent Date is populated from Received Date of Correspondence Record");
		triagePage.validateOrderDetailsValues(fieldNames.get(3), date);

		Logger("Step 6: User Logout the Application.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: Pre requisite for 16888 where CPE has to be made Inactive
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test
	public void Enrollment_PreRequisite_For_16888(String TestCaseNumber) throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Specialty Pharmacy Name",
				"Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy", "Prescription-5A Dose",
				"Prescription-5B Dose", "Relationship" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "Automation Correspondence SP",
				"L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE", "Dupixent 200 MG/1.14ML pre-filled syringe",
				"Dupixent 300 MG/2ML pre-filled syringe", "Caregiver" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-requisite STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		
		Logger("Pre-requisite STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-requisite STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("Pre-requisite STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-requisite STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-requisite STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-requisite STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-requisite STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-requisite STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);

		Logger("Pre-requisite STEP 11: CPE record is made Inactive");
		accountObject.clickCPEStatusDrpdwn("CPE Status Update");
		docMgmt.selectCPEStatus(cpeStatus.get(1));
		docMgmt.clickOnInactivationReason(InactivationReasons.get(2));
		documentsPage.clickOnNextButtonInCM();
		docMgmt.selectUnenrollPatBox(listOptions.get(0));
		documentsPage.clickOnNextButtonInCM();

		Logger("STEP : logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: R4-P&CTM Automate ICARE-16888 -- iCare15165:SIT:TC01:
	 * Validate System Updates when Enrolling an Existing Patient
	 * For the Same Indication as the Inactive CPE and with Different Enrollment
	 * Form Details
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "SIT:TC01:Validate System Updates when Enrolling an Existing Patient For the Same Indication as the Inactive CPE and with  Different Enrollment Form Details", enabled = true)
	public void PCTM_IC16888_Validate_System_Updates_when_Enrolling_an_Existing_Patient_For_the_Same_Indication_as_the_Inactive_CPE_and_with_Different_Enrollment_Form_Details()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC8";

		Enrollment_PreRequisite_For_16888(TestCaseNumber);

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		String cpeName = accountName + " - " + careProgramProduct.get(1).split(" -")[0];

		//// uploading the second form, to verify the CPE auto update functionality
		Map<String, String> ExcelTestData1 = new HashMap<String, String>();
		String TestCaseNumber1 = "TC9";
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName1[] = { "Prescription-5A RefillCaptured", "Prescription-B RefillCaptured",
				"Prescription-5A Dose",
				"Prescription-5B Dose", "Rx Payer Name", "Medical Payer Name", "Diagnosis Code",
				"Text Messaging Consent", "Voicemail", "Text", "Relationship" };
		String columnValue1[] = { "2", "2", "Dupixent 200 MG/1.14ML pre-filled pen",
				"Dupixent 300 MG/2ML pre-filled pen", "Payer Pharmacy TestAutomation", "Thera Medical LLC",
				"L20 - Atopic Dermatitis", "TRUE", "TRUE", "TRUE", "Caregiver" };

		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber1, columnName1, columnValue1);
		}

		ExcelTestData1 = excel.getExcelInputData(TestCaseNumber1);
		String cpeName1 = ExcelTestData1.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath = updatepdf.PDFCreation(TestCaseNumber1, functionality);
			updatepdf.updatePDFForm(TestCaseNumber1, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails1 = { ExcelTestData1.get(patientName), ExcelTestData1.get(patientDOB),
				ExcelTestData1.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID1 = uploadDocs.uploadDoc(filePath, cpeDetails1);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.1:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID1, status.get(1));
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 4: On Patient search Screen, Click on Product Indication field and select the same indication as the existing Patient with Inactive CPE");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name1 = updatepdf.splitFullName(ExcelTestData1.get(patientName));
		String patientFirstName1 = name1[0];
		String patientMidName1 = name1[1];
		String patientLastName1 = name1[2];

		Logger("STEP 5: Populate the First Name, last name, Patient DOB, Patient Phone,Zip fields with the data of the existing patient →Search & Select the Patient from the search box → Click on Next button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName1, patientLastName1,
				ExcelTestData1.get(documentTypeSelected), ExcelTestData1.get(patientEmail),
				ExcelTestData1.get(patientPrimaryphone), ExcelTestData1.get(zip), careProgramProduct.get(2),
				ExcelTestData1.get(patientDOB));

		// Existing Patient details
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		patientSearch.enterExistingPatientDetails(patientFirstName, patientLastName, ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail), ExcelTestData.get(zip), ExcelTestData.get(patientPrimaryphone));
		patientSearch.searchAndSelectExistingPat();

		Logger("STEP 6: In the patient Information and Authorization section, populate all the mandatory fields, Populate the email and phone number field with different details on the existing patient");
		String[] legalRepName1 = updatepdf.splitFullName(ExcelTestData1.get(legalRepresentativeName));
		String legalRepFirstName1 = legalRepName1[0];
		String legalRepLastName1 = legalRepName1[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName1, patientMidName1, patientLastName1,
				ExcelTestData1.get(patientDOB), ExcelTestData1.get(gender), ExcelTestData1.get(language),
				ExcelTestData1.get(patientAddress), ExcelTestData1.get(city), ExcelTestData1.get(state),
				ExcelTestData1.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData1.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData1.get(patientCertificationsDate),
				ExcelTestData1.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData1.get(patientEmail), ExcelTestData1.get(patientPrimaryphone),
				ExcelTestData1.get(voicemail), ExcelTestData1.get(text), ExcelTestData1.get(bestTimingAM),
				ExcelTestData1.get(bestTimingAfternoon), ExcelTestData1.get(bestTimingPM),
				ExcelTestData1.get(patientSecondaryphone));

		Logger("STEP 7: In the Legal Representative section, Populate the First Name, Last Name and Relationship field with the data that is different from the existing Caregiver.Click on Next");
		patientInfo.enterLegalRepDetails(legalRepFirstName1, legalRepLastName1, ExcelTestData1.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 8: In the insurance information section, Populate both Payer Name field on the enrollment form with a different payer than the existing one.Populate rest of the details and Click on Next");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData1.get(patienthasNOInsurance), ExcelTestData1.get(rxPhone),
				ExcelTestData1.get(rxPolicyID), ExcelTestData1.get(rxGroup), ExcelTestData1.get(rxBIN),
				ExcelTestData1.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData1.get(medicalPhone), ExcelTestData1.get(medicalPolicyID),
				ExcelTestData1.get(medicalGroup), ExcelTestData1.get(policyholderName),
				ExcelTestData1.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData1.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData1.get(preferredSpecialtyPharmacy),
				ExcelTestData1.get(pharmacyPhone), ExcelTestData1.get(pharmacyfax), ExcelTestData1.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData1.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerInfo(memberPlan.get(4), payerFieldVal.get(0));
		insuranceinfo.selectPayerInfo(memberPlan.get(5), payerFieldVal.get(1));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 9: In the Prescriber Information Section, Populate the Prescriber First Name, Prescriber last name, NPI, address fields with a different HCP detail than the HCP related to the existing patient");
		String[] preName1 = updatepdf.splitFullName(ExcelTestData1.get(prescriberName));
		String preFirstName1 = preName1[0];
		String prLastName1 = preName1[2];

		String[] ofcName1 = updatepdf.splitFullName(ExcelTestData1.get(officeContactName));
		String ofcFirstName1 = ofcName1[0];
		String ofcLastName1 = ofcName1[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName1, prLastName1, ExcelTestData1.get(specialty),
				ExcelTestData1.get(prescriberNPI), ExcelTestData1.get(prescriberState),
				ExcelTestData1.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData1.get(prescriberAddress),
				ExcelTestData1.get(prescriberCity), ExcelTestData1.get(prescriberState),
				ExcelTestData.get(prescriberZip));

		Logger("STEP 10: Populate the Facility Name, phone and fax number fields with the details of the HCO related to the existing patient, search and select it, fill rest of the fields and click on next");
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName1, ofcLastName1, ExcelTestData1.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData1.get(taxID));
		prescriberInformationPage.clearHCOFields();
		prescriberInformationPage.searchAndSelectHCO(ExcelTestData.get(sitefacilityname));

		Logger("STEP 11: Populate the Office Contact first Name, last name and email field with the details of office contact other than the office contact on the existing patient");
		prescriberInformationPage.enterHCOInfo(ofcFirstName1, ofcLastName1, ExcelTestData1.get(officeContactEmail),
				ExcelTestData1.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		Logger("STEP 12: In the Diagnosis Information section, select a different diagnosis code and the date of diagnosis then the existing Patient→ Click on Next");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData1.get(diagnosisCode), ExcelTestData1.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13: In the Prescription Information Section, in prescription dose field on the enrollment form select the different prescription dose than the existing one.Populate rest of the details and Click on Submit button");
		String[] mdName1 = updatepdf.splitFullName(ExcelTestData1.get(collaboratingMDName));
		String mdFirstName1 = mdName1[0];
		String mdLastName1 = mdName1[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData1.get(prescriptionARefillCaptured),
				ExcelTestData1.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData1.get(prescriptionBRefillCaptured), ExcelTestData1.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData1.get(prescriberSignatureDate), mdFirstName1, mdLastName1,
				ExcelTestData1.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-requisite STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 14: Now Open the Patient account → Click on the related tab → Go to the CPE related list → Open the CPE record → Validate the CPE record is auto updated to Status = Active");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData1.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName1);
		careProgram.checkStatusOfCPERecord(statusCPEP.get(0));
		
		Logger("STEP 15: Click on the related tab → Go to the received document list and validate the New Enrollment form is linked to the existing CPE");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToReceivedDocTable();
		careProgram.clickOnViewAll(viewAllTable.get(3));
		docMgmt.validateNewDocLinkedToCPE(documentType.get(0));

		Logger("STEP 16: Navigate to the CPEP related list present on the CPE record → Open the Existing Default CPEP record and Validate the Status is auto updated to Active");
		missingInformatioPage.navigateToCPERecord(cpeName1);
		iapPage.navigateToCPEPTable();
		careProgram.clickOnViewAll(viewAllTable.get(0));
		refresh();
		triagePage.validateCPEPstatus(cpepProductName.get(1), statusCPEP.get(0));

		Logger("STEP 17: Now go to CPE Work order list →Validate the All-Cancelled work order status remains Cancelled only");
		missingInformatioPage.navigateToCPERecord(cpeName1);
		accountObject.clickOnTab(tabsName.get(1));
		List<String> checkboxLabels = List.of(workOrderName.get(0));
		copayFlow.checkCPEWorkOrderData(careProgramProduct.get(2), ExcelTestData1.get(patientName),
				checkboxLabels, workorderStatus.get(0));

		Logger("STEP 18: Now Navigate to the Patient Account → validate in the details section, Email and Phone number field is updated with the latest details populated in the enrollment form in step 6");
		missingInformatioPage.navigateToCPERecord("Account");
		accountObject.validateDetails(fieldsDetailTab.get(0), ExcelTestData1.get(patientPrimaryphone));
		accountObject.validateDetails(fieldsDetailTab.get(1), ExcelTestData1.get(patientEmail));

		Logger("STEP 19: Click on the Related tab → Go to the CCR related list → Validate that a new CCR record is created for the caregiver details populated in the Step 5 and the CCR Status = Active");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToCCR();
		accountObject.clickOnCCRRecord(ExcelTestData1.get(legalRepresentativeName));
		accountObject.validateActiveCheckbox(true);

		Logger("STEP 20: Open the previous old CCR record for the Caregiver, validate that the Active checkbox is unchecked");
		getWebDriver().navigate().back();
		accountObject.clickOnCCRRecord(ExcelTestData.get(legalRepresentativeName));
		accountObject.validateActiveCheckbox(false);

		Logger("STEP 21: Validate that a new CCR record is created for the HCP details populated in the Step 7,relationship=HCP-Prescribing and the Active checkbox marked as checked");
		getWebDriver().navigate().back();
		accountObject.clickOnCCRRecord(ExcelTestData1.get(prescriberName));
		accountObject.validateActiveCheckbox(true);

		Logger("STEP 22: Open the existing old CCR record for the HCP, validate that the Active checkbox is unchecked automatically");
		getWebDriver().navigate().back();
		accountObject.clickOnCCRRecord(ExcelTestData.get(prescriberName));
		accountObject.validateActiveCheckbox(false);

		Logger("STEP 23: Open the HCP account → Click on related tab and go to the  Healthcare Practitioner Facilities list → validate the Healthcare Practitioner Facilities record is created and the existing HCO is now related to the newly created HCP");
		missingInformatioPage.navigateToCPERecord(cpeName1);
		accountObject.clickOnTab(tabsName.get(0));
		accountObject.openHCPorHCOFromDetailsPage(fieldsDetailTab.get(2));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.validateHealthCarePractFacilityName(ExcelTestData.get(sitefacilityname));

		Logger("STEP 24:Open the HCO record → Click on related tab → Go to the Related Contact list and Validate the New Office Contact record is visible on the list → Click on the dropdown tab of the record and Click on View Relationship → Validate a ACR record is created and the Active checkbox is marked as checked");
		missingInformatioPage.navigateToCPERecord(cpeName1);
		accountObject.clickOnTab(tabsName.get(0));
		accountObject.openHCPorHCOFromDetailsPage(fieldsDetailTab.get(3));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.clickViewRelationShipforRelatedContact(ExcelTestData1.get(officeContactName),
				relatedContDropdownOpt.get(0));
		accountObject.validateActiveCheckbox(true);

		Logger("STEP 25: Now Navigate back to the patient account and click on related tab → go to the Member Plan list view, validate Two new Member plan records are created with the Payer Name selected on the step 6 , for both record types i.e. Pharmacy and Medical, with Status = Draft and \"Primary/Secondary/Tertiary\" = Primary.");
		missingInformatioPage.navigateToCPERecord("Account");
		accountObject.clickOnTab(tabsName.get(1));
		careProgram.clickOnViewAll(appLauncherMenuItem.get(9));
		accountObject.validateMemberPlansCreated(memberPlan.get(4),
				memberPlanAndMedStatus.get(0), memberPlanType.get(2), memberPlanType.get(0));
		getWebDriver().navigate().back();
		accountObject.validateMemberPlansCreated(memberPlan.get(5),
				memberPlanAndMedStatus.get(0), memberPlanType.get(2), memberPlanType.get(1));
		getWebDriver().navigate().back();

		Logger("STEP 26: Now Open the Old existing Member plan records for Pharmacy and medical record type and validate the status is changed to Inactive for both record");
		accountObject.validateMemberPlansCreated(ExcelTestData.get(rxPayerName),
				memberPlanAndMedStatus.get(1), memberPlanType.get(2), memberPlanType.get(0));
		getWebDriver().navigate().back();
		accountObject.validateMemberPlansCreated(ExcelTestData.get(medicalPayerName),
				memberPlanAndMedStatus.get(1), memberPlanType.get(2), memberPlanType.get(1));

		Logger("STEP 27: Now Go to the Health Condition list, validate a new Health Condition record is created for the diagnosis code selected in step 10");
		missingInformatioPage.navigateToCPERecord(cpeName1);
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.validateHealthCondtCode(ExcelTestData1.get(diagnosisCode));

		Logger("STEP 28: Now open the existing health condition record and validate existing health condition record is not updated");
		accountObject.validateHealthCondtCode(ExcelTestData.get(diagnosisCode));

		Logger("STEP 29: Now go to the Medication Request list → Validate that a new Medication Request records are created for the prescription dose selected in step 11, and the Status = Active for both newly created records");
		accountObject.validateMedicationRequests(ExcelTestData1.get(prescription5ADose), memberPlanAndMedStatus.get(2));
		getWebDriver().navigate().back();
		accountObject.validateMedicationRequests(ExcelTestData1.get(prescription5BDose), memberPlanAndMedStatus.get(2));
		getWebDriver().navigate().back();

		Logger("STEP 30: Now open the existing Medication request records and validate that the Status = \"Cancelled \"on both old existing medication request records");
		accountObject.validateMedicationRequests(ExcelTestData.get(prescription5ADose), memberPlanAndMedStatus.get(3));
		getWebDriver().navigate().back();
		accountObject.validateMedicationRequests(ExcelTestData.get(prescription5BDose), memberPlanAndMedStatus.get(3));

		Logger("STEP 31: Logout from the Application.");
		documentsPage.logout();

	}

}
