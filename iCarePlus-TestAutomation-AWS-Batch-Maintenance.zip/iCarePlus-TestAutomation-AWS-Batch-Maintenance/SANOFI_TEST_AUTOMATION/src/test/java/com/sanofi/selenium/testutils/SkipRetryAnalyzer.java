package com.sanofi.selenium.testutils;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class SkipRetryAnalyzer implements IRetryAnalyzer {
    private int retryCount = 0;
    private static final int maxRetryCount = 1; 
    @Override
    public boolean retry(ITestResult result) {
        System.out.println("[RetryAnalyzer] Method: " + result.getMethod().getMethodName() + 
            " | Status: " + result.getStatus() + 
            " | Retry count: " + retryCount);

        if (result.getStatus() == ITestResult.SKIP && retryCount < maxRetryCount) {
            retryCount++;
            return true;
        }
        return false;
    }

}
