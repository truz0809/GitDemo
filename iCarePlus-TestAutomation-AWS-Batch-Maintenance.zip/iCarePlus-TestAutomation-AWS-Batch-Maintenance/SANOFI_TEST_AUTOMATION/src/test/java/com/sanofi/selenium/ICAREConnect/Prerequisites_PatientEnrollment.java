package com.sanofi.selenium.ICAREConnect;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.utils.ReadExcel;

public class Prerequisites_PatientEnrollment extends BaseTest {
	public String filePath;
	public ReadExcel excel;
	public String fileName;
	String functionality = "Enrollment";

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);

		sheetName = "PDF_Data";
		excel = new ReadExcel(sheetName);
	}

	
	@Test(description = "SIT_Patient Enrollment-SF-Scenario 2-Creation of MI Records as BV Specialist, DIS and Case Manager User.", enabled = true)
	public void PatientEnrollment_Prerequisites() throws Exception {

		// Map to hold test case data for each test case number
		Map<String, Map<String, String>> testCaseData = new HashMap<>();

		int numberOfIterations = 1;
		for (int i = 0; i < numberOfIterations; i++) {

			String testCaseNumber = "TC1";
			testCaseData.put(testCaseNumber, excelDataUpdate.createTestData(Map.of("Preferred Specialty Pharmacy",
					"FALSE", "DUPIXENT MyWay", "TRUE", "Diagnosis Code", "L20.9 - Atopic dermatitis, unspecified")));

			Map<String, String> ExcelTestData = testCaseData.get(testCaseNumber);

			Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement for TestCaseNumber: "
					+ testCaseNumber);
			excelDataUpdate.updateExcelTestData(testCaseNumber, ExcelTestData, functionality);
			ExcelTestData = excel.getExcelInputData(testCaseNumber);
			String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

			Logger("Pre-Requisite : User updates the Patient Form");
			updatepdf.selectEnrollmentForm("Asthma");
			filePath = updatepdf.PDFCreation(testCaseNumber, functionality);
			updatepdf.updatePDFForm(testCaseNumber, functionality);
			System.out.println(filePath);

			Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
			homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

			Logger("STEP 2.1: Open ICARE Connect App from the App launcher.");
			homeportalPage.closeTabs();
			documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

			Logger("STEP 2.2: Navigate to the Received Document Object from the app launcher.");
			documentsPage.verifyRecentlyViewDocumentList();

			Logger("STEP 2.3: Click on the Upload Document Button and upload a PDF Enrollment Form.");
			documentsPage.VerifyUploadDocumentButton();
			documentsPage.uploadEnrollmentDocument(filePath);

			Logger("STEP 2.4:Once the PDF Enrollment Form is uploaded, navigate to the 'Received Document Worklist' list view of the Received Document.");
			fileName = documentsPage.getFileName(filePath);
			documentsPage.verifyRecord(fileName);
			String parentDocId = documentsPage.getParentDocumentID(fileName);

			Logger("STEP 2.5:Check the checkbox on the record and click on 'Assign to me' button.");
			documentsPage.navigateToReceiveddocument();
			documentsPage.verifyAndAssignDocumentID(parentDocId);

			Logger("STEP 2.6:User will be redirected to the 'My Received Document' list view, Open the Document.");
			documentsPage.navigateToMyReceivedDoc(parentDocId, status.get(1));

			Logger("STEP 2.7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
			documentsPage.verifyDocDetailsPage(fileName, ownerName.get(0));
			documentsPage.verifyOCRStatus(documentOCRstatus.get(0));
			String parentDocumentID = documentsPage.receivedDocumentId();

			Logger("STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
			documentsPage.verfiyParentDocDetailsPage(tabsName.get(0), status.get(1));
			documentsPage.classifyDocument(documentType.get(0));
			documentsPage.submitDocument();

			Logger("STEP 3.2:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
			String childDocFileName = fileName + " (1)";
			documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
			documentsPage.verifyDocDetailsPage(childDocFileName, ownerName.get(1));
			documentsPage.verfiyChildDocDetailsPage(tabsName.get(0), documentType.get(0), status.get(0), fileName);
			String childDocumentID = documentsPage.receivedDocumentId();

			Logger("STEP 3.3:Validate a new child document with new record ID gets created in 'Received Document' related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
			documentsPage.navigateToparentRecord();
			documentsPage.verifyChildRecord(tabsName.get(1), childDocFileName);
			documentsPage.compareDocumentIDs(parentDocumentID, childDocumentID);
			documentsPage.verfiyParentDocDetailsPage(tabsName.get(0), status.get(2));
			documentsPage.navigateToChildRecord();

			Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
			refresh();
			patientSearch.verifyPatientSearchPageTitle();

			String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
			String patientFirstName = name[0];
			String patientMidName = name[1];
			String patientLastName = name[2];

			Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
			patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
					ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
					ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
					ExcelTestData.get(patientDOB));
			patientSearch.clickOnNextButton();

			// patientinfoAndauthorization-Page
			Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
			String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
			String legalRepFirstName = legalRepName[0];
			String legalRepLastName = legalRepName[2];

			patientInfo.verifyPatientAuthorizationPageTitle();
			patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
					ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
					ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
					ExcelTestData.get(zip));
			patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
					patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
					ExcelTestData.get(textMessagingConsent));
			patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
					ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
					ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
					ExcelTestData.get(patientSecondaryphone));
			patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
			patientInfo.clickOnNextButton();

			// Patient Insurance - Page
			Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
			insuranceinfo.verifyInsuranceInfoPageTitle();
			insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
					ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
					ExcelTestData.get(rxPCN));
			insuranceinfo.selectPayerPharmacy();
			insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
					ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
					ExcelTestData.get(insrelationshipToPatient));
			insuranceinfo.selectMedicalPayer();
			insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
			insuranceinfo.selectSpecialtyPharmacy();
			insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
					ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
			insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
			insuranceinfo.clickOnNextButton();

			Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
			String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
			String preFirstName = preName[0];
			String prLastName = preName[2];

			String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
			String ofcFirstName = ofcName[0];
			String ofcLastName = ofcName[2];

			prescriberInformationPage.verifyPrescriberInfoPageTitle();
			prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
					ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
					ExcelTestData.get(prescriberstateLicense));
			prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
					ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
					ExcelTestData.get(prescriberZip));
			prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
					ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
					ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
			prescriberInformationPage.clickOnNextButton();

			// Diagnosis information-Page
			Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
			diagnosisinformation.verifyDiagnosisInfoPageTitle();
			diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
			diagnosisinformation.clickOnNextButton();

			Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
			String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
			String mdFirstName = mdName[0];
			String mdLastName = mdName[2];

			prescriptioninformation.verifyPrescriptionInfoPageTitle();
			prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
					ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
					ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
					prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
					ExcelTestData.get(NursePractitionerNPI));
			prescriptioninformation.clickOnNextButton();

			Logger("STEP 10:User Clicks on Form Confirmation Button");
			formConfirmation.clicOnFormConfirmation();

			Logger("STEP 11:Verify account is created ");
			accountObject.navigateToAccDetails(ExcelTestData.get(patientName));

			Logger("STEP 12: Verify Care program enrollee record is linked to account ");
			accountObject.navigateCareProgramEnrollee();
			accountObject.verifyAndClickOnCPERecord(cpeName);

			Logger("STEP 13: User Logout the Application.");
			documentsPage.logout();

		}

	}

}
