package com.sanofi.selenium.Regression;

import java.util.HashMap;
import java.util.Map;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.junit.Assert;
import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.CopayFlow;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.HealthcareAccountSearch;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PAPPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;

public class Alerts extends BaseTest {
	private static ThreadLocal<String> filePath = new ThreadLocal<>();
	public ReadExcel excel;
	public String fileName;
	String functionality = "RGNAlerts";

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		copayFlow = GetInstance(CopayFlow.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		triagePage = GetInstance(TriagePage.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		sheetName = "RGNAlerts";
		excel = new ReadExcel(sheetName);
		papPage = GetInstance(PAPPage.class);
		hcAccountSearch = GetInstance(HealthcareAccountSearch.class);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE18027 RGN-P2-Alerts: Automate ICARE-10774: SIT: TC01:
	 * Validation of welcome case creation via enrollment form
	 * 
	 * @author Shanavaz Nishani , date- 4/30/2025
	 *         ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "SIT: TC01: Validation of welcome case creation via enrollment form", enabled = true)
	public void Alert01_IC13240_Validation_of_welcome_case_creation_via_enrollment_form() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC2";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Preferred Specialty Pharmacy", "Diagnosis Code" };
		String columnValue[] = { "TRUE", "L20.9 - Atopic dermatitis, unspecified" };
		synchronized (excelDataUpdate) {
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 2.2:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.1:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.2: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 3.3: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 4: Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 5: Fill all the mandatory fields on Insurance Information page and click on next.NOTE: Check the check box of Preferred Specialty Pharmacy in BV To Be Conducted By Section");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 6: Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 6.1: Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 6.2: Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 6.3: User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 7: Logout the application as DIS User.");
		documentsPage.logout();

		Logger("STEP 8: Login the application as CM user.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 9: Navigate to Care Program Enrollee object and open the enrolled patient CPE record.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);

		Logger("STEP 10: Navigate to Related tab and route to Cases related list and verify welcome correspondence case is created.");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCasesTable();
		careProgram.clickOnViewAll("Cases");
		int numberOfWelcomeCases = docMgmt.verifyWelcomeCases();
		if (numberOfWelcomeCases == 1) {
			utilityPage.LoggingInfo("welcome correspondence case is created successfully.");
		} else {
			Assert.fail("welcome correspondence case is not created.");
		}

		Logger("STEP 11: Complete any one of the free goods or commercial work orders i.e., Quick start or IAP or PAP or Triage");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		iapPage.clickOnStartNewService();
		iapPage.verifyServiceTitle();
		iapPage.selectQSService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		iapPage.selectQSReason();
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();
		
		quickStartPage.clickOnTask();
		
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		quickStartPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();
		
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 11.1: After completing any one of the work orders navigate to related tab and route to Cases related list and verify welcome correspondence case is not created when the work order gets completed.");
		docMgmt.switchtoRequiredTab("Cases");
		int numberOfWelcomeCases1 = docMgmt.verifyWelcomeCases();
		if (numberOfWelcomeCases1 == 1) {
			utilityPage.LoggingInfo("welcome correspondence case is not created when the work order gets completed");
		} else if (numberOfWelcomeCases1 > 1) {
			Assert.fail("welcome correspondence case is created when the work order gets completed");
		}
		

		Logger("STEP 12: Logout the application as CM User.");
		documentsPage.logout();
		
		
		}

	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-18026 Regression-DocMgmnt: Case Manager (CM)
	 * 
	 * @author Pednekar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "TC01 - Validation of welcome Case creation via order generation", enabled = true)
	public void Alert02_IC_13243_Validation_of_welcome_Case_creation_via_order_generation() throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC18";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Specialty Pharmacy Name",
				"Pharmacy Phone", "Pharmacy Fax", "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "Automation Correspondence SP", "(954) 312-1432",
				"(982) 053-8606", "J45.40 - Moderate persistent asthma, uncomplicated", "TRUE", "FALSE" };

		synchronized (excelDataUpdate) {
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Asthma");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy("Automation Correspondence SP");
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);

		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);
		
		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		Logger("STEP 2: Open a CPE record");
		homeportalPage.closeTabs();
		navigateToUrl(CPEURL);
		Thread.sleep(4000);
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCasesTable();
		docMgmt.verifyNoWelcomeCaseIsCreated();
		refresh();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		// quick start start
		papPage.clickOnStartNewService();
		papPage.selectService("Quick Start");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason(serviceReason.get(4));

		Logger("STEP 42 : Click on save and refresh the page");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		Logger("STEP 12: Navigate to Quick Start and verify flow has initiated");

		quickStartPage.checkQuickStartIntiation();
		quickStartPage.checkQuickStartTaskInitiation();

		Logger("STEP 13: Click on Enrollment task");
		quickStartPage.clickOnTask();

		Logger("STEP 14: Enter Eligibility Criteria and click on Next button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(0));
		quickStartPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 15: Enter Eligibility outcome and click on next button ");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 17: Enter order details and click on submit button");
		quickStartPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCasesTable();
		careProgram.clickOnViewAll("Cases");
		docMgmt.verifyWelcomeCaseIsCreated();
		refresh();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		// iap start
//		Logger("STEP 38: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
//		iapPage.verifyStartNewServiceButton();

		Logger("STEP 39: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 40: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		iapPage.selectService();
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		iapPage.selectReason();

		Logger("STEP 41: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		
		Logger("STEP 42: Validate that in the right side of the UI there are two tasks:IAP Summary,Extend/Discontinue");
		iapPage.checkIAPIntiation();
		iapPage.checkIAPTaskInitiation();
		iapPage.checkIAPSecondTask();

		Logger("STEP 43: Expand the IAP Summary section and Click on IAP Enrollment Task");
		iapPage.clickOnTask();

		Logger("STEP 44: Verify Users selects Enrollment Reason as Below Enrollment End Date populates accordingly");
		iapPage.verifyTaskIsLoaded(taskTitle.get(0));
		iapPage.enterEligibilityCriteria();
		missingInformatioPage.clickNextButton();

		Logger("STEP 45: Validate if User is navigated to the eligibility screen");
		iapPage.verifyTaskIsLoaded(taskTitle.get(1));
		quickStartPage.verifyAndEntereligibilityOutcome(quickStartOutcome.get(0));
		missingInformatioPage.clickNextButton();

		Logger("STEP 47: On Order Section Select the Prescription which were updated at the time of patient enrollment.");
		iapPage.verifyTaskIsLoaded(taskTitle.get(3));
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();

		refresh();
		iapPage.checkIAPIntiation();

		iapPage.checkIAPSecondTask();
		iapPage.clickOnTask2();
		iapPage.enterDiscontinue();
		missingInformatioPage.clickNextButton();
		iapPage.enterDiscontinuationReason();
		quickStartPage.clickOnSubmitButton();
		refresh();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));

		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCasesTable();
		careProgram.clickOnViewAll("Cases");
		docMgmt.verifyWelcomeCaseIsNotCreated();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		
//		 pap start
		Logger("STEP 41 :PAP work order initialization.");
		papPage.clickOnStartNewService();
		papPage.selectService("PAP");
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		papPage.selectReason("PAP Appeal");
		Logger("STEP 42 : Click on save and refresh the page");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		Logger("STEP 9: Open Capture Coverage Outcome sub task");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(0));
		papPage.enterCoverageSituation(coverageSituation.get(0));
		quickStartPage.clickOnSubmitButton();
		refresh();
		
		Logger("STEP 10: Validate the Below Mentioned Fields Outcome is picklist (Approved, Denied)");
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(0));
		papPage.clickOnTask(papSubTaskNames.get(1));
		papPage.enterAlternateCoverageSituation(alternateResearch.get(1));
		quickStartPage.clickOnSubmitButton();
		papPage.clickOnPAPTask();
		papPage.clickOnMainTask(papMainTaskNames.get(1));
		papPage.clickOnTask(papSubTaskNames.get(4));
		papPage.enterEligibilityCheck();
		quickStartPage.clickOnNextButton();
		papPage.enterOutcome(iapoutcome.get(0));
		papPage.enterCoverageOutcome(pAOutcomeOptions.get(1));
		quickStartPage.clickOnNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCasesTable();
		careProgram.clickOnViewAll("Cases");
		docMgmt.verifyWelcomeCaseIsNotCreated();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		// triage start
		Logger("STEP 35: Navigate to Traige and verify flow has initiated");
		
        
        iapPage.clickOnStartNewService();
		iapPage.verifyServiceTitle();
		copayFlow.selectService(workOrderName.get(4));
		missingInformatioPage.clickNextButton();
		iapPage.checkAttestationcheckboxIfPresent();
		copayFlow.selectReason(serviceReason.get(3));
		missingInformatioPage.clickOnSaveButton();
		refresh();
		Thread.sleep(2000);
        
//		triagePage.checkTraigeIntiation();
//		triagePage.checkTriageTaskInitiation();

		careProgram.clickOnWorkOrderTask(workOrderName.get(4));
		careProgram.clickOnMainTask(triageMainTaskNames.get(0));
		careProgram.clickOnSubTask(triageSubTaskNames.get(0));

		Logger("STEP 28: Enter order details and click on submit");
		missingInformatioPage.clickNextButton();
		quickStartPage.enterOrderDetails();
		quickStartPage.checkAttachCheckbox();
		quickStartPage.clickOnSubmitButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToCasesTable();
		careProgram.clickOnViewAll("Cases");
		docMgmt.verifyWelcomeCaseIsNotCreated();
		
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

	}

}