package com.sanofi.selenium.ICAREConnect;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.utils.ReadExcel;

public class PatientEnrollmentForm extends BaseTest {

	public String filePath;
	public ReadExcel excel;
	public String fileName;
	String functionality = "Enrollment";

	public static double getRandomNumber(double min, double max) {
		double x = (int) (Math.random() * ((max - min) + 1)) + min;
		return x;
	}

	double randomNum = getRandomNumber(1111, 9999);

//	@BeforeClass
//	public void ExcelTestDataGeneration() throws Exception {
//		GenerateTestData generateTestData = new GenerateTestData(getWebDriver());
//		generateTestData.generateEnrollmentTestData(functionality);
//	}

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		uploadDocs = GetInstance(UploadDocument.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);

		sheetName = "PDF_Data";
		excel = new ReadExcel(sheetName);
	}

	@Test(description = "Pre-Requisite : Generate test data for enrpllment test cases", enabled = true, priority = 1)
	public void enrollmentTestCases_ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	@Test(description = "TC01:Creation of new 'Received Documents' record with 'DMW-Atopic-Dermatitis-Enrollment-Form-English'.", enabled = true, priority = 2)
	public void EN01_IC851_creationOfNewReceivedDocumentsRecord_EnrollmentForm_AtopicDermatitis() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC1";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Best Timing AM",
				"Diagnosis Code"};
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "TRUE",
				"L20.9 - Atopic dermatitis, unspecified"}; 
		
		synchronized (excelDataUpdate) {
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

    	Logger("STEP 2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 4:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.enterTransformDocValues();
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		patientSearch.verifyCareProgProductError();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		// Patient Search Page
		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.verifyBackToClassify();
		patientSearch.verifyPatientSearchButton();
		patientInfo.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		// Prescription Informaiton-Page
		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");

		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		// Accounts Validation
		Logger("STEP 11:Verify if the 'Account--> Patient' record is visible");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.NavigateToAccObject(ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(gender), ExcelTestData.get(patientSecondaryphone), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientAddress), patientHasInsurance.get(0), ExcelTestData.get(language),
				ExcelTestData.get(city), ExcelTestData.get(state), ExcelTestData.get(zip));

		Logger("STEP 12: Verify 'Contact Contact Relationships' record is visible");
		accountObject.verifyAndClickOnCCR();
		accountObject.verifyCCR(ExcelTestData.get(legalrelationship));

		// payer name need to add in insurance // no data
		Logger("STEP 13: verify 'Member Plans' record(s) with record type 'Pharmacy / Medical' are visible in 'Member Plans' Related List");
		accountObject.clickOnMemberPlan();
		accountObject.validateMemberPlans(ExcelTestData.get(rxPayerName), ExcelTestData.get(medicalPayerName));
		accountObject.navigateToAccountAutomation();
		
		
		Logger("STEP 15: Verify 'Care Program Enrolles' record is updated.");
		accountObject.verifyCareProgramEnrollees(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(dUPIXENTMyWay));
		
		Logger("STEP 14: Verify Health Condition object is created.");
		accountObject.globalSearch(searchFilter.get(1), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateHealthConditions();
		accountObject.validateHealthConditionsFromCPE(ExcelTestData.get(diagnosisCode));

		Logger("STEP 16: Verify 'Medication Requests' record(s) are visible in 'Medication Requests' Related List.");
		accountObject.navigateMedicationRequests();
		accountObject.validateTwoMedicationRequests(ExcelTestData.get(prescription5BDose),
				ExcelTestData.get(prescription5ADose), ExcelTestData.get(prescriberName));	
		accountObject.navigateToAccountAutomation();
		
		Logger("STEP 17: Verify Authorization Consent record.");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToAuthFormConsentTable();
		accountObject.verifyPPAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientCertificationsDate));
		accountObject.navigateToAccountAutomation();
		
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToAuthFormConsentTable();
		accountObject.verifyHIPAAConsentDate(ExcelTestData.get(state), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientAuthorizationDate));


		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();
	}

	@Test(description = "TC02:Creation of new 'Received Documents' record with 'DMW-Nasal-Polyps-Enrollment-Form-English' with only mandatory field Entry.", enabled = true, priority = 3)
	public void EN02_IC1040_creationOfNewReceivedDocumentsRecord_EnrollmentForm_NasalPolyps() throws Exception {

		Logger("Pre-Requisite : Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC2";
		String columnName[] = { "Language", "Patient has NO Insurance" };
		String columnValue[] = { "Spanish", "TRUE" };
		synchronized (excelDataUpdate) {
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_TestCase02);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		Logger("Pre-Requisite : User updates the Patient Form");
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		Logger("Pre-Requisite : User updates the Patient Form");
		
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Nasal Polyps");
			filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}	
		System.out.println(filePath);
		
		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 4:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		
		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		patientSearch.verifyCareProgProductError();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		patientSearch.verifyBackToClassify();
		patientSearch.verifyPatientSearchButton();
		patientSearch.clickOnNextButton();

		// PatientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		patientInfo.verifyPatientAuthorizationPageTitle();
		String legalRepFirstName = null;
		String legalRepLastName = null;
		if (ExcelTestData.get(legalRepresentativeName) != null) {
			String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
			legalRepFirstName = legalRepName[0];
			legalRepLastName = legalRepName[2];
		}
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(1), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(1), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.VerifySaveLater();
		patientInfo.clickOnNextButton();

		// Insurance Information-Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		// Prescriber Information-Page
		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis Information Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		// Prescription Information-Page
		// 0th index=yes
		// 1st index=no
		Logger("STEP :Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String mdFirstName = "";
		String mdLastName = "";
		if (ExcelTestData.get(collaboratingMDName) != null) {
			String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
			mdFirstName = mdName[0];
			mdLastName = mdName[2];
		}
		System.out.println(mdFirstName + "   ------    " + mdLastName);

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(2),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(2), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		// Enrollment-Form Confirmation
		Logger("STEP 9:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		
		
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(0).split(" -")[0];

		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		
		Logger("STEP 10:User validates accounts object being created or not.");
		accountObject.verifyAccountObjectsHasNoRecords(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(patientSecondaryphone),
				ExcelTestData.get(patientEmail), ExcelTestData.get(patientAddress), patientHasInsurance.get(0),
				ExcelTestData.get(language));

		Logger("STEP 11: Verify 'Care Program Enrolles' record is updated.");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		
		Logger("STEP 12: Verify Health Condition object is not created");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateHealthConditions();
		accountObject.validateHealthConditionsFromCPENoRecord();

		Logger("STEP 13: Verify 'Medication Requests' not created.");
		accountObject.navigateMedicationRequests();
		accountObject.validateMRFromCPENoRecord();	
		
		Logger("STEP 14: User Logout the Application.");
		documentsPage.logout();

	}

	@Test(description = "ICARE-14 - Enrollment-Form - SIT - TC03-Create 'Received Document' record with 'DMW-Asthma-Enrollment-Form-English'.", enabled = true, priority = 4)
	public void EN03_IC1150_creationOfNewReceivedDocumentsRecord_EnrollmentForm_Ashtma() throws Exception {

		Logger("Pre-Requisite : Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC4";
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated" };
		synchronized (excelDataUpdate) {
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_TestCase03);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}

		Logger("Pre-Requisite : User updates the Patient Form");
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		
		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Asthma");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(PSRUserName, UserPassword);

		Logger("STEP 2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);
		
		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 4:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));
		fileName = documentsPage.getFileName(filePath);

		// documentsPage.verifyDocDetailsPage(fileName, ownerName.get(0));
		// String parentDocumentID = documentsPage.receivedDocumentId();
		// System.out.println("ParentDocId: " + parentDocumentID.toString());

		Logger("STEP 3.1:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		// documentsPage.verfiyParentDocDetailsPage(tabsName.get(0), status.get(1));
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		documentsPage.navigateToChildRecord();
		accountObject.clickOnTab(tabsName.get(0));
		String childDocId = documentsPage.getChildDocumentID();

		Logger("STEP 3.2: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		patientSearch.verifyCareProgProductError();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4:Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.verifyBackToClassify();
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		patientInfo.VerifySaveLater();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		homeportalPage.closeTabs();
		documentsPage.verifyRecentlyViewDocumentList();
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(childDocId, status.get(4));


		// prescriber info
		Logger("STEP 7:Verify Patient Prescriber Information Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnPreviousButton();
		prescriberInformationPage.clickOnNextButton();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		// 0th index=yes
		// 1st index=no
		// Prescription Informaiton-Page
		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");

		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		// Accounts Validation
		Logger("STEP 11:Verify if the 'Account--> Patient' record is visible");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		
		accountObject.NavigateToAccObject(ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(gender), ExcelTestData.get(patientSecondaryphone), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientAddress), patientHasInsurance.get(0), ExcelTestData.get(language),
				ExcelTestData.get(city), ExcelTestData.get(state), ExcelTestData.get(zip));


		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("STEP 13: Verify 'Care Program Enrolles' record is updated.");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		
		Logger("STEP 15: Verify Health Condition object is not created");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateHealthConditions();
		accountObject.validateHealthConditionsFromCPE(ExcelTestData.get(diagnosisCode));
		accountObject.navigateToAccountAutomation();

		Logger("STEP 16: Verify Consent created");
		String hippaDate = accountObject.formatDatemddyyyy(ExcelTestData.get(patientAuthorizationDate));
		String ppaDate = accountObject.formatDatemddyyyy(ExcelTestData.get(patientCertificationsDate));
		accountObject.verifyConsentDateHippa(hippaDate);
		accountObject.verifyConsentDatePpa(ppaDate);
		

		Logger("STEP 17: User Logout the Application.");
		documentsPage.logout();
	}

	@Test(description = "ICARE-435 - Enrollment-Form - SIT - TC04-Creation of new 'Received Documents' record with 'DMW-Prurigo-Nodularis-Enrollment-Form-English'", enabled = true, priority = 5)
	public void EN04_IC1154_creationOfNewReceivedDocumentsRecord_EnrollmentForm_PrurigoNodularis() throws Exception {

		Logger("Pre-Requisite : Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC3";

		String columnName[] = {  "Diagnosis Code" };
		String columnValue[] = {  "L28.1 - Prurigo nodularis" };
		synchronized (excelDataUpdate) {
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_TestCase04);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(PSRUserName, UserPassword);

		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("STEP 2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 4:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(1),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();
//		patientSearch.verifyExistingPatient();

		Logger("STEP 4:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(1), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(1), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.verifyContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Insurance Page
		Logger("STEP 5:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();
		patientInfo.VerifySaveLater();

		// Prescriber Information-Page
		Logger("STEP 6:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis Information Page
		Logger("STEP 7:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 8:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String mdFirstName = "";
		String mdLastName = "";
		if (ExcelTestData.get(collaboratingMDName) != null) {
			String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
			mdFirstName = mdName[0];
			mdLastName = mdName[2];
		}
		System.out.println(mdFirstName + "   ------    " + mdLastName);

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(2),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(2), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 9:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

	//	Logger("STEP 20:Navigate to 'Received Documents' related list and click on the Submitted document record.");
		//documentsPage.verifyRecentlyViewDocumentList();

	//	Logger("STEP 21: Validate the Submitted document record status is in 'Completed' status.");
		//documentsPage.navigateToAllRecDocAndSearchRecord(childDocFileName);
		//documentsPage.verifyDocumentStatus(status.get(3));
		
		Logger("STEP 10:Verify if the 'Account--> Patient' record is visible");
		accountObject.navigateToAccount();
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.NavigateToAccObject(ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(gender), ExcelTestData.get(patientSecondaryphone), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientAddress), patientHasInsurance.get(0), ExcelTestData.get(language),
				ExcelTestData.get(city), ExcelTestData.get(state), ExcelTestData.get(zip));


		Logger("STEP 11: Verify 'Care Program Enrolles' record is updated.");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(cpeName);
		
		Logger("STEP 12: Verify Health Condition object is not created");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateHealthConditions();
		accountObject.validateHealthConditionsFromCPE(ExcelTestData.get(diagnosisCode));
		
		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

	/*	Logger("STEP 25 Login as PC user");
		homeportalPage = loginPage.userLogin(PCUserName, UserPassword);

		Logger("STEP 26: Navigate to Received Document object → Validate that the Program Coordinator can assign themselves a Received Document record from the PSQA Review Queue List View by clicking an \"Assign to me\" button.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		documentsPage.verifyRecentlyViewDocumentList();
		documentsPage.navigatetoPSQAReviewWorklistView();
		String docName = fileName + " (1)";
		documentsPage.searchDocument(docName);
		documentsPage.assigntoMe(docName);

		Logger("STEP 27: On the record validate that PC user is able to Review and update a received document record’s classification.");
		documentsPage.verifyRecordAndClick(docName);
		patientSearch.fieldEditButton();
		patientSearch.updateSourceChannelField("Web");
		patientSearch.selectReviewOutcome();
		utilityPage.clickOnButton("Save");

		Logger("STEP 28 and 29: Validate that the Program Coordinator can change the Received Document record status to \"Complete\" only after populating the PSQA Review Outcome field or it will throw an error.");
		patientSearch.fieldEditButton();
		patientSearch.errorValidation();
		patientSearch.selectReviewOutcome();
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 30: Log out");
		documentsPage.logout();*/
	}

	

	@Test(description = "TC06-TC06-Creation of new 'Received Documents' as DIS validating different Document status", enabled = true, priority = 7)
	public void EN06_IC1699_creationOfNewReceivedDocumentsRecord_EnrollmentForm_ValidateDocumentStatus()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC6";
		
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = {  "L20.9 - Atopic dermatitis, unspecified", "TRUE", "TRUE" };
		synchronized (excelDataUpdate) {
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite 2 : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);		
		}
		System.out.println(filePath);
//		fileName = documentsPage.getFileName(filePath);
//		String childDocFileName = fileName + " (1)";
//		System.out.println(childDocFileName);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 4:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);
		Logger("Step 4: When DIS user navigates to Received Document Object opened, Click on List View and Validate different List View.");
		docMgmt.ClicklistViewdropdownobject("Received Documents");
		for (String listView : RecivedlistViewFilters) {
			docMgmt.validateListViewFilters(listView);
		}

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		docMgmt.navigateToListofCPE(RecivedlistViewFilters.get(1));
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7: Validate after assignment using \"*Assign to Me*\" button, DIS user is navigated to My Received Document list view, where DIS user can see the status of the document as *In Review* and Click on the Open Document URL and user will be redirected to Received document details page.");
		// documentsPage.verifyDocDetailsPage(fileName, ownerName.get(0));
		// // documentsPage.verifyOCRStatus(documentOCRstatus.get(0));
		// String parentDocumentID = documentsPage.receivedDocumentId();

		Logger("STEP 8.1: On Classify Document' tab, validate when \"Document Type\" is blank and click on Submit button, error is displayed: Error: Document Type is required.");
		// documentsPage.verfiyParentDocDetailsPage(tabsName.get(0), status.get(1));
		documentsPage.classifyDocumentError();

		Logger("STEP 8.2: Validate appropriate error message is displayed when user enter text or Special character value for below fields.");
		documentsPage.verifyTransformDocError();

		Logger("STEP 9: Validate if DIS can Add or Delete new documents using the Add button on top left.");
		documentsPage.clickOnAddAndDeleteButton();

		Logger("STEP 10: After Submission, click on Refresh tab and validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		refresh();
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 12: User selects valid ‘Care Program Product' field data and click on Next Button,Navigate to Patient Search' tab and validate when '*Care Program Product*' field data is not selected and user click on next button,error message will pops up.");
		patientSearch.verifyPatientSearchPageTitle();
		patientSearch.verifyCareProgProductError();

		accountObject.clickOnTab(tabsName.get(0));
		String childDocId = documentsPage.getChildDocumentID();
		
		Logger("STEP 13:On the Patient search page, Validate the required fields in '*Patient Information & Authorizations*' section are populated as per the details given in the uploaded PDF form in Step5, enter required field data and click on 'Next' button.");
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		Logger("STEP 14: On the Patient Enrollment' page, Validate the required fields in '*Patient Information & Authorizations*' section are populated as per the details given in the uploaded PDF form in Step5, enter required field data and click on 'Next' button.");

		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		Logger("STEP 15: In '*Insurance Information*' section, click on '*Save for Later.*,Verify that user is able to view below mentioned message as Your OmniScript is saved for later and user can use the link to resume the form filling afterwards also.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 16:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String preFirstName = null;
		String prLastName = null;
		if (!(ExcelTestData.get(prescriberName) == null)) {
			String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
			preFirstName = preName[0];
			prLastName = preName[2];
		}

		String ofcFirstName = null;
		String ofcLastName = null;
		if (!(ExcelTestData.get(officeContactName) == null)) {
			String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
			ofcFirstName = ofcName[0];
			ofcLastName = ofcName[2];
		}

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 17:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 18:Verify Patient Prescription Inforamtion Page details and click on Next Button");

		String mdFirstName = null;
		String mdLastName = null;
		if (!(ExcelTestData.get(collaboratingMDName) == null)) {

			String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
			mdFirstName = mdName[0];
			mdLastName = mdName[2];
		}
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(1),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(1), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 19:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 20:Navigate to 'Received Documents' related list and click on the Submitted document record.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0),
				DocumentPage.class);
		documentsPage.verifyRecentlyViewDocumentList();
		accountObject.searchRecord(childDocId);
		accountObject.clickOnfirstRecord();
		
		Logger("STEP 21: Validate the Submitted document record status is in 'Completed' status.");
		accountObject.clickOnTab(tabsName.get(0));
		accountObject.verifyStatusField(status.get(6));

//		documentsPage.navigateToAllRecDocAndSearchRecord(childDocFileName);
//		documentsPage.verifyDocumentStatus(status.get(3));

		Logger("STEP 22: User Logout the Application.");
		documentsPage.logout();
	}

	@Test(description = "IC15690 - Regression-Enroll: Automate SIT_Patient Enrollment_SF - Scenario 5 - TC 03- TC11-Creation of new 'Received Documents' record validate the source system on the search results for payer and SP search.", enabled = true, priority = 8)
	public void EN07_IC4577_ValidateSearchResultsForPayerandSPsearch() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC7";

			Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
			String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay",
					"Preferred Specialty Pharmacy" };
			String columnValue[] = {  "L20.9 - Atopic dermatitis, unspecified", "TRUE", "TRUE" };
			
			synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			}
			ExcelTestData = excel.getExcelInputData(TestCaseNumber);

			String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

			Logger("Pre-Requisite 02: User updates the Patient Form");
			synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
			}
			
			System.out.println(filePath);

			Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
			homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

			Logger("STEP 2:Upload document to Dupixent portal");
			String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
					ExcelTestData.get(patientEmail) };
			String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

			Logger("STEP 3: Navigate To Recently View Document list");
			documentsPage.verifyRecentlyViewDocumentList();

			// Logger("STEP 4:Navigate to All Received Documents and Check the checkbox on
			// the record and click on 'Assign to me' button.");
			// documentsPage.navigateToReceiveddocument();
			// documentsPage.verifyAndAssignDocID(documentID);

			Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
			documentsPage.navigateToMyReceivedDocListView();
			documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

			Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
			// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

			Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
			documentsPage.classifyDocument(documentType.get(0));
			documentsPage.submitDocument();

			Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
			documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
			patientSearch.verifyPatientSearchPageTitle();
			patientSearch.verifyCareProgProductError();

			String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
			String patientFirstName = name[0];
			String patientMidName = name[1];
			String patientLastName = name[2];

			Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
			patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
					ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
					ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
					ExcelTestData.get(patientDOB));
			patientSearch.clickOnNextButton();

			// patientinfoAndauthorization-Page
			Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
			String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
			String legalRepFirstName = legalRepName[0];
			String legalRepLastName = legalRepName[2];

			patientInfo.verifyPatientAuthorizationPageTitle();
			patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
					ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
					ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
					ExcelTestData.get(zip));
			patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
					patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
					ExcelTestData.get(textMessagingConsent));
			patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
					ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
					ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
					ExcelTestData.get(patientSecondaryphone));
			patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
			patientInfo.clickOnNextButton();

			// Patient Insurance - Page
			Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
			insuranceinfo.verifyInsuranceInfoPageTitle();
			insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
			insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
			insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
					ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
					ExcelTestData.get(rxPCN));
			insuranceinfo.selectPayerPharmacy();
			insuranceinfo.validateSourceSystem("Pharmacy");
			insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
					ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
					ExcelTestData.get(insrelationshipToPatient));
			insuranceinfo.selectMedicalPayer();
			insuranceinfo.validateSourceSystem("Medical");
			insuranceinfo.selectSpecialtyPharmacy("Automation Specialty Pharmacy");
			insuranceinfo.validateSourceSystem("Speciality Pharmacy");
			insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
					ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
			insuranceinfo.clickOnNextButton();

			Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
			String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
			String preFirstName = preName[0];
			String prLastName = preName[2];

			String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
			String ofcFirstName = ofcName[0];
			String ofcLastName = ofcName[2];

			prescriberInformationPage.verifyPrescriberInfoPageTitle();
			prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
					ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
					ExcelTestData.get(prescriberstateLicense));
			prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
					ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
					ExcelTestData.get(prescriberZip));
			prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
					ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
					ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
			prescriberInformationPage.clickOnNextButton();

			// Diagnosis information-Page
			Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
			diagnosisinformation.verifyDiagnosisInfoPageTitle();
			diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
			diagnosisinformation.clickOnNextButton();

			Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
			String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
			String mdFirstName = mdName[0];
			String mdLastName = mdName[2];

			prescriptioninformation.verifyPrescriptionInfoPageTitle();
			prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
					ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
					ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
					prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
					ExcelTestData.get(NursePractitionerNPI));
			prescriptioninformation.clickOnNextButton();

			Logger("STEP 10:User Clicks on Form Confirmation Button");
			formConfirmation.clicOnFormConfirmation();

			Logger("STEP 12: User Logout the Application.");
			documentsPage.logout();
		

	}

	@Test(description = "Patient Enrollment_SF - Scenario 5 - TC 01-Creation of new 'Received Documents' record with OCR mapping from PDF to Omniscript'.", enabled = true)
	public void EN08_IC2929_ValidateCreationOfNewReceivedDocumentsMappingFromPDFToOmniscript() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC9";


		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = {  "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = {  "L20.9 - Atopic dermatitis, unspecified", "TRUE", "TRUE" };

		synchronized (excelDataUpdate) {
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 4:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));
		patientSearch.verifyPatientSearchPageTitle();
		patientSearch.verifyCareProgProductError();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));

		insuranceinfo.clickOnNextButton();
		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = "Dr." + preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Navigate to care program enrollee Record and verify the Prescriber Name");
	    accountObject.globalSearch(searchFilter.get(1),cpeName);	
		String prescriber = "Dr." + ExcelTestData.get(prescriberName);
	    documentsPage.verifyPrescriberName(prescriber);

		Logger("STEP 12: User Logout the Application.");
		documentsPage.logout();

	}
}
