package com.sanofi.selenium.Regression;

import java.util.HashMap;
import java.util.Map;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.pages.HealthcareAccountSearch;
import com.sanofi.selenium.utils.ReadExcel;

public class DocDropPortal extends BaseTest {
	public String filePath;
	public ReadExcel excel;
	public String fileName;
	String functionality = "DocDropPortal";

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		sheetName = "DocDropPortal";
		excel = new ReadExcel(sheetName);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		uploadDocs = GetInstance(UploadDocument.class);
		triagePage = GetInstance(TriagePage.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		hcAccountSearch = GetInstance(HealthcareAccountSearch.class);
	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-13460 - Regression-Doc Drop/Portal: Automate the
	 * Receive new documents Enrollment signed from the Adobe e-Sign feature on
	 * Portal English Version
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT - TC01: Validate the Receive new documents Enrollment signed from the Adobe e-Sign feature on Portal English Version", enabled = true)
	public void DDP1_IC3486_Validate_the_Receive_new_documents_Enrollment_signed_from_the_Adobe_e_Sign_feature_on_Portal_English_Version()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String testCaseNumber = "TC1";
		ExcelTestData = excel.getExcelInputData(testCaseNumber);
		String docName = "Patient Consent and Enrollment Form – English.pdf";

		Logger("STEP 1: Launch the Following Portal URL for QA org.");
		uploadDocs.navigateToDupxientUrl();
		dupixentPortal.clickOnAcceptAllCookies();
		
		Logger("STEP 1:Login as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 1.2:Upload document to Dupixent portal");
		uploadDocs.navigateToDupxientUrl();

		Logger("STEP 2: Once URL is launched, from the welcome a Pop up is displayed Click on \"I am a Patient or Caregiver\" button");
//		dupixentPortal.clickOnAcceptAllCookies();
		dupixentPortal.clickOnPatientorCaregiverButton();

		Logger("STEP 3: Click the \"Electronically Sign Patient Consent Form\" button in the home page.");
		dupixentPortal.clickOnElectronicConsentForm();

		Logger("STEP 4: Validate the User is navigating to \"Patient eSignature Authorization Form\" Page.");
		dupixentPortal.verifyPatienteSignatureAuthorizationPage();

		Logger("STEP 5: verify the Following Fields on English version are required fields on Enrollment Form:");
		dupixentPortal.selectCategoryForForm(formCategory.get(0));
		for (String formField : requiredFormFields) {
			dupixentPortal.verifyRequiredFields(formField);
		}

		Logger("STEP 6:  Click the \"Review & Sign Electronically\" button and Validate the user can enter values for all fields on the Patient Enrollment form on English version PDF’s..");
		dupixentPortal.enterPatientInfo(ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone));
		dupixentPortal.esignPDF();

		Logger("STEP 7: Verify the once all required fields are entered, the user is able to proceed and confirm submission of their signature via the Adobe e-Sign window");
		dupixentPortal.clickToSign(ExcelTestData.get(patientEmail));

		Logger("STEP 8: After Submitting the Documents from the Unauthenticated Portal, Now Log in QA org As DIS User");
		uploadDocs.navigateToSFUrl();
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);

		Logger("STEP 9: Click on the App Launcher and navigate to iCare Connect App >> Received Documents Object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

		Logger("STEP 10: Change List view to Received Document Worklist and Validate Status of document uploaded via Portal from Status Column");
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		docMgmt.navigateToListofCPE("All Received Documents");
		Thread.sleep(12000);
		String docId = documentsPage.getParentDocumentIDOfLatestDoc(docName);
		System.out.println(docId);
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		docMgmt.navigateToListofCPE("Received Document Worklist");
		Thread.sleep(4000);

		Logger("STEP 11: Click the Uploaded Documents from Unauthenticated Portal and Validate the Fields values are set on the Received Document record for any documents uploaded or submitted via the Unauthenticated Portal: 'Document # is autogenerated and populated'  'Source Channel = Web' 'Source = DupixentMyWay Portal'.");
		documentsPage.searchDocumentWithName(docId);
		Thread.sleep(4000);
		docMgmt.validateDOcdetails(docId);

		Logger("STEP 12: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE-3833 - Validate the Receive new documents Medicare Part D
	 * PAP Re-enrollment signed from the Adobe e-Sign feature on Portal English
	 * Version
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT - TC01: Validate the Receive new documents Medicare Part D PAP Re-enrollment signed from the Adobe e-Sign feature on Portal English Version", enabled = true)
	public void DDP2_IC3833_Validate_the_Receive_new_documents_Medicare_Part_PAP_Re_enrollment_signed_from_the_Adobe_e_Sign_feature_on_Portal_English_Version()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String testCaseNumber = "TC2";
		ExcelTestData = excel.getExcelInputData(testCaseNumber);
		//String docName = "Medicare Part D PAP Re-enrollment Form – English.pdf";
		String docName = "Patient Consent and Enrollment Form - English.pdf";
		
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);	
		
		
		Logger("STEP 1: Launch the Following Portal URL for QA org.");
		uploadDocs.navigateToDupxientUrl();
		

		Logger("STEP 2: Once URL is launched, from the welcome a Pop up is displayed Click on \"I am a Patient or Caregiver\" button");
		dupixentPortal.clickOnAcceptAllCookies();
		dupixentPortal.handleLoginScreen();
		dupixentPortal.clickOnPatientorCaregiverButton();
		
		Logger("STEP 3: Click the \"Electronically Sign Patient Consent Form\" button in the home page.");
		dupixentPortal.clickOnElectronicConsentForm();

		Logger("STEP 4: Validate the User is navigating to \"Patient eSignature Authorization Form\" Page.");
		dupixentPortal.verifyPatienteSignatureAuthorizationPage();

		Logger("STEP 5: verify the Following Fields on English version are required fields on Enrollment Form:");
		dupixentPortal.selectMedDCategory();
		for (String formField : requiredFormFieldsMedD) {
			dupixentPortal.verifyRequiredFieldsMedD(formField);	
		}

		Logger("STEP 6:  Click the \"Review & Sign Electronically\" button and Validate the user can enter values for all fields on the Patient Enrollment form on English version PDF’s..");
		dupixentPortal.enterPatientInfoMedD(ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(gender), ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				PeopleInHousehold.get(0), AnnualIncome.get(0));
		dupixentPortal.esignPDFMedD();

		Logger("STEP 7: Verify the once all required fields are entered, the user is able to proceed and confirm submission of their signature via the Adobe e-Sign window");
		dupixentPortal.clickToSign(ExcelTestData.get(patientEmail));

		Logger("STEP 8: After Submitting the Documents from the Unauthenticated Portal, Now Log in QA org As DIS User");
		uploadDocs.navigateToSFUrl();
		documentsPage.logout(); 
		homeportalPage = loginPage.userLogin(PSRUserName, UserPassword);

		Logger("STEP 9: Click on the App Launcher and navigate to iCare Connect App >> Received Documents Object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

		Logger("STEP 10: Change List view to Received Document Worklist and Validate Status of document uploaded via Portal from Status Column");
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		//docMgmt.navigateToListofCPE("All Received Documents");
		docMgmt.navigateToListofCPE("Received Document Worklist");
		//Thread.sleep(12000);
		String docId = documentsPage.getParentDocumentIDOfLatestDoc(docName);
		System.out.println(docId);
		Thread.sleep(3000);

		Logger("STEP 11: Click the Uploaded Documents from Unauthenticated Portal and Validate the Fields values are set on the Received Document record for any documents uploaded or submitted via the Unauthenticated Portal: 'Document # is autogenerated and populated'  'Source Channel = Web' 'Source = DupixentMyWay Portal'.");
		documentsPage.searchDocumentWithName(docId);
		Thread.sleep(4000);
		docMgmt.validateDOcdetails(docId);

		Logger("STEP 12: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-2861 Automate the Store Patient Information and Submitter
	 * Information fields on Received Document object in iCC+
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Validate the Store Patient Information and Submitter Information fields on Received Document object in iCC+", enabled = true)
	public void DM13_IC2861_Validate_the_Store_Patient_Information_and_Submitter_Information_fields_on_ReceivedDocument_object_in_iCC()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC3";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Prescriber Name", "Specialty", "Prescriber NPI", "Prescriber Zip",
				"Site/facility name", "Office Fax", "Office Phone", "Tax ID", "Diagnosis Code", "DUPIXENT MyWay",
				"Preferred Specialty Pharmacy" };
		String columnValue[] = { "Automation HCP", "Neurologist", "4105589820", "10038", "Automation HCO",
				"(987) 678-9098", "(982) 789-9378", "989098789", "J42 - Unspecified chronic bronchitis", "TRUE",
				"FALSE" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(5).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("COPD");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 4: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 5: Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 5:Navigate to Details tab of record ");
		accountObject.clickOnTab(tabsName.get(0));

		Logger("STEP 6:Navigate to Additional Information section ");
		accountObject.navigateToAdditionalInfoSection();

		Logger("STEP 7: Validate the new fields in the 'Received Document Fields  Details Tab");
		accountObject.validateNewFields(cpeDetails, documentID);

		Logger("STEP 8: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-4617 Validate that a portal user is presented with cookie
	 * page
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Validate that a portal user is presented with cookie page", enabled = true)
	public void DM13_IC4617_Validate_that_a_portal_user_is_presented_with_cookie_page() throws Exception {

		Logger("STEP 1: Launch the dupixent My way Portal URL for QA/Val org'.");
		
		
		uploadDocs.navigateToDupxientUrl();

		Logger("STEP 2:when URL is launched user sees a Cookie preference pop up validate the message");
		dupixentPortal.validateMessage();

		Logger("STEP 3:Click and validate the Cookie pop links ");
		dupixentPortal.validateSanofiPrivacyPolicy();
		dupixentPortal.validateRegeneronPrivacyNotice();

		Logger("STEP 4:verify user is able to see Accept all cookies,Reject optional cookies and cookies setting button ");
		dupixentPortal.validateButtons();

		Logger("STEP 5:Click on cookie settings and validate message ");
		dupixentPortal.validatecookieSettingsMessage();

		Logger("STEP 6:verify to click on \"REJECT OPTIONAL COOKIES\" button");
		dupixentPortal.validateRejectOptionalCookiesbutton();

		Logger("STEP 7:Verify to Relaunch the portal URL in incognito tab and select ACCEPT ALL COOKIES");
		uploadDocs.RelaunchPortalInIncognito();

		Logger("STEP 8:Relaunch the portal URL in incognito tab and select ACCEPT ALL COOKIES");
		dupixentPortal.validateAcceptAllCookies();

		Logger("STEP 9:Again Relaunch the Portal URL in incognito tab and click on Cookies Settings and verify \"Strictly Necessary Cookies\"");
		uploadDocs.RelaunchPortalInIncognito();
		dupixentPortal.verifyCookieSettings();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-3818 - Regression-Doc Drop/Portal: Automate the
	 * Receive new documents Enrollment signed from the Adobe e-Sign feature on
	 * Portal Spanish Version
	 * 
	 * @author kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
@Test(description = "SAT - TC02: Validate the Receive new documents Enrollment signed from the Adobe e-Sign feature on Portal Spanish Version", enabled = true)
	public void DDP5_IC3818_Validate_the_Receive_new_documents_Enrollment_signed_from_the_Adobe_e_Sign_feature_on_Portal_Spanish_Version()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String testCaseNumber = "TC5";
		ExcelTestData = excel.getExcelInputData(testCaseNumber);
		String docName = "Patient Consent and Enrollment Form – Spanish.pdf";

		Logger("STEP 1: Launch the Following Portal URL for QA org.");
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);	
		uploadDocs.navigateToDupxientUrl();

		Logger("STEP 2: Once URL is launched, from the welcome a Pop up is displayed Click on \"I am a Patient or Caregiver\" button");
		dupixentPortal.clickOnAcceptAllCookies();
		dupixentPortal.handleLoginScreen();
		dupixentPortal.clickOnPatientorCaregiverButton();

		Logger("STEP 3: Click the \"Electronically Sign Patient Consent Form\" button in the home page.");
		dupixentPortal.clickOnElectronicConsentForm();

		Logger("STEP 4: Validate the User is navigating to \"Patient eSignature Authorization Form\" Page.");
		dupixentPortal.verifyPatienteSignatureAuthorizationPage();

		Logger("STEP 5: verify the Following Fields on Spanish version are required fields on Enrollment Form:");
		dupixentPortal.selectFormulariodeinscripcionCategory();
		for (String formField : requiredFormFields) {
			dupixentPortal.verifyRequiredFields(formField);
		}

		Logger("STEP 6:  Click the \"Review & Sign Electronically\" button and Validate the user can enter values for all fields on the Patient Enrollment form on Spanish version PDF’s..");
		dupixentPortal.enterSpanishPatientInfo(ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone));
		dupixentPortal.esignPDF();

		Logger("STEP 7: Verify the once all required fields are entered, the user is able to proceed and confirm submission of their signature via the Adobe e-Sign window");
		dupixentPortal.clickToSign(ExcelTestData.get(patientEmail));

		Logger("STEP 8: After Submitting the Documents from the Unauthenticated Portal, Now Log in QA org As DIS User");
		uploadDocs.navigateToSFUrl();
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);

		Logger("STEP 9: Click on the App Launcher and navigate to iCare Connect App >> Received Documents Object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

		Logger("STEP 10: Change List view to Received Document Worklist and Validate Status of document uploaded via Portal from Status Column");
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		//docMgmt.navigateToListofCPE("All Received Documents");
		docMgmt.navigateToListofCPE("Received Document Worklist");
		Thread.sleep(12000);
		String docId = documentsPage.getParentDocumentIDOfLatestDoc(docName);
		System.out.println(docId);
		//docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		//docMgmt.navigateToListofCPE("Received Document Worklist");
		Thread.sleep(4000);

		Logger("STEP 11: Click the Uploaded Documents from Unauthenticated Portal and Validate the Fields values are set on the Received Document record for any documents uploaded or submitted via the Unauthenticated Portal: 'Document # is autogenerated and populated'  'Source Channel = Web' 'Source = DupixentMyWay Portal'.");
		documentsPage.searchDocumentWithName(docId);
		Thread.sleep(4000);
		docMgmt.validateDOcdetails(docId);

		Logger("STEP 12: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-3841 - Validate the Receive new documents
	 * Medicare Part D PAP Re-enrollment signed from the Adobe e-Sign feature on
	 * Portal Spanish Version
	 * 
	 * @author Trupti
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Validate the Receive new documents Medicare Part D PAP Re-enrollment signed from the Adobe e-Sign feature on Portal Spanish Version", enabled = true)
	public void DDP06_IC3841_Receive_new_documents_Medicare_Part_D_PAP_Reenrollment_signed_from_the_Adobe_eSign_feature_on_Portal_Spanish_Version()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String testCaseNumber = "TC6";
		ExcelTestData = excel.getExcelInputData(testCaseNumber);
		String docName = "Patient Consent and Enrollment Form – Spanish.pdf";
		
		Logger("STEP 1: Launch the Following Portal URL for QA org.");
//		String docName = "Patient Consent and Enrollment Form – spanish.pdf";

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
		
		Logger("STEP 1: Launch the Following Portal URL");
		uploadDocs.navigateToDupxientUrl();

		dupixentPortal.handleLoginScreen();
		
		Logger("STEP 2: Once URL is launched, from the welcome a Pop up is displayed Click on \"I am a Patient or Caregiver\" button");
		dupixentPortal.clickOnAcceptAllCookies();
		dupixentPortal.handleLoginScreen();
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword); //ARC
		dupixentPortal.clickOnPatientorCaregiverButton();
		
		Logger("STEP 3: Click the \"Electronically Sign Patient Consent Form\" button in the home page.");
		dupixentPortal.clickOnElectronicConsentForm();

		Logger("STEP 4: Validate the User is navigating to \"Patient eSignature Authorization Form\" Page.");
		dupixentPortal.verifyPatienteSignatureAuthorizationPage();

		Logger("STEP 5: Validate the user can enter values for all fields on the Formulario de reinscripcion PAP de la Parte D de Medicare Re-enrollment PDF form on Spanish version PDF’s.");
		dupixentPortal.selectCategoryForForm(formCategory.get(3));
		for (String formField : requiredFormFieldsSpanish) {
			dupixentPortal.verifyRequiredFieldsSpanishVer(formField);
		}

		Logger("STEP 6:  Click the \"Review & Sign Electronically\" button and verify the Following Fields on Spanish version are required fields on Formulario de reinscripcion PAP de la Parte D de Medicare Form:");
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientLastName = name[2];

		dupixentPortal.enterPatientInfoSpanish(patientFirstName, patientLastName,
				ExcelTestData.get(patientPrimaryphone));

		Logger("STEP 7: Verify the once all required fields are entered, the user is able to proceed and confirm submission of their signature via the Adobe e-Sign window");
		dupixentPortal.clickToSign(ExcelTestData.get(patientEmail));

		Logger("STEP 8: After Submitting the Documents from the Unauthenticated Portal, Now Log in QA org As DIS User");
		uploadDocs.navigateToSFUrl();
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(PSRUserName, UserPassword);

		Logger("STEP 9: Click on the App Launcher and navigate to iCare Connect App >> Received Documents Object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);

		Logger("STEP 10: Change List view to Received Document Worklist and Validate Status of document uploaded via Portal from Status Column");
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
//		docMgmt.navigateToListofCPE("All Received Documents");
		
		Thread.sleep(12000);
		docMgmt.navigateToListofCPE("Received Document Worklist");  //ARC
		Thread.sleep(5000); //ARC
		String docId = documentsPage.getParentDocumentIDOfLatestDoc(docName);
		System.out.println(docId);
		//docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		//docMgmt.navigateToListofCPE("Received Document Worklist");
		Thread.sleep(4000);

		Logger("STEP 11: Click the Uploaded Documents from Unauthenticated Portal and Validate the Fields values are set on the Received Document record for any documents uploaded or submitted via the Unauthenticated Portal: 'Document # is autogenerated and populated'  'Source Channel = Web' 'Source = DupixentMyWay Portal'.");
		documentsPage.searchDocumentWithName(docId);
		Thread.sleep(4000);
		docMgmt.validateDOcdetails(docId);

		Logger("STEP 12: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-10389: SIT: TC_01: To Validate Enrollment form is
	 * routing into Received Document Worklist on uploading from Portal
	 * 
	 * @author Kavyashree
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "To Validate Enrollment form is routing into Received Document Worklist on uploading from Portal", enabled = true)
	public void DDP07_IC12133_To_Validate_Enrollment_form_is_routing_into_Received_Document_Worklist_on_uploading_from_Portal()
			throws Exception {
		String cpeUrl = null;

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC7";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "L28.1 - Prurigo nodularis", "TRUE", "FALSE" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(1).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);

		// updatepdf.selectEnrollmentForm("Prurigo Nodularis");
		// filePath1.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		// updatepdf.updatePDFForm(TestCaseNumber, functionality);
		// System.out.println(filePath1.get());
				
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 1: Go To Dupixent Unauthenticated Portal, Click on Accept All Cookies Button from the Cookies setting Prompt.");
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		uploadDocs.navigateToDupxientUrl();
		dupixentPortal.clickOnAcceptAllCookies();
		dupixentPortal.handleLoginScreen();

		Logger("STEP 2:On Welcome Screen, Select I am a Patient or Caregiver option.");
		dupixentPortal.clickOnPatientorCaregiverButton();

		Logger("Step 3:Click the \"Upload Document\" button in the home page.");
		dupixentPortal.clickOnUploadDocButton();

		Logger("STEP 4:Click on Submit Code, On Patient Information Page Update Patient First Name, Patient Last Name, Patient Date of Birth and Patient Email Address.");
		dupixentPortal.enterAccessCode("8443879370");
		dupixentPortal.clickOnSubmitCodeButton();
		String pName = cpeDetails[0];
		String pDOB = cpeDetails[1];
		String pEmail = cpeDetails[2];
		String[] cpEDetails = { pName, pDOB, pEmail };
		dupixentPortal.enterPatientInfo(cpEDetails);
		dupixentPortal.clickOnSubmitDocCheckBox();

		Logger("STEP 5: Check on Consent and Upload any Dupixent Document.On Confirmation Page, Click on Submit button");
		dupixentPortal.clickOnConsentCheckBoxes();
		dupixentPortal.clickOnUploadFileButton();
		uploadDocs.uploadPDFDocument(filePath);
		dupixentPortal.clickOnSubmitButton();
		String documentID = "";
		documentID = dupixentPortal.getDocumentID();
		
		Logger("STEP 6: On Confirmation Page, Click on Submit button");
		dupixentPortal.clickOnSubmitButton();

//		Logger("STEP 7: Login to UAT Org as a PSR user");
//		uploadDocs.navigateToSFUrl();
//		documentsPage.logout();
//		homeportalPage = loginPage.userLogin(PSRUserName, UserPassword);
//		refresh();
		
		Logger("STEP 7: After Submitting the Documents from the Unauthenticated Portal, Now Log in QA org As DIS User");
		uploadDocs.navigateToSFUrl();
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(PSRUserName, UserPassword);

		Logger("STEP 8:Navigate to Received Document Object and Change List view to Received Document Worklist");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		documentsPage.verifyRecentlyViewDocumentList();
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		docMgmt.navigateToListofCPE("Received Document Worklist");

		Logger("STEP 9:Validate uploaded document is visible in Received Document Worklist.");
		documentsPage.searchDocumentWithName(documentID);
		Thread.sleep(7000);
		docMgmt.validateDOcdetails(documentID);

		Logger("STEP 10: User Logout the Application.");
		documentsPage.logout();
	}


	/**
	 * ====================================================================================================================
	 * Test Case Id:Automate ICARE-15654 - Regression-Doc Drop: Automate
	 * ICARE-10389: SIT: TC_02: To Validate Existing Enrollment form is routing into
	 * Received Document Worklist on uploading from Portal
	 * 
	 * @author Shanavaz Nishani , Date: 28-Mar-2025
	 * 
	 * @throws Exception ====================================================================================================================
	 */
		public void DDP08_IC12158_To_Validat_Existing_Enrollmentform_is_routing_into_Received_Document_Worklist_on_uploading_from_Portal()
			throws Exception 
	{		
		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC15";

		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L28.1 - Prurigo nodularis" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite 2: User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Prurigo Nodularis");
//		filePath1.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
//		updatepdf.updatePDFForm(TestCaseNumber, functionality);
//		System.out.println(filePath1.get());
		
		filePath = updatepdf.PDFCreation(TestCaseNumber, functionality);
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath);
		
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		String[] cpeDetails = new String[3];
//
		// Pre-requiste to get existing patient details from CPE
		Logger("Pre-requisite 3: To get the existing patient details from CPE");
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
		homeportalPage.closeTabs();

		accountObject.globalSearchNormal(searchFilter.get(1), "Automation");
		String cpeURL = getCurrentPageURL();
		accountObject.navigateToAccountAutomation();
		
		cpeDetails[0] = docMgmt.getPatientDetailsFromCPEPageName("Account Name");
		cpeDetails[1] = docMgmt.getPatientDetailsFromCPEPage("Birthdate");
		cpeDetails[2] = docMgmt.getPatientDetailsFromCPEPageEmail("Email");

		Logger("STEP 1: Go To Dupixent Unauthenticated Portal, Click on Accept All Cookies Button from the Cookies setting Prompt.");
		uploadDocs.navigateToDupxientUrl();
		dupixentPortal.clickOnAcceptAllCookies();
		dupixentPortal.handleLoginScreen();
		//dupixentPortal.clickOnAcceptAllCookies();

		Logger("STEP 2: On Welcome Screen, Select I am a Patient or Caregiver option.");
		dupixentPortal.clickOnPatientorCaregiverButton();

		Logger("STEP 3: On Main Screen, Click on Upload Document");
		dupixentPortal.clickOnUploadDocButton();

		Logger("STEP 4: Click on Submit Code, On Patient Information Page Update Patient First Name, Patient Last Name, Patient Date of Birth and Patient Email Address of exiting Pa");
		dupixentPortal.enterAccessCode("8443879370");
		dupixentPortal.clickOnSubmitCodeButton();
		dupixentPortal.enterPatientInfo(cpeDetails);
		dupixentPortal.clickOnSubmitDocCheckBox();

		Logger("STEP 5: Check on Consent and Upload any Dupixent Document.On Uploading Document Click on Done.");
		dupixentPortal.clickOnConsentCheckBoxes();
//		dupixentPortal.clickOnUploadFileButton();
		System.out.println(filePath);
		
		//uploadDocs.uploadPDFDocument(filePath1);
		//String[] filePath1 = filePath.split(".pdf");
		//System.out.println(filePath1[0]);
		uploadDocs.uploadFileWithSendKeys(filePath);
	
		Logger("STEP 6: On Confirmation Page, Click on Submit button");
		dupixentPortal.clickOnSubmitButton();
		String documentID = dupixentPortal.getDocumentID();
		System.out.println("DocumentID :: " + documentID);

		Logger("STEP 7: Login to UAT Org as a PSR user");
		uploadDocs.navigateToSFUrl();
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(PSRUserName, UserPassword);
		refresh();
		
		Logger("STEP 8: Navigate to Received Document Object and Change List view to Received Document Worklist.Validate uploaded document is visible in Received Document Worklist.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		docMgmt.navigateToListofCPE(RecivedlistViewFilters.get(2));
		System.out.println(documentID);
		documentsPage.searchDocumentWithName(documentID);
		documentsPage.validateRecordIsPresent(documentID);

		Logger("STEP 9: Assign the document to the user by clicking on the dropdown button on the right side and click on change owner button and selecting the DIS user → Open Received Document Record and Verify Document is not Linked to Patient and CPE record.");
		documentsPage.changeOwnerByDropdown(documentID);
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(0));
		docMgmt.navigateToListofCPE(RecivedlistViewFilters.get(1));
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));
		accountObject.clickOnTab(tabsName.get(0));
		documentsPage.validateCPEandRecDocFields();

		Logger("STEP 10: Navigate to Already Existing Patients CPE record,Verify Enrollment form uploaded is not linked in Received Document and Files Related list.");
		navigateToURL(cpeURL);
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.validatedata("Files", patientFirstName);
		missingInformatioPage.navigateToCPERecord(cpeDetails[0]);
		docMgmt.validatedata("Received Documents", patientFirstName);

		Logger("STEP 11: Now log out as a PSR user and Login as a PC user");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(PCUserName, UserPassword);

		Logger("STEP 12: Navigate to Received Document Object and Change List view to PSQA Listview.Validate uploaded document is not visible in PSQA Listview");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		documentsPage.verifyRecentlyViewDocumentList();
		documentsPage.navigatetoPSQAReviewWorklistView();
		fileName = documentsPage.getFileName(filePath);
		String docName = fileName + " (1)";
		documentsPage.searchDocument(docName);
		documentsPage.validateRecordIsPresent(docName);		
		documentsPage.logout();
	}
}