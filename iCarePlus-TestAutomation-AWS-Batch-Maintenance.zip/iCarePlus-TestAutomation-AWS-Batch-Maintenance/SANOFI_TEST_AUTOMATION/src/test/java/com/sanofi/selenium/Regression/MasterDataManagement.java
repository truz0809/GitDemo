package com.sanofi.selenium.Regression;

import java.util.HashMap;
import java.util.Map;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.CopayFlow;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;

public class MasterDataManagement extends BaseTest {
    private static ThreadLocal<String> filePath = new ThreadLocal<>();
    public ReadExcel excel;
    public String fileName;
    String functionality = "Fax";

    public static double getRandomNumber(double min, double max) {
        double x = (int) (Math.random() * ((max - min) + 1)) + min;
        return x;
    }

    double randomNum = getRandomNumber(1111, 9999);

    @BeforeMethod
    public void setUp() {
        utilityPage = GetInstance(Utility_Function.class);
        insuranceinfo = GetInstance(InsuranceInformation.class);
        diagnosisinformation = GetInstance(DiagnosisInfo.class);
        prescriptioninformation = GetInstance(PrescriptionInformation.class);
        updatepdf = GetInstance(UpdatePDF.class);
        patientSearch = GetInstance(PatientSearchPage.class);
        patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
        prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
        formConfirmation = GetInstance(FormConfirmation.class);
        accountObject = GetInstance(AccountObject.class);
        documentsPage = GetInstance(DocumentPage.class);
        generateTestData = GetInstance(GenerateTestData.class);
        excelDataUpdate = GetInstance(ExcelDataUpdate.class);
        bvPage = GetInstance(BenefitVerificationPage.class);
        paAppealsPage = GetInstance(PAAndAppealsPage.class);
        iapPage = GetInstance(IAPPage.class);
        uploadDocs = GetInstance(UploadDocument.class);
        assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
        missingInformatioPage = GetInstance(MissingInformatioPage.class);
        careProgram = GetInstance(CareProgramEnrolleePage.class);
        docMgmt = GetInstance(DocumentManagementPage.class);
        sheetName = "Fax";
        excel = new ReadExcel(sheetName);
        dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
        uploadDocs = GetInstance(UploadDocument.class);
        triagePage = GetInstance(TriagePage.class);
        copayFlow = GetInstance(CopayFlow.class);

    }

    @Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
    public void ExcelTestDataGeneration() throws Exception {
        Logger("Pre-Requisite : Generate test data for enrpllment test cases");
        generateTestData.generateEnrollmentTestData(functionality);
    }

    /***
     * 
     * Test Case Id:Automate ICARE-27016 R4.x-MDM Automate ICARE-16216-SIT-TC02-To
     * Validate updates on Correspondence templates
     * 
     * @author Shanavaz Nishani
     * 
     * @throws Exception ====================================================================================================================
     */
    @Test(description = "ICARE-16216-SIT-TC02-To Validate updates on Correspondence templates", enabled = true)
    public void MDM01_IC19067_Validate_updates_on_Correspondence_templates()
            throws Exception {

        String TestCaseNumber = "TC1";
        Map<String, String> ExcelTestData = new HashMap<String, String>();

        Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
        String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Diagnosis Code", "DUPIXENT MyWay",
                "Preferred Specialty Pharmacy", "State", "Zip", "City", "Language" };
        String columnValue[] = { "TRUE", "TRUE", "TRUE", "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE",
                "New York", "10001", "New York City", "English" };

        excelDataUpdate.selectExcelSheet(functionality);
        excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
        ExcelTestData = excel.getExcelInputData(TestCaseNumber);
        String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

        Logger("Pre-Requisite : User updates the Patient Form");
        updatepdf.selectEnrollmentForm("Atopic Dermatitis");
        filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
        updatepdf.updatePDFForm(TestCaseNumber, functionality);
        System.out.println(filePath.get());

        Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
        homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

        String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
                ExcelTestData.get(patientEmail) };

        Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
        String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

        Logger("Pre-Requisite STEP 4: Navigate To Recently View Document list");
        documentsPage.verifyRecentlyViewDocumentList();

        // Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
        // the record and click on 'Assign to me' button.");
        // documentsPage.navigateToReceiveddocument();
        // documentsPage.verifyAndAssignDocID(documentID);

        Logger("Pre-Requisite STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
        documentsPage.navigateToMyReceivedDocListView();
        documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

        Logger("Pre-Requisite STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
        // documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

        Logger("Pre-Requisite STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
        documentsPage.classifyDocument(documentType.get(0));
        documentsPage.submitDocument();

        Logger("Pre-Requisite STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
        documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

        Logger("Pre-Requisite STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
        patientSearch.verifyPatientSearchPageTitle();
        String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
        String patientFirstName = name[0];
        String patientMidName = name[1];
        String patientLastName = name[2];

        Logger("Pre-Requisite STEP 4: Verify Patient Search Page details and click on Next Button");
        patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
                ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
                ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
                ExcelTestData.get(patientDOB));
        patientSearch.clickOnNextButton();

        // patientinfoAndauthorization-Page
        Logger("Pre-Requisite STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
        String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
        String legalRepFirstName = legalRepName[0];
        String legalRepLastName = legalRepName[2];

        patientInfo.verifyPatientAuthorizationPageTitle();
        patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
                ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
                ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
                ExcelTestData.get(zip));
        patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
                patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
                ExcelTestData.get(textMessagingConsent));
        patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
                ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
                ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
                ExcelTestData.get(patientSecondaryphone));
        patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
        patientInfo.clickOnNextButton();

        // Patient Insurance - Page
        Logger("Pre-Requisite STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
        insuranceinfo.verifyInsuranceInfoPageTitle();
        insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
        insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
        insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
                ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
                ExcelTestData.get(rxPCN));

        insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
                ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
                ExcelTestData.get(insrelationshipToPatient));
        insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
                ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
        insuranceinfo.selectPayerPharmacy();
        insuranceinfo.selectMedicalPayer();
        insuranceinfo.clickOnNextButton();

        Logger("Pre-Requisite STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
        String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
        String preFirstName = preName[0];
        String prLastName = preName[2];

        String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
        String ofcFirstName = ofcName[0];
        String ofcLastName = ofcName[2];

        prescriberInformationPage.verifyPrescriberInfoPageTitle();
        prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
                ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
                ExcelTestData.get(prescriberstateLicense));
        prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
                ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
                ExcelTestData.get(prescriberZip));
        prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
                ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
                ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
        prescriberInformationPage.clickOnNextButton();

        // Diagnosis information-Page
        Logger("Pre-Requisite STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
        diagnosisinformation.verifyDiagnosisInfoPageTitle();
        diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
        diagnosisinformation.clickOnNextButton();

        Logger("Pre-Requisite STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
        String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
        String mdFirstName = mdName[0];
        String mdLastName = mdName[2];

        prescriptioninformation.verifyPrescriptionInfoPageTitle();
        prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
                ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
                ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
                prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
                ExcelTestData.get(NursePractitionerNPI));
        prescriptioninformation.clickOnNextButton();

        Logger("Pre-Requisite STEP 10:User Clicks on Form Confirmation Button");
        formConfirmation.clicOnFormConfirmation();
        documentsPage.verifyRecentlyViewDocumentList();

        Logger("Pre-Requisite STEP 11:Verify account is created ");
        accountObject.navigateToAccount();
        accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
        refresh();
        accountObject.clickOnTab(tabsName.get(1));

        Logger("Pre-Requisite STEP 12: Verify Care program enrollee record is linked to account ");
        accountObject.navigateCareProgramEnrollee();
        accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
        String ID = assessmentTasksPage.navigateAndGetID();

        Logger("Pre-Requisite STEP 13: User Logout the Application.");
        documentsPage.logout();

        Logger("STEP 1: Login the application as BV User.");
        homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

        Logger("STEP 2: Navigate to Assessment task and Change to All BVS Worklist. And Assign any Review and Finalize benefit Task to User.");
        homeportalPage.closeTabs();
        documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(2), DocumentPage.class);
        assessmentTasksPage.verifyRecentlyViewList();
        assessmentTasksPage.navigateToAllBVWorklist();
        String createdDate = assessmentTasksPage.verifyAndAssignCPERecord(ID);
        assessmentTasksPage.openCPETask(createdDate);

        Logger("STEP 3: Open CPE record and Complete BV");
        careProgram.clickOnWorkOrderTask(workOrderName.get(0));
        careProgram.clickOnMainTask(bvMainTaskNames.get(0));
        careProgram.clickOnSubTask(bvSubTaskNames.get(0));

        Logger("STEP 3.1: Update Member Plan Mandatory Fields and Click on SAVE button");
        bvPage.verifyAndEnterPharmacyDetails(ExcelTestData.get(rxPayerName), ExcelTestData.get(patientName),
                ExcelTestData.get(rxBIN), ExcelTestData.get(rxPhone), ExcelTestData.get(rxPCN), planType.get(0),
                ExcelTestData.get(rxGroup));
        bvPage.clickOnSavePharmacy();

        Logger("STEP 3.2: On Coverage Benefit section, Update Coverage Status as covered or PA Required and fill Other Mandatory fields,Click on SAVE then Click on Complete");
        bvPage.enterMandatoryDetailsOnCoverageBenefit(coverageStatus.get(0), pharmacyDeductiable.get(0),
                medicarePartD.get(0), paRequired.get(0), pAOutcomeOptions.get(0));
        bvPage.clickOnCoverageBenefitSave();
        bvPage.clickOnCompleteButton();

        Logger("STEP 4: Verify Correspondence page is displayed");
        missingInformatioPage.validateCorrespondencePageDisplayed();

        Logger("STEP 4.1: Verify the below correspondence is visible, select the template, DMW Copay Card Information- MD Fax");
        docMgmt.selectItemsToSend(itemToSend.get(5));
        missingInformatioPage.clickNextButton();
        missingInformatioPage.clickNextButton();

        Logger("STEP 4.2: Validate The Data and Dup Codes on Correspondence document template.");
        String pdfname = itemToSend.get(5);
        String DEST = docMgmt.downloadPDFfromGenerateDocScreen(pdfname, cpeName);
        docMgmt.validatePDFData(DEST + ".pdf", dupCodes.get(0), 1);
        docMgmt.deletePDF(DEST + ".pdf");
        missingInformatioPage.navigateToCPERecord(cpeName);
        refresh();
        String CpeUrl = getCurrentPageURL();

        Logger("STEP 5: Logout as BV user");
        documentsPage.logout();

        Logger("STEP 6: Login into Application with CM user.");
        homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

        Logger("STEP 7: Navigate to CPE Object and Access CPE record");
        navigateToURL(CpeUrl);
        Thread.sleep(4000);

        Logger("STEP 8: Verify that Copay Work Order is completed");
        copayFlow.verifyWorkOrderStatus(selectProcessName.get(3), StatusCheck.get(1));

        Logger("STEP 9: Click on the Correspondence Button, Select the Process Name as Copay and validate the below Correspondence is visible in Select Items to Send picklist. DMW Copay Card Information- MD Fax");
        docMgmt.clickOnCorrespondenceBotton();
        docMgmt.selectProcessName(selectProcessName.get(3));
        docMgmt.selectItemsToSend(itemToSend.get(5));
        missingInformatioPage.clickNextButton();
        missingInformatioPage.clickNextButton();

        Logger("STEP 9.1: Validate Dup Code on Correspondence document generated.");
        String pdfName = itemToSend.get(5);
        String dest = docMgmt.downloadPDFfromGenerateDocScreen(pdfName, cpeName);
        docMgmt.validatePDFData(dest + ".pdf", dupCodes.get(0), 1);
        docMgmt.deletePDF(dest + ".pdf");

        Logger("STEP 10: Logout from the application");
        documentsPage.logout();

    }

}