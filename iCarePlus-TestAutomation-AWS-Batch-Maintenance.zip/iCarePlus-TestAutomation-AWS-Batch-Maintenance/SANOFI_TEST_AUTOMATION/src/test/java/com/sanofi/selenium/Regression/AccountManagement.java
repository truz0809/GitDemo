package com.sanofi.selenium.Regression;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.CopayFlow;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.HealthcareAccountSearch;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PAPPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;

public class AccountManagement extends BaseTest {
	private static ThreadLocal<String> filePath = new ThreadLocal<>();
	public ReadExcel excel;
	public String fileName;
	String functionality = "RGNAM";

	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		copayFlow = GetInstance(CopayFlow.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		triagePage = GetInstance(TriagePage.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		sheetName = "PDF_Data";
		excel = new ReadExcel(sheetName);
		papPage = GetInstance(PAPPage.class);
		hcAccountSearch = GetInstance(HealthcareAccountSearch.class);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE18030 RGN-AM: Automate ICARE-5132-SIT-TC02-To Verify the
	 * Order of columns in Cases- List Views
	 * 
	 * @author Shanavaz Nishani , date- 5/2/2025
	 *         ====================================================================================================================
	 * @throws Exception
	 */
	@Test(description = "SIT: TC01: Validation of welcome case creation via enrollment form", enabled = true)
	public void AM01_IC13203_Verify_the_Order_of_columns_in_Cases_List_Views() throws Exception {

		int numberOfUsers = 3;
		SoftAssert softassert = new SoftAssert();
		String currentUser = "";
		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {
				case 0:
					Logger("STEP 1: Login to the UAT Org as 'Case Manager'.");
					homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
					currentUser = "CM";
					break;
				case 1:
					Logger("STEP 1: Login to the UAT Org as 'PC User'.");
					homeportalPage = loginPage.userLogin(PCUserName, UserPassword);
					currentUser = "PC";
					break;
				case 2:
					Logger("STEP 1: Login to the UAT Org as 'PM User'.");
					homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
					currentUser = "PM";
					break;
				}

				homeportalPage.closeTabs();
				Logger("STEP 2: Click on App Launcher and select the Cases Object ,Verify \"Recently Viewed\" cases list view is displayed");
				documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5),
						DocumentPage.class);

				Logger("STEP 3: Verify the below columns are displayed in order from left to right as mentioned : 1.Case Number 2.Record Type 3.Care Program Enrollee 4.Status 5.Date/Time Opened 6.Case Owner Alias");
				assessmentTasksPage.verifyRecentlyViewList();
				docMgmt.verifyColumnOrder();

				Logger("STEP 4: Select \"All Open Cases \" from cases List view");
				docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(5));
				assessmentTasksPage.clickOnListView(Cases_ListView.get(1));

				Logger("STEP 4.1: Verify the below columns are displayed in order from left to right as mentioned : 1.Case Number 2.Record Type 3.Care Program Enrollee 4.Status 5.Date/Time Opened 6.Case Owner Alias");
				docMgmt.verifyColumnOrder();

				Logger("STEP 5: Select \"My Cases \" from cases List view");
				docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(5));
				assessmentTasksPage.clickOnListView(Cases_ListView.get(2));

				Logger("STEP 5.1: Verify the below columns are displayed in order from left to right as mentioned : 1.Case Number 2.Record Type 3.Care Program Enrollee 4.Status 5.Date/Time Opened 6.Case Owner Alias");
				docMgmt.verifyColumnOrder();

				Logger("STEP 6: Select \"My Open Cases \" from cases List view");
				docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(5));
				assessmentTasksPage.clickOnListView(Cases_ListView.get(3));

				Logger("STEP 6.1: Verify the below columns are displayed in order from left to right as mentioned : 1.Case Number 2.Record Type 3.Care Program Enrollee 4.Status 5.Date/Time Opened 6.Case Owner Alias");
				docMgmt.verifyColumnOrder();

				Logger("STEP 7: Logout from the application");
				documentsPage.logout();

			}

			catch (Exception e) {
				Logger("Test failed for user " + currentUser + " due to error: " + e.getMessage());
			}
		}

		softassert.assertAll();
	}
	
	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE-22917 Verify related list views on HCO and HCP accounts for FRM User
	 * 
	 * @author Anand Pawar 
	 * @throws Exception
	 * ====================================================================================================================
	 * TC is cancelled as FRM User is decommissioned
	 * 
     */
	/*@Test(description = "Verify related list views on HCO and HCP accounts for FRM User", enabled = true)
	public void AM02_IC22917_Verify_related_list_views_on_HCO_and_HCP_accounts_for_FRM_User() throws Exception {
		
		Logger("STEP 1: Login to Org as FRM User.");
		homeportalPage = loginPage.userLogin(FRMUserName, UserPassword);		
		homeportalPage.closeTabs();

		Logger("STEP 2: Navigate to Accounts Object");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(3),
				DocumentPage.class);
		
		Logger("STEP 3: Select all HCPs list view");
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(3));
		assessmentTasksPage.clickOnListView(Accounts_ListView.get(0));
		
		Logger("STEP 4:Verify the Patient Account related list is update with the following Columns:First Column displays the name:  Name and Zip Code Column \r\n");
		docMgmt.clickOnHCPLink();
		accountObject.clickOnTab(tabsName.get(1));
		String[] columns= {"Name"};
		accountObject.verifyColumns(columns);	
		accountObject.verifyColumn();	
		accountObject.verifyZipColumnNotPresent();
		
		Logger("STEP 5:Navigate to Accounts Object>Select the All Facilities from the list view>Select a Facility record and click on the Related List");
		accountObject.navigateToAccount();
		docMgmt.ClicklistViewdropdownobject(appLauncherMenuItem.get(3));
		assessmentTasksPage.clickOnListView(Accounts_ListView.get(1));

		Logger("STEP 6:Verify the Patient Account related list is update with the following Columns:First Column displays the name:  Name and Zip Code Column \r\n");
		docMgmt.clickOnHCPLink();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyColumns(columns);	
		accountObject.verifyColumn();
		accountObject.verifyZipColumnNotPresent();
		
		Logger("STEP 7: Logout from the application");
		documentsPage.logout();	
		
	}*/
}
