package com.sanofi.selenium.Regression;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.testng.annotations.*;
import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.Configuration;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.AuthorizationFormConsentPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.CareTeamAssignment;
import com.sanofi.selenium.pages.ConsentCaptureDate;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.HealthcareAccountSearch;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.Log;
import com.sanofi.selenium.utils.ReadExcel;

public class MissingInformationMgmnt extends BaseTest {
	public static String PatientName, PatientDoB, PatientEmail, CMName, CPEURL, existingCPEURL;

	private static ThreadLocal<String> filePath = new ThreadLocal<>();
	public ReadExcel excel;
	public String fileName;
	String functionality = "MissingInformation";
	public static String CPEMissingInfoURL, caseOwner;

	public static double getRandomNumber(double min, double max) {
		double x = (int) (Math.random() * ((max - min) + 1)) + min;
		return x;
	}

	double randomNum = getRandomNumber(1111, 9999);

	@BeforeMethod
	public void setUp() {

		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		authorizationConsentPage = GetInstance(AuthorizationFormConsentPage.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		sheetName = "MI_Management";
		excel = new ReadExcel(sheetName);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		uploadDocs = GetInstance(UploadDocument.class);
		triagePage = GetInstance(TriagePage.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		hcAccountSearch = GetInstance(HealthcareAccountSearch.class);
		authorizationConsentPage = GetInstance(AuthorizationFormConsentPage.class);
		consentCaptureDate = GetInstance(ConsentCaptureDate.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		sheetName = "MI_Management";
		excel = new ReadExcel(sheetName);
		uploadDocs = GetInstance(UploadDocument.class);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		CPEMissingInfoURL = Configuration.readApplicationFile("CPEMissingInfo");
		caseOwner = Configuration.readApplicationFile("DISUserOwner");
		careTeamAsgn = GetInstance(CareTeamAssignment.class);

	}

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-2777 To validate that Case Manager can update relevant
	 * Missing Information
	 * 
	 * @author Anand Pawar
	 * @Maintenance_author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "To validate that Case Manager can update relevant Missing Information", enabled = true)
	public void MI01_IC2777_To_validate_that_Case_Manager_can_update_relevant_Missing_Information() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC1";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified" };
		String removeColumnValue[] = { "Zip" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnValue);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 13:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 14:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 15: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 16: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		homeportalPage.closeTabs();

		Logger("STEP 17:  Verify recently view list is displayed and search the CPE Record.");
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 18: Navigate to MI-Tab and click on MI Case");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.clickOnMICase();

		Logger("STEP 19: Click on the Patient hyperlink to open the Patient record");
		missingInformatioPage.clickonAccount(ExcelTestData.get(patientName));

		Logger("STEP 20: Validate that Case Manager can edit and save the following fields on patient:Birthdate,Gender,Address,Email,Phone");
		refresh();
		docMgmt.clcikOnEditbtn("Birthdate");
		docMgmt.editDOB();
		docMgmt.editGender();
		docMgmt.editPhone();
		docMgmt.editEmail2(patientFirstName);
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 21: Navigate to Patient’s related lists → Open the Medication Request record → Validate that the following fields can be edited and saved by Case Manager:Medication and Refill Quantity");
		missingInformatioPage.navigateToCPERecord(cpeName);
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToMedicationRequestTable();
		accountObject.clickonFirstMedicationRequest();
		docMgmt.clickEditMedication();
		docMgmt.editRefillQty();
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.clickonAccount(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 22: Navigate to Patient’s related lists → Open the Health Conditions record → Validate that the following fields can be edited and saved by Case Manager:Condition Code and Onset Period Date");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToHealthConditions();
		accountObject.clickonHealthConditionRecord();
		docMgmt.clickEditConditionCode();
		docMgmt.editCopdCode();
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.clickonAccount(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 23:  Navigate to Patient’s related lists → Open the Member Plan (Pharmacy) record → Validate that the following fields can be edited and saved by Case Manager:Group number and Rx PCN");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToMemberPlantable();
		accountObject.clickOnMemberPlan(memberPlan.get(0));
		docMgmt.editGroupNumberRxPCN();
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.clickonAccount(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 24:  Navigate to Patient’s related lists → Open the Member Plan (Medical) record → Validate that the following fields can be edited and saved by Case Manager:Insurance Phone and Policy");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToMemberPlantable();
		accountObject.clickOnMemberPlan(memberPlan.get(1));
		docMgmt.editInsurancePhone();
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 25: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-1692 Test Configuration of Missing Information for a given
	 * Care Program
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Test Configuration of Missing Information for a given Care Program.", enabled = true)
	public void MI02_IC1692_Test_Configuration_of_Missing_Information_for_a_given_Care_Program() throws Exception {

		Logger("STEP 1: Log in to the org with Admin Read only user");
		homeportalPage = loginPage.userLogin(SAUserName, UserPassword);

		Logger("STEP 2: Go to Setup >>Click on Object Manager and Navigate to \"Care Program Missing Information\"  object");
		homeportalPage.closeTabs();
		navigateToUrl(CPEMissingInfoURL);

		Logger("STEP 3: Go to Fields and Relationship");
		boolean homepage = dupixentPortal.verifyLoginScreen();
		if (homepage) {
			homeportalPage = loginPage.userLogin(SAUserName, UserPassword);
		}
		missingInformatioPage.navigateToDataList("Fields & Relationships");

		Logger("STEP 4: Validate that the \"MI Records\" page layout  has a Status Field with the Following Picklist Values:Active,Inactive");
		missingInformatioPage.clickOnFieldLabel("Status");
		missingInformatioPage.validatePicklistValue();

		Logger("STEP 5: Validate that the Care Program MI contains the categories of MI: ");
		missingInformatioPage.navigateToDataList("Fields & Relationships");
		missingInformatioPage.clickOnFieldLabel("Categories");
		missingInformatioPage.validateCategoriesValue();

		Logger("STEP 6: Validate that the Care Program MI also contains the fields listed in the attached document");
		missingInformatioPage.navigateToDataList("Fields & Relationships");
		missingInformatioPage.validateFieldLabelValue();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-3161 Automated Check for Missing Information following
	 * Enrollment Form Submission for multiple MI Case created.
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Automated Check for Missing Information following Enrollment Form Submission for multiple MI Case created.", enabled = true)
	public void MI03_IC3161_Automated_Check_for_MI_following_Enrollment_FormSubmission_for_multiple_MI_Case_created()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC3";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String removeColumnData[] = { "Address", "City", "State", "Diagnosis Code" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 4:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 5:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 6: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 7: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 8:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 9:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 10:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 11:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 16:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 17:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the Org as 'CM User'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 20: Open ICARE Connect App from the App launcher.");
		homeportalPage.closeTabs();

		Logger("STEP 21: Search record and click on Care program enrollee list");
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 22: Go to MI tab and validate newly created MI cases as per missing information on the Enrollment form ");
		accountObject.clickOnTab(tabsName.get(2));
		List<String> caseNames = Arrays.asList("Patient Address Street", "Patient State", "Diagnosis Missing",
				"Patient City");
		List<String> expectedStepsBlocked = Arrays.asList("QuickStart;SP Triage;IAP;Copay;PAP",
				"QuickStart;SP Triage;IAP;Copay;PAP", "BV;QuickStart;SP Triage;IAP;PAP",
				"QuickStart;SP Triage;IAP;Copay;PAP");

		missingInformatioPage.verifyStepsBlockedDueToMI(caseNames, expectedStepsBlocked);
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-13469 Regression-Missing Info Mgmnt: Automate the flow to
	 * populate all the needed fields in MI,when created manually and automatically
	 * as a BV Specialist
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT-TC03-To validate the flow to populate all the needed fields in MI,when created manually and automatically as a BV Specialist.", enabled = true)
	public void MI04_IC3034_validate_the_flow_to_populate_all_the_needed_fields_in_MI_when_created_manually_and_automatically_as_a_BVSpecialist()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC4";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "Date Of Diagnosis" };
		String columnValue[] = { "", "" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.1:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 3.2: Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 3.3: After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 4:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 5:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 6:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 7:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 7.1:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 7.2:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 7.3:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.openCPERecord();
		String url = getCurrentPageURL();

		Logger("STEP 12: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 8: Login as a BV Specialist  in the Org.");
		homeportalPage = loginPage.userLogin(BVUsername, UserPassword);

		Logger("STEP 9: Navigate to Care Program Enrollee tab and open the newly created Care Program Enrollee and Validate that the status = Active.");
		navigateToUrl(url);

		Logger("STEP 10: Now click on the MI tab>> in the Cases Related List ,click on New");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.clickNewButton();

		Logger("Step 11 : Search and Select the Care Program MI from the search box (Selecting \"DMW Asthma : Patient DOB\" for now ) and Click on Save");
		missingInformatioPage.selectCareProgramMI("Patient DOB");
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 12: Validate that the \"Step Blocked due to MI\" field is having values which are blocking the WO steps");
		missingInformatioPage.verifyStepblockedDueToMI();

		Logger("STEP 13: Validate the \"Subject\" Field is visible in the page layout.");
		missingInformatioPage.verifyFieldPresentOnLayout("Subject");

		Logger("STEP 14: Validate the \"Category\" Field is visible in the page layout.");
		missingInformatioPage.verifyFieldPresentOnLayout("Category");

		Logger("Step 15: Validate that the \"HCP Account Name\" field is populated with HCP Account ID");
		missingInformatioPage.verifyHCPAccountName(ExcelTestData.get(prescriberName));

		Logger("STEP 16: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-ICARE-13475 Regression-Missing Info Mgmnt: Automate MI
	 * Case is assigned automatically to the Case Manager mentioned in its
	 * respective CPE
	 * 
	 * @author Sonica P
	 * @Maintainence_author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "ICARE-13475 Regression-Missing Info Mgmnt: Automate MI Case is assigned automatically to the Case Manager mentioned in its respective CPE", enabled = true)
	public void MI05_IC4021_Validate_that_MI_Case_is_assigned_automatically_to_the_Case_Manager_mentioned_in_its_respective_CPE()
			throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC5";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_TestCase08);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(0).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Nasal Polyps");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 17: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);

		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		Logger("STEP 18: Logout as DIS User");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 20: Navigate to the Care program Enrollees object");
		navigateToUrl(cpeURL);

		Logger("STEP 21: Open the the MI Cases on the CPE → Validate that 'Case Owner' field is visible on CPE highlights panel → Validate that initially the Case Owner of automatically created MI Cases is the DIS who submitted the Enrollment Form");
		accountObject.clickOnTab(tabsName.get(2));
		careProgram.clickOnOpenCase();
		String expectedCaseOwner = caseOwner;
		missingInformatioPage.validateCaseOwner(expectedCaseOwner);

		Logger("STEP 22: Validate that if there is any Missing Information Case record present for the CPE then a warning symbol will be visible on highlight panel 'MI' field and otherwise this field will remain blank");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		missingInformatioPage.verifyMIIconIsDisplayed();

		Logger("STEP 23: Validate if the warning symbol is displayed, then verify the columns of MI Panel");
		missingInformatioPage.validateMIColumns();

		Logger("STEP 24:  Logout AS DIS and Login as PC User.");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(PCUserName, UserPassword);

		Logger("STEP 25: On CPE, add Case Manager as Care Program Enrollee Team Member in related list manually  → Validate that Case Owner of existing MI Cases also gets updated to the Case Manager added as Care Program Enrollee Team Member");
		navigateToUrl(cpeURL);
		accountObject.clickOnTab(tabsName.get(1));
		careTeamAsgn.clickOnNewButton();
		expectedCaseOwner = careTeamAsgn.enrollTeamMember("Case Manager");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(2));
		careProgram.clickOnOpenCase();
		missingInformatioPage.validateCaseOwner(expectedCaseOwner);

		Logger("STEP 26:  Logout as PC.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-3438:Completing MI Received via Document Intake
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Completing MI Received via Document Intake", enabled = true)
	public void MI06_IC3438_Completing_MI_Received_via_Document_Intake() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC6";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 5:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 6:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 7: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 8: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 9:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 10:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 11:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 12:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 16:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 13:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Step 14: Validate newly added below fields not visible on the Details page of Received Document: Case Manager Reviewed by CM");
		String childDocFileName = "Enrollment Form";
		missingInformatioPage.navigateToCPERecord(childDocFileName);
		accountObject.clickOnTab(tabsName.get(0));
		documentsPage.verifyFieldsAreNotVisible();

		Logger("STEP 15: Logout as DIS user.");
		documentsPage.logout();

		Logger("STEP 16: Login to the as 'CM user'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 17: Open ICARE Connect App from the App launcher.");
		homeportalPage.closeTabs();

		Logger("STEP 18: Search record and click on Care program enrollee list");
		accountObject.globalSearch(searchFilter.get(1), cpeName);
		String cpeURL = getCurrentPageURL();

		Logger("STEP 19: Validate Received Document on Related List of CPE record.");
		accountObject.clickOnTab(tabsName.get(1));
		docMgmt.navigateToReceivedDocTable();
		careProgram.clickOnViewAll("Received Documents");
		docMgmt.verifyReceivedDocIDLinkedToCPE(childDocFileName);

		Logger("STEP 20:  Logout as cm.");
		documentsPage.logout();

		Logger("STEP 21:  Logout AS CM and Login as PC User.");
		homeportalPage = loginPage.userLogin(PCUserName, UserPassword);

		Logger("STEP 22: Add Case Manager on CPE as CPE Team Member in related list and verify CM is also updated");
		navigateToUrl(cpeURL);
		accountObject.clickOnTab(tabsName.get(1));
		careTeamAsgn.clickOnNewButton();
		String caseManager = careTeamAsgn.enrollTeamMember("Case Manager");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		docMgmt.navigateToAccount();
		String accountDetails[] = accountObject.getCPEDetails();

		// Patient name
		String[] existingPname = updatepdf.splitFullName(accountDetails[0]);
		String patientFName = existingPname[0];
		String patientLName = existingPname[2];

		// Patient DOB
		String dob = Utility_Function.changeFormatDateMMddYYYY(accountDetails[1]);

		// Patient email
		String email = accountDetails[2];

		// patient phone
		String patientPhone = Utility_Function.formatNumber(accountDetails[3]);

		Logger("STEP 23:  Logout as cm.");
		documentsPage.logout();

		Logger("STEP 24:  Logout AS DIS and Login as PC User.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 25: Upload document to Dupixent portal");
		String[] cpeDetails2 = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID2 = uploadDocs.uploadDoc(filePath.get(), cpeDetails2);

		Logger("STEP 26: Navigate to the Recently view ");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 27:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID2, status.get(1));

		Logger("STEP 28:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 29: After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 30: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));

		Logger("Step 31: Click on 'search Patient' button and Select an existing patient from the search table and click on next button and  Validate message on the Received document that \"Case Manager has been assigned successfully\".");
		patientSearch.searchExistingPatient2(patientFName, patientLName, dob, patientPhone, email, zipCode);
		patientSearch.verifyCaseMangerAssignedMSG();

		String docUrl = getCurrentPageURL();

		Logger("STEP 32: Logout as DIS and Login as Case Manager");
		documentsPage.logout();

		Logger("STEP 33: Login to the as 'CM user'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 34: Go to Received Documents and open earlier submitted Received document");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(0), DocumentPage.class);
		documentsPage.verifyRecentlyViewDocumentList();
		navigateToUrl(docUrl);

		Logger("STEP 35: Validate Received document page layout: Document PDF on the Left-Hand Side Related List and Details Tab on the Right-Hand side.");
		docMgmt.validateDocumentPageLayout();

		Logger("STEP 36: Validate newly added below fields on the Details page of Received Document");
		documentsPage.verifyFieldsAreVisible();

		Logger("STEP 37: Validate newly added below fields on the Details page of Received Document");
		documentsPage.verifyFieldsValue(caseManager, cpeName);

		Logger("STEP 38: Logout as case Manager");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-ICARE-5220 Validate that MI Cases are created for
	 * Caregiver/Legal Representative if Patient is a minor
	 * 
	 * @author Sonica P
	 * @Maintainence_author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Regression-Missing Info Mgmnt: Automate MI Cases are created for Caregiver/Legal Representative if Patient is a minor", enabled = true)
	public void MI07_IC5220_Validate_that_MI_Cases_are_created_for_Caregiver_LegalRepresentative_if_Patient_is_a_minor()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC7";

		String columnName[] = { "Patient DOB", "State", "Diagnosis Code", "Text Messaging Consent" };
		String columnValue[] = { "01-16-2024", "California", "L20.9 - Atopic dermatitis, unspecified", "TRUE" };
		String removeColumnData[] = { "Legal Representative Name" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite 02: User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		Logger("STEP 2:Upload document to Dupixent portal");
		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 2.1: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.1: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 4: On Classify document page select Doc type = Enrollment Form > Click on submit.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 4.1: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4.2: Enter the CARE PROGRAM PRODUCT > Click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 4.3: In Patient Information & Authorizations pg enter all the mandatory details of the patient.");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 4.4: Enter all the mandatory details in the Insurance Information section > Click on next.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 4.5: In the Prescriber Information section fill the  details and Select HCP and HCO via Search Functionality> click on next.");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 4.6: In the Diagnosis Information fill all the mandatory details > click on next.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 4.7:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 5: Click on Submit and Enrollment Form should be submitted");
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 6:  Navigate to CPE record.");
		accountObject.navigateToCareProgramEnrollee();
		assessmentTasksPage.verifyRecentlyViewList();
		documentsPage.searchDocument(cpeName);
		missingInformatioPage.clickOnRecord(cpeName);

		Logger("STEP 7:  Validate MI Case is created for Caregiver and blocking BV, QS and Triage stage.");
		accountObject.clickOnTab(tabsName.get(2));
		List<String> caseNames = Arrays.asList("Caregiver Missing");
		List<String> expectedStepsBlocked = Arrays.asList("BV;QuickStart;SP Triage;Copay");
		missingInformatioPage.verifyStepsBlockedDueToMI(caseNames, expectedStepsBlocked);

		Logger("STEP 8:  Logout as DIS user.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-4325 Validate the Manual creation of MI record when PAP is
	 * blocked / or user wants to gather more information for PAP
	 * 
	 * @author Kavyashree MB
	 * @Maintenance_author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Validate the Manual creation of MI record when PAP is blocked / or user wants to gather more information for PAP", enabled = true)
	public void MI08_IC4325_Validate_the_Manual_creation_of_MI_record_when_PAP_is_blocked_or_user_wants_to_gather_more_information_for_PAP()
			throws Exception {

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care Program Enrollee'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 3: Change List view to 'Recently View' queue list view.");
		docMgmt.verifyRecentlyViewList();

		Logger("STEP 4: Open the any newly created CPE");
		documentsPage.searchDocument("Automation");
		String recordName = missingInformatioPage.searchAndOpenRecord();

		Logger("STEP 5: Navigate to MI Tab ");
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 6: Now click on the \"New\" Button at the top right corner of the MI section.");
		missingInformatioPage.clickNewButton();

		Logger("STEP 7: Give the Care Program MI and hit on save button.");
		String miName = "Patient Program Consent";
		missingInformatioPage.selectCareProgramMI(miName);
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToCPERecord(recordName);
		refresh();

		Logger("STEP 8:Navigate to the Missing Information section and verify the fields in newly created Missing Information record is displayed");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.validateStepBlockedMI("Patient Program Consent", "PAP");

		Logger("STEP 9:Verify if thes record contains the step blocked due to MI value as PAP and verify if that record is in Not Collected/Open Status, Click on the record, and Update the Status as Collected");
		missingInformatioPage.changeStatusOfMICases();

		Logger("STEP 10: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-12552 Regression-MIM: Automate ICARE-6585: SIT: TC02: To
	 * Validate User is able to Collect MI Cases with appropriate information
	 * 
	 * @author Sonica prasad
	 * @Maintenance_author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "Regression-MIM: Automate ICARE-6585: SIT: TC02: To Validate User is able to Collect MI Cases with appropriate information", enabled = true)
	public void MI09_IC12552_ICARE_6585_To_Validate_User_is_able_to_Collect_MI_Cases_with_appropriate_information()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC9";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated" };
		String removeColumnData[] = { "Legal Representative Name", "Patient Authorization Date",
				"Patient Primary phone", "Prescriber Name", "Prescriber NPI", "Prescriber Signed",
				"Prescriber Signature Date" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Asthma");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the VAL Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.1: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 4: On Classify document page select Doc type = Enrollment Form > Click on submit.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 4.1: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4.2: Enter the CARE PROGRAM PRODUCT > Click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 4.3: In Patient Information & Authorizations pg enter all the mandatory details of the patient.");
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.clearTextFromDateField();
		patientInfo.enterAutherization(authorizationSigned.get(1), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(1), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 4.4: Enter all the mandatory details in the Insurance Information section > Click on next.");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 4.5: In the Prescriber Information section fill the  details and Select HCP and HCO via Search Functionality> click on next.");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		System.out.println(ExcelTestData.get(prescriberZip));
		System.out.println(ExcelTestData.get(specialty));
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 4.6: In the Diagnosis Information fill all the mandatory details > click on next.");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 4.7:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(1), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));

		Logger("STEP 5: Click on Submit and Enrollment Form should be submitted");
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 6:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);

		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		Logger("STEP 7: Logout AS DIS and Login as CM User.");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 8: Navigate to the Care Program Enrollee object and validate that MI cases are created for all the missed-out information with Status-Open");
		navigateToURL(cpeURL);
		accountObject.clickOnTab(tabsName.get(2));
		List<String> caseNames = Arrays.asList("Patient DOB", "Patient HIPAA Consent", "Patient Program Consent",
				"Patient HIPAA Consent", "HCP Consent", "Prescriber Missing");
		missingInformatioPage.verifyStatusOfMICase(caseNames, statusOptionsMIOpenCases.get(1));

		Logger("Step 9: Update Status of any one of the MI cases from Open to In Progress and Validate no Validation error is prompted");
		missingInformatioPage.verifyInProgressStatus(statusOptionsMIOpenCases.get(1));

		Logger("Step 10: Validate System throws an error when user updates Status field as any other then In Progres");
		missingInformatioPage.verifyOtherThanInProgressStatus(statusOptionsMIOpenCases.get(5));

		Logger("STEP 8:  Logout as CM user.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-12542 To Validate Bulk Close button on MI Tab List view
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "To Validate Bulk Close button on MI Tab List view.", enabled = true, priority = 33)
	public void MI10_IC12542_To_Validate_Bulk_Close_button_on_MI_Tab_List_view() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC10";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code" };
		String columnValue[] = { "L20.9 - Atopic dermatitis, unspecified" };
		synchronized (excelDataUpdate) {
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			excelDataUpdate.selectExcelSheet(functionality);
		}
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 10: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 11: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 12:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 13:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 15:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 16:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 16:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 17:Verify account is created ");
		accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 18: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		Logger("STEP 19: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 20: Login to the QA_SIT Org as 'Case Manager");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		navigateToUrl(CPEURL);
		Thread.sleep(4000);

		Logger("STEP 21: Navigate to MI-Tab");
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 22: Validate Bulk Close button is visible on the MI Open Cases Related list view.");
		missingInformatioPage.verifyBulkCloseButton(tableNames.get(0));

		Logger("STEP 23: Validate that Bulk Close Button is not present on Closed Cases Related List View.");
		missingInformatioPage.verifyBulkCloseButton(tableNames.get(1));

		Logger("STEP 24:Check the Checkbox of multiple Open MI cases present in the Open Cases Related List view and Click on Bulk Close Button.");
		missingInformatioPage.selectMultipleMICasesCheckbox();
		missingInformatioPage.clickBulkCloseButton();

		Logger("STEP 25.Validate the Omniscript Page Layout displayed");
		missingInformatioPage.validateOmniScriptLayout();

		Logger("STEP 26.Validate Status Picklist field on New Tab consists of 2 Picklist Values: Collected,Not Collected");
		missingInformatioPage.validateStatusPicklistValue();

		Logger("STEP 30.Verify validation rule is added on the \"Status\" field that prevents the user from selecting \"Not Collected\" unless ALL of the following fields are populated:(i.e user need to fill all the details on the displayed omni script page) -1st Attempt,1st Attempt Date,2nd Attempt,2nd Attempt Date,3rd Attempt,3rd Attempt Date");
		missingInformatioPage.verifyValidationRuleForStatusNotCollected();
		missingInformatioPage.clickOnPreviousButton();

		Logger("STEP 31.validate that a user cannot save a Missing Information Case record when the \"1st Attempt\" OR \"1st Attempt Date\" fields are Blank, and the Status field = Collected and click on next");
		missingInformatioPage.verifyMICaseSaveErrorAttemptBlank();

		Logger("STEP 32. Select the Status as Not Collected on the status field and fill all the fields on the page layout and Click on Next Button");
		missingInformatioPage.saveStatusNotCollcted();
		refresh();
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 33.Validate all the selected MI Cases should be updated as Not Collected and all other fields are populated on the MI Case record.");
		missingInformatioPage.verifyNotCollectedStatus();

		Logger("STEP 34.Verify Canceled Picklist value is added in Status field of MI Case record");
		missingInformatioPage.verifyCanceledPicklistValue("Patient Program Consent");

		missingInformatioPage.clickNewButton();

		// create new MI to check collected status working
		String miName = "Patient Program Consent";
		missingInformatioPage.selectCareProgramMI(miName);
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 35.Select the Status as Collected on the status field and fill all the fields on the page layout and Click on Next Button");
		missingInformatioPage.changeStatusOfMICases();

		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.clickNewButton();

		// create new single MI, repeat all steps
		String miSingleName = "Primary Indication";
		missingInformatioPage.selectCareProgramMI(miSingleName);
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 36:Check the Checkbox of multiple Open MI cases present in the Open Cases Related List view and Click on Bulk Close Button.");
		missingInformatioPage.selectMultipleMICasesCheckbox();
		missingInformatioPage.clickBulkCloseButton();

		Logger("STEP 37.Validate the Omniscript Page Layout displayed");
		missingInformatioPage.validateOmniScriptLayout();

		Logger("STEP 38.Validate Status Picklist field on New Tab consists of 2 Picklist Values: Collected,Not Collected");
		missingInformatioPage.validateStatusPicklistValue();

		Logger("STEP 39.Validate that the following Picklist Value is added to the First Attempt, Second Attempt, and Third Attempt Missing Information case fields >> Not Applicable");
		missingInformatioPage.validateAttemptPicklistValue();

		Logger("STEP 40.Validate that the \"Reason\" dependent field is shown to the user when Attempt 1 Type OR Attempt 2 Type OR Attempt 3 Type = Not Applicable.");
		missingInformatioPage.validateReasonDependentField();

		Logger("STEP 41.Validate that the Reason Picklist fields, Picklist Options: Enrollment Oversight, Triaged to SP");
		missingInformatioPage.validateReasonPickListValues();

		Logger("STEP 42.Verify validation rule is added on the \"Status\" field that prevents the user from selecting \"Not Collected\" unless ALL of the following fields are populated:(i.e user need to fill all the details on the displayed omni script page) -1st Attempt,1st Attempt Date,2nd Attempt,2nd Attempt Date,3rd Attempt,3rd Attempt Date");
		missingInformatioPage.verifyValidationRuleForStatusNotCollected();
		missingInformatioPage.clickOnPreviousButton();

		Logger("STEP 43.validate that a user cannot save a Missing Information Case record when the \"1st Attempt\" OR \"1st Attempt Date\" fields are Blank, and the Status field = Collected and click on next");
		missingInformatioPage.verifyMICaseSaveErrorAttemptBlank();

		Logger("STEP 44. Select the Status as Not Collected on the status field and fill all the fields on the page layout and Click on Next Button");
		missingInformatioPage.saveStatusNotCollcted();
		refresh();
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 45.Validate all the selected MI Cases should be updated as Not Collected and all other fields are populated on the MI Case record.");
		missingInformatioPage.verifyNotCollectedStatus();

		Logger("STEP 46: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-12265:To Verify the Validation Rule added to Missing
	 * Information Case Record Fields
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "To Verify the Validation Rule added to Missing Information Case Record Fields", enabled = true)
	public void MI11_IC12265_To_Verify_the_Validation_Rule_added_to_Missing_Information_Case_Record_Fields()
			throws Exception {

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care Program Enrollee'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 3: Change List view to 'Recently View' queue list view.");
		docMgmt.verifyRecentlyViewList();

		Logger("STEP 4: Open the any newly created CPE");
		documentsPage.searchDocument("Automation");
		String recordName = missingInformatioPage.searchAndOpenRecord();

		Logger("STEP 5: Navigate to MI Tab ");
		accountObject.clickOnTab(tabsName.get(2));
		String url = getCurrentPageURL();

		Logger("STEP 6: Now click on the \"New\" Button at the top right corner of the MI section.");
		missingInformatioPage.clickNewButton();
		Utility_Function.switchToWindow("Case");

		Logger("STEP 7: Enter the value for care program MI Field and save");
		String miName = "Patient Program Consent";
		missingInformatioPage.enterCareProgramMI(miName);
		missingInformatioPage.clickOnSaveButton();
		navigateToURL(url);
		refresh();
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 8: click on select all checkbox and click on bulk close ");
		missingInformatioPage.clickOnBulkClose();

		Logger("STEP 9:  update the status as Collected and validate if ‘1st Attempt’ and ‘1st Attempt Date’ is Mandatory field  ");
		missingInformatioPage.verifyStatusCollected();

		Logger("STEP 10:  Validate that ‘Not Applicable’ Picklist value is added to ‘1st Attempt’, ‘2nd Attempt’ and ‘3rd Attempt’ MI Case Fields. ");
		missingInformatioPage.verifyNotApplicable();

		Logger("STEP 11:  Validate a Dependent field ‘Reason’ is visible when User selects ‘1st Attempt’ OR ‘2nd Attempt’ OR ‘3rd Attempt’ is equals to Not Applicable. ");
		missingInformatioPage.verifyReasonField();

		Logger("STEP 12:  validate to select option from ‘Reason’ field ");
		missingInformatioPage.selectReason();
		navigateToURL(url);
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 13:  Open the newly created MI case record (mentioned in the Pre-requisite) Click on the Close Button and Update the status as ‘Not Collected ");
		missingInformatioPage.verifyToCloseMI();

		Logger("STEP 14:  Validate if ‘Cancelled’ picklist value is added to Status field on the Case Object of MI Record. ");
		missingInformatioPage.verifyCancelledStatus();

		Logger("STEP 15: Logout as case Manager");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-12178 Regression-MIM: Automate ICARE-6585-SIT-TC01:
	 * Validate the updated fields on MI Page Layout
	 * 
	 * @author Kavyashree MB
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SAT: TC01: Validate the updated fields on MI Page Layout", enabled = true)
	public void MI12_IC12178_Validate_the_updated_fields_on_MI_Page_Layout() throws Exception {
		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC12";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		String removeColumnData_MI[] = { "Prescriber Name", "Prescriber NPI", "Prescriber Signed",
				"Prescriber Signature Date" };
		
		synchronized (excelDataUpdate) {
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_MI);
		}

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
			updatepdf.selectEnrollmentForm("Atopic Dermatitis");
			filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
			updatepdf.updatePDFForm(TestCaseNumber, functionality);

		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate to the Recently view list ");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger(" STEP 4:Once the PDF Enrollment Form is uploaded, navigate to the 'Received Document Worklist' list view of the Received Document.");

		fileName = documentsPage.getFileName(filePath.get());
		System.out.println(fileName);

		Logger(" STEP 5: User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger(" STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 17: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 19: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
		homeportalPage.closeTabs();
		accountObject.globalSearch(searchFilter.get(1), cpeName);

		Logger("STEP 21: Navigate to MI Tab");
		accountObject.clickOnTab(tabsName.get(2));
		String cpeUrl = getCurrentPageURL();

		Logger("STEP 22: Navigate to the Care Program Enrollee object and validate that MI cases are created and status is open");
		// missingInformatioPage.verifyMIRecordCreated("Diagnosis Missing","Open");

		Logger("STEP 22: Verify Missing Information icon is displayed on the CPE record");

		Logger("STEP 23: Navigate to MI tab on the CPE > Click on any one of the MI case");
		missingInformatioPage.clickOnMICase();

		Logger("STEP 24: verify 1st , 2nd and 3rd attempt fields");
		missingInformatioPage.verifyMIAttemptFields();

		Logger("STEP 25: Open any one MI Case Verify the Close Button is added on Individual Case Records");
		missingInformatioPage.verifyCloseButton();

		Logger("STEP 26: Validate Status Picklist field on New Tab consists of 2 Picklist Value");
		missingInformatioPage.verifyStatusFields();

		Logger("STEP 27: Validate that Not Applicale value  is added to attempt type field ");
		missingInformatioPage.verifyNotApplicableValue();

		Logger("STEP 28: Validate that the Reason dependent field is shown to the user when Attempt 1 Type OR Attempt 2 Type OR Attempt 3 Type is Not Applicable.");
		missingInformatioPage.verifyReason();

		Logger("STEP 29: Validate  Reason Picklist fields");
		missingInformatioPage.selectReason();
		navigateToURL(cpeUrl);
		refresh();
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.clickOnMICase();
		missingInformatioPage.verifyCloseButton();

		Logger("STEP 30: Verify validation rule when status is not collected ");
		missingInformatioPage.verifyValidationForNotCollected();

		Logger("STEP 31: Verify validation rule when status is  collected ");
		missingInformatioPage.verifyValidationForCollected();

		Logger("STEP 32: Select the Status as Not Collected on the status field and fill all the fields on the page layout and Click on Submit Button ");
		missingInformatioPage.verifyCloseButton();
		missingInformatioPage.selectNotCollected();

		Logger("STEP 33:Select the Status as Collected on the status field and fill all the fields on the page layout and Click on Submit Button ");
		missingInformatioPage.verifyCloseButton();
		missingInformatioPage.selectCollected();

		Logger("STEP 34: Verify Cancel Button is added on the individual MI Case record page layout");
		missingInformatioPage.verifyCancelButton();

		Logger("STEP 35: Click on the Cancel Button verify the following message is displayed Are you sure to Cancel the MI Case, because of Order Triaged to SP");
		missingInformatioPage.verifyCancelMessage();

		Logger("STEP 36:Verify the 2 buttons Yes and no are displayed when user clicks on Cancel Button.");
		missingInformatioPage.verifyButtons();

		Logger("STEP 37: Verify that once the user clicks no case status does not auto-updated to Cancelled ");
		missingInformatioPage.selectNo();

		Logger("STEP 38: Verify that Once the user clicks Yes case status is auto-updated to Cancelled ");
		missingInformatioPage.verifyCancelButton();
		missingInformatioPage.selectYes();

		Logger("STEP 39: Logout as case Manager");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-12023: To validate MI cases are populating into their
	 * respective related list on MI tab
	 * 
	 * @author Kavyashree MB
	 * @Maintenance_author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "To validate MI cases are populating into their respective related list on MI tab", enabled = true)
	public void MI13_IC12023_To_validate_MI_cases_are_populating_into_their_respective_related_list_on_MI_tab()
			throws Exception {

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care Program Enrollee'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);

		Logger("STEP 3: Change List view to 'Recently View' queue list view.");
		docMgmt.verifyRecentlyViewList();

		Logger("STEP 4: Open the any newly created CPE");
		documentsPage.searchDocument("Automation");
		String recordName = missingInformatioPage.searchAndOpenRecord();

		Logger("STEP 5: Navigate to MI Tab ");
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 6: Now click on the \"New\" Button at the top right corner of the MI section.");
		missingInformatioPage.clickNewButton();

		Logger("STEP 7: Give the Care Program MI and hit on save button.");
		String miName = "Diagnosis Missing";
		missingInformatioPage.selectCareProgramMI(miName);
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 8: Verify that the Status field is Open on the case page layout for the newly created MI case ");
		String status = "Open";
		accountObject.verifyStatusField(status);
		String caseNumber = missingInformatioPage.getCaseNumber();
		refresh();
		missingInformatioPage.navigateToCPERecord(recordName);

		Logger("STEP 9: Validate that Open status MI case is visible in Open Cases related list under MI tab on Care Program enrollee Page.");
		String tableName = "Open Cases";
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.validateCasePresence(caseNumber, tableName);

		Logger("STEP 10:  Change the Open status MI case to In Progress and verify In Progress MI case is visible in Open Cases related list. ");
		missingInformatioPage.clickOnRecordBasedOnCaseNo(caseNumber);
		missingInformatioPage.changeMIStatus(miStatusOptions.get(0));
		refresh();
		missingInformatioPage.navigateToCPERecord(recordName);
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.validateCasePresence(caseNumber, tableName);

		Logger("STEP 11: When user changes the status of Open or In Progress cases which are in Open Cases related list to Collected or Not Collected or Cancelled Status this case should be visible in \"Closed Cases\" related list under MI tab on Care Program enrollee Page.");
		accountObject.clickOnTab(tabsName.get(1));
		// Collect MI case- diagnosis Information
		// docMgmt.navigateToAccount();
		// accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateToHealthConditions();
		accountObject.newHealthCond();
		String hcCode = "0 -";
		accountObject.addNewHealthCondition(hcCode);
		missingInformatioPage.navigateToCPERecord(recordName);
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 12: When user changes the status of Open or In Progress cases which are in Open Cases related list to Collected or Not Collected or Cancelled Status this case should be visible in \"Closed Cases\" related list.");
		String miSubjectName = "Diagnosis Missing";
		String collectedCasenum = missingInformatioPage.changeStatusOfCreatedMICase(miSubjectName);
		missingInformatioPage.navigateToCPERecord(recordName);
		refresh();
		accountObject.clickOnTab(tabsName.get(2));
		tableName = "Closed Cases";
		missingInformatioPage.validateCasePresence(collectedCasenum, tableName);

		Logger("STEP 13: Verify case should be visible in Closed Cases related list under MI tab on Care Program enrollee Page ");
		missingInformatioPage.validateCasePresence(collectedCasenum, tableName);

		Logger("STEP 14: Logout as case Manager");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-2068 Missing Information Management - SIT - TC02- Tracking
	 * records for the Missing Information.
	 * 
	 * @author Anand Pawar
	 * @Maintenance_author Trupti Zure
	 * 
	 * @throws Exception ==================================================================================================
	 */

	@Test(description = "To Validate Bulk Close button on MI Tab List view.", enabled = true, priority = 33)
	public void MI14_IC2068_To_Validate_Bulk_Close_button_on_MI_Tab_List_view() throws Exception {

		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2:Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care Program Enrollee'Object.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5), DocumentPage.class);

		Logger("STEP 3: Verify Recently Viewed queue list view.");
		docMgmt.verifyRecentlyViewList();

		Logger("STEP 4: Validate New button is removed from the top right corner.");
		careProgram.verifyNewButtonRemoved();

		Logger("STEP 5: Click on Open MI record and validate the field");
		careProgram.clickOnOpenCase();
		String misubject = careProgram.validateMIPageFields();

		Logger("STEP 6: Navigate to linked patient CPE record");
		careProgram.navigateTolinkedCPE();

		Logger("STEP 7: Validate Open MI Record is visible");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.checkMIRecord(misubject);

		Logger("STEP 8: Logout as case Manager");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-13592 To Validate auto-inactivation is not triggered on
	 * CPE Record when Non-Critical MI Case Status is Not Collected
	 * 
	 * @author Anand Pawar
	 * @Maintenance_author Trupti Zure
	 * 
	 * @throws Exception ==================================================================================================
	 */

	@Test(description = "To Validate auto-inactivation is not triggered on CPE Record when Non-Critical MI Case Status is Not Collected", enabled = true, priority = 34)
	public void MI15_IC13592_To_Validate_auto_inactivation_is_not_triggered_on_CPE_Record_when_Non_Critical_MI_Case_Status_is_Not_Collected()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC15";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "Prescriber NPI" };
		String columnValue[] = { "J45.40 - Moderate persistent asthma, uncomplicated", "370841" + randomNum };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 4:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 6:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 7:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 8: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 9: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 10:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 11:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));
		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 12:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 13:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 14:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 15:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 16:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 17: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		Logger("STEP 18: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 19:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		navigateToUrl(CPEURL);
		Thread.sleep(2000);

		Logger("STEP 20:Navigate to MI tab");
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 21:Create non-critical MI for validation");
		missingInformatioPage.clickNewButton();
		missingInformatioPage.selectCareProgramMI(careProgramMI.get(0));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.verifyCaseIsCreated(careProgramMI.get(0));

		Logger("STEP 22:Click on Close Button and mark the status as Not Collected. Fill all the attempts field and Save and Close the Record.");
		missingInformatioPage.clickOnCloseButton();
		missingInformatioPage.saveStatusNotCollcted();

		Logger("STEP 23:Validate if new Correspondence tab is not getting opened once Non-Critical MI Case Status is updated to Not Collected.");
		missingInformatioPage.verifyCorrespondenceTabNotGenerated();

		Logger("STEP 24:Navigate to related tab of MI Case Record and Validate if history tracking is done for all the changes made under Case History.");
		accountObject.clickOnTab(tabsName.get(1));
		careProgram.clickOnViewAll("Case History");
		missingInformatioPage.verifyCaseHistory();

		Logger("STEP 25:Navigate to CPE Details Page and validate if CPE Status is not changed.Also Validate if ‘Inactivation Reason’ is blank and no value is populated.");
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		missingInformatioPage.verifyCPEStatusInactivationReason(statusReason.get(0));

		Logger("STEP 26: User Logout the Application.");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:11958 To Validate First MI Case List Filter and Add Second MI
	 * Cases List updated on the CPE MI Tab
	 * 
	 * @author Trupti Zure
	 * 
	 * @throws Exception ====================================================================================================================
	 */

	@Test(description = "To Validate First MI Case List Filter and Add Second MI Cases List updated on the CPE MI Tab", enabled = true)
	public void MI16_IC11958_Validate_First_MI_Case_List_Filter_and_Add_Second_MI_Cases_List_Updated_on_the_CPE_MI_Tab()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC16";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_TestCase08);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(0).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Nasal Polyps");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.verifyAndClickOnCPERecord(cpeName);

		String cpeURL = getCurrentPageURL();
		cpeURL = Utility_Function.removeQueryString(cpeURL);

		Logger("STEP 13: Logout as DIS User");
		documentsPage.logout();

		Logger("STEP 14: Login to the QA_SIT Org as 'Case Manager'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 15: Navigate to the Care program Enrollees object");
		navigateToUrl(cpeURL);

		Logger("STEP 16: Open the created CPE record and navigate to MI tab.");
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 17: Open the created CPE record and navigate to MI tab.");
		missingInformatioPage.validateMITableName();

		Logger("STEP 18: Change the Open status MI case to In Progress and verify In Progress MI case is visible in Open Cases related list.");
		String tableName = "Open Cases";
		String casenum = missingInformatioPage.updateStatusOfCreatedMICase(statusOptionsMIOpenCases.get(1), tableName,
				statusOptionsMIOpenCases.get(0));

		Logger("STEP 19: Validate that Open and In Progress Status Cases are added to Open Cases related list and validate that Status column is sorted in Descending order");
		missingInformatioPage.validateCasePresence(casenum, tableName);
		missingInformatioPage.validateStatusColumnState();

		Logger("STEP 20: Collect information");
		// Collect MI case- diagnosis Information
		docMgmt.navigateToAccount();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateHealthConditions();
		accountObject.clickOnNew();
		String hcCode = "J33.0 - Polyp of nasal cavity";
		accountObject.addNewHealthCondition(hcCode);
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 21: When user changes the status of Open or In Progress cases which are in Open Cases related list to Collected or Not Collected or Cancelled Status this case should be visible in \"Closed Cases\" related list.");
		String miSubjectName = "Diagnosis Missing";
		String collectedCasenum = missingInformatioPage.changeStatusOfCreatedMICase(miSubjectName);
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(2));
		tableName = "Closed Cases";
		missingInformatioPage.validateCasePresence(collectedCasenum, tableName);

		Logger("STEP 22: Validate that Collected, Not Collected and Cancelled Status cases are added to Closed Cases related list and validate that Collected Date column is sorted in Descending order.");
		missingInformatioPage.validateStatusColumnState();

		documentsPage.logout();

		int numberOfUsers = 5;

		for (int i = 0; i < numberOfUsers; i++) {
			try {
				// Login based on the user role
				switch (i) {

				case 0:
					Logger("STEP 15: Login to the QA_SIT Org as 'BV User'.");
					homeportalPage = loginPage.userLogin(BVUsername, UserPassword);
					break;
				case 1:
					Logger("STEP 16: Login to the QA_SIT Org as 'PC User'.");
					homeportalPage = loginPage.userLogin(PCUserName, UserPassword);
					break;
				case 2:
					Logger("STEP 16: Login to the QA_SIT Org as 'PM User'.");
					homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
					break;
				case 3:
					Logger("STEP 16: Login to the QA_SIT Org as 'BO User'.");
					homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
					break;

				case 4:
					Logger("STEP 15: Login to the QA_SIT Org as 'DIS User'.");
					homeportalPage = loginPage.userLogin(DISUserName, UserPassword);
					break;

				}

				navigateToUrl(cpeURL);

				Logger("STEP 17: Open the created CPE record and navigate to MI tab.");
				accountObject.clickOnTab(tabsName.get(2));

				Logger("STEP 18: Open the created CPE record and navigate to MI tab.");
				missingInformatioPage.validateMITableName();

				Logger("STEP 19: Change the Open status MI case to In Progress and verify In Progress MI case is visible in Open Cases related list.");
				tableName = "Open Cases";
				casenum = missingInformatioPage.updateStatusOfCreatedMICase(statusOptionsMIOpenCases.get(1), tableName,
						statusOptionsMIOpenCases.get(0));

				Logger("STEP 20: Validate that Open and In Progress Status Cases are added to Open Cases related list and validate that Status column is sorted in Descending order");
				missingInformatioPage.validateCasePresence(casenum, tableName);
				missingInformatioPage.validateStatusColumnState();

				Logger("STEP 21: When user changes the status of Open or In Progress cases which are in Open Cases related list to Collected or Not Collected or Cancelled Status this case should be visible in \"Closed Cases\" related list.");
				tableName = "Closed Cases";
				missingInformatioPage.validateCasePresence(collectedCasenum, tableName);

				Logger("STEP 22: Validate that Collected, Not Collected and Cancelled Status cases are added to Closed Cases related list and validate that Collected Date column is sorted in Descending order.");
				missingInformatioPage.validateStatusColumnState();
				documentsPage.logout();

			} catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				documentsPage.logout();
			}
		}

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-18035 To Validate User is able to Collect MI Cases with
	 * appropriate information Enrollment Form Submission for multiple MI Case
	 * created. This testcase is duplicate of testcase
	 * -MI09_IC12552_ICARE_6585_To_Validate_User_is_able_to_Collect_MI_Cases_with_appropriate_information
	 * 
	 * @author Tejal
	 * 
	 * @throws Exception ====================================================================================================================
	 */

// 	@Test(description = "Automated Check for Missing Information following Enrollment Form Submission for multiple MI Case created.", enabled = true, priority = 33)
// 	public void MI17_IC18035_12552_To_Validate_User_is_able_to_Collect_MI_Cases_with_appropriate_information()
// 			throws Exception {

// 		Map<String, String> ExcelTestData = new HashMap<String, String>();
// 		String TestCaseNumber = "TC17";

// 		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
// 		String removeColumnData[] = { "Patient DOB", "Patient Secondary phone", "Patient Authorization Date",
// 				"Prescriber Name", "Prescriber NPI" };
// 		excelDataUpdate.selectExcelSheet(functionality);
// 		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
// 		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
// 		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

// 		Logger("Pre-Requisite : User updates the Patient Form");
// 		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
// 		filePath.set( updatepdf.PDFCreation(TestCaseNumber, functionality));
// 		updatepdf.updatePDFForm(TestCaseNumber, functionality);
// 		System.out.println(filePath.get());

// 		// Logger("STEP 1:Login to the SIT Org as 'Data Intake Specialist'.");
// 		// homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

// 		// String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
// 		// 		ExcelTestData.get(patientEmail) };

// 		// Logger("STEP 2:Upload document to Dupixent portal");
// 		// String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

// 		// Logger("STEP 4: Navigate To Recently View Document list");
// 		// documentsPage.verifyRecentlyViewDocumentList();

// 		// Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
// 		// documentsPage.navigateToMyReceivedDocListView();
// 		// documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

// 		// Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
// 		// documentsPage.classifyDocument(documentType.get(0));
// 		// documentsPage.submitDocument();

// 		// Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
// 		// documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

// 		// Logger("STEP 10: User selects valid ‘Care Program Product' field data and click on Next Button.");
// 		// patientSearch.verifyPatientSearchPageTitle();
// 		// String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
// 		// String patientFirstName = name[0];
// 		// String patientMidName = name[1];
// 		// String patientLastName = name[2];

// 		// Logger("STEP 11: Verify Patient Search Page details and click on Next Button");
// 		// patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
// 		// 		ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
// 		// 		ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
// 		// 		ExcelTestData.get(patientDOB));
// 		// patientSearch.clickOnNextButton();

// 		// // patientinfoAndauthorization-Page
// 		// Logger("STEP 12:Verify Patient Information & Authorizations Page details and click on Next Button");
// 		// String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
// 		// String legalRepFirstName = legalRepName[0];
// 		// String legalRepLastName = legalRepName[2];

// 		// patientInfo.verifyPatientAuthorizationPageTitle();
// 		// patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
// 		// 		ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
// 		// 		ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
// 		// 		ExcelTestData.get(zip));
// 		// patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
// 		// 		patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
// 		// 		ExcelTestData.get(textMessagingConsent));
// 		// patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
// 		// 		ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
// 		// 		ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
// 		// 		ExcelTestData.get(patientSecondaryphone));
// 		// patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
// 		// patientInfo.clickOnNextButton();

// 		// // Patient Insurance - Page
// 		// Logger("STEP 13:Verify Patient Insurance Inforamtion Page details and click on Next Button");
// 		// insuranceinfo.verifyInsuranceInfoPageTitle();
// 		// insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
// 		// 		ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
// 		// 		ExcelTestData.get(rxPCN));
// 		// insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
// 		// 		ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
// 		// 		ExcelTestData.get(insrelationshipToPatient));
// 		// insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
// 		// 		ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
// 		// insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
// 		// insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
// 		// insuranceinfo.clickOnNextButton();

// 		// Logger("STEP 14:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
// 		// String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
// 		// String preFirstName = preName[0];
// 		// String prLastName = preName[2];

// 		// String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
// 		// String ofcFirstName = ofcName[0];
// 		// String ofcLastName = ofcName[2];

// 		// prescriberInformationPage.verifyPrescriberInfoPageTitle();
// 		// prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
// 		// 		ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
// 		// 		ExcelTestData.get(prescriberstateLicense));
// 		// prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
// 		// 		ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
// 		// 		ExcelTestData.get(prescriberZip));
// 		// prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
// 		// 		ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
// 		// 		ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
// 		// prescriberInformationPage.clickOnNextButton();

// 		// // Diagnosis information-Page
// 		// Logger("STEP 15:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
// 		// diagnosisinformation.verifyDiagnosisInfoPageTitle();
// 		// diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
// 		// diagnosisinformation.clickOnNextButton();

// 		// Logger("STEP 16:Verify Patient Prescription Inforamtion Page details and click on Next Button");
// 		// String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
// 		// String mdFirstName = mdName[0];
// 		// String mdLastName = mdName[2];

// 		// prescriptioninformation.verifyPrescriptionInfoPageTitle();
// 		// prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
// 		// 		ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
// 		// 		ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
// 		// 		prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
// 		// 		ExcelTestData.get(NursePractitionerNPI));
// 		// prescriptioninformation.clickOnNextButton();

// 		// Logger("STEP 16:User Clicks on Form Confirmation Button");
// 		// formConfirmation.clicOnFormConfirmation();

// 		// Logger("STEP 17:Verify account is created ");
// 		// accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));

// 		// refresh();
// 		// accountObject.clickOnTab(tabsName.get(1));

// 		// Logger("STEP 12: Verify Care program enrollee record is linked to account ");
// 		// accountObject.navigateCareProgramEnrollee();
// 		// accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

// 		// CPEURL = getCurrentPageURL();
// 		// CPEURL = Utility_Function.removeQueryString(CPEURL);

// 		// Logger("STEP 13: User Logout the Application.");
// 		// documentsPage.logout();

// 		Logger("STEP 19: Login to the QA_SIT Org as 'Case Manager'.");
// 		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

// 		Logger("STEP 2: Open a CPE record");
// 		homeportalPage.closeTabs();
// 		navigateToUrl("https://icarecrm--toleuat.sandbox.lightning.force.com/lightning/r/CareProgramEnrollee/0Wwbf0000005T2zCAE/view");

// 		accountObject.clickOnTab(tabsName.get(2));
// 		careProgram.clickOnViewAll("Open Cases");
// 		Logger("done");
// 		missingInformatioPage.verifyOpenMIRecords();
// 		Logger("done");
// //		missingInformatioPage.verifyMIRecordCreated("Prescriber Missing");
// //		missingInformatioPage.verifyMIRecordCreated("HCO Missing");
// //		missingInformatioPage.verifyMIRecordCreated("HCP Consent");

// 		missingInformatioPage.changeToInProgressStatus(statusOptionsMIOpenCases.get(0));
// 		Logger("done");
// 		missingInformatioPage.verifyOtherThanInProgressStatus(statusOptionsMIOpenCases.get(5));

// 		Logger("STEP 13: User Logout the Application.");
// 		documentsPage.logout();

// 	}

	/**
	 * ====================================================================================================================
	 * Test Case Id: ICARE18034 RGN-MIM: Automate ICARE-12690: SIT: TC01: To
	 * Validate User is able to Collect MI Cases in Bulk with appropriate
	 * information
	 * 
	 * @author Shanavaz Nishani , date- 5/7/2025
	 *         ====================================================================================================================
	 * @throws Exception
	 */

	@Test(description = "ICARE-12690: SIT: TC01: To Validate User is able to Collect MI Cases in Bulk with appropriate information", enabled = true)
	public void MI18_IC12695_Validate_User_is_able_to_Collect_MI_Cases_in_Bulk_with_appropriate_information()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC18";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Preferred Specialty Pharmacy", "DUPIXENT MyWay", "Text Messaging Consent", "Gender" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "-- Clear --" };
		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_MICases);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(3).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), "5/21/1990", ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 3: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 3.1:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 4:Select document type as Enrollment Form and click on submit and fill all the mandatory details in patient search and click on next.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 4.1:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 4.2: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 5: Fill all the mandatory fields on Patient Information section and miss all the details and click on next.");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(3),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5.1:Fill all the mandatory fields on Patient Information section and miss all the details and click on next.");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.clickOnNextButton();

		Logger("STEP 6: Miss all the information on Insurance section and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7: Miss all the details on Prescriber Information section and click on Submit.");
		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.clickOnNextButton();

		Logger("STEP 7.1: Miss all the details on Diagnosis Information section and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 8: Miss all the details on Prescription information page and click on submit.");
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.clickOnNextButton();
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 9: Logout the application as DIS User.");
		documentsPage.logout();

		Logger("STEP 10: Login the application as CM user.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 11: Navigate to Care Program Enrollee object and open the enrolled patient CPE record.");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		careProgram.navigateToAllCPE();
		careProgram.checkColumnSorting();
		careProgram.clickOnCPERecord(cpeName);
		accountObject.clickOnTab(tabsName.get(2));

		ArrayList<String> MissingCases = missingInformatioPage.getMICasesNames("Open Cases");

		Logger("STEP 12: When user clicks on Close or Bulk Close button for a MI Case, if the data in related object/field as per Care Program MI record is not populated Validate that System throws a validation error message that \"The relevant Missing Information is not updated. Please update the related data before marking the status as Collected\",");
		String expectedErroMsg = "The relevant Missing Information is not updated. Please update the related data before marking the status as Collected.";
		missingInformatioPage.selectMICases("All");
		missingInformatioPage.clickBulkCloseButton();
		missingInformatioPage.collectMICase();
		missingInformatioPage.validateBulkMICasesErrorMsg(expectedErroMsg);
		refresh();
		Thread.sleep(2000);

		Logger("STEP 12.1: Update the missing information in the relevant field for Patient DOB, Phone and Gender and click on save button.");
		docMgmt.navigateToAccount();
		docMgmt.clcikOnEditbtn("Birthdate");
		docMgmt.editDOB();
		authorizationConsentPage.updateGender("Male");
		docMgmt.editPhone();
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		refresh();

		Logger("STEP 13: Validate when user selects multiple MI Cases (eg. 4) to be closed and information in relevant field is populated for only few (for eg. 2) of those, then the MI Cases with missing relevant info is not closed and system gives error message \"The relevant Missing Information is not updated. Please update the related data before marking the status as Collected'. Other MI Cases which had data captured in related fields are marked as Collected");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.selectMICases(MissingCases.get(0));
		missingInformatioPage.selectMICases(MissingCases.get(1));
		missingInformatioPage.selectMICases(MissingCases.get(2));
		missingInformatioPage.selectMICases(MissingCases.get(3));
		missingInformatioPage.selectMICases(MissingCases.get(4));
		missingInformatioPage.clickBulkCloseButton();
		missingInformatioPage.collectMICase();
		missingInformatioPage.validateBulkMICasesErrorMsg(expectedErroMsg);
		accountObject.clickOnTab(tabsName.get(2));

		ArrayList<String> collectedCases = missingInformatioPage.getMICasesNames("Closed Cases");
		if (collectedCases.contains(MissingCases.get(0)) && collectedCases.contains(MissingCases.get(1))
				&& collectedCases.contains(MissingCases.get(2))) {
			utilityPage.LoggingInfo("MI cases are collected successfully.");
		} else {
			Assert.fail("MI cases are not collected successfully.");
		}

		Logger("STEP 14: Create related record for all MI Cases and Validate that when user close or bulk close multiple MI cases, System Does not throw any Validation message and all selected MI cases are closed and marked as collected.");
		String hcpName = "Automation HCP";
		String hcoName = "Automation HCO";
		accountObject.clickOnTab(tabsName.get(0));
		careTeamAsgn.updateHCPandHCO(hcpName, hcoName);

		Logger("STEP 14.1: Create Medication Request related record");
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.clickOnNewMedicationRequest();
		accountObject.createMedicationRequest("Active", "No", "Dupixent 300 MG/2ML pre-filled syringe");
		accountObject.clickOnSave();

		Logger("STEP 14.2: Create Insurance related record");
		missingInformatioPage.navigateToCPERecord("Account");
		accountObject.clickOnTab(tabsName.get(1));
		String pharmacyName = "TestAutomation Payer Pharmacy";
		String payerName = "Test Payer";
		accountObject.clickOnNewMemberPlan();
		accountObject.createPharmacyMemberPlan(pharmacyName, payerName, policyHolderDOB);
		accountObject.clickOnSave();
		missingInformatioPage.navigateToCPERecord(cpeName);

		Logger("STEP 14.3: Create Diagnosis related record");
		accountObject.navigateHealthConditions();
		accountObject.newHealthCond();
		String hcCode = "0 -";
		accountObject.addNewHealthCondition(hcCode);
		missingInformatioPage.navigateToCPERecord("Account");

		Logger("STEP 14.4: Create Consent related records.");
		String careProgram = "DMW Asthma";
		String status = "Active";
		authorizationConsentPage.verifyClickNewButton();
		authorizationConsentPage.selectAuthorizationConsent();
		authorizationConsentPage.verifyNextButton();
		authorizationConsentPage.createAuthorizationRec("HIPAA Consent", careProgram, status, "HIPAA", "James Bob",
				ExcelTestData.get(patientName));
		missingInformatioPage.navigateToCPERecord("Account");

		authorizationConsentPage.verifyClickNewButton();
		authorizationConsentPage.selectAuthorizationConsent();
		authorizationConsentPage.verifyNextButton();
		authorizationConsentPage.createAuthorizationRec("Program Authorization", careProgram, status,
				"Patient Program Authorization", "James Bob", ExcelTestData.get(patientName));
		missingInformatioPage.navigateToCPERecord("Account");

		authorizationConsentPage.verifyClickNewButton();
		authorizationConsentPage.selectAuthorizationConsent();
		authorizationConsentPage.verifyNextButton();
		authorizationConsentPage.createAuthorizationRec("HCP Consent", careProgram, status, "HCP Authorization",
				hcpName, ExcelTestData.get(patientName));
		missingInformatioPage.navigateToCPERecord("Account");
		refresh();

		missingInformatioPage.navigateToCPERecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.selectMICases("All");
		missingInformatioPage.clickBulkCloseButton();
		missingInformatioPage.collectMICase();

		accountObject.clickOnTab(tabsName.get(2));
		ArrayList<String> openMIcases = missingInformatioPage.getMICasesNames("Open Cases");
		if (openMIcases.size() == 0) {
			utilityPage.LoggingInfo("All MI cases are collected successfully.");
		} else {
			Assert.fail("All MI cases are not collected successfully.");

		}

		Logger("STEP 15: Logout the application as CM User.");
		documentsPage.logout();
	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-18050 RGN-MIM: Automate SIT_Missing Information
	 * Management-SF-Scenario 3 TC01- Validate that MI Case can be manually created
	 * for incorrect Enrollment Form Version or Indication
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SIT_Missing Information Management-SF-Scenario 3-TC01- Validate that MI Case can be manually created for incorrect Enrollment Form Version or Indication", enabled = true)
	public void MI19_IC6358_Validate_that_MI_Case_can_be_manually_created_for_incorrect_Enrollment_Form_Version_or_Indication()
			throws Exception {
		String TestCaseNumber = "TC19";
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Diagnosis Code", "DUPIXENT MyWay", "Preferred Specialty Pharmacy" };
		String columnValue[] = { "K20.0 - Eosinophilic esophagitis", "TRUE", "FALSE" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(4).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Asthma");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 1.1:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 1.2: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 1.3:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 1.4:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 1.5:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 2: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 2.1: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(4),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 2.2:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail), ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text), ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("STEP 2.3:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("STEP 2.4:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 2.5:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 2.6:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 2.7:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("STEP 3: Open the newly created Care Program Enrollee record. Go to MI tab → Click 'New'");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		refresh();
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));
		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		Logger("STEP 4:Select CPMI as below (create 2 separate Cases for each) → Select Account as the Patient associated with the CPE → Save, 1.Incorrect Enrollment Form Version");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.clickNewButton();
		missingInformatioPage.selectCareProgramMI(careProgramMI.get(1));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.validateCatandStepsBlockedOnDetailsPage("Enrollment Form", "");
		missingInformatioPage.navigateToCPERecord("Care Program Enrollee");
		refresh();
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.validateMICaseCategory(careProgramMI.get(1), "Enrollment Form");
		missingInformatioPage.validateStepBlocked(careProgramMI.get(1), "");

		Logger("STEP 4.1: Select CPMI as, 2.Incorrect Enrollment Form Indication");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.clickNewButton();
		missingInformatioPage.selectCareProgramMI(careProgramMI.get(2));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.validateCatandStepsBlockedOnDetailsPage("Enrollment Form", "");
		missingInformatioPage.navigateToCPERecord("Care Program Enrollee");
		refresh();
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.validateMICaseCategory(careProgramMI.get(2), "Enrollment Form");
		missingInformatioPage.validateStepBlocked(careProgramMI.get(2), "");
		missingInformatioPage.selectMICases("All");
		missingInformatioPage.clickBulkCloseButton();
		missingInformatioPage.collectMICase();

		Logger("STEP 5: Case Manager should be able to login.");
		documentsPage.logout();
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 6: Repeat steps 3-4 and validate that Case Manager is able to create the Cases manually as well");
		navigateToURL(CPEURL);
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.clickNewButton();
		missingInformatioPage.selectCareProgramMI(careProgramMI.get(1));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.validateCatandStepsBlockedOnDetailsPage("Enrollment Form", "");
		missingInformatioPage.navigateToCPERecord("Care Program Enrollee");
		refresh();
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.validateMICaseCategory(careProgramMI.get(1), "Enrollment Form");
		missingInformatioPage.validateStepBlocked(careProgramMI.get(1), "");

		Logger("STEP 6.1:Select CPMI as Incorrect Enrollment Form Indication");
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.clickNewButton();
		missingInformatioPage.selectCareProgramMI(careProgramMI.get(2));
		missingInformatioPage.clickOnSaveButton();
		missingInformatioPage.validateCatandStepsBlockedOnDetailsPage("Enrollment Form", "");
		missingInformatioPage.navigateToCPERecord("Care Program Enrollee");
		refresh();
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.validateMICaseCategory(careProgramMI.get(2), "Enrollment Form");
		missingInformatioPage.validateStepBlocked(careProgramMI.get(2), "");

		Logger("STEP 7: Log out as Case Manager");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:IC20982 R4-MIM Automate ICARE-17309 --
	 * iCare13168:SIT:TC02::Validate Updates in Bulk Close Omniscript
	 * 
	 * @author Shanavaz Nishani
	 *
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "To validate that Case Manager can update relevant Missing Information", enabled = true)
	public void MI20_IC17309_Validate_Updates_in_Bulk_Close_Omnscript() throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC20";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Patient Primary phone", "Gender", "Patient Email", "Diagnosis Code" };
		String columnValue[] = { "", "-- Clear --", "", "L20.9 - Atopic dermatitis, unspecified" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("Pre-Requisite STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("Pre-Requisite STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("Pre-Requisite STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Pre-Requisite STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-Requisite STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), "", ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(zip), careProgramProduct.get(2), "");
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("Pre-Requisite STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName, "",
				ExcelTestData.get(gender), ExcelTestData.get(language), ExcelTestData.get(patientAddress),
				ExcelTestData.get(city), ExcelTestData.get(state), ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation("", ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(voicemail),
				ExcelTestData.get(text), ExcelTestData.get(bestTimingAM), ExcelTestData.get(bestTimingAfternoon),
				ExcelTestData.get(bestTimingPM), ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-Requisite STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Pre-Requisite STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		Logger("Pre-Requisite STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 1: Login to the  Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		String editField = "Care Program MI";
		String dateFormat = "MMM dd, yyyy";

		Logger("STEP 2: Navigate to the Care Program Enrollee object and Open a CPE record with Open MI cases");
		homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(7), DocumentPage.class);
		navigateToURL(CPEURL);

		Logger("STEP 3: Now open the MI cases one by one and Populate the Attempt and Attempt Date fields as mentioned below");
		accountObject.clickOnTab(tabsName.get(2));
		ArrayList<String> MissingCasesName = missingInformatioPage.getMICasesNames(MICases_Table.get(0));
		System.out.println(MissingCasesName.toString());

		Logger("STEP 3.1: Open a MI case (MI Case 1) and Leave All the Attempt and Attempt Date fields as blank");
		missingInformatioPage.openMiCase(MICases_Table.get(0), MissingCasesName.get(0));
		Thread.sleep(3000);
		getWebDriver().navigate().back();

		Logger("STEP 3.2: Open another MI case (MI case 2) and Populate the 1st Attempt and 1st Attempt date field ");
		missingInformatioPage.openMiCase(MICases_Table.get(0), MissingCasesName.get(1));
		docMgmt.clcikOnEditbtn(editField);
		missingInformatioPage.populateFirstAttempt(ClosureAttempt_PicklistValues.get(0));
		missingInformatioPage.clickOnSaveButton();
		getWebDriver().navigate().back();

		Logger("STEP 3.3: Open another MI case (MI case 3) and Populate the 1st Attempt ,1st Attempt Date ,2nd Attempt and 2nd attempt date fields");
		missingInformatioPage.openMiCase(MICases_Table.get(0), MissingCasesName.get(2));
		docMgmt.clcikOnEditbtn(editField);
		missingInformatioPage.populateFirstAttempt(ClosureAttempt_PicklistValues.get(0));
		missingInformatioPage.populateSecondAttempt(ClosureAttempt_PicklistValues.get(1));
		missingInformatioPage.clickOnSaveButton();
		getWebDriver().navigate().back();

		Logger("STEP 3.4: Now open another MI case (MI case 4) and Populate All the Attempt 1,2,3 fields");
		missingInformatioPage.openMiCase(MICases_Table.get(0), MissingCasesName.get(3));
		docMgmt.clcikOnEditbtn(editField);
		missingInformatioPage.populateFirstAttempt(ClosureAttempt_PicklistValues.get(0));
		missingInformatioPage.populateSecondAttempt(ClosureAttempt_PicklistValues.get(1));
		missingInformatioPage.populateThirdAttempt(ClosureAttempt_PicklistValues.get(2));
		missingInformatioPage.clickOnSaveButton();
		getWebDriver().navigate().back();

		Logger("STEP 4: Now select all the MI cases checbox and Click on Bulk Close button");
		refresh();
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.selectMICases("All");
		missingInformatioPage.clickBulkCloseButton();

		Logger("STEP 5.1: Validate the below fields are visible, 1.Status");
		missingInformatioPage.validateMICasePageFields("Status");

		Logger("STEP 5.2: Collected Channel -> Dependent field that opens when Status = Collected (Existing)");
		missingInformatioPage.validateCollectedChannel();

		Logger("STEP 5.3: Closure Attempt -> Field Type: a.Picklist (Voice Call, Fax, Email, SMS, Patient Letter, Not Applicable), b.Mandatory Field");
		missingInformatioPage.validateClosureAttemptPicklistVal();
		missingInformatioPage.checkMandatoryField("Closure Attempt");

		Logger("STEP 5.4: Closure Attempt Date -> Field Type: a.Date Time, b.Mandatory Field");
		missingInformatioPage.validateMICasePageFields("Closure Attempt Date");
		missingInformatioPage.checkMandatoryField("Closure Attempt Date");

		Logger("STEP 5.5: Reason Field Type: a.Picklist (Enrollment Oversight, Triaged to SP) ,b.Dependent field when Closure Attempt = Not Applicable");
		missingInformatioPage.validateReasonFieldDependentonClosureAttmpt();
		missingInformatioPage.validateReasonDropdownValues();

		Logger("STEP 6: Click on the Status field → Validate \"Not Collected \"value is not visible on the status field and Only \"Collected \"picklist value is visible");
		missingInformatioPage.validateStatusFieldValues();

		Logger("STEP 7: Now Populate the Status as Collected and populate the Collected Channel, Closure Attempt fields → In the Closure Attempt Date select a future date and click on submit.Validate an error message is visible to the user 'Cannot Submit a future date'");
		String futureDate = Utility_Function.getDateByOffsetDays(2, dateFormat);
		missingInformatioPage.collectMICase("Collected", CollectedChannel_PicklistValues.get(0),
				ClosureAttempt_PicklistValues.get(1), futureDate);
		missingInformatioPage.validateDateErrorMessage("Cannot submit a future date.");

		Logger("STEP 8: Now Populate the Closure Attempt date field with the date of today or past and click on submit");
		String pastDate = Utility_Function.getDateByOffsetDays(-2, dateFormat);
		missingInformatioPage.collectMICase("Collected", CollectedChannel_PicklistValues.get(0),
				ClosureAttempt_PicklistValues.get(1), pastDate);

		Logger("STEP 9: After click on submit, validate a Confirmation message is visible on the screen 'Are you sure you want to Bulk Close all the selected MI Cases with selected Attempt values?' with Yes and No options to select");
		missingInformatioPage.validateBulkCloseConfirmMsgScreen();

		Logger("STEP 10: Select as NO and click on next button → Validate user is navigated back to the CPE record and No MI case is marked as collected");

		missingInformatioPage.selectBulkCloseConfirmOption(BulkClose_Options.get(1));
		accountObject.clickOnNext();
		accountObject.clickOnTab(tabsName.get(2));
		ArrayList<String> closedCases = missingInformatioPage.getMICasesNames(MICases_Table.get(1));
		if (closedCases.size() == 0) {
			Log.info("No MI Case is marked as Collected");
		}

		Logger("STEP pre_requisite: Create MI case records for Collecting");
		docMgmt.navigateToAccount();
		docMgmt.clcikOnEditbtn("Birthdate");
		docMgmt.editDOB();
		docMgmt.editGender();
		docMgmt.editPhone();
		docMgmt.editEmail2(patientName);
		missingInformatioPage.clickOnSaveButton();

		Logger("STEP 11: Again Select the MI cases and Click on Bulk Close button");
		missingInformatioPage.navigateToCPERecord(cpeName);
		accountObject.clickOnTab(tabsName.get(2));
		missingInformatioPage.selectMICases("All");
		missingInformatioPage.clickBulkCloseButton();

		Logger("STEP 12: Populate the Status, as collected  Collected Channel field ,Closure attempt field, closure attempt date field and click on submit");
		missingInformatioPage.collectMICase("Collected", CollectedChannel_PicklistValues.get(0),
				ClosureAttempt_PicklistValues.get(4), pastDate);

		Logger("STEP 13: Now Select the Yes option and Click on Next button.Validate the MI cases are marked as Collected");
		missingInformatioPage.selectBulkCloseConfirmOption(BulkClose_Options.get(0));
		accountObject.clickOnNext();
		refresh();
		ArrayList<String> NotCollected = missingInformatioPage.getMICasesNames(MICases_Table.get(1));
		if (NotCollected.size() == 0) {
			Log.info("All the MI cases are marked as Collected");
		} else {
			Log.info("Some Mi cases are Open");
		}

		Logger("STEP 14:Now open the MI cases and validate the below fields in the MI cases are populated with the same value selected in the Closure Attempt and Closure Attempt Date field in Step 12");
		missingInformatioPage.openMiCase(MICases_Table.get(1), MissingCasesName.get(0));
		missingInformatioPage.validateAttemptDetailsonMICase(attempt_Fields.get(0), attempt_Fields.get(3),
				ClosureAttempt_PicklistValues.get(4), pastDate);
		getWebDriver().navigate().back();

		missingInformatioPage.openMiCase(MICases_Table.get(1), MissingCasesName.get(1));
		missingInformatioPage.validateAttemptDetailsonMICase(attempt_Fields.get(1), attempt_Fields.get(4),
				ClosureAttempt_PicklistValues.get(4), pastDate);
		getWebDriver().navigate().back();

		missingInformatioPage.openMiCase(MICases_Table.get(1), MissingCasesName.get(2));
		missingInformatioPage.validateAttemptDetailsonMICase(attempt_Fields.get(2), attempt_Fields.get(5),
				ClosureAttempt_PicklistValues.get(4), pastDate);
		getWebDriver().navigate().back();

		missingInformatioPage.openMiCase(MICases_Table.get(1), MissingCasesName.get(3));
		missingInformatioPage.verifyStatusField();
		getWebDriver().navigate().back();

		Logger("STEP 15: Logout of the application");
		documentsPage.logout();

	}

	/**
	 * ====================================================================================================================
	 * Test Case Id:SIT:ICARE-19683: To Verify users are not allowed to create
	 * duplicate MI cases for the same CPMI if status on the original MI case is
	 * Open/ In Progress
	 * 
	 * @author Sonica P
	 *
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SIT:ICARE-19683: To Verify users are not allowed to create duplicate MI cases for the same CPMI if status on the original MI case is Open/ In Progress", enabled = true)
	public void MI21_IC25158_To_Verify_users_are_not_allowed_to_create_duplicate_MI_cases_for_the_same_CPMI_if_status_on_the_original_MI_case_is_Open_In_Progress()
			throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = "TC20";

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Gender", "Diagnosis Code" };
		String columnValue[] = { "-- Clear --", "L20.9 - Atopic dermatitis, unspecified" };
		String removeColumnData[] = { "City" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
		excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData);
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String cpeName = ExcelTestData.get(patientName) + " - " + careProgramProduct.get(2).split(" -")[0];

		Logger("Pre-Requisite : User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		System.out.println(filePath.get());

		Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("Pre-Requisite STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("Pre-Requisite STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("Pre-Requisite STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Pre-Requisite STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-Requisite STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), "", ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(zip), careProgramProduct.get(2), "");
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("Pre-Requisite STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName, "",
				ExcelTestData.get(gender), ExcelTestData.get(language), ExcelTestData.get(patientAddress),
				ExcelTestData.get(city), ExcelTestData.get(state), ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation("", ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(voicemail),
				ExcelTestData.get(text), ExcelTestData.get(bestTimingAM), ExcelTestData.get(bestTimingAfternoon),
				ExcelTestData.get(bestTimingPM), ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName, ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-Requisite STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.enterRxInsuranceInfo(ExcelTestData.get(patienthasNOInsurance), ExcelTestData.get(rxPhone),
				ExcelTestData.get(rxPolicyID), ExcelTestData.get(rxGroup), ExcelTestData.get(rxBIN),
				ExcelTestData.get(rxPCN));

		insuranceinfo.enterMedicalInsuranceInfo(ExcelTestData.get(medicalPhone), ExcelTestData.get(medicalPolicyID),
				ExcelTestData.get(medicalGroup), ExcelTestData.get(policyholderName),
				ExcelTestData.get(insrelationshipToPatient));
		insuranceinfo.enterSpecialtyPharmacyInformation(ExcelTestData.get(preferredSpecialtyPharmacy),
				ExcelTestData.get(pharmacyPhone), ExcelTestData.get(pharmacyfax), ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectPayerPharmacy();
		insuranceinfo.selectMedicalPayer();
		insuranceinfo.selectSpecialtyPharmacy();
		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();

		Logger("Pre-Requisite STEP 11:Verify account is created ");
		accountObject.navigateToAccount();
		accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		Logger("Pre-Requisite STEP 13: User Logout the Application.");
		documentsPage.logout();

		Logger("STEP 1: Login to the  Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		navigateToUrl(CPEURL);

		Logger("STEP 5: Navigate to MI Tab ");
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 6: Now click on the \"New\" Button at the top right corner of the MI section.");
		missingInformatioPage.clickNewButton();

		Logger("STEP 7: Give the Care Program MI and hit on save button.");
		String miName = "Patient Gender";
		missingInformatioPage.selectCareProgramMI(miName);
		missingInformatioPage.clickOnSaveButton();

		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 5: Navigate to MI Tab ");
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 6: Update MI case 1 to Mi case 2");
		accountObject.editMIRec("DMW PN : Patient Gender");

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		// PM User
		Logger("STEP 1: Login to the  Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(PMUserName, UserPassword);

		navigateToUrl(CPEURL);

		Logger("STEP 5: Navigate to MI Tab ");
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 6: Now click on the \"New\" Button at the top right corner of the MI section.");
		missingInformatioPage.clickNewButton();

		Logger("STEP 7: Give the Care Program MI and hit on save button.");
		String miName1 = "Patient Gender";
		missingInformatioPage.selectCareProgramMI(miName1);
		missingInformatioPage.clickOnSaveButton();

		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 5: Navigate to MI Tab ");
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 6: Update MI case 1 to Mi case 2");
		accountObject.editMIRec("DMW PN : Patient Gender");

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();

		// BO User
		Logger("STEP 1: Login to the  Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);

		navigateToUrl(CPEURL);

		Logger("STEP 5: Navigate to MI Tab ");
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 6: Now click on the \"New\" Button at the top right corner of the MI section.");
		missingInformatioPage.clickNewButton();

		Logger("STEP 7: Give the Care Program MI and hit on save button.");
		String miName2 = "Patient Gender";
		missingInformatioPage.selectCareProgramMI(miName2);
		missingInformatioPage.clickOnSaveButton();

		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		Logger("STEP 5: Navigate to MI Tab ");
		accountObject.clickOnTab(tabsName.get(2));

		Logger("STEP 6: Update MI case 1 to Mi case 2");
		accountObject.editMIRec("DMW PN : Patient Gender");

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();
	}
}
