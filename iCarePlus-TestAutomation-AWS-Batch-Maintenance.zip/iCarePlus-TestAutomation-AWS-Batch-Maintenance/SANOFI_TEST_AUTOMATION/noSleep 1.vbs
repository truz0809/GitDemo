Function noSleep()	
	Dim mySendKeys
set mySendKeys = CreateObject("WScript.shell")

	do while(1)
	mySendKeys.SendKeys("^")
	WScript.Sleep (30*1000)
	loop
	
End Function

Call noSleep()
