package com.sanofi.selenium.pages;

import java.time.LocalDate;
import java.time.Period;
import java.util.HashMap;
import java.util.Map;

import org.joda.time.Years;

import com.sanofi.selenium.constants.ExcelTestDataConstants;
import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.ReadExcel;

public class dummyConsent extends BaseTest {

	
	LocalDate EighteenBday;
	LocalDate eighteenYearsAgo;
	LocalDate TwentyOneBday;
	LocalDate consignedDate;
	LocalDate PatientUpdatedDate;
	LocalDate ConsentUpdatedDate;
	LocalDate DOB;
	public ReadExcel excel;
	public int years;
	public int months;
	public int days;
	public String state;
	public String dob;
	public String ConsignedDate;
	public LocalDate ConsentCalculatedDate = null;


	public LocalDate HIPAAConsentExpiryDate()
	{
		LocalDate value = null;
		sheetName = "PDF_Data";
		excel = new ReadExcel(sheetName);


		Map<String, String> ExcelTestData = new HashMap<String, String>();
		{
			
			ExcelTestData = excel.getExcelInputData("TC01");
			state =  ExcelTestData.get(ExcelTestDataConstants.state);
			System.out.println(state);

			dob =  ExcelTestData.get(ExcelTestDataConstants.patientDOB);
			System.out.println("date of birth - "+dob);
			String dobForParsing = Utility_Function.changeDateFormat(dob);
			System.out.println(Utility_Function.changeDateFormat(dob) + " DOB format changed");

			ConsignedDate =  ExcelTestData.get(ExcelTestDataConstants.patientAuthorizationDate);
			System.out.println("ConsignedDate - "+ConsignedDate);
			String consignedDateForParsing = Utility_Function.changeDateFormat(ConsignedDate);
			System.out.println(Utility_Function.changeDateFormat(ConsignedDate) + " ConsignedDate format changed");

			LocalDate today = LocalDate.now();
			System.out.println("today date -"+today);
			
			DOB = LocalDate.parse(dobForParsing);
			consignedDate = LocalDate.parse(consignedDateForParsing);

			//Calculate current Date 
//			LocalDate today = LocalDate.now();
//			System.out.println("today date -"+today);

			Period difference = Period.between(DOB , today);   
			// Show date difference in years, months, and days   
			System.out.print("Difference between two dates is:\n");   
			System.out.printf( "%d days, %d months and %d years",   
					difference.getDays(),  
					difference.getMonths(),   
					difference.getYears());  
			System.out.println("  ");

			years = difference.getYears();
			months = difference.getMonths();
			days = difference.getDays();
						

			eighteenYearsAgo = DOB.minusYears(18);
			
			EighteenBday = DOB.plusYears(18);		
			System.out.println("Eighteen years add - "+EighteenBday);
			TwentyOneBday = DOB.plusYears(21);	
			System.out.println("TwentyOne years add - "+TwentyOneBday);

		}
		
	//Minor for HIPAA Authorization Consent
	if((years < 18) && (state.equalsIgnoreCase("Minnesota")) || (state.equalsIgnoreCase("Maryland"))) {
		PatientUpdatedDate = EighteenBday.plusDays(180);
		ConsentUpdatedDate = consignedDate.plusDays(365);
		if(PatientUpdatedDate.isAfter(ConsentUpdatedDate)) {
			System.out.println("Maryland && Minnesota Minor Result + 180 " + ConsentUpdatedDate);
			value = ConsentUpdatedDate;
		}else {
			System.out.println("Maryland && Minnesota Minor Result + 365 " + PatientUpdatedDate);
			value = PatientUpdatedDate;
	}
	}else if((years < 21) && (state.equalsIgnoreCase("Puerto Rico"))){
		
		PatientUpdatedDate = TwentyOneBday.plusDays(180);
		ConsentUpdatedDate = consignedDate.plusDays(540);
		System.out.println("Puerto Rico Minor + 180 - " + PatientUpdatedDate);
		System.out.println("Puerto Rico Minor + 540 - " + ConsentUpdatedDate);
		if(PatientUpdatedDate.isAfter(ConsentUpdatedDate)) {
			System.out.println("Puerto Rico Minor Result + 180 " + ConsentUpdatedDate);
			value = ConsentUpdatedDate;
		}else {
			System.out.println("Puerto Rico Minor Result + 540 " + PatientUpdatedDate);
			value = PatientUpdatedDate;
		}
	}else if ((years < 18) && (!state.equalsIgnoreCase("Maryland")) && (!state.equalsIgnoreCase("Minnesota")) && (!state.equalsIgnoreCase("Puerto Rico"))) {
		
		PatientUpdatedDate = EighteenBday.plusDays(180);
		ConsentUpdatedDate = consignedDate.plusDays(540);
		System.out.println("Other States Minor Result + 180 - " + PatientUpdatedDate);
		System.out.println("Other States Minor Result + 540 - " + ConsentUpdatedDate);
		if(PatientUpdatedDate.isAfter(ConsentUpdatedDate)){
			System.out.println("Other States Minor Result + 180 " + ConsentUpdatedDate);
			value = ConsentUpdatedDate;
		} else {
			System.out.println("Other States Minor + 540 " + PatientUpdatedDate);
			value = PatientUpdatedDate;
		}
	}
	
	
	//Major for HIPAA Authorization
	if((years >= 18) && (state.equalsIgnoreCase("Maryland")))
			{
		
		value = consignedDate.plusYears(1);
		System.out.println("Major Maryland " + value);
	
	}else if((years >= 18) && (state.equalsIgnoreCase("Minnesota"))){
		
		value = consignedDate.plusYears(1);
		System.out.println("Major Minnesota " + value);
		
	}else if(years >= 21 && state.equalsIgnoreCase("Puerto Rico")) {
		
		value = consignedDate.plusDays(540);
		System.out.println("Major puerto rico " + value);
		
	}else if((years >= 18) && (!state.equalsIgnoreCase("Maryland")) && (!state.equalsIgnoreCase("Minnesota")) && (!state.equalsIgnoreCase("Puerto Rico")))
	{
		value = consignedDate.plusDays(540);
		System.out.println("Major other states" + value);
	
	}
	return value;
	
	}
	
	
	
	
	//Patient Program Authorization Consent and other Consents
	
	public LocalDate PPAConsentExpiryDate()
	{
		LocalDate value = null;
		sheetName = "PDF_Data";
		excel = new ReadExcel(sheetName);


		Map<String, String> ExcelTestData = new HashMap<String, String>();
		{
			
			ExcelTestData = excel.getExcelInputData("TC01");
			
			state =  ExcelTestData.get(ExcelTestDataConstants.state);
			System.out.println(state);

			dob =  ExcelTestData.get(ExcelTestDataConstants.patientDOB);
			System.out.println("date of birth - " + dob);
			String dobForParsing = Utility_Function.changeDateFormat(dob);
			System.out.println(Utility_Function.changeDateFormat(dob) + " DOB format changed");
			
			ConsignedDate =  ExcelTestData.get(ExcelTestDataConstants.patientAuthorizationDate);
			System.out.println("ConsignedDate - "+ConsignedDate);
			String consignedDateForParsing = Utility_Function.changeDateFormat(ConsignedDate);
			System.out.println(Utility_Function.changeDateFormat(ConsignedDate) + " ConsignedDate format changed");

			LocalDate today = LocalDate.now();
			System.out.println("today date - "+today);
			
			DOB = LocalDate.parse(dobForParsing);
			consignedDate = LocalDate.parse(consignedDateForParsing);

			//Calculate current Date 
//			LocalDate today = LocalDate.now();
//			System.out.println("today date -"+today);

			Period difference = Period.between(DOB , today);   
			// Show date difference in years, months, and days   
			System.out.print("Difference between two dates is:\n");   
			System.out.printf( "%d days, %d months and %d years",   
					difference.getDays(),  
					difference.getMonths(),   
					difference.getYears());  
			System.out.println("  ");

			years = difference.getYears();
			months = difference.getMonths();
			days = difference.getDays();
						

			eighteenYearsAgo = DOB.minusYears(18);
			
			EighteenBday = DOB.plusYears(18);		
			System.out.println("Eighteen years add - "+EighteenBday);
			TwentyOneBday = DOB.plusYears(21);	
			System.out.println("TwentyOne years add - "+TwentyOneBday);

		}
		
		
	//Minor for PPA and other consents
	if((years < 21) && (state.equalsIgnoreCase("Puerto Rico"))){
		
		PatientUpdatedDate = TwentyOneBday.plusDays(180);
		ConsentUpdatedDate = consignedDate.plusDays(540);
		System.out.println("Puerto Rico Minor + 180 - " + PatientUpdatedDate);
		System.out.println("Puerto Rico Minor + 540 - " + ConsentUpdatedDate);
		if(PatientUpdatedDate.isAfter(ConsentUpdatedDate)) {
			System.out.println("Puerto Rico Minor Result + 180 " + ConsentUpdatedDate);
			value = ConsentUpdatedDate;
		}else {
			System.out.println("Puerto Rico Minor Result + 540 " + PatientUpdatedDate);
			value = PatientUpdatedDate;
		}
	}else if ((years < 18) && (!state.equalsIgnoreCase("Maryland")) && (!state.equalsIgnoreCase("Minnesota")) && (!state.equalsIgnoreCase("Puerto Rico"))) {
		
		PatientUpdatedDate = EighteenBday.plusDays(180);
		ConsentUpdatedDate = consignedDate.plusDays(540);
		System.out.println("Other States Minor Result + 180 - " + PatientUpdatedDate);
		System.out.println("Other States Minor Result + 540 - " + ConsentUpdatedDate);
		if(PatientUpdatedDate.isAfter(ConsentUpdatedDate)){
			System.out.println("Other States Minor Result + 180 " + ConsentUpdatedDate);
			value = ConsentUpdatedDate;
		} else {
			System.out.println("Other States Minor + 540 " + PatientUpdatedDate);
			value = PatientUpdatedDate;
		}
	}
	
	
	//Major for PPA and other consents
	if(years >= 21 && state.equalsIgnoreCase("Puerto Rico")) {
		
		value = consignedDate.plusDays(540);
		System.out.println("Major puerto rico " + value);
		
	}else if((years >= 18) && (!state.equalsIgnoreCase("Maryland")) && (!state.equalsIgnoreCase("Minnesota")) && (!state.equalsIgnoreCase("Puerto Rico")))
	{
		value = consignedDate.plusDays(540);
		System.out.println("Major other states" + value);
	
	}
	return value;
	
	}
}
	
