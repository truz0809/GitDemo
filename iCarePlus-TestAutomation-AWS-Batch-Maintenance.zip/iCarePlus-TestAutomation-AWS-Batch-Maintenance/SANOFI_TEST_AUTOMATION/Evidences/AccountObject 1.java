package com.sanofi.selenium.pages;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.sanofi.selenium.constants.ExcelTestDataConstants;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;
import com.sanofi.selenium.utils.ReadExcel;

public class AccountObject extends Utility_Function{

	public AccountObject(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public static String accountName ;
	//public static String accountName1 ;
	
	SoftAssert softAssert = new SoftAssert();


	/************* Static Elements ******************************************/

	public static By RelatedTab = By.xpath("//a[@id=\"relatedListsTab__item\"]");

	public static By NavigationMenu = By.xpath("//button[@aria-label='Show Navigation Menu']");

	public static By AccountMenu = By.xpath("//span[text()='Accounts']");

	public static By SearchList = By.xpath("//input[@placeholder='Search this list...']");

	public static By DetailsTab = By.xpath("//a[text()='Details']");

	public static By accRec = By.xpath("(//a[@data-refid='recordId'])[1]");

	public static By AuthorizationFormTextMessaging = By.xpath("//span[contains(text(), 'Text Messaging Consent')]");
	public static By AuthorizationFormHIPAA = By.xpath("//span[contains(text(), 'HIPAA Authorization')]");


	public static By HealthConditionRec = By.xpath("(//span[starts-with(text(), 'CON-')])[2]");
	public static By CareProgEnrolleesRec = By.xpath("(//span[contains(text(), 'DMW EoE : ')])[3]");
	public static By PrefSpecialtyPharmacyChkbox = By.xpath("//input[@name='PreferredSpecialtyPharmacy_ICC__c']//parent::span//following-sibling::label");
	public static By DUPIXENTCheckbox = By.xpath("//input[@name='DUPIXENTMyWay_ICC__c']//parent::span//following-sibling::label");

	public static By MedicationRequest1 = By.xpath("(//span[starts-with(text(),'MR-')])[1]");
	public static By MedicationRequest2 = By.xpath("(//span[starts-with(text(),'MR-')])[3]");
	public static By ConsentExpirationDate = By.xpath("//span[text()='Consent Expiration Date Time']//parent::div//parent::dt//following-sibling::dd//child::div//child::span//child::slot//child::lightning-formatted-text");
	public static By MemberPlanRecordType = By.xpath("(//span[text()='Pharmacy'])[1]");

	public static By eleCCRTitle = By.xpath("//span[@title='Contact Contact Relationships']");

	public static By eleFirstCCR=By.xpath("(//span[contains(text(),'CCR') and @id='window'])[3]");

	public static By eleMedicationReq = By.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()='Medication']//parent::div//parent::dt//following-sibling::dd//child::span//child::span)[1]"); 

	public static By eleContactRelationshipRec = By.xpath("(//span[starts-with(text(), 'CCR-000')])[4]");

	public static By eleMemberPlanTitle = By.xpath("//span[@title='Member Plans']");

	public static By eleFirstMP=By.xpath("(//h1[@title='Member Plans']/following::a[@class='flex-wrap-ie11 slds-truncate'])[1]");

	public static By eleConditionCode = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Condition Code\"]//parent::div//parent::dt//following-sibling::dd//child::span//child::span");

	public static By eleCareProgram =By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Care Program Enrollees\"])[1]");

	public static By eleCareProgramEnrollees = By.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()='Care Program Enrollees'])[1]");

	public static By eleCareProgramEnrolleeRec = By.xpath("//span[starts-with(text(), 'DMW')]");

	public static By eleRecordType =By.xpath("(//span[text()=\"Record Type\"]//parent::div//parent::dt//following-sibling::dd//lightning-formatted-text)[2]");

	public static By elePatientHasIns = By.xpath("//lightning-formatted-text[text()='No']");
	public static By eleAuthorizationConsentTitle = By.xpath("//strong[contains(text(), 'Authorization Form Consents (0)')]");
	
	/************* Dynamic Elements ******************************************/

	public static String strAccName = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//parent::dt//following-sibling::dd//lightning-formatted-name";	
	public static String strAccountObjectDetails = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//parent::dt//following-sibling::dd//lightning-formatted-text";
	public static String strAccObjectPhone = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//parent::dt//following-sibling::dd//child::div//child::span//child::slot//child::records-output-phone";
	public static String strAccObjEmail = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//parent::dt//following-sibling::dd//child::div//child::span//child::slot//child::emailui-formatted-email-account";
	public static String strAccObjAddress = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//parent::dt//following-sibling::dd//child::div//child::span//child::slot//child::lightning-formatted-address";
	public static String strAccountObjectsCreated = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::a";
	public static String strFields ="//span[text()=\"{0}\"]//parent::div//parent::dt//following-sibling::dd//lightning-formatted-text";
    public static String strAccObject = "//span[text()=\"{0}\"]";
    public static String strAccObjectNoRec = "//span[text()=\"{0}\"]//following-sibling::span";
	
	public void navigateToToAccDetails() {

		waitAndVerifyElement(NavigationMenu);
		click(NavigationMenu);
		click(AccountMenu);
		setTimeOut(2000);

		click(SearchList);
		setTimeOut(1000);
		inputText(SearchList, "Patient2 Eosinophilic2 Patient2"); //accountName
		genericKeyPress(SearchList,"Enter");
		waitAndVerifyElement(accRec);
		setTimeOut(5000);
		click(accRec);

		setTimeOut(2000);
		refresh();
		click(DetailsTab);
		setTimeOut(2000);
	}

	//To navigate to Account object
	public void navigateToAccObject(String Firstname,String MiddleName,String LastName,String DateofBirth,String gender,
			String Phone,String email,String address,String patientHasInsurance,String Lang,String city, String state, String zip) {


		try {

			setTimeOut(10000);
			accountName = Firstname +" "+ MiddleName+" "+LastName;

			waitForPageLoaded();					
			navigateToToAccDetails();

			By AccountNameDetailsTab = getDynamicElement(strAccName, "Account Name");
			String constAccountName = getText(AccountNameDetailsTab);

			verifyDetails(AccountNameDetailsTab, accountName, "Account Name");

			//			By accObjectBirthdate = getDynamicElement(strAccountObjectDetails, "Birthdate");
			//
			//			String DOB= DateofBirth.replaceAll("-","/");			//dob need to chang
			//			System.out.print(DOB);
			//			DOB = DOB.replaceFirst("^0*", "");
			//			System.out.println(DOB);
			//			verifyDetails(accObjectBirthdate, DOB, "Birthdate");

			By accObjectGender = getDynamicElement(strAccountObjectDetails, "Gender");
			verifyDetails(accObjectGender, gender, "Gender");

			By accObjectOtherPhone = getDynamicElement(strAccObjectPhone, "Other Phone");
			verifyDetails(accObjectOtherPhone, Phone, "Phone");

			By accObjEmail = getDynamicElement(strAccObjEmail, "Email");
			verifyDetails(accObjEmail, email, "Email");

			//			By accObjaddress = getDynamicElement(strAccObjAddress, "Mailing Address");								//new line need to add
			//			String addr = address+" " + city + "," + " " + state + " " + zip + " " + "United States";
			//			System.out.println(addr + "excel addr");
			//			verifyDetails(accObjaddress, addr, "Mailing Address");


			//			By accObjPatientHasIns = getDynamicElement(strAccountObjectDetails, "Patient has insurance");		//checkbox
			//			verifyDetails(accObjPatientHasIns, patientHasInsurance, "patient has insurance");

			By accObjPrefLang = getDynamicElement(strAccountObjectDetails, "Preferred Language");
			verifyDetails(accObjPrefLang, Lang, "Preferred Language");

			setTimeOut(2000);
			click(RelatedTab);
			setTimeOut(2000);
			LoggingInfo("Click on Related Tab section");

		}catch(Exception e){
			e.printStackTrace();
			Log.error("Failed to verify element " + e.getMessage());
		}

	}

	public void verifyConsentExpiryDate() { 

		try {
			setTimeOut(8000);
			scrollToDocumentHeight();
			setTimeOut(2000);
			waitAndVerifyElement(AuthorizationFormTextMessaging);
			waitAndVerifyElement(AuthorizationFormHIPAA);
			LoggingInfo("Verify Authorization Form for Text Messaging and HIPAA Form");

			//AuthorizationFormConsent
			clickByJavascript(AuthorizationFormTextMessaging);
			setTimeOut(2000);
			LoggingInfo("Clicks on Authorization Form for Text messaging");
			System.out.println("Clicks on Authorization Form for Text messaging");
			
			By ConsentExpiryDate = getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time");
			
			//To split it into date and time
			String cExpiryDt = getText(ConsentExpiryDate);
			String[] date = cExpiryDt.split(",");
			String consentExpDate = date[0];
			System.out.println(consentExpDate + " date splitted");
			
			dummyConsent expDate = new dummyConsent();
			LocalDate PatientConsentDate = expDate.PPAConsentExpiryDate();
			System.out.println(PatientConsentDate + " - method calculated for localdate expiry date");
			String updatedPatientConsentDate = PatientConsentDate.toString();
		
			String consentExpDateUI = Utility_Function.changeDateFormat1(consentExpDate);
			System.out.println(consentExpDateUI + " changing the date format obtained from UI");
			
			//comparison method
			
			if(consentExpDateUI.equalsIgnoreCase(updatedPatientConsentDate)) {
				System.out.println("Consent expiry date matches " + consentExpDateUI);
			}else {
				System.out.println("Consent expiry date does not match " + " actual " + consentExpDateUI + "," + " expected "+ updatedPatientConsentDate);
			}
			
		
			//HIPAA
			back();
			setTimeOut(3000);
			clickByJavascript(AuthorizationFormHIPAA);
			setTimeOut(2000);
			LoggingInfo("Clicks on Authorization Form for HIPAA");
			System.out.println("Clicks on Authorization Form for HIPAA");
			
			By ConsentHipaaExpiryDate = getDynamicElement(strAccountObjectDetails, "Consent Expiration Date Time");
			
			//To split it into date and time
			String cExpiryDtH = getText(ConsentHipaaExpiryDate);
			String[] dateH = cExpiryDtH.split(",");
			String consentExpDateH = dateH[0];
			
			LocalDate PatientConsentDateH = expDate.HIPAAConsentExpiryDate();
			System.out.println(PatientConsentDateH + " - method calculated localdate expiry date for HIPAA");
			String updatedPatientConsentDateHIPAA = PatientConsentDateH.toString();
			
			String consentExpiryDateUIHIPAA = Utility_Function.changeDateFormat1(consentExpDateH);
		
			//comparison method
			if(consentExpiryDateUIHIPAA.equalsIgnoreCase(updatedPatientConsentDateHIPAA)) {
				System.out.println("Consent expiry date matches " + consentExpiryDateUIHIPAA);
			}else {
				System.out.println("Consent expiry date does not match " + " actual "+ consentExpiryDateUIHIPAA + "," + " expected " + updatedPatientConsentDateHIPAA);
			}
			
			//back to account page
			setTimeOut(4000);
			navigateToToAccDetails();
			setTimeOut(4000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Authorization Form Consent verification failed " + e.getMessage());
			Assert.fail("Authorization Form Consent verification failed" + ". Error - " + e.getMessage());
		}

	}


	public void verifyCareProgramEnrollees() { 

		try {
			setTimeOut(1000);
			clickByJavascript(eleCareProgramEnrollees);
			setTimeOut(4000);
			LoggingInfo("Clicked on CareProgramEnrollees");

			refresh();
			setTimeOut(3000);
			click(eleCareProgramEnrolleeRec);
			setTimeOut(4000);
			LoggingInfo("Clicks on Care Program Enrollees record");

			//Verify Preferred Specialty Pharmacy checkbox
			//						utilityPage.isCheckboxSelected(PrefSpecialtyPharmacyChkbox);
			LoggingInfo("Verify Preferred Specialty Pharmacy checkbox");

			//Verify DUPIXENT checkbox
			//						utilityPage.isCheckboxSelected(DUPIXENTCheckbox);
			LoggingInfo("Verify DUPIXENT checkbox");

			setTimeOut(4000);
			navigateToToAccDetails();
			setTimeOut(4000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("CCR Title verification failed " + e.getMessage());
			Assert.fail("CCR Title verification failed" + ". Error - " + e.getMessage());
		}

	}

	public void verifyHealthCondition(String diagnosisCode) { 

		try {

			setTimeOut(2000);
			//			HealthConditions			
			setTimeOut(2000);
			By healthCond = getDynamicElement(strAccountObjectsCreated, "Health Conditions");
			clickByJavascript(healthCond);
			setTimeOut(2000);
			LoggingInfo("Clicked on Health conditions section");
			click(HealthConditionRec);
			setTimeOut(2000);
			LoggingInfo("Clicks on Health Conditions record");
			verifyDetails(eleConditionCode, diagnosisCode, "DiagnosisCode");
			setTimeOut(4000);
			navigateToToAccDetails();
			setTimeOut(4000);

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("CCR Title verification failed " + e.getMessage());
			Assert.fail("CCR Title verification failed" + ". Error - " + e.getMessage());
		}

	}

	public void VerifyMedicationRecord(String prescription5a, String prescription5b)
	{
		By medicationReq = getDynamicElement(strAccountObjectsCreated, "Medication Requests");
		clickByJavascript(medicationReq);
		setTimeOut(2000);
		LoggingInfo("Clicks on Medication Requests section");
		refresh();
		setTimeOut(3000);
		waitAndVerifyElement(MedicationRequest1);
		click(MedicationRequest1);
		setTimeOut(2000);

		verifyDetails(eleMedicationReq, prescription5a, "Prescription5ADose");
		setTimeOut(5000);

		back();
		setTimeOut(4000);
		refresh();

		click(MedicationRequest2);
		setTimeOut(4000);
		verifyDetails(eleMedicationReq, prescription5b, "Prescription5BDose");
		setTimeOut(4000);

		navigateToToAccDetails();
		setTimeOut(4000);
	}


	public void verifyAndClickOnCCR() {

		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleCCRTitle);
			LoggingInfo("CCR Title is loaded");
			clickByJavascript(eleCCRTitle);
			LoggingInfo("First CCR  is clicked");
			setTimeOut(500);
			clickByJavascript(eleContactRelationshipRec);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("CCR Title verification failed " + e.getMessage());
			Assert.fail("CCR Title verification failed" + ". Error - " + e.getMessage());
		}

	}

	public void verifyCCR(String relationship) {
		try {
			setTimeOut(1000);
			Log.info("Verify Relationship is Present");
			//			By eleRelationship = getDynamicElement(strFields, "Relationship");
			//			waitAndVerifyElement(eleRelationship);
			//		verifyDetails(eleRelationship, relationship, "Relationship");
			LoggingInfo("Relationship is verified");
			setTimeOut(1000);
			setTimeOut(4000);
			navigateToToAccDetails();
			setTimeOut(4000);


		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Relationship verification failed " + e.getMessage());
			Assert.fail("Relationship verification failed  " + e.getMessage());

		}

	}

	public void verifyAndClickOnMemberPlan() {

		try {
			setTimeOut(2000);
			waitAndVerifyElement(eleMemberPlanTitle);
			LoggingInfo("Memeber Plan Title is loaded");
			clickByJavascript(eleMemberPlanTitle);
			LoggingInfo("Memeber Plan  is clciked");
			setTimeOut(500);
			clickByJavascript(eleFirstMP);
			setTimeOut(2000);
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Member plan title verification failed " + e.getMessage());
			Assert.fail("Member plan title verification failed" + ". Error - " + e.getMessage());
		}
	}


	public void verifyRecordType(String recordType) {
		try {
			setTimeOut(2000);
			Log.info("Verify Record type is Present");
			waitAndVerifyElement(eleRecordType);
			verifyDetails(eleRecordType, recordType, "Record Type");
			LoggingInfo("Record Type is verified");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Record Type verification failed " + e.getMessage());
			Assert.fail("Record Type verification failed  " + e.getMessage());
		}
	}
	
	public void verifyAccountObjectsHasNoRecords(String Firstname,String MiddleName,String LastName, String DateofBirth,String gender,
			String Phone,String email,String address,String patientHasInsurance,String Lang) {
		
		try {
			setTimeOut(10000);
			accountName = Firstname +" "+ MiddleName+" "+LastName;

			waitForPageLoaded();					
			navigateToToAccDetails();

			By AccountNameDetailsTab = getDynamicElement(strAccName, "Account Name");
			String constAccountName = getText(AccountNameDetailsTab);

			verifyDetails(AccountNameDetailsTab, accountName, "Account Name");

			//			By accObjectBirthdate = getDynamicElement(strAccountObjectDetails, "Birthdate");
			//
			//			String DOB= DateofBirth.replaceAll("-","/");			//dob need to chang
			//			System.out.print(DOB);
			//			DOB = DOB.replaceFirst("^0*", "");
			//			System.out.println(DOB);
			//			verifyDetails(accObjectBirthdate, DOB, "Birthdate");

			By accObjectGender = getDynamicElement(strAccountObjectDetails, "Gender");
			verifyDetails(accObjectGender, gender, "Gender");

			By accObjectOtherPhone = getDynamicElement(strAccObjectPhone, "Other Phone");
			verifyDetails(accObjectOtherPhone, Phone, "Phone");

			By accObjEmail = getDynamicElement(strAccObjEmail, "Email");
			verifyDetails(accObjEmail, email, "Email");

			//			By accObjaddress = getDynamicElement(strAccObjAddress, "Mailing Address");								//new line need to add
			//			String addr = address+" " + city + "," + " " + state + " " + zip + " " + "United States";
			//			System.out.println(addr + "excel addr");
			//			verifyDetails(accObjaddress, addr, "Mailing Address");


            String patienthasInsurance = getText(elePatientHasIns);
			verifyDetails(elePatientHasIns, patienthasInsurance, "patient has insurance");

			By accObjPrefLang = getDynamicElement(strAccountObjectDetails, "Preferred Language");
			verifyDetails(accObjPrefLang, Lang, "Preferred Language");

			setTimeOut(2000);
			click(RelatedTab);
			setTimeOut(2000);
			LoggingInfo("Click on Related Tab section");
			
			//Verify Account Objects has no records
			//Authorization Form Consent
			
			scrollToDocumentHeight();
			setTimeOut(2000);
			String authorizationConsent = getText(eleAuthorizationConsentTitle);
			waitAndVerifyElement(eleAuthorizationConsentTitle);
			setTimeOut(2000);
			LoggingInfo("Successfully verified Authorization Consent object with no records");
			
			//Verify Member Plans has no records
			By memberPlanAccObject = getDynamicElement(strAccObject, "Member Plans");
			By memberPlanRecAccObject = getDynamicElement(strAccObjectNoRec, "Member Plans");
			waitAndVerifyElement(memberPlanRecAccObject);
			setTimeOut(2000);
			LoggingInfo("Successfully verified Member Plans object with no records");
			
			//Verify Medication Requests has no records
			By medicationRequestsRecAccObject = getDynamicElement(strAccObjectNoRec, "Medication Requests");
			waitAndVerifyElement(medicationRequestsRecAccObject);
			setTimeOut(2000);
			LoggingInfo("Successfully verified Medication Requests object with no records");
			
			//Verify Health Conditions has no records
			By healthConditionsRecAccObject = getDynamicElement(strAccObjectNoRec, "Health Conditions");
			waitAndVerifyElement(healthConditionsRecAccObject);
			setTimeOut(2000);
			LoggingInfo("Successfully verified Health Conditions object with no records");
			
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Verification failed for Account Object" + e.getMessage());
		}
	}
}
