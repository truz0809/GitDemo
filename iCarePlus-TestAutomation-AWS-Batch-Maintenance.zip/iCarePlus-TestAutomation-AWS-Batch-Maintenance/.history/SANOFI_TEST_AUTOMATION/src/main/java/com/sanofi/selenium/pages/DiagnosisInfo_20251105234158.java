package com.sanofi.selenium.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class DiagnosisInfo extends Utility_Function {

	public DiagnosisInfo(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	/************* Static Elements ******************************************/

	public static By DiagnosisDateInputField = By.xpath(
			"//*[contains(text(),'Date of Diagnosis')]//parent::label//parent::div//following-sibling::div//child::input");

	public static By Submit = By.xpath("//span[normalize-space()='Next' and @class='btnLabel']");

	public static By elePageTitle = By.xpath(
			"*//div[contains(@class,\"omniscript-body\")]//*[text()='Diagnosis Information']");
	public static By patientDependent = By
			.xpath("(//*[contains(@class,\"active lafPageHost\")]//div//input[@type=\"checkbox\"])[1]");
	public static By elePatientDependentChkBox=By.xpath("(//*[contains(@class,\"active lafPageHost\")]//div//input[@type=\"checkbox\"]//parent::div//span)[1]");
	/************* Dynamic Elements ******************************************/

	public static String strSearchBarDropdown = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div[contains(@class,\"slds-combobox\")]//input";
	public static String strSearchBarDropdownList = "//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//child::div//child::span//child::span";
	public static String prevNextButtons = "//*[contains(@class,\"omniscript-button-position\")]//*[text()=\"{0}\"]";
	public static String elePrevNextButtons = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"omniscript-button-position\")]//*[text()=\"{0}\"]//parent::button";
	public static String strdropDownXpath = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\\\"slds-combobox\\\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//child::input";
	public static String dropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]";
	public static String eosCount = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//child::input";

	public void verifyDiagnosisInfoPageTitle() {
		try {

			setTimeOut(2000);
			waitForPageLoaded();
			Log.info("Verify Diagnosis Information Page Present");
			waitAndVerifyElement(elePageTitle);
			LoggingInfo("Diagnosis Information Page is loaded");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Page load has Failed" + ". Error - " + e.getMessage());

		}
	}

	public void DiagnosisValidation(String DiagnosisCodeExcelData, String DiagnosisDateExcelData)
			throws InterruptedException {
		setTimeOut(2000);

		try {

			Log.info("Diagnosis Information");
			By diagnosisCodeDropDownBox = getDynamicElement(strSearchBarDropdown, "Diagnosis Code");
			waitAndVerifyElement(diagnosisCodeDropDownBox);
			verifyHardAssertDropDown(diagnosisCodeDropDownBox, DiagnosisCodeExcelData, diagnosisCode);

			// Date check
			waitAndVerifyElement(DiagnosisDateInputField);
			verifyHardAssertCalendarDate(DiagnosisDateInputField, DiagnosisDateExcelData, dateOfDiagnosis);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Page verification has failed" + ". Error - " + e.getMessage());
		}

	}

	public void enterDiagnosis(String DiagnosisCodeExcelData, String DiagnosisDateExcelData)
			throws InterruptedException {
		setTimeOut(2000);

		try {

			Log.info("Diagnosis Information");
			By diagnosisCodeDropDownBox = getDynamicElement(strSearchBarDropdown, "Diagnosis Code");
			waitAndVerifyElement(diagnosisCodeDropDownBox);
			String code = getAttributeValue(diagnosisCodeDropDownBox, "value");
			if (code==null || !code.equalsIgnoreCase(DiagnosisCodeExcelData)) {
				By diagnosisCodeDropDownList = getDynamicElement(strSearchBarDropdownList, "Diagnosis Code");
				click(diagnosisCodeDropDownBox);
				selectItemFromList(diagnosisCodeDropDownBox, diagnosisCodeDropDownList, DiagnosisCodeExcelData,
						diagnosisCode);
			} else {
				highLightElement(diagnosisCodeDropDownBox);
				Log.info("Actual text " + code + " matches with expected text " + DiagnosisCodeExcelData);
			}

			// Date check
			waitAndVerifyElement(DiagnosisDateInputField);
			verifyAndEnterInfoInputField(DiagnosisDateInputField, DiagnosisDateExcelData, dateOfDiagnosis);
			
			LoggingInfo("Diagnosis Information has been entered/verified successfully.");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Page verification has failed" + ". Error - " + e.getMessage());
		}

	}

	public void clickOnNextButton() {
		try {
			setTimeOut(1000);
			By nextButton = getDynamicElement(prevNextButtons, "Next");
			scrollToElement(nextButton);
			waitAndVerifyElement(nextButton);
			click(nextButton);
			Log.info("Clicked on Next Button");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on Previous Button-" + "Error - " + e.getMessage());
		}
	}

	public void clickOnPreviousButton() {
		try {
			setTimeOut(1000);
			By previousButton = getDynamicElement(elePrevNextButtons, "Previous");
			waitAndVerifyElement(previousButton);
			click(previousButton);
			setTimeOut(2000);
			Log.info("Clicked on Previous Button");
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to click on Previous Button-" + "Error - " + e.getMessage());
		}
	}
	
	/**
	 * Function: verify diagnosis fields are present on page
	 * 
	 * @author Trupti Zure
	 **/

	public void verifyDiagnosisFields() {
		try {
			// Eosinophil Count Populated?
			By eosCount = By.xpath(
					"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Eosinophil Count Populated?\"]//parent::label//parent::div//following-sibling::div//child::input)[1]");
			boolean eosFound = isElementPresent(eosCount);
			Assert.assertTrue(eosFound, "Eosinophil Count Populated? is not present");

			// Patient Dependent on Corticosteroids?
			boolean patientDependentFound = isElementPresent(patientDependent);
			Assert.assertTrue(patientDependentFound, "Patient Dependent on Corticosteroids?");

			LoggingInfo("Two new fields are visible  on the diagnosis code section");
			setTimeOut(2000);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to verify diagnosis fields-" + "Error - " + e.getMessage());
		}
	}
	
	/**
	 * Function: Enter EOS count and patient dependent infomration
	 * 
	 * @author Trupti Zure
	 **/

	public void enterEosCountAndPatientDepenedent(String eosCount, String ispatientDependent) {
		try {

			
//			setTimeOut(2000);
//			By eosCountElementBox = getDynamicElement(eosCount, "Eosinophil Count");
//			waitAndVerifyElement(eosCountElementBox);
//			scrollToElement(eosCountElementBox);
//			inputText(eosCountElementBox,eosCount);
//			setTimeOut(2000);
			
			// Eosinophil Count Populated?
			By eosCountElementBox = getDynamicElement(strdropDownXpath, "Eosinophil Count Populated?");
			waitAndVerifyElement(eosCountElementBox);
			scrollToElement(eosCountElementBox);
			click(eosCountElementBox);
			By eosCountOptions = getDynamicElement(dropDownOptions, "Eosinophil Count Populated?");
			waitAndVerifyElement(eosCountOptions);
			selectItemFromList(eosCountElementBox, eosCountOptions, eosCount, "Eosinophil Count Populated?");

			// Patient Dependent on Corticosteroids?
			waitAndVerifyElement(patientDependent);
			scrollToElement(patientDependent);
			if (ispatientDependent.equalsIgnoreCase("Yes")) {
				click(elePatientDependentChkBox);
			}

			LoggingInfo("Entered data in Eosinophil Count Populated? and Patient Dependent on Corticosteroids?");

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Failed to enter Eosinophil Count Populated? and Patient Dependent on Corticosteroids? -"
					+ "Error - " + e.getMessage());
		}
	}

}
