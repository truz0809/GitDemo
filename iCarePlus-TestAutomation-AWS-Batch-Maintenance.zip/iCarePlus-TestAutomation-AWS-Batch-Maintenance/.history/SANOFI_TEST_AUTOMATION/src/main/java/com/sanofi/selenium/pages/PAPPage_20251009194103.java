package com.sanofi.selenium.pages;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.utils.Log;

public class PAPPage extends Utility_Function {

	public PAPPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	/************************
	 * Elements
	 **************************************************/
	public static By order = By.xpath("//table//tr[td[normalize-space()='IAP']]//th[@data-label='Order Number']//a");
	public static By eleStartNewServiceButton = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//button[@name=\"CareProgramEnrollee.CPE_StartNewService_ICC\"]");
	public static By select = By.xpath("(//button[contains(text(),'Select')])[1]");
	public static By attachments = By
			.xpath("//span[contains(text(), 'Automation')]/preceding::span[@class='slds-checkbox_faux'][1]");
	public static By eleSelectDropDown = By.xpath("//*[contains(@class,\"active lafPageHost\")]//select");
	public static By elePayerName = By.xpath(
			"(//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Payer Name\"]//parent::label//parent::div//following-sibling::div//li//span[contains(@class,\"option-text\")])[2]");
	public static By eleAttemptDate = By.xpath(
			"//*[contains(@class,'active lafPageHost')]//*[text()='Attempt Date']//parent::label//parent::div//following-sibling::div//input");
	public static By eleSearchButton = By
			.xpath("//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Search\"]//parent::button");
	public static By eleOutcome = By.xpath("//*[contains(@class,\"active lafPageHost\")]//*[@title=\"Approved\"]");
	public static By eleMedD = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"Patient has Medicare Part D?\"]//parent::div//following-sibling::div//lightning-formatted-text");
	public static By elePAPOrder = By.xpath("(//*[contains(@class,\"active lafPageHost\")]//*[@title=\"PAP\"])[1]");
	public static By eleRefresh = By.xpath(
			"//*[contains(@class,\"active lafPageHost\")]//button[@title=\"Refresh\" and @Kx-scope=\"button-neutral\"]");
	/************************
	 * Dynamic Elements
	 **************************************************/
	public static String eleButton = "//*[contains(@class,\"active lafPageHost\")]//*[@title=\"{0}\"]";
	public static String strTaskName = "//*[contains(@class,\"active lafPageHost\")]//*[@class=\"slds-section__title\"]//*[text()=\"{0}\"]";
	public static String taskButton = "(//*[@class=\"slds-section__title\"]//*[text()=\"{0}\"]//parent::div//span)[1]";
	public static String strSubtaskName = "//*[@class=\"card\"]//*[text()=\"{0}\"]";
	public static String strSubTaskStatus = "(//*[@class=\"card\"]//*[text()=\"{0}\"]//parent::div//li)[2]";
	public static String subTaskButton = "//*[contains(@class,\"active lafPageHost\")]//div[@class=\"card\"]//h2[text()=\"{0}\"]//parent::div";
	public static String strInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String strDropDownInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//input";
	public static String searchDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//span[contains(@class,\"option-text\")]";
	public static String strDropDownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]";
	public static String strInputField = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::label//ancestor::div[@class=\"slds-grid\"]//following-sibling::input";
	public static String strDropDownOptions2 = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::label//parent::div//following-sibling::div//li//child::span[contains(@class,\"option-text\")]";
	public static String updatedInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::div[contains(@class,\"slds-grid\")]//runtime_omnistudio_omniscript-omniscript-text//input";
	public static String strAccountObjectDetails = "//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-grid\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//lightning-formatted-text";
	public static String labelsField = "//*[contains(@class,\"active lafPageHost\")]//div//span[text()=\"{0}\"]";
	public static String icareplusRecordsRadioBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//ancestor::tr//lightning-button//button[@title=\"Select\"]";
	public static String correspondenceInputField = "(//*[contains(@class,\"active lafPageHost\")]//span[text()=\"{0}\"]//ancestor::div[contains(@class,\"slds-form-element\")])[2]";
	public static String strReadOnlyFields = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"Enrollment Start Date\"]//parent::div//following-sibling::div//span[contains(@class,\"test-id__field-value\") and contains(@class, \"is-read-only\")]";
	public static String strfieldInputBox = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"Status\"]//parent::div//following-sibling::div//span/slot//*[contains(@slot, \"output\")]";
	public static String strfieldEditButton = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div/button";
	public static String outcomeDropOption = "//*[contains(@class,\"active lafPageHost\")]//span[text()=\"Outcome\"]//parent::label//parent::div//following-sibling::div//li//span[contains(text(),\"{0}\")]";
	/**
	 * Function:Select start new service
	 * 
	 * @author Trupti
	 **/
	public void selectService() {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			selectItemFromList(eleSelectDropDown, "PAP");
			LoggingInfo("Selected Service as PAP");
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Service " + e.getMessage());
			Assert.fail("Failed to select Service " + e.getMessage());
		}
	}

	/**
	 * Function:Select reason
	 * 
	 * @author Trupti
	 * 
	 **/
	public void selectReason(String reason) {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			selectItemFromList(eleSelectDropDown, reason);
			LoggingInfo("Selected Reason as-" + reason);
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Reason " + e.getMessage());
			Assert.fail("Failed to select Reason " + e.getMessage());
		}
	}

	// Anand P
	public void selectService(String service) {
		try {
			waitAndVerifyElement(eleSelectDropDown);
			selectItemFromList(eleSelectDropDown, service);
			LoggingInfo("Selected Service as " + service);
			setTimeOut(1000);
		} catch (Exception e) {
			Log.error("Failed to select Service " + e.getMessage());
			Assert.fail("Failed to select Service " + e.getMessage());
		}
	}

	/**
	 * Function:Check PAP wo initiation
	 * 
	 * @author Trupti
	 **/

	public void checkPAPWOIntiation() {
		try {
			setTimeOut(10000);
			By papButton = getDynamicElement(eleButton, "PAP");
			waitAndVerifyElement(papButton);
			scrollToElement(papButton);
			click(papButton);
			String buttonState = getAttributeValue(papButton, "aria-pressed");
			// Assert the state of the button
			Assert.assertEquals(buttonState, "true", "PAP flow is initialized");
			LoggingInfo("PAP flow is initialized");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to check the status of PAP intiation " + e.getMessage());
			Assert.fail("Failed to check the status of PAP intiation " + e.getMessage());
		}
	}

	/**
	 * Function:Check PAP task initiation
	 * 
	 * @author Trupti
	 **/

	public void checkPAPTaskInitiation() {
		try {
			By taskName = getDynamicElement(strTaskName, "Alternate Coverage");
			waitAndVerifyElement(taskName);
			scrollToElement(taskName);
			LoggingInfo("Alternate Coverage task has been initialized");
			setTimeOut(2000);

			By eleTaskButton = getDynamicElement(taskButton, "Alternate Coverage");
			click(eleTaskButton);
			LoggingInfo("Clicked on Alternate Coverage task");
			setTimeOut(1000);

			By subTaskName = getDynamicElement(strSubtaskName, "Pre-Check");
			waitAndVerifyElement(subTaskName);
			LoggingInfo("Pre-Check sub task has been initialized");
			setTimeOut(2000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, "Pre-Check");
			waitAndVerifyElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Not Started", "Pre-Check task status verified");

		} catch (Exception e) {
			Log.error("Failed to Check PAP Task Initiation " + e.getMessage());
			Assert.fail("Failed to Check PAP Task Initiation " + e.getMessage());
		}
	}

	/**
	 * Function:Click on task
	 * 
	 * @author Trupti
	 **/

	public void clickOnTask(String taskname) {
		try {
			By eleSubTaskButton = getDynamicElement(subTaskButton, taskname);
			waitAndVerifyElement(eleSubTaskButton);
			scrollToElement(eleSubTaskButton);
			clickByJavascript(eleSubTaskButton);
			setTimeOut(2000);
			LoggingInfo("Clicked on task-" + taskname);
		} catch (Exception e) {
			Log.error("Failed to click on task " + e.getMessage());
			Assert.fail("Failed to click on task " + e.getMessage());
		}
	}

	/**
	 * Function: Enter Eligibility Check
	 * 
	 * @author Anand P
	 **/
	public void enterEligibilityCheck() {
		try {

			String[] dropdownLabels = { "Uninsured or functionally uninsured situation:", "Patient resides in US/PR?",
					"HCP in US/PR?", "FDA approved indication?", "Patient is not in-patient?" };
			for (String dropdownLabel : dropdownLabels) {
				By dropdownInputBox = getDynamicElement(strDropDownInputBox, dropdownLabel);
				waitAndVerifyElement(dropdownInputBox);
				scrollToElement(dropdownInputBox);
				click(dropdownInputBox);
				String option = "Yes";
				By dropdownOptions = getDynamicElement(strDropDownOptions, dropdownLabel);
				waitAndVerifyElement(dropdownOptions);
				selectItemFromList(dropdownInputBox, dropdownOptions, option, dropdownLabel);
				LoggingInfo("Selected " + dropdownLabel + " as-" + option);
				setTimeOut(1000);
			}

			By eleFPL = getDynamicElement(strDropDownInputBox, "Adjusted FPL %");
			waitAndVerifyElement(eleFPL);
			scrollToElement(eleFPL);
			inputText(eleFPL, "37");
			setTimeOut(1000);

			By inputBox = getDynamicElement(strInputBox, "BV Outcome");
			waitAndVerifyElement(inputBox);
			String value = getAttributeValue(inputBox, "value");
			if (value.equalsIgnoreCase(coverageSituation.get(2)) || value.equalsIgnoreCase(coverageSituation.get(3))
					|| value.equalsIgnoreCase(coverageSituation.get(4))) {

				By dropdownInputBox = getDynamicElement(strDropDownInputBox, "LIS");
				waitAndVerifyElement(dropdownInputBox);
				scrollToElement(dropdownInputBox);
				clickByJavascript(dropdownInputBox);
				By dropdownOptions = getDynamicElement(strDropDownOptions, "LIS");
				waitAndVerifyElement(dropdownOptions);
				selectItemFromList(dropdownInputBox, dropdownOptions, "Eligibile", "LIS");
				LoggingInfo("Selected LIS  as Eligibile");

			}

		} catch (Exception e) {
			Log.error("Failed to enter Eligibility Check " + e.getMessage());
			Assert.fail("Failed to enter Eligibility Check " + e.getMessage());
		}
	}

	/**
	 * Function:Validate patient information fields are disable
	 * 
	 * @author Trupti
	 **/
	public void validatePatientInfoFieldsAreDisable(boolean section) {

		String[] fieldsLabels = { "BV Outcome", "Annual adjusted household income % of FPL", "Plan Type",
				"Estimated Household Income", "LIS Eligible", "Estimated Household Size" };

		try {
			LoggingInfo("'Patient information' section is enable");
			setTimeOut(2000);

			for (String fieldLabel : fieldsLabels) {
				By fieldLocator = getDynamicElement(strInputBox, fieldLabel);
				scrollToElement(fieldLocator);
				verifyFieldIsEnabledOrDisabled(fieldLocator, fieldLabel, section);
				setTimeOut(2000);
			}

		} catch (Exception e) {
			Log.error("Failed to validate Patient Information Fields " + e.getMessage());
			Assert.fail("Failed to validate Patient Information Fields " + e.getMessage());
		}
	}

	/**
	 * Function:Validate patient information fields details
	 * 
	 * @author Trupti
	 **/
	public void verifyPatientInformationDetails(ArrayList<String> expectedValues) {

		String[] inputLabels = { "BV Outcome", "Annual adjusted household income % of FPL", "Plan Type",
				"Estimated Household Income", "LIS Eligible", "Estimated Household Size" };

		try {

			for (int i = 0; i < inputLabels.length; i++) {
				String inputLabel = inputLabels[i];
				By inputBox = getDynamicElement(strInputBox, inputLabel);
				waitAndVerifyElement(inputBox);
				String value = getAttributeValue(inputBox, "value");
				Assert.assertEquals(value, expectedValues.get(i),
						"Failed to verify pre check details for : " + inputLabel);
				LoggingInfo(inputLabel + " - value is as expected");
			}

		} catch (Exception e) {
			Log.error("Failed to verify patient information: " + e.getMessage());
			Assert.fail("Failed to verify patient information: " + e.getMessage());
		}
	}

	/**
	 * Function:Validate Coverage Situation Is Enable
	 * 
	 * @author Trupti
	 **/
	public void validateCoverageSituationIsEnable(boolean section) {

		try {
			LoggingInfo("'Coverage Situation' field is enable");
			By fieldLocator = getDynamicElement(strInputBox, "Coverage Situation");
			verifyFieldIsEnabledOrDisabled(fieldLocator, "Coverage Situation", section);
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to validate Coverage Situation Field " + e.getMessage());
			Assert.fail("Failed to validate Coverage Situation Field " + e.getMessage());
		}
	}

	/**
	 * Function:validate Alternate Research Is Disable
	 * 
	 * @author Trupti
	 **/
	public void validateAlternateResearchIsDisable(boolean section) {

		try {
			LoggingInfo("'Alternate Research Required?' field is disable");
			By fieldLocator = getDynamicElement(strInputField, "Alternate Research Required?");
			verifyFieldIsEnabledOrDisabled(fieldLocator, "Alternate Research Required?", section);
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to validate Alternate Research Required? Field " + e.getMessage());
			Assert.fail("Failed to validate Alternate Research Required? Field " + e.getMessage());
		}
	}

	/**
	 * Function:enter Coverage Situation
	 * 
	 * @author Trupti
	 **/
	public void enterCoverageSituation(String situation) {
		try {
			By coverageSituationdropdownInputBox = getDynamicElement(strDropDownInputBox, "Coverage Situation");
			waitAndVerifyElement(coverageSituationdropdownInputBox);
			scrollToElement(coverageSituationdropdownInputBox);
			click(coverageSituationdropdownInputBox);
			By dropdownOptions = getDynamicElement(strDropDownOptions, "Coverage Situation");
			waitAndVerifyElement(dropdownOptions);
			selectItemFromList(coverageSituationdropdownInputBox, dropdownOptions, situation, "Coverage Situation");

		} catch (Exception e) {
			Log.error("Failed to enter Coverage Situation Field " + e.getMessage());
			Assert.fail("Failed to enter Coverage Situation Field " + e.getMessage());
		}
	}

	/**
	 * Function:verify Alternate Research
	 * 
	 * @author Trupti
	 **/
	public void verifyAlternateResearch(String alternateResearch) {
		try {

			By alternateResearchInputBox = getDynamicElement(strInputField, "Alternate Research Required?");
			String value = getAttributeValue(alternateResearchInputBox, "value");
			Assert.assertEquals(value, alternateResearch, "Failed to verify value of alternate Research");
			LoggingInfo("Verified value of alternate Research");
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to verify value of Alternate Research Required? Field " + e.getMessage());
			Assert.fail("Failed to verify value of Alternate Research Required? Field " + e.getMessage());
		}
	}

	/**
	 * Function:Click on main task
	 * 
	 * @author Trupti
	 **/
	public void clickOnMainTask(String taskName) {
		try {

			By eleTaskButton = getDynamicElement(taskButton, taskName);
			scrollToElement(eleTaskButton);
			clickByJavascript(eleTaskButton);

			LoggingInfo("Clicked on task-" + taskName);
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to click on task " + e.getMessage());
			Assert.fail("Failed to click on task " + e.getMessage());
		}
	}

	/**
	 * Function:Click on PA task
	 * 
	 * @author Trupti
	 **/
	public void clickOnPAPTask() {
		try {
			By papButton = getDynamicElement(eleButton, "PAP");
			waitAndVerifyElement(papButton);
			scrollToElement(papButton);
			click(papButton);
		} catch (Exception e) {
			Log.error("Failed to click on PAP task " + e.getMessage());
			Assert.fail("Failed to click on PAP task " + e.getMessage());
		}
	}

	/**
	 * Function:enter Research Details
	 * 
	 * @author Trupti
	 **/
	public void enterResearchDetails(String alternateCoverage, String payername, String phone) {
		try {
			waitForPageLoaded();
			By alternateCoveragedropdownInputBox = getDynamicElement(strDropDownInputBox,
					"Alternate Coverage Identified?");
			waitAndVerifyElement(alternateCoveragedropdownInputBox);
			clickByJavascript(alternateCoveragedropdownInputBox);
			By dropdownOptions = getDynamicElement(strDropDownOptions, "Alternate Coverage Identified?");
			waitAndVerifyElement(dropdownOptions);
			selectItemFromList(alternateCoveragedropdownInputBox, dropdownOptions, alternateCoverage,
					"Alternate Coverage Identified?");
			LoggingInfo("Selected Alternate Coverage Identified? as" + alternateCoverage);

			if (alternateCoverage.equals("Yes")) {
				LoggingInfo("Verify Payer name and payer phone fields are displayed");
				// Payer Name
				By payernameField = getDynamicElement(updatedInputBox, "* Payer Name");
				verifyAnyFieldIsEnabledOrDisabled(payernameField, "* Payer Name", true);
				setTimeOut(2000);

				// Payer Phone
				By payePhoneField = getDynamicElement(strInputBox, "Payer Phone");
				verifyAnyFieldIsEnabledOrDisabled(payePhoneField, "Payer Phone", true);
				setTimeOut(2000);
				inputText(payernameField, payername);

				// Enter Payer Phone
				click(payePhoneField);
				WebElement element = getWebDriver().findElement(payePhoneField);
				JavascriptExecutor js = (JavascriptExecutor) getWebDriver();
				String script = "arguments[0].value = arguments[1];"
						+ "arguments[0].dispatchEvent(new Event('input', { bubbles: true }));"
						+ "arguments[0].dispatchEvent(new Event('change', { bubbles: true }));";
				js.executeScript(script, element, phone);
				// sendKeysWithRobotClass(phone);
				LoggingInfo("Entered payer phone");
				setTimeOut(3000);

				// Select payer name
				clickByJavascript(eleSearchButton);
				setTimeOut(2000);
				click(eleSearchButton);
				By payerRadiobutton = getDynamicElement(icareplusRecordsRadioBox, payername);
				waitAndVerifyElement(payerRadiobutton);
				scrollToElement(payerRadiobutton);
				clickByJavascript(payerRadiobutton);
				setTimeOut(2000);

				LoggingInfo("Selected Payer name");
			}
		} catch (Exception e) {
			Log.error("Failed to enter research details " + e.getMessage());
			Assert.fail("Failed to enter research details " + e.getMessage());
		}
	}

	/**
	 * Function:enter Communicate Results Details
	 * 
	 * @author Trupti
	 **/
	public void enterCommunicateResultsDetails(ArrayList<String> expectedValues, String attemptOutcome2,
			String attemptOutcome3) {

		String[] dropdownLabels = { "Status", "Patient Contact Made?", "Attempts Made to Patient",
				"Attempt 1 Outcome" };

		try {
			for (int i = 0; i < dropdownLabels.length; i++) {
				By dropdownLocator = getDynamicElement(strDropDownInputBox, dropdownLabels[i]);
				waitAndVerifyElement(dropdownLocator);
				scrollToElement(dropdownLocator);
				click(dropdownLocator);
				By dropdownOptions = getDynamicElement(strDropDownOptions, dropdownLabels[i]);
				waitAndVerifyElement(dropdownOptions);
				selectItemFromList(dropdownLocator, dropdownOptions, expectedValues.get(i), dropdownLabels[i]);
				LoggingInfo("Selected " + dropdownLabels[i] + "as-" + expectedValues.get(i));
			}

			// Attempt 1
			By attemptoneField = getDynamicElement(strInputBox, "Attempt 1");
			waitAndVerifyElement(attemptoneField);
			inputText(attemptoneField, "VC-");
			setTimeOut(2000);
			Actions action = new Actions(getWebDriver());
			action.sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();

			// Check attempt date is populated

			// Attempt 2
			By attempttwoField = getDynamicElement(strInputBox, "Attempt 2");
			waitAndVerifyElement(attempttwoField);
			inputText(attempttwoField, "VC-");
			setTimeOut(2000);
			action.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();

			// select Attempt 2 outcome
			By attempttwodropdownInputBox = getDynamicElement(strDropDownInputBox, "Attempt 2 Outcome");
			waitAndVerifyElement(attempttwodropdownInputBox);
			clickByJavascript(attempttwodropdownInputBox);
			By attemptoutcomedropdownOptions = getDynamicElement(strDropDownOptions, "Attempt 2 Outcome");
			waitAndVerifyElement(attemptoutcomedropdownOptions);
			selectItemFromList(attempttwodropdownInputBox, attemptoutcomedropdownOptions, attemptOutcome3,
					"Attempt 2 Outcome");

			if (attemptOutcome3.equalsIgnoreCase("No Contact Made")) {
				// Attempt 3
				By attemptthreeField = getDynamicElement(strInputBox, "Attempt 3");
				waitAndVerifyElement(attemptthreeField);
				inputText(attemptthreeField, "VC-");
				setTimeOut(2000);
				action.sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build()
						.perform();

				// select Attempt 3 outcome
				By attemptthreedropdownInputBox = getDynamicElement(strDropDownInputBox, "Attempt 3 Outcome");
				waitAndVerifyElement(attemptthreedropdownInputBox);
				scrollToElement(attemptthreedropdownInputBox);
				click(attemptthreedropdownInputBox);
				By attemptoutcome3dropdownOptions = getDynamicElement(strDropDownOptions, "Attempt 3 Outcome");
				waitAndVerifyElement(attemptoutcome3dropdownOptions);
				selectItemFromList(attemptthreedropdownInputBox, attemptoutcome3dropdownOptions, attemptOutcome3,
						"Attempt 3 Outcome");
			}
		} catch (Exception e) {
			Log.error("Failed to enter Communicate Results Details" + e.getMessage());
			Assert.fail("Failed to enter Communicate Results Details " + e.getMessage());
		}

	}

	/**
	 * Function:validate Alternate Research Is Disable
	 * 
	 * @author Trupti
	 **/
	public void validateEligibiltyIsDisable(boolean section) {

		try {
			LoggingInfo("'Eligibility Outcome' field is disable");
			By fieldLocator = getDynamicElement(strInputField, "Eligibility Outcome");
			verifyFieldIsEnabledOrDisabled(fieldLocator, "Eligibility Outcome", section);
			setTimeOut(2000);

			By bvOutcomeinputBox = getDynamicElement(strInputField, "Eligibility Outcome");
			waitAndVerifyElement(bvOutcomeinputBox);
			String outcomevalue = getAttributeValue(bvOutcomeinputBox, "value");
			Assert.assertEquals(outcomevalue, "Eligible", "Verified details for : " + "Eligibilty");
		} catch (Exception e) {
			Log.error("Failed to validate Alternate Research Required? Field " + e.getMessage());
			Assert.fail("Failed to validate Alternate Research Required? Field " + e.getMessage());
		}
	}

	/**
	 * Function:enter Coverage Outcome
	 * 
	 * @author Trupti
	 **/
	public void enterCoverageOutcome(String outcome) {
		try {
//			scrollToTopOfPage();
//			waitForPageLoaded();
//			By outcomedropdownInputBox = getDynamicElement(strDropDownInputBox, "Outcome");
//			waitAndVerifyElement(outcomedropdownInputBox);
//			scrollToElement(outcomedropdownInputBox);
//			click(outcomedropdownInputBox);
//			By outcomedropdownOptions = getDynamicElement(strDropDownOptions2, "Outcome");
//			waitAndVerifyElement(outcomedropdownOptions);
//			selectItemFromList(outcomedropdownInputBox, outcomedropdownOptions, outcome, "Outcome");
			
			By eleOutcomedropdown = getDynamicElement(strDropDownInputBox, "Outcome");
			waitAndVerifyElement(eleOutcomedropdown);
			scrollToElement(eleOutcomedropdown);
			click(eleOutcomedropdown);

			By eleOutcomeOption = getDynamicElement(outcomeDropOption, outcome);
			waitAndVerifyElement(eleOutcomeOption);
			click(eleOutcomeOption);
			LoggingInfo("Selected outcome as-" + outcome);

			
		} catch (Exception e) {
			Log.error("Failed to enter Coverage Outcome" + e.getMessage());
			Assert.fail("Failed to enter Coverage Outcome " + e.getMessage());
		}
	}

	// Anand P
	public void validatePlantype(String expectedOutcome) {
		try {
			LoggingInfo("Verify PAP Plan Type ");
			setTimeOut(2000);
			By outcome = getDynamicElement(strAccountObjectDetails, "Plan Type");
			waitAndVerifyElement(outcome);
			scrollToElement(outcome);
			verifyDetails(outcome, expectedOutcome, "Plan Type");
			LoggingInfo("plan type Verified Successfully ");

		} catch (Exception e) {
			Log.error("Failed to verify PAP outcome " + e.getMessage());
			Assert.fail("Failed to verify PAP outcome " + e.getMessage());
		}
	}

	/**
	 * Function:enter Coverage Outcome reason
	 * 
	 * @author Anand P
	 **/
	public void enterCoverageOutcomeReason(String outcome) {
		try {
			By outcomedropdownInputBox = getDynamicElement(strDropDownInputBox, "Outcome Reason");
			waitAndVerifyElement(outcomedropdownInputBox);
			click(outcomedropdownInputBox);
			By outcomedropdownOptions = getDynamicElement(strDropDownOptions2, "Outcome Reason");
			waitAndVerifyElement(outcomedropdownOptions);
			selectItemFromList(outcomedropdownInputBox, outcomedropdownOptions, outcome, "Outcome Reason");
		} catch (Exception e) {
			Log.error("Failed to enter Coverage Outcome reason" + e.getMessage());
			Assert.fail("Failed to enter Coverage Outcome reason " + e.getMessage());
		}
	}

	/**
	 * Function:check CPE Work Order Data
	 * 
	 * @author Trupti
	 **/

	public void checkCPEWorkOrderData(String careProduct, String patientName) {
		careProduct = careProduct.split(" -")[0];
		By tableRows = By.xpath(
				"//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-border_left\")]//div[contains(@class,\"data-table-row tableRow\")]");

		ArrayList<String> allData = getWorkTableData(tableRows, "CareProgrameeEnrolleeName", "Name", "Status",
				"Outcome", "Outcome Reason");
		logData("Actual Data:", allData);

		ArrayList<String> expectedData = new ArrayList<>();
		expectedData.add(patientName + " - " + careProduct + ", " + "PAP" + ", " + "Completed" + ", " + "Withdrawn"
				+ ", " + "Alternate coverage approved");
		logData("expecetd Data:", expectedData);
		boolean allExpectedFound = true;
		for (String expected : expectedData) {
			if (!allData.contains(expected)) {
				allExpectedFound = false;
				break;
			}
		}
		if (!allExpectedFound) {
			throw new AssertionError("Not all expected data is present in allData.");
		}
	}

	/**
	 * Function:Verify attempt date is not null
	 * 
	 * @author Trupti
	 **/

	public void verifyAttemptDateIsNotNull() {
		try {

			List<WebElement> elements = getWebDriver().findElements(eleAttemptDate);
			if (elements.isEmpty()) {
				Assert.fail("Attempt date elements are not present");
			}
			for (WebElement element : elements) {
				String values = element.getAttribute("value");
				Assert.assertNotNull(values, "Element's value should not be null.");
				// Assert.assertFalse(value.trim().isEmpty(), "Element's value should not be
				// empty.");
			}
		} catch (Exception e) {
			Log.error("Failed to verify attempt date " + e.getMessage());
			Assert.fail("Failed to verify attempt date " + e.getMessage());
		}
	}

	/**
	 * Function: Enter Eligibility Check
	 * 
	 * @author Anand P
	 **/
	public void enterEligibilityCheck(String option) {
		try {

			String[] dropdownLabels = { "Uninsured or functionally uninsured situation:", "Patient resides in US/PR?",
					"HCP in US/PR?", "FDA approved indication?", "Patient is not in-patient?" };
			for (String dropdownLabel : dropdownLabels) {
				By dropdownInputBox = getDynamicElement(strDropDownInputBox, dropdownLabel);
				waitAndVerifyElement(dropdownInputBox);
				scrollToElement(dropdownInputBox);
				clickByJavascript(dropdownInputBox);
				By dropdownOptions = getDynamicElement(strDropDownOptions, dropdownLabel);
				waitAndVerifyElement(dropdownOptions);
				selectItemFromList(dropdownInputBox, dropdownOptions, option, dropdownLabel);
				LoggingInfo("Selected " + dropdownLabel + " as-" + option);
				setTimeOut(1000);
			}

			By eleFPL = getDynamicElement(strDropDownInputBox, "Adjusted FPL %");
			waitAndVerifyElement(eleFPL);
			scrollToElement(eleFPL);
			inputText(eleFPL, "50");
			setTimeOut(1000);

			By inputBox = getDynamicElement(strInputBox, "BV Outcome");
			waitAndVerifyElement(inputBox);
			String value = getAttributeValue(inputBox, "value");
			if (value.equalsIgnoreCase(coverageSituation.get(2)) || value.equalsIgnoreCase(coverageSituation.get(3))) {

				By dropdownInputBox = getDynamicElement(strDropDownInputBox, "LIS");
				waitAndVerifyElement(dropdownInputBox);
				scrollToElement(dropdownInputBox);
				clickByJavascript(dropdownInputBox);
				By dropdownOptions = getDynamicElement(strDropDownOptions, "LIS");
				waitAndVerifyElement(dropdownOptions);
				selectItemFromList(dropdownInputBox, dropdownOptions, "Eligibile", "LIS");
				LoggingInfo("Selected LIS  as Eligibile");

			}

		} catch (Exception e) {
			Log.error("Failed to enter Eligibility Check " + e.getMessage());
			Assert.fail("Failed to enter Eligibility Check " + e.getMessage());
		}
	}

	/**
	 * Function: Validate enrollment start end date
	 * 
	 * @author Anand P
	 **/

	public void validateEnrollmenetStartEndDate() {
		try {
			LoggingInfo("Verify Enrollment start Date");
			setTimeOut(2000);
			By startDate = getDynamicElement(strAccountObjectDetails, "Enrollment Start Date");
			waitAndVerifyElement(startDate);
			String expectedStartDate = getDateNDaysFromToday(0);
			verifyDetails(startDate, expectedStartDate, "Enrollment Start Date");

			LoggingInfo("Verify Enrollment End Date");
			setTimeOut(2000);
			By endDate = getDynamicElement(strAccountObjectDetails, "Enrollment End Date");
			waitAndVerifyElement(endDate);
			String expectedEndDate = getDateNDaysFromToday(365);
			verifyDetails(endDate, expectedEndDate, "Enrollment End Date");
		} catch (Exception e) {
			Log.error("Failed to validate enrollmenet record  " + e.getMessage());
			Assert.fail("Failed to validate enrollmenet record  " + e.getMessage());
		}
	}

	// Anand P
	public void validatePAPOutcomeStatus() {
		try {
			LoggingInfo("Verify PAP Outcome ");
			setTimeOut(2000);
			By outcome = getDynamicElement(strAccountObjectDetails, "Outcome");
			waitAndVerifyElement(outcome);
			String expectedOutcome = "Renewed";
			verifyDetails(outcome, expectedOutcome, "Enrollment Start Date");
			LoggingInfo(" PAP Outcome Verified Successfully ");

		} catch (Exception e) {
			Log.error("Failed to verify PAP outcome " + e.getMessage());
			Assert.fail("Failed to verify PAP outcome " + e.getMessage());
		}
	}

	// Anand P
	public void checkPAPCompletion() {
		try {
			By status = By.xpath("//p[text()=\"PAP\"]//parent::div//preceding-sibling::div//span[text()=\"Complete\"]");
			waitAndVerifyElement(status);
			LoggingInfo("PAP completed successfully");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("PAP status is not completed  " + e.getMessage());
			Assert.fail("PAP status is not completed  " + e.getMessage());

		}
	}

	/**
	 * Function:check CPE Work Order Data
	 * 
	 * @author Trupti
	 **/

	public void checkCPEWorkOrderWithOutcome(String careProduct, String patientName, String outcome,
			String outcomeReason, String workorder, String status) {
		careProduct = careProduct.split(" -")[0];
		By tableRows = By.xpath(
				"//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-border_left\")]//div[@class=\"data-table-row tableRow\"]");

		ArrayList<String> allData = getWorkTableData(tableRows, "CareProgrameeEnrolleeName", "Name", "Status",
				"Outcome", "Outcome Reason");
		logData("Actual Data:", allData);

		ArrayList<String> expectedData = new ArrayList<>();
		expectedData.add(patientName + " - " + careProduct + ", " + workorder + ", " + status + ", " + outcome + ", "
				+ outcomeReason);
		logData("expecetd Data:", expectedData);
		boolean allExpectedFound = true;
		for (String expected : expectedData) {
			if (!allData.contains(expected)) {
				allExpectedFound = false;
				break;
			}
		}
		if (!allExpectedFound) {
			throw new AssertionError("Not all expected data is present in allData.");
		}
	}

	/**
	 * Function: Enter Eligibility Check
	 * 
	 * @author Anand P
	 **/
	public void enterEligibilityCheckEligibileforLIS(String option) {
		try {

			String[] dropdownLabels = { "Uninsured or functionally uninsured situation:", "Patient resides in US/PR?",
					"HCP in US/PR?", "FDA approved indication?", "Patient is not in-patient?" };
			for (String dropdownLabel : dropdownLabels) {
				By dropdownInputBox = getDynamicElement(strDropDownInputBox, dropdownLabel);
				waitAndVerifyElement(dropdownInputBox);
				scrollToElement(dropdownInputBox);
				clickByJavascript(dropdownInputBox);
				By dropdownOptions = getDynamicElement(strDropDownOptions, dropdownLabel);
				waitAndVerifyElement(dropdownOptions);
				selectItemFromList(dropdownInputBox, dropdownOptions, option, dropdownLabel);
				LoggingInfo("Selected " + dropdownLabel + " as-" + option);
				setTimeOut(1000);
			}

			By eleFPL = getDynamicElement(strDropDownInputBox, "Adjusted FPL %");
			waitAndVerifyElement(eleFPL);
			scrollToElement(eleFPL);
			inputText(eleFPL, "189");
			setTimeOut(1000);

			By eleMP3 = By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//span[text()='M3P and Deductible Not Met']//parent::label//parent::div//following-sibling::div//input");
			clickByJavascript(eleMP3);
			setTimeOut(1000);
			By dropdownOptions = getDynamicElement(strDropDownOptions, "M3P and Deductible Not Met");
			waitAndVerifyElement(dropdownOptions);
			selectItemFromList(eleMP3, dropdownOptions, "Yes", "M3P and Deductible Not Met");

		} catch (Exception e) {
			Log.error("Failed to enter Eligibility Check " + e.getMessage());
			Assert.fail("Failed to enter Eligibility Check " + e.getMessage());
		}
	}

	/**
	 * Function: Validate patient information details
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyPatientInfoDetails(ArrayList<String> expectedValues) {

		try {

			// "BV Outcome"
			By bvOutcomeinputBox = getDynamicElement(strInputBox, "BV Outcome");
			waitAndVerifyElement(bvOutcomeinputBox);
			String outcomevalue = getAttributeValue(bvOutcomeinputBox, "value");
			Assert.assertEquals(outcomevalue, expectedValues.get(0),
					"Failed to verify pre check details for : " + "BV Outcome");

			// Annual adjusted household income % of FPL
			By fPLinputBox = getDynamicElement(strInputBox, "Annual adjusted household income % of FPL");
			waitAndVerifyElement(fPLinputBox);
			String fplvalue = getAttributeValue(fPLinputBox, "value");
			if (!fplvalue.equals("0") && fplvalue != null && !fplvalue.isEmpty()) {
				Assert.fail("Expected value for " + "Annual adjusted household income % of FPL"
						+ " to be either '0' or 'null', but got: " + fplvalue);
			}

			// Plan Type
			By planinputBox = getDynamicElement(strInputBox, "Plan Type");
			waitAndVerifyElement(planinputBox);
			String planvalue = getAttributeValue(planinputBox, "value");
			Assert.assertEquals(planvalue, expectedValues.get(1), "Failed to verify details for : " + "Plan Type");

			// LIS Eligible
			if (fplvalue != null && !fplvalue.isEmpty()) {
				By lisEligibleBox = getDynamicElement(strInputBox, "LIS Eligible");
				String lisValue = getAttributeValue(lisEligibleBox, "value");
				Assert.assertEquals(lisValue, "Yes",
						"LIS Eligible should be 'Yes' when Annual adjusted household income % of FPL is populated");
				LoggingInfo(
						"Annual adjusted household income % of FPL is populated, LIS Eligible is as expected (Yes)");
			}

			// "Estimated Household Income"
			By incomeinputBox = getDynamicElement(strInputBox, "Estimated Household Income");
			waitAndVerifyElement(incomeinputBox);
			String incomevalue = getAttributeValue(incomeinputBox, "value");
			Assert.assertEquals(incomevalue, expectedValues.get(2),
					"Failed to verify details for : " + "Estimated Household Income");

			// "Estimated Household Size"
			By householdinputBox = getDynamicElement(strInputBox, "Estimated Household Size");
			waitAndVerifyElement(householdinputBox);
			String householdvalue = getAttributeValue(incomeinputBox, "value");
			Assert.assertEquals(householdvalue, expectedValues.get(2),
					"Failed to verify details for : " + "Estimated Household Size");

		} catch (Exception e) {
			Log.error("Failed to verify patient information: " + e.getMessage());
			Assert.fail("Failed to verify patient information: " + e.getMessage());
		}
	}

	/**
	 * Function: Validate enrollment start date
	 * 
	 * @author Trupti Zure
	 **/

	public void validateEnrollmenetStartDate(String expectedStartDate) {
		try {
			LoggingInfo("Verify Enrollment Start Date");
			setTimeOut(2000);
			By startDate = getDynamicElement(strAccountObjectDetails, "Enrollment Start Date");
			waitAndVerifyElement(startDate);
			verifyDetails(startDate, expectedStartDate, "Enrollment Start Date");
		} catch (Exception e) {
			Log.error("Failed to validate enrollmenet record  " + e.getMessage());
			Assert.fail("Failed to validate enrollmenet record  " + e.getMessage());
		}
	}

	/**
	 * Function: Validate enrollment end date
	 * 
	 * @author Trupti Zure
	 **/

	public void validateEnrollmenetEndDate(String expectedEndDate) {
		try {
			LoggingInfo("Verify Enrollment End Date");
			setTimeOut(2000);
			By endDate = getDynamicElement(strAccountObjectDetails, "Enrollment End Date");
			waitAndVerifyElement(endDate);
			verifyDetails(endDate, expectedEndDate, "Enrollment End Date");
		} catch (Exception e) {
			Log.error("Failed to validate enrollmenet record  " + e.getMessage());
			Assert.fail("Failed to validate enrollmenet record  " + e.getMessage());
		}
	}

	/**
	 * Function:Verify Information Fields are present
	 * 
	 * @author Trupti Zure
	 **/
	public void verifyInformationFieldsArePresent() {

		String[] inputLabels = { "Name", "Status", "Enrollment Type", "Enrollment Start Date", "Denial Start Date",
				"Patient has Medicare Part D?", "Care Program Enrollee", "Product", "Outcome", "Adjusted FPL %",
				"Enrollment End Date", "Early Renewal Date", "Action Required", "Care Program Product" };
		try {

			for (String inputLabel : inputLabels) {
				By fieldName = getDynamicElement(labelsField, inputLabel);
				scrollToElement(fieldName);
				boolean found = isElementPresent(fieldName);
				Assert.assertTrue(found);
				LoggingInfo("Field is present on layout- " + inputLabel);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Field " + e.getMessage());
			Assert.fail("Failed to verify Field " + e.getMessage());
		}
	}

	/**
	 * Function:Verify System Information Fields are present
	 * 
	 * @author Trupti Zure
	 **/

	public void verifySysInformationFieldsArePresent() {

		String[] inputLabels = { "Created By", "Source System", "Last Modified By" };
		try {

			for (String inputLabel : inputLabels) {
				By fieldName = getDynamicElement(labelsField, inputLabel);
				scrollToElement(fieldName);
				boolean found = isElementPresent(fieldName);
				Assert.assertTrue(found);
				LoggingInfo("Field is present on layout- " + inputLabel);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Field " + e.getMessage());
			Assert.fail("Failed to verify Field " + e.getMessage());
		}
	}

	public void verifyCPEWorkOrderData(String careProduct, String patientName) {
		careProduct = careProduct.split(" -")[0];
		By tableRows = By.xpath(
				"//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-border_left\")]//div[@class=\"slds-data-table-row tableRow\"]");

		ArrayList<String> allData = getWorkTableData(tableRows, "CareProgrameeEnrolleeName", "Name", "Status",
				"Outcome", "Outcome Reason");
		logData("Actual Data:", allData);

		ArrayList<String> expectedData = new ArrayList<>();
		expectedData.add(patientName + " - " + careProduct + ", " + "PAP" + ", " + "Completed" + ", " + "Withdrawn"
				+ ", " + "Alternate coverage approved");
		logData("expecetd Data:", expectedData);
		boolean allExpectedFound = true;
		for (String expected : expectedData) {
			if (!allData.contains(expected)) {
				allExpectedFound = false;
				break;
			}
		}
		if (!allExpectedFound) {
			throw new AssertionError("Not all expected data is present in allData.");
		}
	}

	public void verifyResearchTask() {
		try {
			By subTaskName = getDynamicElement(strSubtaskName, "Research");
			waitAndVerifyElement(subTaskName);
			LoggingInfo("Pre-Check sub task has been initialized");
			setTimeOut(2000);

			By subTaskStatus = getDynamicElement(strSubTaskStatus, "Research");
			waitAndVerifyElement(subTaskStatus);
			String status = getText(subTaskStatus);
			// Assert the status of subtask
			Assert.assertEquals(status, "Not Started", "Research task status verified");
		} catch (Exception e) {
			e.printStackTrace();
			Log.error("PAP subtask Research has not been initiated " + e.getMessage());
			Assert.fail("PAP subtask Research has not been initiated " + e.getMessage());
		}

	}

	public void checkCPEWorkOrderWithWithdraw(String careProduct, String patientName, String outcome,
			String outcomeReason, String workorder, String status) {
		careProduct = careProduct.split(" -")[0];
		By tableRows = By.xpath(
				"//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-border_left\")]//div[@class=\"slds-data-table-row tableRow\"]");

		ArrayList<String> allData = getWorkTableData(tableRows, "CareProgrameeEnrolleeName", "Name", "Status",
				"Outcome", "Outcome Reason");
		logData("Actual Data:", allData);

		ArrayList<String> expectedData = new ArrayList<>();
		expectedData.add(patientName + " - " + careProduct + ", " + workorder + ", " + status + ", " + outcome + ", "
				+ outcomeReason);
		logData("expecetd Data:", expectedData);
		boolean allExpectedFound = true;
		for (String expected : expectedData) {
			if (!allData.contains(expected)) {
				allExpectedFound = false;
				break;
			}
		}
		if (!allExpectedFound) {
			throw new AssertionError("Not all expected data is present in allData.");
		}
	}

	public void verifyAttemptIsNotNull() {
		try {

			List<WebElement> elements = getWebDriver().findElements(eleAttemptDate);
			if (elements.isEmpty()) {
				Assert.fail("Attempt date elements are not present");
			}
			for (WebElement element : elements) {
				String value = element.getAttribute("value");
				Assert.assertNotNull(value, "Element's value should not be null.");
				// Assert.assertFalse(value.trim().isEmpty(), "Element's value should not be
				// empty.");
			}
		} catch (Exception e) {
			Log.error("Failed to verify attempt date " + e.getMessage());
			Assert.fail("Failed to verify attempt date " + e.getMessage());
		}
	}

	public void clickOnStartNewService() {
		try {

			waitAndVerifyElement(eleStartNewServiceButton);
			scrollToElement(eleStartNewServiceButton);
			waitForvisiblityOfElementLocated(eleStartNewServiceButton);
			click(eleStartNewServiceButton);
			LoggingInfo("Clicked on 'Start New Service Button'");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click On Start New Service " + e.getMessage());
			Assert.fail("Failed to click On Start New Service " + e.getMessage());
		}
	}

	public void enterAlternateCoverageSituation(String situation) {
		try {
			By coverageSituationdropdownInputBox = getDynamicElement(strDropDownInputBox,
					"Alternate Coverage Identified?");
			waitAndVerifyElement(coverageSituationdropdownInputBox);
			scrollToElement(coverageSituationdropdownInputBox);
			click(coverageSituationdropdownInputBox);
			By dropdownOptions = getDynamicElement(strDropDownOptions, "Alternate Coverage Identified?");
			waitAndVerifyElement(dropdownOptions);
			selectItemFromList(coverageSituationdropdownInputBox, dropdownOptions, situation,
					"Alternate Coverage Identified?");

		} catch (Exception e) {
			Log.error("Failed to enter Coverage Situation Field " + e.getMessage());
			Assert.fail("Failed to enter Coverage Situation Field " + e.getMessage());
		}
	}

	public void enterOutcome(String situation) {
		try {
			By eleOutcomedropdown = getDynamicElement(strDropDownInputBox, "Outcome");
			waitAndVerifyElement(eleOutcomedropdown);
			scrollToElement(eleOutcomedropdown);
			click(eleOutcomedropdown);

			By eleOutcomeOption = getDynamicElement(outcomeDropOption, situation);
			waitAndVerifyElement(eleOutcomeOption);
			click(eleOutcomeOption);
			LoggingInfo("Selected outcome as-" + situation);

		} catch (Exception e) {
			Log.error("Failed to enter Coverage Situation Field " + e.getMessage());
			Assert.fail("Failed to enter Coverage Situation Field " + e.getMessage());
		}
	}

	public void enterCoverageSituationAndValidateNoneoptionisAbsent(String situation) {
		try {
			By coverageSituationDropdownInputBox = getDynamicElement(strDropDownInputBox, "Coverage Situation");
			waitAndVerifyElement(coverageSituationDropdownInputBox);
			scrollToElement(coverageSituationDropdownInputBox);
			click(coverageSituationDropdownInputBox);

			setTimeOut(2000);
			List<WebElement> noneOptions = getWebDriver().findElements(By.xpath(
					"//*[contains(@class,\"active lafPageHost\")]//*[contains(@class,\"slds-combobox\")]//*[text()=\"Coverage Situation\"]//parent::label//parent::div//following-sibling::div//li//span[contains(@class,\"option-text\") and normalize-space(text())=\"None\"]"));

			if (!noneOptions.isEmpty() && noneOptions.get(0).isDisplayed()) {
				Assert.fail("\"None\" option should NOT be present in the Coverage Situation dropdown");
			}

			By dropdownOptions = getDynamicElement(strDropDownOptions, "Coverage Situation");
			waitAndVerifyElement(dropdownOptions);
			selectItemFromList(coverageSituationDropdownInputBox, dropdownOptions, situation, "Coverage Situation");

		} catch (Exception e) {
			Log.error("Failed to enter Coverage Situation Field: " + e.getMessage());
			Assert.fail("Failed to enter Coverage Situation Field: " + e.getMessage());
		}
	}

	public void clickOnPAPCpe() {
		try {
			By papCpe = By
					.xpath("//*[contains(@class, \"active lafPageHost\")]//*[contains(text(), \"PAP\")]//ancestor::a");
			waitAndVerifyElement(papCpe);
			scrollToElement(papCpe);
			clickByJavascript(papCpe);
		} catch (Exception e) {
			Log.error("Failed to click on PAP CPE task: " + e.getMessage());
			Assert.fail("Failed to click on PAP CPE task: " + e.getMessage());
		}
	}

	public void verifyStartEndDateNotEditable() {
		try {
			setTimeOut(2000);
			WebElement section1 = getWebDriver().findElement(By.xpath(
					"//*[contains(@class, \"active lafPageHost\")]//button[.//span[contains(text(), \"Edit Enrollment Start Date\")]]"));
			Assert.assertFalse(section1.isDisplayed(), "Enrollment Start Date section should not be editable");
			setTimeOut(2000);
			WebElement section2 = getWebDriver().findElement(By.xpath(
					"//*[contains(@class, \"active lafPageHost\")]//button[.//span[contains(text(), \"Edit Enrollment End Date\")]]"));
			Assert.assertFalse(section2.isDisplayed(), "Enrollment End Date section should not be editable");

		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println(
					"Both Caregiver Information and Office Contact Information is not present on the page, as expected.");
			LoggingInfo("Validated Caregiver Information and Office contact Information not visible as expected");
		}

	}

	public void validateMedicarePartDisNo(String caseType) {
		try {

			By recordtype = getDynamicElement(strAccountObjectDetails, "Patient has Medicare Part D?");
			waitAndVerifyElement(recordtype);
			scrollToElement(recordtype);
			String actualText = getText(recordtype);

			if (actualText.contains(caseType)) {
				Log.info(
						"Validation Passed: The Patient has Medicare Part D? type has the expected value: " + caseType);
			} else {
				Log.error(
						"Validation Failed:The Patient has Medicare Part D? type does not has the expected value: Expected: "
								+ caseType + " but found: " + actualText);
				Assert.fail("The expected case type '" + caseType + "' was not found in the record type. Found: "
						+ actualText);
			}

		} catch (Exception e) {
			Log.error("An error occurred: " + e.getMessage());
			Assert.fail("An error occurred during validation: " + e.getMessage());
		}
	}

	public void OrderDetails() {
		try {
			waitAndVerifyElement(select);

			click(select);

			waitAndVerifyElement(attachments);

			click(attachments);

		} catch (Exception e) {
			Log.error("Failed to click on PAP task " + e.getMessage());
			Assert.fail("Failed to click on PAP task " + e.getMessage());

		}

	}

	public void validateIAPCPEPfield() {
		try {
			By cpepField = getDynamicElement(correspondenceInputField, "Care Program Enrollee Product");
			waitAndVerifyElement(cpepField);
			scrollToElement(cpepField);
			Log.info("CPEP field is present and visible.");

			By iapStartSpan = By
					.xpath("(//*[contains(@class,'active lafPageHost')]//span[contains(text(), 'IAP -')])[1]");
			waitAndVerifyElement(iapStartSpan);

			Log.info("IAP span element is present and visible.");

			By closeButton = By.xpath("(//button[contains(@title, 'Close') and contains(@title, 'Order')])[2]");
			waitAndVerifyElement(closeButton);
			scrollToElement(closeButton);
			getWebDriver().findElement(closeButton).click();
			Log.info("Clicked the Close button.");

		} catch (Exception e) {
			Log.error("Failed to verify CPEP field: " + e.getMessage());
			Assert.fail("Failed to verify CPEP field: " + e.getMessage());
		}
	}

	public void validatePAPCPEPfield() {
		try {

			By cpepField = getDynamicElement(correspondenceInputField, "Care Program Enrollee Product");
			waitAndVerifyElement(cpepField);
			scrollToElement(cpepField);
			Log.info("CPEP field is present and visible.");

			By quickStartSpan = By
					.xpath("(//*[contains(@class,'active lafPageHost')]//span[contains(text(), 'PAP -')])[1]");
			waitAndVerifyElement(quickStartSpan);

			Log.info("PAP span element is present and visible.");

			By closeButton = By.xpath("(//button[contains(@title, 'Close') and contains(@title, 'Order')])[2]");
			waitAndVerifyElement(closeButton);
			scrollToElement(closeButton);
			getWebDriver().findElement(closeButton).click();
			Log.info("Clicked the Close button.");

		} catch (Exception e) {
			Log.error("Failed during QuickStart CPEP field validation: " + e.getMessage());
			Assert.fail("Failed during QuickStart CPEP field validation: " + e.getMessage());
		}
	}

	public void validateQuickStartCPEPfield() {
		try {

			By cpepField = getDynamicElement(correspondenceInputField, "Care Program Enrollee Product");
			waitAndVerifyElement(cpepField);
			scrollToElement(cpepField);
			highLightElement(cpepField);
			Log.info("CPEP field is present and visible.");

			By quickStartSpan = By
					.xpath("(//*[contains(@class,'active lafPageHost')]//span[contains(text(), 'QuickStart -')])[1]");
			waitAndVerifyElement(quickStartSpan);
			highLightElement(quickStartSpan);
			Log.info("QuickStart span element is present and visible.");

			By closeButton = By.xpath("(//button[contains(@title, 'Close') and contains(@title, 'Order')])[2]");
			waitAndVerifyElement(closeButton);
			scrollToElement(closeButton);
			getWebDriver().findElement(closeButton).click();
			Log.info("Clicked the Close button.");

		} catch (Exception e) {
			Log.error("Failed during QuickStart CPEP field validation: " + e.getMessage());
			Assert.fail("Failed during QuickStart CPEP field validation: " + e.getMessage());
		}
	}

	public void clickOnOrder() {
		try {

			waitAndVerifyElement(order);

			clickByJavascript(order);
			LoggingInfo("Clicked on 'Start New Service Button'");
			setTimeOut(2000);
		} catch (Exception e) {
			Log.error("Failed to click On Start New Service " + e.getMessage());
			Assert.fail("Failed to click On Start New Service " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Outcome Picklist Value Elgibility task
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateOutcomePicklistValue(String outcome) {
		try {
			boolean isTextFound = false;
			scrollToTopOfPage();
			waitForPageLoaded();
			By outcomedropdownInputBox = getDynamicElement(strDropDownInputBox, "Outcome");
			waitAndVerifyElement(outcomedropdownInputBox);
			scrollToElement(outcomedropdownInputBox);
			click(outcomedropdownInputBox);
			By outcomedropdownOptions = getDynamicElement(strDropDownOptions2, "Outcome");
			waitAndVerifyElement(outcomedropdownOptions);
			List<WebElement> options = getWebDriver().findElements(outcomedropdownOptions);
			for (WebElement option : options) {
				String text = option.getText();
				if (text.equalsIgnoreCase(outcome)) {
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].style.border='2px solid red'",
							option);
					LoggingInfo("Outcome is present in the list: " + outcome);
					isTextFound = true;
					click(outcomedropdownInputBox);
					break;

				}
			}
			if (!isTextFound) {
				Log.error(outcome + " value is not present in the picklist");
				Assert.fail(outcome + " value is not present in the picklist");
			}
		} catch (Exception e) {
			Log.error("Failed to enter Coverage Outcome" + e.getMessage());
			Assert.fail("Failed to enter Coverage Outcome " + e.getMessage());
		}
	}

	/**
	 * Function: Verify Outcome Field Value in PAP CPEP
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validatePAPoutcomeVal(String strOutcome) {
		try {
			LoggingInfo("Verify PAP Outcome ");
			setTimeOut(2000);
			By outcome = getDynamicElement(strAccountObjectDetails, "Outcome");
			scrollToElement(outcome);
			waitAndVerifyElement(outcome);
			verifyDetails(outcome, strOutcome, "Outcome");
			highLightElement(outcome);
			LoggingInfo(" PAP Outcome " + outcome + " Verified Successfully ");

		} catch (Exception e) {
			Log.error("Failed to verify PAP outcome " + e.getMessage());
			Assert.fail("Failed to verify PAP outcome " + e.getMessage());
		}
	}

	/**
	 * Function: Verify picklist values in CPEP(PAP)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validatePickListValues(String fieldname, String picklistVal) throws Exception {

		String strdropdownBtn = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::div//button";
		By dropdownBtn = getDynamicElement(strdropdownBtn, fieldname);
		waitAndVerifyElement(dropdownBtn);
		scrollToElement(dropdownBtn);
		click(dropdownBtn);
		boolean isTextfound = false;
		String strdropdownOptions = "//*[contains(@class,\"active lafPageHost\")]//*[text()=\"{0}\"]//parent::div//following-sibling::lightning-base-combobox-item//span[@class=\"slds-media__body\"]";
		By dropdownOptions = getDynamicElement(strdropdownOptions, fieldname);
		waitAndVerifyElement(dropdownOptions);
		List<WebElement> options = getWebDriver().findElements(dropdownOptions);
		for (WebElement option : options) {
			String text = option.getText();
			if (text.equalsIgnoreCase(picklistVal)) {
				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].style.border='2px solid red'",
						option);
				LoggingInfo(picklistVal + " value is present in the picklist");
				isTextfound = true;
				click(dropdownBtn);
				break;
			}
		}
		if (!isTextfound) {
			Log.error(picklistVal + " value is not present in the picklist");
			Assert.fail(picklistVal + " value is not present in the picklist");
		}

	}

	/**
	 * Function:validate that the Patient has Medicare Part D field is populated as
	 * Yes
	 * 
	 * @author Kavyashree
	 **/

	public void validatedPatientHasMedPartD() {

		try {
			setTimeOut(4000);
			waitAndVerifyElement(eleMedD);
			String value = getText(eleMedD);
			// Assert the status of subtask
			Assert.assertEquals(value, "Yes", "Medicare Part D field is populated as Yes");
			LoggingInfo("Medicare Part D field is populated as Yes");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Medicare Part D field is populated as Yes " + e.getMessage());
			Assert.fail("Failed to verify Medicare Part D field is populated as Yes " + e.getMessage());
		}
	}

	/**
	 * Function: Enter Eligibility Check
	 * 
	 * @author Kavyashree MB
	 **/
	public void verifyAndenterEligibilityCheck(String option) {
		try {

			String[] dropdownLabels = { "Uninsured or functionally uninsured situation:", "Patient resides in US/PR?",
					"HCP in US/PR?", "FDA approved indication?", "Patient is not in-patient?",
					"M3P and Deductible Not Met" };
			for (String dropdownLabel : dropdownLabels) {
				By dropdownInputBox = getDynamicElement(strDropDownInputBox, dropdownLabel);
				waitAndVerifyElement(dropdownInputBox);
				scrollToElement(dropdownInputBox);
				clickByJavascript(dropdownInputBox);
				By dropdownOptions = getDynamicElement(strDropDownOptions, dropdownLabel);
				waitAndVerifyElement(dropdownOptions);
				selectItemFromList(dropdownInputBox, dropdownOptions, option, dropdownLabel);
				LoggingInfo("Selected " + dropdownLabel + " as-" + option);
				setTimeOut(1000);
			}

			By eleFPL = getDynamicElement(strDropDownInputBox, "Adjusted FPL %");
			waitAndVerifyElement(eleFPL);
			scrollToElement(eleFPL);
			inputText(eleFPL, "50");
			setTimeOut(1000);

			String outcome = "Denied";

			By LISdropdownInputBox = getDynamicElement(strDropDownInputBox, "LIS");
			waitAndVerifyElement(LISdropdownInputBox);
			scrollToElement(LISdropdownInputBox);
			click(LISdropdownInputBox);
			By LISdropdownOptions = getDynamicElement(strDropDownOptions2, "LIS");
			waitAndVerifyElement(LISdropdownOptions);
			selectItemFromList(LISdropdownInputBox, LISdropdownOptions, outcome, "LIS");

		} catch (Exception e) {
			Log.error("Failed to enter Eligibility Check " + e.getMessage());
			Assert.fail("Failed to enter Eligibility Check " + e.getMessage());
		}
	}

	/**
	 * Function:Validate that the Enrollment Start Date and Enrollment End Date
	 * fields are Read only fields
	 * 
	 * @author Kavyashree
	 **/

	public void ValidateEnrollmentDateReadOnlyFields() {

		try {
			setTimeOut(3000);
			By eleStartDate = getDynamicElement(strReadOnlyFields, "Enrollment Start Date");
			waitAndVerifyElement(eleStartDate);
			scrollToElement(eleStartDate);
			Assert.assertTrue(getAttributeValue(eleStartDate, "class").contains("is-read-only"),
					"Field is  marked as read-only.");
			setTimeOut(2000);

			By eleEndDate = getDynamicElement(strReadOnlyFields, "Enrollment End Date");
			waitAndVerifyElement(eleEndDate);
			scrollToElement(eleEndDate);
			Assert.assertTrue(getAttributeValue(eleEndDate, "class").contains("is-read-only"),
					"Field is  marked as read-only.");
			setTimeOut(2000);
			LoggingInfo("Enrollment Start Date and Enrollment End Date fields are Read only fields");

		} catch (Exception e) {
			e.printStackTrace();
			Log.error("Failed to verify Enrollment Start Date and Enrollment End Date fields are Read only fields "
					+ e.getMessage());
			Assert.fail("Failed to verify Enrollment Start Date and Enrollment End Date fields are Read only fields "
					+ e.getMessage());
		}
	}

	/**
	 * Function: Click on refresh
	 * 
	 * @author Kavyashree MB
	 **/
	public void clickRefresh() {
		try {
			waitAndVerifyElement(eleRefresh);
			scrollToElement(eleRefresh);
			click(eleRefresh);
			setTimeOut(5000);
			LoggingInfo("clicked on refresh successfully");
		} catch (Exception e) {
			Log.error("Failed to click on refresh " + e.getMessage());
			Assert.fail("Failed to click on refresh " + e.getMessage());
		}
	}

	/**
	 * Function:Validate CPE Workorder outcome
	 * 
	 * @author Kavyashree
	 **/
	public void validateCPEWOOutcomeStatus(String expectedOutcome) {
		try {
			LoggingInfo("Verify PAP Outcome ");
			setTimeOut(2000);
			waitAndVerifyElement(eleOutcome);
			verifyDetails(eleOutcome, expectedOutcome, "Outcome");
			LoggingInfo(" PAP Outcome Verified Successfully ");

		} catch (Exception e) {
			Log.error("Failed to verify PAP outcome " + e.getMessage());
			Assert.fail("Failed to verify PAP outcome " + e.getMessage());
		}
	}

	/**
	 * Function:
	 * 
	 * @author Tejal
	 **/
	public void enterDetails(String status, String payerContact, String attempt, String att1, String attempt1,
			String att2, String attempt2, String att3, String attempt3) {
		try {

			// Status
			By elestatus = getDynamicElement(strDropDownInputBox, "Status");
			waitAndVerifyElement(elestatus);
			scrollToElement(elestatus);
			click(elestatus);
			By elestatusOptions = getDynamicElement(strDropDownOptions, "Status");
			waitAndVerifyElement(elestatusOptions);
			selectItemFromList(elestatus, elestatusOptions, status, "Status");
			setTimeOut(1000);

			// Payer Contact Successful?
			By elePayerContact = getDynamicElement(strDropDownInputBox, "Patient Contact Made?");
			waitAndVerifyElement(elePayerContact);
			scrollToElement(elePayerContact);
			click(elePayerContact);
			By elePayerContactOptions = getDynamicElement(strDropDownOptions, "Patient Contact Made?");
			waitAndVerifyElement(elePayerContactOptions);
			selectItemFromList(elePayerContact, elePayerContactOptions, payerContact, "Patient Contact Made?");
			setTimeOut(1000);

			By elePayerAttempts = getDynamicElement(strDropDownInputBox, "Attempts Made to Patient");
			waitAndVerifyElement(elePayerAttempts);
			scrollToElement(elePayerAttempts);
			click(elePayerAttempts);
			By elePayerAttempt = getDynamicElement(strDropDownOptions, "Attempts Made to Patient");
			waitAndVerifyElement(elePayerAttempt);
			selectItemFromList(elePayerAttempts, elePayerAttempt, attempt, "Attempts Made to Patient");
			setTimeOut(1000);

			By eleAtt1 = getDynamicElement(strInputBox, "Attempt 1");
			waitAndVerifyElement(eleAtt1);
			inputText(eleAtt1, att1);

			By elePayerAttempt1 = getDynamicElement(strDropDownInputBox, "Attempt 1 Outcome");
			waitAndVerifyElement(elePayerAttempt1);
			scrollToElement(elePayerAttempt1);
			click(elePayerAttempt1);
			By elePayerAttemptfirst = getDynamicElement(strDropDownOptions, "Attempt 1 Outcome");
			waitAndVerifyElement(elePayerAttemptfirst);
			selectItemFromList(elePayerAttempt1, elePayerAttemptfirst, attempt1, "Attempt 1 Outcome");
			setTimeOut(1000);

			By eleAtt2 = getDynamicElement(strInputBox, "Attempt 2");
			waitAndVerifyElement(eleAtt2);
			inputText(eleAtt2, att2);

			By elePayerAttempt2 = getDynamicElement(strDropDownInputBox, "Attempt 2 Outcome");
			waitAndVerifyElement(elePayerAttempt2);
			scrollToElement(elePayerAttempt2);
			click(elePayerAttempt2);
			By elePayerAttemptSecond = getDynamicElement(strDropDownOptions, "Attempt 2 Outcome");
			waitAndVerifyElement(elePayerAttemptSecond);
			selectItemFromList(elePayerAttempt2, elePayerAttemptSecond, attempt2, "Attempt 2 Outcome");
			setTimeOut(1000);

			By eleAtt3 = getDynamicElement(strInputBox, "Attempt 3");
			waitAndVerifyElement(eleAtt3);
			inputText(eleAtt3, att3);

			By elePayerAttempt3 = getDynamicElement(strDropDownInputBox, "Attempt 3 Outcome");
			waitAndVerifyElement(elePayerAttempt3);
			scrollToElement(elePayerAttempt3);
			click(elePayerAttempt3);
			By elePayerAttemptThird = getDynamicElement(strDropDownOptions, "Attempt 3 Outcome");
			waitAndVerifyElement(elePayerAttemptThird);
			selectItemFromList(elePayerAttempt3, elePayerAttemptThird, attempt3, "Attempt 3 Outcome");
			setTimeOut(1000);
		}

		catch (Exception e) {
			Log.error("Failed to enter details of HCP Follow up " + e.getMessage());
			Assert.fail("Failed to enter details of HCP Follow up " + e.getMessage());
		}

	}

	/**
	 * Function:PAP eligibility yes
	 * 
	 * @author Tejal
	 **/
	public void enterPAPEligibilityCheck() {
		try {

			String[] dropdownLabels = { "Uninsured or functionally uninsured situation:", "Patient resides in US/PR?",
					"HCP in US/PR?", "FDA approved indication?", "Patient is not in-patient?",
					"M3P and Deductible Not Met" };
			for (String dropdownLabel : dropdownLabels) {
				By dropdownInputBox = getDynamicElement(strDropDownInputBox, dropdownLabel);
				waitAndVerifyElement(dropdownInputBox);
				scrollToElement(dropdownInputBox);
				click(dropdownInputBox);
				String option = "Yes";
				By dropdownOptions = getDynamicElement(strDropDownOptions, dropdownLabel);
				waitAndVerifyElement(dropdownOptions);
				selectItemFromList(dropdownInputBox, dropdownOptions, option, dropdownLabel);
				LoggingInfo("Selected " + dropdownLabel + " as-" + option);
				setTimeOut(1000);
			}

			By eleFPL = getDynamicElement(strDropDownInputBox, "Adjusted FPL %");
			waitAndVerifyElement(eleFPL);
			scrollToElement(eleFPL);
			inputText(eleFPL, "9");
			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to enter Eligibility Check " + e.getMessage());
			Assert.fail("Failed to enter Eligibility Check " + e.getMessage());
		}
	}

	/**
	 * Function:PAP eligibility no
	 * 
	 * @author Tejal
	 **/
	public void enterPAPEligibilityCheckNo() {
		try {

			String[] dropdownLabels = { "Uninsured or functionally uninsured situation:", "Patient resides in US/PR?",
					"HCP in US/PR?", "FDA approved indication?", "Patient is not in-patient?" };
			for (String dropdownLabel : dropdownLabels) {
				By dropdownInputBox = getDynamicElement(strDropDownInputBox, dropdownLabel);
				waitAndVerifyElement(dropdownInputBox);
				scrollToElement(dropdownInputBox);
				click(dropdownInputBox);
				String option = "No";
				By dropdownOptions = getDynamicElement(strDropDownOptions, dropdownLabel);
				waitAndVerifyElement(dropdownOptions);
				selectItemFromList(dropdownInputBox, dropdownOptions, option, dropdownLabel);
				LoggingInfo("Selected " + dropdownLabel + " as-" + option);
				setTimeOut(1000);
			}

			By eleFPL = getDynamicElement(strDropDownInputBox, "Adjusted FPL %");
			waitAndVerifyElement(eleFPL);
			scrollToElement(eleFPL);
			inputText(eleFPL, "300");
			setTimeOut(1000);

		} catch (Exception e) {
			Log.error("Failed to enter Eligibility Check " + e.getMessage());
			Assert.fail("Failed to enter Eligibility Check " + e.getMessage());
		}
	}

	/**
	 * Function:check status and outcome of work order
	 * 
	 * @author Tejal
	 **/

	public void checkCPEWorkOrderData(List<String> workOrders, String status, String outcome) {

		By tableRows = By.xpath(
				"//*[contains(@class,\"active lafPageHost\")]//div[contains(@class,\"slds-border_left\")]//*[@class=\"slds-data-table-row tableRow\"]");

		ArrayList<String> allData = getWorkTableData(tableRows, "Name", "Status", "Outcome");
		logData("Actual Data:", allData);

		ArrayList<String> expectedData = new ArrayList<>();
		for (String workOrder : workOrders) {
			expectedData.add(workOrder + ", " + status + ", " + outcome);
		}
		logData("Expected Data:", expectedData);

		boolean allExpectedFound = true;
		for (String expected : expectedData) {
			if (!allData.contains(expected)) {
				allExpectedFound = false;
				Log.error("Expected data not found: " + expected);
				break;
			}
		}

		if (!allExpectedFound) {
			throw new AssertionError("Not all expected work orders with given status and outcome were found.");
		} else {
			LoggingInfo("Successfully verified work orders with Status = '" + status + "' and Outcome = '" + outcome
					+ "'.");
		}
	}

	/**
	 * Function: Validate enrollment end date of PAP
	 * 
	 * @author Kavyashree MB
	 **/

	public void verifyEnrollmenetEndDate(String expectedEndDate) {
		try {
			LoggingInfo("Verify Enrollment End Date");
			setTimeOut(2000);
			By endDate = getDynamicElement(strAccountObjectDetails, "Enrollment End Date");
			waitAndVerifyElement(endDate);
			verifyDetails(endDate, expectedEndDate, "Enrollment End Date");
		} catch (Exception e) {
			Log.error("Failed to validate enrollmenet record  " + e.getMessage());
			Assert.fail("Failed to validate enrollmenet record  " + e.getMessage());
		}
	}

	/**
	 * Function: Validate PAP Order
	 * 
	 * @author Kavyashree
	 **/

	public void VerifyPAPOrder() {
		try {
			setTimeOut(2000);
			waitAndVerifyElement(elePAPOrder);
			LoggingInfo("verified PAP order ");

		} catch (Exception e) {
			Log.error("Failed to verify PAP order " + e.getMessage());
			Assert.fail("Failed to verify PAP order  " + e.getMessage());
		}
	}

	/**
	 * Function:verifying start and end dates are editable
	 * 
	 * @author Tejal
	 **/
	public void verifyStartEndDateEditable() {
		try {

			WebElement section1 = getWebDriver().findElement(By.xpath(
					"//*[contains(@class, \"active lafPageHost\")]//button[.//*[contains(text(), \"Edit Enrollment Start Date\")]]"));
			Assert.assertTrue(section1.isDisplayed(), "Enrollment Start Date section should be editable");

			LoggingInfo("Enrollment Start Date edit button is present as expected.");

			WebElement section2 = getWebDriver().findElement(By.xpath(
					"//*[contains(@class, \"active lafPageHost\")]//*[.//span[contains(text(), \"Edit Enrollment End Date\")]]"));
			Assert.assertTrue(section2.isDisplayed(), "Enrollment End Date section should be editable");
			LoggingInfo("Enrollment End Date edit button is present as expected.");

		} catch (Exception e) {

			Assert.fail("Expected editable Start/End Date button is NOT present: " + e.getMessage());
		}
	}

	// author Tejal
	public void enterLISinfo(String option) throws Exception {
		By dropdownInputBox = getDynamicElement(strDropDownInputBox, "LIS");
		waitAndVerifyElement(dropdownInputBox);
		scrollToElement(dropdownInputBox);
		clickByJavascript(dropdownInputBox);
		By dropdownOptions = getDynamicElement(strDropDownOptions, "LIS");
		waitAndVerifyElement(dropdownOptions);
		selectItemFromList(dropdownInputBox, dropdownOptions, option, "LIS");
		LoggingInfo("Selected " + "LIS" + " as-" + option);
		setTimeOut(1000);
	}

	// author Tejal
	public void enterCaptureCoverageOutcome(String situation) {
		try {
			By coverageSituationdropdownInputBox = getDynamicElement(strDropDownInputBox, "Outcome");
			waitAndVerifyElement(coverageSituationdropdownInputBox);
			scrollToElement(coverageSituationdropdownInputBox);
			click(coverageSituationdropdownInputBox);
			By dropdownOptions = getDynamicElement(strDropDownOptions2, "Outcome");
			waitAndVerifyElement(dropdownOptions);
			selectItemFromList(coverageSituationdropdownInputBox, dropdownOptions, situation, "Outcome");

		} catch (Exception e) {
			Log.error("Failed to enter Coverage Situation Field " + e.getMessage());
			Assert.fail("Failed to enter Coverage Situation Field " + e.getMessage());
		}
	}

	/**
	 * Function: Verify value of field (Patient has Medicare A&B only?)
	 * 
	 * @author Shanavaz Nishani
	 **/
	public void validateMedicareAandB(String value) throws Exception {
		try {
			By ele = getDynamicElement(strAccountObjectDetails, "Patient has Medicare A&B only?");
			scrollToElement(ele);
			String actualValue = getText(ele).trim();
			highLightElement(ele);
			if (actualValue.equalsIgnoreCase(value)) {
				LoggingInfo("Medicare A&B only - Field value is as expected: " + actualValue);
			} else {
				Assert.fail("Medicare A&B only - Field value Expected: " + value + " but Found: " + actualValue);
			}
		} catch (Exception e) {
			Log.error("Failed to verify Medicare A&B only - " + e.getMessage());
			Assert.fail("Failed to verify Medicare A&B only - " + e.getMessage());
		}

	}

	/**
	 * Function:Validate fields is Enabled or Disabled
	 * 
	 * @author Shraddha Shetty
	 **/

	public void validateFieldsAreEnableOrDisable(String fieldLabel, boolean value) {

		try {
			By fieldLocator = getDynamicElement(strfieldInputBox, fieldLabel);
			scrollToElement(fieldLocator);
			// By editBtn = getDynamicElement(strfieldEditButton, fieldLabel);
			By editBtn = By.xpath(MessageFormat.format(strfieldEditButton, fieldLabel));
			Boolean expectedvalue = null;
			if (isElementPresent(editBtn)) {
				expectedvalue = true;
			} else {
				expectedvalue = false;
			}
			if (expectedvalue == value) {
				LoggingInfo(fieldLabel + " Field is enabled");
			} else {
				Log.error(fieldLabel + " Field is disabled");
			}
			setTimeOut(2000);

		} catch (Exception e) {
			Log.error("Failed to validate Fields " + e.getMessage());
			Assert.fail("Failed to validate Fields " + e.getMessage());
		}
	}

	/**
	 * Function:Validate field value
	 * 
	 * @author Shraddha Shetty
	 **/

	public void validateFields(String fieldLabel, String expectedvalue) {

		try {
			By inputBox = getDynamicElement(strfieldInputBox, fieldLabel);
			waitAndVerifyElement(inputBox);

			String inputvalue = getText(inputBox);
			// getAttributeValue(inputBox, "value");
			Assert.assertEquals(inputvalue, expectedvalue, "Failed to verify value of : " + fieldLabel);
			LoggingInfo(fieldLabel + " - value is as expected");

		} catch (Exception e) {
			Log.error("Failed to validate Fields " + e.getMessage());
			Assert.fail("Failed to validate Fields " + e.getMessage());
		}
	}

}
