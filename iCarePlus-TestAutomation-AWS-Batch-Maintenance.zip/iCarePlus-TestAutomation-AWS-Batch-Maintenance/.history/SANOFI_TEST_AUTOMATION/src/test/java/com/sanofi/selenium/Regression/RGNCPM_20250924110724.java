package com.sanofi.selenium.Regression;

import java.io.File;
import java.time.LocalDate;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.io.File;

import org.joda.time.chrono.AssembledChronology.Fields;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.model.Log;
import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
//import com.sanofi.selenium.pages.CampaignsPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
//import com.sanofi.selenium.pages.CareTeamAssignment;
import com.sanofi.selenium.pages.CopayFlow;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PAPPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;
import com.sanofi.selenium.pages.FreeGoodsPage;

public class RGNCPM extends BaseTest {

	public String filePath;
	public ReadExcel excel;
	public String fileName;
	String functionality = "Enrollment";

	public static double getRandomNumber(double min, double max) {
		double x = (int) (Math.random() * ((max - min) + 1)) + min;
		return x;
	}
	
	double randomNum = getRandomNumber(1111, 9999);

	
	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		copayFlow = GetInstance(CopayFlow.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		triagePage = GetInstance(TriagePage.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		// campaigns=GetInstance(CampaignsPage.class);
		papPage = GetInstance(PAPPage.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		documentsPage = GetInstance(DocumentPage.class);

		sheetName = "PDF_Data";
		excel = new ReadExcel(sheetName);
	}

/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-18068 RGN-CPM: Automate SIT_Consent Management /Retention_SF - Scenario 2 
	 * TC012 -Validation of the Authorization Form Consent Object for HCP, 
	 * Email and Text Consents where Patient's 21 Birthday + 180 > Consent Signed Date+ 540 for Puerto Rico
	 * 
	 * @author Shanavaz Nishani
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "SIT_Consent Management /Retention_SF - Scenario 2 -TC012 -Validation of the Authorization Form Consent Object for HCP, Email and Text Consents where Patient's 21 Birthday + 180 > Consent Signed Date+ 540 for Puerto Rico", enabled = true)
	public void RGNCPM03_IC5089_Validation_of_the_Authorization_Form_Consent_Object_for_HCP_Email_and_Text_Consents_where_Patients_21_Birthday_plus_180_GreaterThan_Consent_Signed_Date_plus_540_for_Puerto_Rico()
			throws Exception {
		Logger("Pre-Requisite 01: Update test data in excel test data sheet as per test case requirement");

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String testCaseNumber = "TC4";

		String columnName[] = { "Patient DOB", "Patient Certifications Date", "State", "Voicemail", "Diagnosis Code",
				"Text Messaging Consent", "Best Timing Afternoon", "Text", "Patient Email", "Patient Primary Phone",
				"Prescriber Signature Date" };
		String columnValue[] = { "05-06-2005", "05-30-2025", "Puerto Rico", "True", "J33.0 - Polyp of nasal cavity",
				"TRUE", "TRUE", "TRUE", "abc12@gmail.com", "7898789899", "" };

		excelDataUpdate.selectExcelSheet(functionality);
		excelDataUpdate.updateExcelData(testCaseNumber, columnName, columnValue);
		ExcelTestData = excel.getExcelInputData(testCaseNumber);

		Logger("Pre-Requisite 02: User updates the Patient Form");
		updatepdf.selectEnrollmentForm("Nasal Polyps");
		filePath = updatepdf.PDFCreation(testCaseNumber, functionality);
		updatepdf.updatePDFForm(testCaseNumber, functionality);
		System.out.println(filePath);

		Logger("Pre-Requisite STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName),
				ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("Pre-Requisite STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath, cpeDetails);

		Logger("Pre-Requisite STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

		// Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on
		// the record and click on 'Assign to me' button.");
		// documentsPage.navigateToReceiveddocument();
		// documentsPage.verifyAndAssignDocID(documentID);

		Logger("Pre-Requisite STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		// Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR
		// status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("Pre-Requisite STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' 	button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("Pre-Requisite STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent	document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("Pre-Requisite STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();

		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("Pre-Requisite STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName,
				patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip),
				careProgramProduct.get(0),
				ExcelTestData.get(patientDOB));
		prescriberInformationPage.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("Pre-Requisite STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		String[] legalRepName = updatepdf.splitFullName(ExcelTestData.get(legalRepresentativeName));
		String legalRepFirstName = legalRepName[0];
		String legalRepLastName = legalRepName[2];

		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender),
				ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city),
				ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0),
				ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.enterContactInformation(ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone),
				ExcelTestData.get(voicemail), ExcelTestData.get(text),
				ExcelTestData.get(bestTimingAM),
				ExcelTestData.get(bestTimingAfternoon), ExcelTestData.get(bestTimingPM),
				ExcelTestData.get(patientSecondaryphone));
		patientInfo.enterLegalRepDetails(legalRepFirstName, legalRepLastName,
				ExcelTestData.get(legalrelationship));
		patientInfo.clickOnNextButton();

		// Patient Insurance - Page
		Logger("Pre-Requisite STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));

		insuranceinfo.clickOnNextButton();

		Logger("Pre-Requisite STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName,
				ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName,
				ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("Pre-Requisite STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode),
				ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
		String formattedDate = currentDate.format(formatter);
		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured),
				ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), formattedDate, mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("Pre-Requisite STEP 10: User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		documentsPage.verifyRecentlyViewDocumentList();

		Logger("STEP 2: Navigate to the 'App Launcher' and select the 'iCare Connect' app.");
		accountObject.globalSearch("Accounts", ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 3: Verify that user is able to navigate to Authorization Form Consent object and is able to view below mentioned records");
		accountObject.navigateToAuthFormConsentTable();
		accountObject.validateConsentRecords(consentNames.get(5));
		accountObject.validateConsentRecords(consentNames.get(1));
		accountObject.validateConsentRecords(consentNames.get(4));
		accountObject.validateConsentRecords(consentNames.get(3));
		accountObject.validateConsentRecords(consentNames.get(2));
		accountObject.validateConsentRecords(consentNames.get(7));

		Logger("STEP 4: Click on HCP Authorization and verify user is navigated to Authorization Form Consent → HCP Authorization.Validate that 1.Status: Active, 2.Consent Capture Date: Date of Signature [(MM/DD/YYYY), AM/PM)]. Validate that Consent Expiration Date Time is set as BLANK.");
		accountObject.verifyHCPAuthorization(ExcelTestData.get(patientName));
		accountObject.validateConsentStatusField("Active");
		accountObject.validateConsentSignedDate(formattedDate);

		Logger("STEP 5: Click on Email Communication and verify user is navigated to Authorization Form Consent → Email Communication Consent");
		accountObject.navigateToAccountRecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyEmailAuthorization(ExcelTestData.get(patientName), ExcelTestData.get(state),
				ExcelTestData.get(patientDOB), ExcelTestData.get(patientCertificationsDate));
		accountObject.validateConsentStatusField("Active");
		accountObject.validateConsentSignedDate(formattedDate);

		Logger("STEP 6: Click on General Marketing and verify user is navigated to Authorization Form Consent → General Marketing Consent");
		accountObject.navigateToAccountRecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyGeneralAuthorization(ExcelTestData.get(patientName), ExcelTestData.get(state),
				ExcelTestData.get(patientDOB), ExcelTestData.get(patientCertificationsDate));
		accountObject.validateConsentStatusField("Active");
		accountObject.validateConsentSignedDate(formattedDate);

		Logger("STEP 7: Click on Written/Mail Communication and verify user is navigated to Authorization Form Consent → Written/Mail Communication Consent");
		accountObject.navigateToAccountRecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyWrittenMailAuthorization(ExcelTestData.get(patientName), ExcelTestData.get(state),
				ExcelTestData.get(patientDOB), ExcelTestData.get(patientCertificationsDate));
		accountObject.validateConsentStatusField("Active");
		accountObject.validateConsentSignedDate(formattedDate);

		Logger("STEP 8: Click on Telephone Communication and verify user is navigated to Authorization Form Consent → Telephone Communication Consent");
		accountObject.navigateToAccountRecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyTelephoneAuthorization(ExcelTestData.get(patientName), ExcelTestData.get(state),
				ExcelTestData.get(patientDOB), ExcelTestData.get(patientCertificationsDate));
		accountObject.validateConsentStatusField("Active");
		accountObject.validateConsentSignedDate(formattedDate);

		Logger("STEP 9: Click on Text Messaging and verify user is navigated to Authorization Form Consent → Text Messaging Consent");
		accountObject.navigateToAccountRecord(ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));
		accountObject.verifyTextMessagingAuthorization(ExcelTestData.get(patientName), ExcelTestData.get(state),
				ExcelTestData.get(patientDOB), ExcelTestData.get(patientCertificationsDate));
		accountObject.validateConsentStatusField("Active");
		accountObject.validateConsentSignedDate(formattedDate);

		Logger("STEP 10: User Logout the Application.");
		documentsPage.logout();

	}

}