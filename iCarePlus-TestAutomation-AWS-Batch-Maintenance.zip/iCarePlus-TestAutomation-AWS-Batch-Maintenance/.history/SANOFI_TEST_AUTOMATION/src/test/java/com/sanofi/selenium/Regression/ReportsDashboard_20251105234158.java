package com.sanofi.selenium.Regression;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.AuthorizationFormConsentPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.HealthcareAccountSearch;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;

public class ReportsDashboard extends BaseTest {
	public String filePath;
	public ReadExcel excel;
	public String fileName;
	String functionality = "ReportsDashboard";
	


	@BeforeMethod
	public void setUp() {
		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		authorizationConsentPage = GetInstance(AuthorizationFormConsentPage.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		sheetName = "ReportsDashboard";
		excel = new ReadExcel(sheetName);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		uploadDocs = GetInstance(UploadDocument.class);
		triagePage = GetInstance(TriagePage.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		hcAccountSearch = GetInstance(HealthcareAccountSearch.class);

	}
	

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE- 6370 To validate Program Coordinator Home Page
	 * 
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "To validate Program Coordinator Home Page", enabled = true)
	public void RD01_IC6370_To_validate_Program_Coordinator_Home_Page() throws Exception {
		
		Logger("STEP 1:Login to the SIT Org as 'Program Co-ordinator User");
		homeportalPage = loginPage.userLogin(PCUserName, UserPassword);
		
		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Home' Object.");
	     homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(4), DocumentPage.class);

		Logger("STEP 3: Validate that the home page has a component, titled as My PSQA Review Documents having a list View of Received Documents assigned to the user");
		accountObject.verifyMYPSQAReviewDocuments();
		
		Logger("STEP 4: Validate that the home page have a widget( showing the count of PSQA Reviews in \"Needing Attention\" Status and Click on the widget  ");
		accountObject.verifyAndClickOnPSQAWidget();
		
		Logger("STEP 5: Validate that the user is redirected to the PSQA review worklist ");
		accountObject.verifyPSQAReviewPage();
		
		Logger("STEP 6: Validate that the home page contains widget showing the count of CPEs in the Care Team Assignment Queue and click on it ");
		accountObject.verifyAndClickOnCPEAssignmentWidget();
		
		Logger("STEP 7: Validate that the user is redirected to the Care Team Assignment queue.");
		accountObject.verifyCPEQueuePage();
		
		Logger("STEP 8: User Logout the Application.");
		documentsPage.logout();

	}
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE- 27033 Verify Dashboard and Report Access for PM and BO Users Across Roles
	 * 
	 * 
	 * @author Shraddha Shetty
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "Verify Dashboard and Report Access for PM and BO Users Across Roles", enabled = true)
	public void RD02_IC21509_Verify_Dashboard_and_Report_Access_for_PM_and_BO_Users_Across_Roles() throws Exception {
		int numberOfUsers = 2;
		
		for (int i = 0; i < numberOfUsers; i++) {
			try {
				switch (i) {
				case 0:
					Logger("STEP 1: Login to the QA_SIT Org as 'PM Manager'.");
					homeportalPage = loginPage.userLogin(PMUserName, UserPassword);
					break;
				case 1:
					Logger("STEP 1: Login to the QA_SIT Org as 'BO User'.");
					homeportalPage = loginPage.userLogin(BusinessOpsUserName, UserPassword);
					break;
				}
				Logger("STEP 2: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Dashboard' Object.");
			    homeportalPage.closeTabs();
				documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(24), DocumentPage.class);

				Logger("STEP 3: Navigated to All dashboard and All Folders");
				accountObject.navigateToFolderSideBarOption(DashboardSideBarOptions.get(0));
				accountObject.navigateToFolderSideBarOption(DashboardSideBarOptions.get(1));
				
				Logger("STEP 4: Validate the User is able to see all the Dashboards present on the system of all the Users");
				accountObject.validateDashboardFolders(dashboardFolders);
				
				Logger("STEP 5: Now Open the PM dashboard and Validate user can see the data present on the different reports on the dashboard");
				accountObject.navigateToFolderSideBarOption(DashboardSideBarOptions.get(0));
				accountObject.openDashboardFolder(dashboardFolders.get(2));
				accountObject.validateAllComponents();
				
				Logger("STEP 6: Open any CPE record and Validate that the user is able to open CPE");
				if(i == 0) {
					accountObject.openCPERecordfromDashboard();
				}else {
					getWebDriver().switchTo().defaultContent();
				}
				
				Logger("STEP 7: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Report' Object and Navigate to All Reports");
				homeportalPage.closeTabs();
				documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(25), DocumentPage.class);
				accountObject.navigateToFolderSideBarOption(ReportsSideBarOptions.get(0));
				
				Logger("STEP 8: Validate user is able to access reports");
				accountObject.openReportsFolder(reportsFolders.get(0));
				accountObject.navigateToTab("All Reports");
				accountObject.closeTab(reportsFolders.get(0));
				accountObject.openReportsFolder(reportsFolders.get(1));
				accountObject.navigateToTab("All Reports");
				accountObject.closeTab("All Reports");
				
				Logger("STEP 9: User Logout the Application.");
				documentsPage.logout();
			} catch (Exception e) {
				Logger("Test failed for user " + i + " due to error: " + e.getMessage());
				documentsPage.logout();
			}
		}
		
	}
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-24888 To Validate ARS Dashboard
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "To Validate ARS Dashboard", enabled = true)
	public void RD02_IC24888_To_Validate_ARS_Dashboard() throws Exception {
		
		Logger("STEP 1:Login to the Org as 'ARS User");
		homeportalPage = loginPage.userLogin(ARSUserName, UserPassword);
	    homeportalPage.closeTabs();

		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Home' Object.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(4), DocumentPage.class);
		
		Logger("STEP 3:	User is landed on Home Page>>Verify Home Page Dashboard is named as AR Specialist Homepage.");
		accountObject.verifyARHomepageTitle();

		Logger("STEP 4:	Verify These Reports are visible on ARS Dashboard to ARS user:");
		String[] reports= {"Patients' Missing Information", "My Open Tasks","Open Cases","Aging Cases","Received Documents","My Failed Correspondence"};
		accountObject.verifyReports(reports);
		
		Logger("STEP 5:Click on  View Report button. >>Click On Filter ICON and Verify these Filter criteria is added:>>‘AR in Progress’ checkbox = TRUE>>AR Specialist stamped on corresponding CPE record = Logged in ARS user for all reports");
		accountObject.clickReportAndVerifyARInProgress(condition.get(0),reports);
		
		Logger("STEP 6:Verify reports should not be included in the ARS Dashboard:");
		String[] reportsToVerify = { "My Patients Free Goods Eligibility", "Active QS with Approved PA", "Voicemails",
				"Dual Path patients", "My Way App Activity" };
		accountObject.verifyReportsNotPresent(reportsToVerify);

		Logger("STEP 7: Log out as ARS User from TOLE UAT org");
		documentsPage.logout();
		
		Logger("STEP 8:Log in to TOLE UAT Org as Dupixent Case Manager user.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
	    homeportalPage.closeTabs();
	    
        Logger("STEP 9: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Home' Object.");
 		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(4), DocumentPage.class);	

 		Logger("STEP 10:User is landed on Home Page>>Verify Home Page Dashboard is named as Case Manager Homepage");
		accountObject.verifyCaseManagerHomepageTitle();
		
		Logger("STEP 11:Click on 'Reports' View Report button. >>Click On Filter ICON and Verify these Filter criteria is added:>>‘AR in Progress’ checkbox = False");
		accountObject.clickReportAndVerifyARInProgress2(condition.get(1),reports);
		
		Logger("STEP 12: Validate no Changes are performed on these reports:");
		String[] reportsToVerifyNoChanges = { "My Patients Free Goods Eligibility", "Active QS with Approved PA",
				"VoiceMails", "My Way App Activity" };		
		accountObject.clickReportAndVerifyNoChanges(reportsToVerifyNoChanges);
		
		Logger("STEP 13: Log out from the org");
		documentsPage.logout();	
	}
}
