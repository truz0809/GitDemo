package com.sanofi.selenium.Regression;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sanofi.selenium.core.BaseTest;
import com.sanofi.selenium.core.ExcelDataUpdate;
import com.sanofi.selenium.core.GenerateTestData;
import com.sanofi.selenium.core.UpdatePDF;
import com.sanofi.selenium.core.UploadDocument;
import com.sanofi.selenium.core.Utility_Function;
import com.sanofi.selenium.pages.AccountObject;
import com.sanofi.selenium.pages.AssessmentTasksPage;
import com.sanofi.selenium.pages.AuthorizationFormConsentPage;
import com.sanofi.selenium.pages.BenefitVerificationPage;
import com.sanofi.selenium.pages.CareProgramEnrolleePage;
import com.sanofi.selenium.pages.ConsentCaptureDate;
import com.sanofi.selenium.pages.CopayFlow;
import com.sanofi.selenium.pages.DUPIXENTMyWayPortal;
import com.sanofi.selenium.pages.DiagnosisInfo;
import com.sanofi.selenium.pages.DocumentManagementPage;
import com.sanofi.selenium.pages.DocumentPage;
import com.sanofi.selenium.pages.FormConfirmation;
import com.sanofi.selenium.pages.HealthcareAccountSearch;
import com.sanofi.selenium.pages.IAPPage;
import com.sanofi.selenium.pages.InsuranceInformation;
import com.sanofi.selenium.pages.MissingInformatioPage;
import com.sanofi.selenium.pages.PAAndAppealsPage;
import com.sanofi.selenium.pages.PatientInformationAndAuthorizationPage;
import com.sanofi.selenium.pages.PatientSearchPage;
import com.sanofi.selenium.pages.PrescriberInformationPage;
import com.sanofi.selenium.pages.PrescriptionInformation;
import com.sanofi.selenium.pages.QuickStartPage;
import com.sanofi.selenium.pages.TriagePage;
import com.sanofi.selenium.utils.ReadExcel;

public class PatientEducation  extends BaseTest {

	private static ThreadLocal<String> filePath = new ThreadLocal<>();
	public ReadExcel excel;
	public String fileName;
	String functionality = "PatientEducation";
	
	@BeforeMethod
	public void setUp() {

		utilityPage = GetInstance(Utility_Function.class);
		insuranceinfo = GetInstance(InsuranceInformation.class);
		diagnosisinformation = GetInstance(DiagnosisInfo.class);
		prescriptioninformation = GetInstance(PrescriptionInformation.class);
		updatepdf = GetInstance(UpdatePDF.class);
		patientSearch = GetInstance(PatientSearchPage.class);
		patientInfo = GetInstance(PatientInformationAndAuthorizationPage.class);
		prescriberInformationPage = GetInstance(PrescriberInformationPage.class);
		formConfirmation = GetInstance(FormConfirmation.class);
		accountObject = GetInstance(AccountObject.class);
		documentsPage = GetInstance(DocumentPage.class);
		generateTestData = GetInstance(GenerateTestData.class);
		excelDataUpdate = GetInstance(ExcelDataUpdate.class);
		bvPage = GetInstance(BenefitVerificationPage.class);
		paAppealsPage = GetInstance(PAAndAppealsPage.class);
		iapPage = GetInstance(IAPPage.class);
		uploadDocs = GetInstance(UploadDocument.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		authorizationConsentPage = GetInstance(AuthorizationFormConsentPage.class);
		docMgmt = GetInstance(DocumentManagementPage.class);
		sheetName = "PatientEducation";
		excel = new ReadExcel(sheetName);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		uploadDocs = GetInstance(UploadDocument.class);
		triagePage = GetInstance(TriagePage.class);
		quickStartPage = GetInstance(QuickStartPage.class);
		hcAccountSearch = GetInstance(HealthcareAccountSearch.class);
		authorizationConsentPage = GetInstance(AuthorizationFormConsentPage.class);
		consentCaptureDate = GetInstance(ConsentCaptureDate.class);
		missingInformatioPage = GetInstance(MissingInformatioPage.class);
		careProgram = GetInstance(CareProgramEnrolleePage.class);
		excel = new ReadExcel(sheetName);
		uploadDocs = GetInstance(UploadDocument.class);
		dupixentPortal = GetInstance(DUPIXENTMyWayPortal.class);
		assessmentTasksPage = GetInstance(AssessmentTasksPage.class);
		copayFlow = GetInstance(CopayFlow.class);

	}
	

	@Test(description = "Pre-Requisite : Generate test data for test cases", enabled = true)
	public void ExcelTestDataGeneration() throws Exception {
		Logger("Pre-Requisite : Generate test data for enrpllment test cases");
		generateTestData.generateEnrollmentTestData(functionality);
	}

	@Test(description = "SIT_FreeGoods Workflow Patient Enrollment Prerequisites", enabled = true)
	public String PatientEducation_PatientEnrollment_Prerequisites(String testcaseNumber) throws Exception {

		Map<String, String> ExcelTestData = new HashMap<String, String>();
		String TestCaseNumber = testcaseNumber;

		Logger("Pre-Requisite 1: Update test data in excel test data sheet as per test case requirement");
		String columnName[] = { "Text Messaging Consent", "Voicemail", "Text", "Diagnosis Code", "DUPIXENT MyWay",
				"Preferred Specialty Pharmacy" };
		String columnValue[] = { "TRUE", "TRUE", "TRUE", "L20.9 - Atopic dermatitis, unspecified", "TRUE", "FALSE" };

		
		synchronized(excelDataUpdate){
			excelDataUpdate.selectExcelSheet(functionality);
			excelDataUpdate.updateExcelData(TestCaseNumber, columnName, columnValue);
			excelDataUpdate.removeExcelData(TestCaseNumber, removeColumnData_PE);
			}	
		ExcelTestData = excel.getExcelInputData(TestCaseNumber);

		Logger("Pre-Requisite : User updates the Patient Form");
		synchronized (updatepdf) {
		updatepdf.selectEnrollmentForm("Atopic Dermatitis");
		filePath.set(updatepdf.PDFCreation(TestCaseNumber, functionality));
		updatepdf.updatePDFForm(TestCaseNumber, functionality);
		}
		System.out.println(filePath.get());

		Logger("STEP 1:Login to the QA_SIT Org as 'Data Intake Specialist'.");
		homeportalPage = loginPage.userLogin(DISUserName, UserPassword);

		String[] cpeDetails = { ExcelTestData.get(patientName), ExcelTestData.get(patientDOB),
				ExcelTestData.get(patientEmail) };

		Logger("STEP 2:Upload document to Dupixent portal");
		String documentID = uploadDocs.uploadDoc(filePath.get(), cpeDetails);

		Logger("STEP 4: Navigate To Recently View Document list");
		documentsPage.verifyRecentlyViewDocumentList();

//		Logger("STEP 5:Navigate to All Received Documents and Check the checkbox on the record and click on 'Assign to me' button.");
//		documentsPage.navigateToReceiveddocument();
//		documentsPage.verifyAndAssignDocID(documentID);

		Logger("STEP 6:User will be redirected to the 'My Received Document' list view, Open the Document.");
		documentsPage.navigateToMyReceivedDocListView();
		documentsPage.navigateToMyReceivedDocument(documentID, status.get(1));

		Logger("STEP 7:Once the Document is opened, Click on refresh until the OCR status is updated to Success.");
		// documentsPage.verifyOCRStatus(documentOCRstatus.get(0));

		Logger("STEP 8:Verify docuement details and Now on ‘Classify Document’ section and fill Document Type required field data and click on 'Submit' button.");
		documentsPage.classifyDocument(documentType.get(0));
		documentsPage.submitDocument();

		Logger("STEP 9:After Submission, Validate a new child document with new record ID gets created in \"Received Document\" related list of parent document where Name of the child document(s) should be same as Name of the parent document.");
		documentsPage.verifyOCRStatus(documentOCRstatus.get(1));

		Logger("STEP 3.4: User selects valid ‘Care Program Product' field data and click on Next Button.");
		patientSearch.verifyPatientSearchPageTitle();
		String[] name = updatepdf.splitFullName(ExcelTestData.get(patientName));
		String patientFirstName = name[0];
		String patientMidName = name[1];
		String patientLastName = name[2];

		Logger("STEP 4: Verify Patient Search Page details and click on Next Button");
		patientSearch.enterPatientSearchFields(documentType.get(0), patientFirstName, patientLastName,
				ExcelTestData.get(documentTypeSelected), ExcelTestData.get(patientEmail),
				ExcelTestData.get(patientPrimaryphone), ExcelTestData.get(zip), careProgramProduct.get(2),
				ExcelTestData.get(patientDOB));
		patientSearch.clickOnNextButton();

		// patientinfoAndauthorization-Page
		Logger("STEP 5:Verify Patient Information & Authorizations Page details and click on Next Button");
		
		patientInfo.verifyPatientAuthorizationPageTitle();
		patientInfo.enterDemographicInfo(patientFirstName, patientMidName, patientLastName,
				ExcelTestData.get(patientDOB), ExcelTestData.get(gender), ExcelTestData.get(language),
				ExcelTestData.get(patientAddress), ExcelTestData.get(city), ExcelTestData.get(state),
				ExcelTestData.get(zip));
		patientInfo.enterAutherization(authorizationSigned.get(0), ExcelTestData.get(patientAuthorizationDate),
				patientcertSigned.get(0), ExcelTestData.get(patientCertificationsDate),
				ExcelTestData.get(textMessagingConsent));
		patientInfo.clickOnNextButton();


		// Patient Insurance - Page
		Logger("STEP 6:Verify Patient Insurance Inforamtion Page details and click on Next Button");
		insuranceinfo.verifyInsuranceInfoPageTitle();
		insuranceinfo.selectDupixentMyWay(ExcelTestData.get(dUPIXENTMyWay));
		insuranceinfo.selectSpecialityPharmacyCheckbox(ExcelTestData.get(preferredSpecialtyPharmacy));
		insuranceinfo.clickOnNextButton();

		Logger("STEP 7:Verify Patient Prescriber Inforamtion Page details and click on Next Button");
		String[] preName = updatepdf.splitFullName(ExcelTestData.get(prescriberName));
		String preFirstName = preName[0];
		String prLastName = preName[2];

		String[] ofcName = updatepdf.splitFullName(ExcelTestData.get(officeContactName));
		String ofcFirstName = ofcName[0];
		String ofcLastName = ofcName[2];

		prescriberInformationPage.verifyPrescriberInfoPageTitle();
		prescriberInformationPage.enterPrescriberInfo(preFirstName, prLastName, ExcelTestData.get(specialty),
				ExcelTestData.get(prescriberNPI), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberstateLicense));
		prescriberInformationPage.enterPrescriberAddressInfo(ExcelTestData.get(prescriberAddress),
				ExcelTestData.get(prescriberCity), ExcelTestData.get(prescriberState),
				ExcelTestData.get(prescriberZip));
		prescriberInformationPage.enterSiteFacilityInfo(ExcelTestData.get(sitefacilityname),
				ExcelTestData.get(officePhone), ofcFirstName, ofcLastName, ExcelTestData.get(officeContactEmail),
				ExcelTestData.get(officeFax), ExcelTestData.get(taxID));
		prescriberInformationPage.clickOnNextButton();

		// Diagnosis information-Page
		Logger("STEP 8:Verify Patient Diagnosis Inforamtion Page details and click on Next Button");
		diagnosisinformation.verifyDiagnosisInfoPageTitle();
		diagnosisinformation.enterDiagnosis(ExcelTestData.get(diagnosisCode), ExcelTestData.get(dateOfDiagnosis));
		diagnosisinformation.clickOnNextButton();

		Logger("STEP 9:Verify Patient Prescription Inforamtion Page details and click on Next Button");
		String[] mdName = updatepdf.splitFullName(ExcelTestData.get(collaboratingMDName));
		String mdFirstName = mdName[0];
		String mdLastName = mdName[2];

		prescriptioninformation.verifyPrescriptionInfoPageTitle();
		prescriptioninformation.enterPrescriptionInformation(ExcelTestData.get(prescriptionARefillCaptured),
				ExcelTestData.get(prescription5ADose), quickStartRx.get(0),
				ExcelTestData.get(prescriptionBRefillCaptured), ExcelTestData.get(prescription5BDose),
				prescriberSignature.get(0), ExcelTestData.get(prescriberSignatureDate), mdFirstName, mdLastName,
				ExcelTestData.get(NursePractitionerNPI));
		prescriptioninformation.clickOnNextButton();

		Logger("STEP 10:User Clicks on Form Confirmation Button");
		formConfirmation.clicOnFormConfirmation();
		
		Logger("STEP 11:Verify account is created ");
		accountObject.globalSearch(searchFilter.get(0), ExcelTestData.get(patientName));
		accountObject.clickOnTab(tabsName.get(1));

		Logger("STEP 12: Verify Care program enrollee record is linked to account ");
		accountObject.navigateCareProgramEnrollee();
		accountObject.cickOnCPERecord(ExcelTestData.get(patientName));

		String CPEURL = getCurrentPageURL();
		CPEURL = Utility_Function.removeQueryString(CPEURL);

		Logger("STEP 13: User Logout the Application.");
		documentsPage.logout();
		
		return CPEURL;


	}
	
	
	/**
	 * ====================================================================================================================
	 * Test Case Id:ICARE-6494 To Verify Case Manager can Create Injection Training Case on CPE
	 * 
	 * @author Anand Pawar
	 * 
	 * @throws Exception ====================================================================================================================
	 */
	@Test(description = "To Verify Case Manager can Create Injection Training Case on CPE", enabled = true)
	public void PED01_IC6494_To_Verify_case_Manager_can_Create_Injection_Training_Case_on_CPE() throws Exception {

		String TestCaseNumber = "TC1";

		// Prerequisites
		String cpeURL=PatientEducation_PatientEnrollment_Prerequisites(TestCaseNumber);
		
		Map<String, String> ExcelTestData = new HashMap<String, String>();

		ExcelTestData = excel.getExcelInputData(TestCaseNumber);
		String accountName = ExcelTestData.get(patientName);
		
		
		Logger("STEP 1: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);

		Logger("STEP 2: Navigate to the App Launcher' Search and Open 'iCare Connect' App.From App Launcher, search and click on the 'Care program enrollee' Object.");
	     homeportalPage.closeTabs();
	     
			navigateToUrl(cpeURL);
		
		Logger("STEP 5: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 6: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 7: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		copayFlow.selectService(service.get(4));
		missingInformatioPage.clickNextButton();
		copayFlow.selectReason(serviceReason.get(2));

		Logger("STEP 8: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
	
		Logger("STEP 9: User navigated to New Case : Injection Training");
		documentsPage.verifyNewCaseTitle();
		
		Logger("STEP 10: Select Account for Patient whom Injection Training is requested along with HCP associated with Patient if not auto-populated");
		documentsPage.verifyAccountAndHCPName(accountName,ExcelTestData.get(prescriberName));
		
		Logger("STEP 11:Update Type of Training Required from the following Picklist:In Person,Virtual,On Spot");
		documentsPage.selectTrainingType(trainingType.get(0));
		
		Logger("STEP 12:Update HCP training Status from the given picklist values:Received,Not Received");
		documentsPage.selectHCPTrainingStatus(trainingStatus.get(0));
		documentsPage.selectCaseStatus(caseStatus.get(0));

		Logger("STEP 13: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		Thread.sleep(2000);
		refresh();
		
		Logger("STEP 14: Verify and get case number");
		String caseNumber=documentsPage.getCaseNumber();

		Logger("STEP 15: Go to Cases object and Verify that newly created Case is visible to CM user in DMW Nurse Educator List view.");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5), DocumentPage.class);
		documentsPage.navigateNurseEducatorsListView();
		accountObject.searchRecord(caseNumber);
		docMgmt.verifyColumnsHeaderCases(columnsDMWNurseEducators);

		Logger("STEP 16: User Logout the Application as CM User");
		documentsPage.logout();

		Logger("STEP 17: Login to the QA_SIT Org as 'Nurse Educator'.");
		homeportalPage = loginPage.userLogin(NurseEduUserName, UserPassword);

		Logger("STEP 18: Navigate to the App Launcher' Search and Navigate to Cases object and switch to DMW Nurse Educator Listview.");
	    homeportalPage.closeTabs();
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5), DocumentPage.class);
		
		Logger("STEP 19: Verify newly created case by Case Manager is visible to Nurse Educator User in List view.");
		documentsPage.navigateNurseEducatorsListView();
		refresh();
		accountObject.searchRecord(caseNumber);
		docMgmt.validateRecordPresent(caseNumber);

		Logger("STEP 20: User Logout the Application as CM User");
		documentsPage.logout();
		
		Logger("STEP 21: Login to the QA_SIT Org as 'Case Manger'.");
		homeportalPage = loginPage.userLogin(CMUserName, UserPassword);
		
		navigateToUrl(cpeURL);
		Thread.sleep(4000);
		
		
		Logger("STEP 22: On the CPE record, validate the visibility of the new button \"Start New Services\" on the top right side of the UI");
		iapPage.verifyStartNewServiceButton();

		Logger("STEP 23: Click on the button \"Start New Services\"");
		iapPage.clickOnStartNewService();

		Logger("STEP 24: User will see two fields: 1. Start Service : Pick the value as \"Interim Assistance Program\" 2. Reason: Any one");
		iapPage.verifyServiceTitle();
		copayFlow.selectService(service.get(4));
		missingInformatioPage.clickNextButton();
		copayFlow.selectReason(serviceReason.get(2));

		Logger("STEP 25: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
	
		Logger("STEP 26: User navigated to New Case : Injection Training");
		documentsPage.verifyNewCaseTitle();
		
		Logger("STEP 27:Update Type of Training Required from the following Picklist:In Person,Virtual,On Spot");
		documentsPage.selectTrainingType(trainingType.get(0));
		
		Logger("STEP 28:Update HCP training Status from the given picklist values:Received,Not Received");
		documentsPage.selectHCPTrainingStatus(trainingStatus.get(0));
		
		Logger("STEP 29:Select case status as closed");
		documentsPage.selectCaseStatus(caseStatus.get(1));
		documentsPage.selectNursingOutcome(nursingOutcome.get(0));
		documentsPage.selectNursingOutcomeReason(nursingOutcomeReason.get(0));

		Logger("STEP 30: Click on Save button");
		missingInformatioPage.clickOnSaveButton();
		refresh();
		
		Logger("STEP 31: Verify and get case number");
		String closedCaseNumber=documentsPage.getCaseNumber();
		
		Logger("STEP 32: Verify When Status is select Collected, Not Collected and Closed then it will not get into DMW Nurse Educator Listview");
		documentsPage = homeportalPage.selectItemFromAppLauncher(appLauncherMenuItem.get(5), DocumentPage.class);
		documentsPage.navigateNurseEducatorsListView();
		accountObject.searchRecord(closedCaseNumber);
		docMgmt.verifyCaseRecordNotVisibleAsDMWNurseEducatorListView(closedCaseNumber);

		Logger("STEP 33: User Logout the Application as CM User");
		documentsPage.logout();
		
		
	}
	
	


}
